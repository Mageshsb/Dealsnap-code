import type { MetadataRoute } from "next";
import { getSiteSettings } from "@/lib/site-settings";
import { getSiteUrl } from "@/lib/site-url";
import { isStaging } from "@/lib/environment";

// Read fresh on every request, so a test copy (DEALSNAP_ENV) is hidden even from a shared build.
export const dynamic = "force-dynamic";

const AI_TRAINING_CRAWLERS = ["GPTBot", "CCBot", "Google-Extended", "ClaudeBot", "anthropic-ai", "Bytespider", "Applebot-Extended", "meta-externalagent", "Amazonbot", "cohere-training-data-crawler", "Diffbot", "omgili"];

// Served at /robots.txt. The "hide from search engines" switch in
// /admin/settings turns the whole site off for crawlers (use it on a test copy).
export default async function robots(): Promise<MetadataRoute.Robots> {
  if (isStaging || getSiteSettings().hideFromSearchEngines) {
    return { rules: { userAgent: "*", disallow: "/" } };
  }
  return {
    sitemap: `${await getSiteUrl()}/sitemap.xml`,
    rules: [
      { userAgent: "*", allow: "/", disallow: ["/admin", "/api/", "/go/", "/out/", "/pick/", "/visit/", "/ad-report/", "/media-kit/", "/login", "/signup", "/profile", "/account", "/notifications", "/saved", "/alerts", "/feed", "/settings", "/member/", "/email/", "/community/new"] },
      // Crawlers that copy sites to train AI models: members' deals and
      // comments aren't theirs to take. (AI search tools that link back,
      // like ChatGPT search and Perplexity, are still welcome above. The
      // live site's Cloudflare "Block AI bots" setting enforces this for
      // crawlers that ignore robots.txt.)
      { userAgent: AI_TRAINING_CRAWLERS, disallow: "/" },
    ],
  };
}
