import { NextResponse, type NextRequest } from "next/server";
import { getCampaign, getRunningCampaigns } from "@/lib/db";
import { countClick } from "@/lib/ad-serving";
import { isAdSlotId } from "@/lib/ads";
import { ukDay } from "@/lib/events";
import { LIMITS, overLimit } from "@/lib/rate-limit";

// A tap on an ad: counted (lib/ad-serving.ts says what counts), then sent on
// to the advertiser's page. Where it goes is always the campaign's saved link,
// checked when it was saved, never anything from the address, so this can't
// be used to send people somewhere else.
// DealSnap's tracking tags on the advertiser's link, so their own analytics
// show the visits and sales that came from here (what they're paying for).
// A link that already has its own tags is left alone.
function tagged(link: string, campaign: string, slot: string | null): string {
  try {
    const url = new URL(link);
    if (url.searchParams.has("utm_source")) return link;
    url.searchParams.set("utm_source", "dealsnap");
    url.searchParams.set("utm_medium", "display");
    url.searchParams.set("utm_campaign", campaign.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60) || "campaign");
    if (isAdSlotId(slot)) url.searchParams.set("utm_content", slot);
    return url.toString();
  } catch {
    return link;
  }
}

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const campaign = /^[0-9a-f-]{36}$/.test(id) ? getCampaign(id) : undefined;
  if (!campaign) return NextResponse.redirect(new URL("/", request.url));
  const slot = request.nextUrl.searchParams.get("s");
  // Counted only while the campaign is really running (live, inside its dates)
  // in a space it's booked in (countClick checks the space), so a tap can't be
  // made to add clicks to a paused or finished campaign.
  if (isAdSlotId(slot) && getRunningCampaigns(ukDay()).some((c) => c.id === campaign.id) && !(await overLimit("visit", LIMITS.go))) {
    await countClick(campaign, slot);
  }
  const to = campaign.linkUrl.startsWith("/") ? new URL(campaign.linkUrl, request.url) : tagged(campaign.linkUrl, campaign.name, slot);
  const res = NextResponse.redirect(to, 302);
  res.headers.set("Cache-Control", "no-store");
  res.headers.set("X-Robots-Tag", "noindex, nofollow");
  return res;
}
