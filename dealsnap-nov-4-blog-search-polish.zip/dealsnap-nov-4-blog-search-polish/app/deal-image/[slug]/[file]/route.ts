import { dealPhotoIsShown } from "@/lib/pictures";
import { getPicture } from "@/lib/picture-store";

// Serves a deal's photo: "<id>.webp" (up to 1200px) or "<id>-sm.webp"
// (480px, for lists). A replaced photo gets a new id, so a copy is always
// still right, but a deal can be taken down. So browsers keep a photo for a
// day and Cloudflare (or any shared cache) for an hour: a photo of a removed
// deal is gone from everywhere within the hour, and for anyone who already
// has it, within a day. After that, asking again costs almost nothing: the id
// is the version, so we answer "unchanged" without sending the photo. The
// files are kept by lib/picture-store.ts.
const BROWSER_SECONDS = 24 * 60 * 60;
const SHARED_CACHE_SECONDS = 60 * 60;

export async function GET(request: Request, { params }: { params: Promise<{ slug: string; file: string }> }) {
  const { slug, file } = await params;
  const match = /^[a-z0-9-]{1,200}$/.test(slug) ? file.match(/^([a-z0-9]{1,24})(-sm)?\.webp$/) : null;
  if (!match || !/^[a-f0-9]{24}$/.test(match[1]) || !dealPhotoIsShown(slug, match[1])) {
    return new Response("Not found", { status: 404 });
  }
  const headers = {
    "Cache-Control": `public, max-age=${BROWSER_SECONDS}, s-maxage=${SHARED_CACHE_SECONDS}`,
    ETag: `"${match[1]}${match[2] ? "-sm" : ""}"`,
    "X-Content-Type-Options": "nosniff",
  };
  if (request.headers.get("if-none-match") === headers.ETag) return new Response(null, { status: 304, headers });

  const data = await getPicture(match[1], match[2] ? "sm" : "full");
  if (!data) return new Response("Not found", { status: 404 });

  return new Response(new Uint8Array(data), {
    headers: {
      ...headers,
      "Content-Type": "image/webp",
      // Only ever a picture: nothing in it can run as a page.
      "Content-Security-Policy": "default-src 'none'; sandbox",
    },
  });
}
