import type { Metadata } from "next";
import { notFound } from "next/navigation";
import SitePageView from "@/components/SitePageView";
import { getCurrentUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { getSitePage, pageMetadata } from "@/lib/site-pages";

// A page the team added in Admin → Pages (the built-in ones have their own
// addresses). One that isn't published is only visible to people who can
// manage pages, so it can be checked before it goes live.
type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ topic?: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const page = getSitePage(slug);
  if (!page || page.builtin) return { title: "Page not found" };
  return { ...pageMetadata(slug), ...(page.published ? {} : { robots: { index: false } }) };
}

export default async function CustomPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const { topic } = await searchParams;
  const page = getSitePage(slug);
  if (!page || page.builtin) notFound();
  if (!page.published) {
    const user = await getCurrentUser();
    if (!user || user.suspended || !can(user.role, "pages.manage")) notFound();
  }
  return <SitePageView page={page} topic={topic} />;
}
