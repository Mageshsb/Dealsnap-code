import Link from "next/link";
import SiteMark from "@/components/SiteMark";
import Icon, { type IconName } from "@/components/Icon";
import MoreFromDealSnap from "@/components/MoreFromDealSnap";
import SitePageView from "@/components/SitePageView";
import { getSitePage, pageMetadata } from "@/lib/site-pages";
import { getAboutWords } from "@/lib/about-words";
import { getSiteName } from "@/lib/site-url";

const DESIGNED = {
  title: "About",
  description: "DealSnap is a UK deals community: shoppers post the bargains they find and everyone else loves the best ones to the top. Here's our story.",
  alternates: { canonical: "/about" },
};

// The built-in design below, unless the page has been given its own HTML (Admin → Pages).
export function generateMetadata() {
  if (getSitePage("about")?.format === "html") return pageMetadata("about");
  return { ...DESIGNED, description: DESIGNED.description.replace("DealSnap", getSiteName()) };
}

const card = "rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900";
const link = "font-medium text-orange-700 underline-offset-2 hover:underline dark:text-orange-400";

// The icons are part of the design; the words come from Admin → Wording → About page.
const STEP_ICONS: IconName[] = ["eye", "camera", "heart", "shopping-bag"];
const BELIEF_ICONS: IconName[] = ["users", "scale", "comment", "pound"];

export default function AboutPage() {
  const page = getSitePage("about");
  if (page?.format === "html") {
    return (
      <SitePageView page={page}>
        <MoreFromDealSnap />
      </SitePageView>
    );
  }
  const w = getAboutWords();
  const STEPS = STEP_ICONS.map((icon, i) => ({ icon, title: w[`step${i + 1}Title`], body: w[`step${i + 1}Body`] }));
  const BELIEFS = BELIEF_ICONS.map((icon, i) => ({ icon, title: w[`belief${i + 1}Title`], body: w[`belief${i + 1}Body`] }));
  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-10 px-4 py-6">
      {/* Hello */}
      <section className="relative flex flex-col items-start gap-3 overflow-hidden rounded-2xl bg-linear-to-br from-orange-500 to-amber-400 p-6 text-white sm:p-10">
        {/* A few price tags drifting off the corner, just for fun. */}
        <div aria-hidden className="pointer-events-none absolute -right-6 -bottom-10 hidden text-white/15 sm:block">
          <Icon name="tag" className="size-56 rotate-12" />
        </div>
        <div aria-hidden className="pointer-events-none absolute top-6 right-40 hidden text-white/10 lg:block">
          <Icon name="heart" className="size-20 -rotate-12" />
        </div>
        <SiteMark className="relative h-11 w-11 rounded-xl bg-white p-1.5" />
        <h1 className="relative text-2xl font-extrabold leading-tight text-balance sm:text-4xl lg:text-5xl">{w.headline}</h1>
        <p className="relative max-w-xl text-base leading-relaxed text-white/90 sm:text-lg">
          {w.intro}
        </p>
      </section>

      {/* The story */}
      <section aria-labelledby="story" className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1fr)_18rem] lg:gap-12">
        <div className="flex max-w-2xl flex-col gap-3 text-[15px] leading-relaxed text-zinc-700 dark:text-zinc-300">
          <h2 id="story" className="text-xl font-bold text-zinc-900 dark:text-zinc-100">How it started</h2>
          <p>{w.story1}</p>
          <p>{w.story2}</p>
          <p>{w.story3}</p>
        </div>
        <figure className="hidden flex-col gap-3 self-center border-l-4 border-orange-400 py-2 pl-6 lg:flex">
          <blockquote className="text-2xl font-bold leading-snug text-zinc-900 text-balance dark:text-zinc-100">
            {w.quote}
          </blockquote>
          <figcaption className="text-sm text-zinc-500">{w.quoteBy}</figcaption>
        </figure>
      </section>

      {/* How it works */}
      <section aria-labelledby="how" className="flex flex-col gap-3">
        <h2 id="how" className="text-xl font-bold">How it works</h2>
        <ol className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((s, i) => (
            <li key={s.title} className={`flex gap-3 p-4 lg:flex-col lg:p-5 ${card}`}>
              <span aria-hidden className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-orange-50 text-orange-700 dark:text-orange-400 dark:bg-orange-950/40">
                <Icon name={s.icon} className="size-5" />
              </span>
              <div className="flex flex-col gap-0.5">
                <h3 className="font-semibold">
                  <span className="text-orange-700 dark:text-orange-400">{i + 1}.</span> {s.title}
                </h3>
                <p className="text-sm leading-relaxed text-zinc-600 dark:text-zinc-400">{s.body}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      {/* What we care about */}
      <section aria-labelledby="beliefs" className="flex flex-col gap-3">
        <h2 id="beliefs" className="text-xl font-bold">What we care about</h2>
        <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {BELIEFS.map((b) => (
            <li key={b.title} className={`flex gap-3 p-4 sm:p-5 ${card}`}>
              <span className="flex w-6 shrink-0 justify-center pt-0.5">
                <Icon name={b.icon} className="size-5 text-orange-700 dark:text-orange-400" />
              </span>
              <div className="flex flex-col gap-0.5">
                <h3 className="font-semibold">{b.title}</h3>
                <p className="text-sm leading-relaxed text-zinc-600 dark:text-zinc-400">{b.body}</p>
              </div>
            </li>
          ))}
        </ul>
        <p className="text-sm text-zinc-500">
          {w.moneyLine}{" "}
          <Link href="/terms#how-we-make-money" className={link}>How we make money</Link>
        </p>
      </section>

      {/* Join in */}
      <section className={`flex flex-col items-center gap-3 p-6 text-center ${card}`}>
        <h2 className="text-lg font-bold">{w.joinTitle}</h2>
        <p className="text-sm text-zinc-600 dark:text-zinc-400">{w.joinLine}</p>
        <div className="flex flex-wrap justify-center gap-2">
          <Link href="/submit" className="rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600">
            + Post a deal
          </Link>
          <Link
            href="/"
            className="rounded-full border border-zinc-300 px-5 py-2 text-sm font-semibold text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
          >
            Browse deals
          </Link>
        </div>
      </section>

      <p className="text-center text-sm text-zinc-500">
        Got an idea, a question or just want to say hello?{" "}
        <Link href="/contact" className={link}>Get in touch</Link>
      </p>

      <MoreFromDealSnap />
    </main>
  );
}
