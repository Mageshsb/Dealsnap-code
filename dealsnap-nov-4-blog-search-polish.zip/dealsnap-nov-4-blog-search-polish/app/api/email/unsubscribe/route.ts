import { verifyUnsubscribe } from "@/lib/email";
import { turnOffAllEmails } from "@/lib/notifications";
import { findUserById } from "@/lib/db";

// One-click unsubscribe: what Gmail, Outlook and Apple Mail call when someone
// taps their own "Unsubscribe" button (the List-Unsubscribe header).
export async function POST(request: Request) {
  const params = new URL(request.url).searchParams;
  const userId = params.get("u") ?? "";
  if (!findUserById(userId) || !verifyUnsubscribe(userId, params.get("t") ?? "")) {
    return new Response("Invalid link", { status: 400 });
  }
  turnOffAllEmails(userId);
  return new Response("Unsubscribed", { status: 200 });
}
