import { searchDeals, getDealsForView } from "@/lib/mock-deals";
import { parseLovedWindow, parseSearchSort, parseView } from "@/lib/deal-views";
import { parseMinHearts, parseSlug, parseDealType, narrowDeals } from "@/lib/deal-filters";
import { capSearch } from "@/lib/search-limits";
import { LIMITS, overLimit, tooMany } from "@/lib/rate-limit";

// Paginated deal listing for the homepage's infinite scroll. Unlike
// /api/search (used by the search dropdown and browser extension, which
// always wants a small top-N slice), this returns full Deal objects and an
// offset/limit window so the client can keep asking for "the next batch".
export async function GET(request: Request) {
  // Over the limit, the list just stops growing (no more to load).
  if (await overLimit("deals", LIMITS.deals)) return tooMany({ results: [], hasMore: false, total: 0 });
  const { searchParams } = new URL(request.url);
  const q = capSearch(searchParams.get("q"));
  const category = searchParams.get("category") ?? undefined;
  const tag = searchParams.get("tag") ?? undefined;
  const store = searchParams.get("store") ?? undefined;
  const minHearts = parseMinHearts(searchParams.get("hearts"));
  // The Category dropdown on a store page (see lib/deal-filters). The Store
  // dropdown on category/tag pages arrives as `store` above, which already narrows.
  const cat = parseSlug(searchParams.get("cat"));
  // A brand page's deals, or the Brand dropdown on a category or tag page.
  const brand = parseSlug(searchParams.get("brand")) || undefined;
  // The Deal type dropdown (vouchers, freebies…), on every list.
  const type = parseDealType(searchParams.get("type"));
  const offset = Math.max(0, parseInt(searchParams.get("offset") ?? "0", 10) || 0);
  const limit = Math.min(50, Math.max(1, parseInt(searchParams.get("limit") ?? "20", 10) || 20));

  // Search sorts by best match unless a view is picked; otherwise the chosen
  // sort view applies.
  const allDeals = narrowDeals(
    q
      ? searchDeals(q, category, tag, store, minHearts, parseSearchSort(searchParams.get("view")), brand)
      : getDealsForView(parseView(searchParams.get("view")), category, tag, store, minHearts, parseLovedWindow(searchParams.get("when")), brand),
    "",
    cat,
    type
  );
  const results = allDeals.slice(offset, offset + limit);
  const hasMore = offset + limit < allDeals.length;

  return Response.json({ results, hasMore, total: allDeals.length });
}
