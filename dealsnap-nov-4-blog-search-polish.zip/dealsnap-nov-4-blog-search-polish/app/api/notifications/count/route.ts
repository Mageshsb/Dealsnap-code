import { getCurrentUser } from "@/lib/auth";
import { countUnreadNotifications } from "@/lib/db";

// The bell's unread count, checked now and then so it updates without a reload.
export async function GET() {
  const user = await getCurrentUser();
  return Response.json(
    { count: user ? countUnreadNotifications(user.id) : 0 },
    { headers: { "Cache-Control": "no-store" } }
  );
}
