import { sqlite } from "@/lib/db";

// "Is the site up and able to read its database?" for the host's health check
// and an uptime monitor (UptimeRobot, Better Stack…). It says nothing about the
// site's contents, so it's safe to leave open; it's never cached.
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    sqlite.prepare("SELECT 1").get();
    return Response.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ ok: false }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
