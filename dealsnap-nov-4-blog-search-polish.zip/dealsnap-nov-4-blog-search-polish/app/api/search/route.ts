import { getStoreFacet, liveDealsForLink, searchBrands, searchCorrection, searchDeals, searchStores } from "@/lib/mock-deals";
import { kindAskedFor, namesIn } from "@/lib/search";
import { searchCategoriesAndTags } from "@/lib/categories";
import { dealRow } from "@/lib/deal-rows";
import { capSearch } from "@/lib/search-limits";
import { linkIn } from "@/lib/pasted-link";
import { LIMITS, overLimit, tooMany } from "@/lib/rate-limit";

const MAX_CATEGORIES = 3;
const MAX_TAGS = 5;
const MAX_STORES = 3;
const MAX_BRANDS = 3;
const MAX_DEALS = 6;

// Public read-only search endpoint — this is what the website's search bar
// and the browser extension (see /extension) both call, so the two stay in
// sync. Returns matching categories/tags (for quick navigation) alongside
// matching deals.
//
// ?link=<a shop link> (pasted into the search box) instead answers whether
// that product is already on DealSnap: its live deals, if any.
export async function GET(request: Request) {
  if (await overLimit("search", LIMITS.search)) {
    return tooMany({ categories: [], tags: [], brands: [], stores: [], results: [] });
  }
  const { searchParams } = new URL(request.url);
  if (searchParams.has("link")) {
    const link = linkIn(searchParams.get("link"));
    return Response.json(
      { categories: [], tags: [], brands: [], stores: [], results: [], link: link ? { url: link, deals: liveDealsForLink(link).map(dealRow) } : undefined },
      { headers: { "Access-Control-Allow-Origin": "*" } }
    );
  }
  const q = capSearch(searchParams.get("q"));
  const category = searchParams.get("category") ?? undefined;

  // Category, tag and store names are matched on the search with typos fixed
  // ("hedaphones" → the Headphone tag); deals fix their own (see lib/search).
  const named = q ? (searchCorrection(q) ?? q) : undefined;
  const { categories, tags } = named ? searchCategoriesAndTags(named) : { categories: [], tags: [] };

  // Store and brand names are matched without words like "voucher" or
  // "sale", so "asos voucher codes" still offers ASOS.
  const names = named ? namesIn(named) : "";
  const stores = names ? searchStores(names, MAX_STORES).map(({ name, slug, dealCount }) => ({ name, slug, dealCount })) : [];
  const brands = names ? searchBrands(names, MAX_BRANDS) : [];

  // Asking for codes ("asos voucher", "discount code"): straight to the
  // voucher codes, for the store named if it has any.
  let vouchers: { name: string; href: string; count: number } | undefined;
  if (named && kindAskedFor(named) === "voucher") {
    const withCodes = getStoreFacet({ kind: "voucher" }, 0, "");
    const store = stores.length ? withCodes.find((o) => o.slug === stores[0].slug) : undefined;
    vouchers = store
      ? { name: `${stores[0].name} voucher codes`, href: `/vouchers?store=${store.slug}`, count: store.count }
      : { name: "All voucher codes", href: "/vouchers", count: withCodes.reduce((n, o) => n + o.count, 0) };
  }

  // A brand and a type together ("apple laptop"): straight to that tag's page
  // with the Brand filter set.
  let combo: { name: string; href: string } | undefined;
  if (names && brands.length) {
    const rest = names
      .split(/\s+/)
      .filter((w) => w.toLowerCase() !== brands[0].name.toLowerCase())
      .join(" ");
    const tag = rest && rest !== names ? searchCategoriesAndTags(rest).tags[0] : undefined;
    if (tag) combo = { name: `${tag.name} made by ${brands[0].name}`, href: `/tags/${tag.slug}?brand=${brands[0].slug}` };
  }

  // Live deals come first (see searchDeals); expired ones only fill spare slots.
  // Nothing but symbols ("%", "£") isn't a search: no deals to suggest.
  const results = q && /[a-z0-9]/i.test(q) ? searchDeals(q, category).slice(0, MAX_DEALS).map(dealRow) : [];

  return Response.json(
    {
      categories: categories.slice(0, MAX_CATEGORIES),
      tags: tags.slice(0, MAX_TAGS),
      brands,
      ...(combo && { combo }),
      ...(vouchers && { vouchers }),
      stores,
      results,
    },
    { headers: { "Access-Control-Allow-Origin": "*" } }
  );
}

export async function OPTIONS() {
  return new Response(null, {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}
