import { countClicks, countViews } from "@/lib/ad-serving";
import { isAdSlotId, type AdSlotId } from "@/lib/ads";
import { overLimit } from "@/lib/rate-limit";

// The browser's list of ads that were properly seen (half on screen for a
// second), and of taps on sponsored deals, sent every few seconds and as the
// page closes (AdSpace). Only the
// site's own pages can send it; the list is small and checked item by item.
const MAX_BYTES = 4096;
const MAX_ITEMS = 50;
const ID = /^[0-9a-f-]{36}$/;

export async function POST(request: Request) {
  const site = request.headers.get("sec-fetch-site");
  if (site && site !== "same-origin") return new Response(null, { status: 403 });
  if (Number(request.headers.get("content-length") ?? 0) > MAX_BYTES) return new Response(null, { status: 413 });
  if (await overLimit("ad-seen", 60)) return new Response(null, { status: 429 });
  const text = await request.text();
  if (text.length > MAX_BYTES) return new Response(null, { status: 413 });
  let body: { v?: unknown; c?: unknown };
  try {
    body = JSON.parse(text);
  } catch {
    return new Response(null, { status: 400 });
  }
  if (!Array.isArray(body?.v) && !Array.isArray(body?.c)) return new Response(null, { status: 400 });
  // [[campaign, space], …]; anything else in the list is skipped.
  const read = (items: unknown) => {
    const out: { id: string; slot: AdSlotId }[] = [];
    for (const item of Array.isArray(items) ? items.slice(0, MAX_ITEMS) : []) {
      if (Array.isArray(item) && typeof item[0] === "string" && ID.test(item[0]) && isAdSlotId(item[1])) out.push({ id: item[0], slot: item[1] });
    }
    return out;
  };
  await countViews(read(body.v));
  // Taps on sponsored deals (other ads count theirs at /visit).
  await countClicks(read(body.c).filter((t) => t.slot === "sponsored"));
  return new Response(null, { status: 204, headers: { "Cache-Control": "no-store" } });
}
