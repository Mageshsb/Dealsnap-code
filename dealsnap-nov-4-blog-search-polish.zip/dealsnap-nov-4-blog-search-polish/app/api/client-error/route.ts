import { recordError } from "@/lib/error-log";
import { overLimit } from "@/lib/rate-limit";

// Where a visitor's browser reports a script error (components/ClientErrorReporter.tsx).
// It's open to anyone, so it's careful: same-site only, small, rate-limited, and
// it keeps only text (never anything the visitor typed or who they are).
const MAX_BYTES = 4000;

export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && new URL(origin).host !== request.headers.get("host")) return new Response(null, { status: 403 });
  if (await overLimit("client-error", 20)) return new Response(null, { status: 429 });
  const text = await request.text();
  if (text.length > MAX_BYTES) return new Response(null, { status: 413 });
  try {
    const body = JSON.parse(text) as { message?: unknown; stack?: unknown; path?: unknown };
    if (typeof body.message !== "string" || !body.message.trim()) return new Response(null, { status: 400 });
    recordError({
      kind: "browser",
      message: body.message,
      stack: typeof body.stack === "string" ? body.stack : undefined,
      path: typeof body.path === "string" ? body.path : undefined,
    });
  } catch {
    return new Response(null, { status: 400 });
  }
  return new Response(null, { status: 204 });
}
