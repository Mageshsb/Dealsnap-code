import { dealClick } from "@/lib/deal-click";
import { LIMITS, overLimit, tooMany } from "@/lib/rate-limit";

// The phone apps' "Get deal" (components/AppBridge.tsx): the same as /go/<slug>,
// but answers with where to go instead of going there, so the app can open
// it in the in-app browser or hand it to the store's own app.
export async function GET(_request: Request, { params }: { params: Promise<{ slug: string }> }) {
  if (await overLimit("go", LIMITS.go)) return tooMany({ error: "too many requests" });
  const { slug } = await params;
  const click = await dealClick(slug);
  if (!click) return Response.json({ error: "not found" }, { status: 404, headers: { "cache-control": "no-store" } });
  return Response.json(click, { headers: { "cache-control": "no-store" } });
}
