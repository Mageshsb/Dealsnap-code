import { clearDealVote, upsertDealVote } from "@/lib/db";
import { getDealBySlug } from "@/lib/mock-deals";
import { onDealHeartsChanged } from "@/lib/notifications";
import { extensionMember, readJson } from "@/lib/extension-api";

// The heart on a deal in the browser extension (the same as on the site).
export async function POST(request: Request) {
  const { user, error } = await extensionMember(request);
  if (error) return error;
  const body = await readJson(request);
  const slug = String(body.slug ?? "");
  const deal = getDealBySlug(slug);
  if (!deal || deal.postedByUserId === user.id) return Response.json({ error: "Not found" }, { status: 404 });
  if (body.on) upsertDealVote(user.id, slug, "love");
  else clearDealVote(user.id, slug);
  onDealHeartsChanged(slug);
  return Response.json({ hearts: getDealBySlug(slug)?.hearts ?? deal.hearts });
}
