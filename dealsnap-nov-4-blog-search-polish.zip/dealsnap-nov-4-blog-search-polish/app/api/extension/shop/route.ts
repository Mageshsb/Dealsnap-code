import { shopSummary } from "@/lib/extension-shop";
import { overLimit, tooMany } from "@/lib/rate-limit";

// The shop you're on, when you open the browser extension there: its live
// deals and codes on DealSnap, and whether this product has been posted.
// Each look reads every live deal, so it's limited per visitor (far above
// what opening the extension by hand ever reaches) and very long addresses
// are turned away.
export async function GET(request: Request) {
  if (await overLimit("extension-shop", 60)) return tooMany({ deals: [], codes: [] });
  const url = new URL(request.url).searchParams.get("url") ?? "";
  if (url.length > 2000) return Response.json({ deals: [], codes: [] });
  return Response.json(shopSummary(url), { headers: { "cache-control": "no-store" } });
}
