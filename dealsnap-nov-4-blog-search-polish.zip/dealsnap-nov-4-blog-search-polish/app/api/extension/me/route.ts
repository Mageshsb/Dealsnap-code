import { getCurrentUser } from "@/lib/auth";
import { countUnreadNotifications } from "@/lib/db";

// Whether you're signed in to DealSnap, for the browser extension's header.
export async function GET() {
  const user = await getCurrentUser();
  return Response.json(
    { user: user ? { username: user.username } : null, unread: user ? countUnreadNotifications(user.id) : 0 },
    { headers: { "Cache-Control": "no-store" } }
  );
}
