import { shopCounts } from "@/lib/extension-shop";

// Every shop with live deals and how many, for the count on the browser
// extension's icon. The extension downloads this now and then and matches
// the page you're on itself, so where you browse never leaves your device.
export async function GET() {
  return Response.json({ shops: shopCounts() }, { headers: { "Cache-Control": "public, max-age=600" } });
}
