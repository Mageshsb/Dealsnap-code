import { revalidatePath } from "next/cache";
import { setDealSaved } from "@/lib/db";
import { getDealBySlug } from "@/lib/mock-deals";
import { extensionMember, readJson } from "@/lib/extension-api";

// "Save for later" on a deal in the browser extension.
export async function POST(request: Request) {
  const { user, error } = await extensionMember(request);
  if (error) return error;
  const body = await readJson(request);
  const slug = String(body.slug ?? "");
  if (body.on && !getDealBySlug(slug)) return Response.json({ error: "Not found" }, { status: 404 });
  setDealSaved(user.id, slug, !!body.on);
  revalidatePath("/saved");
  return Response.json({ ok: true });
}
