import { getCurrentUser } from "@/lib/auth";
import { getNotifications } from "@/lib/db";

// Your newest unread notifications, which the browser extension shows as
// desktop notifications (only ones newer than `after`, the last it showed).
export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return Response.json({ items: [] }, { headers: { "Cache-Control": "no-store" } });
  const after = Number(new URL(request.url).searchParams.get("after") ?? 0) || 0;
  const items = getNotifications(user.id, { limit: 10 })
    .filter((n) => !n.readAt && n.id > after)
    .map((n) => ({ id: n.id, text: n.text }));
  return Response.json({ items }, { headers: { "Cache-Control": "no-store" } });
}
