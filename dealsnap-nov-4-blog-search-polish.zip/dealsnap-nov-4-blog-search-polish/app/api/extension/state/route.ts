import { getCurrentUser } from "@/lib/auth";
import { getSavedDealSlugs, getVotesByUser } from "@/lib/db";

// Which of these deals you've loved and saved, for the browser extension's
// heart and save buttons.
export async function GET(request: Request) {
  const user = await getCurrentUser();
  const slugs = (new URL(request.url).searchParams.get("slugs") ?? "").split(",").filter(Boolean).slice(0, 50);
  if (!user) return Response.json({ loved: [], saved: [] }, { headers: { "Cache-Control": "no-store" } });
  const votes = getVotesByUser(user.id);
  const saved = new Set(getSavedDealSlugs(user.id).map((s) => s.dealSlug));
  return Response.json(
    { loved: slugs.filter((s) => votes[s] === "love"), saved: slugs.filter((s) => saved.has(s)) },
    { headers: { "Cache-Control": "no-store" } }
  );
}
