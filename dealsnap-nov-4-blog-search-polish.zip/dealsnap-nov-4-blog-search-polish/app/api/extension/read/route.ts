import { getRecentFailedLogins, recordFailedLogin } from "@/lib/db";
import { getKnownStores, getLearnedCategoryIndex } from "@/lib/mock-deals";
import { readPageHtml } from "@/lib/scrape-deal";
import { isPublicUrl } from "@/lib/public-fetch";
import { finishRead, keepExtensionRead } from "@/lib/deal-read";
import { clientIp } from "@/lib/client-ip";

// The DealSnap browser extension's "Post this deal": it sends the product
// page the shopper is looking at (read in their own browser, so it works on
// stores that turn our reader away), and gets back a ticket for the post
// form, /submit?read=<ticket>.
//
// Only ever read as text by the same parser as any other page, never run or
// stored as it came. Its photo is fetched and cleaned like any other.

const MAX_BYTES = 3_000_000;
const PER_HOUR_FROM_ONE_PLACE = 60;

export async function POST(request: Request) {
  if (Number(request.headers.get("content-length") ?? 0) > MAX_BYTES) {
    return Response.json({ error: "That page is too big to read." }, { status: 413 });
  }
  const ip = await clientIp();
  const key = `extension-read:${ip}`;
  if (getRecentFailedLogins(key, 60 * 60 * 1000).count >= PER_HOUR_FROM_ONE_PLACE) {
    return Response.json({ error: "Lots of pages have been read from here recently. Please try again later." }, { status: 429 });
  }
  recordFailedLogin(key);

  const body = (await request.json().catch(() => null)) as { url?: unknown; html?: unknown } | null;
  const rawUrl = typeof body?.url === "string" ? body.url : "";
  const html = typeof body?.html === "string" ? body.html.slice(0, MAX_BYTES) : "";
  let url: URL;
  try {
    url = new URL(rawUrl);
  } catch {
    return Response.json({ error: "That isn't a store's page." }, { status: 400 });
  }
  if (!isPublicUrl(url) || !html) return Response.json({ error: "That isn't a store's page." }, { status: 400 });

  const result = await finishRead(readPageHtml(html, url, getKnownStores(), getLearnedCategoryIndex()), url.toString());
  return Response.json({ ticket: keepExtensionRead({ ...result, via: "extension" }) });
}
