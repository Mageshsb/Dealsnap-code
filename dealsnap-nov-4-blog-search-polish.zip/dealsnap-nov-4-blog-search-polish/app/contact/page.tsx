import ContactFormBlock from "@/components/ContactFormBlock";
import SitePageView from "@/components/SitePageView";
import { getLegal, operatorLine } from "@/lib/legal";
import { getSitePage, pageMetadata } from "@/lib/site-pages";
import Icon from "@/components/Icon";

const DESIGNED = {
  title: "Contact us",
  description: "Get in touch with the DealSnap team: questions, feedback, problems with a deal, partnerships or your data.",
  alternates: { canonical: "/contact" },
};

// The built-in design below, unless the page has been given its own HTML (Admin → Pages).
export function generateMetadata() {
  return getSitePage("contact")?.format === "html" ? pageMetadata("contact") : DESIGNED;
}

// Fresh bot check per visit, and the form is filled in for signed-in members.
export const dynamic = "force-dynamic";

const card = "rounded-xl border border-zinc-200 bg-white p-5 dark:border-zinc-800 dark:bg-zinc-900";
const cardTitle = "flex items-center gap-2 text-sm font-semibold text-zinc-900 dark:text-zinc-100";

// The form on the left; on the right (below it on phones) the things worth
// knowing before writing, how to stay safe, and the plain email addresses.
// The "About an order?" note sits above the form on phones, as it saves the
// most wasted messages.
export default async function ContactPage({ searchParams }: { searchParams: Promise<{ topic?: string }> }) {
  const { topic } = await searchParams;
  const page = getSitePage("contact");
  if (page?.format === "html") return <SitePageView page={page} topic={topic} />;
  const legal = getLegal();
  const domain = legal.email.support.split("@")[1];
  const inboxes = [
    { label: "Help and feedback", email: legal.email.support },
    { label: "Privacy and your data", email: legal.email.privacy },
    { label: "Stores and partnerships", email: legal.email.partners },
  ];
  const company = legal.operator || legal.companyNumber || legal.registeredAddress;

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-6 px-4 py-6">
      <header className="flex max-w-2xl flex-col gap-1">
        <h1 className="text-xl font-bold sm:text-2xl">Contact us</h1>
        <p className="text-sm text-zinc-500">
          Questions, ideas, or something not quite right? We’re a small team and we read every message.
        </p>
      </header>

      <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-[minmax(0,1fr)_20rem] lg:grid-rows-[auto_1fr] lg:gap-x-8">
        <div className="flex gap-3 rounded-xl border border-orange-200 bg-orange-50 p-4 text-sm leading-relaxed text-zinc-700 lg:col-start-2 lg:row-start-1 dark:border-orange-900/60 dark:bg-orange-950/20 dark:text-zinc-300">
          <Icon name="shopping-bag" className="mt-0.5 size-5 shrink-0 text-orange-700 dark:text-orange-400" />
          <p>
            <strong className="font-semibold text-zinc-900 dark:text-zinc-100">About an order?</strong> We don’t sell anything ourselves, so
            for orders, deliveries or refunds, please contact the store you bought from.
          </p>
        </div>

        <div className="lg:col-start-1 lg:row-span-2 lg:row-start-1">
          <ContactFormBlock topic={topic} />
        </div>

        <aside className="flex flex-col gap-4 lg:col-start-2 lg:row-start-2">
          <section aria-labelledby="contact-safe" className={card}>
            <h2 id="contact-safe" className={cardTitle}>
              <Icon name="shield-check" className="size-4 text-orange-700 dark:text-orange-400" />
              Staying safe
            </h2>
            <ul className="mt-2 flex flex-col gap-1.5 text-sm leading-relaxed text-zinc-600 dark:text-zinc-400">
              <li>We’ll never ask for your password, two-step codes or bank details.</li>
              <li>
                Our emails only ever come from <span className="font-medium text-zinc-800 dark:text-zinc-200">@{domain}</span>. If you get
                one that doesn’t, please tell us.
              </li>
            </ul>
          </section>

          <section aria-labelledby="contact-by-email" className={card}>
            <h2 id="contact-by-email" className={cardTitle}>
              <Icon name="send" className="size-4 text-orange-700 dark:text-orange-400" />
              Prefer email?
            </h2>
            <ul className="mt-2 flex flex-col gap-2.5 text-sm">
              {inboxes.map((i) => (
                <li key={i.email} className="flex flex-col">
                  <span className="text-xs text-zinc-500">{i.label}</span>
                  <a
                    href={`mailto:${i.email}`}
                    className="break-all font-medium text-zinc-800 underline-offset-2 hover:text-orange-600 hover:underline dark:text-zinc-200 dark:hover:text-orange-400"
                  >
                    {i.email}
                  </a>
                </li>
              ))}
            </ul>
          </section>

          {company && (
            <section aria-labelledby="contact-company" className="px-1 text-xs leading-relaxed text-zinc-500">
              <h2 id="contact-company" className="font-semibold text-zinc-600 dark:text-zinc-400">
                Company details
              </h2>
              <p>DealSnap is run by {operatorLine()}.</p>
              {legal.icoNumber && <p>ICO registration {legal.icoNumber}.</p>}
            </section>
          )}
        </aside>
      </div>
    </main>
  );
}
