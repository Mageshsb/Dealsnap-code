import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Icon from "@/components/Icon";
import DealCard from "@/components/DealCard";
import { AdRow, AdStrip } from "@/components/AdCreative";
import { AdProgress, AdStatePill } from "@/components/admin/AdBits";
import { getAdTotalsAllTime } from "@/lib/db";
import { campaignForReport, reportExpires, reportFor } from "@/lib/ad-report";
import { getDealBySlug } from "@/lib/mock-deals";
import { overLimit } from "@/lib/rate-limit";
import { ukDay } from "@/lib/events";
import { campaignState, clickRate, creativeImageUrl, pounds, slotName } from "@/lib/ads";

// An advertiser's live report, opened from the private link staff send them
// (Admin → Ads → a campaign → Report link). One campaign, read-only, with no
// sign-in: the link itself is the key (lib/ad-report.ts). Never indexed or
// cached, and the link isn't passed on to other sites.
export const metadata: Metadata = { title: "Campaign report", robots: { index: false, follow: false } };

const long = (d: string) => new Date(`${d}T12:00:00Z`).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
const short = (d: string) => new Date(`${d}T12:00:00Z`).toLocaleDateString("en-GB", { day: "numeric", month: "short", timeZone: "UTC" });
const nf = (n: number) => n.toLocaleString("en-GB");

export default async function AdReportPage({ params }: { params: Promise<{ id: string; token: string }> }) {
  if (await overLimit("ad-report", 60)) notFound();
  const { id, token } = await params;
  const c = campaignForReport(id, token);
  if (!c) notFound();

  const today = ukDay();
  const r = reportFor(c);
  const state = campaignState(c, { total: r.views, today: r.today }, today);
  const expires = reportExpires(c);
  // Oldest first for the chart, the last 60 days with any numbers.
  const days = [...r.days].reverse().slice(-60);
  const peak = Math.max(1, ...days.map((d) => d.views));
  const deal = c.kind === "deal" && c.dealSlug ? getDealBySlug(c.dealSlug) : undefined;
  const creative = {
    id: c.id,
    advertiser: c.shownName,
    headline: c.headline,
    body: c.body,
    ctaLabel: c.ctaLabel,
    imageUrl: c.imageVersion ? creativeImageUrl(c.id, "image", c.imageVersion) : undefined,
    logoUrl: c.logoVersion ? creativeImageUrl(c.id, "logo", c.logoVersion) : undefined,
    internal: false,
  };
  // How DealSnap's ads do overall, for context, once there are enough views for it to mean something.
  const site = getAdTotalsAllTime();
  const average = site.views >= 10_000 ? clickRate(site.views, site.clicks) : undefined;
  const tiles: [string, string, string?][] = [
    ["Views", nf(r.views)],
    ["Clicks", nf(r.clicks)],
    ["Click rate", clickRate(r.views, r.clicks), average && `All DealSnap ads: ${average}`],
    ...(c.reportCosts && c.pricing !== "none" ? [[c.pricing === "flat" ? "Fee" : "Cost so far", pounds(r.cost)] as [string, string]] : []),
  ];
  const panel = "flex flex-col gap-3 rounded-2xl border border-zinc-200 bg-white p-4 sm:p-5 dark:border-zinc-800 dark:bg-zinc-900";
  const heading = "text-sm font-bold uppercase tracking-wide text-zinc-500";

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col gap-5 px-4 py-6">
      <header className="flex flex-col gap-1.5">
        <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-zinc-500">
          <Icon name="chart-column" className="size-4" />
          Campaign report · DealSnap
        </p>
        <h1 className="text-xl font-bold text-balance sm:text-2xl">{c.name}</h1>
        <div className="flex flex-wrap items-center gap-2 text-sm text-zinc-500">
          <AdStatePill state={state} />
          <span>
            {c.shownName} · {c.kind === "deal" ? "Sponsored deal" : "Ad"}
            {(c.startsOn || c.endsOn) && ` · ${c.startsOn ? long(c.startsOn) : "From the start"} to ${c.endsOn ? long(c.endsOn) : "no end date"}`}
          </span>
        </div>
      </header>

      <dl className={`grid grid-cols-2 gap-2 ${tiles.length === 4 ? "sm:grid-cols-4" : "sm:grid-cols-3"}`}>
        {tiles.map(([k, v, note]) => (
          <div key={k} className="rounded-xl border border-zinc-200 bg-white p-3 dark:border-zinc-800 dark:bg-zinc-900">
            <dt className="text-xs text-zinc-500">{k}</dt>
            <dd className="text-xl font-semibold tabular-nums">{v}</dd>
            {note && <dd className="text-xs text-zinc-500">{note}</dd>}
          </div>
        ))}
      </dl>

      {c.goal && (
        <section className={panel}>
          <h2 className={heading}>Delivery</h2>
          <AdProgress views={r.views} goal={c.goal} startsOn={c.startsOn} endsOn={c.endsOn} today={today} />
        </section>
      )}

      <section className={panel}>
        <h2 className={heading}>Views by day</h2>
        {days.length ? (
          <>
            <div className="flex h-36 items-end gap-px" role="img" aria-label={`Views by day, from ${short(days[0].day)} to ${short(days[days.length - 1].day)}`}>
              {days.map((d) => (
                <div
                  key={d.day}
                  title={`${short(d.day)}: ${nf(d.views)} views, ${nf(d.clicks)} clicks`}
                  className="min-w-0 flex-1 rounded-t bg-orange-400 dark:bg-orange-500"
                  style={{ height: `${Math.max(2, (d.views / peak) * 100)}%` }}
                />
              ))}
            </div>
            <div className="flex justify-between text-xs text-zinc-500">
              <span>{short(days[0].day)}</span>
              <span>{short(days[days.length - 1].day)}</span>
            </div>
            <div className="max-h-72 overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-white text-left text-xs text-zinc-500 dark:bg-zinc-900">
                  <tr>
                    <th className="py-1 font-medium">Day</th>
                    <th className="py-1 text-right font-medium">Views</th>
                    <th className="py-1 text-right font-medium">Clicks</th>
                    <th className="py-1 text-right font-medium">Rate</th>
                  </tr>
                </thead>
                <tbody>
                  {r.days.map((d) => (
                    <tr key={d.day} className="border-t border-zinc-100 dark:border-zinc-800">
                      <td className="py-1.5">{short(d.day)}</td>
                      <td className="py-1.5 text-right tabular-nums">{nf(d.views)}</td>
                      <td className="py-1.5 text-right tabular-nums">{nf(d.clicks)}</td>
                      <td className="py-1.5 text-right tabular-nums">{clickRate(d.views, d.clicks)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          <p className="text-sm text-zinc-500">Nothing counted yet. Numbers appear here as the campaign runs.</p>
        )}
      </section>

      {r.slots.length > 1 && (
        <section className={panel}>
          <h2 className={heading}>Where it showed</h2>
          <table className="w-full text-sm">
            <thead className="text-left text-xs text-zinc-500">
              <tr>
                <th className="py-1 font-medium">Ad space</th>
                <th className="py-1 text-right font-medium">Views</th>
                <th className="py-1 text-right font-medium">Clicks</th>
                <th className="py-1 text-right font-medium">Rate</th>
              </tr>
            </thead>
            <tbody>
              {r.slots.map((s) => (
                <tr key={s.slot} className="border-t border-zinc-100 dark:border-zinc-800">
                  <td className="py-1.5">{slotName(s.slot)}</td>
                  <td className="py-1.5 text-right tabular-nums">{nf(s.views)}</td>
                  <td className="py-1.5 text-right tabular-nums">{nf(s.clicks)}</td>
                  <td className="py-1.5 text-right tabular-nums">{clickRate(s.views, s.clicks)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}

      <section className={panel}>
        <h2 className={heading}>The {c.kind === "deal" ? "sponsored deal" : "ad"}</h2>
        {c.kind === "deal" ? (
          deal ? (
            <div className="max-w-xl">
              <DealCard deal={{ ...deal, featured: false, hero: false }} />
            </div>
          ) : (
            <p className="text-sm text-zinc-500">The deal is no longer on DealSnap.</p>
          )
        ) : (
          <div className="flex flex-col gap-3">
            <div className="max-w-xl">
              <AdRow ad={creative} />
            </div>
            <div className="max-w-xl">
              <AdStrip ad={creative} />
            </div>
          </div>
        )}
      </section>

      <section className="flex flex-col gap-2 text-sm text-zinc-500">
        <h2 className="font-semibold text-zinc-700 dark:text-zinc-300">How we count</h2>
        <ul className="flex list-disc flex-col gap-1 pl-5">
          <li>A view counts when at least half of the {c.kind === "deal" ? "deal" : "ad"} is on screen for a full second (the industry&apos;s “viewable” standard).</li>
          <li>Bots, link previews and DealSnap&apos;s own team are never counted, and repeated views by one person are capped each day.</li>
          <li>A click counts once per person every 10 minutes. {c.kind === "ad" && "Visits arrive tagged utm_source=dealsnap, so you can follow them in your own analytics."}</li>
          <li>No cookies and nothing personal are used: the {c.kind === "deal" ? "deal is" : "ad is"} shown for the page it&apos;s on, never for who&apos;s looking.</li>
        </ul>
        <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2">
          <a
            href={`/ad-report/${c.id}/${token}/csv`}
            className="inline-flex items-center gap-1.5 rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600"
          >
            <Icon name="download" className="size-4" />
            Download (CSV)
          </a>
          <span className="text-xs">
            Up to the minute when opened.{expires && ` This link works until ${long(expires)}.`}
          </span>
        </div>
      </section>
    </main>
  );
}
