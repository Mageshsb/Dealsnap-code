import { campaignForReport, csvResponse, reportCsv } from "@/lib/ad-report";
import { overLimit } from "@/lib/rate-limit";

// The advertiser's report as a spreadsheet (CSV), from their report link.
export async function GET(_request: Request, { params }: { params: Promise<{ id: string; token: string }> }) {
  if (await overLimit("ad-report", 60)) return new Response("Try again in a minute", { status: 429 });
  const { id, token } = await params;
  const campaign = campaignForReport(id, token);
  if (!campaign) return new Response("Not found", { status: 404 });
  return csvResponse(reportCsv(campaign, campaign.reportCosts));
}
