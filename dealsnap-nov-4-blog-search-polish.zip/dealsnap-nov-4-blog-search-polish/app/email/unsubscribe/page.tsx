import Link from "next/link";
import { redirect } from "next/navigation";
import { verifyUnsubscribe } from "@/lib/email";
import { turnOffAllEmails } from "@/lib/notifications";
import { findUserById } from "@/lib/db";
import Icon from "@/components/Icon";

export const metadata = { title: "Unsubscribe", robots: { index: false } };

async function unsubscribeAction(formData: FormData) {
  "use server";
  const userId = String(formData.get("u") ?? "");
  const token = String(formData.get("t") ?? "");
  if (findUserById(userId) && verifyUnsubscribe(userId, token)) turnOffAllEmails(userId);
  redirect(`/email/unsubscribe?u=${encodeURIComponent(userId)}&t=${encodeURIComponent(token)}&done=1`);
}

// The "Unsubscribe from all emails" link at the bottom of every email. It
// asks first rather than acting on the click, because some email scanners
// open every link in a message.
export default async function UnsubscribePage({
  searchParams,
}: {
  searchParams: Promise<{ u?: string; t?: string; done?: string }>;
}) {
  const { u = "", t = "", done } = await searchParams;
  const user = findUserById(u);
  const valid = !!user && !user.deletedAt && verifyUnsubscribe(u, t);

  return (
    <main className="mx-auto flex w-full max-w-md flex-1 flex-col items-center justify-center gap-4 px-4 py-16 text-center">
      <Icon name="mail" strokeWidth={1.5} className="size-12 text-zinc-300 dark:text-zinc-600" />
      {!valid ? (
        <>
          <h1 className="text-xl font-bold sm:text-2xl">This link doesn&apos;t work</h1>
          <p className="text-sm text-zinc-500">
            It may have been copied incompletely. You can turn emails off any time in{" "}
            <Link href="/settings?s=notifications" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
              Settings → Notification settings
            </Link>
            .
          </p>
          <Link
            href="/"
            className="inline-flex items-center gap-0.5 rounded-full border border-zinc-300 py-2 pl-3 pr-4 text-sm font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
          >
            <Icon name="chevron-left" className="size-4" />
            Today&apos;s deals
          </Link>
        </>
      ) : done ? (
        <>
          <h1 className="text-xl font-bold sm:text-2xl">You&apos;re unsubscribed</h1>
          <p className="text-sm text-zinc-500">
            We won&apos;t email you any more. Notifications still appear under the bell on the site, and you can switch emails back
            on in{" "}
            <Link href="/settings?s=notifications" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
              Settings → Notification settings
            </Link>
            .
          </p>
        </>
      ) : (
        <>
          <h1 className="text-xl font-bold sm:text-2xl">Stop all emails?</h1>
          <p className="text-sm text-zinc-500">
            {user.username}, this turns off every email from DealSnap: alerts, replies and updates about your deals. They&apos;ll
            still show under the bell on the site.
          </p>
          <form action={unsubscribeAction}>
            <input type="hidden" name="u" value={u} />
            <input type="hidden" name="t" value={t} />
            <button type="submit" className="rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600">
              Unsubscribe from all emails
            </button>
          </form>
          <Link href="/settings?s=notifications" className="text-sm text-zinc-500 hover:underline">
            Or choose which emails to keep
          </Link>
        </>
      )}
    </main>
  );
}
