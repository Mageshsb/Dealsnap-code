import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getSavedDealSlugs } from "@/lib/db";
import { getDealBySlug } from "@/lib/mock-deals";
import { canSeeDeal } from "@/lib/deal-visibility";
import { isExpired } from "@/lib/format";
import { clearUnavailableSavedAction } from "@/lib/member-actions";
import type { Deal } from "@/lib/types";
import AccountShell, { AccountPageHeader } from "@/components/AccountShell";
import DealCard from "@/components/DealCard";
import SortSelect from "@/components/SortSelect";
import Icon from "@/components/Icon";
import EmptyState from "@/components/EmptyState";

export const metadata = { title: "Saved deals" };

const SORT_OPTIONS = [
  { value: "saved", label: "Recently saved" },
  { value: "hearts", label: "Most hearts" },
  { value: "newest", label: "Newest deals" },
  { value: "ending", label: "Ending soon" },
];

// Deals that end soonest first; ones with no end date, then expired ones, last.
function endingRank(d: Deal): number {
  if (!d.expiresAt) return Number.MAX_SAFE_INTEGER - 1;
  if (isExpired(d.expiresAt)) return Number.MAX_SAFE_INTEGER;
  return new Date(d.expiresAt).getTime();
}

function sortDeals(deals: Deal[], sort: string): Deal[] {
  if (sort === "hearts") return [...deals].sort((a, b) => b.hearts - a.hearts);
  if (sort === "newest") return [...deals].sort((a, b) => new Date(b.postedAt).getTime() - new Date(a.postedAt).getTime());
  if (sort === "ending") return [...deals].sort((a, b) => endingRank(a) - endingRank(b));
  return deals; // already most recently saved first
}

export default async function SavedDealsPage({
  searchParams,
}: {
  searchParams: Promise<{ show?: string; sort?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/saved");
  const params = await searchParams;
  const showExpired = params.show === "all";
  const sort = SORT_OPTIONS.some((o) => o.value === params.sort) ? params.sort! : "saved";

  const saved = getSavedDealSlugs(user.id);
  const deals = saved.map((s) => getDealBySlug(s.dealSlug)).filter((d): d is Deal => !!d && canSeeDeal(d, user));
  const unavailable = saved.length - deals.length;
  const expiredCount = deals.filter((d) => isExpired(d.expiresAt)).length;
  const visible = sortDeals(showExpired ? deals : deals.filter((d) => !isExpired(d.expiresAt)), sort);
  const expiredQuery = new URLSearchParams([
    ...(showExpired ? [] : [["show", "all"]]),
    ...(sort !== "saved" ? [["sort", sort]] : []),
  ]).toString();

  return (
    <AccountShell user={user} active="/saved">
      <AccountPageHeader
        title="Saved deals"
        description="Only you can see these. Tap the bookmark on any deal to save it for later."
      />

      {(deals.length > 1 || expiredCount > 0) && (
        <div className="flex flex-wrap items-center justify-between gap-2">
          {expiredCount > 0 ? (
            <Link
              href={expiredQuery ? `/saved?${expiredQuery}` : "/saved"}
              aria-pressed={showExpired}
              scroll={false}
              className={`flex min-h-9 items-center gap-1.5 rounded-xl px-3 text-sm font-medium transition-colors ${
                showExpired
                  ? "bg-orange-500 text-white hover:bg-orange-600"
                  : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
              }`}
            >
              {showExpired && <Icon name="check" className="size-4" />}
              {showExpired ? "Showing expired" : `Show ${expiredCount} expired`}
            </Link>
          ) : (
            <span />
          )}
          {deals.length > 1 && (
            <SortSelect keep={{ show: showExpired ? "all" : undefined }} current={sort} options={SORT_OPTIONS} />
          )}
        </div>
      )}

      {unavailable > 0 && (
        <form action={clearUnavailableSavedAction} className="flex flex-wrap items-center gap-2 rounded-lg bg-zinc-100 px-3 py-2 text-sm text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">
          <span>
            {unavailable} saved deal{unavailable === 1 ? " is" : "s are"} no longer on the site.
          </span>
          <button type="submit" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
            Clear {unavailable === 1 ? "it" : "them"}
          </button>
        </form>
      )}

      {visible.length === 0 ? (
        <EmptyState icon="bookmark">
          <p>{deals.length === 0 ? "No saved deals yet." : "All your saved deals have expired."}</p>
          <p>Tap the bookmark on any deal to keep it handy. It doesn&apos;t change the deal&apos;s ranking.</p>
          <Link
            href="/"
            className="mt-2 flex min-h-9 items-center gap-1.5 rounded-full bg-orange-500 px-4 text-sm font-semibold text-white hover:bg-orange-600"
          >
            <Icon name="heart" className="size-4" />
            See this week&apos;s most loved
          </Link>
        </EmptyState>
      ) : (
        <div className="flex flex-col gap-3">
          {visible.map((d) => (
            <DealCard key={d.slug} deal={d} />
          ))}
        </div>
      )}
    </AccountShell>
  );
}
