"use client";

import Link from "next/link";
import { useEffect } from "react";
import Icon from "@/components/Icon";
import { reportClientError } from "@/components/ClientErrorReporter";

// Shown when a page breaks, instead of the browser's bare error: an apology,
// a way to try again and a way back in. The header and footer stay.
export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
    // A crash with a digest happened on the server and is already logged there;
    // one without it broke in this browser, which only we can report.
    if (!error.digest) reportClientError(error.message, error.stack);
  }, [error]);

  return (
    <main className="mx-auto flex w-full max-w-md flex-1 flex-col items-center justify-center gap-5 px-4 py-16 text-center">
      <Icon name="warning" strokeWidth={1.5} className="size-14 text-zinc-300 dark:text-zinc-600" />
      <div className="flex flex-col gap-2">
        <h1 className="text-xl font-bold sm:text-2xl">Sorry, something went wrong</h1>
        <p className="text-sm text-zinc-500">
          That page didn&apos;t load properly. It&apos;s not you, it&apos;s us. Please try again in a moment.
        </p>
      </div>

      <div className="flex flex-wrap justify-center gap-2">
        <button
          type="button"
          onClick={reset}
          className="rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600"
        >
          Try again
        </button>
        <Link
          href="/"
          className="inline-flex items-center gap-0.5 rounded-full border border-zinc-300 py-2 pl-3 pr-4 text-sm font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
        >
          <Icon name="chevron-left" className="size-4" />
          Today&apos;s deals
        </Link>
      </div>

      {error.digest && (
        <p className="text-xs text-zinc-500 dark:text-zinc-400">
          If it keeps happening,{" "}
          <Link href="/contact" className="underline hover:text-orange-500">
            let us know
          </Link>{" "}
          and mention code {error.digest}.
        </p>
      )}
    </main>
  );
}
