import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";

export const metadata = { title: "Your profile" };

// "Your profile" is simply your public profile page, so /profile just takes
// you there (keeping the tab, sort and page).
export default async function ProfilePage({
  searchParams,
}: {
  searchParams: Promise<{ tab?: string; sort?: string; page?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/profile");

  const { tab, sort, page } = await searchParams;
  const params = new URLSearchParams();
  if (tab) params.set("tab", tab);
  if (sort) params.set("sort", sort);
  if (page) params.set("page", page);
  redirect(`/u/${encodeURIComponent(user.username)}${params.size ? `?${params}` : ""}`);
}
