import { getCurrentUser } from "@/lib/auth";
import { getUserDataExport } from "@/lib/db";
import { exportCommunityData } from "@/lib/community-db";

// "Download my data" from profile settings: a JSON file of everything we hold.
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return new Response("Please log in first.", { status: 401 });
  const body = JSON.stringify({ ...getUserDataExport(user.id), community: exportCommunityData(user.id) }, null, 2);
  return new Response(body, {
    headers: {
      "content-type": "application/json; charset=utf-8",
      "content-disposition": `attachment; filename="dealsnap-${user.username}-data.json"`,
      "cache-control": "no-store",
    },
  });
}
