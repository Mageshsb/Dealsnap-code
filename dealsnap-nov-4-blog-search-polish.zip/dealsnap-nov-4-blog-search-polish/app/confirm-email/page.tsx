import Link from "next/link";
import Icon from "@/components/Icon";
import ResendConfirmButton from "@/components/ResendConfirmButton";
import { getCurrentUser } from "@/lib/auth";
import { confirmEmail } from "@/lib/db";

export const metadata = { title: "Confirm your email", robots: { index: false } };

// Where the link in the "Confirm your email" email lands.
export default async function ConfirmEmailPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token } = await searchParams;
  const confirmed = token ? confirmEmail(token) : undefined;
  const user = confirmed ? undefined : await getCurrentUser();
  const ok = !!confirmed || !!user?.emailVerified;

  return (
    <main className="mx-auto flex w-full max-w-sm flex-1 flex-col items-center gap-4 px-4 py-6 text-center">
      <Icon name={ok ? "circle-check" : "warning"} className={`size-10 ${ok ? "text-green-700 dark:text-green-400" : "text-amber-500"}`} />
      <h1 className="text-xl font-bold sm:text-2xl">{ok ? "Email confirmed" : "That link didn't work"}</h1>
      <p className="text-sm text-zinc-500 dark:text-zinc-400">
        {ok ? (
          "Thanks! You're all set to comment on deals, and your alerts will reach your inbox."
        ) : user ? (
          <>
            It may have expired, or a newer one was sent. <ResendConfirmButton />
          </>
        ) : (
          "It may have expired, or a newer one was sent. Log in and we'll send you a fresh one."
        )}
      </p>
      <Link
        href={ok || user ? "/" : "/login"}
        className="mt-2 rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600"
      >
        {ok || user ? "Back to deals" : "Log in"}
      </Link>
    </main>
  );
}
