import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getBlockedIds, getFollowingCount, getSuggestedPosters } from "@/lib/db";
import { getFollowingFeed, type FeedItem } from "@/lib/social";
import AccountShell, { AccountPageHeader } from "@/components/AccountShell";
import ActivityFeed from "@/components/ActivityFeed";
import EmptyState from "@/components/EmptyState";
import FollowButton from "@/components/FollowButton";
import UserAvatar from "@/components/UserAvatar";
import SortSelect from "@/components/SortSelect";

export const metadata = { title: "Following feed" };

const SHOW_OPTIONS = [
  { value: "all", label: "All" },
  { value: "posted", label: "Posted" },
  { value: "loved", label: "Loved" },
];

const SORT_OPTIONS = [
  { value: "latest", label: "Latest" },
  { value: "hearts", label: "Most hearts" },
  { value: "newest", label: "Newest deals" },
];

const FEED_SIZE = 50;

function sortFeed(items: FeedItem[], sort: string): FeedItem[] {
  if (sort === "hearts") return [...items].sort((a, b) => b.deal.hearts - a.deal.hearts);
  if (sort === "newest")
    return [...items].sort((a, b) => new Date(b.deal.postedAt).getTime() - new Date(a.deal.postedAt).getTime());
  return items; // already latest activity first
}

export default async function FollowingFeedPage({
  searchParams,
}: {
  searchParams: Promise<{ show?: string; sort?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/feed");
  const params = await searchParams;
  const show = SHOW_OPTIONS.some((o) => o.value === params.show) ? params.show! : "all";
  const sort = SORT_OPTIONS.some((o) => o.value === params.sort) ? params.sort! : "latest";

  const blocked = new Set(getBlockedIds(user.id));
  // Fetch more than we show, so "Posted" or "Loved" on its own still fills the page.
  const all = getFollowingFeed(user.id, FEED_SIZE * 4).filter(
    (i) => !blocked.has(i.userId) && !blocked.has(i.deal.postedByUserId ?? "")
  );
  const items = sortFeed(show === "all" ? all : all.filter((i) => i.type === show), sort).slice(0, FEED_SIZE);
  const following = getFollowingCount(user.id);
  const suggested = following < 3 ? getSuggestedPosters(user.id, 3) : [];

  return (
    <AccountShell user={user} active="/feed">
      <AccountPageHeader
        title="Following feed"
        description={
          <>
            Deals posted and loved by the people you follow.{" "}
            <Link href={`/u/${user.username}/following`} className="hover:underline">
              You follow {following} {following === 1 ? "person" : "people"}
            </Link>
          </>
        }
      />

      {all.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-2">
          <nav aria-label="Show" className="flex gap-1.5">
            {SHOW_OPTIONS.map((o) => {
              const query = new URLSearchParams([
                ...(o.value !== "all" ? [["show", o.value]] : []),
                ...(sort !== "latest" ? [["sort", sort]] : []),
              ]).toString();
              return (
                <Link
                  key={o.value}
                  href={query ? `/feed?${query}` : "/feed"}
                  aria-current={show === o.value ? "page" : undefined}
                  className={`flex min-h-9 items-center rounded-xl px-3 text-sm font-medium transition-colors ${
                    show === o.value
                      ? "bg-orange-500 text-white"
                      : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
                  }`}
                >
                  {o.label}
                </Link>
              );
            })}
          </nav>
          <SortSelect keep={{ show: show !== "all" ? show : undefined }} current={sort} options={SORT_OPTIONS} />
        </div>
      )}

      {items.length === 0 ? (
        <EmptyState icon="users">
          {all.length > 0 ? (
            <p>
              Nobody you follow has {show === "posted" ? "posted" : "loved"} a deal yet.{" "}
              <Link href="/feed" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
                Show everything
              </Link>
            </p>
          ) : (
            <>
              <p>Nothing here yet.</p>
              <p>Follow members to see the deals they post and love here.</p>
            </>
          )}
        </EmptyState>
      ) : (
        <div className="rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900 sm:p-6">
          <ActivityFeed items={items} />
        </div>
      )}

      {/* Someone new to following gets a place to start: the members whose
          deals got the most hearts lately. */}
      {following < 3 && suggested.length > 0 && (
        <section className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900 sm:p-6">
          <h2 className="font-bold">People to follow</h2>
          <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {suggested.map((p) => (
              <li key={p.id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                <Link href={`/u/${p.username}`} className="flex min-w-0 flex-1 items-center gap-3">
                  <UserAvatar username={p.username} avatarUrl={p.avatarUrl} size="h-10 w-10" />
                  <span className="flex min-w-0 flex-col">
                    <span className="truncate font-medium hover:text-orange-600">{p.username}</span>
                    <span className="text-xs text-zinc-500">
                      {p.deals} {p.deals === 1 ? "deal" : "deals"} · {p.hearts} hearts lately
                    </span>
                  </span>
                </Link>
                <FollowButton targetUserId={p.id} initialFollowing={false} initialMuted={false} />
              </li>
            ))}
          </ul>
        </section>
      )}
    </AccountShell>
  );
}
