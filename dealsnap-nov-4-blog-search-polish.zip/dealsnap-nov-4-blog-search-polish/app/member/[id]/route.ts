import { redirect, notFound } from "next/navigation";
import { findUserById } from "@/lib/db";

// A link to a member that keeps working after they change their username
// (notifications store this instead of /u/<name>).
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = findUserById(id);
  if (!user || user.deletedAt) notFound();
  redirect(`/u/${encodeURIComponent(user.username)}`);
}
