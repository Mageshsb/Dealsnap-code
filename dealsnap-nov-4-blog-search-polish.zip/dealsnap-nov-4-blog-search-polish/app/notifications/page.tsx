import Link from "next/link";
import { emailDeliveryReady } from "@/lib/email";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getNotifications, countUnreadNotifications, pruneNotifications } from "@/lib/db";
import { markAllNotificationsReadAction } from "@/lib/member-actions";
import { NOTIFICATION_FILTERS, NOTIFICATION_KINDS, type NotificationKind } from "@/lib/notification-kinds";
import { timeAgo } from "@/lib/format";
import AccountShell, { AccountPageHeader } from "@/components/AccountShell";
import Icon from "@/components/Icon";
import EmptyState from "@/components/EmptyState";

export const metadata = { title: "Notifications" };

const PAGE_SIZE = 30;

export default async function NotificationsPage({
  searchParams,
}: {
  searchParams: Promise<{ filter?: string; page?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/notifications");
  const { filter: filterParam, page: pageParam } = await searchParams;
  const filter = NOTIFICATION_FILTERS.find((f) => f.key === filterParam) ?? NOTIFICATION_FILTERS[0];
  const page = Math.max(1, Number(pageParam) || 1);

  pruneNotifications(user.id);
  // One extra tells us whether there's an older page.
  const rows = getNotifications(user.id, { kinds: filter.kinds, limit: PAGE_SIZE * page + 1 });
  const items = rows.slice(0, PAGE_SIZE * page);
  const hasMore = rows.length > items.length;
  const unread = countUnreadNotifications(user.id);
  const filterHref = (key: string) => (key === "all" ? "/notifications" : `/notifications?filter=${key}`);

  return (
    <AccountShell user={user} active="/notifications">
      <AccountPageHeader
        title="Notifications"
        description={
          <>
            {unread ? `${unread} new` : "You're all caught up"}
            {" · "}
            <Link href="/settings?s=notifications" className="hover:underline">
              Choose what you&apos;re told about
            </Link>
          </>
        }
        actions={
          unread > 0 && (
            <form action={markAllNotificationsReadAction}>
              <button
                type="submit"
                className="flex items-center gap-1.5 rounded-full border border-zinc-300 px-4 py-1.5 text-sm font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
              >
                <Icon name="check" className="size-4" />
                Mark all as read
              </button>
            </form>
          )
        }
      />

      {/* One line on every phone: if a large text size still overflows, it
          scrolls sideways rather than wrapping. */}
      <div className="no-scrollbar -mx-4 flex gap-1 overflow-x-auto px-4 sm:mx-0 sm:gap-1.5 sm:px-0">
        {NOTIFICATION_FILTERS.map((f) => (
          <Link
            key={f.key}
            href={filterHref(f.key)}
            aria-current={f.key === filter.key ? "true" : undefined}
            // The site's "which ones to show" tabs (see the Following feed).
            className={`flex min-h-9 shrink-0 items-center whitespace-nowrap rounded-xl px-2.5 text-sm font-medium transition-colors sm:px-3 ${
              f.key === filter.key
                ? "bg-orange-500 text-white"
                : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
            }`}
          >
            {f.label}
          </Link>
        ))}
      </div>

      {items.length === 0 ? (
        <EmptyState icon="bell">
          <p>Nothing here yet.</p>
          <p>
            Set up{" "}
            <Link href="/alerts" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
              alerts
            </Link>{" "}
            to hear about new deals, and you&apos;ll also be told about replies, followers and your own deals.
          </p>
        </EmptyState>
      ) : (
        <ul className="flex flex-col overflow-hidden rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
          {items.map((n) => {
            const kind = NOTIFICATION_KINDS[n.kind as NotificationKind];
            const isNew = !n.readAt;
            return (
              <li key={n.id} className="border-b border-zinc-100 last:border-b-0 dark:border-zinc-800">
                <a
                  href={`/notifications/open/${n.id}`}
                  className={`flex items-start gap-3 px-4 py-3 hover:bg-zinc-50 dark:hover:bg-zinc-800/60 ${
                    isNew ? "bg-orange-50/60 dark:bg-orange-950/20" : ""
                  }`}
                >
                  <span
                    aria-hidden
                    className={`flex size-9 shrink-0 items-center justify-center rounded-xl ${
                      isNew
                        ? "bg-orange-100 text-orange-700 dark:bg-orange-950/60 dark:text-orange-400"
                        : "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400"
                    }`}
                  >
                    <Icon name={kind?.icon ?? "bell"} className="size-4" />
                  </span>
                  <span className="flex min-w-0 flex-1 flex-col gap-0.5">
                    <span className={`text-sm leading-snug ${isNew ? "font-semibold text-zinc-900 dark:text-zinc-50" : "text-zinc-700 dark:text-zinc-300"}`}>
                      {n.text}
                    </span>
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">{timeAgo(n.createdAt)}</span>
                  </span>
                  {isNew && (
                    <span className="shrink-0 rounded-full bg-orange-500 px-2 py-0.5 text-[11px] font-bold uppercase text-white">New</span>
                  )}
                </a>
              </li>
            );
          })}
        </ul>
      )}

      {hasMore && (
        <Link
          href={`${filterHref(filter.key)}${filter.key === "all" ? "?" : "&"}page=${page + 1}`}
          scroll={false}
          className="self-center rounded-full border border-zinc-300 px-4 py-1.5 text-sm font-medium text-zinc-600 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
        >
          Show older
        </Link>
      )}

      {!emailDeliveryReady() && (
        <p className="text-center text-xs text-zinc-500 dark:text-zinc-400">Email notifications are coming soon. For now, everything arrives here.</p>
      )}
    </AccountShell>
  );
}
