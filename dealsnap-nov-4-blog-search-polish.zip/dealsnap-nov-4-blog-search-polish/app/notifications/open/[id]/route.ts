import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { openNotification } from "@/lib/db";
import { localPath } from "@/lib/local-path";

// Clicking a notification marks it read, then goes where it points.
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/notifications");
  const { id } = await params;
  const url = openNotification(user.id, Number(id));
  redirect(localPath(url, "/notifications"));
}
