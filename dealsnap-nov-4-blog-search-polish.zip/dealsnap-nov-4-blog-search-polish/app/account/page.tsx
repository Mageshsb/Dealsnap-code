import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import AccountShell, { AccountHub } from "@/components/AccountShell";
import {
  getBrandAlerts,
  getCategoryAlerts,
  getFollowingCount,
  getKeywordAlerts,
  getSavedDealSlugs,
  getStoreAlerts,
  getTagAlerts,
  getUserStats,
} from "@/lib/db";
import { getDealBySlug } from "@/lib/mock-deals";
import { isExpired } from "@/lib/format";
import ProfileContent from "@/components/ProfileContent";

export const metadata = { title: "My account" };

// My account. On phones it's the menu itself, each row saying what's in it;
// on desktop the menu is always down the side, so this opens on My profile.
export default async function AccountPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/account");

  const stats = getUserStats(user.id);
  // Saved deals still up, as the Saved deals page counts them.
  const saved = getSavedDealSlugs(user.id).filter((s) => {
    const deal = getDealBySlug(s.dealSlug);
    return deal && !isExpired(deal.expiresAt);
  }).length;
  const alerts =
    getTagAlerts(user.id).length +
    getCategoryAlerts(user.id).length +
    getStoreAlerts(user.id).length +
    getBrandAlerts(user.id).length +
    getKeywordAlerts(user.id).length;
  const summary = { dealCount: stats.dealCount, heartsReceived: stats.heartsReceived, saved, alerts, following: getFollowingCount(user.id) };

  return (
    <>
      <main className="mx-auto flex w-full max-w-xl flex-1 flex-col px-4 py-6 md:hidden">
        <AccountHub user={user} summary={summary} />
      </main>
      <div className="hidden md:flex md:flex-1 md:flex-col">
        <AccountShell user={user} active="/profile">
          <ProfileContent profileUser={user} viewer={user} params={{}} />
        </AccountShell>
      </div>
    </>
  );
}
