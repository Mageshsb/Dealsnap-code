import { brandPictureData, getSiteBrand } from "@/lib/site-brand";

// The site's uploaded logo (Admin → Settings → General): /site-logo/<version>.png,
// or /site-logo/dark-<version>.png for dark mode. The version changes with
// the logo, so browsers keep a copy for a year; an old address (a page
// someone kept open) gets today's logo, briefly cached.
export async function GET(_request: Request, { params }: { params: Promise<{ file: string }> }) {
  const match = (await params).file.match(/^(dark-)?([a-f0-9]{16})\.png$/);
  if (!match) return new Response("Not found", { status: 404 });
  const dark = !!match[1];
  const brand = getSiteBrand();
  const picture = dark ? brand.logoDark : brand.logo;
  const data = picture ? brandPictureData(dark ? "logoDark" : "logo") : undefined;
  if (!picture || !data) return new Response("Not found", { status: 404 });
  return new Response(new Uint8Array(data), {
    headers: {
      "Content-Type": "image/png",
      "Cache-Control": picture.v === match[2] ? "public, max-age=31536000, immutable" : "public, max-age=300",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
