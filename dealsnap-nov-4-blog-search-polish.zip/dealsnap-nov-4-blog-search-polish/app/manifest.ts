import type { MetadataRoute } from "next";
import { getSiteName } from "@/lib/site-url";
import { getSiteSettings } from "@/lib/site-settings";
import { manifestIcons } from "@/lib/site-brand";

// Read on each visit, not once at build: the name and icon can change in Admin.
export const dynamic = "force-dynamic";

// Lets people add DealSnap to their home screen like an app (and is what makes
// phone notifications possible on iPhone). The icons come from
// scripts/make-app-icons.mjs.
export default function manifest(): MetadataRoute.Manifest {
  const name = getSiteName();
  return {
    name,
    short_name: name,
    description: getSiteSettings().siteDescription,
    start_url: "/",
    scope: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#f97316",
    lang: "en-GB",
    categories: ["shopping", "lifestyle"],
    // "Share" on a phone: a shop's page shared to DealSnap opens the post
    // form with its link already read.
    share_target: {
      action: "/submit",
      method: "GET",
      params: { title: "title", text: "text", url: "url" },
    },
    // The icon uploaded in Admin → Settings → General, or the built-in one.
    icons: manifestIcons(),
  };
}
