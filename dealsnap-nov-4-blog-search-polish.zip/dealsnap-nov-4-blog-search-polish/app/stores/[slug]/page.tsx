import type { Metadata } from "next";
import { notFound, permanentRedirect } from "next/navigation";
import SidebarBoxes from "@/components/SidebarBoxes";
import BrowseExperience from "@/components/BrowseExperience";
import SwipeHeader from "@/components/SwipeHeader";
import SortAndFilters from "@/components/SortAndFilters";
import StoreLogo from "@/components/StoreLogo";
import AlertButton from "@/components/AlertButton";
import CategoryPills from "@/components/CategoryPills";
import CategorySwitcher from "@/components/CategorySwitcher";
import { getCurrentUser } from "@/lib/auth";
import { hasStoreAlert } from "@/lib/db";
import { parseView, parseLovedWindow, lovedDivider, DEFAULT_VIEW, DEFAULT_LOVED_WINDOW } from "@/lib/deal-views";
import { parseMinHearts, parseSlug, parseDealType, narrowDeals, narrowQuery, typeFacet, type Facet } from "@/lib/deal-filters";
import { slugify } from "@/lib/slug";
import { STORE_INDEX_DEALS, getCategoryFacet, getDealsForView, getStoreBySlug } from "@/lib/mock-deals";
import { PAGE_SIZE } from "@/lib/pagination";
import InfoToggle from "@/components/InfoToggle";
import InfoSheetButton from "@/components/InfoSheetButton";
import { StorePanel } from "@/components/InfoPanels";
import JsonLd from "@/components/JsonLd";
import { breadcrumbStructuredData } from "@/lib/structured-data";
import { Crumbs } from "@/components/TagPills";
import { getSiteUrl } from "@/lib/site-url";
import { getStoreDetails, storeQuestions, faqStructuredData } from "@/lib/store-details";
import { storeInfo } from "@/lib/topic-info";
import EmptyState from "@/components/EmptyState";
import { getListPromos } from "@/lib/promo-site";
import { getListAds } from "@/lib/ad-serving";
import { panelDiscussions } from "@/lib/community-panel";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const store = getStoreBySlug(slugify(decodeURIComponent((await params).slug)));
  if (!store) return {};
  // The page shows just the store's name; its title for search results and
  // shared links says what's here in full ("Currys deals and discount
  // codes"), as do the share previews (which otherwise fall back to the
  // site's own title). Its codes are in the list, as vouchers.
  const title = `${store.name} deals and discount codes`;
  const description = `The latest ${store.name} deals, offers and discount codes, rated by the DealSnap community.`;
  return {
    title,
    description,
    alternates: { canonical: `/stores/${store.slug}` },
    // Too few live deals: open to visitors, but not offered to search engines yet.
    robots: store.dealCount >= STORE_INDEX_DEALS ? undefined : { index: false, follow: true },
    openGraph: { title, description, url: `/stores/${store.slug}` },
    twitter: { card: "summary_large_image", title, description },
  };
}

export default async function StorePage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ view?: string; hearts?: string; when?: string; cat?: string; type?: string }>;
}) {
  const { slug: rawSlug } = await params;
  const sp = await searchParams;
  const view = parseView(sp.view);
  const when = parseLovedWindow(sp.when);
  const minHearts = parseMinHearts(sp.hearts);
  const cat = parseSlug(sp.cat);
  const type = parseDealType(sp.type);
  // Store addresses are the store's name, so tolerate "/stores/Currys" or
  // "/stores/jd%20sports" by sending visitors to the tidy address.
  const store = getStoreBySlug(slugify(decodeURIComponent(rawSlug)));

  if (!store) notFound();
  // Also catches variants: "/stores/amazon-uk" → "/stores/amazon".
  const slug = store.slug;
  if (slug !== rawSlug) {
    const qs = new URLSearchParams(sp as Record<string, string>).toString();
    permanentRedirect(`/stores/${slug}${qs ? `?${qs}` : ""}`);
  }

  const basePath = `/stores/${slug}`;
  const user = await getCurrentUser();
  const alertOn = user ? hasStoreAlert(user.id, store.key) : false;
  const facet: Facet = { param: "cat", options: getCategoryFacet({ store: slug }, minHearts, cat) };
  const filterQuery = narrowQuery("", cat, type);
  const listed = narrowDeals(getDealsForView(view, undefined, undefined, slug, minHearts, when), "", cat);
  const facets = [facet, typeFacet(listed)];
  const deals = narrowDeals(listed, "", "", type);
  const firstPage = deals.slice(0, PAGE_SIZE);
  const hasMore = deals.length > firstPage.length;

  // The ⓘ beside the name: the store's details, or a short automatic intro.
  const details = getStoreDetails(store.key);
  const questions = storeQuestions(store.name, details);

  // The ⓘ panel: under the title in the List view, a bottom sheet in Scroll.
  const infoLabel = `About ${store.name}`;
  const infoPanel = <StorePanel storeName={store.name} details={details} {...storeInfo(facet.options)} discussions={panelDiscussions("store", slug, store.name)} />;
  // Most loved/New and the Filters pill above the card in the Scroll view
  // (stepped down a size on short screens, so the card keeps its room).
  const controls = <SortAndFilters active={view} when={when} minHearts={minHearts} filterQuery={filterQuery} facets={facets} basePath={basePath} />;
  // The List view's own row under the title, which also comes back under
  // the category strip when scrolling up from halfway down the list.
  const listRow = <SortAndFilters active={view} when={when} basePath={basePath} minHearts={minHearts} filterQuery={filterQuery} facets={facets} inList />;
  return (
    <>
    <BrowseExperience
      promos={await getListPromos({ kind: "store", slug: slug })}
      ads={await getListAds({ kind: "store", slug: slug })}
      controls={listRow}
      resetKey={`${slug}|${view}|${when}|${minHearts}|${filterQuery}`}
      minHearts={minHearts || undefined}
      filterQuery={filterQuery || undefined}
      view={view === DEFAULT_VIEW ? undefined : view}
      when={view === "hottest" && when !== DEFAULT_LOVED_WINDOW ? when : undefined}
      divider={lovedDivider(view, when)}
      initialDeals={firstPage}
      initialHasMore={hasMore}
      isEmpty={deals.length === 0}
      store={slug}
      heading={
        <div key="heading">
          <InfoToggle label={infoLabel} panel={infoPanel}>
            <h1 className="flex min-w-0 items-center gap-2 text-xl font-bold sm:text-2xl">
              <StoreLogo name={store.name} logoUrl={store.logoUrl} className="h-6 w-6" />
              <span className="min-w-0 truncate sm:overflow-visible sm:whitespace-normal">{store.name}</span>
              {/* For search engines and screen readers: the heading in full. */}
              <span className="sr-only"> deals and discount codes</span>
            </h1>
            <AlertButton kind="store" target={store.key} name={store.name} nextPath={basePath} initialOn={alertOn} />
          </InfoToggle>
          {questions.length > 0 && <JsonLd data={faqStructuredData(questions)} />}
          <div className="mt-3">
            {listRow}
          </div>
        </div>
      }
      listFilterBar={
        // The same category row as the home page, so moving on from a store
        // works like everywhere else.
        <CategoryPills
          key="list-filter-bar"
          leading={<CategorySwitcher activeSlug="all" />}
          crumbs={<Crumbs path={[{ name: "Stores", href: "/stores" }]} current={{ name: store.name, href: basePath }} deselectHref="/" joined={false} />}
          divided
        />
      }
      swipeLabel={
        <SwipeHeader
          key="swipe-label"
          controls={controls}
          title={
            <>
              <StoreLogo name={store.name} logoUrl={store.logoUrl} className="h-6 w-6" />
              <span className="min-w-0 truncate sm:overflow-visible sm:whitespace-normal">{store.name}</span>
              <AlertButton kind="store" target={store.key} name={store.name} nextPath={basePath} initialOn={alertOn} className="px-2.5 py-1 text-xs font-semibold" />
              <InfoSheetButton label={infoLabel} panel={infoPanel} className="px-2.5 py-1 text-xs font-semibold" />
            </>
          }
        />
      }
      sidebar={<SidebarBoxes key="sidebar" facets={facets} />}
      emptyState={
        <EmptyState key="empty-state" icon="search">
          <p>No deals from this store yet.</p>
        </EmptyState>
      }
    />
    {/* The Stores › Currys trail above, for search results. */}
    <JsonLd data={breadcrumbStructuredData([{ name: "Home", href: "/" }, { name: "Stores", href: "/stores" }, { name: store.name, href: basePath }], await getSiteUrl())} />
    </>
  );
}
