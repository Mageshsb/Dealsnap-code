import type { Metadata } from "next";
import StoreDirectory, { type DirectoryStore } from "@/components/StoreDirectory";
import BrowseTop from "@/components/BrowseTop";
import { getStores } from "@/lib/mock-deals";
import { getStoreAliasRows, getStoreAlerts } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import YourFollows from "@/components/YourFollows";
import StoreLogo from "@/components/StoreLogo";
import { getStorePerksByKey } from "@/lib/store-details";
import { getCategoryGroups } from "@/lib/categories";
import { slugify } from "@/lib/slug";

export function generateMetadata(): Metadata {
  return {
    title: "Browse stores and discount codes",
    description: "Every store with deals on DealSnap, from Amazon to Argos, and how many working discount codes each has.",
    alternates: { canonical: "/stores" },
  };
}

export default async function StoresPage({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  // Drawn per visit (filters are in the address), so the store links are in
  // the page itself for search engines rather than filled in afterwards.
  await searchParams;
  const all = getStores();
  const aliases = new Map<string, string[]>();
  for (const a of getStoreAliasRows()) aliases.set(a.targetKey, [...(aliases.get(a.targetKey) ?? []), a.aliasName]);
  const perks = getStorePerksByKey();
  const stores: DirectoryStore[] = all.map((s) => ({
    name: s.name,
    slug: s.slug,
    logoUrl: s.logoUrl,
    dealCount: s.dealCount,
    codeCount: s.codeCount,
    categories: s.categories,
    aliases: aliases.get(s.key) ?? [],
    perks: perks.get(s.key),
  }));
  // Only categories some store has live deals in.
  const categories = getCategoryGroups()
    .map((g) => ({ slug: slugify(g.name), name: g.name, icon: g.icon }))
    .filter((c) => all.some((s) => s.categories[c.slug]));

  // The shops this person has the bell on for, those with something new first.
  // Capped, so a long list can't make the page heavy.
  const user = await getCurrentUser();
  const followedKeys = user ? new Set(getStoreAlerts(user.id)) : undefined;
  const yourShops = followedKeys
    ? all
        .filter((s) => followedKeys.has(s.key))
        .sort((a, b) => b.newCount - a.newCount || b.dealCount - a.dealCount || a.name.localeCompare(b.name))
        .slice(0, 12)
        .map((s) => ({
          key: s.slug,
          name: s.name,
          href: `/stores/${s.slug}`,
          leading: (
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-zinc-100 bg-white p-1 dark:border-zinc-800">
              <StoreLogo name={s.name} logoUrl={s.logoUrl} className="h-full w-full" />
            </span>
          ),
          liveCount: s.dealCount,
          newCount: s.newCount,
        }))
    : [];

  const liveCodes = all.reduce((n, s) => n + s.codeCount, 0);

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-5 px-4 py-6">
      <BrowseTop show="stores">
        {all.length.toLocaleString("en-GB")} stores · {liveCodes.toLocaleString("en-GB")} voucher codes
      </BrowseTop>
      <YourFollows id="your-shops" title="Your stores" manageHref="/alerts#shops" items={yourShops} />
      {/* Reads its filters from the address, so Back from a store keeps them. */}
      <StoreDirectory stores={stores} categories={categories} />
    </main>
  );
}
