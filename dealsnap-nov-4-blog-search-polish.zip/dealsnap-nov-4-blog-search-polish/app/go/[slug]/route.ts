import { dealClick } from "@/lib/deal-click";
import { LIMITS, overLimit } from "@/lib/rate-limit";

// Every "Get deal" button goes through here so admins can see which deals
// people actually click (Admin → Insights), then on to the retailer, through
// an affiliate link once those are set up (lib/affiliate.ts).
export async function GET(request: Request, { params }: { params: Promise<{ slug: string }> }) {
  if (await overLimit("go", LIMITS.go)) {
    return new Response("Too many requests. Please try again in a minute.", { status: 429, headers: { "retry-after": "60" } });
  }
  const { slug } = await params;
  const click = await dealClick(slug);
  if (!click) return Response.redirect(new URL("/", request.url), 302);
  return new Response(null, { status: 302, headers: { location: click.url, "cache-control": "no-store" } });
}
