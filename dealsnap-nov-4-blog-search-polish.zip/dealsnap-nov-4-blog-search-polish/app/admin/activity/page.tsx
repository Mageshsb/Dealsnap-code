import Link from "next/link";
import SelectField from "@/components/SelectField";
import { isStillAhead } from "@/lib/moderation";
import { requirePermission } from "@/lib/auth";
import { can } from "@/lib/permissions";
import TeamHeader from "@/components/admin/TeamHeader";
import { getStaffUsersAdmin, getAuditLog, getLastAuditByActor, getUserAdmin } from "@/lib/db";
import RangeSwitch from "@/components/staff/RangeSwitch";
import { TEAM_RANGES, rangeStart, teamRow } from "@/lib/staff-impact";
import {
  AUDIT_ACTIONS,
  AUDIT_GROUPS,
  flagThresholds,
  actionsInGroup,
  summariseActivity,
  type AuditAction,
  type AuditGroup,
} from "@/lib/audit";
import { formatDate, timeAgo } from "@/lib/format";
import Icon from "@/components/Icon";
import Pager from "@/components/admin/Pager";
import EmptyState from "@/components/EmptyState";
import { searchField } from "@/components/admin/formStyles";

export const metadata = { title: "Activity log" };

const PAGE_SIZE = 50;

const ROLE_STYLE: Record<string, string> = {
  admin: "bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400",
  moderator: "bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400",
  system: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400",
};

export default async function AdminActivityPage({
  searchParams,
}: {
  searchParams: Promise<{ staff?: string; group?: string; days?: string; page?: string; q?: string }>;
}) {
  const viewer = await requirePermission("activity.view");
  const { staff = "", group: groupParam = "all", days, page: pageParam, q: qParam = "" } = await searchParams;
  const q = qParam.trim().slice(0, 100);
  const group = groupParam in AUDIT_GROUPS || groupParam === "removals" ? (groupParam as AuditGroup | "removals") : "all";
  // The feed starts at the last 7 days: recent enough to spot a problem while it's small.
  const range = TEAM_RANGES.find((r) => r.key === days) ?? TEAM_RANGES[1];
  const since = rangeStart(range.days);
  const page = Math.max(1, parseInt(pageParam ?? "1", 10) || 1);

  const summary = summariseActivity();
  const staffUsers = getStaffUsersAdmin();
  // Who has done anything in the last week (busiest this hour first), and who hasn't.
  const week = (id: string) => summary.get(id)?.week ?? 0;
  const busy = staffUsers
    .filter((u) => week(u.id) > 0 || u.suspended)
    .sort((a, b) => (summary.get(b.id)?.hour ?? 0) - (summary.get(a.id)?.hour ?? 0) || (summary.get(b.id)?.day ?? 0) - (summary.get(a.id)?.day ?? 0) || week(b.id) - week(a.id));
  const quiet = staffUsers.filter((u) => week(u.id) === 0 && !u.suspended);
  // Anyone worth a look in this time block: an unusual hour, a burst or lots of repeat edits, or fixes that didn't stand.
  const worthALook = staffUsers
    .filter((u) => !u.deletedAt)
    .map((u) => ({ user: u, reasons: [...(summary.get(u.id)?.flagged ? ["an unusual number of actions in an hour"] : []), ...teamRow(u.id, since).flags] }))
    .filter((w) => w.reasons.length > 0);
  const thresholds = flagThresholds();
  const lastActive = getLastAuditByActor();

  const roleFilter = staff === "moderators" ? "moderator" : staff === "helpers" ? "helper" : undefined;
  const actorId = staff && !roleFilter ? staff : undefined;
  const removalActions = (Object.keys(AUDIT_ACTIONS) as AuditAction[]).filter((a) => AUDIT_ACTIONS[a].removal);
  const { entries, total } = getAuditLog({
    actorId,
    actorRole: roleFilter,
    actions: group === "all" ? undefined : group === "removals" ? removalActions : actionsInGroup(group),
    since,
    search: q,
    limit: PAGE_SIZE,
    offset: (page - 1) * PAGE_SIZE,
  });
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  // (Someone no longer on the team still has their history.)
  const selected = actorId ? (staffUsers.find((u) => u.id === actorId) ?? getUserAdmin(actorId)) : undefined;

  function href(next: { staff?: string; group?: string; days?: string; page?: number }) {
    const params = new URLSearchParams();
    const st = next.staff ?? staff;
    const gr = next.group ?? group;
    const dy = next.days ?? range.key;
    if (st) params.set("staff", st);
    if (gr && gr !== "all") params.set("group", gr);
    if (dy !== "7") params.set("days", dy);
    if (q) params.set("q", q);
    if (next.page && next.page > 1) params.set("page", String(next.page));
    const qs = params.toString();
    return qs ? `/admin/activity?${qs}` : "/admin/activity";
  }
  const hasFilters = Boolean(staff) || group !== "all" || range.key !== "7" || Boolean(q);

  return (
    <div className="flex flex-col gap-4">
      <TeamHeader
        current="activity"
        rules={can(viewer.role, "settings.manage")}
        description="A permanent record of what helpers, moderators and admins do, and what the site does by itself (the nightly Awin sync, product lists, backups). It can't be edited or deleted from the site."
        side={<RangeSwitch ranges={TEAM_RANGES} current={range.key} href={(k) => href({ days: k, page: 1 })} />}
      />

      <section
        className={`flex flex-col gap-2 rounded-xl border p-4 ${
          worthALook.length > 0
            ? "border-amber-300 bg-amber-50 dark:border-amber-900 dark:bg-amber-950/30"
            : "border-zinc-200 bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900/40"
        }`}
      >
        <h2 className="text-sm font-bold uppercase tracking-wide text-zinc-700 dark:text-zinc-200">
          <Icon name={worthALook.length > 0 ? "warning" : "circle-check"} className="mr-1.5" />
          {worthALook.length > 0 ? "Worth a look" : "Nothing unusual"}
          <span className="ml-2 text-xs font-normal normal-case text-zinc-500">{range.label === "All time" ? "all time" : `last ${range.label}`}</span>
        </h2>
        {worthALook.length > 0 && (
          <ul className="flex flex-col gap-1.5">
            {worthALook.map((w) => (
              <li key={w.user.id} className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1 text-sm">
                <span>
                  <b>{w.user.username}</b> <span className="text-zinc-500">({w.user.role})</span>: {w.reasons.join(" · ")}
                </span>
                <span className="flex gap-3 text-xs font-medium text-orange-700 dark:text-orange-400">
                  <Link href={`/admin/users/${w.user.id}?tab=staff&days=${range.key}`} className="hover:underline">
                    Their work
                  </Link>
                  <Link href={href({ staff: w.user.id, page: 1 })} className="hover:underline">
                    Their actions
                  </Link>
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-zinc-50 p-4 dark:border-zinc-800 dark:bg-zinc-900/40">
        <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1">
          <h2 className="whitespace-nowrap text-sm font-bold uppercase tracking-wide text-zinc-600 dark:text-zinc-300">
            <Icon name="users" className="mr-1.5" />
            Right now
          </h2>
          <p className="text-xs text-zinc-500">
            Everyone on the team, busiest first. Flagged if {thresholds.removals}+ removals or {thresholds.actions}+ actions in an hour.
          </p>
        </div>
        {staffUsers.length === 0 ? (
          <p className="text-sm text-zinc-500">
            No helpers, moderators or admins yet. Add them from the{" "}
            <Link href="/admin/users" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
              Users
            </Link>{" "}
            page.
          </p>
        ) : (
          <>
            <ul className="flex flex-col divide-y divide-zinc-200 dark:divide-zinc-800">
              {busy.map((m) => {
                const a = summary.get(m.id);
                return (
                  <li key={m.id} className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1 py-2.5 first:pt-0 last:pb-0">
                    <div className="min-w-0">
                      <p className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm">
                        <Link href={`/admin/users/${m.id}?tab=staff&days=${range.key}`} className="font-semibold hover:underline">
                          {m.username}
                        </Link>
                        <span className="text-xs text-zinc-500">{m.role}</span>
                        {m.suspended && (
                          <span className="rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700 dark:bg-red-950/40 dark:text-red-400">Suspended</span>
                        )}
                        {m.modProbationUntil && isStillAhead(m.modProbationUntil) && (
                          <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-700 dark:bg-amber-950/40 dark:text-amber-400">
                            Probation until {formatDate(m.modProbationUntil)}
                          </span>
                        )}
                        {a?.flagged && (
                          <span className="rounded-full bg-red-600 px-2 py-0.5 text-xs font-semibold text-white">
                            <Icon name="warning" className="mr-1" />
                            Unusual activity
                          </span>
                        )}
                      </p>
                      <p className="text-xs text-zinc-500">
                        {lastActive.get(m.id) ? `Last action ${timeAgo(lastActive.get(m.id)!)}` : "No actions yet"}
                        {m.lastLoginAt ? ` · last login ${timeAgo(m.lastLoginAt)}` : ""}
                      </p>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-zinc-500">
                      <span>
                        <b className="text-zinc-800 dark:text-zinc-200">{a?.hour ?? 0}</b> last hour
                      </span>
                      <span>
                        <b className="text-zinc-800 dark:text-zinc-200">{a?.day ?? 0}</b> today
                      </span>
                      <span>
                        <b className="text-zinc-800 dark:text-zinc-200">{a?.week ?? 0}</b> this week
                      </span>
                      <Link href={href({ staff: m.id, page: 1 })} className="text-xs font-medium text-orange-700 dark:text-orange-400 hover:underline">
                        Actions
                      </Link>
                    </div>
                  </li>
                );
              })}
            </ul>
            {quiet.length > 0 && (
              <p className="text-xs text-zinc-500">
                {busy.length > 0 ? "Quiet this week: " : "Nobody has done anything this week: "}
                {quiet.map((m, i) => (
                  <span key={m.id}>
                    {i > 0 && ", "}
                    <Link href={`/admin/users/${m.id}?tab=staff&days=${range.key}`} className="hover:underline">
                      {m.username}
                    </Link>
                  </span>
                ))}
              </p>
            )}
          </>
        )}
      </section>

      <form action="/admin/activity" className="grid grid-cols-2 items-center gap-2 sm:flex sm:flex-wrap">
        <input type="hidden" name="days" value={range.key} />
        <input
          type="search"
          name="q"
          defaultValue={q}
          maxLength={100}
          placeholder="Search: a deal, a member, a store…"
          aria-label="Search the activity"
          className={`col-span-2 min-w-[180px] sm:flex-1 ${searchField}`}
        />
        <SelectField
          look="admin"
          name="staff"
          label="Who"
          defaultValue={staff}
          options={[
            { value: "", label: "Everyone" },
            { value: "moderators", label: "All moderators" },
            { value: "helpers", label: "All helpers" },
            { value: "system", label: "Automatic jobs" },
            ...staffUsers.map((u) => ({ value: u.id, label: `${u.username} (${u.role})` })),
          ]}
          className="col-span-2"
        />
        <SelectField
          look="admin"
          name="group"
          label="Type of action"
          defaultValue={group}
          options={[
            { value: "all", label: "All types of action" },
            { value: "removals", label: "Removals and take-downs only" },
            ...(Object.keys(AUDIT_GROUPS) as AuditGroup[]).map((g) => ({ value: g, label: AUDIT_GROUPS[g] })),
          ]}
          className="col-span-2"
        />
        <button
          type="submit"
          className="col-span-2 min-h-[42px] rounded-lg bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600 sm:col-auto"
        >
          Apply
        </button>
      </form>

      <p className="-mt-2 text-sm text-zinc-500">
        {selected ? (
          <>
            Showing {selected.username}&apos;s actions.{" "}
            <Link href={`/admin/users/${selected.id}?tab=staff&days=${range.key}`} className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
              See their staff work →
            </Link>{" "}
          </>
        ) : (
          ""
        )}
        {total} action{total === 1 ? "" : "s"} recorded.
        {hasFilters && (
          <>
            {" "}
            <Link href="/admin/activity" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
              Clear all filters
            </Link>
          </>
        )}
      </p>

      <ul className="flex flex-col gap-2">
        {entries.map((e) => {
          const meta = AUDIT_ACTIONS[e.action as AuditAction];
          return (
            <li
              key={e.id}
              className="flex flex-col gap-1 rounded-xl border border-zinc-200 bg-white px-4 py-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4 dark:border-zinc-800 dark:bg-zinc-900"
            >
              <div className="min-w-0 text-sm">
                <p>
                  <Icon name={meta?.icon ?? "clipboard"} className="mr-1 text-zinc-500 dark:text-zinc-400" />
                  <Link href={href({ staff: e.actorId, page: 1 })} className="font-semibold hover:underline">
                    {e.actorUsername}
                  </Link>{" "}
                  <span className={`rounded-full px-1.5 py-0.5 text-[11px] font-medium ${ROLE_STYLE[e.actorRole] ?? "bg-zinc-100 text-zinc-600"}`}>
                    {e.actorRole}
                  </span>{" "}
                  <span className="text-zinc-600 dark:text-zinc-400">{meta?.text ?? e.action}</span>{" "}
                  {e.targetUrl ? (
                    <Link href={e.targetUrl} target={e.targetUrl.startsWith("/deals/") ? "_blank" : undefined} className="font-medium hover:underline">
                      {e.targetLabel}
                    </Link>
                  ) : (
                    <span className="font-medium">{e.targetLabel}</span>
                  )}
                </p>
                {e.detail && <p className="mt-0.5 break-words text-xs text-zinc-500">{e.detail}</p>}
              </div>
              <p className="shrink-0 text-xs text-zinc-500 dark:text-zinc-400" title={new Date(e.at).toLocaleString("en-GB")}>
                {timeAgo(e.at)}
              </p>
            </li>
          );
        })}
        {entries.length === 0 && (
          <li>
            <EmptyState icon="clipboard">
              <p>
                Nothing recorded {hasFilters ? "for these filters" : "yet"}. Actions are logged from now on.
              </p>
            </EmptyState>
          </li>
        )}
      </ul>

      <Pager page={page} totalPages={totalPages} href={(p) => href({ page: p })} prev="← Newer" next="Older →" />
    </div>
  );
}
