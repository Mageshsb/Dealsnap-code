import Link from "next/link";
import { msAgo } from "@/lib/moderation";
import { requirePermission } from "@/lib/auth";
import ShareTopFive from "@/components/admin/ShareTopFive";
import { getAllDeals, getStores } from "@/lib/mock-deals";
import { rankMostLoved } from "@/lib/deal-views";
import { isExpired } from "@/lib/format";
import { dealPriceTag, priceTagText } from "@/lib/deal-kinds";
import { getSiteName, getSiteUrl } from "@/lib/site-url";
import { getAlertDemand, getInsightSeries, getTopClickedSlugs, type InsightPoint, type InsightUnit } from "@/lib/db";
import { allTags, getCategoryGroups } from "@/lib/categories";
import { getBrandList } from "@/lib/brands";
import { slugify } from "@/lib/slug";
import AccountSection from "@/components/AccountSection";
import { getAdminDealsView } from "@/lib/mock-deals";
import { autofillByShop, FIELD_LABELS } from "@/lib/autofill-report";
import { earningRoute } from "@/lib/affiliate";
import { getAffiliateProgrammes } from "@/lib/db";
import { getSiteSettings } from "@/lib/site-settings";
import Icon, { HeartIcon, type IconName } from "@/components/Icon";

export const metadata = { title: "Insights" };

// "all" is everything since the site started.
const RANGES = [
  { key: "7", label: "7 days", days: 7 },
  { key: "30", label: "30 days", days: 30 },
  { key: "90", label: "90 days", days: 90 },
  { key: "all", label: "All time", days: null },
] as const;

const UNIT_WORDS: Record<InsightUnit, { per: string; last: string }> = {
  day: { per: "per day", last: "Today" },
  week: { per: "per week", last: "This week" },
  month: { per: "per month", last: "This month" },
};

function bucketLabel(start: string, unit: InsightUnit): string {
  const d = new Date(start);
  if (unit === "month") return d.toLocaleDateString("en-GB", { month: "short", year: "numeric" });
  const day = d.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
  return unit === "week" ? `Week of ${day}` : day;
}

function Chart({
  title,
  icon,
  series,
  unit,
  color,
}: {
  title: string;
  icon: IconName;
  series: InsightPoint[];
  unit: InsightUnit;
  color: string;
}) {
  const total = series.reduce((n, p) => n + p.count, 0);
  const max = Math.max(1, ...series.map((p) => p.count));
  const half = Math.floor(series.length / 2);
  const recent = series.slice(half).reduce((n, p) => n + p.count, 0);
  const earlier = series.slice(0, half).reduce((n, p) => n + p.count, 0);
  const trend = earlier === 0 ? (recent > 0 ? "up" : "flat") : recent > earlier * 1.1 ? "up" : recent < earlier * 0.9 ? "down" : "flat";

  return (
    <section className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900 sm:p-5">
      <div className="flex items-baseline justify-between gap-2">
        <h2 className="flex items-center gap-2 font-semibold">
          <Icon name={icon} className="size-5 text-orange-700 dark:text-orange-400" />
          {title}
        </h2>
        <p className="text-xs text-zinc-500">
          {trend !== "flat" && <Icon name={trend === "up" ? "trending-up" : "trending-down"} className="mr-1" />}
          {trend === "up" ? "rising" : trend === "down" ? "falling" : "steady"}
        </p>
      </div>
      <p className="text-2xl font-bold">{total.toLocaleString("en-GB")}</p>
      <div className="flex h-24 items-end gap-[2px]" role="img" aria-label={`${title} ${UNIT_WORDS[unit].per}`}>
        {series.map((p) => (
          <div
            key={p.start}
            title={`${bucketLabel(p.start, unit)}: ${p.count}`}
            className={`min-w-0 flex-1 rounded-t-sm ${color}`}
            style={{ height: `${Math.max(p.count === 0 ? 2 : 6, (p.count / max) * 100)}%`, opacity: p.count === 0 ? 0.25 : 1 }}
          />
        ))}
      </div>
      <div className="flex justify-between text-[11px] text-zinc-500 dark:text-zinc-400">
        <span>{bucketLabel(series[0].start, unit).replace("Week of ", "")}</span>
        <span>{UNIT_WORDS[unit].last}</span>
      </div>
    </section>
  );
}

export default async function AdminInsightsPage({ searchParams }: { searchParams: Promise<{ days?: string }> }) {
  await requirePermission("insights.view");
  const { days: daysParam } = await searchParams;
  const range = RANGES.find((r) => r.key === daysParam) ?? RANGES[1];
  const days = range.days;
  const series = getInsightSeries(days);
  const deals = getAdminDealsView();
  const bySlug = new Map(deals.map((d) => [d.slug, d]));

  const topClicked = getTopClickedSlugs(days, 10)
    .map((t) => ({ ...t, deal: bySlug.get(t.slug) }))
    .filter((t) => t.deal);
  const storeClicks = new Map<string, number>();
  for (const t of getTopClickedSlugs(days, 1000)) {
    const store = bySlug.get(t.slug)?.store;
    if (store) storeClicks.set(store, (storeClicks.get(store) ?? 0) + t.clicks);
  }
  const topStores = [...storeClicks.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
  // The stores people click most that don't have their own programme yet:
  // which ones to apply to next (their own usually pays more than the
  // catch-all network). Judged by each store's most-clicked deal's link.
  const settings = getSiteSettings();
  const programmes = getAffiliateProgrammes();
  const storeLinks = new Map<string, string>();
  for (const t of getTopClickedSlugs(days, 1000)) {
    const deal = bySlug.get(t.slug);
    if (deal?.url && !storeLinks.has(deal.store)) storeLinks.set(deal.store, deal.url);
  }
  const applyNext = [...storeClicks.entries()]
    .map(([store, clicks]) => ({ store, clicks, route: earningRoute(storeLinks.get(store) ?? "", settings, programmes) }))
    .filter((s) => s.route === "catch-all" || s.route === "none")
    .sort((a, b) => b.clicks - a.clicks)
    .slice(0, 8);
  const since = days ? msAgo(days * 24 * 60 * 60 * 1000) : 0;
  const autofill = autofillByShop(since).slice(0, 12);
  const demand = getAlertDemand();
  const storeNames = new Map(getStores().map((s) => [s.key, s.name]));
  const categoryNames = new Map(getCategoryGroups().map((c) => [slugify(c.name), c.name]));
  const tagNames = new Map(allTags().map((t) => [slugify(t.tag.name), t.tag.name] as const));
  const brandNames = new Map(getBrandList().map((b) => [b.slug, b.name]));
  const lovedNew = deals
    .filter((d) => new Date(d.postedAt).getTime() >= since && d.status !== "removed")
    .sort((a, b) => b.hearts - a.hearts)
    .slice(0, 8);

  // The Daily Top 5: this week's five most-loved live deals, written out to
  // paste into a WhatsApp Channel, Telegram, Facebook group or newsletter.
  const site = await getSiteUrl();
  const topFive = rankMostLoved(getAllDeals().filter((d) => !isExpired(d.expiresAt) && !d.endedByMembers)).slice(0, 5);
  const today = new Date().toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short", timeZone: "Europe/London" });
  const topFiveText = [
    `❤️ ${getSiteName()}'s top 5 deals today (${today})`,
    "",
    ...topFive.flatMap((d, i) => {
      const tag = dealPriceTag(d);
      return [`${i + 1}. ${d.title}: ${priceTagText(tag)}${tag.off ? ` (${tag.off}% off)` : ""} at ${d.store}`, `${site}/deals/${d.slug}`, ""];
    }),
    `More deals, rated by shoppers: ${site}`,
  ].join("\n");

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold sm:text-2xl">Insights</h1>
          <p className="text-sm text-zinc-500">How DealSnap is growing. Clicks count every &ldquo;Get deal&rdquo; press.</p>
        </div>
        <div className="flex gap-1 rounded-lg border border-zinc-300 p-0.5 dark:border-zinc-700">
          {RANGES.map((r) => (
            <Link
              key={r.key}
              href={`/admin/insights?days=${r.key}`}
              aria-current={r === range ? "true" : undefined}
              className={`whitespace-nowrap rounded-md px-2.5 py-1.5 text-sm font-medium sm:px-3 ${
                r === range
                  ? "bg-orange-100 text-orange-700 dark:bg-orange-950/50 dark:text-orange-400"
                  : "text-zinc-600 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-800"
              }`}
            >
              {r.label}
            </Link>
          ))}
        </div>
      </div>

      <details className="group rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
        <summary className="flex cursor-pointer list-none items-center gap-2 px-4 py-4 text-lg font-semibold sm:px-6 [&::-webkit-details-marker]:hidden">
          <Icon name="megaphone" className="size-5 text-orange-700 dark:text-orange-400" />
          <span className="flex-1">Daily Top 5 to share</span>
          <Icon name="chevron-down" className="size-5 text-zinc-500 dark:text-zinc-400 transition-transform group-open:rotate-180" />
        </summary>
        <div className="flex flex-col gap-2 border-t border-zinc-100 p-4 sm:p-6 dark:border-zinc-800">
          <p className="text-sm text-zinc-500">
            Ready to paste into a WhatsApp Channel, Telegram channel or Facebook group. Posting it every morning reminds
            people DealSnap exists and brings them back.
          </p>
          <ShareTopFive text={topFiveText} />
        </div>
      </details>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Chart title="New members" icon="users" series={series.signups} unit={series.unit} color="bg-sky-500" />
        <Chart title="Deals posted" icon="tag" series={series.deals} unit={series.unit} color="bg-orange-500" />
        <Chart title="Comments" icon="comment" series={series.comments} unit={series.unit} color="bg-violet-500" />
        <Chart title="Get deal clicks" icon="shopping-cart" series={series.clicks} unit={series.unit} color="bg-green-500" />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="min-w-0 lg:col-span-2">
        <AccountSection icon="trophy" title="Most-clicked deals">
          {topClicked.length === 0 ? (
            <p className="text-sm text-zinc-500">No clicks recorded yet. Counting started with this update.</p>
          ) : (
            <ol className="flex flex-col gap-1.5">
              {topClicked.map((t, i) => (
                <li key={t.slug} className="flex items-center justify-between gap-3 text-sm">
                  <Link href={`/deals/${t.slug}`} target="_blank" className="min-w-0 truncate hover:underline">
                    <span className="mr-1.5 text-zinc-500 dark:text-zinc-400">{i + 1}.</span>
                    {t.deal!.title}
                  </Link>
                  <span className="shrink-0 font-semibold tabular-nums">{t.clicks}</span>
                </li>
              ))}
            </ol>
          )}
        </AccountSection>
        </div>
        <AccountSection icon="store" title="Stores by clicks">
          {topStores.length === 0 ? (
            <p className="text-sm text-zinc-500">Nothing yet.</p>
          ) : (
            <ul className="flex flex-col gap-1.5">
              {topStores.map(([store, clicks]) => (
                <li key={store} className="flex justify-between gap-3 text-sm">
                  <span className="min-w-0 truncate">{store}</span>
                  <span className="shrink-0 font-semibold tabular-nums">{clicks}</span>
                </li>
              ))}
            </ul>
          )}
        </AccountSection>
      </div>

      <AccountSection
        id="apply-next"
        icon="pound"
        title="Stores to apply for next"
        description="The stores people click through to most that don't have their own affiliate programme here yet. Apply to these first, on Awin or their own network: a store's own programme usually pays more than the catch-all. Once approved, Earnings picks them up by itself."
      >
        {applyNext.length === 0 ? (
          <p className="text-sm text-zinc-500">Every store people clicked through to in this period already earns through its own programme.</p>
        ) : (
          <ul className="flex flex-col gap-1.5">
            {applyNext.map((s) => (
              <li key={s.store} className="flex items-center justify-between gap-3 text-sm">
                <span className="min-w-0 truncate">
                  {s.store}{" "}
                  <span className={`text-xs ${s.route === "none" ? "text-amber-700 dark:text-amber-400" : "text-zinc-500 dark:text-zinc-400"}`}>
                    · {s.route === "none" ? "not earning" : "catch-all only"}
                  </span>
                </span>
                <span className="shrink-0 font-semibold tabular-nums" title={`${s.clicks} clicks`}>
                  {s.clicks}
                </span>
              </li>
            ))}
          </ul>
        )}
      </AccountSection>

      <AccountSection
        icon="target"
        title="What members want"
        description="What members have set alerts for, most wanted first: deals worth finding, and stores whose affiliate programmes are worth joining first."
      >
        {!demand.keywords.length && !demand.stores.length && !demand.categories.length && !demand.tags.length && !demand.brands.length ? (
          <p className="text-sm text-zinc-500">No alerts yet.</p>
        ) : (
          <div className="grid grid-cols-1 gap-x-8 gap-y-5 sm:grid-cols-2">
            <DemandList title="Words" rows={demand.keywords.map((r) => ({ label: `“${r.value}”`, people: r.people }))} />
            <DemandList title="Stores" rows={demand.stores.map((r) => ({ label: storeNames.get(r.value) ?? r.value, people: r.people }))} />
            <DemandList title="Categories" rows={demand.categories.map((r) => ({ label: categoryNames.get(r.value) ?? r.value, people: r.people }))} />
            <DemandList title="Products" rows={demand.tags.map((r) => ({ label: tagNames.get(r.value) ?? r.value, people: r.people }))} />
            <DemandList title="Brands" rows={demand.brands.map((r) => ({ label: brandNames.get(r.value) ?? r.value, people: r.people }))} />
          </div>
        )}
      </AccountSection>

      <AccountSection
        icon="sparkles"
        title="Autofill by store"
        description="For deals posted from a link: how often the poster left everything autofill filled in, and what they had to fix or add. The stores at the top are the ones to improve next."
      >
        {autofill.length === 0 ? (
          <p className="text-sm text-zinc-500">No deals posted from a link in this period.</p>
        ) : (
          <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {autofill.map((shop) => (
              <li key={shop.host} className="flex flex-col gap-0.5 py-2 text-sm">
                <span className="flex justify-between gap-3">
                  <span className="min-w-0 truncate font-medium">{shop.host}</span>
                  <span className="shrink-0 tabular-nums text-zinc-500">
                    {shop.allKept} of {shop.posts} left as filled
                  </span>
                </span>
                {(shop.fixes.length > 0 || shop.linkOnly > 0 || shop.fromList > 0) && (
                  <span className="text-xs text-zinc-500">
                    {[
                      shop.fixes.length > 0 && `Fixed or added: ${shop.fixes.map((f) => `${FIELD_LABELS[f.field]} (${f.times})`).join(", ")}`,
                      shop.linkOnly > 0 && `Page couldn't be read ${shop.linkOnly}×`,
                      shop.fromList > 0 && `Filled from its product list ${shop.fromList}×`,
                    ]
                      .filter(Boolean)
                      .join(" · ")}
                  </span>
                )}
              </li>
            ))}
          </ul>
        )}
      </AccountSection>

      <AccountSection icon="heart" title={days ? "Most-loved deals posted in this period" : "Most-loved deals of all time"}>
        {lovedNew.length === 0 ? (
          <p className="text-sm text-zinc-500">No deals posted in this period.</p>
        ) : (
          <ul className="flex flex-col gap-1.5">
            {lovedNew.map((d) => (
              <li key={d.slug} className="flex items-center justify-between gap-3 text-sm">
                <Link href={`/deals/${d.slug}`} target="_blank" className="min-w-0 truncate hover:underline">
                  {d.title} <span className="text-zinc-500 dark:text-zinc-400">· {d.store}</span>
                </Link>
                <span className="shrink-0 tabular-nums"><HeartIcon className="mr-1" />{d.hearts}</span>
              </li>
            ))}
          </ul>
        )}
      </AccountSection>
    </div>
  );
}

// One "What members want" list: the most wanted first, with how many
// members asked for it.
function DemandList({ title, rows }: { title: string; rows: { label: string; people: number }[] }) {
  return (
    <div className="flex flex-col gap-2">
      <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">{title}</h3>
      {rows.length === 0 ? (
        <p className="text-sm text-zinc-500 dark:text-zinc-400">None yet</p>
      ) : (
        <ul className="flex flex-col gap-1.5">
          {rows.map((r) => (
            <li key={r.label} className="flex justify-between gap-3 text-sm">
              <span className="min-w-0 truncate">{r.label}</span>
              <span className="shrink-0 font-semibold tabular-nums" title={`${r.people} ${r.people === 1 ? "member" : "members"}`}>
                {r.people}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
