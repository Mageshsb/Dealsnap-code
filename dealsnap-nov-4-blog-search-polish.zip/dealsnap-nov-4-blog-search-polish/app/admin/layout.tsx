import Link from "next/link";
import { requireStaff } from "@/lib/auth";
import { can, ROLE_LABELS } from "@/lib/permissions";
import { logoutAction } from "@/lib/actions";
import { countOpenContactMessages, countReportedComments, getOpenProfileReports } from "@/lib/db";
import { getAdminTodo } from "@/lib/admin-todo";
import { countOpenErrors } from "@/lib/error-log";
import { launchMustsLeft } from "@/lib/launch-checks";
import { countHeldThreads, countModerationQueue } from "@/lib/community-db";
import { AdminSidebar, AdminTabs, type AdminNavGroup } from "@/components/admin/AdminNav";
import { type IconName } from "@/components/Icon";
import AdminSearch from "@/components/admin/AdminSearch";

// Every admin page's browser tab says which page and that it's the admin side ("Deals · Admin").
export const metadata = { title: { default: "Admin", template: "%s · Admin" } };

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await requireStaff();
  const watched = !can(user.role, "activity.view");
  const reportedComments = countReportedComments();
  // What's waiting for staff in each section (the only numbers in the menu).
  const { deals: dealsTodo, stores: storesTodo } = getAdminTodo();

  // Grouped by the job: looking after the community, what the site holds and
  // shows, what grows it and earns from it, then the team and settings.
  const sections: AdminNavGroup[] = [
    { items: [{ href: "/admin", label: "Dashboard", icon: "dashboard" }] },
    {
      label: "Moderate",
      items: [
        { href: "/admin/deals", label: "Deals", icon: "tag", todo: dealsTodo },
        { href: "/admin/comments", label: "Comments", icon: "comment", todo: reportedComments },
        ...(can(user.role, "forum.moderate")
          ? [{ href: "/admin/community", label: "Community", icon: "replies" as IconName, todo: countModerationQueue() + countHeldThreads(), also: ["/admin/community/spaces", "/admin/community/limits"] }]
          : []),
        { href: "/admin/users", label: "Members", icon: "users", todo: getOpenProfileReports().length },
        ...(can(user.role, "messages.handle")
          ? [{ href: "/admin/messages", label: "Messages", icon: "mail" as IconName, todo: countOpenContactMessages() }]
          : []),
        ...(can(user.role, "deals.fix") ? [{ href: "/admin/helper", label: "Helper desk", icon: "hand-helping" as IconName }] : []),
      ],
    },
    {
      label: "Site",
      items: [
        ...(can(user.role, "stores.manage") ? [{ href: "/admin/stores", label: "Stores", icon: "store" as IconName, todo: storesTodo }] : []),
        ...(can(user.role, "content.manage")
          ? [
              { href: "/admin/labels", label: "Tags and brands", icon: "tag" as IconName },
              {
                href: "/admin/content",
                label: "Site content",
                icon: "megaphone" as IconName,
                also: ["/admin/banners", "/admin/promos", "/admin/events"],
              },
            ]
          : []),
        ...(can(user.role, "pages.manage") ? [{ href: "/admin/pages", label: "Pages", icon: "file-text" as IconName }] : []),
        ...(can(user.role, "blog.manage") ? [{ href: "/admin/blog", label: "Blog", icon: "pen-line" as IconName }] : []),
        ...(can(user.role, "settings.manage") ? [{ href: "/admin/engine", label: "Deal engine", icon: "bot" as IconName }] : []),
        ...(can(user.role, "settings.manage") ? [{ href: "/admin/wording", label: "Wording", icon: "pen-line" as IconName }] : []),
      ],
    },
    {
      label: "Grow",
      items: [
        ...(can(user.role, "insights.view") ? [{ href: "/admin/insights", label: "Insights", icon: "chart-line" as IconName }] : []),
        ...(can(user.role, "settings.revenue") ? [{ href: "/admin/earnings", label: "Earnings", icon: "pound" as IconName }] : []),
        ...(can(user.role, "ads.manage") ? [{ href: "/admin/ads", label: "Ads", icon: "target" as IconName }] : []),
      ],
    },
    {
      label: "Run the site",
      items: [
        // People, the activity log and (for admins) the team's rules, as tabs.
        ...(can(user.role, "activity.view")
          ? [{ href: "/admin/team", label: "Team", icon: "handshake" as IconName, also: ["/admin/activity"] }]
          : []),
        ...(can(user.role, "settings.manage") ? [{ href: "/admin/settings", label: "Settings", icon: "settings" as IconName }] : []),
        ...(can(user.role, "settings.manage") ? [{ href: "/admin/errors", label: "Site health", icon: "shield-check" as IconName, todo: countOpenErrors() }] : []),
        ...(can(user.role, "settings.manage") ? [{ href: "/admin/launch", label: "Launch checklist", icon: "rocket" as IconName, todo: launchMustsLeft() }] : []),
        // Admins edit the guidelines in Team → Rules; everyone else reads them here.
        ...(can(user.role, "settings.manage") ? [] : [{ href: "/admin/guidelines", label: "Guidelines", icon: "book-open" as IconName }]),
      ],
    },
  ];
  const groups = sections.filter((g) => g.items.length > 0);

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-5 px-4 py-5">
      <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1">
        <p className="text-sm text-zinc-500">
          <span className="mr-2 text-xs font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">{ROLE_LABELS[user.role]}</span>
          {user.username}
          {watched && <span className="ml-2 text-xs text-zinc-500 dark:text-zinc-400">· your actions are logged for the admins to review</span>}
        </p>
        <div className="-my-1.5 flex items-center gap-4 text-sm [&>*]:min-h-9">
          <Link href="/" className="inline-flex items-center text-zinc-500 hover:underline">
            ← Back to site
          </Link>
          <form action={logoutAction} className="flex">
            <button type="submit" className="text-red-600 hover:underline">
              Log out
            </button>
          </form>
        </div>
      </div>

      <div className="flex flex-col gap-3 md:hidden">
        <AdminSearch />
        <AdminTabs groups={groups} />
      </div>

      <div className="flex flex-col gap-5 md:flex-row md:items-start md:gap-6 lg:gap-8">
        <aside className="hidden md:sticky md:top-20 md:flex md:w-48 md:shrink-0 md:flex-col md:gap-4 lg:w-52">
          <AdminSearch />
          <AdminSidebar groups={groups} />
        </aside>
        <main className="min-w-0 flex-1">{children}</main>
      </div>
    </div>
  );
}
