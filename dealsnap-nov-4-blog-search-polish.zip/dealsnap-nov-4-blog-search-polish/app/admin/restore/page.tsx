import Link from "next/link";
import { redirect } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import { inspectBackup, restorePointById } from "@/lib/backups";
import { restoreBackupAction } from "@/lib/restore-actions";
import Icon from "@/components/Icon";
import Notice from "@/components/admin/Notice";
import { field, hint, label, panel, panelTitle } from "@/components/admin/formStyles";

export const metadata = { title: "Restore from a backup" };

const DATA = "/admin/settings?tab=data";
const day = (iso: string) => new Date(iso).toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "Europe/London" });

// The "are you sure" page before the whole site is put back to a backup: what's
// in it, what will be lost, and a typed word to confirm.
export default async function RestorePage({ searchParams }: { searchParams: Promise<{ from?: string; error?: string }> }) {
  const admin = await requirePermission("data.restore");
  const { from = "", error } = await searchParams;
  const point = restorePointById(from);
  if (!point) redirect(`${DATA}&error=${encodeURIComponent("That backup isn't on the server any more.")}`);
  const check = inspectBackup(point.file, admin.id);

  return (
    <div className="flex max-w-2xl flex-col gap-5">
      <div>
        <Link href={DATA} className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline">
          ← Data &amp; backups
        </Link>
        <h1 className="mt-2 text-xl font-bold sm:text-2xl">Restore the site from a backup</h1>
        <p className="mt-1 text-sm text-zinc-500">{point.label}</p>
      </div>

      <Notice error={error} />

      {!check.ok ? (
        <Notice error={check.reason} />
      ) : (
        <>
          <section className={panel}>
            <h2 className={panelTitle}>What&apos;s in this backup</h2>
            <dl className="grid grid-cols-3 gap-3 text-center">
              {[
                ["Members", check.members],
                ["Deals", check.deals],
                ["Comments", check.comments],
              ].map(([name, n]) => (
                <div key={name} className="rounded-xl bg-zinc-50 px-2 py-3 dark:bg-zinc-950">
                  <dd className="text-xl font-bold tabular-nums">{Number(n).toLocaleString("en-GB")}</dd>
                  <dt className="text-xs text-zinc-500">{name}</dt>
                </div>
              ))}
            </dl>
            <p className="text-sm text-zinc-500">
              {check.newestDeal ? `The newest deal in it was posted on ${day(check.newestDeal)}. ` : ""}
              {(point.bytes / 1048576).toFixed(1)}MB.
            </p>
          </section>

          {!check.includesYou && (
            <p className="rounded-lg bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
              <Icon name="warning" className="mr-1.5" />
              Your own account isn&apos;t in this backup, so you&apos;ll be signed out when it&apos;s restored and need an account that is.
            </p>
          )}

          <section className={panel}>
            <h2 className={panelTitle}>What happens</h2>
            <ul className="flex list-disc flex-col gap-2 pl-5 text-sm text-zinc-700 marker:text-zinc-300 dark:text-zinc-300">
              <li>
                <strong>Everything is replaced</strong> with what this backup holds: members, deals, comments, settings, pages, ads and the rest. Anything added or
                changed since the backup was made is lost from the live site.
              </li>
              <li>
                A <strong>safety copy of the site as it is right now</strong> is saved first, and shows in the list of backups afterwards, so you can undo this.
              </li>
              <li>If anything goes wrong part-way, nothing is changed at all.</li>
              <li>
                Everyone who is signed in stays signed in, and the staff activity log is kept (this restore is added to it). Stores&apos; product lists aren&apos;t
                touched.
              </li>
              <li>It takes a few seconds, and the site stays up while it happens.</li>
            </ul>
          </section>

          <form action={restoreBackupAction} className={panel}>
            <input type="hidden" name="from" value={point.id} />
            <label className={label}>
              Type RESTORE to confirm
              <span className={hint}>This can&apos;t be done by accident: the word has to be typed.</span>
              <input name="confirm" required autoComplete="off" autoCapitalize="characters" spellCheck={false} placeholder="RESTORE" className={`${field} max-w-xs font-mono`} />
            </label>
            <div className="flex flex-wrap items-center gap-3">
              <button type="submit" className="rounded-full bg-red-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-red-700">
                Restore the site
              </button>
              <Link href={DATA} className="rounded-full border border-zinc-300 px-5 py-2.5 text-sm font-semibold hover:bg-zinc-50 dark:border-zinc-700 dark:hover:bg-zinc-800">
                Cancel
              </Link>
            </div>
          </form>
        </>
      )}
    </div>
  );
}
