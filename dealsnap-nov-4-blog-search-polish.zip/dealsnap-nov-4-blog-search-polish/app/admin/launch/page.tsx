import { requirePermission } from "@/lib/auth";
import { getLaunchChecks, type LaunchCheck } from "@/lib/launch-checks";
import Icon from "@/components/Icon";

export const metadata = { title: "Launch checklist" };

const LEVELS: { level: LaunchCheck["level"]; title: string; blurb: string }[] = [
  { level: "must", title: "Before you launch", blurb: "The site shouldn't go public until these are done." },
  { level: "should", title: "Soon after, or before if you can", blurb: "The site works without them, but it's safer, quicker to run or earns more with them." },
  { level: "nice", title: "Nice to have", blurb: "Small extras." },
];

// What still stands between this copy of the site and a real launch, worked out
// from the site itself (lib/launch-checks.ts). Done items turn green by themselves.
export default async function AdminLaunchPage() {
  await requirePermission("settings.manage");
  const checks = getLaunchChecks();
  const musts = checks.filter((c) => c.level === "must");
  const left = musts.filter((c) => !c.ok).length;

  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-xl font-bold sm:text-2xl">Launch checklist</h1>
        <p className="max-w-2xl text-sm text-zinc-500">
          Checked against the site as it is right now, so ticks appear by themselves once something&apos;s done.{" "}
          {left === 0 ? "Everything needed for launch is in place." : `${left} of ${musts.length} must-haves left.`}
        </p>
      </div>
      {LEVELS.map(({ level, title, blurb }) => {
        const items = checks.filter((c) => c.level === level);
        return (
          <section key={level} className="flex flex-col gap-2">
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wide text-zinc-500">{title}</h2>
              <p className="text-sm text-zinc-500">{blurb}</p>
            </div>
            <ul className="flex flex-col divide-y divide-zinc-100 rounded-xl border border-zinc-200 bg-white dark:divide-zinc-800 dark:border-zinc-800 dark:bg-zinc-900">
              {items.map((c) => (
                <li key={c.key} className="flex gap-3 px-4 py-3">
                  <Icon
                    name={c.ok ? "circle-check" : "warning"}
                    className={`mt-0.5 size-5 shrink-0 ${c.ok ? "text-emerald-600" : level === "must" ? "text-red-600" : "text-amber-600"}`}
                  />
                  <div className="min-w-0 [overflow-wrap:anywhere]">
                    <p className="text-sm font-semibold">{c.title}</p>
                    <p className="text-sm text-zinc-500">{c.detail}</p>
                    {!c.ok && <p className="mt-1 text-sm">{c.fix}</p>}
                  </div>
                </li>
              ))}
            </ul>
          </section>
        );
      })}
    </div>
  );
}
