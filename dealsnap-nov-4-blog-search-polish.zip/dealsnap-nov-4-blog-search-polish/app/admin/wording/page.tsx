import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import SectionTabs from "@/components/admin/SectionTabs";
import Notice from "@/components/admin/Notice";
import { card, hint, input, outlineButton, saveButton } from "../settings/ui";
import { EMAIL_KINDS, EMAIL_WORD_LIMITS, fillEmailWords, getEmailWords, savedEmailWords, type EmailKind } from "@/lib/email-wording";
import { ENDED_REMOVAL_REASON, MAX_REASONS, OTHER_REASON, editableReasons } from "@/lib/moderation";
import { BUILT_IN_SAME } from "@/lib/search";
import { getSiteSetting } from "@/lib/db";
import { parseSynonymLines, synonymLinesText } from "@/lib/search-synonyms";
import { ABOUT_FIELDS, aboutWordsRaw, savedAboutWords } from "@/lib/about-words";
import { getSiteName } from "@/lib/site-url";
import { emailDeliveryReady } from "@/lib/email";
import {
  resetAboutWordsAction,
  resetEmailWordingAction,
  resetReasonsAction,
  saveAboutWordsAction,
  saveEmailWordingAction,
  saveReasonsAction,
  saveSynonymsAction,
  sendTestEmailAction,
} from "@/lib/wording-actions";

export const metadata = { title: "Wording" };

const TABS = [
  { key: "emails", label: "Emails", href: "/admin/wording?tab=emails" },
  { key: "reasons", label: "Reasons", href: "/admin/wording?tab=reasons" },
  { key: "search", label: "Search words", href: "/admin/wording?tab=search" },
  { key: "about", label: "About page", href: "/admin/wording?tab=about" },
] as const;
type Tab = (typeof TABS)[number]["key"];

const textarea = `${input} resize-y`;

// Wording: the words the site says that used to need a developer to change.
export default async function AdminWordingPage({
  searchParams,
}: {
  searchParams: Promise<{ tab?: string; saved?: string; note?: string; error?: string }>;
}) {
  await requirePermission("settings.manage");
  const params = await searchParams;
  const tab: Tab = TABS.some((t) => t.key === params.tab) ? (params.tab as Tab) : "emails";
  const notice = params.saved ? params.note ?? "Saved." : params.note;

  return (
    <div className="flex max-w-2xl flex-col gap-6">
      <div>
        <h1 className="text-xl font-bold sm:text-2xl">Wording</h1>
        <p className="text-sm text-zinc-500">
          The words the site says: the emails members get, the reasons you give when you take something down, what search treats as the same word, and the
          About page. Changes show straight away, and every one has &quot;Use the standard&quot; to put it back.
        </p>
      </div>
      <SectionTabs label="Wording sections" tabs={TABS} current={tab} />
      <Notice notice={notice} error={params.error} />

      {tab === "emails" && <EmailsTab savedId={params.saved} />}
      {tab === "reasons" && <ReasonsTab />}
      {tab === "search" && <SearchTab />}
      {tab === "about" && <AboutTab />}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Emails
// ---------------------------------------------------------------------------

function EmailsTab({ savedId }: { savedId?: string }) {
  const ready = emailDeliveryReady();
  return (
    <>
      <p className="text-sm text-zinc-600 dark:text-zinc-400">
        These are the emails about someone&apos;s own account. Change what they say; the layout, the button&apos;s link and the safety rules aren&apos;t editable, so
        no change can break one. Use <code className="rounded bg-zinc-100 px-1 dark:bg-zinc-800">{"{name}"}</code> for the member&apos;s username and{" "}
        <code className="rounded bg-zinc-100 px-1 dark:bg-zinc-800">{"{site}"}</code> for the site&apos;s name. Others (alerts, daily email) are written in code.
      </p>
      {!ready && (
        <p className="rounded-lg bg-amber-50 px-4 py-2 text-sm text-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
          Email isn&apos;t set up yet, so a test email is saved in the server&apos;s email-outbox folder instead of being sent (Admin → Launch checklist).
        </p>
      )}
      {EMAIL_KINDS.map((kind) => (
        <EmailCard key={kind.id} kind={kind} justSaved={savedId === kind.id} />
      ))}
    </>
  );
}

function EmailCard({ kind, justSaved }: { kind: EmailKind; justSaved: boolean }) {
  const words = getEmailWords(kind.id);
  const changed = Object.keys(savedEmailWords(kind.id)).length > 0;
  const site = getSiteName();
  const vars = { name: "Alex", site, email: "new-address@example.com" };
  const limits = EMAIL_WORD_LIMITS;
  return (
    <div className={card} id={kind.id}>
      <div>
        <h2 className="font-semibold">
          {kind.label} {changed && <span className="ml-1 rounded-full bg-orange-100 px-2 py-0.5 align-middle text-xs font-semibold text-orange-800 dark:bg-orange-950/50 dark:text-orange-300">Changed</span>}
          {justSaved && <span className="ml-1 text-xs font-normal text-green-700 dark:text-green-400">Saved</span>}
        </h2>
        <p className={hint}>{kind.when}</p>
      </div>

      <form action={saveEmailWordingAction} className="flex flex-col gap-3">
        <input type="hidden" name="id" value={kind.id} />
        <label className="flex flex-col gap-1 text-sm font-medium">
          Subject
          <input name="subject" defaultValue={words.subject} maxLength={limits.subject} className={input} />
        </label>
        <label className="flex flex-col gap-1 text-sm font-medium">
          What it says
          <textarea name="intro" rows={4} defaultValue={words.intro} maxLength={limits.intro} className={textarea} />
        </label>
        <label className="flex flex-col gap-1 text-sm font-medium">
          Button
          <input name="button" defaultValue={words.button} maxLength={limits.button} className={`${input} sm:max-w-xs`} />
        </label>
        <label className="flex flex-col gap-1 text-sm font-medium">
          Small print underneath
          <textarea name="footer" rows={3} defaultValue={words.footer} maxLength={limits.footer} className={textarea} />
        </label>
        {kind.extra.includes("email") && (
          <p className={hint}>
            You can also use <code>{"{email}"}</code>, the new address.
          </p>
        )}
        <div className="flex flex-wrap gap-2">
          <button type="submit" className={saveButton}>
            Save
          </button>
        </div>
      </form>

      <div className="rounded-lg border border-dashed border-zinc-300 p-3 text-sm dark:border-zinc-700">
        <p className="text-xs font-semibold uppercase tracking-wide text-zinc-500">How it reads now, for a member called Alex</p>
        <p className="mt-1 font-medium">{fillEmailWords(words.subject, vars)}</p>
        <p className="mt-1 text-zinc-700 dark:text-zinc-300">{fillEmailWords(words.intro, vars)}</p>
        <p className="mt-2">
          <span className="inline-block rounded-full bg-orange-500 px-3 py-1 text-xs font-semibold text-white">{fillEmailWords(words.button, vars)}</span>
        </p>
        <p className="mt-2 text-xs text-zinc-500">{fillEmailWords(words.footer, vars)}</p>
      </div>

      <div className="flex flex-wrap gap-2">
        <form action={sendTestEmailAction}>
          <input type="hidden" name="id" value={kind.id} />
          <button type="submit" className={outlineButton}>
            Send me a test
          </button>
        </form>
        {changed && (
          <form action={resetEmailWordingAction}>
            <input type="hidden" name="id" value={kind.id} />
            <button type="submit" className={outlineButton}>
              Use the standard
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Reasons
// ---------------------------------------------------------------------------

function ReasonsTab() {
  return (
    <>
      <p className="text-sm text-zinc-600 dark:text-zinc-400">
        The person affected reads the reason you pick, so write them to be read by that person. What was decided before keeps the words it was decided with.
        Up to {MAX_REASONS - 2} of your own; &quot;{ENDED_REMOVAL_REASON}&quot; and &quot;{OTHER_REASON}&quot; are always offered at the end.
      </p>
      <ReasonsCard
        list="deal"
        title="Taking a deal down"
        where="Admin → Deals → Take down…"
        fixed={[ENDED_REMOVAL_REASON, OTHER_REASON]}
        saved={editableReasons("deal")}
      />
      <ReasonsCard
        list="suspend"
        title="Suspending a member"
        where="Admin → Members → Suspend…"
        fixed={[OTHER_REASON]}
        saved={editableReasons("suspend")}
      />
    </>
  );
}

function ReasonsCard({
  list,
  title,
  where,
  fixed,
  saved,
}: {
  list: "deal" | "suspend";
  title: string;
  where: string;
  fixed: string[];
  saved: string[];
}) {
  return (
    <div className={card}>
      <div>
        <h2 className="font-semibold">{title}</h2>
        <p className={hint}>Offered at {where}. The first one is ticked by default.</p>
      </div>
      <form action={saveReasonsAction} className="flex flex-col gap-3">
        <input type="hidden" name="list" value={list} />
        <label className="flex flex-col gap-1 text-sm font-medium">
          One reason per line
          <textarea name="reasons" rows={Math.max(6, saved.length + 1)} defaultValue={saved.join("\n")} className={textarea} />
        </label>
        <p className={hint}>
          Always added at the end: {fixed.map((f) => `“${f}”`).join(", then ")}.{" "}
          {list === "deal" && "Choosing “Expired or out of stock” marks the deal as ended instead of removing it."}
        </p>
        <div className="flex flex-wrap gap-2">
          <button type="submit" className={saveButton}>
            Save
          </button>
        </div>
      </form>
      <form action={resetReasonsAction}>
        <input type="hidden" name="list" value={list} />
        <button type="submit" className={outlineButton}>
          Use the standard list
        </button>
      </form>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Search words
// ---------------------------------------------------------------------------

function SearchTab() {
  const saved = synonymLinesText(parseSynonymLines(getSiteSetting("search_synonyms") ?? ""));
  return (
    <>
      <div className={card}>
        <div>
          <h2 className="font-semibold">Words that mean the same thing</h2>
          <p className="text-sm text-zinc-500">
            Someone searching one of the words also finds deals using the others, ranked a little below the exact word. Use it for what shoppers actually
            type: a nickname, a spelling, a brand people shorten.
          </p>
        </div>
        <form action={saveSynonymsAction} className="flex flex-col gap-3">
          <label className="flex flex-col gap-1 text-sm font-medium">
            One group per line, words separated by commas
            <textarea
              name="synonyms"
              rows={Math.max(6, saved.split("\n").length + 2)}
              defaultValue={saved}
              placeholder={"specs, glasses, spectacles\nmicrowave, microwaves, zapper"}
              className={textarea}
            />
          </label>
          <p className={hint}>
            Single words only (the search already treats &quot;air fryer&quot; and &quot;airfryer&quot; alike). Up to 8 words a line. Two lines sharing a word join into one group.
            Typos are fixed automatically, so don&apos;t add those.
          </p>
          <button type="submit" className={saveButton}>
            Save
          </button>
        </form>
      </div>
      <details className={card}>
        <summary className="cursor-pointer text-sm font-semibold">Already built in ({BUILT_IN_SAME.length} groups)</summary>
        <ul className="grid grid-cols-1 gap-x-6 gap-y-1 text-sm text-zinc-700 sm:grid-cols-2 dark:text-zinc-300">
          {BUILT_IN_SAME.map((g) => (
            <li key={g.join()}>{g.join(", ")}</li>
          ))}
        </ul>
      </details>
    </>
  );
}

// ---------------------------------------------------------------------------
// About page
// ---------------------------------------------------------------------------

function AboutTab() {
  const raw = aboutWordsRaw();
  const changed = Object.keys(savedAboutWords()).length;
  const groups = [...new Set(ABOUT_FIELDS.map((f) => f.group))];
  return (
    <>
      <p className="text-sm text-zinc-600 dark:text-zinc-400">
        The words on the <Link href="/about" className="font-medium text-orange-700 underline underline-offset-2 dark:text-orange-400">About page</Link> (its pictures and layout stay as designed).
        {" "}<code className="rounded bg-zinc-100 px-1 dark:bg-zinc-800">{"{site}"}</code> is the site&apos;s name. {changed > 0 && `${changed} line${changed === 1 ? "" : "s"} changed from the standard.`}
      </p>
      <form action={saveAboutWordsAction} className="flex flex-col gap-4">
        {groups.map((group) => (
          <div key={group} className={card}>
            <h2 className="font-semibold">{group}</h2>
            {ABOUT_FIELDS.filter((f) => f.group === group).map((f) => (
              <label key={f.key} className="flex flex-col gap-1 text-sm font-medium">
                {f.label}
                {f.kind === "line" ? (
                  <input name={f.key} defaultValue={raw[f.key]} maxLength={f.max} className={input} />
                ) : (
                  <textarea name={f.key} rows={f.max > 250 ? 4 : 2} defaultValue={raw[f.key]} maxLength={f.max} className={textarea} />
                )}
              </label>
            ))}
          </div>
        ))}
        <button type="submit" className={saveButton}>
          Save
        </button>
      </form>
      {changed > 0 && (
        <form action={resetAboutWordsAction}>
          <button type="submit" className={outlineButton}>
            Use the standard words
          </button>
        </form>
      )}
    </>
  );
}
