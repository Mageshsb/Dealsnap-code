import Link from "next/link";
import SectionTabs from "@/components/admin/SectionTabs";
import { requirePermission } from "@/lib/auth";
import { getCategoryGroups, type Tag } from "@/lib/categories";
import { moveLabelAction } from "@/lib/taxonomy-actions";
import { getBrandList } from "@/lib/brands";
import { getTagWords } from "@/lib/db";
import { BRAND_TILE_DAYS, BRAND_TILE_DEALS, getBrandCounts, getCategorySummary } from "@/lib/mock-deals";
import { fetchMissingBrandLogosAction } from "@/lib/label-actions";
import Icon from "@/components/Icon";
import Notice from "@/components/admin/Notice";
import BrandLogo from "@/components/BrandLogo";

export const metadata = { title: "Tags and brands" };

const save = "rounded-full bg-orange-500 px-4 py-1.5 text-sm font-semibold text-white hover:bg-orange-600";
// Admin → Tags and brands: the type list (category › tag › sub-tag) with the
// extra words autofill uses for each, and the brand list (other spellings,
// where each can be detected, hidden or not). Words that keep turning up
// without a tag, and labels that have gone quiet, come later, once the site
// has enough deals to say.
export default async function AdminLabelsPage({ searchParams }: { searchParams: Promise<{ tab?: string; notice?: string; error?: string }> }) {
  await requirePermission("content.manage");
  const { tab: rawTab, notice, error } = await searchParams;
  const tab = rawTab === "brands" ? "brands" : "types";

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0 max-w-2xl">
          <h1 className="text-xl font-bold sm:text-2xl">Tags and brands</h1>
          <p className="text-sm text-zinc-500">
            What a deal is (category › tag › sub-tag) and who makes it. Changes here affect autofill and the brand pages straight away.
          </p>
        </div>
        <Link href={tab === "types" ? "/admin/labels/category/new" : "/admin/labels/brand/new"} className="rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
          {tab === "types" ? "+ Add a category" : "+ Add a brand"}
        </Link>
      </div>
      <SectionTabs
        label="Tags and brands"
        tabs={[
          { key: "types", label: "Types", href: "/admin/labels?tab=types" },
          { key: "brands", label: "Brands", href: "/admin/labels?tab=brands" },
        ]}
        current={tab}
      />
      <Notice notice={notice} error={error} />
      {tab === "types" ? <Types /> : <Brands />}
    </div>
  );
}

function Types() {
  const words = getTagWords();
  const groups = getCategoryGroups();
  return (
    <div className="flex flex-col gap-4">
      <p className="text-sm text-zinc-500">
        Everything a deal can be: category › tag › sub-tag. Tap one to rename it, change its icon, move it or take it away. The arrows set
        the order on the site&apos;s menus.
      </p>
      {groups.map((group, gi) => {
        const counts = getCategorySummary(group.name).tags;
        return (
          <form key={group.id} action={moveLabelAction}>
            <section id={`category-${group.id}`} className="overflow-hidden rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
              <div className="flex items-center gap-2 border-b border-zinc-100 bg-zinc-50 py-1 pl-4 pr-2 dark:border-zinc-800 dark:bg-zinc-950/40">
                <h2 className="min-w-0 flex-1">
                  <Link href={`/admin/labels/category/${group.id}`} className="flex min-h-10 items-center gap-2 font-semibold hover:underline">
                    <Icon name={group.icon} className="size-4 shrink-0 text-zinc-500" />
                    <span className="truncate">{group.name}</span>
                  </Link>
                </h2>
                <Arrows kind="category" id={group.id!} name={group.name} first={gi === 0} last={gi === groups.length - 1} />
              </div>
              <ul className="divide-y divide-zinc-100 dark:divide-zinc-800">
                {group.tags.flatMap((tag, i) => [
                  <TagRow key={tag.id} tag={tag} count={counts[tag.name.toLowerCase()] ?? 0} words={words.get(tag.name)?.length ?? 0} first={i === 0} last={i === group.tags.length - 1} />,
                  ...(tag.subtags ?? []).map((sub, j) => (
                    <TagRow key={sub.id} tag={sub} parent={tag} count={counts[sub.name.toLowerCase()] ?? 0} words={words.get(sub.name)?.length ?? 0} first={j === 0} last={j === tag.subtags!.length - 1} />
                  )),
                ])}
              </ul>
              <Link
                href={`/admin/labels/tag/new?place=c:${group.id}`}
                className="flex min-h-11 items-center border-t border-zinc-100 px-4 text-sm font-semibold text-orange-700 hover:bg-orange-50 dark:border-zinc-800 dark:text-orange-400 dark:hover:bg-orange-950/30"
              >
                + Add a tag to {group.name}
              </Link>
            </section>
          </form>
        );
      })}
    </div>
  );
}

// Earlier / later, as submit buttons of the category's one form.
function Arrows({ kind, id, name, first, last }: { kind: "category" | "tag"; id: number; name: string; first: boolean; last: boolean }) {
  const button = "flex size-9 items-center justify-center rounded-lg text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900 disabled:pointer-events-none disabled:opacity-25 dark:hover:bg-zinc-800 dark:hover:text-zinc-100";
  return (
    <span className="flex shrink-0 items-center">
      <button name="move" value={`${kind}:${id}:up`} disabled={first} aria-label={`Move ${name} earlier`} className={button}>
        <Icon name="arrow-up" className="size-4" />
      </button>
      <button name="move" value={`${kind}:${id}:down`} disabled={last} aria-label={`Move ${name} later`} className={button}>
        <Icon name="arrow-down" className="size-4" />
      </button>
    </span>
  );
}

function TagRow({ tag, parent, count, words, first, last }: { tag: Tag; parent?: Tag; count: number; words: number; first: boolean; last: boolean }) {
  const maker = tag.maker ?? parent?.maker;
  return (
    <li id={`tag-${tag.id}`} className={`flex items-center gap-1 py-0.5 pr-2 ${parent ? "pl-10" : "pl-4"}`}>
      <Link href={`/admin/labels/tag/${tag.id}`} className="flex min-h-10 min-w-0 flex-1 items-center gap-2 text-sm hover:underline">
        <Icon name={tag.icon} className="size-4 shrink-0 text-zinc-500 dark:text-zinc-400" />
        <span className="truncate font-medium">{tag.name}</span>
        {maker && <span className="hidden shrink-0 text-xs text-zinc-500 sm:inline">made by {maker}</span>}
        <span className="ml-auto shrink-0 text-xs tabular-nums text-zinc-500">
          {count} live{words > 0 && ` · ${words} word${words === 1 ? "" : "s"}`}
        </span>
      </Link>
      <Arrows kind="tag" id={tag.id!} name={tag.name} first={first} last={last} />
    </li>
  );
}

function Brands() {
  const counts = getBrandCounts();
  const brands = getBrandList();
  const missingLogos = brands.filter((b) => !b.hidden && !b.logoUrl && b.website).length;
  return (
    <div className="flex flex-col gap-4">
      <p className="text-sm text-zinc-500">
        Quiet brands (under {BRAND_TILE_DEALS} deals in {BRAND_TILE_DAYS} days) keep their page and alerts but aren&apos;t shown to
        search engines. Limit a brand to some categories when its name is also an everyday word
        (Apple, Shark, Dove).
      </p>

      {missingLogos > 0 && (
        <form action={fetchMissingBrandLogosAction} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
          <p className="text-sm text-zinc-600 dark:text-zinc-400">
            <Icon name="image" className="mr-1.5" />
            {missingLogos} brand{missingLogos === 1 ? " has" : "s have"} no logo yet. Fetch them from the brands&apos; own websites in one go.
          </p>
          <button className={save}>Fetch missing logos</button>
        </form>
      )}

      <ul className="flex flex-col divide-y divide-zinc-100 overflow-hidden rounded-xl border border-zinc-200 bg-white dark:divide-zinc-800 dark:border-zinc-800 dark:bg-zinc-900">
        {brands.map((b) => {
          const c = counts.get(b.slug);
          const busy = (c?.recent ?? 0) >= BRAND_TILE_DEALS;
          return (
            <li key={b.slug}>
              <Link href={`/admin/labels/brand/${b.slug}`} className="flex min-h-12 items-center gap-2 px-4 py-1.5 text-sm hover:bg-zinc-50 dark:hover:bg-zinc-800/50">
                <BrandLogo name={b.name} logoUrl={b.logoUrl} className="h-6 w-6" />
                <span className={`min-w-0 truncate font-medium ${b.hidden ? "text-zinc-500 dark:text-zinc-400 line-through" : ""}`}>{b.name}</span>
                <span className="shrink-0 text-xs text-zinc-500">{b.hidden ? "hidden" : busy ? "active" : "quiet"}</span>
                <span className="ml-auto shrink-0 text-xs tabular-nums text-zinc-500">
                  {c?.live ?? 0} live<span className="hidden sm:inline"> · {c?.recent ?? 0} in {BRAND_TILE_DAYS} days</span>
                </span>
                <Icon name="chevron-right" className="size-4 shrink-0 text-zinc-500 dark:text-zinc-400" />
              </Link>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

