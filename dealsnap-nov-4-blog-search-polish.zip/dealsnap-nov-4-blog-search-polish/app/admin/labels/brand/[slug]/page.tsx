import Link from "next/link";
import { notFound } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import { getCategoryGroups } from "@/lib/categories";
import { getBrandList } from "@/lib/brands";
import { BRAND_TILE_DAYS, getBrandCounts } from "@/lib/mock-deals";
import { fetchBrandLogoAction, removeBrandAction, removeBrandLogoAction, saveBrandAction, uploadBrandLogoAction } from "@/lib/label-actions";
import Notice from "@/components/admin/Notice";
import BrandLogo from "@/components/BrandLogo";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import { panel, panelTitle } from "@/components/admin/formStyles";

export const metadata = { title: "Brand" };

const input =
  "w-full min-w-0 rounded-lg border border-zinc-300 bg-white px-3 py-2 text-base outline-none focus:border-orange-500 sm:text-sm dark:border-zinc-700 dark:bg-zinc-900";
const save = "rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600";

// Admin → Tags and brands → one brand: its other spellings, website, where it's
// detected, hidden or not, its logo, and taking it away. New ones start here
// too (/new).
export default async function AdminBrandPage({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ notice?: string; error?: string }> }) {
  await requirePermission("content.manage");
  const [{ slug }, { notice, error }] = await Promise.all([params, searchParams]);
  const adding = slug === "new";
  const brand = adding ? undefined : getBrandList().find((b) => b.slug === slug);
  if (!adding && !brand) notFound();
  const counts = brand ? getBrandCounts().get(brand.slug) : undefined;

  return (
    <div className="flex max-w-2xl flex-col gap-4">
      <Link href="/admin/labels?tab=brands" className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline">
        ← Tags and brands
      </Link>
      <div>
        <h1 className="flex items-center gap-2 text-xl font-bold sm:text-2xl">
          {brand && <BrandLogo name={brand.name} logoUrl={brand.logoUrl} className="h-8 w-8" />}
          <span className={brand?.hidden ? "text-zinc-500 dark:text-zinc-400 line-through" : ""}>{brand ? brand.name : "New brand"}</span>
          {brand?.hidden && <span className="text-sm font-normal text-zinc-500">hidden</span>}
        </h1>
        {brand && (
          <p className="text-sm text-zinc-500">
            {counts?.live ?? 0} live · {counts?.recent ?? 0} in {BRAND_TILE_DAYS} days
          </p>
        )}
      </div>
      <Notice notice={notice} error={error} />

      <section className={panel}>
        <BrandForm brand={brand} />
      </section>

      {brand && (
        <section className={panel}>
          <h2 className={panelTitle}>Logo</h2>
          <BrandLogoForms brand={brand} />
        </section>
      )}

      {brand && (
        <form action={removeBrandAction} className={panel}>
          <h2 className={panelTitle}>Remove this brand</h2>
          <input type="hidden" name="slug" value={brand.slug} />
          <p className="text-sm text-zinc-500">
            Added by mistake, or never wanted? Removing it deletes the brand and its followers&apos; alerts; its deals stay, with no brand. To switch it off and keep it, tick Hidden above.
          </p>
          <div>
            <ConfirmSubmitButton
              confirmText={`Remove ${brand.name}? Its page goes, people following it stop getting its alerts, and ${counts?.live ?? 0} live deal${counts?.live === 1 ? "" : "s"} will have no brand. This can't be undone.`}
              confirmLabel="Yes, remove it"
              className="rounded-full border border-red-300 px-5 py-2.5 text-sm font-semibold text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/40"
            >
              Remove brand
            </ConfirmSubmitButton>
          </div>
        </form>
      )}
    </div>
  );
}

function BrandForm({ brand }: { brand?: { slug: string; name: string; words: string[]; categories: string[]; hidden: boolean; website?: string } }) {
  const id = brand?.slug ?? "new";
  return (
    <form action={saveBrandAction} className="flex flex-col gap-3">
      {brand ? <input type="hidden" name="slug" value={brand.slug} /> : <input type="hidden" name="new" value="1" />}
      {!brand && (
        <div className="flex flex-col gap-1">
          <label htmlFor="brand-name" className="text-xs font-medium text-zinc-600 dark:text-zinc-400">
            Name, as the brand writes it (it can&apos;t be changed later)
          </label>
          <input id="brand-name" name="name" required maxLength={40} className={input} placeholder="e.g. Tefal" />
        </div>
      )}
      <div className="flex flex-col gap-1">
        <label htmlFor={`spellings-${id}`} className="text-xs font-medium text-zinc-600 dark:text-zinc-400">
          Other spellings and product names, separated by commas
        </label>
        <input id={`spellings-${id}`} name="words" defaultValue={brand?.words.join(", ")} className={input} placeholder="e.g. delonghi, de longhi" />
      </div>
      <div className="flex flex-col gap-1">
        <label htmlFor={`website-${id}`} className="text-xs font-medium text-zinc-600 dark:text-zinc-400">
          Website, where its logo is fetched from
        </label>
        <input id={`website-${id}`} name="website" defaultValue={brand?.website} className={input} placeholder="e.g. dyson.co.uk" />
      </div>
      <fieldset className="flex flex-col gap-1.5">
        <legend className="mb-1 text-xs font-medium text-zinc-600 dark:text-zinc-400">Only detect it in (none ticked = anywhere)</legend>
        <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
          {getCategoryGroups().map((g) => (
            <label key={g.name} className="flex items-center gap-2 text-sm">
              <input type="checkbox" name="categories" value={g.name} defaultChecked={brand?.categories.includes(g.name)} className="size-4 accent-orange-500" />
              {g.name}
            </label>
          ))}
        </div>
      </fieldset>
      <div className="flex flex-wrap items-center justify-between gap-3">
        {brand ? (
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="hidden" value="1" defaultChecked={brand.hidden} className="size-4 accent-orange-500" />
            Hidden (no page, can&apos;t be picked)
          </label>
        ) : (
          <span />
        )}
        <div className="flex items-center gap-3">
          {brand && !brand.hidden && (
            <Link href={`/brands/${brand.slug}`} className="text-xs font-medium text-orange-700 hover:underline dark:text-orange-400">
              Open its page ›
            </Link>
          )}
          <button className={save}>{brand ? "Save" : "Add brand"}</button>
        </div>
      </div>
    </form>
  );
}

// The logo: fetched from the website saved above, or uploaded. It sits under
// the main form (forms can't nest) and acts on its own.
function BrandLogoForms({ brand }: { brand: { slug: string; name: string; website?: string; logoUrl?: string } }) {
  return (
    <div className="flex flex-wrap items-start gap-4">
      <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-950">
        <BrandLogo name={brand.name} logoUrl={brand.logoUrl} className="h-11 w-11" />
      </div>
      <div className="flex min-w-[240px] flex-1 flex-col gap-2">
        <p className="text-xs text-zinc-500">
          Shown on {brand.name}&apos;s page and in the brand list, with a small badge so it isn&apos;t mistaken for the shop (PNG, JPG or
          WEBP, up to 1MB; square works best).
        </p>
        <form action={fetchBrandLogoAction} className="flex items-center gap-2">
          <input type="hidden" name="slug" value={brand.slug} />
          <button type="submit" disabled={!brand.website} className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-50">
            {brand.logoUrl ? "Fetch again" : "Fetch logo"}
          </button>
          {!brand.website && <span className="text-xs text-zinc-500">Save its website first.</span>}
        </form>
        <form action={uploadBrandLogoAction} className="flex flex-wrap items-center gap-2">
          <input type="hidden" name="slug" value={brand.slug} />
          <input
            type="file"
            name="logo"
            accept="image/png,image/jpeg,image/webp"
            aria-label={`Upload a logo for ${brand.name}`}
            className="min-w-0 flex-1 text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-zinc-100 file:px-3 file:py-2 file:text-sm file:font-medium hover:file:bg-zinc-200 dark:file:bg-zinc-800"
          />
          <button type="submit" className="rounded-lg border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">
            Upload
          </button>
        </form>
        {brand.logoUrl && (
          <form action={removeBrandLogoAction}>
            <input type="hidden" name="slug" value={brand.slug} />
            <ConfirmSubmitButton confirmText="Remove this logo? The brand goes back to the badge icon." className="text-sm font-medium text-red-600 hover:underline">
              Remove logo
            </ConfirmSubmitButton>
          </form>
        )}
      </div>
    </div>
  );
}
