import Link from "next/link";
import { notFound } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import { getTaxonomy } from "@/lib/categories";
import { countDealsByLabel } from "@/lib/mock-deals";
import { removeCategoryAction, saveCategoryAction } from "@/lib/taxonomy-actions";
import { slugify } from "@/lib/slug";
import { HUES } from "@/lib/category-theme";
import Icon from "@/components/Icon";
import Notice from "@/components/admin/Notice";
import SelectField from "@/components/SelectField";
import IconPicker from "@/components/admin/IconPicker";
import HuePicker from "@/components/admin/HuePicker";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import { field, hint, label, panel, panelTitle } from "@/components/admin/formStyles";

export const metadata = { title: "Category" };

const save = "rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600";

// Admin → Tags and brands → one category: its name, icon and colour, and
// (once it exists) taking it away. New ones start here too (/new).
export default async function AdminCategoryPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ notice?: string; error?: string }> }) {
  await requirePermission("content.manage");
  const [{ id: rawId }, { notice, error }] = await Promise.all([params, searchParams]);
  const adding = rawId === "new";
  const tax = getTaxonomy();
  const category = adding ? undefined : /^\d{1,9}$/.test(rawId) ? tax.groups.find((g) => g.id === Number(rawId)) : undefined;
  if (!adding && !category) notFound();

  const counts = countDealsByLabel();
  const deals = category ? (counts.categories.get(category.name.toLowerCase()) ?? 0) : 0;
  const others = tax.groups.filter((g) => g.id !== category?.id);
  // A new category takes the next colour along, so neighbours differ.
  const hue = category?.hue ?? HUES[tax.groups.length % HUES.length];

  return (
    <div className="flex max-w-2xl flex-col gap-4">
      <Link href="/admin/labels?tab=types" className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline">
        ← Tags and brands
      </Link>
      <div>
        <h1 className="flex items-center gap-2 text-xl font-bold sm:text-2xl">
          {category && <Icon name={category.icon} className="size-6 text-zinc-500" />}
          {category ? category.name : "New category"}
        </h1>
        {category && (
          <p className="text-sm text-zinc-500">
            {category.tags.length} tag{category.tags.length === 1 ? "" : "s"} · {deals} deal{deals === 1 ? "" : "s"} ·{" "}
            <Link href={`/categories/${slugify(category.name)}`} className="font-medium text-orange-700 hover:underline dark:text-orange-400">
              Open its page ›
            </Link>
          </p>
        )}
      </div>
      <Notice notice={notice} error={error} />

      <form action={saveCategoryAction} className={panel}>
        <input type="hidden" name="id" value={category?.id ?? "new"} />
        <label className={label}>
          Name
          <input name="name" required maxLength={40} defaultValue={category?.name} placeholder="e.g. Pets & Garden" className={field} />
          {category && (
            <span className={hint}>
              Renaming updates every deal, alert and brand limit that uses it. The old web address keeps working.
            </span>
          )}
        </label>
        <div className={label}>
          Icon
          <IconPicker name="icon" defaultValue={category?.icon ?? "tag"} />
        </div>
        <div className={label}>
          Colour
          <span className={hint}>Its badges, and the tile behind a deal that has no photo.</span>
          <HuePicker name="hue" defaultValue={hue} />
        </div>
        <div>
          <button className={save}>{category ? "Save" : "Add category"}</button>
        </div>
      </form>

      {category && (
        <section className={panel}>
          <h2 className={panelTitle}>Tags</h2>
          <p className="text-sm text-zinc-500">
            The tags in {category.name} are listed on the Types tab, where you can put them in order. New tags start there too.
          </p>
          <Link href={`/admin/labels/tag/new?place=c:${category.id}`} className="self-start text-sm font-semibold text-orange-700 hover:underline dark:text-orange-400">
            + Add a tag to {category.name}
          </Link>
        </section>
      )}

      {category && (
        <form action={removeCategoryAction} className={panel}>
          <h2 className={panelTitle}>Remove this category</h2>
          <input type="hidden" name="id" value={category.id} />
          {others.length === 0 ? (
            <p className="text-sm text-zinc-500">It&apos;s the only category, so it can&apos;t be removed.</p>
          ) : (
            <>
              <p className="text-sm text-zinc-500">
                {category.tags.length > 0 || deals > 0
                  ? `Its ${category.tags.length} tag${category.tags.length === 1 ? "" : "s"} and ${deals} deal${deals === 1 ? "" : "s"} move to the category you pick, and anyone following it follows that one instead. The old address goes there too.`
                  : "Nothing uses it, so it can just go."}
              </p>
              {(category.tags.length > 0 || deals > 0) && (
                <label className={label}>
                  Move them to
                  <SelectField look="admin" name="into" label="Move to" required placeholder="Choose a category" options={others.map((g) => ({ value: String(g.id), label: g.name, icon: g.icon }))} />
                </label>
              )}
              <div>
                <ConfirmSubmitButton
                  confirmText={`Remove ${category.name}? ${category.tags.length > 0 || deals > 0 ? "Its tags, deals and followers move to the category you picked. " : ""}This can't be undone.`}
                  confirmLabel="Yes, remove it"
                  className="rounded-full border border-red-300 px-5 py-2.5 text-sm font-semibold text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/40"
                >
                  Remove category
                </ConfirmSubmitButton>
              </div>
            </>
          )}
        </form>
      )}
    </div>
  );
}
