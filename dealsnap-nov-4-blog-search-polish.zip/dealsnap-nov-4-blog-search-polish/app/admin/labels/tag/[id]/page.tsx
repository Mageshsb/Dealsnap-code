import Link from "next/link";
import { notFound } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import { getTaxonomy } from "@/lib/categories";
import { getBrandList } from "@/lib/brands";
import { getTagWords } from "@/lib/db";
import { countDealsByLabel } from "@/lib/mock-deals";
import { saveTagWordsAction } from "@/lib/label-actions";
import { removeTagAction, saveTagAction } from "@/lib/taxonomy-actions";
import { slugify } from "@/lib/slug";
import Icon from "@/components/Icon";
import Notice from "@/components/admin/Notice";
import SelectField from "@/components/SelectField";
import IconPicker from "@/components/admin/IconPicker";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import { field, hint, label, panel, panelTitle } from "@/components/admin/formStyles";

export const metadata = { title: "Tag" };

const save = "rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600";

// Admin → Tags and brands → one tag or sub-tag: what it's called, its icon,
// where it sits, who makes it, the words autofill knows it by, its sub-tags,
// and taking it away. New ones start here too (/new).
export default async function AdminTagPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ notice?: string; error?: string; place?: string }>;
}) {
  await requirePermission("content.manage");
  const [{ id: rawId }, { notice, error, place: placeParam }] = await Promise.all([params, searchParams]);
  const adding = rawId === "new";
  const tax = getTaxonomy();
  const info = adding ? undefined : /^\d{1,9}$/.test(rawId) ? tax.getTagById(Number(rawId)) : undefined;
  if (!adding && !info) notFound();
  const tag = info?.tag;

  const counts = countDealsByLabel();
  const deals = tag ? (counts.tags.get(tag.name.toLowerCase()) ?? 0) : 0;
  const subtags = tag?.subtags ?? [];
  const words = tag ? (getTagWords().get(tag.name) ?? []) : [];

  // Where it can sit: straight in a category, or (for a tag without sub-tags of
  // its own) under another tag as a sub-tag.
  const canBeSub = subtags.length === 0;
  const placeOptions = tax.groups.flatMap((g) => [
    { value: `c:${g.id}`, label: `Tag in ${g.name}`, icon: g.icon },
    ...(canBeSub ? g.tags.filter((t) => t.id !== tag?.id).map((t) => ({ value: `t:${t.id}`, label: `Sub-tag of ${t.name} · ${g.name}`, icon: t.icon })) : []),
  ]);
  const asked = placeOptions.find((o) => o.value === placeParam)?.value;
  const place = info ? (info.parent ? `t:${info.parent.id}` : `c:${info.category.id}`) : (asked ?? placeOptions[0]?.value);

  const brands = getBrandList().filter((b) => !b.hidden);
  const makerOptions = [{ value: "", label: "No maker" }, ...brands.map((b) => ({ value: b.name, label: b.name }))];
  const into = tax
    .allTags()
    .filter((t) => t.tag.id !== tag?.id)
    .map((t) => ({
      value: String(t.tag.id),
      label: t.parent ? `${t.category.name} › ${t.parent.name} › ${t.tag.name}` : `${t.category.name} › ${t.tag.name}`,
      icon: t.tag.icon,
    }));

  return (
    <div className="flex max-w-2xl flex-col gap-4">
      <Link href="/admin/labels?tab=types" className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline">
        ← Tags and brands
      </Link>
      <div>
        <h1 className="flex items-center gap-2 text-xl font-bold sm:text-2xl">
          {tag && <Icon name={tag.icon} className="size-6 text-zinc-500" />}
          {tag ? tag.name : "New tag"}
        </h1>
        {info && (
          <p className="text-sm text-zinc-500">
            <Link href={`/admin/labels/category/${info.category.id}`} className="hover:underline">
              {info.category.name}
            </Link>
            {info.parent && (
              <>
                {" › "}
                <Link href={`/admin/labels/tag/${info.parent.id}`} className="hover:underline">
                  {info.parent.name}
                </Link>
              </>
            )}{" "}
            · {deals} deal{deals === 1 ? "" : "s"} ·{" "}
            <Link href={`/tags/${slugify(info.tag.name)}`} className="font-medium text-orange-700 hover:underline dark:text-orange-400">
              Open its page ›
            </Link>
          </p>
        )}
      </div>
      <Notice notice={notice} error={error} />

      <form action={saveTagAction} className={panel}>
        <input type="hidden" name="id" value={tag?.id ?? "new"} />
        <label className={label}>
          Name
          <input name="name" required maxLength={40} defaultValue={tag?.name} placeholder="e.g. Pet Food" className={field} />
          {tag && <span className={hint}>Renaming updates its deals and alerts. The old web address keeps working. Autofill keeps its built-in words.</span>}
        </label>
        <div className={label}>
          Icon
          <span className={hint}>Shown on tiles for deals with no photo, and in menus.</span>
          <IconPicker name="icon" defaultValue={tag?.icon ?? info?.category.icon ?? "tag"} />
        </div>
        <label className={label}>
          Where it sits
          <SelectField look="admin" name="place" label="Where it sits" required defaultValue={place} options={placeOptions} />
          {tag && <span className={hint}>Moving it takes its deals (and its sub-tags) with it.</span>}
        </label>
        <label className={label}>
          Made by
          <span className={hint}>
            Only for a tag where everything is one maker (PS5 → Sony). Deals filed here always get that brand. Leave as &quot;No maker&quot; for everyday types.
          </span>
          <SelectField look="admin" name="maker" label="Made by" defaultValue={tag?.maker ?? ""} options={makerOptions} />
        </label>
        <div>
          <button className={save}>{tag ? "Save" : "Add tag"}</button>
        </div>
      </form>

      {tag && (
        <form action={saveTagWordsAction} className={panel}>
          <input type="hidden" name="tag" value={tag.name} />
          <h2 className={panelTitle}>Autofill words</h2>
          <label className={label} htmlFor="words">
            Extra words, separated by commas
            <span className={hint}>
              {info?.parent
                ? "Sub-tags are only picked once their tag has won, so these can be specific (\"macbook\")."
                : "It already knows everyday words for itself. Add more when autofill keeps missing something, such as a new product name."}
              {!tag.builtin && " This tag is new, so these words are all autofill has for it (plus its name)."}
            </span>
          </label>
          <textarea id="words" name="words" rows={3} defaultValue={words.join(", ")} className={field} placeholder="e.g. air fryer, dual basket" />
          <div>
            <button className={save}>Save words</button>
          </div>
        </form>
      )}

      {info && !info.parent && (
        <section className={panel}>
          <h2 className={panelTitle}>Sub-tags</h2>
          {subtags.length === 0 ? (
            <p className="text-sm text-zinc-500">None yet. A sub-tag is a popular product line under it (Laptop → MacBook).</p>
          ) : (
            <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
              {subtags.map((s) => (
                <li key={s.id}>
                  <Link href={`/admin/labels/tag/${s.id}`} className="flex min-h-11 items-center gap-2 text-sm font-medium hover:underline">
                    <Icon name={s.icon} className="size-4 text-zinc-500 dark:text-zinc-400" />
                    {s.name}
                    <Icon name="chevron-right" className="ml-auto size-4 text-zinc-500 dark:text-zinc-400" />
                  </Link>
                </li>
              ))}
            </ul>
          )}
          <Link href={`/admin/labels/tag/new?place=t:${info.tag.id}`} className="self-start text-sm font-semibold text-orange-700 hover:underline dark:text-orange-400">
            + Add a sub-tag to {info.tag.name}
          </Link>
        </section>
      )}

      {tag && (
        <form action={removeTagAction} className={panel}>
          <h2 className={panelTitle}>Remove this {info?.parent ? "sub-tag" : "tag"}</h2>
          <input type="hidden" name="id" value={tag.id} />
          {subtags.length > 0 ? (
            <p className="text-sm text-zinc-500">It has sub-tags. Move or remove those first, then it can go.</p>
          ) : (
            <>
              <p className="text-sm text-zinc-500">
                {deals > 0
                  ? `Its ${deals} deal${deals === 1 ? "" : "s"}, its alerts and its extra words move to the tag you pick. The old address goes there too.`
                  : "Nothing uses it, so it can just go. Anyone following it stops getting its alerts."}
              </p>
              {deals > 0 && (
                <label className={label}>
                  Move its deals to
                  <SelectField look="admin" name="into" label="Move its deals to" required placeholder="Choose a tag" options={into} />
                </label>
              )}
              <div>
                <ConfirmSubmitButton
                  confirmText={`Remove ${tag.name}? ${deals > 0 ? "Its deals, alerts and words move to the tag you picked. " : ""}This can't be undone.`}
                  confirmLabel="Yes, remove it"
                  className="rounded-full border border-red-300 px-5 py-2.5 text-sm font-semibold text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/40"
                >
                  Remove {info?.parent ? "sub-tag" : "tag"}
                </ConfirmSubmitButton>
              </div>
            </>
          )}
        </form>
      )}
    </div>
  );
}
