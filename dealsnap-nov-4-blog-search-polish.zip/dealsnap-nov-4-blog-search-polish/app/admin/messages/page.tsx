import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { findUserByEmail, findUserById, getContactMessages } from "@/lib/db";
import { contactTopic } from "@/lib/contact";
import { deleteContactMessageAction, setContactMessageHandledAction } from "@/lib/admin-actions";
import { timeAgo } from "@/lib/format";
import { getSiteName } from "@/lib/site-url";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import Icon from "@/components/Icon";
import EmptyState from "@/components/EmptyState";

export const metadata = { title: "Messages" };

const button =
  "min-h-[36px] rounded-lg border border-zinc-300 px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800";

// Everything sent through the contact form. Each one was also emailed to the
// right inbox; this is the record, and where to tick them off.
export default async function AdminMessagesPage({ searchParams }: { searchParams: Promise<{ show?: string }> }) {
  await requirePermission("messages.handle");
  const { show: showParam } = await searchParams;
  const show = showParam === "handled" ? "handled" : "open";
  const messages = getContactMessages(show);
  const siteName = getSiteName();

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold sm:text-2xl">Messages</h1>
          <p className="text-sm text-zinc-500">From the contact form. Each one is also emailed to you; Reply opens your email app.</p>
        </div>
        <div className="flex gap-1.5">
          {(["open", "handled"] as const).map((s) => (
            <Link
              key={s}
              href={s === "open" ? "/admin/messages" : "/admin/messages?show=handled"}
              aria-current={show === s ? "page" : undefined}
              // The site's "which ones to show" tabs.
              className={`flex min-h-9 items-center rounded-xl px-3 text-sm font-medium transition-colors ${
                show === s
                  ? "bg-orange-500 text-white"
                  : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
              }`}
            >
              {s === "open" ? "To do" : "Done"}
            </Link>
          ))}
        </div>
      </div>

      {messages.length === 0 ? (
        <EmptyState icon="mail">
          <p>
            {show === "open" ? "No messages waiting." : "Nothing marked as done yet."}
          </p>
        </EmptyState>
      ) : (
        <ul className="flex flex-col gap-3">
          {messages.map((m) => {
            const topic = contactTopic(m.topic)?.label ?? m.topic;
            // Who sent it, if they have an account: signed in when they wrote,
            // or the same email (a suspended member appealing can't sign in).
            const memberId = m.userId ?? findUserByEmail(m.email)?.id;
            const member = memberId ? findUserById(memberId) : undefined;
            const reply = `mailto:${m.email}?subject=${encodeURIComponent(`Re: your message to ${siteName}`)}`;
            return (
              <li key={m.id} className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
                <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                  <div className="min-w-0">
                    <p className="font-semibold">{m.name}</p>
                    <p className="break-all text-sm text-zinc-500">{m.email}</p>
                    {member && (
                      <p className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs">
                        <Link href={`/admin/users/${member.id}`} className="font-medium text-orange-700 hover:underline dark:text-orange-400">
                          Member: {member.username}
                        </Link>
                        {member.suspended && (
                          <span className="rounded-full bg-red-100 px-2 py-0.5 font-medium text-red-700 dark:bg-red-950/40 dark:text-red-400">Suspended</span>
                        )}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-xs text-zinc-500">
                    <span className="rounded-full bg-orange-100 px-2 py-0.5 font-medium text-orange-700 dark:bg-orange-950/40 dark:text-orange-400">{topic}</span>
                    <span title={new Date(m.createdAt).toLocaleString("en-GB")}>{timeAgo(m.createdAt)}</span>
                  </div>
                </div>

                <p className="whitespace-pre-wrap break-words text-sm leading-relaxed text-zinc-700 dark:text-zinc-300">{m.message}</p>

                <div className="flex flex-wrap items-center gap-2">
                  <a href={reply} className="min-h-[36px] rounded-lg bg-orange-500 px-3 py-1.5 text-xs font-semibold text-white hover:bg-orange-600">
                    Reply
                  </a>
                  <form action={setContactMessageHandledAction}>
                    <input type="hidden" name="id" value={m.id} />
                    <input type="hidden" name="handled" value={show === "open" ? "1" : "0"} />
                    <button type="submit" className={button}>
                      {show === "open" ? (
                        <>
                          <Icon name="check" className="mr-1" />
                          Mark as done
                        </>
                      ) : (
                        "Move back to To do"
                      )}
                    </button>
                  </form>
                  <form action={deleteContactMessageAction} className="ml-auto">
                    <input type="hidden" name="id" value={m.id} />
                    <ConfirmSubmitButton
                      confirmText="Delete this message? This can't be undone."
                      className="min-h-[36px] rounded-lg border border-red-300 px-3 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/40"
                    >
                      Delete
                    </ConfirmSubmitButton>
                  </form>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
