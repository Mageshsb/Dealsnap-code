import { requirePermission } from "@/lib/auth";
import PromoEditor from "@/components/admin/PromoEditor";

export const metadata = { title: "New promo" };

export default async function NewPromoPage({ searchParams }: { searchParams: Promise<{ kind?: string; error?: string }> }) {
  await requirePermission("content.manage");
  const { kind, error } = await searchParams;
  return <PromoEditor kind={kind === "banner" ? "banner" : kind === "signup" ? "signup" : "card"} error={error} />;
}
