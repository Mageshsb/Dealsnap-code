import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getPromos, type PromoRow } from "@/lib/db";
import { bannerState } from "@/lib/banners";
import { ukDay } from "@/lib/events";
import { BANNER_SCOPES, CARD_SCOPES } from "@/lib/promos";
import { setPromoLiveAction } from "@/lib/promo-actions";
import BannerStatePill from "@/components/admin/BannerState";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import ContentHeader from "@/components/admin/ContentHeader";
import EmptyState from "@/components/EmptyState";

import Notice from "@/components/admin/Notice";
export const metadata = { title: "Promos" };

const day = (d: string) =>
  new Date(`${d}T12:00:00Z`).toLocaleDateString("en-GB", { day: "numeric", month: "short", timeZone: "UTC" });

// "Every deal list, after deal 3" / "Store pages: currys, after deal 5" / "Every page".
function where(p: PromoRow): string {
  if (p.kind === "banner") return BANNER_SCOPES.find((s) => s.value === p.scope)?.label ?? "Every page";
  const scope = CARD_SCOPES.find((s) => s.value === p.scope)?.label ?? "Every deal list";
  const only = p.kind === "signup" ? " · people not signed in" : "";
  return `${scope}${p.target ? `: ${p.target}` : ""}, after deal ${p.afterDeals}${only}`;
}

export default async function AdminPromosPage({ searchParams }: { searchParams: Promise<{ notice?: string }> }) {
  await requirePermission("content.manage");
  const { notice } = await searchParams;
  const today = ukDay();
  const promos = getPromos().map((p) => ({ promo: p, state: bannerState(p, today) }));

  return (
    <div className="flex flex-col gap-4">
      <ContentHeader
        current="promos"
        title="Promos"
        description="A card sits inside the deal lists after the deal number you choose. A sign-up tile is a card that asks people who aren't signed in to join. A banner is a band under the header. All can be scheduled; cards and banners can carry the “Promoted” tag and a picture."
        actions={
          <>
            <Link href="/admin/promos/new?kind=card" className="rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
              + Card
            </Link>
            <Link href="/admin/promos/new?kind=signup" className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">
              + Sign-up tile
            </Link>
            <Link href="/admin/promos/new?kind=banner" className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">
              + Banner
            </Link>
          </>
        }
      />

      <Notice notice={notice} />

      <ul className="flex flex-col gap-2">
        {promos.map(({ promo, state }) => (
          <li
            key={promo.id}
            className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-3 sm:flex-row sm:items-center dark:border-zinc-800 dark:bg-zinc-900"
          >
            <div className="flex min-w-0 flex-1 flex-col gap-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-full bg-orange-50 px-2 py-0.5 text-xs font-medium text-orange-700 dark:bg-orange-950/40 dark:text-orange-300">
                  {promo.kind === "card" ? "Card" : promo.kind === "signup" ? "Sign-up tile" : "Banner"}
                </span>
                <BannerStatePill state={state} />
                {(promo.showFrom || promo.showUntil) && (
                  <span className="text-xs text-zinc-500">
                    {promo.showFrom ? day(promo.showFrom) : "Any time"} to {promo.showUntil ? day(promo.showUntil) : "no end"}
                  </span>
                )}
              </div>
              <Link href={`/admin/promos/${promo.id}`} className="line-clamp-2 text-sm font-medium hover:underline">
                {promo.headline}
              </Link>
              <span className="text-xs text-zinc-500">{where(promo)}</span>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <Link
                href={`/admin/promos/${promo.id}`}
                className="inline-flex min-h-[36px] items-center rounded-lg border border-zinc-300 px-3.5 text-xs font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
              >
                Edit
              </Link>
              <form action={setPromoLiveAction}>
                <input type="hidden" name="id" value={promo.id} />
                <input type="hidden" name="back" value="list" />
                <input type="hidden" name="live" value={promo.live ? "0" : "1"} />
                {promo.live ? (
                  <ConfirmSubmitButton
                    confirmText="Take this promo down? It disappears from the site."
                    confirmLabel="Take down"
                    className="inline-flex min-h-[36px] items-center rounded-lg border border-red-300 px-3.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/30"
                  >
                    Take down
                  </ConfirmSubmitButton>
                ) : (
                  <button
                    type="submit"
                    className="inline-flex min-h-[36px] items-center rounded-lg bg-orange-500 px-3.5 text-xs font-semibold text-white hover:bg-orange-600"
                  >
                    Put live
                  </button>
                )}
              </form>
            </div>
          </li>
        ))}
        {promos.length === 0 && (
          <li>
            <EmptyState icon="sparkles">
              <p>
                No promos yet.
              </p>
            </EmptyState>
          </li>
        )}
      </ul>
    </div>
  );
}
