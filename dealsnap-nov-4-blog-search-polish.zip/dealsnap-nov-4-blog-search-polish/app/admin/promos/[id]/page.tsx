import { notFound } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import { getPromoById } from "@/lib/db";
import PromoEditor from "@/components/admin/PromoEditor";

export const metadata = { title: "Edit promo" };

export default async function EditPromoPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string; notice?: string }>;
}) {
  await requirePermission("content.manage");
  const promo = getPromoById((await params).id);
  if (!promo) notFound();
  const { error, notice } = await searchParams;
  return <PromoEditor promo={promo} error={error} notice={notice} />;
}
