import Link from "next/link";
import SelectField from "@/components/SelectField";
import { findCommentsAdmin, AdminCommentRow, type UserRole } from "@/lib/db";
import { getAdminDealsView, AdminDealRow } from "@/lib/mock-deals";
import { deleteCommentAction, dismissCommentReportsAction, escalateAction } from "@/lib/admin-actions";
import { requireStaff } from "@/lib/auth";
import { mayManageComment } from "@/lib/permissions";
import AboveYouNote from "@/components/admin/AboveYouNote";
import ReasonDialog from "@/components/admin/ReasonDialog";
import { timeAgo } from "@/lib/format";
import { getCategoryGroups } from "@/lib/categories";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import Icon from "@/components/Icon";
import ClashNotice from "@/components/admin/ClashNotice";
import { seenNow } from "@/lib/collisions";
import { SEARCH_MAX } from "@/lib/search-limits";
import Pager from "@/components/admin/Pager";
import EmptyState from "@/components/EmptyState";
import Notice from "@/components/admin/Notice";
import ListHeader from "@/components/admin/ListHeader";
import { searchField } from "@/components/admin/formStyles";

export const metadata = { title: "Comments" };

const PAGE_SIZE = 30;

const SORTS = {
  newest: "Newest first",
  oldest: "Oldest first",
  "reports-desc": "Most reported",
} as const;
type SortKey = keyof typeof SORTS;

// Moderators can hand a tricky comment to the admins instead of guessing.
function EscalateComment({ comment }: { comment: AdminCommentRow }) {
  return (
    <form action={escalateAction}>
      <input type="hidden" name="kind" value="comment" />
      <input type="hidden" name="targetId" value={comment.userId} />
      <input type="hidden" name="targetLabel" value={`Comment by ${comment.username}: "${comment.text.slice(0, 80)}"`} />
      <input type="hidden" name="targetUrl" value={`/deals/${comment.dealSlug}#comments`} />
      <input type="hidden" name="back" value="/admin/comments" />
      <ReasonDialog
        label="Escalate…"
        title="Ask an admin about this comment"
        intro="The admins see your note on their dashboard."
        noteLabel="What should they know?"
        noteRequired
        confirmLabel="Send to admins"
        tone="sky"
        buttonClassName="min-h-[36px] rounded-lg border border-sky-300 px-3 py-1.5 text-xs font-medium text-sky-700 hover:bg-sky-50 dark:border-sky-900 dark:text-sky-400 dark:hover:bg-sky-950/40"
      />
    </form>
  );
}

function ReportBadge({ comment }: { comment: AdminCommentRow }) {
  if (comment.reportCount === 0) return null;
  return (
    <details className="inline">
      <summary className="inline cursor-pointer list-none rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700 hover:bg-red-200 dark:bg-red-950/40 dark:text-red-400 dark:hover:bg-red-950/70">
        <Icon name="flag" className="mr-1" />{comment.reportCount} report{comment.reportCount === 1 ? "" : "s"}
      </summary>
      <ul className="mt-1 flex flex-col gap-0.5 rounded-lg border border-red-200 bg-red-50 p-2 text-xs text-red-800 dark:border-red-900 dark:bg-red-950/30 dark:text-red-300">
        {comment.reports.map((r) => (
          <li key={r.id}>
            Reported by {r.reporterUsername} · {timeAgo(r.createdAt)}
          </li>
        ))}
      </ul>
    </details>
  );
}

function DismissReportsButton({ comment, seen }: { comment: AdminCommentRow; seen: string }) {
  if (comment.reportCount === 0) return null;
  return (
    <form action={dismissCommentReportsAction}>
      <input type="hidden" name="commentId" value={comment.id} />
      <input type="hidden" name="seen" value={seen} />
      <button type="submit" className="min-h-[36px] rounded-lg border border-zinc-300 px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800">
        Dismiss reports
      </button>
    </form>
  );
}

// Delete and dismiss for a comment by someone the viewer outranks; otherwise
// just a note on why, and (for moderators) the way to escalate it.
function CommentActions({ comment, viewer, seen }: { comment: AdminCommentRow; viewer: { id: string; role: UserRole }; seen: string }) {
  if (!mayManageComment(viewer, comment)) {
    return (
      <>
        <AboveYouNote role={comment.userRole} what="comment" />
        {viewer.role === "moderator" && <EscalateComment comment={comment} />}
      </>
    );
  }
  return (
    <>
      <form action={deleteCommentAction}>
        <input type="hidden" name="id" value={comment.id} />
        <input type="hidden" name="seen" value={seen} />
        <ConfirmSubmitButton
          confirmText="Delete this comment? Replies to it stay. This can't be undone."
          className="min-h-[36px] rounded-lg border border-red-300 px-3 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/40"
        >
          Delete
        </ConfirmSubmitButton>
      </form>
      <DismissReportsButton comment={comment} seen={seen} />
      {viewer.role === "moderator" && <EscalateComment comment={comment} />}
    </>
  );
}

export default async function AdminCommentsPage({
  searchParams,
}: {
  searchParams: Promise<{
    q?: string;
    category?: string;
    deal?: string;
    reported?: string;
    sort?: string;
    view?: string;
    page?: string;
    notice?: string;
    clash?: string;
    error?: string;
  }>;
}) {
  const {
    q = "",
    category = "all",
    deal: dealSlug = "",
    reported: reportedParam,
    sort: sortParam,
    view: viewParam,
    page: pageParam,
    notice,
    clash,
    error,
  } = await searchParams;
  // When this page was shown, for its buttons (lib/collisions.ts).
  const seen = seenNow();
  const viewer = await requireStaff();
  const sort: SortKey = sortParam && sortParam in SORTS ? (sortParam as SortKey) : "newest";
  const reportedOnly = reportedParam === "true";
  const grouped = viewParam === "grouped";
  const page = Math.max(1, parseInt(pageParam ?? "1", 10) || 1);

  const allDeals = getAdminDealsView();
  const dealsBySlug = new Map<string, AdminDealRow>(allDeals.map((d) => [d.slug, d]));
  // A deal's title and category live with the deals, so work out which deals
  // match and let the database do the rest: filtering, sorting and paging.
  const needle = q.trim().toLowerCase();
  const { rows: pageComments, total } = findCommentsAdmin({
    search: needle,
    dealSlug: dealSlug || undefined,
    titleSlugs: needle ? allDeals.filter((d) => d.title.toLowerCase().includes(needle)).map((d) => d.slug) : undefined,
    onlySlugs: category !== "all" ? allDeals.filter((d) => d.category === category).map((d) => d.slug) : undefined,
    reportedOnly,
    sort,
    limit: PAGE_SIZE,
    offset: (page - 1) * PAGE_SIZE,
  });

  const activeDeal = dealSlug ? dealsBySlug.get(dealSlug) : undefined;
  // The List / By product choice is a view, not a filter, so it doesn't count here.
  const hasFilters = Boolean(q) || category !== "all" || Boolean(dealSlug) || reportedOnly || sort !== "newest";

  function baseParams() {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (category !== "all") params.set("category", category);
    if (dealSlug) params.set("deal", dealSlug);
    if (reportedOnly) params.set("reported", "true");
    if (sort !== "newest") params.set("sort", sort);
    if (grouped) params.set("view", "grouped");
    return params;
  }

  function pageHref(target: number) {
    const params = baseParams();
    params.set("page", String(target));
    return `/admin/comments?${params.toString()}`;
  }

  function viewHref(next: "list" | "grouped") {
    const params = baseParams();
    if (next === "grouped") params.set("view", "grouped");
    else params.delete("view");
    return `/admin/comments?${params.toString()}`;
  }

  function clearDealHref() {
    const params = baseParams();
    params.delete("deal");
    return `/admin/comments?${params.toString()}`;
  }

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  const groups = grouped
    ? Array.from(
        pageComments.reduce((map, c) => {
          const list = map.get(c.dealSlug) ?? [];
          list.push(c);
          map.set(c.dealSlug, list);
          return map;
        }, new Map<string, AdminCommentRow[]>())
      ).sort((a, b) => {
        const titleA = dealsBySlug.get(a[0])?.title ?? a[0];
        const titleB = dealsBySlug.get(b[0])?.title ?? b[0];
        return titleA.localeCompare(titleB);
      })
    : [];

  return (
    <div className="flex flex-col gap-4">
      <ListHeader
        title="Comments"
        count={total}
        noun="comment"
        filtered={hasFilters}
        clearHref={grouped ? "/admin/comments?view=grouped" : "/admin/comments"}
        aside={
        <div className="flex shrink-0 gap-1 rounded-lg border border-zinc-300 p-0.5 dark:border-zinc-700">
          {(["list", "grouped"] as const).map((v) => {
            const active = (v === "grouped") === grouped;
            return (
              <Link
                key={v}
                href={viewHref(v)}
                aria-current={active ? "true" : undefined}
                className={`rounded-md px-3 py-1.5 text-sm font-medium ${
                  active
                    ? "bg-orange-100 text-orange-700 dark:bg-orange-950/50 dark:text-orange-400"
                    : "text-zinc-600 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-800"
                }`}
              >
                {v === "list" ? "List" : "By product"}
              </Link>
            );
          })}
        </div>
        }
      />

      <ClashNotice message={clash} />
      <Notice notice={notice} error={error} />

      {activeDeal && (
        <p className="flex flex-wrap items-center gap-2 rounded-lg border border-orange-200 bg-orange-50 px-3 py-2 text-sm text-orange-800 dark:border-orange-900 dark:bg-orange-950/30 dark:text-orange-300">
          Showing comments on{" "}
          <span className="font-semibold">
            {activeDeal.title}
          </span>
          <Link href={clearDealHref()} className="ml-auto text-xs font-medium hover:underline">
            Remove filter <Icon name="x" className="ml-0.5" />
          </Link>
        </p>
      )}

      <form className="grid grid-cols-2 items-center gap-2 sm:flex sm:flex-wrap" action="/admin/comments">
          <input
            type="search"
          aria-label="Search this list"
            name="q"
            defaultValue={q}
            maxLength={SEARCH_MAX}
            placeholder="Search text, product, or username…"
            className={`col-span-2 min-w-[200px] sm:col-span-1 sm:flex-1 ${searchField}`}
          />
          <SelectField
            look="admin"
            name="category"
            label="Category"
            defaultValue={category}
            options={[{ value: "all", label: "All categories" }, ...getCategoryGroups().map((g) => ({ value: g.name, label: g.name }))]}
            className="w-full sm:w-auto sm:max-w-[180px]"
          />
          <SelectField
            look="admin"
            name="sort"
            label="Sort by"
            defaultValue={sort}
            options={Object.entries(SORTS).map(([key, label]) => ({ value: key, label }))}
            className="w-full sm:w-auto"
            leadingIcon="arrow-up-down"
          />
          <label className="flex items-center gap-1.5 rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-sm dark:border-zinc-700 dark:bg-zinc-900">
            <input type="checkbox" name="reported" value="true" defaultChecked={reportedOnly} className="h-4 w-4 accent-red-500" />
            <Icon name="flag" className="size-4 text-red-500" />
            Reported only
          </label>
          {dealSlug && <input type="hidden" name="deal" value={dealSlug} />}
          {grouped && <input type="hidden" name="view" value="grouped" />}
          <button
            type="submit"
            className="col-span-2 min-h-[42px] rounded-lg bg-orange-500 px-5 py-2 text-sm font-semibold sm:col-auto text-white hover:bg-orange-600"
          >
            Apply
          </button>
        </form>

      {grouped ? (
        <div className="flex flex-col gap-4">
          {groups.map(([slug, groupComments]) => {
            const deal = dealsBySlug.get(slug);
            const groupReportCount = groupComments.reduce((n, c) => n + c.reportCount, 0);
            return (
              <div key={slug} className="rounded-xl border border-zinc-200 dark:border-zinc-800">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 bg-zinc-50 px-4 py-2 dark:border-zinc-800 dark:bg-zinc-900">
                  <div className="min-w-0">
                    {deal ? (
                      <Link href={`/deals/${slug}`} className="font-medium hover:underline" target="_blank">
                        {deal.title}
                      </Link>
                    ) : (
                      <span className="font-medium text-zinc-500">Unknown product ({slug})</span>
                    )}
                    {deal && <p className="text-xs text-zinc-500">{deal.category}</p>}
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    {groupReportCount > 0 && (
                      <span className="rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700 dark:bg-red-950/40 dark:text-red-400">
                        <Icon name="flag" className="mr-1" />{groupReportCount}
                      </span>
                    )}
                    <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-xs text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">
                      {groupComments.length} comment{groupComments.length === 1 ? "" : "s"}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
                  {groupComments.map((c) => (
                    <div key={c.id} className="flex flex-col gap-3 px-4 py-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
                      <div className="min-w-0">
                        <p className="text-sm">{c.text}</p>
                        <p className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-zinc-500">
                          <span>
                            {c.username} · {timeAgo(c.createdAt)}
                            {c.parentId && " · reply"}
                          </span>
                          <ReportBadge comment={c} />
                        </p>
                      </div>
                      <div className="flex shrink-0 flex-wrap items-center gap-2 sm:flex-col sm:items-end sm:gap-1.5">
                        <CommentActions comment={c} viewer={viewer} seen={seen} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
          {groups.length === 0 && (
            <EmptyState icon="comment">
              <p>
                No comments match these filters.
              </p>
            </EmptyState>
          )}
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {pageComments.map((c) => {
            const deal = dealsBySlug.get(c.dealSlug);
            return (
              <div
                key={c.id}
                className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-4 sm:flex-row sm:items-start sm:justify-between sm:gap-4 dark:border-zinc-800 dark:bg-zinc-900"
              >
                <div className="min-w-0">
                  <p className="text-sm">{c.text}</p>
                  <p className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-zinc-500">
                    <span>
                      {c.username} · {timeAgo(c.createdAt)}
                      {c.parentId && " · reply"} ·{" "}
                      {deal ? (
                        <>
                          <Link href={`/deals/${c.dealSlug}`} className="hover:underline" target="_blank">
                            {deal.title}
                          </Link>{" "}
                          ·{" "}
                          <Link href={`/admin/comments?deal=${c.dealSlug}`} className="hover:underline">
                            filter to this product
                          </Link>
                        </>
                      ) : (
                        <span>deal not found ({c.dealSlug})</span>
                      )}
                    </span>
                    <ReportBadge comment={c} />
                  </p>
                </div>
                <div className="flex shrink-0 flex-wrap items-center gap-2 sm:flex-col sm:items-end sm:gap-1.5">
                  <CommentActions comment={c} viewer={viewer} seen={seen} />
                </div>
              </div>
            );
          })}
          {pageComments.length === 0 && (
            <EmptyState icon="comment">
              <p>
                No comments match these filters.
              </p>
            </EmptyState>
          )}
        </div>
      )}

      <Pager page={page} totalPages={totalPages} href={pageHref} />
    </div>
  );
}
