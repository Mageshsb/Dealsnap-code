import Link from "next/link";
import SelectField from "@/components/SelectField";
import { findDuplicates } from "@/lib/mock-deals";
import { ADMIN_DEAL_SORTS, establishedStoreSlugs, findAdminDeals, getAdminDealFacets, type AdminDealFilters, type AdminDealSort } from "@/lib/admin-deals";
import {
  setDealStatusAction,
  setDealFeaturedAction,
  setDealHeroAction,
  deleteDealAction,
  bulkDealStatusAction,
  escalateAction,
  clearEndedReportsAction,
} from "@/lib/admin-actions";
import ReasonDialog from "@/components/admin/ReasonDialog";
import { dealRemovalReasons } from "@/lib/moderation";
import { timeAgo } from "@/lib/format";
import { HERO_NAME } from "@/lib/hero";
import { getDealStatus } from "@/lib/format";
import { DEAL_KINDS, dealPriceTag, filedAs, hasSinglePrice, priceTagText } from "@/lib/deal-kinds";
import { slugify } from "@/lib/slug";
import { getCategoryGroups } from "@/lib/categories";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import RowMenu from "@/components/admin/RowMenu";
import { requireStaff } from "@/lib/auth";
import { can, mayManageDeal } from "@/lib/permissions";
import AboveYouNote from "@/components/admin/AboveYouNote";
import WhereBadge from "@/components/WhereBadge";
import Icon, { HeartIcon } from "@/components/Icon";
import ClashNotice from "@/components/admin/ClashNotice";
import { seenNow } from "@/lib/collisions";
import { SEARCH_MAX } from "@/lib/search-limits";
import Pager from "@/components/admin/Pager";
import { searchField } from "@/components/admin/formStyles";
import Notice from "@/components/admin/Notice";
import ListHeader from "@/components/admin/ListHeader";

export const metadata = { title: "Deals" };

const PAGE_SIZE = 25;

// The hidden fields every deal-moderation form posts so the action knows which deal.
function DealFields({ identity, slug }: { identity: { source: string; id: string }; slug: string }) {
  return (
    <>
      <input type="hidden" name="source" value={identity.source} />
      <input type="hidden" name="id" value={identity.id} />
      <input type="hidden" name="slug" value={slug} />
    </>
  );
}

const SORTS = ADMIN_DEAL_SORTS;
type SortKey = AdminDealSort;

export default async function AdminDealsPage({
  searchParams,
}: {
  searchParams: Promise<{
    q?: string;
    status?: string;
    category?: string;
    brand?: string;
    tag?: string;
    kind?: string;
    flag?: string;
    source?: string;
    store?: string;
    sort?: string;
    page?: string;
    error?: string;
    notice?: string;
    clash?: string;
  }>;
}) {
  const staff = await requireStaff();
  const canCurate = can(staff.role, "deals.curate");
  const canEdit = can(staff.role, "deals.edit");
  const canDelete = can(staff.role, "deals.delete");
  const canStores = can(staff.role, "stores.manage");
  const isModerator = staff.role === "moderator";
  const {
    q = "",
    status = "all",
    category = "all",
    brand = "all",
    tag = "all",
    kind = "all",
    flag = "all",
    source = "all",
    store = "",
    sort: sortParam,
    page: pageParam,
    error,
    notice,
    clash,
  } = await searchParams;
  // When this page was shown, for its buttons (lib/collisions.ts).
  const seen = seenNow();
  const sort: SortKey = sortParam && sortParam in SORTS ? (sortParam as SortKey) : "newest";
  const page = Math.max(1, parseInt(pageParam ?? "1", 10) || 1);

  // The database filters, sorts and counts, and hands back just this page: the
  // list costs the same at 500 deals or 500,000 (lib/admin-deals.ts).
  const filters: AdminDealFilters = { q, status, category, tag, brand, kind, source, store, flag, sort };
  const { rows: pageDeals, total } = findAdminDeals(filters, page, PAGE_SIZE);
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const facets = getAdminDealFacets();
  // Stores that already have at least one approved (live) deal: used to flag a
  // pending submission's store as new, so admins can catch a duplicate spelling
  // before it fragments an existing store.
  const establishedStores = establishedStoreSlugs(pageDeals.filter((d) => getDealStatus(d) === "pending").map((d) => slugify(d.store)));
  const currentHero = findAdminDeals({ ...filters, q: "", status: "hero", category: "all", tag: "all", brand: "all", kind: "all", source: "all", store: "", flag: "all" }, 1, 1).rows[0];
  const storeName = store ? (facets.stores.find((s) => s.slug === store)?.name ?? store) : "";

  function pageHref(target: number) {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (status !== "all") params.set("status", status);
    if (category !== "all") params.set("category", category);
    if (tag !== "all") params.set("tag", tag);
    if (brand !== "all") params.set("brand", brand);
    if (kind !== "all") params.set("kind", kind);
    if (flag !== "all") params.set("flag", flag);
    if (source !== "all") params.set("source", source);
    if (store) params.set("store", store);
    if (sort !== "newest") params.set("sort", sort);
    params.set("page", String(target));
    return `/admin/deals?${params.toString()}`;
  }

  const pendingOnPage = pageDeals.filter((d) => getDealStatus(d) === "pending" && mayManageDeal(staff, d)).length;
  const hasFilters =
    q || status !== "all" || category !== "all" || tag !== "all" || brand !== "all" || kind !== "all" || flag !== "all" || source !== "all" || store || sort !== "newest";
  // The extra filters live behind "More filters", which opens itself while any is on.
  const activeFilters = [status !== "all", category !== "all", tag !== "all", Boolean(store), brand !== "all", kind !== "all", flag !== "all", source !== "all", sort !== "newest"].filter(Boolean).length;
  const moreOn = brand !== "all" || kind !== "all" || flag !== "all" || source !== "all";

  // What each dropdown offers: only things that deals actually have, with how many.
  const byName = (a: [string, unknown], b: [string, unknown]) => a[0].localeCompare(b[0], "en-GB", { sensitivity: "base" });
  const withCount = (label: string, n: number | undefined) => (n ? `${label} (${n})` : label);
  const live = facets.states.live + facets.states.featured + facets.states.hero;
  const brandCounts = new Map(facets.brands.map((b) => [b.slug, b.count]));
  const brandOptions: [string, string][] = facets.brands.map((b) => [b.slug, b.name] as [string, string]).sort((a, b) => a[1].localeCompare(b[1]));
  // Tags narrow to the chosen category once it's applied.
  const tagCounts = new Map<string, number>();
  for (const t of facets.tags) if (category === "all" || t.category === category) tagCounts.set(t.tag, (tagCounts.get(t.tag) ?? 0) + t.count);
  if (tag !== "all" && !tagCounts.has(tag)) tagCounts.set(tag, 0);
  const storeCounts = new Map(facets.stores.map((s) => [s.slug, s.count]));
  const storeOptions: [string, string][] = facets.stores.map((s) => [s.slug, s.name] as [string, string]).sort((a, b) => byName([a[1], 0], [b[1], 0]));
  const kindCounts = facets.kinds;

  return (
    <div className="flex flex-col gap-4">
      <ListHeader title="Deals" count={total} noun="deal" filtered={Boolean(hasFilters)} clearHref="/admin/deals" />

      <ClashNotice message={clash} />
      <Notice notice={notice} error={error} />

      {store && canStores && (
        <p className="text-sm">
          <Link href={`/admin/stores/${store}`} className="inline-flex items-center gap-1.5 text-zinc-500 hover:underline">
            <Icon name="store" className="size-4" />
            Manage {storeName || "this store"}
          </Link>
        </p>
      )}

      <form className="group/filters flex flex-col gap-2" action="/admin/deals">
        {/* On a phone the search sits alone with a Filters button (a plain checkbox, so no script and
            no page shift); the dropdowns open under it, already open while any filter is on. */}
        <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-center">
          <input id="deal-filters" type="checkbox" defaultChecked={Boolean(hasFilters)} className="sr-only" aria-label="Show filters" />
          <div className="flex gap-2 sm:contents">
            <input
              type="search"
          aria-label="Search this list"
              name="q"
              defaultValue={q}
              maxLength={SEARCH_MAX}
              placeholder="Search title, store, brand or poster…"
              className={`min-w-0 flex-1 sm:min-w-[180px] ${searchField}`}
            />
            <label
              htmlFor="deal-filters"
              className="flex min-h-[42px] shrink-0 cursor-pointer items-center gap-1.5 rounded-lg border border-zinc-300 bg-zinc-50 px-3 text-sm font-medium group-has-[#deal-filters:focus-visible]/filters:border-orange-500 sm:hidden dark:border-zinc-700 dark:bg-zinc-900"
            >
              <Icon name="sliders" className="size-4" />
              Filters
              {activeFilters > 0 && <span className="rounded-full bg-orange-500 px-1.5 text-xs font-bold text-white">{activeFilters}</span>}
            </label>
          </div>
          <div className="hidden grid-cols-2 items-center gap-2 group-has-[#deal-filters:checked]/filters:max-sm:grid sm:contents">
          <SelectField
            look="admin"
            name="status"
            label="Status"
            defaultValue={status}
            options={[
              { value: "all", label: "All statuses" },
              { value: "pending", label: withCount("Pending review", facets.states.pending) },
              { value: "live", label: withCount("Live", live) },
              { value: "featured", label: withCount("Featured", facets.states.featured) },
              { value: "hero", label: HERO_NAME },
              { value: "expired", label: withCount("Expired", facets.states.expired) },
              { value: "removed", label: withCount("Taken down", facets.states.removed) },
            ]}
            className="w-full sm:w-auto"
          />
          <SelectField
            look="admin"
            name="category"
            label="Category"
            defaultValue={category}
            options={[{ value: "all", label: "All categories" }, ...getCategoryGroups().map((g) => ({ value: g.name, label: g.name }))]}
            className="w-full sm:w-auto sm:max-w-[180px]"
          />
          <SelectField
            look="admin"
            name="tag"
            label="Tag"
            defaultValue={tag}
            options={[
              { value: "all", label: "All tags" },
              ...[...tagCounts.entries()].sort(byName).map(([value, n]) => ({ value, label: withCount(value, n) })),
            ]}
            className="w-full sm:w-auto sm:max-w-[170px]"
          />
          <SelectField
            look="admin"
            name="store"
            label="Store"
            defaultValue={store}
            options={[
              { value: "", label: "All stores" },
              ...storeOptions.map(([value, label]) => ({ value, label: withCount(label, storeCounts.get(value)) })),
            ]}
            className="w-full sm:w-auto sm:max-w-[170px]"
          />
          <SelectField
            look="admin"
            name="sort"
            label="Sort by"
            defaultValue={sort}
            options={Object.entries(SORTS).map(([key, label]) => ({ value: key, label }))}
            className="w-full sm:w-auto"
            leadingIcon="arrow-up-down"
          />
          <button
            type="submit"
            className="col-span-2 min-h-[42px] rounded-lg bg-orange-500 px-5 py-2 text-sm font-semibold sm:col-auto text-white hover:bg-orange-600"
          >
            Apply
          </button>
          </div>
        </div>
        <details open={moreOn} className="group hidden group-has-[#deal-filters:checked]/filters:max-sm:block sm:block">
          <summary className="inline-flex min-h-8 cursor-pointer list-none items-center gap-1 text-sm font-medium text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200">
            <Icon name="chevron-down" className="size-4 transition-transform group-open:rotate-180" />
            More filters
          </summary>
          <div className="mt-2 grid grid-cols-2 items-center gap-2 sm:flex sm:flex-wrap">
            <SelectField
              look="admin"
              name="kind"
              label="Type"
              defaultValue={kind}
              options={[
                { value: "all", label: "All types" },
                ...DEAL_KINDS.map((k) => ({ value: k.value, label: withCount(k.name, kindCounts.get(k.value)) })),
              ]}
              className="w-full sm:w-auto"
            />
            <SelectField
              look="admin"
              name="brand"
              label="Brand"
              defaultValue={brand}
              options={[
                { value: "all", label: "All brands" },
                { value: "none", label: "No brand" },
                ...brandOptions.map(([value, label]) => ({ value, label: withCount(label, brandCounts.get(value)) })),
              ]}
              className="w-full sm:w-auto sm:max-w-[170px]"
            />
            <SelectField
              look="admin"
              name="flag"
              label="Flags"
              defaultValue={flag}
              options={[
                { value: "all", label: "Any flags" },
                { value: "reported", label: "Reported by members" },
                { value: "ended", label: "Marked as ended" },
                { value: "labels", label: "Labels need a check" },
                { value: "comments", label: "Has comments" },
              ]}
              className="w-full sm:w-auto"
            />
            <SelectField
              look="admin"
              name="source"
              label="Source"
              defaultValue={source}
              options={[
                { value: "all", label: "All sources" },
                { value: "user", label: "Posted by members" },
                { value: "seed", label: "Starter deals" },
              ]}
              className="w-full sm:w-auto"
            />
          </div>
        </details>
      </form>

      {pendingOnPage > 0 && (
        <form
          id="bulk-review"
          action={bulkDealStatusAction}
          className="flex flex-wrap items-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-sm dark:border-amber-900 dark:bg-amber-950/30"
        >
          <input type="hidden" name="seen" value={seen} />
          <span className="mr-auto text-amber-900 dark:text-amber-200">
            Tick pending deals below to approve or reject several at once.
          </span>
          <button
            type="submit"
            name="status"
            value="live"
            className="min-h-[36px] rounded-lg bg-green-700 px-3.5 text-xs font-semibold text-white hover:bg-green-800"
          >
            Approve ticked
          </button>
          <ReasonDialog
            label="Reject ticked…"
            title="Reject the ticked deals"
            intro="Everyone who posted one of them sees this reason."
            reasons={dealRemovalReasons()}
            confirmLabel="Reject ticked deals"
            buttonClassName="min-h-[36px] rounded-lg border border-red-300 bg-white px-3.5 text-xs font-semibold text-red-600 hover:bg-red-50 dark:border-red-900 dark:bg-transparent dark:hover:bg-red-950/40"
          >
            <input type="hidden" name="status" value="removed" />
          </ReasonDialog>
        </form>
      )}

      <div className="rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
        <table className="block w-full text-left text-sm">
          <tbody className="block divide-y divide-zinc-100 dark:divide-zinc-800">
            {pageDeals.map((deal) => {
              const identity =
                deal.source === "user"
                  ? { source: "user", id: String(deal.dbId!) }
                  : { source: "seed", id: "" };
              const removed = deal.status === "removed";
              const dealStatus = getDealStatus(deal);
              const statusStyles: Record<typeof dealStatus, string> = {
                live: "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400",
                pending: "bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
                expired: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400",
                removed: "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400",
                featured: "bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400",
                hero: "bg-gradient-to-r from-violet-600 to-fuchsia-600 text-amber-100",
              };
              const statusLabels: Record<typeof dealStatus, string> = {
                live: "Live",
                pending: "Pending",
                expired: "Expired",
                removed: "Removed",
                featured: "Featured",
                hero: HERO_NAME,
              };
              const isNewStore = dealStatus === "pending" && !establishedStores.has(slugify(deal.store));
              const isPending = dealStatus === "pending";
              const canHero = canCurate && (dealStatus === "live" || dealStatus === "featured" || dealStatus === "hero");
              const userDeal = deal.source === "user";
              // A peer's or senior's deal can only be escalated (or reported), never changed.
              const manageable = mayManageDeal(staff, deal);
              const showEdit = userDeal && canEdit && manageable;
              const showDelete = userDeal && canDelete && manageable;
              const hasMenu = manageable ? !isPending || showEdit || showDelete || isModerator : isModerator;

              const statusBadge = (
                <span className={`inline-block rounded-full px-2 py-0.5 text-xs font-medium whitespace-nowrap ${statusStyles[dealStatus]}`}>
                  {dealStatus === "featured" && <Icon name="star" filled className="mr-1" />}
                  {dealStatus === "hero" && <Icon name="crown" filled className="mr-1" />}
                  {statusLabels[dealStatus]}
                </span>
              );
              const storeEl = (
                <span className="inline-flex flex-wrap items-center gap-1.5">
                  {isNewStore ? (
                    <span
                      className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-700 dark:bg-amber-950/40 dark:text-amber-400"
                      title="New store — check it isn't a duplicate spelling of an existing one"
                    >
                      <Icon name="sparkles" className="size-3" />
                      {deal.store}
                    </span>
                  ) : (
                    canStores ? (
                      <Link href={`/admin/stores/${slugify(deal.store)}`} className="hover:text-orange-600 hover:underline">
                        {deal.store}
                      </Link>
                    ) : (
                      <span>{deal.store}</span>
                    )
                  )}
                  <WhereBadge where={deal.whereToBuy} note={deal.whereNote} />
                </span>
              );
              // A new deal that's already on the site (same product still
              // live at the same or a lower price, or one very like it).
              const dupes = isPending
                ? findDuplicates({
                    url: deal.url,
                    title: deal.title,
                    store: deal.store,
                    price: hasSinglePrice(deal) ? deal.price : undefined,
                    excludeSlug: deal.slug,
                  })
                : undefined;
              const repostOf =
                dupes?.same && dupes.same.state !== "ended" && !dupes.same.cheaperNow ? dupes.same : dupes?.similar[0];
              const reportsEl = (
                <>
                  {repostOf && (
                    <Link
                      href={`/deals/${repostOf.slug}`}
                      target="_blank"
                      title={`Looks like a repost of "${repostOf.title}" (${repostOf.priceLabel})`}
                      className="inline-flex items-center gap-1 rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium whitespace-nowrap text-red-700 hover:underline dark:bg-red-950/40 dark:text-red-400"
                    >
                      <Icon name="copy" className="size-3" />
                      Possible repost
                    </Link>
                  )}
                  {deal.reportCount > 0 && (
                    <span className="rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700 dark:bg-red-950/40 dark:text-red-400">
                      <Icon name="flag" className="mr-1" />{deal.reportCount}
                    </span>
                  )}
                  {deal.endedByMembers && !manageable && (
                    <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-xs font-medium whitespace-nowrap text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">
                      <Icon name="hourglass" className="mr-1" />
                      {deal.endedByStaff ? "Ended by team" : deal.endedByPoster ? "Ended by poster" : "Ended by members"}
                    </span>
                  )}
                  {deal.endedByMembers && manageable && (
                    <form action={clearEndedReportsAction} className="inline-flex">
                      <input type="hidden" name="slug" value={deal.slug} />
                          <input type="hidden" name="seen" value={seen} />
                      <button
                        type="submit"
                        title={
                          deal.endedByStaff
                            ? "The team marked this deal as ended, so it shows as expired. Undo if it's still on."
                            : deal.endedByPoster
                              ? "The poster marked this deal as ended, so it shows as expired. Undo if it's still on."
                              : "Members said this deal has ended, so it shows as expired. Undo if it's still on (each of them gets a strike; members whose reports are often wrong stop counting)."
                        }
                        className="rounded-full bg-zinc-100 px-2 py-0.5 text-xs font-medium whitespace-nowrap text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300"
                      >
                        <Icon name="hourglass" className="mr-1" />
                        {deal.endedByStaff ? "Ended by team" : deal.endedByPoster ? "Ended by poster" : "Ended by members"} · Undo
                      </button>
                    </form>
                  )}
                </>
              );

              return (
                <tr key={`${deal.source}-${deal.id}`} className="block px-4 py-3 sm:flex sm:items-start sm:justify-between sm:gap-4">
                  <td className="block sm:min-w-0 sm:flex-1">
                    <div className="flex items-start gap-2.5">
                      {isPending && manageable && (
                        <input
                          type="checkbox"
                          name="pick"
                          form="bulk-review"
                          value={deal.slug}
                          aria-label={`Select ${deal.title}`}
                          className="mt-0.5 h-5 w-5 shrink-0 accent-orange-500"
                        />
                      )}
                      <div className="min-w-0">
                    <Link href={`/deals/${deal.slug}`} className="line-clamp-2 font-medium hover:underline" target="_blank">
                      {deal.title}
                    </Link>
                    <p className="mt-0.5 text-xs text-zinc-500">
                      {filedAs(deal)}
                      {deal.brand && ` · ${deal.brand}`} ·{" "}
                      <Icon name={deal.source === "user" ? "user" : "sprout"} className="mr-0.5" />
                      {deal.source === "user" ? (deal.postedByUsername ?? "user") : "seed"}
                      {isPending && (
                        <span className="ml-1.5 font-medium text-amber-700 dark:text-amber-400">
                          · <Icon name="hourglass" className="mr-0.5" />waiting {timeAgo(deal.postedAt).replace(" ago", "")}
                        </span>
                      )}
                    </p>
                    <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-zinc-500">
                      {statusBadge}
                      {storeEl}
                      <span>{priceTagText(dealPriceTag(deal))}</span>
                      <span><HeartIcon className="mr-1" />{deal.hearts}</span>
                      <Link href={`/admin/comments?deal=${deal.slug}`} className="hover:underline">
                        <Icon name="comment" className="mr-1" />{deal.realCommentCount}
                      </Link>
                      {reportsEl}
                    </div>
                      </div>
                    </div>
                  </td>
                  <td className="block pt-3 sm:shrink-0 sm:pt-0">
                    {!manageable && (
                      <div className="mb-2">
                        <AboveYouNote role={deal.postedByRole ?? "user"} what="deal" />
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      {isPending && manageable && (
                        <>
                          <form action={setDealStatusAction}>
                            <input type="hidden" name="slug" value={deal.slug} />
                          <input type="hidden" name="seen" value={seen} />
                            <input type="hidden" name="status" value="live" />
                            <button
                              type="submit"
                              className="min-h-[36px] rounded-lg bg-green-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-green-800"
                            >
                              Approve
                            </button>
                          </form>
                          <form action={setDealStatusAction}>
                            <input type="hidden" name="slug" value={deal.slug} />
                          <input type="hidden" name="seen" value={seen} />
                            <input type="hidden" name="status" value="removed" />
                            <ReasonDialog
                              label="Reject"
                              title={`Reject "${deal.title}"`}
                              intro="The person who posted it sees this reason."
                              reasons={dealRemovalReasons()}
                              confirmLabel="Reject deal"
                              buttonClassName="min-h-[36px] rounded-lg border border-red-300 px-3.5 py-1.5 text-xs font-semibold text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/40"
                            />
                          </form>
                        </>
                      )}
                      {hasMenu && (
                        <RowMenu label={isPending ? "More" : "Actions"}>
                          {!isPending && manageable && (
                            <form action={setDealStatusAction}>
                              <input type="hidden" name="slug" value={deal.slug} />
                          <input type="hidden" name="seen" value={seen} />
                              <input type="hidden" name="status" value={removed ? "live" : "removed"} />
                              {removed ? (
                                <button type="submit" role="menuitem" className="text-zinc-700 dark:text-zinc-300">
                                  Restore
                                </button>
                              ) : (
                                <ReasonDialog
                                  label="Take down…"
                                  title={`Take down "${deal.title}"`}
                                  intro={
                                    deal.source === "user"
                                      ? "The person who posted it sees this reason. You can restore it later. “Expired or out of stock” keeps it up, marked as ended, instead."
                                      : "You can restore it later. “Expired or out of stock” keeps it up, marked as ended, instead."
                                  }
                                  reasons={dealRemovalReasons()}
                                  confirmLabel="Take it down"
                                  buttonClassName="text-zinc-700 dark:text-zinc-300"
                                />
                              )}
                            </form>
                          )}
                          {isModerator && (
                            <form action={escalateAction}>
                              <input type="hidden" name="kind" value="deal" />
                              <input type="hidden" name="targetId" value={deal.slug} />
                              <input type="hidden" name="targetLabel" value={deal.title} />
                              <input type="hidden" name="targetUrl" value={`/deals/${deal.slug}`} />
                              <input type="hidden" name="back" value="/admin/deals" />
                              <ReasonDialog
                                label="Escalate to admins…"
                                title="Ask an admin to look at this"
                                intro="Use this when you're not sure what to do. The admins see your note on their dashboard."
                                noteLabel="What should they know?"
                                noteRequired
                                confirmLabel="Send to admins"
                                tone="sky"
                                buttonClassName="text-sky-700 dark:text-sky-400"
                              />
                            </form>
                          )}
                          {!isPending && canCurate && manageable && (
                            <form action={setDealFeaturedAction}>
                              <DealFields identity={identity} slug={deal.slug} />
                              <input type="hidden" name="seen" value={seen} />
                              <input type="hidden" name="featured" value={deal.featured ? "false" : "true"} />
                              <button type="submit" role="menuitem" className="text-zinc-700 dark:text-zinc-300">
                                {deal.featured ? "Unfeature" : "Feature"}
                              </button>
                            </form>
                          )}
                          {canHero && manageable && (
                            <form action={setDealHeroAction}>
                              <input type="hidden" name="slug" value={deal.slug} />
                          <input type="hidden" name="seen" value={seen} />
                              <input type="hidden" name="hero" value={deal.hero ? "false" : "true"} />
                              {deal.hero || !currentHero ? (
                                <button type="submit" role="menuitem" className="text-violet-600 dark:text-violet-400">
                                  {deal.hero ? `Remove ${HERO_NAME}` : `Make ${HERO_NAME}`}
                                </button>
                              ) : (
                                <ConfirmSubmitButton
                                  confirmText={`Make "${deal.title}" the ${HERO_NAME}? It replaces "${currentHero.title}" — only one deal can be the ${HERO_NAME} at a time.`}
                                  className="text-violet-600 dark:text-violet-400"
                                >
                                  Make {HERO_NAME}
                                </ConfirmSubmitButton>
                              )}
                            </form>
                          )}
                          {showEdit && (
                            <Link href={`/deals/${deal.slug}/edit?from=admin`} role="menuitem" className="text-zinc-700 dark:text-zinc-300">
                              Edit
                            </Link>
                          )}
                          {showDelete && (
                            <>
                              <form action={deleteDealAction} className="mt-1 border-t border-zinc-100 pt-1 dark:border-zinc-800">
                                <input type="hidden" name="id" value={deal.dbId} />
                                <input type="hidden" name="slug" value={deal.slug} />
                          <input type="hidden" name="seen" value={seen} />
                                <ConfirmSubmitButton
                                  confirmText={`Permanently delete "${deal.title}"? This can't be undone.`}
                                  className="text-red-600"
                                >
                                  Delete
                                </ConfirmSubmitButton>
                              </form>
                            </>
                          )}
                        </RowMenu>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
            {pageDeals.length === 0 && (
              <tr className="block">
                <td colSpan={6} className="block px-4 py-8 text-center text-zinc-500">
                  No deals match these filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Pager page={page} totalPages={totalPages} href={pageHref} />
    </div>
  );
}
