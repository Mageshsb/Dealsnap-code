import Link from "next/link";
import { requireStaff } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { findCommentsAdmin, findUsersAdmin } from "@/lib/db";
import { findAdminDeals, searchAdminStores } from "@/lib/admin-deals";
import { getDealStatus, timeAgo } from "@/lib/format";
import { SEARCH_MAX } from "@/lib/search-limits";
import Icon, { type IconName } from "@/components/Icon";
import EmptyState from "@/components/EmptyState";
import AdminSearch from "@/components/admin/AdminSearch";

export const metadata = { title: "Search" };

const SHOW = 5;

// Matches across the whole of Admin, a few of each, with a link on to the full
// list (already searched) for any that has more. Only sections the viewer's
// role may open are searched.
export default async function AdminSearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const staff = await requireStaff();
  const { q: raw = "" } = await searchParams;
  const q = raw.trim().slice(0, SEARCH_MAX);
  const needle = q.toLowerCase();

  const sections: {
    key: string;
    title: string;
    icon: IconName;
    total: number;
    all: string;
    rows: { href: string; title: string; note: string; external?: boolean }[];
  }[] = [];

  if (needle) {
    if (can(staff.role, "deals.review")) {
      const found = findAdminDeals(
        { q, status: "all", category: "all", tag: "all", brand: "all", kind: "all", source: "all", store: "", flag: "all", sort: "newest" },
        1,
        SHOW,
      );
      sections.push({
        key: "deals",
        title: "Deals",
        icon: "tag",
        total: found.total,
        all: `/admin/deals?q=${encodeURIComponent(q)}`,
        rows: found.rows.map((d) => ({
          href: `/admin/deals?q=${encodeURIComponent(d.title.slice(0, 60))}`,
          title: d.title,
          note: `${getDealStatus(d)} · ${d.store} · ${timeAgo(d.postedAt)}`,
        })),
      });
    }
    if (can(staff.role, "users.view")) {
      const members = findUsersAdmin({
        search: q,
        searchEmail: can(staff.role, "users.security"),
        status: "all",
        sort: "newest",
        limit: SHOW,
        offset: 0,
      });
      sections.push({
        key: "members",
        title: "Members",
        icon: "users",
        total: members.total,
        all: `/admin/users?q=${encodeURIComponent(q)}`,
        rows: members.rows.map((u) => ({
          href: `/admin/users/${u.id}`,
          title: u.username,
          note: `${u.role}${u.suspended ? " · suspended" : ""} · ${u.dealCount} deals · ${u.commentCount} comments`,
        })),
      });
    }
    if (can(staff.role, "comments.moderate")) {
      const comments = findCommentsAdmin({ search: needle, sort: "newest", limit: SHOW, offset: 0 });
      sections.push({
        key: "comments",
        title: "Comments",
        icon: "comment",
        total: comments.total,
        all: `/admin/comments?q=${encodeURIComponent(q)}`,
        rows: comments.rows.map((c) => ({
          href: `/admin/comments?deal=${c.dealSlug}`,
          title: c.text.length > 90 ? `${c.text.slice(0, 90)}…` : c.text,
          note: `${c.username} · ${timeAgo(c.createdAt)}`,
        })),
      });
    }
    if (can(staff.role, "stores.manage")) {
      const stores = searchAdminStores(q, SHOW);
      sections.push({
        key: "stores",
        title: "Stores",
        icon: "store",
        total: stores.total,
        all: `/admin/stores?q=${encodeURIComponent(q)}`,
        rows: stores.stores.map((s) => ({ href: `/admin/stores/${s.slug}`, title: s.name, note: `${s.approved} approved · ${s.pending} waiting` })),
      });
    }
  }
  const found = sections.filter((s) => s.total > 0);

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-xl font-bold sm:text-2xl">Search</h1>
        <p className="text-sm text-zinc-500">Deals, members, comments and stores in one go.</p>
      </div>
      <AdminSearch defaultValue={q} />

      {!needle ? (
        <EmptyState icon="search">
          <p>Type a deal, username, store or something someone said.</p>
        </EmptyState>
      ) : found.length === 0 ? (
        <EmptyState icon="search">
          <p>Nothing in Admin matches &ldquo;{q}&rdquo;.</p>
        </EmptyState>
      ) : (
        found.map((s) => (
          <section key={s.key} className="rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
            <div className="flex items-center justify-between gap-3 border-b border-zinc-100 px-4 py-2.5 dark:border-zinc-800">
              <h2 className="flex items-center gap-2 text-sm font-bold">
                <Icon name={s.icon} className="size-4 text-zinc-500 dark:text-zinc-400" />
                {s.title}
                <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-xs font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">
                  {s.total.toLocaleString("en-GB")}
                </span>
              </h2>
              {s.total > SHOW && (
                <Link href={s.all} className="text-sm font-medium text-orange-700 dark:text-orange-400 hover:underline">
                  See all
                </Link>
              )}
            </div>
            <ul className="divide-y divide-zinc-100 dark:divide-zinc-800">
              {s.rows.map((r, i) => (
                <li key={`${r.href}-${i}`}>
                  <Link href={r.href} className="flex flex-col gap-0.5 px-4 py-2.5 hover:bg-zinc-50 dark:hover:bg-zinc-800/50">
                    <span className="line-clamp-2 text-sm font-medium">{r.title}</span>
                    <span className="text-xs text-zinc-500">{r.note}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        ))
      )}
    </div>
  );
}
