import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { backupDatabaseTo } from "@/lib/db";
import { adminForDownload, recordDownload } from "@/lib/admin-files";
import { serverBackupPath } from "@/lib/backups";
import { picturesOnDisk, pictureStoreName } from "@/lib/picture-store";
import { tarGzStream } from "@/lib/tar";

// A consistent copy of the whole database, made with SQLite's VACUUM INTO so it
// is safe to take while the site is running. ?file=dealsnap-2026-10-28.db
// downloads one of the daily backups kept on the server instead (lib/backups.ts).
export async function GET(request: Request) {
  const admin = await adminForDownload();
  if (!admin) return new Response("Admins only.", { status: 403 });

  // ?pictures=1: every picture members added (deal, comment and Community
  // photos), as one .tar.gz. Unpack it into the site's pictures folder to put
  // them back (docs/HOSTING.md). With cloud storage the provider keeps them.
  if (new URL(request.url).searchParams.get("pictures")) {
    if (pictureStoreName().kind !== "disk") return new Response("Pictures are kept in cloud storage, which has its own copies.", { status: 404 });
    const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    const entries = picturesOnDisk().map((p) => ({ name: `pictures/${p.id.slice(0, 2)}/${p.path.split("/").pop()}`, path: p.path }));
    recordDownload(admin, `a pictures backup (${entries.length} files)`);
    return new Response(tarGzStream(entries), {
      headers: {
        "content-type": "application/gzip",
        "content-disposition": `attachment; filename="dealsnap-pictures-${stamp}.tar.gz"`,
        "cache-control": "no-store",
      },
    });
  }

  const kept = new URL(request.url).searchParams.get("file");
  if (kept) {
    const found = serverBackupPath(kept);
    if (!found) return new Response("That backup isn't on the server.", { status: 404 });
    recordDownload(admin, `the daily backup ${kept}`);
    return new Response(fs.readFileSync(found), {
      headers: {
        "content-type": "application/octet-stream",
        "content-disposition": `attachment; filename="${kept}"`,
        "cache-control": "no-store",
      },
    });
  }

  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const file = path.join(os.tmpdir(), `dealsnap-backup-${stamp}-${process.pid}.db`);
  try {
    backupDatabaseTo(file);
    const bytes = fs.readFileSync(file);
    recordDownload(admin, "a full backup");
    return new Response(bytes, {
      headers: {
        "content-type": "application/octet-stream",
        "content-disposition": `attachment; filename="dealsnap-backup-${stamp}.db"`,
        "cache-control": "no-store",
      },
    });
  } finally {
    fs.rmSync(file, { force: true });
  }
}
