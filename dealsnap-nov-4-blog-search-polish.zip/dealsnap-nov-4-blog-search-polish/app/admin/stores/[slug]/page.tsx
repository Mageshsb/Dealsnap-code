import { requirePermission } from "@/lib/auth";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { getAdminDealsView, getAdminStores } from "@/lib/mock-deals";
import {
  renameStoreAction,
  mergeStoreAction,
  unmergeStoreAction,
  uploadStoreLogoAction,
  fetchStoreLogoAction,
  removeStoreLogoAction,
  saveStoreDetailsAction,
  removeStoreAction,
} from "@/lib/admin-actions";
import { STORE_DETAIL_LIMITS, STORE_FACTS, getStoreDetails, getStorePerksByKey } from "@/lib/store-details";
import { DELIVERY_LABEL, DELIVERY_KINDS } from "@/lib/store-perks";
import SelectField from "@/components/SelectField";
import { storeKey } from "@/lib/stores";
import { slugify } from "@/lib/slug";
import { formatDate, getDealStatus } from "@/lib/format";
import { dealPriceTag, priceTagText } from "@/lib/deal-kinds";
import { HERO_NAME } from "@/lib/hero";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import StoreLogo from "@/components/StoreLogo";
import Icon, { HeartIcon } from "@/components/Icon";
import Notice from "@/components/admin/Notice";

export const metadata = { title: "Store" };

const card = "flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900";
const field =
  "rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950";

const STATUS_STYLES = {
  live: "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400",
  pending: "bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  expired: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400",
  removed: "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400",
  featured: "bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400",
  hero: "bg-gradient-to-r from-violet-600 to-fuchsia-600 text-amber-100",
} as const;
const STATUS_LABELS = {
  live: "Live",
  pending: "Pending",
  expired: "Expired",
  removed: "Removed",
  featured: "Featured",
  hero: HERO_NAME,
} as const;

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="flex flex-col gap-0.5 rounded-xl border border-zinc-200 bg-white p-3 sm:gap-1 sm:p-4 dark:border-zinc-800 dark:bg-zinc-900">
      <p className="text-xs font-medium text-zinc-500">{label}</p>
      <p className={`font-bold ${typeof value === "number" ? "text-xl sm:text-2xl" : "text-base leading-8 sm:text-lg"}`}>{value}</p>
    </div>
  );
}

export default async function AdminStorePage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ saved?: string; error?: string }>;
}) {
  await requirePermission("stores.manage");
  const { slug: rawSlug } = await params;
  const { saved, error } = await searchParams;
  const slug = slugify(decodeURIComponent(rawSlug));

  const stores = getAdminStores();
  const store =
    stores.find((s) => s.slug === slug) ?? stores.find((s) => s.key === storeKey(slug.replace(/-/g, " ")));
  if (!store) notFound();
  // Old address after a rename or merge → the store's current one.
  if (store.slug !== rawSlug) redirect(`/admin/stores/${store.slug}`);

  const deals = getAdminDealsView().filter((d) => slugify(d.store) === store.slug);
  const others = stores.filter((s) => s.key !== store.key).sort((a, b) => a.name.localeCompare(b.name));
  const hasPublicPage = store.live + store.expired > 0;
  const details = getStoreDetails(store.key);
  const perks = getStorePerksByKey().get(store.key);
  const savedMessage = { added: "Store added.", "added-no-logo": "Store added. Couldn't find a logo on that website, so upload one below or check the address.", renamed: "Store renamed.", merged: "Stores merged.", unmerged: "Name split out into its own store.", logo: "Logo saved.", "logo-removed": "Logo removed.", details: "Store details saved." }[
    saved ?? ""
  ];

  return (
    <div className="flex flex-col gap-4">
      <Link href="/admin/stores" className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline">
        ← All stores
      </Link>

      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="flex flex-wrap items-center gap-2 text-xl font-bold sm:text-2xl">
            <StoreLogo name={store.name} logoUrl={store.logoUrl} className="h-8 w-8" />
            {store.name}
            {store.isNew && (
              <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-700 dark:bg-amber-950/40 dark:text-amber-400">
                <Icon name="sparkles" className="mr-1.5" />New, awaiting review
              </span>
            )}
          </h1>
          <p className="text-sm text-zinc-500">
            Public page:{" "}
            {hasPublicPage ? (
              <Link href={`/stores/${store.slug}`} target="_blank" className="font-mono text-orange-700 dark:text-orange-400 hover:underline">
                /stores/{store.slug}
              </Link>
            ) : (
              <span className="font-mono">/stores/{store.slug}</span>
            )}
            {!hasPublicPage && " (shows once it has an approved deal)"}
          </p>
        </div>
        <div className="flex gap-3 text-sm font-medium">
          <Link href={`/admin/deals?store=${store.slug}`} className="rounded-full bg-zinc-100 px-3 py-1.5 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700">
            Manage its deals
          </Link>
          {store.pending > 0 && (
            <Link
              href={`/admin/deals?status=pending&store=${store.slug}`}
              className="rounded-full bg-amber-100 px-3 py-1.5 text-amber-800 hover:bg-amber-200 dark:bg-amber-950/40 dark:text-amber-300"
            >
              Review {store.pending} pending
            </Link>
          )}
        </div>
      </div>

      <Notice notice={savedMessage} error={error} />
      {store.gone && (
        <p className="rounded-lg bg-zinc-100 px-4 py-2 text-sm text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300">
          <Icon name="ban" className="mr-1.5" />
          This store has been removed: every deal from it is taken down, so it&apos;s left off the Stores list. Restore a deal below and it comes back.
        </p>
      )}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <Stat label="Live" value={store.live} />
        <Stat label="Pending" value={store.pending} />
        <Stat label="Expired" value={store.expired} />
        <Stat label="Taken down" value={store.removed} />
        <Stat label="Hearts (live)" value={store.hearts} />
        <Stat label="Last posted" value={store.lastPostedAt ? formatDate(store.lastPostedAt) : "—"} />
      </div>

      <form action={renameStoreAction} className={card}>
        <div>
          <h2 className="font-semibold">Name</h2>
          <p className="text-sm text-zinc-500">
            Shown on every deal and in the store&apos;s web address. The old name keeps working: old links redirect, and
            anyone who types it when posting a deal is pointed here.
          </p>
        </div>
        <input type="hidden" name="key" value={store.key} />
        <div className="flex flex-wrap gap-2">
          <input name="name" defaultValue={store.name} required maxLength={60} aria-label="Store name" className={`min-w-[220px] flex-1 ${field}`} />
          <button type="submit" className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
            Save name
          </button>
        </div>
      </form>

      <form action={saveStoreDetailsAction} className={card}>
        <div>
          <h2 className="font-semibold">Store details</h2>
          <p className="text-sm text-zinc-500">
            Shown as chips under the store&apos;s name, with the fuller wording under &ldquo;More&rdquo; and in the
            &ldquo;Questions about {store.name}&rdquo; section (which also helps it show up in Google). Leave a fact&apos;s short
            version empty to hide it.
            {details?.updatedAt && <> Last saved {formatDate(details.updatedAt)}.</>}
          </p>
        </div>
        <input type="hidden" name="key" value={store.key} />
        <label className="flex flex-col gap-1">
          <span className="text-sm font-medium">About {store.name}</span>
          <textarea
            name="about"
            rows={3}
            maxLength={STORE_DETAIL_LIMITS.about}
            defaultValue={details?.about ?? ""}
            placeholder="A sentence or two about the store: what it sells and anything shoppers should know."
            className={`resize-y ${field}`}
          />
        </label>
        <div className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
          {STORE_FACTS.map((f) => {
            const v = details?.facts[f.key];
            return (
              <div key={f.key} className="grid grid-cols-1 gap-2 py-3 first:pt-0 sm:grid-cols-[150px_1fr]">
                <p className="text-sm font-medium sm:pt-2">
                  <span aria-hidden>{f.icon} </span>
                  {f.label}
                </p>
                <div className="flex flex-col gap-2">
                  <input
                    name={`${f.key}_short`}
                    defaultValue={v?.short ?? ""}
                    maxLength={STORE_DETAIL_LIMITS.short}
                    placeholder={`Chip, e.g. "${f.example}"`}
                    aria-label={`${f.label}: short version`}
                    className={field}
                  />
                  <input
                    name={`${f.key}_detail`}
                    defaultValue={v?.detail ?? ""}
                    maxLength={STORE_DETAIL_LIMITS.detail}
                    placeholder="Full sentence (optional): answers the question on the page"
                    aria-label={`${f.label}: full sentence`}
                    className={field}
                  />
                </div>
              </div>
            );
          })}
        </div>
        <div className="flex flex-col gap-3 rounded-lg bg-zinc-50 p-3 dark:bg-zinc-950/50">
          <div>
            <p className="text-sm font-medium">Filters on the Stores page</p>
            <p className="text-sm text-zinc-500">
              Only tick what is true for most orders, and leave it out if you&apos;re unsure. &ldquo;Free, no minimum spend&rdquo; means standard delivery is free on any ordinary order.
              &ldquo;Free over a minimum spend&rdquo; means one fixed amount, the same for everyone. If delivery is always charged, depends on the item or postcode, needs a paid pass, or
              sources disagree, leave it on &ldquo;Not free, or it varies&rdquo;.
            </p>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-[1fr_9rem]">
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Standard delivery</span>
              <SelectField
                look="admin"
                name="perk_delivery"
                label="Standard delivery"
                defaultValue={perks?.delivery ?? ""}
                options={[{ value: "", label: "Not free, or it varies" }, ...DELIVERY_KINDS.map((k) => ({ value: k, label: DELIVERY_LABEL[k] }))]}
              />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Free from (£)</span>
              <input name="perk_min" type="number" inputMode="decimal" min={0} max={1000} step="0.01" defaultValue={perks?.deliveryMin ?? ""} placeholder="e.g. 35" className={field} />
            </label>
          </div>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {[
              ["perk_collect", "Free click & collect", perks?.collect],
              ["perk_returns", "Free returns", perks?.freeReturns],
              ["perk_student", "Student, NHS or key-worker discount", perks?.student],
              ["perk_match", "Price match", perks?.priceMatch],
            ].map(([name, label, on]) => (
              <label key={String(name)} className="flex items-center gap-2 text-sm">
                <input type="checkbox" name={String(name)} value="1" defaultChecked={!!on} className="size-4 accent-orange-500" />
                {label}
              </label>
            ))}
          </div>
        </div>
        <button type="submit" className="self-start rounded-lg bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
          Save details
        </button>
      </form>

      <div className={card}>
        <div>
          <h2 className="font-semibold">Logo</h2>
          <p className="text-sm text-zinc-500">
            Shown at the top of {store.name}&apos;s page in place of the store icon. Fetch it from the store&apos;s
            website, or upload your own (PNG, JPG or WEBP, up to 1MB; square works best).
          </p>
        </div>
        <div className="flex flex-wrap items-start gap-4">
          <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-950">
            <StoreLogo name={store.name} logoUrl={store.logoUrl} className="h-14 w-14" />
          </div>
          <div className="flex min-w-[240px] flex-1 flex-col gap-3">
            <form action={fetchStoreLogoAction} className="flex flex-col gap-1">
              <input type="hidden" name="key" value={store.key} />
              <label htmlFor="website" className="text-sm font-medium">
                Store website
              </label>
              <div className="flex flex-wrap gap-2">
                <input
                  id="website"
                  name="website"
                  defaultValue={store.website ?? ""}
                  placeholder="e.g. currys.co.uk"
                  className={`min-w-[180px] flex-1 ${field}`}
                />
                <button type="submit" className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
                  {store.logoUrl ? "Fetch again" : "Fetch logo"}
                </button>
              </div>
              {store.websiteIsGuess && store.website && (
                <p className="text-xs text-zinc-500">Taken from this store&apos;s deal links. Correct it if it&apos;s wrong.</p>
              )}
            </form>
            <form action={uploadStoreLogoAction} className="flex flex-wrap items-center gap-2">
              <input type="hidden" name="key" value={store.key} />
              <input
                type="file"
                name="logo"
                accept="image/png,image/jpeg,image/webp"
                aria-label="Upload a logo"
                className="min-w-0 flex-1 text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-zinc-100 file:px-3 file:py-2 file:text-sm file:font-medium hover:file:bg-zinc-200 dark:file:bg-zinc-800"
              />
              <button type="submit" className="rounded-lg border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">
                Upload
              </button>
            </form>
            {store.logoUrl && (
              <form action={removeStoreLogoAction}>
                <input type="hidden" name="key" value={store.key} />
                <ConfirmSubmitButton confirmText="Remove this logo? The page goes back to the store icon." className="text-sm font-medium text-red-600 hover:underline">
                  Remove logo
                </ConfirmSubmitButton>
              </form>
            )}
          </div>
        </div>
      </div>

      <div className={card}>
        <div>
          <h2 className="font-semibold">Other names for this store</h2>
          <p className="text-sm text-zinc-500">
            Spellings that all count as {store.name}. Capital letters, &ldquo;UK&rdquo; and &ldquo;.com&rdquo; are
            merged automatically; anything you merge in yourself can be undone here.
          </p>
        </div>
        {store.spellings.length === 0 && store.aliases.length === 0 ? (
          <p className="text-sm text-zinc-500">No other spellings so far.</p>
        ) : (
          <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {store.spellings.map((n) => (
              <li key={`s-${n}`} className="flex items-center justify-between gap-2 py-2 text-sm">
                <span>
                  {n} <span className="text-zinc-500 dark:text-zinc-400">· typed on deals, matched automatically</span>
                </span>
              </li>
            ))}
            {store.aliases.map((a) => (
              <li key={`a-${a.key}`} className="flex items-center justify-between gap-2 py-2 text-sm">
                <span>
                  {a.name} <span className="text-zinc-500 dark:text-zinc-400">· merged by an admin</span>
                </span>
                <form action={unmergeStoreAction}>
                  <input type="hidden" name="aliasKey" value={a.key} />
                  <input type="hidden" name="slug" value={store.slug} />
                  <ConfirmSubmitButton
                    confirmText={`Unmerge "${a.name}"? Deals using that name will go back to being their own store.`}
                    className="text-xs font-medium text-red-600 hover:underline"
                  >
                    Unmerge
                  </ConfirmSubmitButton>
                </form>
              </li>
            ))}
          </ul>
        )}
      </div>

      {others.length > 0 && (
        <form action={mergeStoreAction} className={card}>
          <div>
            <h2 className="font-semibold">Merge into another store</h2>
            <p className="text-sm text-zinc-500">
              For when two names are really the same store. {store.name}&apos;s {store.total} deal
              {store.total === 1 ? "" : "s"} will show under the store you pick, and this page will redirect to it.
            </p>
          </div>
          <input type="hidden" name="fromKey" value={store.key} />
          <div className="flex flex-wrap gap-2">
            <SelectField
              look="admin"
              name="intoKey"
              label="Store to merge into"
              required
              placeholder="Choose a store…"
              options={others.map((s) => ({ value: s.key, label: `${s.name} (${s.total})` }))}
              className="min-w-[220px] flex-1"
            />
            <ConfirmSubmitButton
              confirmText={`Merge "${store.name}" into the store you picked? All ${store.total} of its deals will show under that store's name.`}
              className="rounded-lg border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
            >
              Merge
            </ConfirmSubmitButton>
          </div>
        </form>
      )}

      <div className="flex flex-col gap-2">
        <h2 className="font-semibold">Deals from {store.name}</h2>
        <div className="rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
          <table className="block w-full text-left text-sm lg:table">
            <thead className="hidden border-b border-zinc-200 bg-zinc-50 text-xs uppercase text-zinc-500 lg:table-header-group dark:border-zinc-800 dark:bg-zinc-950/40">
              <tr>
                <th className="rounded-tl-xl px-4 py-2.5 font-medium">Deal</th>
                <th className="px-3 py-2.5 font-medium">Price</th>
                <th className="px-3 py-2.5 font-medium">Hearts</th>
                <th className="px-3 py-2.5 font-medium">Posted</th>
                <th className="px-3 py-2.5 font-medium">Status</th>
                <th className="rounded-tr-xl px-4 py-2.5" />
              </tr>
            </thead>
            <tbody className="block divide-y divide-zinc-100 lg:table-row-group dark:divide-zinc-800">
              {deals.slice(0, 15).map((d) => {
                const status = getDealStatus(d);
                const badge = (
                  <span className={`inline-block rounded-full px-2 py-0.5 text-xs font-medium whitespace-nowrap ${STATUS_STYLES[status]}`}>
                    {status === "featured" && <Icon name="star" filled className="mr-1" />}
                    {status === "hero" && <Icon name="crown" filled className="mr-1" />}
                    {STATUS_LABELS[status]}
                  </span>
                );
                return (
                  <tr key={`${d.source}-${d.id}`} className="block px-4 py-3 lg:table-row lg:p-0">
                    <td className="block lg:table-cell lg:w-[44%] lg:px-4 lg:py-3 lg:align-top">
                      <Link href={`/deals/${d.slug}`} target="_blank" className="line-clamp-2 font-medium hover:underline">
                        {d.title}
                      </Link>
                      <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-zinc-500 lg:hidden">
                        {badge}
                        <span>{priceTagText(dealPriceTag(d))}</span>
                        <span><HeartIcon className="mr-1" />{d.hearts}</span>
                        <span>{formatDate(d.postedAt)}</span>
                      </div>
                    </td>
                    <td className="hidden px-3 py-3 align-top whitespace-nowrap text-zinc-600 tabular-nums lg:table-cell dark:text-zinc-400">
                      {priceTagText(dealPriceTag(d))}
                    </td>
                    <td className="hidden px-3 py-3 align-top whitespace-nowrap text-zinc-500 tabular-nums lg:table-cell"><HeartIcon className="mr-1" />{d.hearts}</td>
                    <td className="hidden px-3 py-3 align-top whitespace-nowrap text-zinc-500 lg:table-cell">{formatDate(d.postedAt)}</td>
                    <td className="hidden px-3 py-3 align-top lg:table-cell">{badge}</td>
                    <td className="block lg:table-cell lg:px-4 lg:py-3 lg:text-right lg:align-top">
                      {d.source === "user" && (
                        <Link
                          href={`/admin/deals/${d.dbId}/edit`}
                          className="mt-3 inline-flex min-h-[36px] items-center rounded-lg border border-zinc-300 px-3.5 py-1.5 text-xs font-medium hover:bg-zinc-100 lg:mt-0 dark:border-zinc-700 dark:hover:bg-zinc-800"
                        >
                          Edit
                        </Link>
                      )}
                    </td>
                  </tr>
                );
              })}
              {deals.length === 0 && (
                <tr className="block lg:table-row">
                  <td colSpan={6} className="block px-4 py-6 text-center text-zinc-500 lg:table-cell">
                    No deals yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        {deals.length > 15 && (
          <Link href={`/admin/deals?store=${store.slug}`} className="text-sm font-medium text-orange-700 dark:text-orange-400 hover:underline">
            See all {deals.length} deals →
          </Link>
        )}
      </div>

      {!store.gone && (
        <form action={removeStoreAction} className={card}>
          <input type="hidden" name="key" value={store.key} />
          <div>
            <h2 className="font-semibold">Remove this store</h2>
            <p className="text-sm text-zinc-500">
              {deals.length === 0
                ? "It has no deals, so it can just be deleted, along with its logo and details."
                : `This takes down all ${store.live + store.pending + store.expired} of its deals the same way the Deals page does (each poster is told, and each is in the activity log) and leaves the store off the lists. Restore any deal and the store comes back. To keep the deals, merge the store into another one instead.`}
            </p>
          </div>
          <div>
            <ConfirmSubmitButton
              confirmText={
                deals.length === 0
                  ? `Delete ${store.name}? Its logo and details go too.`
                  : `Remove ${store.name}? Its ${store.live + store.pending + store.expired} deal${store.live + store.pending + store.expired === 1 ? "" : "s"} will be taken down and their posters told.`
              }
              confirmLabel={deals.length === 0 ? "Yes, delete it" : "Yes, remove it"}
              className="rounded-lg border border-red-300 px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/40"
            >
              {deals.length === 0 ? "Delete store" : "Remove store and take down its deals"}
            </ConfirmSubmitButton>
          </div>
        </form>
      )}
    </div>
  );
}
