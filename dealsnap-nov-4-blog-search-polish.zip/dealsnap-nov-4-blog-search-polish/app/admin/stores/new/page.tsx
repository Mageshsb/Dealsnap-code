import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { addStoreAction } from "@/lib/admin-actions";
import Notice from "@/components/admin/Notice";
import { field, hint, label, panel } from "@/components/admin/formStyles";

export const metadata = { title: "Add a store" };

// Admin → Stores → Add a store: a store you want ready before anyone posts a
// deal from it. It's offered on the post form at once, and gets its own page
// when its first deal goes live. With a website, its logo is fetched for you.
export default async function AdminNewStorePage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  await requirePermission("stores.manage");
  const { error } = await searchParams;
  return (
    <div className="flex max-w-2xl flex-col gap-4">
      <Link href="/admin/stores" className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline">
        ← Stores
      </Link>
      <div>
        <h1 className="text-xl font-bold sm:text-2xl">Add a store</h1>
        <p className="text-sm text-zinc-500">
          Offered on the post form straight away. It gets a public page when its first deal goes live.
        </p>
      </div>
      <Notice error={error} />
      <form action={addStoreAction} className={panel}>
        <label className={label}>
          Name
          <input name="name" required maxLength={60} placeholder="e.g. Currys" className={field} />
        </label>
        <label className={label}>
          Website (optional)
          <input name="website" placeholder="e.g. currys.co.uk" className={field} />
          <span className={hint}>Where its logo is fetched from. You can set or change it later.</span>
        </label>
        <div>
          <button className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600">Add store</button>
        </div>
      </form>
    </div>
  );
}
