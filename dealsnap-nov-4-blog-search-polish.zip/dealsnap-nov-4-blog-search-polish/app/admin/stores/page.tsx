import { requirePermission } from "@/lib/auth";
import Link from "next/link";
import SelectField from "@/components/SelectField";
import { getAdminStores, getStoreDuplicateSuggestions, type AdminStore } from "@/lib/mock-deals";
import { mergeStoreAction, fetchMissingStoreLogosAction } from "@/lib/admin-actions";
import Notice from "@/components/admin/Notice";
import ListHeader from "@/components/admin/ListHeader";
import { formatDate } from "@/lib/format";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import StoreLogo from "@/components/StoreLogo";
import Icon, { HeartIcon } from "@/components/Icon";
import { SEARCH_MAX } from "@/lib/search-limits";
import Pager from "@/components/admin/Pager";
import { searchField } from "@/components/admin/formStyles";

export const metadata = { title: "Stores" };

const PAGE_SIZE = 25;

const SORTS = {
  live: "Most live deals",
  az: "A–Z",
  hearts: "Most hearts",
  pending: "Most pending",
  recent: "Recently posted",
} as const;
type SortKey = keyof typeof SORTS;

const FILTERS = {
  all: "All stores",
  new: "New (awaiting review)",
  pending: "Has pending deals",
  nolive: "No live deals",
  merged: "Merged / renamed",
  nologo: "No logo",
  nosite: "No website set",
} as const;
type FilterKey = keyof typeof FILTERS;

function sortStores(stores: AdminStore[], sort: SortKey) {
  const byName = (a: AdminStore, b: AdminStore) => a.name.localeCompare(b.name);
  const sorted = [...stores];
  switch (sort) {
    case "az":
      return sorted.sort(byName);
    case "hearts":
      return sorted.sort((a, b) => b.hearts - a.hearts || byName(a, b));
    case "pending":
      return sorted.sort((a, b) => b.pending - a.pending || byName(a, b));
    case "recent":
      return sorted.sort((a, b) => (b.lastPostedAt ?? "").localeCompare(a.lastPostedAt ?? "") || byName(a, b));
    case "live":
    default:
      return sorted.sort((a, b) => b.live - a.live || byName(a, b));
  }
}

function StatCard({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="flex flex-col gap-1 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
      <p className="text-xs font-medium text-zinc-500">{label}</p>
      <p className="text-2xl font-bold">{value}</p>
    </div>
  );
}

const panel = "rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900";
export default async function AdminStoresPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; filter?: string; sort?: string; page?: string; saved?: string; notice?: string; error?: string }>;
}) {
  await requirePermission("stores.manage");
  const { q = "", filter: filterParam, sort: sortParam, page: pageParam, saved, notice, error } = await searchParams;
  const filter: FilterKey = filterParam && filterParam in FILTERS ? (filterParam as FilterKey) : "all";
  const sort: SortKey = sortParam && sortParam in SORTS ? (sortParam as SortKey) : "live";
  const page = Math.max(1, parseInt(pageParam ?? "1", 10) || 1);

  // Stores whose deals have all been taken down are left off.
  const all = getAdminStores().filter((s) => !s.gone);
  const duplicates = getStoreDuplicateSuggestions(all);
  const newStores = all.filter((s) => s.isNew);
  const missingLogos = all.filter((s) => !s.logoUrl && s.live + s.expired > 0).length;
  const mergedNames = all.reduce((n, s) => n + s.aliases.length, 0);

  let stores = all;
  if (q.trim()) {
    const needle = q.trim().toLowerCase();
    stores = stores.filter(
      (s) =>
        s.name.toLowerCase().includes(needle) ||
        s.spellings.some((n) => n.toLowerCase().includes(needle)) ||
        s.aliases.some((a) => a.name.toLowerCase().includes(needle))
    );
  }
  if (filter === "new") stores = stores.filter((s) => s.isNew);
  if (filter === "pending") stores = stores.filter((s) => s.pending > 0);
  if (filter === "nolive") stores = stores.filter((s) => s.live === 0);
  if (filter === "merged") stores = stores.filter((s) => s.aliases.length > 0 || s.nameChosen);
  if (filter === "nologo") stores = stores.filter((s) => !s.logoUrl);
  // A website only guessed from deal links counts as not set: worth confirming.
  if (filter === "nosite") stores = stores.filter((s) => !s.website || s.websiteIsGuess);
  stores = sortStores(stores, sort);

  const total = stores.length;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const pageStores = stores.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  function pageHref(target: number) {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (filter !== "all") params.set("filter", filter);
    if (sort !== "live") params.set("sort", sort);
    params.set("page", String(target));
    return `/admin/stores?${params.toString()}`;
  }
  const hasFilters = q || filter !== "all" || sort !== "live";

  return (
    <div className="flex flex-col gap-4">
      <ListHeader
        title="Stores"
        count={total}
        noun="store"
        filtered={Boolean(hasFilters)}
        clearHref="/admin/stores"
        intro={<>Every store your deals come from. Spellings like &ldquo;Amazon&rdquo; and &ldquo;Amazon UK&rdquo; are already treated as one store; rename or merge anything else here.</>}
        aside={
          <Link href="/admin/stores/new" className="rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
            + Add a store
          </Link>
        }
      />

      <Notice notice={saved || notice ? (notice ?? "Saved.") : undefined} error={error} />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="Stores" value={all.length} />
        <StatCard label="With live deals" value={all.filter((s) => s.live > 0).length} />
        <StatCard label="New, awaiting review" value={newStores.length} />
        <StatCard label="Merged names" value={mergedNames} />
      </div>

      {missingLogos > 0 && (
        <form action={fetchMissingStoreLogosAction} className={`flex flex-wrap items-center justify-between gap-3 ${panel}`}>
          <p className="text-sm text-zinc-600 dark:text-zinc-400">
            <Icon name="image" className="mr-1.5" />{missingLogos} store{missingLogos === 1 ? " has" : "s have"} no logo yet. Fetch them from the stores&apos; own websites in one go.
          </p>
          <button type="submit" className="col-span-2 min-h-[42px] rounded-lg bg-orange-500 px-5 py-2 text-sm font-semibold sm:col-auto text-white hover:bg-orange-600">
            Fetch missing logos
          </button>
        </form>
      )}

      {newStores.length > 0 && (
        <div className="flex items-center justify-between gap-3 rounded-xl border border-orange-300 bg-orange-50 px-4 py-3 text-sm text-orange-800 dark:border-orange-900 dark:bg-orange-950/40 dark:text-orange-300">
          <span>
            <Icon name="sparkles" className="mr-1.5" />{newStores.length} new store{newStores.length === 1 ? "" : "s"} first seen on a pending deal (
            {newStores
              .slice(0, 4)
              .map((s) => s.name)
              .join(", ")}
            {newStores.length > 4 ? "…" : ""}). Check {newStores.length === 1 ? "it isn't" : "they aren't"} a
            duplicate spelling.
          </span>
          <Link href="/admin/stores?filter=new" className="shrink-0 font-semibold underline">
            Review
          </Link>
        </div>
      )}

      <div className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
        <div>
          <h2 className="font-semibold">Possible duplicates</h2>
          <p className="text-sm text-zinc-500">
            Stores whose names overlap. Merging puts the smaller one under the bigger one&apos;s name and sends its
            page there. You can undo it later.
          </p>
        </div>
        {duplicates.length === 0 ? (
          <p className="text-sm text-green-700 dark:text-green-400"><Icon name="circle-check" className="mr-1.5" />No likely duplicates found.</p>
        ) : (
          <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {duplicates.map(({ from, into }) => (
              <li key={`${from.key}-${into.key}`} className="flex flex-wrap items-center justify-between gap-2 py-2 text-sm">
                <span>
                  <Link href={`/admin/stores/${from.slug}`} className="font-medium hover:underline">
                    {from.name}
                  </Link>{" "}
                  <span className="text-zinc-500 dark:text-zinc-400">({from.total})</span>
                  <span className="mx-2 text-zinc-500 dark:text-zinc-400">→</span>
                  <Link href={`/admin/stores/${into.slug}`} className="font-medium hover:underline">
                    {into.name}
                  </Link>{" "}
                  <span className="text-zinc-500 dark:text-zinc-400">({into.total})</span>
                </span>
                <form action={mergeStoreAction}>
                  <input type="hidden" name="fromKey" value={from.key} />
                  <input type="hidden" name="intoKey" value={into.key} />
                  <ConfirmSubmitButton
                    confirmText={`Merge "${from.name}" into "${into.name}"? Its ${from.total} deal${from.total === 1 ? "" : "s"} will show as ${into.name}.`}
                    className="rounded-lg bg-orange-500 px-3 py-1.5 text-xs font-semibold text-white hover:bg-orange-600"
                  >
                    Merge into {into.name}
                  </ConfirmSubmitButton>
                </form>
              </li>
            ))}
          </ul>
        )}
      </div>

      <form className="grid grid-cols-2 items-center gap-2 sm:flex sm:flex-wrap" action="/admin/stores">
        <input type="search"
          aria-label="Search this list" name="q" defaultValue={q} maxLength={SEARCH_MAX} placeholder="Search stores or old names…" className={`col-span-2 min-w-[180px] sm:col-span-1 sm:flex-1 ${searchField}`} />
        <SelectField
          look="admin"
          name="filter"
          label="Show"
          defaultValue={filter}
          options={Object.entries(FILTERS).map(([key, label]) => ({ value: key, label }))}
        />
        <SelectField
          look="admin"
          name="sort"
          label="Sort by"
          defaultValue={sort}
          leadingIcon="arrow-up-down"
          options={Object.entries(SORTS).map(([key, label]) => ({ value: key, label }))}
        />
        <button type="submit" className="col-span-2 min-h-[42px] rounded-lg bg-orange-500 px-5 py-2 text-sm font-semibold sm:col-auto text-white hover:bg-orange-600">
          Apply
        </button>
      </form>
      <div className="rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
        <table className="block w-full text-left text-sm">
          <tbody className="block divide-y divide-zinc-100 dark:divide-zinc-800">
            {pageStores.map((s) => {
              const others = [...s.spellings, ...s.aliases.map((a) => a.name)];
              const pendingEl =
                s.pending > 0 ? (
                  <Link
                    href={`/admin/deals?status=pending&store=${s.slug}`}
                    className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-700 hover:underline dark:bg-amber-950/40 dark:text-amber-400"
                  >
                    {s.pending}
                  </Link>
                ) : (
                  <span className="text-zinc-500 dark:text-zinc-400">—</span>
                );
              return (
                <tr key={s.key} className="block px-4 py-3 sm:flex sm:items-start sm:justify-between sm:gap-4">
                  <td className="block sm:min-w-0 sm:flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <StoreLogo name={s.name} logoUrl={s.logoUrl} className="h-5 w-5" />
                      <Link href={`/admin/stores/${s.slug}`} className="font-medium hover:underline">
                        {s.name}
                      </Link>
                      {s.isNew && (
                        <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-medium text-amber-700 dark:bg-amber-950/40 dark:text-amber-400">
                          <Icon name="sparkles" className="mr-1.5" />New
                        </span>
                      )}
                      {s.added && s.total === 0 && (
                        <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-[11px] font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">
                          <Icon name="plus" className="mr-1.5" />Added by you · no deals yet
                        </span>
                      )}
                      {s.nameChosen && !(s.added && s.total === 0) && (
                        <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-[11px] font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">
                          <Icon name="pencil" className="mr-1.5" />Named by you
                        </span>
                      )}
                    </div>
                    {others.length > 0 && (
                      <p className="mt-0.5 line-clamp-2 text-xs text-zinc-500" title={others.join(", ")}>
                        Also: {others.join(", ")}
                      </p>
                    )}
                    <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-zinc-500">
                      <span>
                        <b className="font-semibold text-zinc-700 dark:text-zinc-300">{s.live}</b> live
                      </span>
                      {s.pending > 0 && <span className="inline-flex items-center gap-1">{pendingEl} pending</span>}
                      {s.expired > 0 && <span>{s.expired} expired</span>}
                      {s.removed > 0 && <span>{s.removed} taken down</span>}
                      <span><HeartIcon className="mr-1" />{s.hearts}</span>
                      {s.lastPostedAt && <span>Last posted {formatDate(s.lastPostedAt)}</span>}
                    </div>
                  </td>
                  <td className="block pt-3 sm:shrink-0 sm:pt-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <Link
                        href={`/admin/stores/${s.slug}`}
                        className="inline-flex min-h-[36px] items-center rounded-lg border border-zinc-300 px-3.5 py-1.5 text-xs font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
                      >
                        Manage
                      </Link>
                      <Link
                        href={`/admin/deals?store=${s.slug}`}
                        className="inline-flex min-h-[36px] items-center px-1.5 text-xs font-medium whitespace-nowrap text-zinc-600 hover:underline dark:text-zinc-400"
                      >
                        Deals
                      </Link>
                      {s.live + s.expired > 0 && (
                        <Link
                          href={`/stores/${s.slug}`}
                          target="_blank"
                          className="inline-flex min-h-[36px] items-center px-1.5 text-xs font-medium whitespace-nowrap text-zinc-600 hover:underline dark:text-zinc-400"
                        >
                          View ↗
                        </Link>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
            {pageStores.length === 0 && (
              <tr className="block">
                <td colSpan={8} className="block px-4 py-8 text-center text-zinc-500">
                  No stores match these filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Pager page={page} totalPages={totalPages} href={pageHref} />
    </div>
  );
}
