import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { teamMember } from "@/lib/community-access";
import { UNANSWERED_AFTER_HOURS } from "@/lib/community-rules";
import { getCommunityOverview, getCommunitySettings, getModerationQueue, getOpeningPost, listHeldThreads, listMutes, listRemovedThreads, listUnansweredOlderThan } from "@/lib/community-db";
import { mayManageAccount } from "@/lib/permissions";
import { timeAgo } from "@/lib/format";
import { HeldThreadActions, QueuePostActions, RemovedThreadActions, UnmuteButton } from "@/components/admin/CommunityQueue";
import CommunityTabs from "@/components/admin/CommunityTabs";
import { panel, panelTitle } from "@/components/admin/formStyles";
import EmptyState from "@/components/EmptyState";
import Icon from "@/components/Icon";

export const metadata = { title: "Community" };

function Tile({ label, value, hint }: { label: string; value: number; hint?: string }) {
  return (
    <div className="flex flex-col gap-0.5 rounded-xl border border-zinc-200 bg-white p-3 dark:border-zinc-800 dark:bg-zinc-900">
      <span className="text-2xl font-bold tabular-nums">{value.toLocaleString("en-GB")}</span>
      <span className="text-xs text-zinc-500">{label}</span>
      {hint && <span className="text-[11px] text-zinc-500 dark:text-zinc-400">{hint}</span>}
    </div>
  );
}

export default async function AdminCommunity() {
  const user = await requirePermission("forum.moderate");
  const canManage = can(user.role, "forum.manage");
  const settings = getCommunitySettings();
  const o = getCommunityOverview();
  const queue = getModerationQueue();
  const held = listHeldThreads();
  const mutes = listMutes();
  const removed = listRemovedThreads();
  const canDelete = teamMember(user, "forum.delete");
  const lonely = listUnansweredOlderThan(UNANSWERED_AFTER_HOURS, 8);
  const mayMute = teamMember(user, "forum.moderate");

  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-xl font-bold sm:text-2xl">Community</h1>
        <p className="mt-1 text-sm text-zinc-500">
          What needs a person, and how it&apos;s going.{" "}
          <Link href="/community" className="font-medium text-orange-700 hover:underline dark:text-orange-400">
            Open the Community
          </Link>
        </p>
      </div>
      <CommunityTabs current="overview" canManage={canManage} />

      {!settings.on && (
        <p className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5 text-sm text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/20 dark:text-amber-200">
          The Community is switched off, so visitors can&apos;t see it.{canManage && <> Turn it on under Limits.</>}
        </p>
      )}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Tile label="New threads this week" value={o.threadsWeek} />
        <Tile label="Replies this week" value={o.repliesWeek} />
        <Tile label="Members posting this week" value={o.membersPostingWeek} />
        <Tile label="Threads, all time" value={o.threadsTotal} hint={`${o.postsTotal.toLocaleString("en-GB")} posts`} />
      </div>

      {held.length > 0 && (
        <section className={panel} aria-labelledby="held">
          <h2 id="held" className={panelTitle}>
            First threads waiting for a check ({held.length})
          </h2>
          <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {held.map((t) => {
              const opening = getOpeningPost(t.id);
              return (
                <li key={t.id} className="flex flex-col gap-2 py-3 first:pt-0 last:pb-0">
                  <p className="text-sm">
                    <Link href={`/community/t/${t.slug}`} className="font-semibold hover:underline">
                      {t.title}
                    </Link>
                    <span className="text-zinc-500">
                      {" "}
                      · {t.username} · {t.spaceName} · {timeAgo(t.createdAt)}
                    </span>
                  </p>
                  {opening && <p className="line-clamp-4 whitespace-pre-line text-sm text-zinc-600 [overflow-wrap:anywhere] dark:text-zinc-400">{opening.text}</p>}
                  {opening && <HeldThreadActions threadId={t.id} postId={opening.id} />}
                </li>
              );
            })}
          </ul>
        </section>
      )}

      <section className={panel} aria-labelledby="queue">
        <h2 id="queue" className={panelTitle}>
          Reported and hidden posts ({queue.length})
        </h2>
        {queue.length === 0 ? (
          <EmptyState icon="circle-check" boxed={false}>
            Nothing waiting. Reports and anything a helper hides will appear here.
          </EmptyState>
        ) : (
          <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {queue.map((q) => (
              <li key={q.postId} className="flex flex-col gap-2 py-3 first:pt-0 last:pb-0">
                <p className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm">
                  <Link href={`/admin/users/${q.userId}`} className="font-semibold hover:underline">
                    {q.username}
                  </Link>
                  {q.status === "hidden" && <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">Hidden by a helper</span>}
                  {q.reports > 0 && (
                    <span className="rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700 dark:bg-red-950/40 dark:text-red-400">
                      <Icon name="flag" className="mr-1" />
                      {q.reports} report{q.reports === 1 ? "" : "s"}
                    </span>
                  )}
                  <span className="text-zinc-500">· {timeAgo(q.createdAt)} ·</span>
                  <Link href={`/community/t/${q.threadSlug}#post-${q.seq}`} className="min-w-0 truncate text-orange-700 hover:underline dark:text-orange-400">
                    {q.threadTitle}
                  </Link>
                </p>
                <p className="line-clamp-6 whitespace-pre-line text-sm text-zinc-700 [overflow-wrap:anywhere] dark:text-zinc-300">{q.text}</p>
                <QueuePostActions postId={q.postId} userId={q.userId} canMute={mayMute && mayManageAccount(user.role, q.role) && q.userId !== user.id} />
              </li>
            ))}
          </ul>
        )}
      </section>

      {removed.length > 0 && (
        <section className={panel} aria-labelledby="removed">
          <h2 id="removed" className={panelTitle}>
            Removed threads ({removed.length})
          </h2>
          <p className="text-sm text-zinc-500">
            Hidden from everyone but moderators and easy to bring back.{canDelete ? " Deleting one permanently also deletes its replies and can't be undone." : " Only an owner can delete one permanently."}
          </p>
          <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {removed.map((t) => (
              <li key={t.id} className="flex flex-col gap-2 py-3 first:pt-0 last:pb-0">
                <p className="text-sm">
                  <Link href={`/community/t/${t.slug}`} className="font-semibold hover:underline">
                    {t.title}
                  </Link>
                  <span className="text-zinc-500">
                    {" "}
                    · {t.username} · {t.spaceName} · {t.lastSeq} {t.lastSeq === 1 ? "post" : "posts"}
                  </span>
                </p>
                <RemovedThreadActions threadId={t.id} posts={t.lastSeq} canDelete={canDelete} />
              </li>
            ))}
          </ul>
        </section>
      )}

      {mutes.length > 0 && (
        <section className={panel} aria-labelledby="mutes">
          <h2 id="mutes" className={panelTitle}>
            Muted from the Community ({mutes.length})
          </h2>
          <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {mutes.map((m) => (
              <li key={m.userId} className="flex flex-wrap items-center justify-between gap-2 py-2.5 first:pt-0 last:pb-0">
                <p className="min-w-0 text-sm">
                  <span className="font-semibold">{m.username}</span>
                  <span className="text-zinc-500">
                    {" "}
                    · until {new Date(m.until).toLocaleDateString("en-GB", { day: "numeric", month: "short" })} · by {m.by}
                    {m.reason ? ` · ${m.reason}` : ""}
                  </span>
                </p>
                <UnmuteButton userId={m.userId} />
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className={panel} aria-labelledby="lonely">
        <h2 id="lonely" className={panelTitle}>
          No reply yet ({o.noReplyYet} this week)
        </h2>
        <p className="text-sm text-zinc-500">
          Threads a day old with no reply. A first reply from a helper is the best welcome a new member can get, and it&apos;s the biggest reason they come back.
        </p>
        {lonely.length === 0 ? (
          <p className="text-sm text-zinc-500 dark:text-zinc-400">Every thread has had a reply. Nicely done.</p>
        ) : (
          <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {lonely.map((t) => (
              <li key={t.id} className="flex min-w-0 items-baseline justify-between gap-3 py-2 text-sm first:pt-0 last:pb-0">
                <Link href={`/community/t/${t.slug}`} className="min-w-0 truncate font-medium hover:underline">
                  {t.title}
                </Link>
                <span className="shrink-0 text-xs text-zinc-500">
                  {t.username} · {timeAgo(t.createdAt)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
