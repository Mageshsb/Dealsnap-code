import { requirePermission } from "@/lib/auth";
import { getCommunitySettings } from "@/lib/community-db";
import CommunityLimits from "@/components/admin/CommunityLimits";
import CommunityTabs from "@/components/admin/CommunityTabs";

export const metadata = { title: "Community limits" };

export default async function AdminCommunityLimits() {
  await requirePermission("forum.manage");
  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-xl font-bold sm:text-2xl">Community</h1>
        <p className="mt-1 text-sm text-zinc-500">The switch, the limits for new members, and the word filter.</p>
      </div>
      <CommunityTabs current="limits" canManage />
      <CommunityLimits s={getCommunitySettings()} />
    </div>
  );
}
