import { requirePermission } from "@/lib/auth";
import { getSpaceStats, listSpaces } from "@/lib/community-db";
import { AddSpace, SpaceControls, SpaceForm } from "@/components/admin/SpaceForm";
import CommunityTabs from "@/components/admin/CommunityTabs";
import WelcomeThreads from "@/components/admin/WelcomeThreads";
import { panel } from "@/components/admin/formStyles";
import Icon from "@/components/Icon";

import Notice from "@/components/admin/Notice";
export const metadata = { title: "Community spaces" };

export default async function AdminSpaces({ searchParams }: { searchParams: Promise<{ notice?: string; error?: string }> }) {
  const admin = await requirePermission("forum.manage");
  const { notice, error } = await searchParams;
  const spaces = listSpaces(true);
  const stats = getSpaceStats();
  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-xl font-bold sm:text-2xl">Community</h1>
        <p className="mt-1 text-sm text-zinc-500">The places conversations live, in the order members see them. About eight is plenty: more makes each one feel empty.</p>
      </div>
      <CommunityTabs current="spaces" canManage />
      <Notice notice={notice} error={error} />
      <AddSpace />
      <ul className="flex flex-col gap-3">
        {spaces.map((s, i) => {
          const threads = stats.get(s.id)?.threads ?? 0;
          return (
            <li key={s.id} className={`${panel} ${s.archived ? "opacity-70" : ""}`}>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="flex min-w-0 items-center gap-2.5">
                  <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400">
                    <Icon name={s.icon} className="size-5" />
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate font-semibold">{s.name}</span>
                    <span className="block text-xs text-zinc-500">
                      {threads} {threads === 1 ? "thread" : "threads"}
                      {s.kind === "ask" && " · questions"}
                      {s.who === "staff" && " · team only"}
                      {s.archived && " · archived"}
                    </span>
                  </span>
                </p>
                <SpaceControls space={s} first={i === 0} last={i === spaces.length - 1} threads={threads} />
              </div>
              <details className="group">
                <summary className="flex min-h-9 cursor-pointer list-none items-center gap-1 text-sm font-medium text-orange-700 dark:text-orange-400">
                  Edit
                  <Icon name="chevron-down" className="size-4 transition-transform group-open:rotate-180" />
                </summary>
                <div className="pt-3">
                  <SpaceForm space={s} />
                </div>
              </details>
            </li>
          );
        })}
      </ul>
      <WelcomeThreads spaces={spaces} who={admin.username} />
    </div>
  );
}
