import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getAdminDealsView } from "@/lib/mock-deals";
import { getDealStatus, formatDate, timeAgo } from "@/lib/format";
import { BOT_USERNAME, DAILY_CAP_MAX, botAccount, getEngineSettings } from "@/lib/engine";
import { revokeEngineKeyAction, saveEngineRulesAction, setEnginePausedAction, setUpBotAction } from "@/lib/engine-actions";
import AccountSection from "@/components/AccountSection";
import { AccountPageHeader } from "@/components/AccountShell";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import EngineKeyButton from "@/components/admin/EngineKeyButton";
import Icon from "@/components/Icon";
import { Checkbox, hint, input, outlineButton, saveButton } from "../settings/ui";

import Notice from "@/components/admin/Notice";
export const metadata = { title: "Deal engine" };

// Admin → Deal engine: the controls for the cofounders' deal engine, ready
// before it connects (lib/engine.ts). Admins only.

const STATUS_LABEL: Record<string, string> = { live: "Live", pending: "Waiting for review", removed: "Taken down", expired: "Ended" };

function postedToday(deals: { postedAt: string }[]): number {
  const today = new Date().toISOString().slice(0, 10);
  return deals.filter((d) => d.postedAt.slice(0, 10) === today).length;
}

export default async function AdminEnginePage({ searchParams }: { searchParams: Promise<{ saved?: string; note?: string; error?: string }> }) {
  await requirePermission("settings.manage");
  const params = await searchParams;
  const engine = getEngineSettings();
  const bot = botAccount();
  const posted = bot ? getAdminDealsView().filter((d) => d.postedByUserId === bot.id) : [];
  const today = postedToday(posted);
  const ready = { key: !!engine.key, bot: !!bot, address: !!engine.lookupUrl };

  return (
    <div className="flex max-w-2xl flex-col gap-5">
      <AccountPageHeader
        title="Deal engine"
        description="The engine collects every store's products and price history, spots good deals and posts them here as a bot. These are its controls, ready before it connects."
      />

      <Notice notice={params.saved ? "Saved." : params.note} error={params.error} />

      <AccountSection
        icon="bot"
        title="Status"
        aside={
          <span
            className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
              engine.paused ? "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300" : "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400"
            }`}
          >
            {engine.paused ? "Paused" : "On"}
          </span>
        }
      >
        <p className="text-sm text-zinc-600 dark:text-zinc-400">
          <Icon name="hourglass" className="mr-1.5 text-zinc-500 dark:text-zinc-400" />
          <span className="font-medium">Not connected yet.</span> The engine is still being built. Once its side is agreed (see
          Linear JBM-65), it posts here with its key, and the post form asks it about pasted links.
        </p>
        <ul className="flex flex-col gap-1.5 text-sm">
          {[
            [ready.bot, "Bot account set up"],
            [ready.key, "Engine key made"],
            [ready.address, "Engine's address added"],
          ].map(([done, label]) => (
            <li key={label as string} className="flex items-center gap-2">
              <Icon name={done ? "circle-check" : "circle"} className={`size-4 ${done ? "text-emerald-700" : "text-zinc-300 dark:text-zinc-600"}`} />
              <span className={done ? "" : "text-zinc-500"}>{label}</span>
            </li>
          ))}
        </ul>
        <form action={setEnginePausedAction} className="flex flex-wrap items-center gap-3">
          <input type="hidden" name="turn" value={engine.paused ? "run" : "pause"} />
          <button type="submit" className={engine.paused ? saveButton : "self-start rounded-full bg-red-600 px-5 py-2 text-sm font-semibold text-white hover:bg-red-700"}>
            {engine.paused ? "Turn posting on" : "Pause posting now"}
          </button>
          <span className={hint}>
            {engine.paused ? "While paused, the engine can't post anything." : "Pausing stops it at once; deals already up stay up."}
          </span>
        </form>
      </AccountSection>

      <AccountSection icon="settings" title="Rules for engine deals" description="The engine's deals get the same hearts and ranking as everyone's: no boost.">
        <form action={saveEngineRulesAction} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1">
            <label htmlFor="dailyCap" className="text-sm font-medium">Most deals it can post in a day</label>
            <input id="dailyCap" name="dailyCap" type="number" min={0} max={DAILY_CAP_MAX} defaultValue={engine.dailyCap} className={`${input} max-w-[10rem]`} />
            <p className={hint}>So members&apos; own posts are never drowned out. {bot && `Posted today: ${today}.`}</p>
          </div>
          <Checkbox name="reviewFirst" defaultChecked={engine.reviewFirst}>
            <span className="font-medium">Check each one before it goes live</span>
            <span className="block text-xs text-zinc-500">
              Its deals wait in Admin → Deals for a quick look, as a new member&apos;s do. Worth keeping on for the first weeks.
            </span>
          </Checkbox>
          <div className="flex flex-col gap-1">
            <label htmlFor="lookupUrl" className="text-sm font-medium">
              The engine&apos;s address for product lookups <span className="font-normal text-zinc-500 dark:text-zinc-400">(when it&apos;s ready)</span>
            </label>
            <input id="lookupUrl" name="lookupUrl" type="url" defaultValue={engine.lookupUrl} placeholder="https://engine.example.com/lookup" className={input} />
            <p className={hint}>
              Where the post form will ask &ldquo;what&apos;s this link?&rdquo;. Until the engine answers there, the stores&apos; product
              lists from Awin do this job.
            </p>
          </div>
          <button type="submit" className={saveButton}>Save</button>
        </form>
      </AccountSection>

      <AccountSection icon="key" title="Engine key" description="How the site knows a deal really comes from the engine. Only its fingerprint is kept here.">
        {engine.key && (
          <p className="text-sm text-zinc-600 dark:text-zinc-300">
            <Icon name="key" className="mr-1.5 text-zinc-500 dark:text-zinc-400" />
            Key ending <span className="font-mono">{engine.key.hint}</span>, made by {engine.key.by} on {formatDate(engine.key.at)}.
          </p>
        )}
        <div className="flex flex-wrap items-start gap-2">
          <EngineKeyButton hasKey={!!engine.key} />
          {engine.key && (
            <form action={revokeEngineKeyAction}>
              <ConfirmSubmitButton confirmText="Remove the engine's key? It can't post until a new one is made." className={outlineButton}>
                Remove key
              </ConfirmSubmitButton>
            </form>
          )}
        </div>
      </AccountSection>

      <AccountSection icon="user" title="Bot account" description="The member the engine's deals are posted as, so everyone can see a deal came from the engine.">
        {bot ? (
          <p className="text-sm">
            <Icon name="circle-check" className="mr-1.5 text-emerald-700 dark:text-emerald-400" />
            Posting as{" "}
            <Link href={`/u/${bot.username}`} target="_blank" className="font-semibold text-orange-700 dark:text-orange-400 hover:underline">
              {bot.username}
            </Link>
            . It can&apos;t be signed in to.
          </p>
        ) : (
          <form action={setUpBotAction} className="flex flex-col gap-2">
            <p className="text-sm text-zinc-600 dark:text-zinc-400">Makes a member called {BOT_USERNAME}, which nobody can sign in as.</p>
            <button type="submit" className={saveButton}>Set up the bot account</button>
          </form>
        )}
      </AccountSection>

      <AccountSection icon="clipboard" title="What the engine has posted" description="Its newest deals first.">
        {posted.length === 0 ? (
          <p className="text-sm text-zinc-500">Nothing yet. Its deals will show here, with how they&apos;re doing.</p>
        ) : (
          <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {posted.slice(0, 20).map((d) => (
              <li key={d.slug} className="flex items-center justify-between gap-3 py-2 text-sm">
                <Link href={`/deals/${d.slug}`} target="_blank" className="min-w-0 truncate hover:underline">
                  {d.title}
                </Link>
                <span className="shrink-0 text-xs text-zinc-500">
                  {STATUS_LABEL[getDealStatus(d)] ?? getDealStatus(d)} · {timeAgo(d.postedAt)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </AccountSection>

      <details className="group rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
        <summary className="flex cursor-pointer list-none items-center gap-2 px-4 py-4 font-semibold sm:px-6 [&::-webkit-details-marker]:hidden">
          <Icon name="file-text" className="size-5 text-orange-700 dark:text-orange-400" />
          <span className="flex-1">How the engine will connect (to agree)</span>
          <Icon name="chevron-down" className="size-5 text-zinc-500 dark:text-zinc-400 transition-transform group-open:rotate-180" />
        </summary>
        <div className="flex flex-col gap-3 border-t border-zinc-100 p-4 text-sm text-zinc-600 sm:p-6 dark:border-zinc-800 dark:text-zinc-400">
          <p>
            <span className="font-semibold text-zinc-900 dark:text-zinc-100">Posting a deal.</span> The engine sends a deal to the
            site with its key. It sends the store&apos;s plain link, title, price, &ldquo;was&rdquo; price, photo, store, and why it&apos;s a
            good deal (for example &ldquo;lowest in 90 days&rdquo;). The site checks the key, whether posting is on and today&apos;s cap,
            then posts it as {BOT_USERNAME}: live, or waiting for a check.
          </p>
          <p>
            <span className="font-semibold text-zinc-900 dark:text-zinc-100">Looking up a link.</span> When someone pastes a link,
            the post form asks the engine&apos;s address above. It gets back the title, price, &ldquo;was&rdquo; price, photo, brand, stock
            and when the price was checked. If the engine doesn&apos;t answer within a couple of seconds, the form carries on as today.
          </p>
          <p>
            <span className="font-semibold text-zinc-900 dark:text-zinc-100">Earning.</span> The engine never adds affiliate tags:
            the site adds them on every &ldquo;Get deal&rdquo; click, the same as for members&apos; deals (Admin → Earnings).
          </p>
        </div>
      </details>
    </div>
  );
}
