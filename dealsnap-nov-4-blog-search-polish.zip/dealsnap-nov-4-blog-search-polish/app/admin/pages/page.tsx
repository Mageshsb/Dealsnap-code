import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { movePageAction } from "@/lib/page-actions";
import { getAllSitePages, pageHref } from "@/lib/site-pages";
import { usesSampleEmails } from "@/lib/legal";
import { getLinkSettings } from "@/lib/social-links";
import Icon from "@/components/Icon";
import Notice from "@/components/admin/Notice";

export const metadata = { title: "Pages" };

const KIND: Record<string, string> = { doc: "Editable text", auto: "Written from your settings, plus your own sections", code: "Designed page" };
const arrow = "flex size-9 items-center justify-center rounded-lg text-zinc-500 hover:bg-zinc-100 disabled:opacity-30 disabled:hover:bg-transparent dark:hover:bg-zinc-800";

// The pages linked from the footer: Terms, Privacy, Guidelines, About, Contact
// and any the team adds. The order here is the order in the footer.
export default async function AdminPages({ searchParams }: { searchParams: Promise<{ notice?: string; error?: string }> }) {
  await requirePermission("pages.manage");
  const { notice, error } = await searchParams;
  const pages = getAllSitePages();
  const shownLinks = getLinkSettings().filter((l) => l.on && l.url).length;

  return (
    <div className="flex max-w-3xl flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0 max-w-2xl">
          <h1 className="text-xl font-bold sm:text-2xl">Pages</h1>
          <p className="mt-1 text-sm text-zinc-500">
            The pages linked at the bottom of every page. Edit the wording of Terms and Guidelines, add sections to the Privacy policy, paste in pages written as HTML and CSS, or add pages of
            your own. The arrows set the order of the footer links.
          </p>
        </div>
        <Link href="/admin/pages/new" className="rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
          + New page
        </Link>
      </div>

      <Notice notice={notice} error={error} />

      <Link
        href="/admin/pages/company"
        className="flex items-center gap-3 rounded-2xl border border-zinc-200 bg-white p-4 hover:border-orange-300 dark:border-zinc-800 dark:bg-zinc-900"
      >
        <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-orange-50 text-orange-700 dark:text-orange-400 dark:bg-orange-950/30">
          <Icon name="building" className="size-5" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block font-semibold">Company details</span>
          <span className="block text-sm text-zinc-500">
            Who runs the site and the three inboxes. Quoted on Terms, Privacy, Contact and the contact form.
          </span>
        </span>
        {usesSampleEmails() && <span className="shrink-0 rounded-full bg-amber-100 px-2.5 py-1 text-xs font-semibold text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">Sample emails</span>}
      </Link>

      <Link
        href="/admin/pages/social"
        className="flex items-center gap-3 rounded-2xl border border-zinc-200 bg-white p-4 hover:border-orange-300 dark:border-zinc-800 dark:bg-zinc-900"
      >
        <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-orange-50 text-orange-700 dark:text-orange-400 dark:bg-orange-950/30">
          <Icon name="link" className="size-5" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block font-semibold">Social and app links</span>
          <span className="block text-sm text-zinc-500">Your social media pages and phone apps, as small logos in the footer. Switch each on or off and set the order.</span>
        </span>
        <span className="shrink-0 rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-semibold text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">
          {shownLinks ? `${shownLinks} showing` : "None showing"}
        </span>
      </Link>

      <ul className="flex flex-col gap-2">
        {pages.map((p, i) => (
          <li key={p.slug} className="flex items-center gap-2 rounded-2xl border border-zinc-200 bg-white p-3 pl-4 dark:border-zinc-800 dark:bg-zinc-900">
            <Link href={`/admin/pages/${p.slug}`} className="min-w-0 flex-1 py-1">
              <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
                <span className="font-semibold">{p.title}</span>
                {!p.builtin && !p.published && <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-xs font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">Draft</span>}
                {p.inFooter && p.published ? (
                  <span className="rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-800 dark:bg-green-950/40 dark:text-green-300">In the footer</span>
                ) : (
                  <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-xs font-medium text-zinc-600 dark:bg-zinc-800">Not in the footer</span>
                )}
              </span>
              <span className="mt-0.5 block text-sm text-zinc-500">
                {pageHref(p)} · {p.format === "html" ? "Custom HTML" : p.builtin ? KIND[p.kind] : "Your page"}
              </span>
            </Link>
            <form action={movePageAction} className="flex shrink-0">
              <input type="hidden" name="slug" value={p.slug} />
              <button type="submit" name="direction" value="up" disabled={i === 0} aria-label={`Move ${p.title} up`} className={arrow}>
                <Icon name="arrow-up" className="size-4" />
              </button>
              <button type="submit" name="direction" value="down" disabled={i === pages.length - 1} aria-label={`Move ${p.title} down`} className={arrow}>
                <Icon name="arrow-down" className="size-4" />
              </button>
            </form>
          </li>
        ))}
      </ul>
    </div>
  );
}
