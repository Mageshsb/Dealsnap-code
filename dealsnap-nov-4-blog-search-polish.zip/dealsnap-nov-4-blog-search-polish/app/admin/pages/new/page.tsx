import { requirePermission } from "@/lib/auth";
import PageEditor from "@/components/admin/PageEditor";

export const metadata = { title: "New page" };

export default async function NewPage() {
  await requirePermission("pages.manage");
  return <PageEditor />;
}
