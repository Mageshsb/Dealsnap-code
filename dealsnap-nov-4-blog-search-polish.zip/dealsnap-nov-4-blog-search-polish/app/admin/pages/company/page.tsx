import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getLegal } from "@/lib/legal";
import CompanyForm from "@/components/admin/CompanyForm";

export const metadata = { title: "Company details" };

export default async function CompanyPage({ searchParams }: { searchParams: Promise<{ notice?: string }> }) {
  await requirePermission("pages.manage");
  const { notice } = await searchParams;
  return (
    <div className="flex max-w-2xl flex-col gap-5">
      <div>
        <Link href="/admin/pages" className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline">
          ← Pages
        </Link>
        <h1 className="mt-2 text-xl font-bold sm:text-2xl">Company details</h1>
        <p className="mt-1 text-sm text-zinc-500">
          Quoted on the Terms, Privacy policy and Contact pages, and used as the addresses for contact-form messages. Change them here and every page updates.
        </p>
      </div>
      <CompanyForm initial={getLegal()} notice={notice} />
    </div>
  );
}
