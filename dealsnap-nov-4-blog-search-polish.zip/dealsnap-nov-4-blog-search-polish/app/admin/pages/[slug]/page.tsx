import { notFound } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import { DEFAULT_PAGES } from "@/lib/page-defaults";
import { formatPageDate, getSitePage, pageHref } from "@/lib/site-pages";
import PageEditor from "@/components/admin/PageEditor";

export const metadata = { title: "Edit page" };

export default async function EditPage({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ notice?: string; error?: string }> }) {
  await requirePermission("pages.manage");
  const { slug } = await params;
  const { notice, error } = await searchParams;
  const page = getSitePage(slug);
  if (!page) notFound();
  return (
    <PageEditor
      notice={notice}
      error={error}
      page={{
        slug: page.slug,
        kind: page.kind,
        format: page.format,
        html: page.html,
        css: page.css,
        builtin: page.builtin,
        title: page.title,
        description: page.description,
        intro: page.intro,
        summary: page.summary,
        body: page.body,
        numbered: page.numbered,
        showUpdated: page.showUpdated,
        updatedOn: page.updatedOn,
        updatedLabel: page.updatedOn ? formatPageDate(page.updatedOn) : "",
        inFooter: page.inFooter,
        footerLabel: page.footerLabel,
        published: page.published,
        href: pageHref(page),
        hasOriginal: DEFAULT_PAGES.some((d) => d.slug === page.slug),
      }}
    />
  );
}
