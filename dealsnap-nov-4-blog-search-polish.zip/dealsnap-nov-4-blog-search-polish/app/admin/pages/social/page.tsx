import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getLinkSettings } from "@/lib/social-links";
import SocialLinksForm from "@/components/admin/SocialLinksForm";

export const metadata = { title: "Social and app links" };

export default async function SocialLinksPage({ searchParams }: { searchParams: Promise<{ notice?: string }> }) {
  await requirePermission("pages.manage");
  const { notice } = await searchParams;
  return (
    <div className="flex max-w-3xl flex-col gap-5">
      <div>
        <Link href="/admin/pages" className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline">
          ← Pages
        </Link>
        <h1 className="mt-2 text-xl font-bold sm:text-2xl">Social and app links</h1>
        <p className="mt-1 text-sm text-zinc-500">
          Small logos at the bottom of every page (and on the About page on phones), linking to your social media and phone apps. Only ones switched on with a link show. Links must be on the
          network&apos;s own website, so a typo can&apos;t send people somewhere else.
        </p>
      </div>
      <SocialLinksForm initial={getLinkSettings()} notice={notice} />
    </div>
  );
}
