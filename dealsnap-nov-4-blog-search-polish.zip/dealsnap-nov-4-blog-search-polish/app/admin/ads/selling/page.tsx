import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getAudienceNumbers, getMediaKits, type MediaKitRow } from "@/lib/db";
import { getAdSettings } from "@/lib/ad-serving";
import { KIT_DAYS_DEFAULT, getKitSettings, kitPath } from "@/lib/media-kit";
import { getSiteUrl } from "@/lib/site-url";
import { ukDay } from "@/lib/events";
import { timeAgo } from "@/lib/format";
import {
  createMediaKitAction,
  deleteMediaKitAction,
  saveAdvertisePageAction,
  saveKitSettingsAction,
  setMediaKitLinkAction,
  updateMediaKitAction,
} from "@/lib/ad-actions";
import AdsHeader from "@/components/admin/AdsHeader";
import CopyField from "@/components/admin/CopyField";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import { field, hint, label, panel, panelTitle } from "@/components/admin/formStyles";
import EmptyState from "@/components/EmptyState";

export const metadata = { title: "Selling ads" };

const check = "mt-0.5 size-4 shrink-0 accent-orange-500";
const long = (d: string) => new Date(`${d}T12:00:00Z`).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
const smallButton = "inline-flex min-h-[36px] items-center rounded-lg border border-zinc-300 px-3.5 text-xs font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800";

// A new kit's link works for KIT_DAYS_DEFAULT days unless changed.
const defaultKitEnd = () => ukDay(new Date(Date.now() + KIT_DAYS_DEFAULT * 86_400_000));

// A kit link's fields, for making one and for changing one.
function KitFields({ k, usualRates }: { k?: MediaKitRow; usualRates: string }) {
  const defaultEnd = defaultKitEnd();
  return (
    <>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <label className={label}>
          Who it&apos;s for
          <span className={hint}>Shown on the kit as “Prepared for …”.</span>
          <input name="recipient" required maxLength={120} defaultValue={k?.recipient} placeholder="Currys (Jane Smith)" className={field} />
        </label>
        <label className={label}>
          Their contact details (optional)
          <span className={hint}>For you only, never shown in the kit.</span>
          <input name="contact" maxLength={200} defaultValue={k?.contact} placeholder="jane.smith@currys.co.uk" className={field} />
        </label>
      </div>
      <label className={label}>
        A note to them (optional)
        <span className={hint}>Shown at the top, like “Great to talk today. Here&apos;s everything we covered.”</span>
        <textarea name="note" rows={2} maxLength={1000} defaultValue={k?.note} className={field} />
      </label>
      <label className={label}>
        Their own rates (optional)
        <span className={hint}>Leave empty to show your usual rates (below), or write a deal you&apos;ve agreed with them.</span>
        <textarea name="rates" rows={2} maxLength={2000} defaultValue={k?.rates} placeholder={usualRates || "No usual rates set yet"} className={field} />
      </label>
      <div className="flex flex-wrap gap-x-6 gap-y-2">
        <label className="flex items-start gap-2 text-sm">
          <input type="checkbox" name="showRates" defaultChecked={k?.showRates ?? true} className={check} />
          Show rates
        </label>
        <label className="flex items-start gap-2 text-sm">
          <input type="checkbox" name="showStats" defaultChecked={k?.showStats ?? true} className={check} />
          Show the site&apos;s numbers
        </label>
      </div>
      <div className="flex flex-wrap items-end gap-x-4 gap-y-2">
        <label className={label}>
          Link works until
          <input type="date" name="expiresOn" defaultValue={k ? k.expiresOn : defaultEnd} className={`${field} sm:w-48`} />
        </label>
        <label className="flex items-center gap-2 pb-2 text-sm">
          <input type="checkbox" name="noEnd" defaultChecked={!!k && !k.expiresOn} className="size-4 accent-orange-500" />
          No end date
        </label>
      </div>
    </>
  );
}

export default async function SellingPage({ searchParams }: { searchParams: Promise<{ notice?: string; error?: string }> }) {
  await requirePermission("ads.manage");
  const { notice, error } = await searchParams;
  const s = getAdSettings();
  const n = getAudienceNumbers();
  const ks = getKitSettings();
  const kits = getMediaKits();
  const site = await getSiteUrl();
  const today = ukDay();

  return (
    <div className="flex max-w-2xl flex-col gap-4">
      <AdsHeader
        current="selling"
        on={s.on}
        title="Selling"
        description="Finding advertisers: a private media kit for each business you talk to (the full picture, always up to date, saves as a PDF), and the public Advertise page."
        notice={notice}
        error={error}
        actions={
          <Link href="/admin/ads/selling/preview" className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">
            Preview the kit
          </Link>
        }
      />

      <section id="new-kit" className={`${panel} scroll-mt-24`}>
        <h2 className={panelTitle}>Send a media kit</h2>
        <p className={hint}>
          Make a private link for one business and paste it into your email. It shows your latest numbers whenever it&apos;s
          opened, saves as a PDF, and you&apos;ll see below when they&apos;ve read it. Turn it off any time.
        </p>
        <form action={createMediaKitAction} className="flex flex-col gap-4">
          <KitFields usualRates={ks.rates} />
          <div>
            <button type="submit" className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600">
              Make the link
            </button>
          </div>
        </form>
      </section>

      <section id="kits" className="flex scroll-mt-24 flex-col gap-2">
        <h2 className={panelTitle}>Kits sent</h2>
        {kits.length === 0 && (
          <EmptyState icon="file-text">
            <p>
              None yet. Make one above for the next business that asks.
            </p>
          </EmptyState>
        )}
        {kits.map((k) => {
          const path = kitPath(k);
          const expired = !!k.expiresOn && today > k.expiresOn;
          const state = !path ? "Link off" : expired ? "Ended" : "Link on";
          return (
            <article key={k.id} id={`kit-${k.id}`} className="flex scroll-mt-24 flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-3 dark:border-zinc-800 dark:bg-zinc-900">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-medium">{k.recipient}</span>
                <span
                  className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                    state === "Link on" ? "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400" : "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400"
                  }`}
                >
                  {state}
                </span>
                <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${k.opens ? "bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400" : "bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400"}`}>
                  {k.opens ? `Opened ${k.opens} time${k.opens === 1 ? "" : "s"}, last ${timeAgo(k.lastOpenedAt!)}` : "Not opened yet"}
                </span>
              </div>
              <p className="text-xs text-zinc-500">
                Made {timeAgo(k.createdAt)} by {k.createdBy}
                {k.expiresOn ? ` · works until ${long(k.expiresOn)}` : " · no end date"}
                {k.contact && ` · ${k.contact}`}
              </p>
              {path && !expired && <CopyField value={`${site}${path}`} label={`Media kit link for ${k.recipient}`} />}
              <div className="flex flex-wrap items-center gap-2">
                {path && !expired && (
                  <a href={path} target="_blank" rel="noopener" className={smallButton}>
                    Open
                  </a>
                )}
                <form action={setMediaKitLinkAction}>
                  <input type="hidden" name="id" value={k.id} />
                  <input type="hidden" name="on" value="1" />
                  {path ? (
                    <ConfirmSubmitButton confirmText="Make a new link? The current one stops working." confirmLabel="Make a new link" className={smallButton}>
                      New link
                    </ConfirmSubmitButton>
                  ) : (
                    <button type="submit" className={smallButton}>
                      Turn the link on
                    </button>
                  )}
                </form>
                {path && (
                  <form action={setMediaKitLinkAction}>
                    <input type="hidden" name="id" value={k.id} />
                    <input type="hidden" name="on" value="0" />
                    <ConfirmSubmitButton confirmText={`Turn off ${k.recipient}'s link? They can't open it any more.`} confirmLabel="Turn off" className={`${smallButton} text-red-600`}>
                      Turn off
                    </ConfirmSubmitButton>
                  </form>
                )}
              </div>
              <details className="group">
                <summary className="cursor-pointer list-none text-xs font-medium text-orange-700 group-open:hidden dark:text-orange-400">Edit</summary>
                <div className="flex flex-col gap-4 border-t border-zinc-100 pt-3 dark:border-zinc-800">
                  <form action={updateMediaKitAction} className="flex flex-col gap-4">
                    <input type="hidden" name="id" value={k.id} />
                    <KitFields k={k} usualRates={ks.rates} />
                    <div>
                      <button type="submit" className="rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600">
                        Save
                      </button>
                    </div>
                  </form>
                  <form action={deleteMediaKitAction}>
                    <input type="hidden" name="id" value={k.id} />
                    <ConfirmSubmitButton confirmText={`Delete ${k.recipient}'s kit? Its link stops working.`} className="text-sm font-medium text-red-600 hover:underline">
                      Delete this kit
                    </ConfirmSubmitButton>
                  </form>
                </div>
              </details>
            </article>
          );
        })}
      </section>

      <form id="kit-settings" action={saveKitSettingsAction} className={`${panel} scroll-mt-24`}>
        <h2 className={panelTitle}>The kit&apos;s words</h2>
        <p className={hint}>Shared by every kit. The rest (audience, ways to advertise, sizes, how often, targeting, reporting) comes from the site itself.</p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <label className={label}>
            Your name (optional)
            <span className={hint}>Signs the note, and “write to …” at the end.</span>
            <input name="contactName" maxLength={80} defaultValue={ks.contactName} className={field} />
          </label>
          <label className={label}>
            Email for replies
            <input name="contactEmail" type="email" maxLength={254} defaultValue={ks.contactEmail} className={field} />
          </label>
        </div>
        <label className={label}>
          Usual rates (optional)
          <span className={hint}>Shown as written. A kit can have its own instead. Empty: no Rates section, unless the Advertise page has rates.</span>
          <textarea name="rates" rows={4} maxLength={2000} defaultValue={ks.rates} placeholder={"Sponsored deals: £50 a week\nAds: £6 per 1,000 views (minimum 20,000)"} className={field} />
        </label>
        <label className={label}>
          Terms in brief (optional)
          <span className={hint}>Like payment terms and cancellation. Have your full terms checked by your lawyer.</span>
          <textarea name="terms" rows={3} maxLength={3000} defaultValue={ks.terms} placeholder="Payment within 14 days of the invoice. Cancel up to 3 days before the start at no cost." className={field} />
        </label>
        <label className={label}>
          Working days to set an ad up
          <input type="number" name="leadDays" min={0} max={30} defaultValue={ks.leadDays} className={field.replace("w-full", "w-24")} />
        </label>
        <div>
          <button type="submit" className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600">
            Save
          </button>
        </div>
      </form>

      <form action={saveAdvertisePageAction} className={panel}>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className={panelTitle}>Public Advertise page</h2>
          {(s.page.on || s.page.holding) && (
            <Link href="/advertise" target="_blank" className="text-sm font-medium text-orange-700 hover:underline dark:text-orange-400">
              View it
            </Link>
          )}
        </div>
        <p className={hint}>
          A short public pitch at /advertise: the ways to advertise (only the spaces that are on), why DealSnap, how it works,
          and a way to get in touch. Most sites keep numbers and prices for the private kit.
        </p>
        <fieldset className="flex flex-col gap-2.5">
          <legend className="sr-only">What /advertise shows</legend>
          {(
            [
              ["off", "Off", "The page doesn't exist (visitors see a “not found” page)."],
              ["holding", "Holding page", "A short “Looking to advertise? Get in touch” page, with a few lines about the site. Not in the footer or search engines."],
              ["full", "Full page", "Every way to advertise, why DealSnap and how it works. Adds “Advertise” to the footer and the page to search engines."],
            ] as const
          ).map(([value, name, about]) => (
            <label key={value} className="flex items-start gap-2.5 text-sm font-medium">
              <input
                type="radio"
                name="pageMode"
                value={value}
                defaultChecked={(s.page.on ? "full" : s.page.holding ? "holding" : "off") === value}
                className="mt-0.5 size-4 accent-orange-500"
              />
              <span className="flex flex-col gap-0.5">
                {name}
                <span className={hint}>{about}</span>
              </span>
            </label>
          ))}
        </fieldset>
        <label className={label}>
          Opening words (optional)
          <span className={hint}>A few lines under the heading (the kit uses them too). Leave empty for our own.</span>
          <textarea name="pageIntro" rows={3} maxLength={600} defaultValue={s.page.intro} className={field} />
        </label>
        <label className={label}>
          Rates on the public page (optional)
          <span className={hint}>Usually left empty: prices go in the kit.</span>
          <textarea name="pageRates" rows={3} maxLength={1500} defaultValue={s.page.rates} className={field} />
        </label>
        <label className="flex items-start gap-2.5 text-sm font-medium">
          <input type="checkbox" name="pageStats" defaultChecked={s.page.stats} className={check} />
          <span className="flex flex-col gap-0.5">
            Show the site&apos;s numbers on the public page
            <span className={hint}>
              Rounded down, zeros left out. Right now: {n.members.toLocaleString("en-GB")} members, {n.deals30.toLocaleString("en-GB")} deals
              and {n.taps30.toLocaleString("en-GB")} taps to stores in the last 30 days, {n.adViews30.toLocaleString("en-GB")} ads seen.
            </span>
          </span>
        </label>
        <div>
          <button type="submit" className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600">
            Save
          </button>
        </div>
      </form>
    </div>
  );
}
