import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import MediaKit, { KIT_PRINT_CSS } from "@/components/MediaKit";
import { getKitData, getKitSettings } from "@/lib/media-kit";
import { getAdSettings } from "@/lib/ad-serving";
import { sampleSponsoredDeal } from "@/lib/kit-sample";

export const metadata = { title: "Media kit preview" };

// Staff's look at the media kit as a business would see it, with the usual
// rates and the site's numbers, before sending any links.
export default async function MediaKitPreview() {
  await requirePermission("ads.manage");
  const settings = getKitSettings();
  return (
    <div className="flex flex-col gap-3">
      <style>{KIT_PRINT_CSS}</style>
      <Link href="/admin/ads/selling" className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline">
        ← Selling
      </Link>
      <MediaKit
        recipient="(the business's name)"
        note=""
        rates={settings.rates || getAdSettings().page.rates}
        showStats
        data={getKitData()}
        ads={getAdSettings()}
        kit={settings}
        sampleDeal={sampleSponsoredDeal()}
      />
    </div>
  );
}
