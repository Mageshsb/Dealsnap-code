import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getSiteSetting } from "@/lib/db";
import { getAdSettings } from "@/lib/ad-serving";
import { saveAdNetworkAction } from "@/lib/ad-actions";
import { networkSlots } from "@/lib/ads";
import AdsHeader from "@/components/admin/AdsHeader";
import { field, hint, label, panel, panelTitle } from "@/components/admin/formStyles";

export const metadata = { title: "Ad network" };

const check = "mt-0.5 size-4 shrink-0 accent-orange-500";

export default async function AdNetworkPage({ searchParams }: { searchParams: Promise<{ notice?: string; error?: string }> }) {
  await requirePermission("ads.manage");
  const { notice, error } = await searchParams;
  const s = getAdSettings();

  return (
    <div className="flex max-w-2xl flex-col gap-4">
      <AdsHeader
        current="network"
        on={s.on}
        title="Ad network"
        description="For the spaces your own campaigns don't fill: Google Ad Manager auctions them to advertisers automatically. Your campaigns always come first."
        notice={notice}
        error={error}
      />

      <form action={saveAdNetworkAction} className="flex flex-col gap-4">
        <section className={panel}>
          <h2 className={panelTitle}>Google Ad Manager</h2>
          <p className={hint}>
            Set it up at admanager.google.com first (it&apos;s free). Make one ad unit for each space below, with the sizes
            shown. Ad Manager can also bring in AdSense and other networks, so this is the only code the site needs. Worth
            it once the site has steady traffic; a managed network (Raptive, Mediavine and the like) can run it for you
            instead.
          </p>
          <label className="flex items-start gap-2.5 text-sm font-medium">
            <input type="radio" name="network" value="off" defaultChecked={s.network === "off"} className={check} />
            Off
          </label>
          <label className="flex items-start gap-2.5 text-sm font-medium">
            <input type="radio" name="network" value="gam" defaultChecked={s.network === "gam"} className={check} />
            On: fill empty spaces from Google Ad Manager
          </label>
          <label className={label}>
            Network code
            <span className={hint}>The number in your Ad Manager address, like 21234567.</span>
            <input name="networkCode" inputMode="numeric" maxLength={12} defaultValue={s.networkCode} className={`${field} sm:w-48`} />
          </label>
          <ul className="flex flex-col gap-3">
            {networkSlots().map((def) => (
              <li key={def.id}>
                <label className={label}>
                  {def.name}
                  <span className={hint}>
                    Ad unit code, like /21234567/dealsnap_{def.id.replace("-", "_")}. Sizes:{" "}
                    {def.sizes.map((z) => (z === "fluid" ? "fluid (native)" : `${z[0]}×${z[1]}`)).join(", ")}.
                  </span>
                  <input name={`unit-${def.id}`} maxLength={300} defaultValue={s.slots[def.id].unit} className={field} />
                </label>
              </li>
            ))}
          </ul>
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>Personalised ads</h2>
          <label className="flex items-start gap-2.5 text-sm font-medium">
            <input type="checkbox" name="personalised" defaultChecked={s.personalised} className={check} />
            <span className="flex flex-col gap-0.5">
              Allow personalised ads
              <span className={hint}>
                Leave this off unless a Google-certified consent tool (one that supports the IAB&apos;s TCF) is on the site,
                added through Settings → Tracking & code. UK law and Google&apos;s rules need one before ads can use cookies. Off,
                Google shows &ldquo;limited ads&rdquo;: no cookies and nothing personal, so no consent is needed (they earn
                less).
              </span>
            </span>
          </label>
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>ads.txt</h2>
          <p className={hint}>
            The public list of companies allowed to sell DealSnap&apos;s ad space (served at{" "}
            <Link href="/ads.txt" target="_blank" className="underline">
              /ads.txt
            </Link>
            ). Ad buyers check it, and most won&apos;t pay without it. Paste in the lines each network gives you, like
            “google.com, pub-1234567890123456, DIRECT, f08c47fec0942fa0”.
          </p>
          <textarea name="adsTxt" rows={6} defaultValue={getSiteSetting("ads_txt") ?? ""} className={`${field} font-mono text-xs`} />
        </section>

        <div>
          <button type="submit" className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600">
            Save
          </button>
        </div>
      </form>
    </div>
  );
}
