import { requirePermission } from "@/lib/auth";
import { getCampaign } from "@/lib/db";
import { csvResponse, reportCsv } from "@/lib/ad-report";

// A campaign's report as a spreadsheet (CSV), one row a day, for invoicing
// the advertiser or sending them their numbers.
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  await requirePermission("ads.manage");
  const campaign = getCampaign((await params).id);
  if (!campaign) return new Response("Not found", { status: 404 });
  return csvResponse(reportCsv(campaign, true));
}
