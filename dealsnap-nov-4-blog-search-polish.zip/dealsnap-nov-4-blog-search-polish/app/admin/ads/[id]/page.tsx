import { notFound } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import { getAdvertisers, getCampaign, getCampaignReport, getCampaigns } from "@/lib/db";
import { flushAdCounts } from "@/lib/ad-serving";
import { reportExpires, reportPath } from "@/lib/ad-report";
import { getDealBySlug } from "@/lib/mock-deals";
import { getSiteUrl } from "@/lib/site-url";
import { ukDay } from "@/lib/events";
import { rivalsOf } from "@/lib/ads";
import AdEditor from "@/components/admin/AdEditor";

export const metadata = { title: "Edit campaign" };

export default async function EditCampaignPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string; notice?: string }>;
}) {
  await requirePermission("ads.manage");
  const campaign = getCampaign((await params).id);
  if (!campaign) notFound();
  const { error, notice } = await searchParams;
  flushAdCounts();
  const path = reportPath(campaign);
  return (
    <AdEditor
      campaign={campaign}
      advertisers={getAdvertisers()}
      report={getCampaignReport(campaign.id)}
      deal={campaign.dealSlug ? getDealBySlug(campaign.dealSlug) : undefined}
      reportUrl={path ? `${await getSiteUrl()}${path}` : undefined}
      reportExpires={path ? reportExpires(campaign) : undefined}
      today={ukDay()}
      rivals={rivalsOf(campaign, getCampaigns(), ukDay())}
      error={error}
      notice={notice}
    />
  );
}
