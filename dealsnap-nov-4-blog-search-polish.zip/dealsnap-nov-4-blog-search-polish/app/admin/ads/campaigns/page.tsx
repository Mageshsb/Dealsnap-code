import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getAdTotals, getAdTotalsSince, getCampaigns } from "@/lib/db";
import { flushAdCounts, getAdSettings } from "@/lib/ad-serving";
import { setCampaignStatusAction } from "@/lib/ad-actions";
import { ukDay } from "@/lib/events";
import { campaignAttention, campaignState, clickRate, earned, pounds } from "@/lib/ads";
import AdsHeader from "@/components/admin/AdsHeader";
import { AdProgress, AdStatePill } from "@/components/admin/AdBits";
import EmptyState from "@/components/EmptyState";

export const metadata = { title: "Ad campaigns" };

const daysAgo = (n: number) => ukDay(new Date(Date.now() - n * 86_400_000));
const short = (d: string) => new Date(`${d}T12:00:00Z`).toLocaleDateString("en-GB", { day: "numeric", month: "short", timeZone: "UTC" });

export default async function AdCampaignsPage({ searchParams }: { searchParams: Promise<{ notice?: string }> }) {
  await requirePermission("ads.manage");
  const { notice } = await searchParams;
  flushAdCounts();
  const today = ukDay();
  const weekAgo = daysAgo(6);
  const totals = getAdTotals();
  const week = getAdTotalsSince(weekAgo);
  const todays = getAdTotalsSince(today);
  const campaigns = getCampaigns().map((c) => {
    const t = totals.get(c.id) ?? { views: 0, clicks: 0 };
    const d = { total: t.views, today: todays.get(c.id)?.views ?? 0 };
    return { c, t, state: campaignState(c, d, today), notes: campaignAttention(c, d, today) };
  });
  const weekViews = [...week.values()].reduce((n, t) => n + t.views, 0);
  const weekClicks = [...week.values()].reduce((n, t) => n + t.clicks, 0);
  const earnedAll = campaigns.reduce((n, { c, t }) => n + earned(c, t.views), 0);
  const settings = getAdSettings();

  return (
    <div className="flex flex-col gap-4">
      <AdsHeader
        current="campaigns"
        on={settings.on}
        title="Campaigns"
        description="Ads and sponsored deals that advertisers pay DealSnap for directly. Each runs in the spaces and pages you pick, between its dates, until it has had the views bought."
        notice={notice}
        actions={
          <>
            <Link href="/admin/ads/new" className="rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
              + Ad
            </Link>
            <Link
              href="/admin/ads/new?kind=deal"
              className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
            >
              + Sponsored deal
            </Link>
          </>
        }
      />

      <dl className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[
          ["Views, last 7 days", weekViews.toLocaleString("en-GB")],
          ["Clicks, last 7 days", weekClicks.toLocaleString("en-GB")],
          ["Click rate", clickRate(weekViews, weekClicks)],
          ["Earned, all time", pounds(earnedAll)],
        ].map(([k, v]) => (
          <div key={k} className="rounded-xl border border-zinc-200 bg-white p-3 dark:border-zinc-800 dark:bg-zinc-900">
            <dt className="text-xs text-zinc-500">{k}</dt>
            <dd className="text-lg font-semibold">{v}</dd>
          </div>
        ))}
      </dl>

      <ul className="flex flex-col gap-2">
        {campaigns.map(({ c, t, state, notes }) => (
          <li key={c.id} className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-3 sm:flex-row sm:items-center dark:border-zinc-800 dark:bg-zinc-900">
            <div className="flex min-w-0 flex-1 flex-col gap-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <AdStatePill state={state} />
                {c.kind === "deal" && (
                  <span className="rounded-full bg-orange-50 px-2 py-0.5 text-xs font-medium text-orange-700 dark:bg-orange-950/40 dark:text-orange-300">Sponsored deal</span>
                )}
                {c.priority === "house" && (
                  <span className="rounded-full bg-sky-50 px-2 py-0.5 text-xs font-medium text-sky-700 dark:bg-sky-950/40 dark:text-sky-300">House ad</span>
                )}
                {c.reportKey && <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-xs text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">Report shared</span>}
                <span className="text-xs text-zinc-500">
                  {c.advertiserName || "No advertiser"}
                  {(c.startsOn || c.endsOn) && ` · ${c.startsOn ? short(c.startsOn) : "now"} to ${c.endsOn ? short(c.endsOn) : "no end"}`}
                  {c.priority === "sponsorship" && " · sponsorship"}
                </span>
              </div>
              <Link href={`/admin/ads/${c.id}`} className="line-clamp-1 text-sm font-medium hover:underline">
                {c.name}
              </Link>
              <AdProgress views={t.views} goal={c.goal} startsOn={c.startsOn} endsOn={c.endsOn} today={today} />
              {notes.slice(0, 1).map((n) => (
                <span key={n.text} className={`text-xs ${n.level === "warn" ? "font-medium text-amber-700 dark:text-amber-400" : "text-zinc-500"}`}>
                  {n.short}
                </span>
              ))}
              <span className="text-xs text-zinc-500">
                {t.clicks.toLocaleString("en-GB")} click{t.clicks === 1 ? "" : "s"} · {clickRate(t.views, t.clicks)} · {pounds(earned(c, t.views))}
              </span>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <Link
                href={`/admin/ads/${c.id}`}
                className="inline-flex min-h-[36px] items-center rounded-lg border border-zinc-300 px-3.5 text-xs font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
              >
                Edit
              </Link>
              {(c.status === "live" || c.status === "paused") && (
                <form action={setCampaignStatusAction}>
                  <input type="hidden" name="id" value={c.id} />
                  <input type="hidden" name="back" value="list" />
                  <input type="hidden" name="status" value={c.status === "live" ? "paused" : "live"} />
                  <button
                    type="submit"
                    className={`inline-flex min-h-[36px] items-center rounded-lg px-3.5 text-xs font-semibold ${
                      c.status === "live"
                        ? "border border-zinc-300 hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
                        : "bg-orange-500 text-white hover:bg-orange-600"
                    }`}
                  >
                    {c.status === "live" ? "Pause" : "Resume"}
                  </button>
                </form>
              )}
            </div>
          </li>
        ))}
        {campaigns.length === 0 && (
          <li>
            <EmptyState icon="target">
              <p>
                No campaigns yet. When an advertiser books space, add it here.
              </p>
            </EmptyState>
          </li>
        )}
      </ul>
    </div>
  );
}
