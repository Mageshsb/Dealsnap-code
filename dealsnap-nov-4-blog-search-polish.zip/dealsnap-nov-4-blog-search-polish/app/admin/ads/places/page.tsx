import { cookies } from "next/headers";
import { requirePermission } from "@/lib/auth";
import { ADS_PREVIEW_COOKIE, getAdSettings } from "@/lib/ad-serving";
import { saveAdPlacesAction, setAdsPreviewAction } from "@/lib/ad-actions";
import { getCategoryGroups } from "@/lib/categories";
import { slugify } from "@/lib/slug";
import { AD_PAGE_KINDS, AD_SCREENS, AD_SIZES, AD_SLOTS, MAX_EVERY, MAX_FIRST, MAX_PER_PAGE, minEvery, minFirst, repeatUnit, repeatUnits } from "@/lib/ads";
import AdsHeader from "@/components/admin/AdsHeader";
import AdRepeatFields from "@/components/admin/AdRepeatFields";
import { field, hint, label, panel, panelTitle } from "@/components/admin/formStyles";

export const metadata = { title: "Ad spaces" };

const check = "mt-0.5 size-4 shrink-0 accent-orange-500";
// The shared box style, narrowed for a small number (its w-full would win over w-20).
const number = field.replace("w-full", "w-20");

export default async function AdPlacesPage({ searchParams }: { searchParams: Promise<{ notice?: string; error?: string }> }) {
  await requirePermission("ads.manage");
  const { notice, error } = await searchParams;
  const s = getAdSettings();
  const previewing = (await cookies()).get(ADS_PREVIEW_COOKIE)?.value === "1";

  return (
    <div className="flex max-w-2xl flex-col gap-4">
      <AdsHeader
        current="places"
        on={s.on}
        title="Ad spaces"
        description="Where ads can appear, how often, and on which pages. Every space keeps a fixed size, so nothing on the page moves when an ad loads."
        notice={notice}
        error={error}
      />

      <section className={panel}>
        <h2 className={panelTitle}>See them on the site</h2>
        <p className={hint}>
          Outlines every ad space that would show under the rules below (even with ads off), named, so you can check
          them on phones, laptops and wide screens. Only staff see the outlines. They switch off after two hours.
        </p>
        <form action={setAdsPreviewAction} className="flex flex-wrap gap-2">
          <input type="hidden" name="on" value={previewing ? "0" : "1"} />
          <button
            type="submit"
            className={`rounded-full px-5 py-2.5 text-sm font-semibold ${
              previewing ? "border border-zinc-300 hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800" : "bg-orange-500 text-white hover:bg-orange-600"
            }`}
          >
            {previewing ? "Hide the outlines" : "Show the ad spaces on the site"}
          </button>
        </form>
      </section>

      <form action={saveAdPlacesAction} className="flex flex-col gap-4">
        <section className={panel}>
          <h2 className={panelTitle}>Everywhere</h2>
          <label className="flex items-start gap-2.5 text-sm font-medium">
            <input type="checkbox" name="adsOn" defaultChecked={s.on} className={check} />
            <span className="flex flex-col gap-0.5">
              Show ads on the site
              <span className={hint}>The master switch. Off, no ad space is drawn and no ad code loads anywhere.</span>
            </span>
          </label>
          <label className="flex items-start gap-2.5 text-sm font-medium">
            <input type="checkbox" name="membersFree" defaultChecked={s.membersFree} className={check} />
            <span className="flex flex-col gap-0.5">
              No ads for signed-in members
              <span className={hint}>A thank-you for joining (and a reason to). Fewer views to sell.</span>
            </span>
          </label>
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>Which pages</h2>
          <fieldset className="flex flex-col gap-2">
            <legend className="mb-1 text-sm font-medium">Kinds of page with ads</legend>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {AD_PAGE_KINDS.map((k) => (
                <label key={k.value} className="flex items-start gap-2 text-sm">
                  <input type="checkbox" name={`page-${k.value}`} defaultChecked={!s.offPages.includes(k.value)} className={check} />
                  {k.label}
                </label>
              ))}
            </div>
            <span className={hint}>A kind of page that&apos;s off draws no ad space and loads no ad code.</span>
          </fieldset>
          <fieldset className="flex flex-col gap-2">
            <legend className="mb-1 text-sm font-medium">No ads at all on these categories</legend>
            <span className={hint}>Their pages and their deals&apos; pages. Most ad networks also refuse some topics (alcohol, gambling, adult).</span>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {getCategoryGroups().map((c) => {
                const slug = slugify(c.name);
                return (
                  <label key={slug} className="flex items-start gap-2 text-sm">
                    <input type="checkbox" name="blocked" value={slug} defaultChecked={s.blockedCategories.includes(slug)} className={check} />
                    {c.name}
                  </label>
                );
              })}
            </div>
          </fieldset>
          <label className={label}>
            No ads on these pages
            <span className={hint}>
              One address a line, like /stores/currys, /deals/… or /blog/…. A store, category, tag or brand page also keeps
              ads off its deals&apos; pages (useful when a partner asks for it). Up to 200.
            </span>
            <textarea name="blockedPaths" rows={4} defaultValue={s.blockedPaths.join("\n")} placeholder="/stores/currys" className={`${field} font-mono text-xs`} />
          </label>
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>Each space</h2>
          <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {AD_SLOTS.map((def, i) => {
              const slot = s.slots[def.id];
              const r = def.repeats;
              const of = r ? repeatUnit(r.of) : "deal";
              return (
                <li key={def.id} id={`space-${def.id}`} className="flex scroll-mt-24 flex-col gap-3 py-4 first:pt-0 last:pb-0">
                  <label className="flex items-start gap-2.5 text-sm font-medium">
                    <input type="checkbox" name={`enabled-${def.id}`} defaultChecked={slot.enabled} className={check} />
                    <span className="flex flex-col gap-0.5">
                      {i + 1} · {def.name}
                      <span className={hint}>
                        {def.where} {def.screenChoice ? "" : `${def.screens}.`}
                      </span>
                    </span>
                  </label>
                  <div className="ml-6.5 flex flex-col gap-3">
                    {r && (
                      <AdRepeatFields
                        id={def.id}
                        name={def.name}
                        of={of}
                        ofPlural={r ? repeatUnits(r.of) : undefined}
                        first={slot.first}
                        every={slot.every}
                        max={slot.max}
                        firstMin={minFirst(def)}
                        firstMax={MAX_FIRST}
                        everyMin={minEvery(def)}
                        everyMax={MAX_EVERY}
                        maxMax={MAX_PER_PAGE}
                        className={number}
                      >
                        Never closer than every {minEvery(def)} {r.of === "posts" ? "replies" : `${of}s`}. 0 for “up to” means no limit
                        {r.of === "paragraphs" ? "" : r.of === "posts" ? " in a very long thread" : " as the list scrolls on"}.
                        {r.of === "paragraphs"
                          ? " Short articles get fewer, or none."
                          : r.of === "posts"
                            ? " Short threads get fewer, or none, and an ad never sits beside the opening post."
                            : r.of === "threads"
                              ? " Never first in a list. The same on the Community home and in each space."
                              : " Never right beside a promo card or the sign-up tile."}
                      </AdRepeatFields>
                    )}
                    {def.size && (
                      <fieldset className="flex flex-col gap-1.5">
                        <legend className="sr-only">{def.name}: size</legend>
                        {AD_SIZES.map((z) => (
                          <label key={z.value} className="flex items-start gap-2 text-sm">
                            <input type="radio" name={`size-${def.id}`} value={z.value} defaultChecked={slot.size === z.value} className="mt-0.5 size-4 accent-orange-500" />
                            <span>
                              {z.label} <span className={hint}>{z.hint}</span>
                            </span>
                          </label>
                        ))}
                      </fieldset>
                    )}
                    {def.screenChoice && (
                      <fieldset className="flex flex-wrap gap-x-4 gap-y-1.5">
                        <legend className="sr-only">{def.name}: screens</legend>
                        {AD_SCREENS.map((sc) => (
                          <label key={sc.value} className="flex items-center gap-2 text-sm">
                            <input type="radio" name={`screens-${def.id}`} value={sc.value} defaultChecked={slot.screens === sc.value} className="size-4 accent-orange-500" />
                            {sc.label}
                          </label>
                        ))}
                      </fieldset>
                    )}
                    {def.condition && (
                      <label className={label}>
                        <span className="font-normal">{def.condition.label}</span>
                        <span className={hint}>{def.condition.hint}</span>
                        <input type="number" name={`cond-${def.id}`} min={0} max={def.condition.max} defaultValue={slot.cond} className={field.replace("w-full", "w-28")} />
                      </label>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        <div>
          <button type="submit" className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600">
            Save
          </button>
        </div>
      </form>
    </div>
  );
}
