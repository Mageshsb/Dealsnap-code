import { requirePermission } from "@/lib/auth";
import { getAdvertisers } from "@/lib/db";
import { ukDay } from "@/lib/events";
import AdEditor from "@/components/admin/AdEditor";
import { isAdSlotId } from "@/lib/ads";

export const metadata = { title: "New campaign" };

export default async function NewCampaignPage({ searchParams }: { searchParams: Promise<{ error?: string; slot?: string; kind?: string }> }) {
  await requirePermission("ads.manage");
  const { error, slot, kind } = await searchParams;
  return (
    <AdEditor
      advertisers={getAdvertisers()}
      today={ukDay()}
      error={error}
      kind={kind === "deal" || slot === "sponsored" ? "deal" : "ad"}
      slot={isAdSlotId(slot) ? slot : undefined}
    />
  );
}
