import Link from "next/link";
import type { ReactNode } from "react";
import { requirePermission } from "@/lib/auth";
import { getAdTotals, getAdTotalsSince, getCampaigns, getMediaKits, getRunningCampaigns } from "@/lib/db";
import { flushAdCounts, getAdSettings, type AdSettings } from "@/lib/ad-serving";
import { setAdsOnAction } from "@/lib/ad-actions";
import { ukDay } from "@/lib/events";
import { AD_PAGE_KINDS, AD_SCREENS, AD_SLOTS, campaignAttention, clickRate, repeatUnit, type AdSlotDef, type AdSlotId } from "@/lib/ads";
import Icon from "@/components/Icon";
import AdsHeader from "@/components/admin/AdsHeader";

export const metadata = { title: "Ads" };

// Ads at a glance: the master switch, last week's numbers, a map of where
// every ad space sits (on a phone, a laptop, a deal page, a blog article and the Community),
// coloured by what fills it, and a card per space with its rules and what's
// running in it. The numbers on the maps match the cards.

type State = "campaigns" | "network" | "empty" | "off";

const STATE: Record<State, { pill: string; map: string; label: (n: number) => string }> = {
  campaigns: {
    pill: "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400",
    map: "bg-green-100 text-green-800 ring-1 ring-green-300 dark:bg-green-950/50 dark:text-green-300 dark:ring-green-800",
    label: (n) => `${n} campaign${n === 1 ? "" : "s"} running`,
  },
  network: {
    pill: "bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400",
    map: "bg-sky-100 text-sky-800 ring-1 ring-sky-300 dark:bg-sky-950/50 dark:text-sky-300 dark:ring-sky-800",
    label: () => "Ad network fills it",
  },
  empty: {
    pill: "bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400",
    map: "border border-dashed border-amber-400 bg-amber-50 text-amber-800 dark:border-amber-700 dark:bg-amber-950/30 dark:text-amber-300",
    label: () => "On, nothing to show yet",
  },
  off: {
    pill: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400",
    map: "border border-dashed border-zinc-300 text-zinc-500 dark:text-zinc-400 dark:border-zinc-700",
    label: () => "Off",
  },
};

const daysAgo = (n: number) => ukDay(new Date(Date.now() - n * 86_400_000));

// The space's rules in a line: how often, which screens, when.
function rules(def: AdSlotDef, s: AdSettings["slots"][AdSlotId]): string {
  const parts: string[] = [];
  if (def.repeats) {
    const of = repeatUnit(def.repeats.of);
    parts.push(`After ${of} ${s.first}, then every ${s.every}${s.max ? `, up to ${s.max} a page` : ""}`);
  }
  if (def.size) parts.push(s.size === "compact" ? "Compact" : "Standard size");
  parts.push(def.screenChoice ? AD_SCREENS.find((x) => x.value === s.screens)!.label : def.screens);
  if (def.condition && s.cond) parts.push(def.id === "deal" ? `descriptions of ${s.cond}+ characters` : `deals with ${s.cond}+ comments`);
  return parts.join(" · ");
}

const GREY = "rounded bg-zinc-100 dark:bg-zinc-800";

// A numbered space on the maps, linking to its card.
function MapSpace({ id, n, state, name, className = "", children }: { id: AdSlotId; n: number; state: State; name: string; className?: string; children?: ReactNode }) {
  return (
    <a href={`#space-${id}`} title={name} className={`flex items-center justify-center rounded text-[10px] font-bold leading-none ${STATE[state].map} ${className}`}>
      {children ?? n}
    </a>
  );
}

function MapDeal() {
  return <div className={`${GREY} h-6`} />;
}

function MapFrame({ title, children }: { title: string; children: ReactNode }) {
  return (
    <figure className="flex flex-col gap-1.5">
      <div inert className="flex flex-1 flex-col gap-1 rounded-xl border border-zinc-200 bg-white p-2 dark:border-zinc-800 dark:bg-zinc-900">
        <div className={`${GREY} h-4`} />
        {children}
      </div>
      <figcaption className="text-center text-xs text-zinc-500">{title}</figcaption>
    </figure>
  );
}

export default async function AdsOverviewPage({ searchParams }: { searchParams: Promise<{ notice?: string }> }) {
  await requirePermission("ads.manage");
  const { notice } = await searchParams;
  flushAdCounts();
  const settings = getAdSettings();
  const today = ukDay();
  const running = getRunningCampaigns(today);
  const week = [...getAdTotalsSince(daysAgo(6)).values()];
  const views = week.reduce((n, t) => n + t.views, 0);
  const clicks = week.reduce((n, t) => n + t.clicks, 0);
  const kitCount = getMediaKits().length;
  const totals = getAdTotals();
  const todays = getAdTotalsSince(today);
  const attention = getCampaigns()
    .filter((c) => c.status === "live")
    .flatMap((c) =>
      campaignAttention(c, { total: totals.get(c.id)?.views ?? 0, today: todays.get(c.id)?.views ?? 0 }, today).map((a) => ({ c, a })),
    )
    .sort((x, y) => Number(y.a.level === "warn") - Number(x.a.level === "warn"));
  const pagesOn = AD_PAGE_KINDS.filter((k) => !settings.offPages.includes(k.value));

  const spaces = AD_SLOTS.map((def, i) => {
    const s = settings.slots[def.id];
    const campaigns = running.filter((c) => c.slots.includes(def.id)).length;
    const pages = def.pages.filter((p) => !settings.offPages.includes(p));
    const state: State =
      !s.enabled || !pages.length ? "off" : campaigns ? "campaigns" : settings.network === "gam" && s.unit ? "network" : "empty";
    return { def, s, n: i + 1, campaigns, state, pages };
  });
  const by = Object.fromEntries(spaces.map((x) => [x.def.id, x])) as Record<AdSlotId, (typeof spaces)[number]>;

  const at = (id: AdSlotId) => ({ id, n: by[id].n, state: by[id].state, name: by[id].def.name });

  return (
    <div className="flex flex-col gap-4">
      <AdsHeader
        current="overview"
        on={settings.on}
        title="Overview"
        description={
          settings.on
            ? "Where ads can show, what fills each space, and the rules for each. Tap a space on a map to jump to it."
            : "Ads are off: no ad spaces are drawn and no ad code loads, so pages are exactly as fast as without them. Set things up here, check them with the outlines, then turn them on."
        }
        notice={notice}
        actions={
          <form action={setAdsOnAction}>
            <input type="hidden" name="on" value={settings.on ? "0" : "1"} />
            <button
              type="submit"
              className={`rounded-full px-4 py-2 text-sm font-semibold ${
                settings.on
                  ? "border border-zinc-300 hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
                  : "bg-orange-500 text-white hover:bg-orange-600"
              }`}
            >
              {settings.on ? "Turn ads off" : "Turn ads on"}
            </button>
          </form>
        }
      />

      <dl className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[
          ["Running campaigns", String(running.length)],
          ["Views, last 7 days", views.toLocaleString("en-GB")],
          ["Clicks, last 7 days", clicks.toLocaleString("en-GB")],
          ["Click rate", clickRate(views, clicks)],
        ].map(([k, v]) => (
          <div key={k} className="rounded-xl border border-zinc-200 bg-white p-3 dark:border-zinc-800 dark:bg-zinc-900">
            <dt className="text-xs text-zinc-500">{k}</dt>
            <dd className="text-lg font-semibold">{v}</dd>
          </div>
        ))}
      </dl>

      {attention.length > 0 && (
        <section aria-label="Needs attention" className="flex flex-col gap-2 rounded-xl border border-zinc-200 bg-white p-3 dark:border-zinc-800 dark:bg-zinc-900">
          <h2 className="text-sm font-semibold">Needs your eye</h2>
          <ul className="flex flex-col gap-1.5">
            {attention.map(({ c, a }) => (
              <li key={`${c.id}-${a.text}`} className="flex items-start gap-2 text-sm">
                <Icon name={a.level === "warn" ? "warning" : "info"} className={`mt-0.5 size-4 shrink-0 ${a.level === "warn" ? "text-amber-600" : "text-zinc-500 dark:text-zinc-400"}`} />
                <span className="min-w-0">
                  <Link href={`/admin/ads/${c.id}`} className="font-medium hover:underline">
                    {c.name}
                  </Link>{" "}
                  <span className="text-zinc-600 dark:text-zinc-400">{a.text}</span>
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-zinc-500">
        <span>
          Advertise page:{" "}
          {settings.page.on ? (
            <Link href="/advertise" target="_blank" className="font-medium text-orange-700 hover:underline dark:text-orange-400">
              on, at /advertise
            </Link>
          ) : settings.page.holding ? (
            "holding page only"
          ) : (
            "off"
          )}
        </span>
        <span>· Media kits sent: {kitCount}</span>
        <Link href="/admin/ads/selling" className="underline hover:text-zinc-700 dark:hover:text-zinc-300">
          Selling
        </Link>
      </p>

      <section className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-zinc-50 p-3 sm:p-4 dark:border-zinc-800 dark:bg-zinc-950">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          <MapFrame title="Phone · deal list">
            <MapDeal />
            <MapSpace {...at("sponsored")} className="h-6" />
            <MapDeal />
            <MapSpace {...at("list")} className="h-6" />
            <MapDeal />
            <MapDeal />
            <MapSpace {...at("cards")} className="h-10">
              2 · Cards view
            </MapSpace>
          </MapFrame>
          <MapFrame title="Laptop · deal list">
            <div className="flex flex-1 gap-1">
              <MapSpace {...at("rail-left")} className="w-3 self-stretch" />
              <div className="flex flex-1 flex-col gap-1">
                <MapDeal />
                <MapSpace {...at("sponsored")} className="h-6" />
                <MapSpace {...at("list")} className="h-6" />
                <MapDeal />
              </div>
              <div className="flex w-6 flex-col gap-1">
                <div className={`${GREY} h-8`} />
                <MapSpace {...at("sidebar")} className="h-8" />
              </div>
              <MapSpace {...at("rail-right")} className="w-3 self-stretch" />
            </div>
          </MapFrame>
          <MapFrame title="Deal page">
            <div className={`${GREY} h-10`} />
            <div className={`${GREY} h-4`} />
            <MapSpace {...at("deal")} className="h-6" />
            <div className={`${GREY} h-8`} />
            <MapSpace {...at("deal-end")} className="h-6" />
            <MapDeal />
          </MapFrame>
          <MapFrame title="Blog article">
            <div className="h-2 w-3/4 rounded bg-zinc-200 dark:bg-zinc-700" />
            <div className={`${GREY} h-6`} />
            <MapSpace {...at("blog")} className="h-6" />
            <div className={`${GREY} h-6`} />
            <MapSpace {...at("blog")} className="h-6" />
            <div className={`${GREY} h-4`} />
            <MapSpace {...at("blog-end")} className="h-6" />
          </MapFrame>
          <MapFrame title="Community · conversations">
            <MapDeal />
            <MapDeal />
            <MapDeal />
            <MapSpace {...at("community-list")} className="h-6" />
            <MapDeal />
            <MapDeal />
          </MapFrame>
          <MapFrame title="Community · thread">
            <div className={`${GREY} h-8`} />
            <div className={`${GREY} h-6`} />
            <div className={`${GREY} h-6`} />
            <MapSpace {...at("community-thread")} className="h-6" />
            <div className={`${GREY} h-6`} />
            <div className={`${GREY} h-4`} />
            <MapSpace {...at("community-end")} className="h-6" />
          </MapFrame>
        </div>
        <p className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-zinc-500">
          {(["campaigns", "network", "empty", "off"] as State[]).map((k) => (
            <span key={k} className="flex items-center gap-1.5">
              <span className={`size-3 rounded ${STATE[k].map}`} />
              {k === "campaigns" ? "Your campaigns" : k === "network" ? "Ad network" : k === "empty" ? "On, nothing to show" : "Off"}
            </span>
          ))}
          <span>
            Ads on: {pagesOn.length === AD_PAGE_KINDS.length ? "every kind of page" : pagesOn.map((p) => p.label).join(", ") || "no pages"}.
          </span>
        </p>
      </section>

      <ul className="flex flex-col gap-2">
        {spaces.map(({ def, s, n, campaigns, state, pages }) => (
          <li
            key={def.id}
            id={`space-${def.id}`}
            className="flex scroll-mt-24 flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-3 sm:flex-row sm:items-center dark:border-zinc-800 dark:bg-zinc-900"
          >
            <div className="flex min-w-0 flex-1 items-start gap-3">
              <span className={`flex size-10 shrink-0 items-center justify-center rounded-xl text-sm font-bold ${STATE[state].map}`}>{n}</span>
              <div className="flex min-w-0 flex-col gap-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-medium">{def.name}</span>
                  <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${STATE[state].pill}`}>{STATE[state].label(campaigns)}</span>
                </div>
                <p className="text-sm text-zinc-500">{def.where}</p>
                <p className="text-xs text-zinc-500">
                  {rules(def, s)}
                  {state !== "off" && pages.length < def.pages.length && ` · not on ${def.pages.filter((p) => !pages.includes(p)).map((p) => AD_PAGE_KINDS.find((k) => k.value === p)!.label.toLowerCase()).join(", ")}`}
                </p>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <Link
                href={`/admin/ads/places#space-${def.id}`}
                className="inline-flex min-h-[36px] items-center rounded-lg border border-zinc-300 px-3.5 text-xs font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
              >
                Settings
              </Link>
              <Link
                href={def.id === "sponsored" ? "/admin/ads/new?kind=deal" : `/admin/ads/new?slot=${def.id}`}
                className="inline-flex min-h-[36px] items-center rounded-lg bg-orange-500 px-3.5 text-xs font-semibold text-white hover:bg-orange-600"
              >
                {def.id === "sponsored" ? "+ Sponsored deal" : "+ Campaign"}
              </Link>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
