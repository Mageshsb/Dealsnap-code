import { requirePermission } from "@/lib/auth";
import { getAdvertisers } from "@/lib/db";
import { getAdSettings } from "@/lib/ad-serving";
import { deleteAdvertiserAction, saveAdvertiserAction } from "@/lib/ad-actions";
import { AD_TEXT } from "@/lib/ads";
import AdsHeader from "@/components/admin/AdsHeader";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import { field, hint, label, panel, panelTitle } from "@/components/admin/formStyles";
import EmptyState from "@/components/EmptyState";

export const metadata = { title: "Advertisers" };

// The companies that buy ads, with who to talk to there. Private to admins.
function AdvertiserFields({ a }: { a?: { name: string; contact: string; notes: string } }) {
  return (
    <>
      <label className={label}>
        Name
        <input name="name" required maxLength={AD_TEXT.name} defaultValue={a?.name} className={field} />
      </label>
      <label className={label}>
        Contact (optional)
        <span className={hint}>Who you deal with and how to reach them.</span>
        <input name="contact" maxLength={200} defaultValue={a?.contact} className={field} />
      </label>
      <label className={label}>
        Notes (optional)
        <span className={hint}>Rates agreed, invoicing details, anything to remember.</span>
        <textarea name="notes" rows={3} maxLength={1000} defaultValue={a?.notes} className={field} />
      </label>
    </>
  );
}

export default async function AdvertisersPage({ searchParams }: { searchParams: Promise<{ notice?: string; error?: string }> }) {
  await requirePermission("ads.manage");
  const { notice, error } = await searchParams;
  const advertisers = getAdvertisers();

  return (
    <div className="flex max-w-2xl flex-col gap-4">
      <AdsHeader
        current="advertisers"
        on={getAdSettings().on}
        title="Advertisers"
        description="The companies that buy ads, with your contact and notes for each. Only admins see this."
        notice={notice}
        error={error}
      />

      <ul className="flex flex-col gap-2">
        {advertisers.map((a) => (
          <li key={a.id} className="rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
            <details className="group">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-3 p-3">
                <span className="flex min-w-0 flex-col">
                  <span className="truncate text-sm font-medium">{a.name}</span>
                  <span className="truncate text-xs text-zinc-500">
                    {a.campaigns} campaign{a.campaigns === 1 ? "" : "s"}
                    {a.contact && ` · ${a.contact}`}
                  </span>
                </span>
                <span className="shrink-0 text-xs font-medium text-orange-700 group-open:hidden dark:text-orange-400">Edit</span>
              </summary>
              <div className="flex flex-col gap-4 border-t border-zinc-100 p-3 dark:border-zinc-800">
                <form action={saveAdvertiserAction} className="flex flex-col gap-4">
                  <input type="hidden" name="id" value={a.id} />
                  <AdvertiserFields a={a} />
                  <div>
                    <button type="submit" className="rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600">
                      Save
                    </button>
                  </div>
                </form>
                {a.campaigns === 0 && (
                  <form action={deleteAdvertiserAction}>
                    <input type="hidden" name="id" value={a.id} />
                    <ConfirmSubmitButton confirmText={`Delete ${a.name}?`} className="text-sm font-medium text-red-600 hover:underline">
                      Delete this advertiser
                    </ConfirmSubmitButton>
                  </form>
                )}
              </div>
            </details>
          </li>
        ))}
        {advertisers.length === 0 && (
          <li>
            <EmptyState icon="handshake">
              <p>
                No advertisers yet. Add one here, or while making a campaign.
              </p>
            </EmptyState>
          </li>
        )}
      </ul>

      <form action={saveAdvertiserAction} className={panel}>
        <h2 className={panelTitle}>Add an advertiser</h2>
        <AdvertiserFields />
        <div>
          <button type="submit" className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600">
            Add
          </button>
        </div>
      </form>
    </div>
  );
}
