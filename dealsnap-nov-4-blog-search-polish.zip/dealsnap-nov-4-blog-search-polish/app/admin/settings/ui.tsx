// The look Settings' tabs share (app/admin/settings/page.tsx), also used by Earnings and Team → Rules.

export const card = "flex flex-col gap-4 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900";
export const input =
  "rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-900";
export const mono = `${input} font-mono`;
export const saveButton = "self-start rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600";
export const outlineButton =
  "self-start rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold text-zinc-700 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800";
export const hint = "text-xs text-zinc-500";

export function Checkbox({ name, defaultChecked, children }: { name: string; defaultChecked: boolean; children: React.ReactNode }) {
  return (
    <label className="flex items-start gap-2 text-sm">
      <input
        type="checkbox"
        name={name}
        defaultChecked={defaultChecked}
        className="mt-0.5 h-4 w-4 shrink-0 rounded border-zinc-300 accent-orange-500"
      />
      <span>{children}</span>
    </label>
  );
}
