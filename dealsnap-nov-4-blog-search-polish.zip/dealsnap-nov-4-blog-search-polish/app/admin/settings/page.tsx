import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { can, type Permission } from "@/lib/permissions";
import SectionTabs from "@/components/admin/SectionTabs";
import { getSiteSetting } from "@/lib/db";
import { getSiteSettings, MIN_LIST_DAYS } from "@/lib/site-settings";
import {
  setMaintenanceModeAction,
  saveGeneralSettingsAction,
  saveTrackingSettingsAction,
  saveSecuritySettingsAction,
  saveExtensionSettingsAction,
  saveSpamSettingsAction,
  saveBackupSettingsAction,
  saveEmailSettingsAction,
  saveDealRulesAction,
  saveTwoStepRuleAction,
  signOutEveryoneAction,
  saveApplePushKeyAction,
  removeApplePushKeyAction,
  saveGooglePushAccountAction,
  removeGooglePushAccountAction,
  saveAndroidAppLinksAction,
} from "@/lib/admin-actions";
import { secretStatus } from "@/lib/secrets";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import Icon from "@/components/Icon";
import { autoBackupsOn, listRestorePoints, listServerBackups } from "@/lib/backups";
import { MAX_UPLOAD_BYTES, sizeLabel } from "@/lib/backup-limits";
import RestoreUpload from "@/components/admin/RestoreUpload";
import { adminAlertsOn } from "@/lib/admin-alerts";
import { emailDeliveryReady } from "@/lib/email";
import { formatDate } from "@/lib/format";
import { Checkbox, card, hint, input, mono, outlineButton, saveButton } from "./ui";

import Notice from "@/components/admin/Notice";
import SiteBrandForm from "@/components/admin/SiteBrandForm";
import { getSiteBrand } from "@/lib/site-brand";
import { iconSrc, logoSrc } from "@/lib/site-brand-shared";
import { getSiteName } from "@/lib/site-url";
import { pictureStoreName } from "@/lib/picture-store";
import { THROWAWAY_DOMAINS, getBlockedDomains, getBlockedWords } from "@/lib/site-blocks";
export const metadata = { title: "Settings" };

// Each tab needs its own permission, so a tier can be given some of Settings without the rest.
// (Earnings has its own page next to Ads; the team's rules are in Team → Rules.)
const TABS = [
  { value: "general", label: "General", needs: "settings.manage" },
  { value: "tracking", label: "Tracking & code", needs: "settings.revenue" },
  { value: "security", label: "Security", needs: "settings.security" },
  { value: "data", label: "Data & backups", needs: "data.export" },
] as const satisfies readonly { value: string; label: string; needs: Permission }[];

type Tab = (typeof TABS)[number]["value"];

function NumberField({
  name,
  label,
  value,
  min,
  max,
}: {
  name: string;
  label: string;
  value: number;
  min: number;
  max: number;
}) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-sm font-medium" htmlFor={name}>
        {label}
      </label>
      <input id={name} name={name} type="number" min={min} max={max} defaultValue={value} className={input} />
    </div>
  );
}

export default async function AdminSettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ tab?: string; saved?: string; error?: string; note?: string }>;
}) {
  const viewer = await requirePermission("settings.manage");
  const params = await searchParams;
  const tabs = TABS.filter((t) => can(viewer.role, t.needs));
  const tab: Tab = tabs.some((t) => t.value === params.tab) ? (params.tab as Tab) : tabs[0].value;
  const mayRunMaintenance = can(viewer.role, "settings.security");
  const s = getSiteSettings();
  const brand = getSiteBrand();

  const backups = tab === "data" ? listServerBackups() : [];
  const mayRestore = tab === "data" && can(viewer.role, "data.restore");
  const restorePoints = mayRestore ? listRestorePoints() : [];
  const emailReady = emailDeliveryReady();
  const maintenanceOn = getSiteSetting("maintenance_mode") === "1";
  const maintenanceMessage =
    getSiteSetting("maintenance_message") ?? "We're doing some quick maintenance and will be back shortly.";

  return (
    <div className="flex max-w-2xl flex-col gap-6">
      <div>
        <h1 className="text-xl font-bold sm:text-2xl">Settings</h1>
        <p className="text-sm text-zinc-500">
          How the site behaves, how it keeps people safe, and your backups. Changes take effect straight away.
        </p>
      </div>

      <SectionTabs
        label="Settings sections"
        tabs={tabs.map((t) => ({ key: t.value, label: t.label, href: `/admin/settings?tab=${t.value}` }))}
        current={tab}
      />

      <Notice notice={params.saved ? "Saved." : params.note} error={params.error} />

      {tab === "general" && (
        <>
          <SiteBrandForm
            siteName={getSiteName()}
            logo={brand.logo && { src: logoSrc(brand.logo), w: brand.logo.w, h: brand.logo.h }}
            logoDark={brand.logoDark && { src: logoSrc(brand.logoDark, true), w: brand.logoDark.w, h: brand.logoDark.h }}
            icon={brand.icon && { src: iconSrc(brand.icon, "192"), w: 192, h: 192 }}
            showName={brand.showName}
            cardClass={card}
            hintClass={hint}
            saveClass={saveButton}
          />

          <form action={saveGeneralSettingsAction} className={card}>
            <div>
              <h2 className="font-semibold">Site details &amp; search engines</h2>
              <p className="text-sm text-zinc-500">What Google and social sites show for your homepage.</p>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium" htmlFor="siteTitle">Site title</label>
              <input id="siteTitle" name="siteTitle" defaultValue={s.siteTitle} maxLength={120} className={input} />
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium" htmlFor="siteDescription">Description</label>
              <textarea
                id="siteDescription"
                name="siteDescription"
                defaultValue={s.siteDescription}
                rows={2}
                maxLength={300}
                className={input}
              />
              <p className={hint}>One or two sentences. Search results often show this under your title.</p>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium" htmlFor="searchConsole">Google Search Console verification</label>
              <input
                id="searchConsole"
                name="searchConsole"
                defaultValue={s.searchConsoleToken}
                placeholder='Paste the meta tag Google gives you, or just its code'
                className={mono}
              />
              <p className={hint}>Optional. Lets you prove to Google that you own the site.</p>
            </div>

            <Checkbox name="hideFromSearchEngines" defaultChecked={s.hideFromSearchEngines}>
              <span className="font-medium">Hide this site from Google and other search engines</span>
              <span className="block text-xs text-zinc-500">
                Tick this on any test copy of the site. Untick it when you go live.
              </span>
            </Checkbox>

            <button type="submit" className={saveButton}>Save</button>
          </form>

          {mayRunMaintenance && (
            <div className={card}>
              <div>
                <h2 className="font-semibold">Maintenance mode</h2>
                <p className="text-sm text-zinc-500">
                  Show a holding page to every visitor except signed-in admins — useful while the backend is being
                  switched over or during an incident. Login stays reachable so admins can turn it back off.
                </p>
              </div>

              <form action={setMaintenanceModeAction} className="flex flex-col gap-4">
                <label className="flex items-center gap-2 text-sm font-medium">
                  <input
                    type="checkbox"
                    name="enabled"
                    value="true"
                    defaultChecked={maintenanceOn}
                    className="h-4 w-4 rounded border-zinc-300 accent-orange-500"
                  />
                  Enable maintenance mode
                </label>

                <div className="flex flex-col gap-1">
                  <label className="text-sm font-medium">Holding page message</label>
                  <textarea name="message" aria-label="What visitors see while it's on" defaultValue={maintenanceMessage} rows={3} className={input} />
                </div>

                <button type="submit" className={saveButton}>Save</button>
              </form>

              {maintenanceOn && (
                <p className="rounded-lg bg-amber-50 px-4 py-2 text-sm text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
                  <Icon name="construction" className="mr-1.5" />Maintenance mode is currently ON.
                </p>
              )}
            </div>
          )}

          <form action={saveEmailSettingsAction} className={card}>
            <div>
              <h2 className="font-semibold">Email</h2>
              <p className="text-sm text-zinc-500">
                {emailReady ? (
                  <>
                    <Icon name="circle-check" className="mr-1.5 text-emerald-700 dark:text-emerald-400" />
                    Set up: emails are being sent.
                  </>
                ) : (
                  <>
                    <Icon name="warning" className="mr-1.5 text-amber-600" />
                    Not set up yet, so nothing is sent: each email is saved on the server instead.
                  </>
                )}
              </p>
            </div>
            <div className="flex flex-col gap-1 text-sm">
              <p className="font-medium">{emailReady ? "What it sends" : "What switches on once it's set up"}</p>
              <ul className="list-disc pl-5 text-zinc-600 dark:text-zinc-400">
                <li>Password reset links</li>
                <li>Confirming new members&apos; email addresses (they can comment once confirmed)</li>
                <li>Members&apos; deal alerts and reply notifications (instantly or as a daily summary)</li>
                <li>A copy of every contact-form message</li>
                <li>Admin alerts, below</li>
              </ul>
            </div>
            {!emailReady && (
              <p className={hint}>
                To set it up: make an account at resend.com, verify the site&apos;s domain there, then add RESEND_API_KEY,
                EMAIL_FROM (like &ldquo;DealSnap &lt;alerts@yourdomain&gt;&rdquo;) and SITE_URL to the server&apos;s settings with
                the host. Nothing changes here: everything above starts on its own.
              </p>
            )}
            <Checkbox name="adminAlerts" defaultChecked={adminAlertsOn()}>
              <span className="font-medium">Email admins when something urgent is waiting</span>
              <span className="block text-xs text-zinc-500">
                Deals to approve, reports, messages, an Awin problem: at most every 6 hours, and only when something new is
                waiting. Sent to every admin&apos;s account email.
              </span>
            </Checkbox>
            <button type="submit" className={saveButton}>Save</button>
          </form>

          <form action={saveExtensionSettingsAction} className={card}>
            <div>
              <h2 className="font-semibold">Browser extension</h2>
              <p className="text-sm text-zinc-500">
                Once the DealSnap extension is published, paste its store pages here. Some shops (Argos, Currys, Tesco…)
                won&apos;t let the site read their pages, but the extension can. While a link is set, the post form suggests
                the extension to people on a computer when they paste one of those shops&apos; links.
              </p>
            </div>
            <div className="flex flex-col gap-1">
              <label htmlFor="extensionChromeUrl" className="text-sm font-medium">Chrome Web Store page</label>
              <input
                id="extensionChromeUrl"
                name="extensionChromeUrl"
                type="url"
                defaultValue={s.extensionChromeUrl}
                placeholder="https://chromewebstore.google.com/detail/dealsnap/…"
                className={input}
              />
              <p className="text-xs text-zinc-500">Also used for Edge, Brave and Opera, which run Chrome extensions.</p>
            </div>
            <div className="flex flex-col gap-1">
              <label htmlFor="extensionFirefoxUrl" className="text-sm font-medium">
                Firefox Add-ons page <span className="font-normal text-zinc-500 dark:text-zinc-400">(optional)</span>
              </label>
              <input
                id="extensionFirefoxUrl"
                name="extensionFirefoxUrl"
                type="url"
                defaultValue={s.extensionFirefoxUrl}
                placeholder="https://addons.mozilla.org/en-GB/firefox/addon/dealsnap/"
                className={input}
              />
            </div>
            <button type="submit" className={saveButton}>Save</button>
          </form>

          <form action={saveDealRulesAction} className={card}>
            <div>
              <h2 className="font-semibold">Ended deals</h2>
              <p className="text-sm text-zinc-500">When members&apos; &ldquo;this has ended&rdquo; reports mark a deal as ended.</p>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <NumberField name="endedReportsToExpire" label="Mark a deal ended after this many members say so" value={s.endedReportsToExpire} min={1} max={50} />
              <NumberField name="endedReportsMax" label="…rising for popular deals, up to at most" value={s.endedReportsMax} min={1} max={50} />
            </div>
            <p className={hint}>
              The first number is for small deals; popular ones need a few more (with 3 and 8: 100 hearts needs 5, 400
              needs 7, 625 or more needs 8). Make both the same to never ask for more. One moderator or admin saying so is
              always enough. Undo it from the deal&apos;s row in Deals; members who&apos;ve been undone twice in six months
              stop counting towards ending deals, though you still see their reports.
            </p>
            <div className="grid grid-cols-1 gap-4 border-t border-zinc-100 pt-4 sm:grid-cols-2 dark:border-zinc-800">
              <NumberField name="dealListDays" label="Lists and search reach back this many days" value={s.dealListDays} min={MIN_LIST_DAYS} max={1000} />
            </div>
            <p className={hint}>
              Deals posted longer ago than this drop out of the lists, search and counts, whether they&apos;ve ended or not.
              Their own page keeps working, so links and Google results don&apos;t break. It starts at 365 and can&apos;t go
              lower: Most loved offers &ldquo;Last 12 months&rdquo;, which needs a full year behind it. Raise it if you want
              older deals to stay findable. Memory and speed follow how many deals fall inside it, so watch the server&apos;s
              memory after months of heavy posting.
            </p>
            <button type="submit" className={saveButton}>Save</button>
          </form>

          {mayRunMaintenance && <PhoneAppsCard />}
        </>
      )}

      {tab === "tracking" && (
        <form action={saveTrackingSettingsAction} className="flex flex-col gap-6">
          <div className={card}>
            <div>
              <h2 className="font-semibold">Google Analytics / Tag Manager</h2>
              <p className="text-sm text-zinc-500">
                Paste the code Google gave you — the whole snippet or just the ID (starts <code>G-</code> for Analytics,{" "}
                <code>GTM-</code> for Tag Manager). We pick out the ID and add it to every public page for you.
              </p>
            </div>

            <div className="flex flex-col gap-1">
              <textarea
                name="googleCode"
                defaultValue={[s.gaId, s.gtmId].filter(Boolean).join("\n")}
                rows={4}
                placeholder="G-XXXXXXXXXX"
                className={mono}
              />
              <p className={hint}>Leave empty to switch tracking off. Use Analytics <em>or</em> Tag Manager, not both for the same property, or visits get counted twice.</p>
              <p className="rounded-lg bg-amber-50 px-4 py-2 text-xs text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
                <Icon name="warning" className="mr-1.5" />
                Put ad pixels (Meta, TikTok and so on) in Custom code below, never inside Tag Manager. Custom code waits for a
                visitor&apos;s yes to marketing cookies and is named on the cookie banner; a non-Google tag inside Tag Manager
                ignores the banner unless you set up its consent check in Tag Manager yourself.
              </p>
            </div>

            <p
              className={`rounded-lg px-4 py-2 text-sm ${
                s.gaId || s.gtmId
                  ? "bg-green-50 text-green-800 dark:bg-green-950/40 dark:text-green-300"
                  : "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300"
              }`}
            >
              {s.gaId || s.gtmId ? (
                <>
                  <Icon name="circle-check" className="mr-1.5" />
                  Set up: {[s.gaId && `Analytics ${s.gaId}`, s.gtmId && `Tag Manager ${s.gtmId}`].filter(Boolean).join(" · ")}
                </>
              ) : (
                "Not set up yet."
              )}
            </p>

            <p className="text-sm text-zinc-600 dark:text-zinc-300">
              <Icon name="cookie" className="mr-1.5 text-orange-700 dark:text-orange-400" />
              UK law needs a visitor&apos;s yes before analytics or the custom code below can run, so while either is set
              up, every visitor gets a cookie banner and nothing optional loads until they accept it. With neither, there&apos;s
              no banner.{" "}
              <a href="/?cookie-preview" target="_blank" className="font-medium text-orange-700 hover:underline dark:text-orange-400">
                Preview the banner
              </a>
            </p>

            <p className="rounded-lg bg-zinc-100 px-4 py-2 text-xs text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">
              Tracking never runs inside /admin, and it&apos;s switched off on <code>localhost</code> so your own testing
              doesn&apos;t pollute your numbers. It starts working once the site is on your real domain.
            </p>
          </div>

          <div className={card}>
            <div>
              <h2 className="font-semibold">Custom code (advanced)</h2>
              <p className="text-sm text-zinc-500">
                For anything else that comes as a snippet — a Meta pixel, an advert tag and so on. Works like the
                &ldquo;headers and footers&rdquo; boxes in WordPress. It counts as marketing on the cookie banner, so it only
                runs for visitors who allow marketing cookies.
              </p>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium" htmlFor="marketingPartners">Who is this code from?</label>
              <input
                id="marketingPartners"
                name="marketingPartners"
                defaultValue={s.marketingPartners}
                maxLength={120}
                placeholder="e.g. Meta, TikTok"
                className={input}
              />
              <p className={hint}>
                Needed whenever there&apos;s code below: the cookie banner and privacy policy name these companies, because
                visitors have to know who gets their data.
              </p>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium" htmlFor="headCode">Header code</label>
              <textarea id="headCode" name="headCode" defaultValue={s.headCode} rows={5} className={mono} />
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium" htmlFor="footerCode">Footer code</label>
              <textarea id="footerCode" name="footerCode" defaultValue={s.footerCode} rows={5} className={mono} />
            </div>

            <p className="rounded-lg bg-amber-50 px-4 py-2 text-xs text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
              <Icon name="warning" className="mr-1.5" />Only paste code from a source you trust. It runs on every public page, so it can see everything a
              visitor does. This is why admin accounts need strong passwords.
            </p>
          </div>

          <button type="submit" className={saveButton}>Save</button>
        </form>
      )}

      {tab === "security" && (
        <>
          <form action={saveTwoStepRuleAction} className={card}>
            <div>
              <h2 className="font-semibold">Two-step login for the team</h2>
              <p className="text-sm text-zinc-500">
                A code from a phone app as well as a password, so a stolen password alone can&apos;t get in.
              </p>
            </div>
            <Checkbox name="requireTwoStepForStaff" defaultChecked={s.requireTwoStepForStaff}>
              <span className="font-medium">Require two-step login for admins, moderators and helpers</span>
              <span className="block text-xs text-zinc-500">
                Until they set it up, admins and moderators can&apos;t open the admin area and helpers can&apos;t fix deals.
                Turn yours on first.
              </span>
            </Checkbox>
            <button type="submit" className={saveButton}>Save</button>
          </form>

          <form action={saveSecuritySettingsAction} className={card}>
            <div>
              <h2 className="font-semibold">Sign-in protection</h2>
              <p className="text-sm text-zinc-500">
                Stops people guessing passwords: after too many wrong attempts, sign-in is paused for a while.
              </p>
            </div>

            <Checkbox name="loginProtection" defaultChecked={s.loginProtection}>
              <span className="font-medium">Lock out repeated failed sign-ins</span>
            </Checkbox>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium" htmlFor="loginMaxAttempts">Wrong attempts allowed</label>
                <input
                  id="loginMaxAttempts"
                  name="loginMaxAttempts"
                  type="number"
                  min={3}
                  max={20}
                  defaultValue={s.loginMaxAttempts}
                  className={input}
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium" htmlFor="loginLockoutMinutes">Lock out for (minutes)</label>
                <input
                  id="loginLockoutMinutes"
                  name="loginLockoutMinutes"
                  type="number"
                  min={1}
                  max={1440}
                  defaultValue={s.loginLockoutMinutes}
                  className={input}
                />
              </div>
            </div>

            <button type="submit" className={saveButton}>Save</button>
          </form>

          <form action={saveSpamSettingsAction} className={card}>
            <div>
              <h2 className="font-semibold">Spam protection</h2>
              <p className="text-sm text-zinc-500">
                Limits on how fast members can post. Brand-new accounts get tighter limits, which stops most spam
                before it starts. Staff are never limited.
              </p>
            </div>
            <Checkbox name="spamProtection" defaultChecked={s.spamProtection}>
              <span className="font-medium">Turn on posting limits</span>
            </Checkbox>
            <Checkbox name="blockLinksFromNewAccounts" defaultChecked={s.blockLinksFromNewAccounts}>
              <span className="font-medium">Block links in comments from new accounts</span>
            </Checkbox>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <NumberField name="newAccountDays" label="An account counts as new for (days)" value={s.newAccountDays} min={0} max={90} />
              <div className="hidden sm:block" />
              <NumberField name="newAccountDealsPerDay" label="Deals per day: new accounts" value={s.newAccountDealsPerDay} min={1} max={100} />
              <NumberField name="dealsPerDay" label="Deals per day: everyone else" value={s.dealsPerDay} min={1} max={500} />
              <NumberField name="newAccountCommentsPerHour" label="Comments per hour: new accounts" value={s.newAccountCommentsPerHour} min={1} max={500} />
              <NumberField name="commentsPerHour" label="Comments per hour: everyone else" value={s.commentsPerHour} min={1} max={1000} />
            </div>
            <label className="flex flex-col gap-1 text-sm font-medium">
              Words that can&apos;t be used
              <textarea
                name="blockedWords"
                rows={4}
                defaultValue={getBlockedWords().join("\n")}
                placeholder={"One word or phrase per line"}
                className="resize-y rounded-lg border border-zinc-300 bg-white px-3 py-2 text-base font-normal outline-none focus:border-orange-500 sm:text-sm dark:border-zinc-700 dark:bg-zinc-900"
              />
              <span className="text-xs font-normal text-zinc-500">
                In deals, comments and the Community. A post with one is refused with a polite message that doesn&apos;t say which word. Whole words
                only, any capitals. The Community also has its own list in Admin → Community.
              </span>
            </label>
            <label className="flex flex-col gap-1 text-sm font-medium">
              Email domains that can&apos;t join
              <textarea
                name="blockedDomains"
                rows={3}
                defaultValue={getBlockedDomains().join("\n")}
                placeholder={"example.com"}
                className="resize-y rounded-lg border border-zinc-300 bg-white px-3 py-2 text-base font-normal outline-none focus:border-orange-500 sm:text-sm dark:border-zinc-700 dark:bg-zinc-900"
              />
              <span className="text-xs font-normal text-zinc-500">
                Throwaway inboxes are already refused ({THROWAWAY_DOMAINS.length} well-known ones, like mailinator.com). Add others here, one per line. People
                already signed up aren&apos;t affected.
              </span>
            </label>
            <button type="submit" className={saveButton}>Save</button>
          </form>

          <div className={card}>
            <div>
              <h2 className="font-semibold">Emergency sign-out</h2>
              <p className="text-sm text-zinc-500">
                If you think an account has been taken over, sign people out. They just log in again; you stay signed in.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <form action={signOutEveryoneAction}>
                <input type="hidden" name="scope" value="staff" />
                <ConfirmSubmitButton
                  confirmText="Sign out every moderator and admin (except you)?"
                  className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
                >
                  Sign out all staff
                </ConfirmSubmitButton>
              </form>
              <form action={signOutEveryoneAction}>
                <input type="hidden" name="scope" value="everyone" />
                <ConfirmSubmitButton
                  confirmText="Sign out EVERY member of the site (except you)? Everyone will have to log in again."
                  className="rounded-full border border-red-300 px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/40"
                >
                  Sign out everyone
                </ConfirmSubmitButton>
              </form>
            </div>
          </div>

          <div className={card}>
            <div>
              <h2 className="font-semibold">Already handled for you</h2>
              <p className="text-sm text-zinc-500">These are built in, so there&apos;s nothing to switch on.</p>
            </div>
            <ul className="flex flex-col gap-2 text-sm text-zinc-600 dark:text-zinc-300">
              <li><Icon name="lock-keyhole" className="mr-1.5" />Passwords are stored scrambled (hashed and salted), never as plain text.</li>
              <li><Icon name="shield" className="mr-1.5" />Admin pages need a staff login, and moderators only see their own tools.</li>
              <li><Icon name="key" className="mr-1.5" />Staff can turn on two-step login, and you can make it required above.</li>
              <li><Icon name="ban" className="mr-1.5" />Suspended members are signed out straight away and can&apos;t post.</li>
              <li><Icon name="cookie" className="mr-1.5" />Login cookies are hidden from scripts, and sent over HTTPS only on the live site.</li>
              <li><Icon name="brick-wall" className="mr-1.5" />Pages tell browsers to refuse being embedded in other sites and to stick to the declared content types.</li>
              <li><Icon name="construction" className="mr-1.5" />New deals from members can be held for approval before they appear.</li>
            </ul>
            <p className={hint}>
              HTTPS certificates and protection against floods of traffic come from your hosting. You can download a
              backup any time from the Data &amp; backups tab; automatic backups get set up with the host.
            </p>
          </div>
        </>
      )}

      {tab === "data" && (
        <>
          <div className={card}>
            <div>
              <h2 className="font-semibold">Download a backup</h2>
              <p className="text-sm text-zinc-500">
                Two downloads together make a whole copy of the site. The <b>database backup</b> holds members, deals, comments, settings, logos,
                profile photos and the activity log, and is what &quot;Restore&quot; uses. The <b>pictures</b> are the photos members add to deals,
                comments and Community posts. Keep copies somewhere safe (not on this computer only).
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              {/* File downloads, so plain links on purpose (not pages for next/link to open). */}
              {/* eslint-disable-next-line @next/next/no-html-link-for-pages */}
              <a href="/admin/backup" className={`${saveButton} inline-block`}>
                Download database backup
              </a>
              {pictureStoreName().kind === "disk" && (
                // eslint-disable-next-line @next/next/no-html-link-for-pages
                <a href="/admin/backup?pictures=1" className={`${saveButton} inline-block`}>
                  Download pictures
                </a>
              )}
            </div>
            {pictureStoreName().kind === "s3" && (
              <p className={hint}>
                Pictures are kept in your cloud storage ({pictureStoreName().where}), which has its own copies, so there&apos;s nothing to download here.
              </p>
            )}
            <p className={hint}>
              <Icon name="warning" className="mr-1.5" />The database file contains members&apos; email addresses and scrambled passwords, so treat it like a password.
              Downloads are recorded in the activity log.
            </p>
          </div>
          <form action={saveBackupSettingsAction} className={card}>
            <div>
              <h2 className="font-semibold">Daily backups on the server</h2>
              <p className="text-sm text-zinc-500">
                A copy of everything is made each day and the last 7 are kept, so a mistake (a bad bulk change, a deleted
                member) can be undone. They&apos;re on the same server as the site, so they don&apos;t protect against losing the
                server: the host&apos;s own backups, or the download above kept somewhere safe, cover that. Stores&apos; product
                lists aren&apos;t included; Awin rebuilds them.
              </p>
            </div>
            <Checkbox name="autoBackups" defaultChecked={autoBackupsOn()}>
              <span className="font-medium">Make a backup every day</span>
            </Checkbox>
            {backups.length > 0 ? (
              <ul className="flex flex-col divide-y divide-zinc-100 rounded-lg border border-zinc-200 text-sm dark:divide-zinc-800 dark:border-zinc-800">
                {backups.map((b) => (
                  <li key={b.name} className="flex items-center justify-between gap-3 px-3 py-2">
                    <span>
                      {formatDate(b.day)} <span className="text-zinc-500 dark:text-zinc-400">· {(b.bytes / 1048576).toFixed(1)}MB</span>
                    </span>
                    <a href={`/admin/backup?file=${encodeURIComponent(b.name)}`} className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
                      <Icon name="download" className="mr-1" />
                      Download
                    </a>
                  </li>
                ))}
              </ul>
            ) : (
              <p className={hint}>No daily backups yet. The first is made within the hour.</p>
            )}
            <button type="submit" className={saveButton}>Save</button>
          </form>
          {mayRestore && (
            <div className={card}>
              <div>
                <h2 className="font-semibold">Restore from a backup</h2>
                <p className="text-sm text-zinc-500">
                  Put the whole site back to how it was in a backup: for a bad mistake, or to move to a new server. It replaces everything, so you
                  confirm on the next page, and a safety copy of the site as it is now is saved first.
                </p>
              </div>
              {restorePoints.length > 0 ? (
                <ul className="flex flex-col divide-y divide-zinc-100 rounded-lg border border-zinc-200 text-sm dark:divide-zinc-800 dark:border-zinc-800">
                  {restorePoints.map((p) => (
                    <li key={p.id} className="flex items-center justify-between gap-3 px-3 py-2">
                      <span className="min-w-0">
                        {p.label} <span className="text-zinc-500 dark:text-zinc-400">· {(p.bytes / 1048576).toFixed(1)}MB</span>
                      </span>
                      <Link href={`/admin/restore?from=${encodeURIComponent(p.id)}`} className="shrink-0 font-medium text-orange-700 dark:text-orange-400 hover:underline">
                        Restore…
                      </Link>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className={hint}>Nothing to restore from yet. The first daily backup is made within the hour, or upload one you downloaded.</p>
              )}
              <div className="flex flex-col gap-2 border-t border-zinc-100 pt-4 dark:border-zinc-800">
                <h3 className="text-sm font-semibold">Or upload a backup you downloaded</h3>
                <RestoreUpload maxBytes={MAX_UPLOAD_BYTES} />
                <p className={hint}>
                  Files up to {sizeLabel(MAX_UPLOAD_BYTES)}. Some hosts and Cloudflare&apos;s free plan refuse uploads over 100MB: if yours does, put the file in the server&apos;s
                  backups folder named like dealsnap-2026-11-03.db and it appears in the list above.
                </p>
              </div>
            </div>
          )}
          <div className={card}>
            <div>
              <h2 className="font-semibold">Export to a spreadsheet</h2>
              <p className="text-sm text-zinc-500">CSV files that open in Excel, Numbers or Google Sheets.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              {[
                ["deals", "Deals"],
                ["users", "Members"],
                ["comments", "Comments"],
                ["activity", "Staff activity"],
              ].map(([kind, label]) => (
                <a
                  key={kind}
                  href={`/admin/export/${kind}`}
                  className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
                >
                  <Icon name="download" className="mr-1.5" />{label}
                </a>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// The phone apps' keys (mobile/README.md walks through getting them). Saved
// encrypted, never shown again: only their last few characters.
function PhoneAppsCard() {
  const apple = secretStatus("apple_push_key");
  const google = secretStatus("google_push_account");
  const fingerprints = getSiteSetting("app_android_sha256") ?? "";
  const saved = (k: NonNullable<typeof apple>, what: string) =>
    k.readable ? (
      <p className="text-sm text-zinc-600 dark:text-zinc-300">
        <Icon name="key" className="mr-1.5 text-zinc-500 dark:text-zinc-400" />
        {what} saved (ending <span className="font-mono">{k.hint}</span>) by {k.savedBy} on {formatDate(k.savedAt)}.
      </p>
    ) : (
      <p className="text-sm text-amber-700 dark:text-amber-400">The saved key can&apos;t be unlocked any more (the site&apos;s secret key changed). Save it again below.</p>
    );

  return (
    <div className={card}>
      <div>
        <h2 className="font-semibold">Phone apps</h2>
        <p className="text-sm text-zinc-500">
          The keys that let the iPhone and Android apps get notifications, and open DealSnap links. Paste them here, never in an
          email or chat. They&apos;re saved scrambled and never shown again.
        </p>
      </div>

      <form action={saveApplePushKeyAction} className="flex flex-col gap-3 border-t border-zinc-100 pt-4 dark:border-zinc-800">
        <h3 className="text-sm font-semibold">iPhone (Apple)</h3>
        {apple && saved(apple, "Key")}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="flex flex-col gap-1">
            <label htmlFor="keyId" className="text-sm font-medium">Key ID</label>
            <input id="keyId" name="keyId" required maxLength={10} autoComplete="off" className={mono} />
          </div>
          <div className="flex flex-col gap-1">
            <label htmlFor="teamId" className="text-sm font-medium">Team ID</label>
            <input id="teamId" name="teamId" required maxLength={10} autoComplete="off" defaultValue={getSiteSetting("app_apple_team_id") ?? ""} className={mono} />
          </div>
        </div>
        <div className="flex flex-col gap-1">
          <label htmlFor="key" className="text-sm font-medium">The .p8 key</label>
          <textarea id="key" name="key" required rows={4} autoComplete="off" spellCheck={false} placeholder="-----BEGIN PRIVATE KEY-----" className={mono} />
          <p className={hint}>Apple Developer → Certificates, IDs &amp; Profiles → Keys → a key with Apple Push Notifications service. Open the file in TextEdit and paste all of it.</p>
        </div>
        <button type="submit" className={saveButton}>{apple ? "Replace" : "Save"}</button>
      </form>
      {apple && (
        <form action={removeApplePushKeyAction} className="-mt-2">
          <ConfirmSubmitButton confirmText="Remove the Apple key? iPhone notifications stop until a new one is saved." confirmLabel="Remove" className={outlineButton}>
            Remove
          </ConfirmSubmitButton>
        </form>
      )}

      <form action={saveGooglePushAccountAction} className="flex flex-col gap-3 border-t border-zinc-100 pt-4 dark:border-zinc-800">
        <h3 className="text-sm font-semibold">Android (Google Firebase)</h3>
        {google && saved(google, "Account")}
        <div className="flex flex-col gap-1">
          <label htmlFor="account" className="text-sm font-medium">Service account (.json)</label>
          <textarea id="account" name="account" required rows={4} autoComplete="off" spellCheck={false} placeholder='{ "type": "service_account", …' className={mono} />
          <p className={hint}>Firebase → Project settings → Service accounts → Generate new private key. Open the file and paste all of it.</p>
        </div>
        <button type="submit" className={saveButton}>{google ? "Replace" : "Save"}</button>
      </form>
      {google && (
        <form action={removeGooglePushAccountAction} className="-mt-2">
          <ConfirmSubmitButton confirmText="Remove the Firebase account? Android notifications stop until a new one is saved." confirmLabel="Remove" className={outlineButton}>
            Remove
          </ConfirmSubmitButton>
        </form>
      )}

      <form action={saveAndroidAppLinksAction} className="flex flex-col gap-3 border-t border-zinc-100 pt-4 dark:border-zinc-800">
        <div className="flex flex-col gap-1">
          <label htmlFor="fingerprints" className="text-sm font-medium">Android app&apos;s SHA-256 fingerprint</label>
          <input id="fingerprints" name="fingerprints" defaultValue={fingerprints} autoComplete="off" placeholder="AB:CD:…" className={mono} />
          <p className={hint}>Google Play Console → Test and release → App integrity → App signing key certificate. Lets DealSnap links open in the Android app. Not secret.</p>
        </div>
        <button type="submit" className={saveButton}>Save</button>
      </form>
    </div>
  );
}
