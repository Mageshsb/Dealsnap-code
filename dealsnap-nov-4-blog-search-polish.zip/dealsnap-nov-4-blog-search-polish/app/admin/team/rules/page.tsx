import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getSiteSettings } from "@/lib/site-settings";
import { saveTeamRulesAction } from "@/lib/admin-actions";
import TeamHeader from "@/components/admin/TeamHeader";
import { card, hint, input, saveButton } from "../../settings/ui";

import Notice from "@/components/admin/Notice";
export const metadata = { title: "Team rules" };

function NumberField({ name, label, value, min, max }: { name: string; label: string; value: number; min: number; max: number }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-sm font-medium" htmlFor={name}>
        {label}
      </label>
      <input id={name} name={name} type="number" min={min} max={max} defaultValue={value} className={input} />
    </div>
  );
}

// Team → Rules: how new moderators start, when the admins get warned about
// someone, and the guidelines everyone works to. (Two-step login for staff
// is in Settings → Security, with the rest of signing in.)
export default async function TeamRulesPage({ searchParams }: { searchParams: Promise<{ saved?: string }> }) {
  await requirePermission("settings.manage");
  const { saved } = await searchParams;
  const s = getSiteSettings();

  return (
    <div className="flex flex-col gap-4">
      <TeamHeader current="rules" rules description="How new moderators start, when you get warned, and the guidelines the team follows." />

      <Notice notice={saved ? "Saved." : undefined} />

      <form action={saveTeamRulesAction} className={`max-w-2xl ${card}`}>
        <div>
          <h2 className="font-semibold">New moderators and warnings</h2>
          <p className="text-sm text-zinc-500">
            A moderator on probation has everything they do checked by an admin. You&apos;re warned on the Dashboard and in
            the Activity log when someone does far more than usual in an hour.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <NumberField name="probationDays" label="Probation for new moderators (days, 0 = none)" value={s.probationDays} min={0} max={365} />
          <NumberField name="flagRemovalsPerHour" label="Warn me at this many removals in an hour" value={s.flagRemovalsPerHour} min={2} max={500} />
          <NumberField name="flagActionsPerHour" label="…or this many actions in an hour" value={s.flagActionsPerHour} min={5} max={1000} />
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium" htmlFor="modGuidelines">Guidelines</label>
          <textarea id="modGuidelines" name="modGuidelines" defaultValue={s.modGuidelines} rows={14} maxLength={8000} className={input} />
          <p className={hint}>
            Moderators see these on their{" "}
            <Link href="/admin/guidelines" className="underline">
              Guidelines
            </Link>{" "}
            page. Leave empty to go back to the default.
          </p>
        </div>
        <button type="submit" className={saveButton}>Save</button>
      </form>
    </div>
  );
}
