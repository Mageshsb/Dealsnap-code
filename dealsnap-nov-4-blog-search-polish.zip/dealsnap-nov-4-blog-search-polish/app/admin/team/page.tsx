import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getStaffUsersAdmin, getLastAuditByActor, getLastEditByEditor } from "@/lib/db";
import { ROLE_LABELS, can } from "@/lib/permissions";
import { TEAM_RANGES, rangeStart, teamRow } from "@/lib/staff-impact";
import { timeAgo } from "@/lib/format";
import TeamHeader from "@/components/admin/TeamHeader";
import SelectField from "@/components/SelectField";
import UserAvatar from "@/components/UserAvatar";
import Icon from "@/components/Icon";
import RangeSwitch from "@/components/staff/RangeSwitch";
import Pager from "@/components/admin/Pager";
import { searchField } from "@/components/admin/formStyles";

export const metadata = { title: "Team" };

const PAGE_SIZE = 25;

const RANKS = [
  { value: "all", label: "All ranks" },
  { value: "admin", label: "Admins" },
  { value: "moderator", label: "Moderators" },
  { value: "helper", label: "Helpers" },
] as const;

// Each sort puts the most interesting people first for what it measures; the
// last two are for spotting trouble ("lowest stood", "most edits per deal").
const SORTS = {
  improved: "Most deals improved",
  ended: "Most marked ended",
  reviewed: "Most reviewed",
  comments: "Most comments handled",
  stood: "Lowest “stood” first",
  repeat: "Most edits per deal",
  recent: "Most recently active",
  name: "Name A to Z",
} as const;
type SortKey = keyof typeof SORTS;

const RANK_ORDER: Record<string, number> = { admin: 0, moderator: 1, helper: 2 };

type Row = { id: string; username: string; role: string; avatarUrl: string | null; n: ReturnType<typeof teamRow>; lastActive: string | null };

// How each helper, moderator and admin has been getting on, for a time block
// you choose: recognition for the ones doing well, a nudge to look where
// something seems off. Every number counts each deal once, and only real
// changes (see lib/deal-changes.ts).
export default async function AdminTeamPage({
  searchParams,
}: {
  searchParams: Promise<{ days?: string; rank?: string; sort?: string; show?: string; q?: string; page?: string }>;
}) {
  const viewer = await requirePermission("activity.view");
  const sp = await searchParams;
  const range = TEAM_RANGES.find((r) => r.key === sp.days) ?? TEAM_RANGES[2];
  const rank = RANKS.find((r) => r.value === sp.rank)?.value ?? "all";
  const sort: SortKey = sp.sort && sp.sort in SORTS ? (sp.sort as SortKey) : "improved";
  const flaggedOnly = sp.show === "flagged";
  const q = (sp.q ?? "").trim().slice(0, 40);
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);

  const since = rangeStart(range.days);
  const lastAudit = getLastAuditByActor();
  const lastEdit = getLastEditByEditor();
  const everyone: Row[] = getStaffUsersAdmin()
    .filter((u) => u.role in RANK_ORDER && !u.deletedAt)
    .map((u) => {
      const times = [lastAudit.get(u.id), lastEdit.get(u.id)].filter((t): t is string => !!t).sort();
      return { id: u.id, username: u.username, role: u.role, avatarUrl: u.avatarUrl, n: teamRow(u.id, since), lastActive: times.at(-1) ?? null };
    });

  let rows = everyone
    .filter((r) => rank === "all" || r.role === rank)
    .filter((r) => !flaggedOnly || r.n.flags.length > 0)
    .filter((r) => !q || r.username.toLowerCase().includes(q.toLowerCase()));
  const by: Record<SortKey, (a: Row, b: Row) => number> = {
    improved: (a, b) => b.n.improved - a.n.improved,
    ended: (a, b) => b.n.ended - a.n.ended,
    reviewed: (a, b) => b.n.reviewed - a.n.reviewed,
    comments: (a, b) => b.n.comments - a.n.comments,
    // Nobody with too few fixes to have a score sorts as if perfect.
    stood: (a, b) => (a.n.kept ?? 101) - (b.n.kept ?? 101),
    repeat: (a, b) => (b.n.editsPerDeal ?? 0) - (a.n.editsPerDeal ?? 0),
    recent: (a, b) => (b.lastActive ?? "").localeCompare(a.lastActive ?? ""),
    name: (a, b) => a.username.localeCompare(b.username),
  };
  rows = rows.sort((a, b) => by[sort](a, b) || RANK_ORDER[a.role] - RANK_ORDER[b.role] || a.username.localeCompare(b.username));

  const total = rows.length;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const pageRows = rows.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const flaggedCount = everyone.filter((r) => r.n.flags.length > 0).length;
  const sum = (pick: (r: Row) => number) => everyone.reduce((n, r) => n + pick(r), 0);

  function href(over: Record<string, string | undefined>) {
    const params = new URLSearchParams();
    const next = { days: range.key, rank, sort, show: flaggedOnly ? "flagged" : undefined, q: q || undefined, ...over };
    for (const [k, v] of Object.entries(next)) if (v && !(k === "days" && v === "30") && !(k === "rank" && v === "all") && !(k === "sort" && v === "improved")) params.set(k, v);
    const qs = params.toString();
    return qs ? `/admin/team?${qs}` : "/admin/team";
  }

  const cols: { label: string; value: (r: Row) => string | number }[] = [
    { label: "Improved", value: (r) => r.n.improved },
    { label: "Ended", value: (r) => r.n.ended },
    { label: "Reviewed", value: (r) => (r.role === "helper" ? "–" : r.n.reviewed) },
    { label: "Comments", value: (r) => (r.role === "helper" ? "–" : r.n.comments) },
    { label: "Escalated", value: (r) => (r.role === "helper" ? "–" : r.n.escalated) },
    { label: "Stood", value: (r) => (r.n.kept === null ? "–" : `${r.n.kept}%`) },
    { label: "Edits per deal", value: (r) => r.n.editsPerDeal ?? "–" },
  ];
  // At the site's width each number column is about 60px: headings are small
  // sentence-case words (not capitals, which ran together) and may wrap.
  const grid = "lg:grid lg:grid-cols-[minmax(0,2.6fr)_repeat(7,minmax(0,1fr))_minmax(0,1.2fr)] lg:items-center lg:gap-2";

  return (
    <div className="flex flex-col gap-4">
      <TeamHeader
        current="people"
        rules={can(viewer.role, "settings.manage")}
        description="How helpers, moderators and admins are getting on. Each deal counts once however often it's edited, and only real changes count."
        side={<RangeSwitch ranges={TEAM_RANGES} current={range.key} href={(k) => href({ days: k, page: undefined })} />}
      />

      <p className="text-sm text-zinc-600 dark:text-zinc-400">
        {range.label === "All time" ? "All time" : `Last ${range.label}`}: {sum((r) => r.n.improved)} deals improved, {sum((r) => r.n.ended)} marked ended
        {flaggedCount > 0 ? (
          <>
            {" · "}
            <Link href={href({ show: "flagged", page: undefined })} className="font-medium text-amber-700 hover:underline dark:text-amber-400">
              {flaggedCount} {flaggedCount === 1 ? "person needs" : "people need"} a look
            </Link>
          </>
        ) : (
          " · nobody needs a look"
        )}
      </p>

      <form action="/admin/team" className="grid grid-cols-2 items-center gap-2 sm:flex sm:flex-wrap">
        <input type="hidden" name="days" value={range.key} />
        <input
          type="search"
          name="q"
          defaultValue={q}
          maxLength={40}
          placeholder="Find a name…"
          aria-label="Find a name"
          className={`col-span-2 min-w-0 sm:w-48 ${searchField}`}
        />
        <SelectField look="admin" name="rank" label="Rank" defaultValue={rank} options={RANKS.map((r) => ({ value: r.value, label: r.label }))} />
        <SelectField
          look="admin"
          name="sort"
          label="Sort by"
          defaultValue={sort}
          leadingIcon="arrow-up-down"
          options={(Object.keys(SORTS) as SortKey[]).map((k) => ({ value: k, label: SORTS[k] }))}
        />
        <SelectField
          look="admin"
          name="show"
          label="Show"
          defaultValue={flaggedOnly ? "flagged" : "all"}
          options={[
            { value: "all", label: "Everyone" },
            { value: "flagged", label: "Needs a look" },
          ]}
        />
        <button
          type="submit"
          className="col-span-2 min-h-[42px] rounded-lg bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600 sm:col-auto"
        >
          Apply
        </button>
      </form>

      <div className="rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
        <div className={`hidden rounded-t-xl border-b border-zinc-200 bg-zinc-50 px-4 py-2.5 text-[11px] font-semibold leading-tight text-zinc-500 dark:border-zinc-800 dark:bg-zinc-950/40 ${grid}`}>
          <span>Person</span>
          {cols.map((c) => (
            <span key={c.label} className="text-center">
              {c.label}
            </span>
          ))}
          <span className="text-right">Last active</span>
        </div>
        <ul className="divide-y divide-zinc-100 dark:divide-zinc-800">
          {pageRows.map((r) => (
            <li key={r.id} className={`px-4 py-3 ${grid}`}>
              <div className="min-w-0">
                <div className="flex min-w-0 items-center gap-2.5">
                  <UserAvatar username={r.username} avatarUrl={r.avatarUrl} size="h-8 w-8" textSize="text-xs" />
                  <div className="min-w-0">
                    <Link href={`/admin/users/${r.id}?tab=staff&days=${range.key}&from=team`} className="block truncate font-semibold hover:underline">
                      {r.username}
                    </Link>
                    <span className="block text-xs text-zinc-500">{ROLE_LABELS[r.role as keyof typeof ROLE_LABELS]}</span>
                  </div>
                </div>
                {r.n.flags.length > 0 && (
                  <p className="mt-1.5 flex items-start gap-1.5 text-xs font-medium text-amber-800 dark:text-amber-300">
                    <Icon name="warning" className="mt-0.5 size-3.5 shrink-0" />
                    {r.n.flags.join(" · ")}
                  </p>
                )}
              </div>
              {cols.map((c) => (
                <div key={c.label} className="hidden text-center text-sm tabular-nums lg:block">
                  {c.value(r)}
                </div>
              ))}
              <dl className="mt-3 grid grid-cols-4 gap-2 sm:grid-cols-7 lg:hidden">
                {cols.map((c) => (
                  <div key={c.label} className="flex flex-col-reverse rounded-lg bg-zinc-50 px-2 py-1.5 dark:bg-zinc-800/60">
                    <dt className="text-[11px] text-zinc-500">{c.label}</dt>
                    <dd className="text-base font-bold tabular-nums">{c.value(r)}</dd>
                  </div>
                ))}
              </dl>
              <p className="mt-2 text-xs text-zinc-500 lg:mt-0 lg:text-right">
                <span className="lg:hidden">Last active </span>
                {r.lastActive ? timeAgo(r.lastActive) : "never"}
              </p>
            </li>
          ))}
        </ul>
        {pageRows.length === 0 && <p className="px-4 py-8 text-center text-sm text-zinc-500">Nobody matches these filters.</p>}
      </div>

      <Pager page={page} totalPages={totalPages} href={(p) => href({ page: p > 1 ? String(p) : undefined })} />
    </div>
  );
}
