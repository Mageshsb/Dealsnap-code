import Link from "next/link";
import { isStillAhead } from "@/lib/moderation";
import {
  countReportedComments,
  getSiteSetting,
  getHeroSlug,
  getAuditLog,
  getStaffUsersAdmin,
  getEscalations,
  getOpenProfileReports,
  countOpenContactMessages,
  getInsightSeries,
  getTrustedPostings,
  type InsightPoint,
} from "@/lib/db";
import { resolveEscalationAction, markReviewedAction } from "@/lib/admin-actions";
import ClashNotice from "@/components/admin/ClashNotice";
import { seenNow } from "@/lib/collisions";
import { timeAgo } from "@/lib/format";
import { findAdminDeals, getAdminDeal, getAdminDealFacets, getDealUrls, getStoreChecks, oldestPendingAt } from "@/lib/admin-deals";
import { countOpenErrors } from "@/lib/error-log";
import { launchMustsLeft } from "@/lib/launch-checks";
import { HERO_NAME } from "@/lib/hero";
import { setDealHeroAction } from "@/lib/admin-actions";
import { requireStaff } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { summariseActivity, AUDIT_ACTIONS, flagThresholds, type AuditAction } from "@/lib/audit";
import Icon, { HeartIcon, type IconName } from "@/components/Icon";
import AccountSection, { RowIcon } from "@/components/AccountSection";
import { AccountPageHeader } from "@/components/AccountShell";
import StaffImpact from "@/components/staff/StaffImpact";
import { getAffiliateProgrammes, getAwinFeeds, getClicksBySlugBetween } from "@/lib/db";
import { earningRoute } from "@/lib/affiliate";
import { getSiteSettings } from "@/lib/site-settings";
import { secretStatus } from "@/lib/secrets";
import { lastStoreSync } from "@/lib/awin";

// (The admin layout's "· Admin" pattern only reaches pages below it.)
export const metadata = { title: { absolute: "Dashboard · Admin" } };

// One thing waiting for staff: what it is, how many, and where to deal with it.
// (Housekeeping, like logos, gets a grey count: red is for people waiting.)
type Todo = { icon: IconName; title: string; detail?: string; count: number; href: string; later?: boolean };

function TodoRow({ icon, title, detail, count, href, later }: Todo) {
  return (
    <li>
      <Link href={href} className="-mx-2 flex items-center gap-3 rounded-xl px-2 py-3 hover:bg-zinc-50 dark:hover:bg-zinc-800/60">
        <RowIcon icon={icon} />
        <span className="min-w-0 flex-1">
          <span className="block font-semibold">{title}</span>
          {detail && <span className="block truncate text-sm text-zinc-500">{detail}</span>}
        </span>
        <span
          className={`flex h-6 min-w-6 items-center justify-center rounded-full px-2 text-xs font-bold tabular-nums ${
            later ? "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300" : "bg-red-500 text-white"
          }`}
        >
          {count}
        </span>
        <Icon name="chevron-right" className="size-4 shrink-0 text-zinc-300 dark:text-zinc-600" />
      </Link>
    </li>
  );
}

// Of the "Get deal" clicks in a stretch of time, how many went out earning:
// through a store's own programme, the Amazon tag or the catch-all network.
function earningShare(urls: Map<string, string>, from: number, to: number): { earning: number; clicks: number } {
  const settings = getSiteSettings();
  const programmes = getAffiliateProgrammes();
  let earning = 0;
  let clicks = 0;
  for (const c of getClicksBySlugBetween(new Date(from).toISOString(), new Date(to).toISOString())) {
    clicks += c.clicks;
    if (earningRoute(urls.get(c.slug) ?? "", settings, programmes) !== "none") earning += c.clicks;
  }
  return { earning, clicks };
}

// This week's share and the week before's.
function earningWeeks() {
  const week = 7 * 24 * 60 * 60 * 1000;
  const now = Date.now();
  // Only the deals that were clicked in these two weeks are looked up.
  const urls = getDealUrls(getClicksBySlugBetween(new Date(now - 2 * week).toISOString(), new Date(now).toISOString()).map((c) => c.slug));
  return { now: earningShare(urls, now - week, now), before: earningShare(urls, now - 2 * week, now - week) };
}

const percent = (part: number, whole: number) => (whole ? Math.round((part / whole) * 100) : 0);

// A number for the last 7 days, and how it compares with the 7 before.
function WeekStat({ label, now, before }: { label: string; now: number; before: number }) {
  const change = before > 0 ? Math.round(((now - before) / before) * 100) : now > 0 ? 100 : 0;
  return (
    <div className="flex flex-col gap-1 rounded-xl bg-zinc-50 p-3 dark:bg-zinc-800/50">
      <span className="text-xs font-medium text-zinc-500">{label}</span>
      <span className="text-2xl font-bold tabular-nums">{now.toLocaleString("en-GB")}</span>
      <span className={`flex items-center gap-1 text-xs font-medium ${change > 0 ? "text-emerald-700 dark:text-emerald-400" : change < 0 ? "text-red-600 dark:text-red-400" : "text-zinc-500"}`}>
        {change !== 0 && <Icon name={change > 0 ? "trending-up" : "trending-down"} className="size-3.5" />}
        {change === 0 ? "Same as the week before" : `${change > 0 ? "+" : ""}${change}% on the week before`}
      </span>
    </div>
  );
}

// The money measure: what share of this week's clicks could earn, and the
// change in points on the week before. It rises as stores accept us.
function EarningLine({ now, before }: { now: { earning: number; clicks: number }; before: { earning: number; clicks: number } }) {
  const share = percent(now.earning, now.clicks);
  const change = share - percent(before.earning, before.clicks);
  return (
    <div className="mt-3 flex flex-wrap items-center justify-between gap-x-4 gap-y-1 rounded-xl bg-zinc-50 px-3 py-2.5 text-sm dark:bg-zinc-800/50">
      <span>
        <Icon name="pound" className="mr-1.5 text-zinc-500 dark:text-zinc-400" />
        <span className="font-semibold">{share}% of clicks earn</span>{" "}
        <span className="text-zinc-500">
          ({now.earning.toLocaleString("en-GB")} of {now.clicks.toLocaleString("en-GB")})
          {before.clicks > 0 && change !== 0 && ` · ${change > 0 ? "up" : "down"} ${Math.abs(change)} point${Math.abs(change) === 1 ? "" : "s"} on the week before`}
        </span>
      </span>
      <Link href="/admin/insights#apply-next" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
        Stores to apply for next
      </Link>
    </div>
  );
}

export default async function AdminDashboardPage({ searchParams }: { searchParams: Promise<{ impact?: string; clash?: string }> }) {
  const { impact, clash } = await searchParams;
  // When this page was shown, for its buttons (lib/collisions.ts).
  const seen = seenNow();
  const staff = await requireStaff();
  const seeTeam = can(staff.role, "activity.view");
  const seeAllEscalations = can(staff.role, "escalations.resolve");
  const seeMessages = can(staff.role, "messages.handle");
  const seeInsights = can(staff.role, "insights.view");
  const canStores = can(staff.role, "stores.manage");
  // The team, looked up once (not every member).
  const team = seeTeam ? getStaffUsersAdmin() : [];
  const teamById = new Map(team.map((u) => [u.id, u]));
  const flagged = seeTeam
    ? [...summariseActivity().values()].filter((a) => a.flagged).map((a) => ({
        ...a,
        username: teamById.get(a.actorId)?.username ?? "A moderator",
        role: teamById.get(a.actorId)?.role,
      })).filter((a) => a.role === "moderator" || a.role === "helper")
    : [];
  const reportedComments = countReportedComments();
  // Counted by the database (lib/admin-deals.ts), not by loading every deal.
  const everything = { q: "", status: "all", category: "all", tag: "all", brand: "all", kind: "all", source: "all", store: "", flag: "all", sort: "newest" } as const;
  const pendingCount = getAdminDealFacets().states.pending;
  const oldestPending = oldestPendingAt();
  const openEscalations = seeAllEscalations ? getEscalations({ open: true }) : getEscalations({ open: true, createdById: staff.id });
  const profileReports = getOpenProfileReports();
  const probationMods = team.filter((u) => u.role === "moderator" && isStillAhead(u.modProbationUntil));
  const probationQueue = probationMods
    .map((m) => ({ mod: m, entries: getAuditLog({ actorId: m.id, unreviewedOnly: true, limit: 5 }) }))
    .filter((p) => p.entries.total > 0);
  const { newStores: newStoreCount, missingLogos: logosToFetch } = getStoreChecks();
  const hero = findAdminDeals({ ...everything, status: "hero" }, 1, 1).rows[0];
  // The slot can point at a deal that has since expired or been taken down —
  // it stops being the Hero on its own, but the admin should know to pick again.
  const heroSlug = getHeroSlug();
  const lapsedHero = !hero && heroSlug ? getAdminDeal(heroSlug) : undefined;
  const maintenanceOn = getSiteSetting("maintenance_mode") === "1";
  // Reported and still up (not taken down, waiting or ended).
  const reportedDeals = findAdminDeals({ ...everything, status: "live", flag: "reported" }, 1, 1).total;
  const openMessages = seeMessages ? countOpenContactMessages() : 0;
  const trustedPosts = getTrustedPostings(7, 5);
  const missingLogos = canStores ? logosToFetch : 0;
  // Awin, for the admins who look after earnings: what stopped working.
  const canEarnings = can(staff.role, "settings.revenue");
  const failedLists = canEarnings ? getAwinFeeds().filter((f) => f.error).length : 0;
  const lockedKeys = canEarnings ? [secretStatus("awin_api_token"), secretStatus("awin_feed_link")].filter((k) => k && !k.readable).length : 0;
  const syncError = canEarnings ? lastStoreSync().error : undefined;
  const siteErrors = can(staff.role, "settings.manage") ? countOpenErrors() : 0;
  const mustsLeft = can(staff.role, "settings.manage") ? launchMustsLeft() : 0;
  const maybeTodos: (Todo | false)[] = [
    mustsLeft > 0 && { icon: "rocket", title: "Things to finish before launch", detail: "See the launch checklist", count: mustsLeft, href: "/admin/launch" },
    pendingCount > 0 && {
      icon: "hourglass",
      title: `${pendingCount === 1 ? "Deal" : "Deals"} waiting for review`,
      detail: oldestPending ? `The oldest has waited ${timeAgo(oldestPending).replace(" ago", "")}` : undefined,
      count: pendingCount,
      href: "/admin/deals?status=pending",
    },
    reportedDeals > 0 && { icon: "flag", title: "Reported deals", detail: "Members say something's wrong", count: reportedDeals, href: "/admin/deals?sort=reports-desc" },
    reportedComments > 0 && { icon: "comment", title: "Reported comments", count: reportedComments, href: "/admin/comments?reported=true" },
    profileReports.length > 0 && { icon: "user", title: "Reported profiles", detail: "A picture, bio or username", count: profileReports.length, href: "/admin/users?status=reported" },
    openMessages > 0 && { icon: "mail", title: "Messages to answer", detail: "From the contact form", count: openMessages, href: "/admin/messages" },
    siteErrors > 0 && { icon: "warning", title: "Things that broke on the site", detail: "In the last 24 hours", count: siteErrors, href: "/admin/errors" },
    canStores && newStoreCount > 0 && { icon: "store", title: "New stores to check", detail: "For duplicate spellings", count: newStoreCount, href: "/admin/stores?filter=new", later: true },
    missingLogos > 0 && { icon: "image", title: "Stores without a logo", detail: "Fetch them in one go", count: missingLogos, href: "/admin/stores", later: true },
    lockedKeys > 0 && { icon: "key", title: "Awin keys need saving again", detail: "They can't be unlocked any more", count: lockedKeys, href: "/admin/earnings" },
    !!syncError && { icon: "warning", title: "Awin store sync didn't work", detail: syncError, count: 1, href: "/admin/earnings" },
    failedLists > 0 && {
      icon: "warning",
      title: "Product lists that didn't download",
      detail: "They're tried again every few hours",
      count: failedLists,
      href: "/admin/earnings?show=lists#stores",
      later: true,
    },
  ];
  const todos = maybeTodos.filter((t): t is Todo => !!t);
  const urgent = todos.filter((t) => !t.later).reduce((n, t) => n + t.count, 0);
  // The last 14 days, day by day: this week and the one before.
  const fortnight = seeInsights ? getInsightSeries(14) : undefined;
  const earning = seeInsights ? earningWeeks() : undefined;
  const week = (points: InsightPoint[] = []) => ({
    now: points.slice(-7).reduce((n, p) => n + p.count, 0),
    before: points.slice(0, -7).reduce((n, p) => n + p.count, 0),
  });

  return (
    <div className="flex flex-col gap-5">
      <AccountPageHeader
        title="Dashboard"
        description={seeInsights ? "What needs you today, and how the week's going." : "What needs your attention: deals to review and reports."}
      />

      <ClashNotice message={clash} />

      {can(staff.role, "settings.security") && maintenanceOn && (
        <div className="flex items-center justify-between rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-800 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-300">
          <span>
            <Icon name="construction" className="mr-1.5" />
            Maintenance mode is on: visitors see the holding page.
          </span>
          <Link href="/admin/settings" className="font-semibold underline">
            Manage
          </Link>
        </div>
      )}

      {flagged.map((f) => (
        <div
          key={f.actorId}
          className="flex items-center justify-between gap-3 rounded-xl border border-red-400 bg-red-50 px-4 py-3 text-sm text-red-900 dark:border-red-800 dark:bg-red-950/40 dark:text-red-200"
        >
          <span>
            <Icon name="warning" className="mr-1.5" />
            <b>{f.username}</b> (moderator) has done {f.hour} action{f.hour === 1 ? "" : "s"} in the last hour
            {f.hourRemovals >= flagThresholds().removals ? `, ${f.hourRemovals} of them removals` : ""}. That&apos;s unusually high.
          </span>
          <Link href={`/admin/users/${f.actorId}?tab=staff&days=1`} className="shrink-0 font-semibold underline">
            Review
          </Link>
        </div>
      ))}

      <AccountSection
        icon="inbox"
        title="Needs attention"
        aside={
          urgent > 0 && <span className="rounded-full bg-red-500 px-2.5 py-1 text-xs font-bold tabular-nums text-white">{urgent}</span>
        }
      >
        {todos.length === 0 ? (
          <p className="flex items-center gap-2 rounded-lg bg-emerald-50 px-4 py-2 text-sm font-medium text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300">
            <Icon name="circle-check" className="size-5" />
            All clear. Nothing is waiting for you.
          </p>
        ) : (
          <ul className="-my-3 flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {todos.map((t) => (
              <TodoRow key={t.href + t.title} {...t} />
            ))}
          </ul>
        )}
      </AccountSection>

      {openEscalations.length > 0 && (
        <AccountSection
          icon="hand"
          title={seeAllEscalations ? "Escalated to admins" : "Your open escalations"}
          description={seeAllEscalations ? "Moderators asked for an admin's decision on these." : "Waiting for an admin."}
          aside={
            <span className="rounded-full bg-red-500 px-2.5 py-1 text-xs font-bold tabular-nums text-white">{openEscalations.length}</span>
          }
        >
          <ul className="-my-3 flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {openEscalations.slice(0, 10).map((esc) => (
              <li key={esc.id} className="flex flex-col gap-2 py-3 text-sm sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p>
                    <span className="text-zinc-500">{esc.kind}:</span>{" "}
                    {esc.targetUrl ? (
                      <Link href={esc.targetUrl} className="font-medium hover:underline" target={esc.targetUrl.startsWith("/deals/") ? "_blank" : undefined}>
                        {esc.targetLabel}
                      </Link>
                    ) : (
                      <span className="font-medium">{esc.targetLabel}</span>
                    )}
                  </p>
                  <p className="text-xs text-zinc-500">
                    “{esc.note}” · {esc.createdByUsername}, {timeAgo(esc.createdAt)}
                  </p>
                </div>
                {seeAllEscalations && (
                  <form action={resolveEscalationAction} className="flex shrink-0 gap-2">
                    <input type="hidden" name="id" value={esc.id} />
                    <input type="hidden" name="seen" value={seen} />
                    <input
                      name="note"
                      placeholder="What you did (optional)"
                      className="w-44 rounded-xl border border-zinc-300 bg-white px-3 py-1.5 text-base outline-none focus:border-orange-400 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950"
                    />
                    <button type="submit" className="rounded-full bg-zinc-900 px-4 py-1.5 text-sm font-semibold text-white hover:bg-zinc-700 dark:bg-zinc-100 dark:text-zinc-900">
                      Resolve
                    </button>
                  </form>
                )}
              </li>
            ))}
          </ul>
        </AccountSection>
      )}

      {probationQueue.map(({ mod, entries }) => (
        <AccountSection
          key={mod.id}
          icon="search"
          title={`${mod.username} is on probation`}
          description={`${entries.total} action${entries.total === 1 ? "" : "s"} to check.`}
          aside={
            <form action={markReviewedAction}>
              <input type="hidden" name="actorId" value={mod.id} />
              <button type="submit" className="rounded-full bg-zinc-900 px-4 py-1.5 text-sm font-semibold text-white hover:bg-zinc-700 dark:bg-zinc-100 dark:text-zinc-900">
                Looks fine
              </button>
            </form>
          }
        >
          <ul className="flex flex-col gap-1.5 text-sm">
            {entries.entries.map((e) => (
              <li key={e.id} className="text-zinc-600 dark:text-zinc-300">
                <Icon name={AUDIT_ACTIONS[e.action as AuditAction]?.icon ?? "clipboard"} className="mr-1.5 text-zinc-500 dark:text-zinc-400" />
                {AUDIT_ACTIONS[e.action as AuditAction]?.text ?? e.action} <b>{e.targetLabel}</b>
                {e.detail ? ` (${e.detail})` : ""} · {timeAgo(e.at)}
              </li>
            ))}
          </ul>
          <Link href={`/admin/activity?staff=${mod.id}`} className="self-start text-sm font-medium text-orange-700 dark:text-orange-400 hover:underline">
            Review all
          </Link>
        </AccountSection>
      ))}

      {fortnight && (
        <AccountSection
          icon="chart-line"
          title="This week"
          description="The last 7 days, compared with the 7 before."
          aside={
            <Link href="/admin/insights" className="text-sm font-medium text-orange-700 dark:text-orange-400 hover:underline">
              Insights
            </Link>
          }
        >
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <WeekStat label="Deals posted" {...week(fortnight.deals)} />
            <WeekStat label="New members" {...week(fortnight.signups)} />
            <WeekStat label="Comments" {...week(fortnight.comments)} />
            <WeekStat label="“Get deal” clicks" {...week(fortnight.clicks)} />
          </div>
          {earning && <EarningLine {...earning} />}
        </AccountSection>
      )}

      {can(staff.role, "deals.curate") && (
        <AccountSection
          icon="crown"
          title={HERO_NAME}
          description="One deal you back, pinned to the top of Most loved."
          aside={
            <Link href="/admin/deals?sort=hearts-desc" className="rounded-full bg-violet-600 px-4 py-1.5 text-sm font-semibold text-white hover:bg-violet-700">
              {hero ? "Change" : "Choose one"}
            </Link>
          }
        >
          {hero ? (
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-violet-50 px-4 py-3 dark:bg-violet-950/30">
              <Link href={`/deals/${hero.slug}`} target="_blank" className="min-w-0 truncate font-semibold hover:underline">
                {hero.title}
                <span className="ml-2 text-sm font-normal text-zinc-500">
                  <HeartIcon className="mr-0.5" /> {hero.hearts} · {hero.store}
                </span>
              </Link>
              <form action={setDealHeroAction}>
                <input type="hidden" name="slug" value={hero.slug} />
                <input type="hidden" name="hero" value="false" />
                <button type="submit" className="text-sm font-medium text-red-600 hover:underline">
                  Remove
                </button>
              </form>
            </div>
          ) : (
            <p className="text-sm text-zinc-500">
              {lapsedHero
                ? `"${lapsedHero.title}" is no longer live, so the slot is empty. Pick a new ${HERO_NAME}.`
                : "The slot is empty. Pick the one deal you want to back."}
            </p>
          )}
        </AccountSection>
      )}

      {trustedPosts.total > 0 && (
        <AccountSection
          icon="badge-check"
          title="Went up without a check"
          description={`${trustedPosts.total} deal${trustedPosts.total === 1 ? "" : "s"} from trusted members this week. Skim them; anything wrong comes down from the deals list.`}
          aside={
            <Link href="/admin/deals" className="text-sm font-medium text-orange-700 dark:text-orange-400 hover:underline">
              All deals
            </Link>
          }
        >
          <ul className="-my-2 flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
            {trustedPosts.latest.map((d) => (
              <li key={d.slug} className="flex flex-wrap items-baseline justify-between gap-x-3 py-2 text-sm">
                <span className="min-w-0">
                  <Link href={`/deals/${d.slug}`} className="font-medium hover:text-orange-600 hover:underline">
                    {d.title}
                  </Link>{" "}
                  <span className="text-zinc-500">
                    · {d.store} · by {d.username}
                  </span>
                </span>
                <span className="text-xs text-zinc-500 dark:text-zinc-400">{timeAgo(d.postedAt)}</span>
              </li>
            ))}
          </ul>
        </AccountSection>
      )}

      {!seeTeam && (
        <p className="text-sm text-zinc-500">
          <Icon name="book-open" className="mr-1.5" />
          New to moderating? Read the{" "}
          <Link href="/admin/guidelines" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
            moderator guidelines
          </Link>
          .
        </p>
      )}

      {/* Admins see everyone's numbers, their own included, in Team. */}
      {!seeTeam && <StaffImpact userId={staff.id} role={staff.role} rangeKey={impact} basePath="/admin" />}
    </div>
  );
}
