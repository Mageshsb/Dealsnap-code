import { requirePermission } from "@/lib/auth";
import BlogEditor from "@/components/admin/BlogEditor";

export const metadata = { title: "New post" };

export default async function NewBlogPostPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  await requirePermission("blog.manage");
  const { error } = await searchParams;
  return <BlogEditor error={error} />;
}
