import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { blogCoverUrl, getAllBlogRowsForAdmin } from "@/lib/mock-blog";
import { getBlogTotalsSince } from "@/lib/db";
import { blogKind, dayDaysAgo, daysSince } from "@/lib/blog";
import { formatDate } from "@/lib/format";
import Icon from "@/components/Icon";
import EmptyState from "@/components/EmptyState";

import Notice from "@/components/admin/Notice";
export const metadata = { title: "Blog" };

type State = "Published" | "Scheduled" | "Draft";
const FILTERS: { key: string; label: string; state?: State }[] = [
  { key: "all", label: "All" },
  { key: "published", label: "Published", state: "Published" },
  { key: "scheduled", label: "Scheduled", state: "Scheduled" },
  { key: "draft", label: "Drafts", state: "Draft" },
];

const STATE_STYLE: Record<State, string> = {
  Published: "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400",
  Scheduled: "bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400",
  Draft: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400",
};

export default async function AdminBlogPage({ searchParams }: { searchParams: Promise<{ notice?: string; show?: string }> }) {
  await requirePermission("blog.manage");
  const { notice, show } = await searchParams;
  const now = new Date().toISOString();
  const totals = getBlogTotalsSince(dayDaysAgo(30));
  const rows = getAllBlogRowsForAdmin().map((r) => ({
    ...r,
    state: (r.status === "draft" ? "Draft" : r.publishedAt > now ? "Scheduled" : "Published") as State,
  }));
  const filter = FILTERS.find((f) => f.key === show) ?? FILTERS[0];
  const shown = filter.state ? rows.filter((r) => r.state === filter.state) : rows;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold sm:text-2xl">Blog</h1>
          <p className="text-sm text-zinc-500">Buying guides, tips and sale dates. Drafts are only visible to admins.</p>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/blog" target="_blank" className="text-sm font-medium text-zinc-600 hover:underline dark:text-zinc-400">
            View blog ↗
          </Link>
          <Link href="/admin/blog/new" className="rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
            + New post
          </Link>
        </div>
      </div>

      <Notice notice={notice} />

      <nav aria-label="Filter posts" className="flex flex-wrap gap-2">
        {FILTERS.map((f) => {
          const count = f.state ? rows.filter((r) => r.state === f.state).length : rows.length;
          const active = f.key === filter.key;
          return (
            <Link
              key={f.key}
              href={f.key === "all" ? "/admin/blog" : `/admin/blog?show=${f.key}`}
              aria-current={active ? "page" : undefined}
              // The site's "which ones to show" tabs.
              className={`flex min-h-9 items-center gap-1.5 rounded-xl px-3 text-sm font-medium transition-colors ${
                active
                  ? "bg-orange-500 text-white"
                  : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
              }`}
            >
              {f.label} <span className={`text-xs tabular-nums ${active ? "text-white/90" : "text-zinc-500 dark:text-zinc-400"}`}>{count}</span>
            </Link>
          );
        })}
      </nav>

      <ul className="flex flex-col gap-2">
        {shown.map((r) => {
          const kind = blogKind(r.kind);
          const t = totals.get(r.id);
          const votes = t ? t.yes + t.no : 0;
          // Prices not checked for four months (or a guide nobody has touched
          // for six) are worth another look.
          const dated = r.checkedAt ? daysSince(r.checkedAt) > 120 : (r.kind === "guide" || r.kind === "sales") && daysSince(r.updatedAt) > 180;
          return (
            <li
              key={r.id}
              className="flex items-center gap-3 rounded-xl border border-zinc-200 bg-white p-2.5 sm:p-3 dark:border-zinc-800 dark:bg-zinc-900"
            >
              <Link href={`/admin/blog/${r.id}`} className="shrink-0" aria-hidden tabIndex={-1}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={blogCoverUrl(r)} alt="" className="aspect-[16/9] w-24 rounded-lg object-cover sm:w-32" />
              </Link>
              <div className="flex min-w-0 flex-1 flex-col gap-1">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${STATE_STYLE[r.state]}`}>{r.state}</span>
                  {r.featured && (
                    <span className="rounded-full bg-orange-100 px-2 py-0.5 text-xs font-medium text-orange-700 dark:bg-orange-950/40 dark:text-orange-300">
                      <Icon name="pin" className="mr-1.5" />Pinned
                    </span>
                  )}
                  <span className="text-xs text-zinc-500">
                    <Icon name={kind.icon} className="mr-1" />
                    {kind.single}
                  </span>
                  {dated && r.state === "Published" && (
                    <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
                      <Icon name="clock" className="mr-1" />
                      Check prices
                    </span>
                  )}
                </div>
                <Link href={`/admin/blog/${r.id}`} className="truncate font-medium hover:underline">
                  {r.title}
                </Link>
                <p className="truncate text-xs text-zinc-500">
                  {formatDate(r.publishedAt)} · {r.category || "No category"} · /blog/{r.slug}
                </p>
                {t && (t.views > 0 || t.clicks > 0 || votes > 0) && (
                  <p className="truncate text-xs text-zinc-500">
                    Last 30 days: {t.views.toLocaleString("en-GB")} views
                    {t.clicks > 0 && <> · {t.clicks.toLocaleString("en-GB")} clicks on picks</>}
                    {votes > 0 && <> · {Math.round((t.yes / votes) * 100)}% found it useful ({votes})</>}
                  </p>
                )}
              </div>
              <div className="hidden shrink-0 items-center gap-3 sm:flex">
                <Link
                  href={`/blog/${r.slug}${r.state === "Published" ? "" : "?preview=1"}`}
                  target="_blank"
                  className="text-xs font-medium text-zinc-600 hover:underline dark:text-zinc-400"
                >
                  View ↗
                </Link>
                <Link
                  href={`/admin/blog/${r.id}`}
                  className="inline-flex min-h-[36px] items-center rounded-lg border border-zinc-300 px-3.5 text-xs font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
                >
                  Edit
                </Link>
              </div>
            </li>
          );
        })}
        {shown.length === 0 && (
          <li>
            <EmptyState icon="pen-line">
              <p>
                {rows.length === 0 ? "No posts yet." : "No posts here."}
              </p>
            </EmptyState>
          </li>
        )}
      </ul>
    </div>
  );
}
