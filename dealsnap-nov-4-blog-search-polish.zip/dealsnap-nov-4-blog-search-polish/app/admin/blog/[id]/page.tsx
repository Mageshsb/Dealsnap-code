import { notFound } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import { getBlogRowById } from "@/lib/db";
import BlogEditor from "@/components/admin/BlogEditor";

export const metadata = { title: "Edit post" };

export default async function EditBlogPostPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string; notice?: string }>;
}) {
  await requirePermission("blog.manage");
  const { id } = await params;
  const { error, notice } = await searchParams;
  const row = getBlogRowById(id);
  if (!row) notFound();
  return <BlogEditor row={row} error={error} notice={notice} />;
}
