import { getAffiliateProgrammes, getAwinFeeds, type AffiliateProgramme, type AwinFeed } from "@/lib/db";
import { secretStatus } from "@/lib/secrets";
import { isRefreshingProductLists, lastStoreSync } from "@/lib/awin";
import { autofillByShop } from "@/lib/autofill-report";
import { formatDate, timeAgo } from "@/lib/format";
import { AFFILIATE_DISCLOSURE_MAX, AMAZON_DISCLOSURE, getSiteSettings } from "@/lib/site-settings";
import {
  saveAffiliateSettingsAction,
  addAffiliateProgrammeAction,
  saveAwinTokenAction,
  removeAwinTokenAction,
  saveAwinFeedLinkAction,
  removeAwinFeedLinkAction,
  checkAwinAction,
  syncAwinStoresAction,
  setProductListAction,
  setProgrammeStoppedAction,
  removeStoreProgrammeAction,
} from "@/lib/admin-actions";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import RowMenu from "@/components/admin/RowMenu";
import SelectField from "@/components/SelectField";
import Icon from "@/components/Icon";
import { Checkbox, card, hint, input, mono, outlineButton, saveButton } from "../settings/ui";
import { searchField } from "@/components/admin/formStyles";

// Admin → Earnings: how "Get deal" clicks earn (network IDs and the
// disclosure), the Awin connection, and each store's own programme. Admins
// with "settings.revenue" only (app/admin/earnings/page.tsx checks).

const smallButton =
  "rounded-full border border-zinc-300 px-3 py-1 text-xs font-semibold text-zinc-700 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800";

const SHOW = {
  all: "All stores",
  blocked: "Blocks our reader",
  lists: "Product list on",
  stopped: "Stopped",
  manual: "Added by hand",
} as const;
type Show = keyof typeof SHOW;

// One store: all its websites together (Awin can list several for one store).
type StoreProgramme = {
  key: string;
  name: string;
  domains: string[];
  first: AffiliateProgramme;
  feed?: AwinFeed;
  reads?: { posts: number; blocked: number };
};

function storesFrom(programmes: AffiliateProgramme[], feeds: Map<string, AwinFeed>): StoreProgramme[] {
  // How often each store turned our reader away in the last 30 days, from
  // the posts made with its links (lib/autofill-report.ts).
  const reads = autofillByShop(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const groups = new Map<string, StoreProgramme>();
  for (const p of programmes) {
    const key = p.network === "awin" && p.merchantId ? `m:${p.merchantId}` : `d:${p.domain}`;
    const store = groups.get(key) ?? {
      key,
      name: p.name ?? p.domain,
      domains: [],
      first: p,
      feed: p.merchantId && p.network === "awin" ? feeds.get(p.merchantId) : undefined,
    };
    store.domains.push(p.domain);
    groups.set(key, store);
  }
  for (const store of groups.values()) {
    const shops = reads.filter((r) => store.domains.some((d) => r.host === d || r.host.endsWith(`.${d}`)));
    const posts = shops.reduce((n, r) => n + r.posts, 0);
    if (posts) store.reads = { posts, blocked: shops.reduce((n, r) => n + r.linkOnly, 0) };
  }
  return [...groups.values()].sort((a, b) => a.name.localeCompare(b.name, "en-GB", { sensitivity: "base" }));
}

function matches(store: StoreProgramme, show: Show, q: string): boolean {
  const term = q.trim().toLowerCase();
  if (term && !store.name.toLowerCase().includes(term) && !store.domains.some((d) => d.includes(term))) return false;
  if (show === "blocked") return !!store.reads?.blocked;
  if (show === "lists") return !!store.feed;
  if (show === "stopped") return !!store.first.stopped;
  if (show === "manual") return !store.first.synced;
  return true;
}

export default function EarningsTab({ q = "", show: showParam }: { q?: string; show?: string }) {
  const s = getSiteSettings();
  const show: Show = showParam && showParam in SHOW ? (showParam as Show) : "all";
  const awinToken = secretStatus("awin_api_token");
  const feedLink = secretStatus("awin_feed_link");
  const canUseLists = !!awinToken?.readable || !!feedLink?.readable;
  const stores = storesFrom(getAffiliateProgrammes(), new Map(getAwinFeeds().map((f) => [f.merchantId, f])));
  const shown = stores.filter((store) => matches(store, show, q));
  const earning = stores.filter((store) => !store.first.stopped).length;
  const withLists = stores.filter((store) => store.feed).length;
  const downloading = isRefreshingProductLists();
  const sync = lastStoreSync();
  const keep = (
    <>
      {q && <input type="hidden" name="q" value={q} />}
      {show !== "all" && <input type="hidden" name="show" value={show} />}
    </>
  );

  return (
    <>
      <form action={saveAffiliateSettingsAction} className={card}>
        <div>
          <h2 className="font-semibold">Affiliate links</h2>
          <p className="text-sm text-zinc-500">
            Earn a commission when people buy through &ldquo;Get deal&rdquo;. Paste the IDs your networks give you and every
            click is tagged on its way to the store. Leave a box empty to skip that network.
          </p>
        </div>
        <div className="flex flex-col gap-1">
          <label htmlFor="amazonTag" className="text-sm font-medium">Amazon Associates tag</label>
          <input id="amazonTag" name="amazonTag" defaultValue={s.amazonTag} placeholder="dealsnap-21" className={input} />
          <p className={hint}>
            From Amazon Associates (affiliate-program.amazon.co.uk). Used for Amazon links. While it&apos;s set, the footer and
            Terms also show Amazon&apos;s required line: &ldquo;{AMAZON_DISCLOSURE}&rdquo;.
          </p>
        </div>
        <div className="flex flex-col gap-1">
          <label htmlFor="awinPublisherId" className="text-sm font-medium">Awin publisher ID</label>
          <input id="awinPublisherId" name="awinPublisherId" defaultValue={s.awinPublisherId} placeholder="123456" inputMode="numeric" className={input} />
          <p className={hint}>Filled in for you when the Awin token below is saved. Used for the stores&apos; own programmes below.</p>
        </div>
        <div className="flex flex-col gap-1">
          <label htmlFor="skimlinksId" className="text-sm font-medium">Skimlinks publisher ID</label>
          <input id="skimlinksId" name="skimlinksId" defaultValue={s.skimlinksId} placeholder="123456X1234567" className={input} />
          <p className={hint}>From Skimlinks → Settings. The catch-all: it earns from most other UK stores in one go.</p>
        </div>
        <div className="flex flex-col gap-1">
          <label htmlFor="affiliateLinkTemplate" className="text-sm font-medium">
            Another network instead of Skimlinks <span className="font-normal text-zinc-500 dark:text-zinc-400">(optional)</span>
          </label>
          <input
            id="affiliateLinkTemplate"
            name="affiliateLinkTemplate"
            defaultValue={s.affiliateLinkTemplate}
            placeholder="https://redirect.viglink.com?key=YOURKEY&u={url}"
            className={input}
          />
          <p className={hint}>
            For networks like Sovrn: their link with <code>{"{url}"}</code> where the store&apos;s link should go (and{" "}
            <code>{"{ref}"}</code> for the deal&apos;s name, if they take one). Only used when the Skimlinks box is empty.
          </p>
        </div>
        <div className="flex flex-col gap-2 border-t border-zinc-100 pt-4 dark:border-zinc-800">
          <h3 className="text-sm font-semibold">Disclosure</h3>
          <p className="text-sm text-zinc-500">
            UK advertising rules say you must tell visitors when you earn from links. It shows automatically whenever any of the
            boxes above is filled in: every &ldquo;Get deal&rdquo; button gets a &ldquo;*&rdquo;, and this line (starting with
            &ldquo;*&rdquo;) shows in the footer and at the bottom of the phone menu, linking to the full explanation in the
            Terms. Keep it to one short line.
          </p>
          <Checkbox name="showAffiliateDisclosure" defaultChecked={s.showAffiliateDisclosure}>
            <span className="font-medium">Show it even with no affiliate IDs above</span>
          </Checkbox>
          <input name="affiliateDisclosure" defaultValue={s.affiliateDisclosure} maxLength={AFFILIATE_DISCLOSURE_MAX} aria-label="Disclosure wording" className={input} />
        </div>
        <button type="submit" className={saveButton}>Save</button>
      </form>

      <div className={card}>
        <div>
          <h2 className="font-semibold">Awin connection</h2>
          <p className="text-sm text-zinc-500">
            Lets DealSnap ask Awin which stores have accepted you and set them up below, and keep product lists for stores that
            won&apos;t let us read their pages, so the post form can still fill in their products.
          </p>
        </div>
        {awinToken && (
          <p className={`text-sm ${awinToken.readable ? "text-zinc-600 dark:text-zinc-300" : "text-amber-700 dark:text-amber-400"}`}>
            {awinToken.readable ? (
              <>
                <Icon name="key" className="mr-1.5 text-zinc-500 dark:text-zinc-400" />
                Token saved (ending <span className="font-mono">{awinToken.hint}</span>) by {awinToken.savedBy} on {formatDate(awinToken.savedAt)}.
              </>
            ) : (
              "The saved token can't be unlocked any more (the site's secret key changed). Save it again below."
            )}
          </p>
        )}
        {awinToken?.readable && (
          <>
            <p className={`text-sm ${sync.error ? "text-amber-700 dark:text-amber-400" : "text-zinc-500"}`}>
              <Icon name={sync.error ? "warning" : "hourglass"} className="mr-1.5" />
              Stores sync by themselves each night.
              {sync.at && ` Last sync ${timeAgo(sync.at)}: `}
              {sync.error ?? sync.note}
            </p>
            <div className="flex flex-wrap gap-2">
              <form action={syncAwinStoresAction}>
                <button type="submit" className={saveButton}>Sync now</button>
              </form>
              <form action={checkAwinAction}>
                <button type="submit" className={outlineButton}>Test connection</button>
              </form>
              <form action={removeAwinTokenAction}>
                <ConfirmSubmitButton confirmText="Remove the Awin token? Stores already set up keep earning." className={outlineButton}>
                  Remove token
                </ConfirmSubmitButton>
              </form>
            </div>
          </>
        )}
        <form action={saveAwinTokenAction} className="flex flex-col gap-3">
          <div className="flex flex-col gap-1">
            <label htmlFor="awinToken" className="text-sm font-medium">
              {awinToken ? "Replace the token" : "Awin API token"}
            </label>
            <input id="awinToken" name="token" type="password" autoComplete="off" spellCheck={false} placeholder="Paste the token from Awin" className={mono} />
            <p className={hint}>
              In Awin, open the menu under your name (top right) and choose API credentials. It&apos;s saved encrypted and never
              shown again, only its last four characters. Only admins can change it, and it&apos;s recorded in the activity log.
            </p>
          </div>
          <button type="submit" className={awinToken ? outlineButton : saveButton}>Save and test</button>
        </form>
        {awinToken?.readable && (
          <div className="flex flex-col gap-3 border-t border-zinc-100 pt-4 dark:border-zinc-800">
            <div>
              <h3 className="text-sm font-semibold">Product lists</h3>
              <p className={hint}>
                Stores share their product lists through Awin&apos;s Create-a-Feed, which has its own key. In Awin, open Toolbox →
                Create-a-Feed, pick any one of your stores, choose Select all columns, CSV and gzip, then copy the download link and
                paste it here. We swap in each store&apos;s list from it. It&apos;s saved encrypted, like the token.
              </p>
            </div>
            {feedLink && (
              <div className="flex flex-wrap items-center gap-2">
                <p className={`text-sm ${feedLink.readable ? "text-zinc-600 dark:text-zinc-300" : "text-amber-700 dark:text-amber-400"}`}>
                  {feedLink.readable ? (
                    <>
                      <Icon name="key" className="mr-1.5 text-zinc-500 dark:text-zinc-400" />
                      Link saved (key ending <span className="font-mono">{feedLink.hint}</span>) on {formatDate(feedLink.savedAt)}.
                    </>
                  ) : (
                    "The saved link can't be unlocked any more. Save it again below."
                  )}
                </p>
                <form action={removeAwinFeedLinkAction}>
                  <ConfirmSubmitButton confirmText="Remove the product list link?" className={smallButton}>
                    Remove
                  </ConfirmSubmitButton>
                </form>
              </div>
            )}
            <form action={saveAwinFeedLinkAction} className="flex flex-col gap-3">
              <input
                name="feedLink"
                type="password"
                autoComplete="off"
                spellCheck={false}
                aria-label="Create-a-Feed download link"
                placeholder="https://productdata.awin.com/datafeed/download/apikey/…"
                className={mono}
              />
              <button type="submit" className={feedLink ? outlineButton : saveButton}>Save and test</button>
            </form>
          </div>
        )}
      </div>

      <div className={card} id="stores">
        <div>
          <h2 className="font-semibold">Stores&apos; own programmes</h2>
          <p className="text-sm text-zinc-500">
            A store&apos;s own programme usually pays more than Skimlinks, so its &ldquo;Get deal&rdquo; clicks use it first.
            {stores.length > 0 &&
              ` ${stores.length} store${stores.length === 1 ? "" : "s"}, ${earning} earning${withLists ? `, ${withLists} with a product list` : ""}.`}{" "}
            Turn on a product list only for a store that blocks our reader: big stores&apos; lists are large.
          </p>
        </div>
        {stores.some((store) => store.first.network === "awin") && !s.awinPublisherId && (
          <p className="text-sm text-amber-700 dark:text-amber-400">
            <Icon name="warning" className="mr-1.5" />
            Add your Awin publisher ID above, or the Awin stores below can&apos;t earn.
          </p>
        )}

        {stores.length > 0 && (
          <form action="/admin/earnings#stores" className="grid grid-cols-2 items-center gap-2 sm:flex sm:flex-wrap">
            <input type="search" name="q" defaultValue={q} maxLength={100} placeholder="Search stores…" aria-label="Search stores" className={`col-span-2 min-w-[160px] sm:col-span-1 sm:flex-1 ${searchField}`} />
            <SelectField look="admin" name="show" label="Show" defaultValue={show} options={Object.entries(SHOW).map(([value, label]) => ({ value, label }))} />
            <button type="submit" className="min-h-[42px] rounded-lg bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600">
              Apply
            </button>
          </form>
        )}

        {stores.length > 0 && shown.length === 0 && <p className="text-sm text-zinc-500">No stores match.</p>}
        {shown.length > 0 && (
          <ul className="flex flex-col divide-y divide-zinc-100 rounded-lg border border-zinc-200 dark:divide-zinc-800 dark:border-zinc-800">
            {shown.map((store) => (
              <StoreRow key={store.key} store={store} canUseLists={canUseLists} downloading={downloading} keep={keep} />
            ))}
          </ul>
        )}

        <details className="group">
          <summary className="cursor-pointer list-none text-sm font-semibold text-orange-700 hover:underline dark:text-orange-400">
            <Icon name="plus" className="mr-1" />
            Add a store by hand
          </summary>
          <form action={addAffiliateProgrammeAction} className="mt-4 flex flex-col gap-3">
            <p className={hint}>For a store Awin didn&apos;t list a website for, or one on another network.</p>
            <div className="flex flex-col gap-1">
              <label htmlFor="programmeDomain" className="text-sm font-medium">Store&apos;s website</label>
              <input id="programmeDomain" name="domain" placeholder="argos.co.uk" className={input} />
            </div>
            <div className="flex flex-col gap-1">
              <label htmlFor="programmeMerchant" className="text-sm font-medium">Awin merchant ID</label>
              <input id="programmeMerchant" name="merchantId" placeholder="1599" inputMode="numeric" className={input} />
              <p className={hint}>On the store&apos;s page in Awin, next to its name.</p>
            </div>
            <div className="flex flex-col gap-1">
              <label htmlFor="programmeTemplate" className="text-sm font-medium">
                Or its link from another network <span className="font-normal text-zinc-500 dark:text-zinc-400">(instead of Awin)</span>
              </label>
              <input id="programmeTemplate" name="template" placeholder="https://network.example/click?id=123&url={url}&ref={ref}" className={input} />
              <p className={hint}>
                <code>{"{url}"}</code> is where the store&apos;s link goes; <code>{"{ref}"}</code> (optional) is where the deal&apos;s name goes.
              </p>
            </div>
            <button type="submit" className={saveButton}>Add store</button>
          </form>
        </details>
      </div>
    </>
  );
}

// One store in the list: where it's earning, how often it blocks our reader,
// its product list, and its actions tucked into one menu.
function StoreRow({ store, canUseLists, downloading, keep }: { store: StoreProgramme; canUseLists: boolean; downloading: boolean; keep: React.ReactNode }) {
  const p = store.first;
  const awin = p.network === "awin" && !!p.merchantId;
  const { feed, reads } = store;
  const listLine = feed
    ? feed.error
      ? { text: `Product list: ${feed.error}`, warn: true }
      : feed.refreshedAt
        ? { text: `Product list: ${feed.products.toLocaleString("en-GB")} products, updated ${timeAgo(feed.refreshedAt)}`, warn: false }
        : { text: downloading ? "Product list: downloading…" : "Product list: waiting to download", warn: false }
    : awin && p.hasList === false
      ? { text: "Doesn't share a product list on Awin", warn: false }
      : undefined;
  const mayAddList = awin && canUseLists && !feed && p.hasList !== false && !p.stopped;
  const where = awin ? `Awin ${p.merchantId}` : "Another network";
  const storeKey = <input type="hidden" name="store" value={store.key} />;

  return (
    <li className="flex items-start justify-between gap-3 px-3 py-3 text-sm">
      <div className="flex min-w-0 flex-1 flex-col gap-0.5">
        <p className="flex flex-wrap items-center gap-x-2 gap-y-1 font-medium">
          {store.name}
          {p.stopped ? (
            <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-[11px] font-semibold text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">Stopped</span>
          ) : (
            <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">Earning</span>
          )}
        </p>
        <p className="truncate text-xs text-zinc-500">
          {store.domains[0]}
          {store.domains.length > 1 && ` + ${store.domains.length - 1} more`} · <span className="whitespace-nowrap">{where}</span>
          {!p.synced && " · Added by hand"}
        </p>
        {reads && (
          <p className={`text-xs ${reads.blocked ? "text-amber-700 dark:text-amber-400" : "text-zinc-500"}`}>
            {reads.blocked
              ? `Blocked our reader on ${reads.blocked} of ${reads.posts} recent post${reads.posts === 1 ? "" : "s"}`
              : `Our reader worked on all ${reads.posts} recent post${reads.posts === 1 ? "" : "s"}`}
          </p>
        )}
        {listLine && <p className={`text-xs ${listLine.warn ? "text-amber-700 dark:text-amber-400" : "text-zinc-500"}`}>{listLine.text}</p>}
      </div>
      <RowMenu label="Manage">
        {mayAddList && (
          <form action={setProductListAction}>
            <input type="hidden" name="merchantId" value={p.merchantId} />
            {keep}
            <button type="submit" name="turn" value="on">Use product list</button>
          </form>
        )}
        {feed && canUseLists && (
          <form action={setProductListAction}>
            <input type="hidden" name="merchantId" value={p.merchantId} />
            {keep}
            <button type="submit" name="turn" value="refresh">Refresh product list</button>
          </form>
        )}
        {feed && (
          <form action={setProductListAction}>
            <input type="hidden" name="merchantId" value={p.merchantId} />
            {keep}
            <button type="submit" name="turn" value="off">Turn off product list</button>
          </form>
        )}
        <form action={setProgrammeStoppedAction}>
          {storeKey}
          {keep}
          <button type="submit" name="turn" value={p.stopped ? "start" : "stop"}>
            {p.stopped ? "Earn through it again" : "Stop using its programme"}
          </button>
        </form>
        {!p.synced && (
          <form action={removeStoreProgrammeAction}>
            {storeKey}
            {keep}
            <ConfirmSubmitButton
              confirmText="Remove this store's affiliate programme from the list? Its deals stop earning through it until you add it again."
              confirmLabel="Yes, remove it"
              className="text-red-600 dark:text-red-400"
            >
              Remove
            </ConfirmSubmitButton>
          </form>
        )}
      </RowMenu>
    </li>
  );
}
