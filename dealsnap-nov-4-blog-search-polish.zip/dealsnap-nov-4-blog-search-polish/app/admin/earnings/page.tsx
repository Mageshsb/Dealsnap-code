import { requirePermission } from "@/lib/auth";
import EarningsTab from "./EarningsTab";

import Notice from "@/components/admin/Notice";
export const metadata = { title: "Earnings" };

// Admin → Earnings: everything that makes money from "Get deal" clicks, next
// to Ads in the menu so all the site's money is in one place.
export default async function AdminEarningsPage({
  searchParams,
}: {
  searchParams: Promise<{ saved?: string; error?: string; note?: string; q?: string; show?: string }>;
}) {
  await requirePermission("settings.revenue");
  const params = await searchParams;

  return (
    <div className="flex max-w-2xl flex-col gap-6">
      <div>
        <h1 className="text-xl font-bold sm:text-2xl">Earnings</h1>
        <p className="text-sm text-zinc-500">
          How &ldquo;Get deal&rdquo; clicks earn: your affiliate networks, the Awin connection and each store&apos;s own
          programme.
        </p>
      </div>

      <Notice notice={params.saved || params.note ? (params.note ?? "Saved.") : undefined} error={params.error} />

      <EarningsTab q={params.q} show={params.show} />
    </div>
  );
}
