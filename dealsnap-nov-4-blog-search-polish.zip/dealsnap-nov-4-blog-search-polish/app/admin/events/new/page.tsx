import { requirePermission } from "@/lib/auth";
import EventEditor from "@/components/admin/EventEditor";

export const metadata = { title: "New event" };

export default async function NewEventPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  await requirePermission("content.manage");
  const { error } = await searchParams;
  return <EventEditor error={error} />;
}
