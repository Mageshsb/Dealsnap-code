import { notFound } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import { getEventById } from "@/lib/db";
import EventEditor from "@/components/admin/EventEditor";

export const metadata = { title: "Edit event" };

export default async function EditEventPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string; notice?: string }>;
}) {
  await requirePermission("content.manage");
  const event = getEventById((await params).id);
  if (!event) notFound();
  const { error, notice } = await searchParams;
  return <EventEditor event={event} error={error} notice={notice} />;
}
