import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getEvents } from "@/lib/db";
import { eventState, eventTiming } from "@/lib/events";
import { setEventLaunchedAction } from "@/lib/content-actions";
import EventStatePill from "@/components/admin/EventState";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import Icon from "@/components/Icon";
import ContentHeader from "@/components/admin/ContentHeader";
import EmptyState from "@/components/EmptyState";

import Notice from "@/components/admin/Notice";
export const metadata = { title: "Events" };

const day = (d: string) =>
  new Date(`${d}T12:00:00Z`).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: "UTC",
  });

export default async function AdminEventsPage({ searchParams }: { searchParams: Promise<{ notice?: string }> }) {
  await requirePermission("content.manage");
  const { notice } = await searchParams;
  const events = getEvents().map((e) => ({ event: e, state: eventState(e), timing: eventTiming(e) }));

  return (
    <div className="flex flex-col gap-4">
      <ContentHeader
        current="events"
        title="Events"
        description="Black Friday, Christmas, Easter… Each gets its own page and a button while it's on."
        actions={
          <Link href="/admin/events/new" className="rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
            + New event
          </Link>
        }
      />

      <Notice notice={notice} />

      <ul className="flex flex-col gap-2">
        {events.map(({ event, state, timing }) => (
          <li
            key={event.id}
            className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-3 sm:flex-row sm:items-center dark:border-zinc-800 dark:bg-zinc-900"
          >
            <div className="flex min-w-0 flex-1 items-center gap-3">
              <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400">
                <Icon name={event.icon} className="size-5" />
              </span>
              <div className="flex min-w-0 flex-col gap-1">
                <div className="flex flex-wrap items-center gap-2">
                  <Link href={`/admin/events/${event.id}`} className="truncate font-medium hover:underline">
                    {event.name}
                  </Link>
                  <EventStatePill state={state} />
                </div>
                <p className="truncate text-xs text-zinc-500">
                  {day(timing.date)} · shows {day(timing.showFrom)} to {day(timing.showUntil)} · /{event.slug}
                </p>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <Link
                href={`/admin/events/${event.id}`}
                className="inline-flex min-h-[36px] items-center rounded-lg border border-zinc-300 px-3.5 text-xs font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
              >
                Edit
              </Link>
              <form action={setEventLaunchedAction}>
                <input type="hidden" name="id" value={event.id} />
                <input type="hidden" name="back" value="list" />
                <input type="hidden" name="launch" value={event.launched ? "0" : "1"} />
                {event.launched ? (
                  <ConfirmSubmitButton
                    confirmText={`Take ${event.name} down? Its page and button disappear from the site.`}
                    confirmLabel="Take down"
                    className="inline-flex min-h-[36px] items-center rounded-lg border border-red-300 px-3.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/30"
                  >
                    Take down
                  </ConfirmSubmitButton>
                ) : (
                  <button
                    type="submit"
                    className="inline-flex min-h-[36px] items-center rounded-lg bg-orange-500 px-3.5 text-xs font-semibold text-white hover:bg-orange-600"
                  >
                    Launch
                  </button>
                )}
              </form>
            </div>
          </li>
        ))}
        {events.length === 0 && (
          <li>
            <EmptyState icon="calendar">
              <p>
                No events yet.
              </p>
            </EmptyState>
          </li>
        )}
      </ul>
    </div>
  );
}
