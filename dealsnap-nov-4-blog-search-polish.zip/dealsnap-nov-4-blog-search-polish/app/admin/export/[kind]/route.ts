import { getAllUsersAdmin, getAllCommentsAdmin, getAuditLog } from "@/lib/db";
import { getAdminDealsView } from "@/lib/mock-deals";
import { getDealStatus } from "@/lib/format";
import { adminForDownload, recordDownload, toCsv } from "@/lib/admin-files";

export async function GET(_req: Request, { params }: { params: Promise<{ kind: string }> }) {
  const admin = await adminForDownload();
  if (!admin) return new Response("Admins only.", { status: 403 });
  const { kind } = await params;

  let csv: string;
  switch (kind) {
    case "deals":
      csv = toCsv(
        ["Title", "Store", "Category", "Tag", "Type", "Offer", "Price", "Was", "Price per", "From price", "Cashback", "Catches", "Hearts", "Status", "Source", "Posted by", "Posted at", "Link"],
        getAdminDealsView().map((d) => [
          d.title,
          d.store,
          d.category,
          d.tag,
          d.kind ?? "price",
          d.offer ?? "",
          (d.kind ?? "price") === "price" ? d.price : "",
          (d.kind ?? "price") === "price" ? d.originalPrice : "",
          d.priceUnit ?? "",
          d.priceFrom ? "yes" : "",
          d.cashback ?? "",
          d.conditions?.join(" ") ?? "",
          d.hearts,
          getDealStatus(d),
          d.source,
          d.postedByUsername ?? "",
          d.postedAt,
          d.url,
        ])
      );
      break;
    case "users":
      csv = toCsv(
        ["Username", "Email", "Role", "Suspended", "Joined", "Last login", "Deals", "Comments"],
        getAllUsersAdmin()
          .filter((u) => !u.deletedAt)
          .map((u) => [u.username, u.email, u.role, u.suspended ? "yes" : "no", u.createdAt, u.lastLoginAt ?? "", u.dealCount, u.commentCount])
      );
      break;
    case "comments":
      csv = toCsv(
        ["Author", "Deal", "Comment", "Reports", "Posted at"],
        getAllCommentsAdmin().map((c) => [c.username, c.dealSlug, c.text, c.reportCount, c.createdAt])
      );
      break;
    case "activity":
      csv = toCsv(
        ["When", "Who", "Role", "Action", "Target", "Detail"],
        getAuditLog({ limit: 100000 }).entries.map((e) => [e.at, e.actorUsername, e.actorRole, e.action, e.targetLabel, e.detail])
      );
      break;
    default:
      return new Response("Unknown export.", { status: 404 });
  }

  recordDownload(admin, `the ${kind} spreadsheet`);
  const day = new Date().toISOString().slice(0, 10);
  // A byte-order mark so Excel reads £ and emoji correctly.
  return new Response(`﻿${csv}`, {
    headers: {
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": `attachment; filename="dealsnap-${kind}-${day}.csv"`,
      "cache-control": "no-store",
    },
  });
}
