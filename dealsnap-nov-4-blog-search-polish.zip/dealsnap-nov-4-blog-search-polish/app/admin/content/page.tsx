import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getBanners, getEvents, getPromos } from "@/lib/db";
import { bannerState } from "@/lib/banners";
import { eventState, ukDay } from "@/lib/events";
import Icon, { type IconName } from "@/components/Icon";
import ContentTabs from "@/components/admin/ContentTabs";

export const metadata = { title: "Site content" };

// Site content: every place staff can put something in front of visitors, with
// a map of where each one sits on a page, what's live in each, and a way to
// make a new one. The numbers on the map match the numbered slots beside it.
export default async function AdminContentPage() {
  await requirePermission("content.manage");
  const today = ukDay();
  const promos = getPromos();
  const liveOf = (kind: "card" | "banner" | "signup") =>
    promos.filter((p) => p.kind === kind && bannerState(p, today) === "live").length;
  const waitingOf = (kind: "card" | "banner" | "signup") =>
    promos.filter((p) => p.kind === kind && bannerState(p, today) === "scheduled").length;
  const strips = getBanners();
  const events = getEvents();

  const slots: {
    n: number;
    name: string;
    icon: IconName;
    where: string;
    live: number;
    waiting: number;
    manage: string;
    create: { href: string; label: string };
  }[] = [
    {
      n: 1,
      name: "Top strip",
      icon: "megaphone",
      where: "A thin line of news above the header, on every page. The newest live one shows.",
      live: strips.filter((b) => bannerState(b, today) === "live").length,
      waiting: strips.filter((b) => bannerState(b, today) === "scheduled").length,
      manage: "/admin/banners",
      create: { href: "/admin/banners/new", label: "New message" },
    },
    {
      n: 2,
      name: "Promo banner",
      icon: "sparkles",
      where: "A band under the header, in your colours, with an optional logo. Scrolls away with the page.",
      live: liveOf("banner"),
      waiting: waitingOf("banner"),
      manage: "/admin/promos",
      create: { href: "/admin/promos/new?kind=banner", label: "New banner" },
    },
    {
      n: 3,
      name: "Promo card",
      icon: "tag",
      where: "A card inside the deal lists after the deal number you pick, with an optional picture and “Promoted” tag.",
      live: liveOf("card"),
      waiting: waitingOf("card"),
      manage: "/admin/promos",
      create: { href: "/admin/promos/new?kind=card", label: "New card" },
    },
    {
      n: 4,
      name: "Sign-up tile",
      icon: "party",
      where: "A card in the deal lists that asks people to join, listing the benefits. Only people who aren't signed in see it.",
      live: liveOf("signup"),
      waiting: waitingOf("signup"),
      manage: "/admin/promos",
      create: { href: "/admin/promos/new?kind=signup", label: "New tile" },
    },
    {
      n: 5,
      name: "Events",
      icon: "calendar",
      where: "Black Friday, Christmas, Easter… each gets its own page, a button and (if you choose) its own top strip while it's on.",
      live: events.filter((e) => eventState(e) === "on").length,
      waiting: events.filter((e) => eventState(e) === "scheduled").length,
      manage: "/admin/events",
      create: { href: "/admin/events/new", label: "New event" },
    },
  ];

  const bar = "flex h-6 items-center justify-center rounded text-[11px] font-semibold";
  const slot = `${bar} bg-orange-100 text-orange-700 hover:bg-orange-200 dark:bg-orange-950/50 dark:text-orange-300`;
  const grey = "rounded bg-zinc-100 dark:bg-zinc-800";

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-xl font-bold sm:text-2xl">Site content</h1>
        <p className="text-sm text-zinc-500">
          Everything you can put in front of visitors, in one place. The map shows where each one sits on a page.
        </p>
      </div>
      <ContentTabs current="overview" />

      <div className="flex flex-col gap-5 md:flex-row md:items-start">
        <div
          inert
          className="flex w-full max-w-[220px] shrink-0 flex-col gap-1.5 self-center rounded-2xl border border-zinc-200 bg-white p-3 md:self-start dark:border-zinc-800 dark:bg-zinc-900"
        >
          <Link href="/admin/banners" className={slot}>
            1 · Top strip
          </Link>
          <div className={`${grey} flex h-7 items-center px-2 text-[11px] text-zinc-500`}>Header</div>
          <Link href="/admin/promos" className={slot}>
            2 · Promo banner
          </Link>
          <div className={`${grey} h-6`} />
          <div className="h-3 w-1/2 rounded bg-zinc-200 dark:bg-zinc-700" />
          <div className={`${grey} h-9`} />
          <div className={`${grey} h-9`} />
          <Link href="/admin/promos" className={`${slot} h-9`}>
            3 · Promo card
          </Link>
          <div className={`${grey} h-9`} />
          <Link href="/admin/promos" className={`${slot} h-9`}>
            4 · Sign-up tile
          </Link>
          <div className={`${grey} h-9`} />
        </div>

        <ul className="flex min-w-0 flex-1 flex-col gap-2">
          {slots.map((s) => (
            <li
              key={s.n}
              className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-3 sm:flex-row sm:items-center dark:border-zinc-800 dark:bg-zinc-900"
            >
              <div className="flex min-w-0 flex-1 items-start gap-3">
                <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400">
                  <Icon name={s.icon} className="size-5" />
                </span>
                <div className="flex min-w-0 flex-col gap-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-medium">
                      {s.n} · {s.name}
                    </span>
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        s.live
                          ? "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400"
                          : "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400"
                      }`}
                    >
                      {s.live ? `${s.live} showing now` : "Nothing showing"}
                    </span>
                    {s.waiting > 0 && (
                      <span className="rounded-full bg-sky-100 px-2 py-0.5 text-xs font-medium text-sky-700 dark:bg-sky-950/40 dark:text-sky-400">
                        {s.waiting} starting later
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-zinc-500">{s.where}</p>
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <Link
                  href={s.manage}
                  className="inline-flex min-h-[36px] items-center rounded-lg border border-zinc-300 px-3.5 text-xs font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
                >
                  Manage
                </Link>
                <Link
                  href={s.create.href}
                  className="inline-flex min-h-[36px] items-center rounded-lg bg-orange-500 px-3.5 text-xs font-semibold text-white hover:bg-orange-600"
                >
                  + {s.create.label}
                </Link>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
