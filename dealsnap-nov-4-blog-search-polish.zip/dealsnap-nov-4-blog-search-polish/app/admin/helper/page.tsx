import { requirePermission } from "@/lib/auth";
import HelperDesk, { type DeskParams } from "@/components/staff/HelperDesk";

export const metadata = { title: "Helper desk" };

// The helper desk inside the admin area, for moderators and admins: the same
// list helpers work from in My account, keeping the admin menu beside it.
export default async function AdminHelperDeskPage({ searchParams }: { searchParams: Promise<DeskParams> }) {
  const user = await requirePermission("deals.fix");
  const sp = await searchParams;
  return (
    <div className="flex flex-col gap-5">
      <HelperDesk sp={sp} user={user} base="/admin/helper" />
    </div>
  );
}
