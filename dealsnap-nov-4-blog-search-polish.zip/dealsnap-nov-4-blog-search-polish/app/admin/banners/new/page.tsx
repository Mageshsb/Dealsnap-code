import { requirePermission } from "@/lib/auth";
import BannerEditor from "@/components/admin/BannerEditor";

export const metadata = { title: "New top strip message" };

export default async function NewBannerPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  await requirePermission("content.manage");
  const { error } = await searchParams;
  return <BannerEditor error={error} />;
}
