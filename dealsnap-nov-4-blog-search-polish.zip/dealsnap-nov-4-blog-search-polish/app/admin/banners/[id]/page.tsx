import { notFound } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import { getBannerById } from "@/lib/db";
import BannerEditor from "@/components/admin/BannerEditor";

export const metadata = { title: "Edit top strip message" };

export default async function EditBannerPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string; notice?: string }>;
}) {
  await requirePermission("content.manage");
  const banner = getBannerById((await params).id);
  if (!banner) notFound();
  const { error, notice } = await searchParams;
  return <BannerEditor banner={banner} error={error} notice={notice} />;
}
