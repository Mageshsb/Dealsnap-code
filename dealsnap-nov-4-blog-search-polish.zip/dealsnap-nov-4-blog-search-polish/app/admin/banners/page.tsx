import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getBanners } from "@/lib/db";
import { bannerState } from "@/lib/banners";
import { ukDay } from "@/lib/events";
import { setBannerLiveAction } from "@/lib/content-actions";
import BannerStatePill from "@/components/admin/BannerState";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import ContentHeader from "@/components/admin/ContentHeader";
import EmptyState from "@/components/EmptyState";

import Notice from "@/components/admin/Notice";
export const metadata = { title: "Top strip" };

const day = (d: string) =>
  new Date(`${d}T12:00:00Z`).toLocaleDateString("en-GB", { day: "numeric", month: "short", timeZone: "UTC" });

export default async function AdminBannersPage({ searchParams }: { searchParams: Promise<{ notice?: string }> }) {
  await requirePermission("content.manage");
  const { notice } = await searchParams;
  const today = ukDay();
  const banners = getBanners().map((b) => ({ banner: b, state: bannerState(b, today) }));

  return (
    <div className="flex flex-col gap-4">
      <ContentHeader
        current="strip"
        title="Top strip"
        description="A thin line of news above the header on every page, in colours you choose. The newest live one shows. For a bigger band under the header, use a promo banner."
        actions={
          <Link href="/admin/banners/new" className="rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
            + New message
          </Link>
        }
      />

      <Notice notice={notice} />

      <ul className="flex flex-col gap-2">
        {banners.map(({ banner, state }) => (
          <li
            key={banner.id}
            className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-3 sm:flex-row sm:items-center dark:border-zinc-800 dark:bg-zinc-900"
          >
            <div className="flex min-w-0 flex-1 flex-col gap-1">
              <div className="flex flex-wrap items-center gap-2">
                <BannerStatePill state={state} />
                {(banner.showFrom || banner.showUntil) && (
                  <span className="text-xs text-zinc-500">
                    {banner.showFrom ? day(banner.showFrom) : "Any time"} to{" "}
                    {banner.showUntil ? day(banner.showUntil) : "no end"}
                  </span>
                )}
              </div>
              <Link href={`/admin/banners/${banner.id}`} className="line-clamp-2 text-sm font-medium hover:underline">
                {banner.message}
              </Link>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <Link
                href={`/admin/banners/${banner.id}`}
                className="inline-flex min-h-[36px] items-center rounded-lg border border-zinc-300 px-3.5 text-xs font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
              >
                Edit
              </Link>
              <form action={setBannerLiveAction}>
                <input type="hidden" name="id" value={banner.id} />
                <input type="hidden" name="back" value="list" />
                <input type="hidden" name="live" value={banner.live ? "0" : "1"} />
                {banner.live ? (
                  <ConfirmSubmitButton
                    confirmText="Take this banner down? It disappears from every page."
                    confirmLabel="Take down"
                    className="inline-flex min-h-[36px] items-center rounded-lg border border-red-300 px-3.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/30"
                  >
                    Take down
                  </ConfirmSubmitButton>
                ) : (
                  <button
                    type="submit"
                    className="inline-flex min-h-[36px] items-center rounded-lg bg-orange-500 px-3.5 text-xs font-semibold text-white hover:bg-orange-600"
                  >
                    Put live
                  </button>
                )}
              </form>
            </div>
          </li>
        ))}
        {banners.length === 0 && (
          <li>
            <EmptyState icon="megaphone">
              <p>
                No messages yet.
              </p>
            </EmptyState>
          </li>
        )}
      </ul>
    </div>
  );
}
