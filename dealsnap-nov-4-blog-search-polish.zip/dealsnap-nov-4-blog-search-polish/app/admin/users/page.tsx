import Link from "next/link";
import SelectField from "@/components/SelectField";
import RowMenu from "@/components/admin/RowMenu";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import SuspendControl from "@/components/admin/SuspendControl";
import { findUsersAdmin, getOpenProfileReports, type UserRole } from "@/lib/db";
import { makeHelperAction, setUserRoleAction } from "@/lib/admin-actions";
import { requireStaff } from "@/lib/auth";
import { ROLE_LABELS, can, mayManageAccount } from "@/lib/permissions";
import { summariseActivity } from "@/lib/audit";
import { formatDate, timeAgo } from "@/lib/format";
import Icon from "@/components/Icon";
import { SEARCH_MAX } from "@/lib/search-limits";
import Pager from "@/components/admin/Pager";
import { searchField } from "@/components/admin/formStyles";

import Notice from "@/components/admin/Notice";
import ListHeader from "@/components/admin/ListHeader";
const SORTS = {
  newest: "Newest first",
  oldest: "Oldest first",
  "deals-desc": "Most deals posted",
  "comments-desc": "Most comments",
  "username-asc": "Username A–Z",
} as const;
type SortKey = keyof typeof SORTS;

const ROLES: UserRole[] = ["admin", "moderator", "helper", "user"];
const PAGE_SIZE = 25;

export const metadata = { title: "Members" };

export default async function AdminUsersPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; status?: string; role?: string; sort?: string; page?: string; error?: string; notice?: string }>;
}) {
  const { q: qParam = "", status: statusParam = "all", role: roleParam = "all", sort: sortParam, page: pageParam, error, notice } = await searchParams;
  const q = qParam.trim().slice(0, SEARCH_MAX);
  const status = (["suspended", "reported", "new", "unconfirmed", "inactive"] as const).find((v) => v === statusParam) ?? "all";
  const role = ROLES.includes(roleParam as UserRole) ? (roleParam as UserRole) : "all";
  const sort: SortKey = sortParam && sortParam in SORTS ? (sortParam as SortKey) : "newest";
  const currentUser = await requireStaff();
  const seePrivate = can(currentUser.role, "users.security");
  const mayChangeRoles = can(currentUser.role, "users.roles");
  const activity = can(currentUser.role, "activity.view") ? summariseActivity() : null;
  const page = Math.max(1, parseInt(pageParam ?? "1", 10) || 1);
  // One page at a time, searched and sorted by the database: quick with 15
  // members or 50,000.
  const { rows: users, total } = findUsersAdmin({
    search: q,
    searchEmail: seePrivate,
    status,
    role: role === "all" ? undefined : role,
    sort,
    limit: PAGE_SIZE,
    offset: (page - 1) * PAGE_SIZE,
  });
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const profileReports = new Map(getOpenProfileReports().map((r) => [r.userId, r]));
  const href = (p: number) => {
    const params = new URLSearchParams(
      Object.entries({ q, status, role, sort, page: String(p) }).filter(
        ([k, v]) => v && !(k === "status" && v === "all") && !(k === "role" && v === "all") && !(k === "sort" && v === "newest") && !(k === "page" && v === "1"),
      ),
    ).toString();
    return params ? `/admin/users?${params}` : "/admin/users";
  };
  const hasFilters = q || status !== "all" || role !== "all" || sort !== "newest";

  return (
    <div className="flex flex-col gap-4">
      <ListHeader title="Members" count={total} noun="account" filtered={Boolean(hasFilters)} clearHref="/admin/users" />

      <Notice notice={notice} error={error} />

      <form className="grid grid-cols-2 items-center gap-2 sm:flex sm:flex-wrap" action="/admin/users">
        <input
          type="search"
          aria-label="Search this list"
          name="q"
          defaultValue={q}
          maxLength={SEARCH_MAX}
          placeholder={seePrivate ? "Search username or email…" : "Search username…"}
          className={`col-span-2 min-w-[180px] sm:col-span-1 sm:flex-1 ${searchField}`}
        />
        <SelectField
          look="admin"
          name="status"
          label="Accounts"
          defaultValue={status}
          options={[
            { value: "all", label: "All accounts" },
            { value: "suspended", label: "Suspended only" },
            { value: "reported", label: "Reported profiles" },
            { value: "new", label: "Joined this week" },
            { value: "unconfirmed", label: "Email not confirmed" },
            { value: "inactive", label: "Not seen for 90 days" },
          ]}
          className="w-full sm:w-auto"
        />
        <SelectField
          look="admin"
          name="role"
          label="Role"
          defaultValue={role}
          options={[
            { value: "all", label: "All roles" },
            { value: "admin", label: "Admins" },
            { value: "moderator", label: "Moderators" },
            { value: "helper", label: `${ROLE_LABELS.helper}s` },
            { value: "user", label: "Regular members" },
          ]}
          className="w-full sm:w-auto"
        />
        <SelectField
          look="admin"
          name="sort"
          label="Sort by"
          defaultValue={sort}
          options={Object.entries(SORTS).map(([key, label]) => ({ value: key, label }))}
          className="w-full sm:w-auto"
          leadingIcon="arrow-up-down"
        />
        <button
          type="submit"
          className="col-span-2 min-h-[42px] rounded-lg bg-orange-500 px-5 py-2 text-sm font-semibold sm:col-auto text-white hover:bg-orange-600"
        >
          Apply
        </button>
      </form>

      <div className="rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
        <table className="block w-full text-left text-sm">
          <tbody className="block divide-y divide-zinc-100 dark:divide-zinc-800">
            {users.map((u) => {
              const isSelf = u.id === currentUser.id;
              // Moderators can only suspend regular members, and never themselves.
              const canSuspend = !isSelf && can(currentUser.role, "users.suspend") && mayManageAccount(currentUser.role, u.role);
              const roleEl = (
                <span className="inline-flex flex-wrap items-center gap-1">
                  <span
                    className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                      u.role === "admin"
                        ? "bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400"
                        : u.role === "moderator"
                          ? "bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400"
                          : u.role === "helper"
                            ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400"
                            : "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400"
                    }`}
                  >
                    {u.role === "moderator" && <Icon name="shield" className="mr-1" />}
                    {u.role === "helper" && <Icon name="badge-check" className="mr-1" />}
                    {u.role === "helper" ? ROLE_LABELS.helper : u.role}
                  </span>
                  {u.deletedAt && (
                    <span className="rounded-full bg-zinc-200 px-2 py-0.5 text-xs font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">
                      Deleted account
                    </span>
                  )}
                  {profileReports.has(u.id) && (
                    <Link
                      href={`/admin/users/${u.id}`}
                      className="rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700 hover:underline dark:bg-red-950/40 dark:text-red-400"
                    >
                      <Icon name="flag" className="mr-1" />Profile reported ×{profileReports.get(u.id)!.count}
                    </Link>
                  )}
                  {u.suspended && (
                    <span className="rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700 dark:bg-red-950/40 dark:text-red-400">
                      {u.suspendedUntil ? `Suspended until ${formatDate(u.suspendedUntil)}` : "Suspended"}
                    </span>
                  )}
                </span>
              );
              const lastLoginText = u.lastLoginAt ? `last login ${timeAgo(u.lastLoginAt)}` : "last login unknown";
              const act = activity?.get(u.id);
              const activityEl =
                activity && u.role === "moderator" ? (
                  <Link
                    href={`/admin/activity?staff=${u.id}`}
                    className={`mt-1 inline-flex items-center gap-1 text-xs font-medium hover:underline ${
                      act?.flagged ? "text-red-600" : "text-sky-700 dark:text-sky-400"
                    }`}
                  >
                    <Icon name={act?.flagged ? "warning" : "clipboard"} className="size-3.5" />
                    {act?.week ?? 0} action{act?.week === 1 ? "" : "s"} this week
                  </Link>
                ) : null;
              const commentsEl =
                u.commentCount > 0 ? (
                  <Link href={`/admin/comments?q=${encodeURIComponent(u.username)}`} className="hover:underline">
                    {u.commentCount}
                  </Link>
                ) : (
                  u.commentCount
                );
              return (
                <tr key={u.id} className="block px-4 py-3 sm:flex sm:items-start sm:justify-between sm:gap-4">
                  <td className="block sm:min-w-0 sm:flex-1">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                      <Link href={`/admin/users/${u.id}`} className="font-medium hover:text-orange-600 hover:underline">
                        {u.username}
                      </Link>
                      <span>{roleEl}</span>
                    </div>
                    {seePrivate && <p className="break-all text-xs text-zinc-500">{u.email}</p>}
                    {activityEl && <div>{activityEl}</div>}
                    <p className="mt-2 text-xs text-zinc-500">
                      Joined {formatDate(u.createdAt)} · {lastLoginText} · {u.dealCount} deal{u.dealCount === 1 ? "" : "s"} · {commentsEl} comment
                      {u.commentCount === 1 ? "" : "s"}
                    </p>
                  </td>
                  <td className="block pt-3 sm:shrink-0 sm:pt-0">
                    <div className="flex flex-wrap items-center gap-2">
                      {canSuspend && (
                        <SuspendControl user={u} />
                      )}
                      {mayChangeRoles && !isSelf && (
                        <RowMenu label="Role">
                          {u.role === "user" && !u.suspended && (
                            <Link href={`/admin/users/${u.id}/make-moderator`} role="menuitem" className="text-sky-700 dark:text-sky-400">
                              Make moderator…
                            </Link>
                          )}
                          {u.role === "user" && !u.suspended && (
                            <form action={makeHelperAction}>
                              <input type="hidden" name="userId" value={u.id} />
                              <ConfirmSubmitButton
                                confirmText={`Make ${u.username} a ${ROLE_LABELS.helper}? They can fix details on live deals and mark deals ended. They can't remove anything.`}
                                className="text-emerald-700 dark:text-emerald-400"
                              >
                                Make {ROLE_LABELS.helper}
                              </ConfirmSubmitButton>
                            </form>
                          )}
                          {u.role === "helper" && (
                            <form action={setUserRoleAction}>
                              <input type="hidden" name="userId" value={u.id} />
                              <input type="hidden" name="role" value="user" />
                              <ConfirmSubmitButton
                                confirmText={`Remove ${ROLE_LABELS.helper} from ${u.username}?`}
                                className="text-zinc-700 dark:text-zinc-300"
                              >
                                Remove {ROLE_LABELS.helper}
                              </ConfirmSubmitButton>
                            </form>
                          )}
                          {u.role === "moderator" && (
                            <form action={setUserRoleAction}>
                              <input type="hidden" name="userId" value={u.id} />
                              <input type="hidden" name="role" value="user" />
                              <ConfirmSubmitButton
                                confirmText={`Remove moderator access from ${u.username}?`}
                                className="text-zinc-700 dark:text-zinc-300"
                              >
                                Remove moderator
                              </ConfirmSubmitButton>
                            </form>
                          )}
                          {u.role === "admin" && (
                            <form action={setUserRoleAction}>
                              <input type="hidden" name="userId" value={u.id} />
                              <input type="hidden" name="role" value="user" />
                              <ConfirmSubmitButton
                                confirmText={`Remove admin access from ${u.username}?`}
                                className="text-zinc-700 dark:text-zinc-300"
                              >
                                Remove admin
                              </ConfirmSubmitButton>
                            </form>
                          )}
                          {u.role !== "admin" && !u.suspended && (
                            <Link href={`/admin/users/${u.id}/make-admin`} role="menuitem" className="text-red-600">
                              Make admin…
                            </Link>
                          )}
                        </RowMenu>
                      )}
                      {!canSuspend && !(mayChangeRoles && !isSelf) && <span className="text-xs text-zinc-500 dark:text-zinc-400">—</span>}
                    </div>
                  </td>
                </tr>
              );
            })}
            {users.length === 0 && (
              <tr className="block">
                <td colSpan={6} className="block px-4 py-8 text-center text-zinc-500">
                  No members match these filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Pager page={page} totalPages={totalPages} href={href} />
    </div>
  );
}
