import { requirePermission } from "@/lib/auth";
import PromoteUser from "@/components/admin/PromoteUser";

export const metadata = { title: "Make admin" };

export default async function MakeAdminPage(props: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string }>;
}) {
  await requirePermission("users.roles");
  return <PromoteUser {...props} tier="admin" />;
}
