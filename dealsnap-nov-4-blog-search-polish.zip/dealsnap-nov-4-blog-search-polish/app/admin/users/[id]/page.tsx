import Link from "next/link";
import SectionTabs from "@/components/admin/SectionTabs";
import { isStillAhead } from "@/lib/moderation";
import { notFound } from "next/navigation";
import { requirePermission } from "@/lib/auth";
import {
  findUserById,
  getDealsByUser,
  getUserNotes,
  getAuditLog,
  getEscalations,
  getUserReportSummary,
  getRecentCommentsByUser,
  countSessionsForUser,
  getUserAdmin,
  getOpenProfileReportsFor,
} from "@/lib/db";
import { ROLE_LABELS, can, mayManageAccount } from "@/lib/permissions";
import { isTrustedPoster } from "@/lib/trust";
import { AUDIT_ACTIONS, type AuditAction } from "@/lib/audit";
import {
  addUserNoteAction,
  signOutUserAction,
  resetTwoStepAction,
  escalateAction,
  handleProfileReportAction,
} from "@/lib/admin-actions";
import { formatDate, timeAgo } from "@/lib/format";
import SuspendControl from "@/components/admin/SuspendControl";
import ReasonDialog from "@/components/admin/ReasonDialog";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import Icon from "@/components/Icon";
import ClashNotice from "@/components/admin/ClashNotice";
import { seenNow } from "@/lib/collisions";
import StaffWork from "@/components/staff/StaffWork";
import { TEAM_RANGES } from "@/lib/staff-impact";

import Notice from "@/components/admin/Notice";
export const metadata = { title: "Member" };

const card = "flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900";
const field =
  "rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950";
const outline =
  "inline-flex min-h-[36px] items-center rounded-lg border border-zinc-300 px-3.5 py-1.5 text-xs font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800";

const STATUS_STYLE: Record<string, string> = {
  live: "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400",
  pending: "bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  removed: "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400",
};

export default async function AdminUserPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ notice?: string; error?: string; clash?: string; tab?: string; days?: string; from?: string }>;
}) {
  const viewer = await requirePermission("users.view");
  const { id } = await params;
  const { notice, error, clash, tab, days, from } = await searchParams;
  const user = findUserById(id);
  if (!user) notFound();

  const seePrivate = can(viewer.role, "users.security");
  const isSelf = viewer.id === user.id;
  const row = getUserAdmin(id);
  const deals = getDealsByUser(id);
  const comments = getRecentCommentsByUser(id, 8);
  const profileReports = getOpenProfileReportsFor(id);
  const canHandleProfile = can(viewer.role, "users.suspend") && mayManageAccount(viewer.role, user.role);
  const notes = getUserNotes(id);
  const reports = getUserReportSummary(id);
  const escalations = getEscalations({ targetId: id });
  const history = getAuditLog({ targetIds: [id, ...deals.map((d) => d.slug)], limit: 30 }).entries;
  const sessions = seePrivate ? countSessionsForUser(id) : 0;
  // Everyone is a member first; helpers, moderators and admins have staff work on top, which admins can see here.
  const hasStaffTab = can(viewer.role, "activity.view") && user.role !== "user";
  const staffTab = hasStaffTab && tab === "staff";
  const range = TEAM_RANGES.find((r) => r.key === days) ?? TEAM_RANGES[2];
  const fromTeam = from === "team";
  const pageHref = (extra: Record<string, string>) => {
    const qs = new URLSearchParams({ ...(fromTeam ? { from: "team" } : {}), ...extra }).toString();
    return `/admin/users/${id}${qs ? `?${qs}` : ""}`;
  };
  const canSuspend = !isSelf && can(viewer.role, "users.suspend") && mayManageAccount(viewer.role, user.role);
  const live = deals.filter((d) => d.status === "live").length;
  const pending = deals.filter((d) => d.status === "pending").length;
  const removed = deals.filter((d) => d.status === "removed").length;
  const back = `/admin/users/${id}`;

  return (
    <div className="flex flex-col gap-5">
      <div>
        <Link
          href={fromTeam ? `/admin/team${range.key === "30" ? "" : `?days=${range.key}`}` : "/admin/users"}
          className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline"
        >
          {fromTeam ? "← Back to the team" : "← Back to members"}
        </Link>
        <div className="mt-2 flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="flex flex-wrap items-center gap-2 text-xl font-bold sm:text-2xl">
              {user.username}
              <span
                className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
                  user.role === "admin"
                    ? "bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400"
                    : user.role === "moderator"
                      ? "bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400"
                      : user.role === "helper"
                        ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400"
                        : "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400"
                }`}
              >
                {user.role === "moderator" && <Icon name="shield" className="mr-1" />}
                {user.role === "helper" && <Icon name="badge-check" className="mr-1" />}
                {user.role === "user" ? "member" : user.role === "helper" ? ROLE_LABELS.helper : user.role}
              </span>
              {user.role === "user" && isTrustedPoster(user) && (
                <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-semibold text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">
                  <Icon name="badge-check" className="mr-1" />
                  Trusted poster
                </span>
              )}
              {user.deletedAt && <span className="rounded-full bg-zinc-200 px-2 py-0.5 text-xs dark:bg-zinc-800">Deleted account</span>}
              {user.modProbationUntil && isStillAhead(user.modProbationUntil) && (
                <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-700 dark:bg-amber-950/40 dark:text-amber-400">
                  On probation until {formatDate(user.modProbationUntil)}
                </span>
              )}
            </h1>
            <p className="text-sm text-zinc-500">
              {seePrivate && <>{user.email} · </>}joined {formatDate(user.createdAt)}
              {row?.lastLoginAt ? ` · last login ${timeAgo(row.lastLoginAt)}` : " · last login unknown"}
              {seePrivate && ` · two-step login ${user.totpEnabled ? "on" : "off"}`}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Link href={`/u/${encodeURIComponent(user.username)}`} target="_blank" className={outline}>
              Public profile ↗
            </Link>
            {canSuspend && <SuspendControl user={user} back={back} />}
            {!can(viewer.role, "escalations.resolve") && !isSelf && (
              <form action={escalateAction}>
                <input type="hidden" name="kind" value="user" />
                <input type="hidden" name="targetId" value={user.id} />
                <input type="hidden" name="targetLabel" value={user.username} />
                <input type="hidden" name="targetUrl" value={back} />
                <input type="hidden" name="back" value={back} />
                <ReasonDialog
                  label="Escalate to admins…"
                  title={`Ask an admin about ${user.username}`}
                  intro="The admins see your note on their dashboard."
                  noteLabel="What should they know?"
                  noteRequired
                  confirmLabel="Send to admins"
                  tone="sky"
                  buttonClassName={`${outline} text-sky-700 dark:text-sky-400`}
                />
              </form>
            )}
          </div>
        </div>
      </div>

      <ClashNotice message={clash} />
      <Notice notice={notice} error={error} />

      {user.suspended && (
        <div className="rounded-xl border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-900 dark:border-red-900 dark:bg-red-950/40 dark:text-red-200">
          <Icon name="ban" className="mr-1.5" />Suspended {user.suspendedUntil ? `until ${new Date(user.suspendedUntil).toLocaleString("en-GB", { dateStyle: "long", timeStyle: "short" })}` : "until lifted"}
          {user.suspensionReason ? `. Reason: ${user.suspensionReason}` : ""}
        </div>
      )}

      {profileReports.length > 0 && (
        <div className="flex flex-col gap-3 rounded-xl border border-red-300 bg-red-50 p-4 text-sm dark:border-red-900 dark:bg-red-950/30">
          <p className="font-semibold text-red-900 dark:text-red-200">
            <Icon name="flag" className="mr-1.5" />Profile reported {profileReports.length} time{profileReports.length === 1 ? "" : "s"}
          </p>
          <ul className="flex flex-col gap-0.5 text-red-900/80 dark:text-red-200/80">
            {profileReports.map((r, i) => (
              <li key={i}>
                {r.reason} · {timeAgo(r.createdAt)}
              </li>
            ))}
          </ul>
          <div className="flex items-center gap-3 rounded-lg bg-white/70 p-3 dark:bg-zinc-900/60">
            {user.avatarUrl ? (
              // eslint-disable-next-line @next/next/no-img-element -- member upload, shown so staff can judge it
              <img src={user.avatarUrl} alt="" className="h-14 w-14 shrink-0 rounded-full object-cover" />
            ) : (
              <span className="text-xs text-zinc-500">No profile picture</span>
            )}
            <div className="min-w-0 text-zinc-700 dark:text-zinc-300">
              <p className="font-semibold">{user.username}</p>
              <p className="whitespace-pre-line break-words text-xs">{user.bio || <span className="text-zinc-500 dark:text-zinc-400">No bio</span>}</p>
            </div>
          </div>
          {canHandleProfile ? (
            <form action={handleProfileReportAction} className="flex flex-wrap gap-2">
              <input type="hidden" name="userId" value={user.id} />
              <input type="hidden" name="seen" value={seenNow()} />
              {user.avatarUrl && (
                <button name="task" value="photo" className="min-h-[36px] rounded-lg bg-red-600 px-3.5 text-xs font-semibold text-white hover:bg-red-700">
                  Remove picture
                </button>
              )}
              {user.bio && (
                <button name="task" value="bio" className="min-h-[36px] rounded-lg bg-red-600 px-3.5 text-xs font-semibold text-white hover:bg-red-700">
                  Clear bio
                </button>
              )}
              <button name="task" value="username" className="min-h-[36px] rounded-lg bg-red-600 px-3.5 text-xs font-semibold text-white hover:bg-red-700">
                Reset username
              </button>
              <button name="task" value="dismiss" className={outline}>
                Nothing wrong, dismiss
              </button>
            </form>
          ) : (
            <p className="text-xs text-zinc-500">Only an admin can change a staff member&apos;s profile.</p>
          )}
          <p className="text-xs text-zinc-500">
            A reset username becomes a neutral one like member_3fa9c1, and they can pick a new one straight away.
          </p>
        </div>
      )}

      {hasStaffTab && (
        <SectionTabs
          label="Sections"
          tabs={[
            { key: "member", label: "Member", href: pageHref({}) },
            { key: "staff", label: "Staff work", href: pageHref({ tab: "staff", days: range.key }) },
          ]}
          current={staffTab ? "staff" : "member"}
        />
      )}

      {staffTab ? (
        <StaffWork
          userId={user.id}
          role={user.role}
          username={user.username}
          rangeKey={range.key}
          hrefFor={(k) => pageHref({ tab: "staff", days: k })}
        />
      ) : (
      <>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          ["Live deals", live],
          ["Pending", pending],
          ["Removed deals", removed],
          ["Comments", row?.commentCount ?? 0],
          ["Reports on their deals", reports.reportsOnTheirDeals],
          ["Reports on their comments", reports.reportsOnTheirComments],
          ["Reports they've made", reports.reportsMade],
        ].map(([label, value]) => (
          <div key={label as string} className="flex flex-col gap-0.5 rounded-xl border border-zinc-200 bg-white p-3 dark:border-zinc-800 dark:bg-zinc-900">
            <p className="text-xs font-medium text-zinc-500">{label}</p>
            <p className="text-xl font-bold">{value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <section className={card}>
          <h2 className="text-sm font-bold uppercase tracking-wide text-zinc-600 dark:text-zinc-300"><Icon name="note" className="mr-1.5" />Staff notes</h2>
          <p className="-mt-2 text-xs text-zinc-500">Private to moderators and admins. Notes can&apos;t be edited or deleted.</p>
          <form action={addUserNoteAction} className="flex flex-col gap-2">
            <input type="hidden" name="userId" value={user.id} />
            <textarea name="text" required maxLength={1000} rows={2} placeholder="e.g. Warned about posting referral links" className={field} />
            <button type="submit" className="min-h-[36px] self-start rounded-lg bg-zinc-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-zinc-700 dark:bg-zinc-100 dark:text-zinc-900">
              Add note
            </button>
          </form>
          <ul className="flex flex-col gap-2">
            {notes.map((n) => (
              <li key={n.id} className="rounded-lg bg-zinc-50 px-3 py-2 text-sm dark:bg-zinc-950/50">
                <p className="whitespace-pre-wrap">{n.text}</p>
                <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                  {n.authorUsername} · {timeAgo(n.createdAt)}
                </p>
              </li>
            ))}
            {notes.length === 0 && <li className="text-sm text-zinc-500">No notes yet.</li>}
          </ul>
        </section>

        <section className={card}>
          <h2 className="text-sm font-bold uppercase tracking-wide text-zinc-600 dark:text-zinc-300"><Icon name="folder" className="mr-1.5" />Moderation history</h2>
          <ul className="flex flex-col gap-2">
            {history.map((e) => (
              <li key={e.id} className="text-sm">
                <p>
                  <Icon name={AUDIT_ACTIONS[e.action as AuditAction]?.icon ?? "clipboard"} className="mr-1 text-zinc-500 dark:text-zinc-400" />
                  <b>{e.actorUsername}</b>{" "}
                  <span className="text-zinc-500">{AUDIT_ACTIONS[e.action as AuditAction]?.text ?? e.action}</span> {e.targetLabel}
                </p>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  {e.detail ? `${e.detail} · ` : ""}
                  {timeAgo(e.at)}
                </p>
              </li>
            ))}
            {history.length === 0 && <li className="text-sm text-zinc-500">Nothing recorded yet.</li>}
          </ul>
          {escalations.length > 0 && (
            <div className="border-t border-zinc-100 pt-2 text-xs text-zinc-500 dark:border-zinc-800">
              {escalations.map((esc) => (
                <p key={esc.id}>
                  <Icon name="hand" className="mr-1.5" />Escalated by {esc.createdByUsername} {timeAgo(esc.createdAt)}: {esc.note}
                  {esc.resolvedAt ? ` · resolved by ${esc.resolvedByUsername}` : " · open"}
                </p>
              ))}
            </div>
          )}
        </section>

        <section className={card}>
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-sm font-bold uppercase tracking-wide text-zinc-600 dark:text-zinc-300"><Icon name="tag" className="mr-1.5" />Recent deals</h2>
            <Link href={`/admin/deals?q=${encodeURIComponent(user.username)}`} className="text-xs font-medium text-orange-700 dark:text-orange-400 hover:underline">
              All in Deals →
            </Link>
          </div>
          <ul className="flex flex-col gap-2">
            {deals.slice(0, 8).map((d) => (
              <li key={d.id} className="flex items-start justify-between gap-3 text-sm">
                <div className="min-w-0">
                  <Link href={`/deals/${d.slug}`} target="_blank" className="line-clamp-1 font-medium hover:underline">
                    {d.title}
                  </Link>
                  {d.status === "removed" && d.moderationReason && <p className="text-xs text-zinc-500">Removed: {d.moderationReason}</p>}
                </div>
                <span className={`shrink-0 rounded-full px-2 py-0.5 text-xs font-medium ${STATUS_STYLE[d.status]}`}>{d.status}</span>
              </li>
            ))}
            {deals.length === 0 && <li className="text-sm text-zinc-500">No deals posted.</li>}
          </ul>
        </section>

        <section className={card}>
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-sm font-bold uppercase tracking-wide text-zinc-600 dark:text-zinc-300"><Icon name="comment" className="mr-1.5" />Recent comments</h2>
            <Link href={`/admin/comments?q=${encodeURIComponent(user.username)}`} className="text-xs font-medium text-orange-700 dark:text-orange-400 hover:underline">
              All in Comments →
            </Link>
          </div>
          <ul className="flex flex-col gap-2">
            {comments.map((c) => (
              <li key={c.id} className="text-sm">
                <p className="line-clamp-2">{c.text}</p>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  <Link href={`/deals/${c.dealSlug}#comments`} target="_blank" className="hover:underline">
                    on deal
                  </Link>{" "}
                  · {timeAgo(c.createdAt)}
                  {c.reportCount > 0 && <span className="ml-1 font-medium text-red-600">· <Icon name="flag" className="mr-1.5" />{c.reportCount}</span>}
                </p>
              </li>
            ))}
            {comments.length === 0 && <li className="text-sm text-zinc-500">No comments.</li>}
          </ul>
        </section>
      </div>

      {seePrivate && !isSelf && (
        <section className={card}>
          <h2 className="text-sm font-bold uppercase tracking-wide text-zinc-600 dark:text-zinc-300"><Icon name="lock" className="mr-1.5" />Account security</h2>
          <p className="-mt-2 text-xs text-zinc-500">
            {sessions} active session{sessions === 1 ? "" : "s"} (devices signed in).
            {hasStaffTab && (
              <>
                {" "}
                <Link href={pageHref({ tab: "staff", days: range.key })} className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
                  See their staff work →
                </Link>
              </>
            )}
          </p>
          <div className="flex flex-wrap gap-2">
            <form action={signOutUserAction}>
              <input type="hidden" name="userId" value={user.id} />
              <ConfirmSubmitButton confirmText={`Sign ${user.username} out on every device?`} className={outline}>
                Sign out everywhere
              </ConfirmSubmitButton>
            </form>
            {user.totpEnabled && (
              <form action={resetTwoStepAction}>
                <input type="hidden" name="userId" value={user.id} />
                <ConfirmSubmitButton
                  confirmText={`Turn off two-step login for ${user.username}? Only do this if you've confirmed it's really them (for example, they lost their phone).`}
                  className={`${outline} text-red-600`}
                >
                  Reset two-step login
                </ConfirmSubmitButton>
              </form>
            )}
          </div>
        </section>
      )}
      </>
      )}
    </div>
  );
}
