import { requirePermission } from "@/lib/auth";
import PromoteUser from "@/components/admin/PromoteUser";

export const metadata = { title: "Make moderator" };

export default async function MakeModeratorPage(props: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string }>;
}) {
  await requirePermission("users.roles");
  return <PromoteUser {...props} tier="moderator" />;
}
