import Link from "next/link";
import { requirePermission } from "@/lib/auth";
import { getLoggedErrors } from "@/lib/error-log";
import { resolveAllErrorsAction, resolveErrorAction } from "@/lib/admin-actions";
import { timeAgo } from "@/lib/format";
import { isStaging } from "@/lib/environment";
import Icon from "@/components/Icon";
import EmptyState from "@/components/EmptyState";

export const metadata = { title: "Site health" };

// What has gone wrong on the site, newest first: a page that crashed, an action
// that failed, a script that broke in someone's browser. One line per problem
// with how often it happened; "Dealt with" tucks it away until it happens again.
export default async function AdminErrorsPage({ searchParams }: { searchParams: Promise<{ show?: string }> }) {
  await requirePermission("settings.manage");
  const { show } = await searchParams;
  const showResolved = show === "all";
  const errors = getLoggedErrors({ showResolved });
  const open = errors.filter((e) => !e.resolvedAt).length;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-end justify-between gap-x-4 gap-y-2">
        <div>
          <h1 className="text-xl font-bold sm:text-2xl">Site health</h1>
          <p className="max-w-2xl text-sm text-zinc-500">
            Anything that broke for a visitor, as it happens. {isStaging ? "This is the test copy, so these are test problems. " : ""}
            Turn on the alert email in Settings to hear about new problems without checking here.
          </p>
        </div>
        <div className="flex items-center gap-3 text-sm">
          <Link href={showResolved ? "/admin/errors" : "/admin/errors?show=all"} className="font-medium text-zinc-500 hover:underline">
            {showResolved ? "Hide dealt with" : "Show dealt with"}
          </Link>
          {open > 0 && (
            <form action={resolveAllErrorsAction}>
              <button type="submit" className="rounded-lg border border-zinc-300 px-3 py-1.5 font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">
                Dealt with all
              </button>
            </form>
          )}
        </div>
      </div>

      {errors.length === 0 ? (
        <EmptyState icon="circle-check">
          <p>Nothing has broken. If something does, it shows up here.</p>
        </EmptyState>
      ) : (
        <ul className="flex flex-col divide-y divide-zinc-100 rounded-xl border border-zinc-200 bg-white dark:divide-zinc-800 dark:border-zinc-800 dark:bg-zinc-900">
          {errors.map((e) => (
            <li key={e.id} className={`flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4 ${e.resolvedAt ? "opacity-60" : ""}`}>
              <div className="min-w-0">
                <p className="break-words text-sm font-medium">{e.message}</p>
                <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-zinc-500">
                  <span className={`rounded-full px-2 py-0.5 font-medium ${e.kind === "server" ? "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400" : "bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400"}`}>
                    {e.kind === "server" ? "Server" : "Browser"}
                  </span>
                  <span className="font-mono">{e.path || "—"}</span>
                  <span>
                    {e.count} time{e.count === 1 ? "" : "s"} · last {timeAgo(e.lastAt)} · first {timeAgo(e.firstAt)}
                  </span>
                  {e.resolvedAt && <span>· dealt with {timeAgo(e.resolvedAt)}</span>}
                </p>
                {e.detail && (
                  <details className="mt-1.5">
                    <summary className="inline-flex cursor-pointer items-center gap-1 text-xs font-medium text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200">
                      <Icon name="chevron-down" className="size-3.5" />
                      Where it happened{e.digest ? ` (code ${e.digest})` : ""}
                    </summary>
                    <pre className="mt-1 max-w-full overflow-x-auto rounded-lg bg-zinc-100 p-2 text-[11px] leading-snug dark:bg-zinc-800">{e.detail}</pre>
                  </details>
                )}
              </div>
              {!e.resolvedAt && (
                <form action={resolveErrorAction} className="shrink-0">
                  <input type="hidden" name="id" value={e.id} />
                  <button type="submit" className="min-h-9 rounded-lg border border-zinc-300 px-3 py-1.5 text-xs font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">
                    Dealt with
                  </button>
                </form>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
