import Link from "next/link";
import { requireStaff } from "@/lib/auth";
import { getSiteSettings } from "@/lib/site-settings";
import Icon from "@/components/Icon";

export const metadata = { title: "Guidelines" };

export default async function ModeratorGuidelinesPage() {
  const user = await requireStaff();
  const { modGuidelines } = getSiteSettings();

  return (
    <div className="flex max-w-2xl flex-col gap-4">
      <div>
        <h1 className="flex items-center gap-2 text-xl font-bold sm:text-2xl">
          <Icon name="book-open" className="size-6 text-orange-700 dark:text-orange-400" />
          Moderator guidelines
        </h1>
        <p className="text-sm text-zinc-500">How we look after DealSnap. Please read these before moderating.</p>
      </div>
      <div className="whitespace-pre-wrap rounded-xl border border-zinc-200 bg-white p-5 text-sm leading-relaxed dark:border-zinc-800 dark:bg-zinc-900">
        {modGuidelines}
      </div>
      {user.role === "admin" && (
        <p className="text-sm text-zinc-500">
          Admins can edit these in{" "}
          <Link href="/admin/team/rules" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
            Team → Rules
          </Link>
          .
        </p>
      )}
    </div>
  );
}
