import Link from "next/link";
import type { Metadata, Viewport } from "next";
import Script from "next/script";
import { cookies } from "next/headers";
import { Geist, Geist_Mono } from "next/font/google";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { ViewModeProvider } from "@/components/ViewModeProvider";
import { parseViewMode, VIEW_COOKIE } from "@/lib/view-mode";
import { ExpiredFilterProvider } from "@/components/ExpiredFilterProvider";
import { UserVotesProvider } from "@/components/UserVotesProvider";
import { getCurrentUser } from "@/lib/auth";
import {
  getVotesByUser,
  getVoteWeight,
  getVoteWeightsByUser,
  getSavedDealSlugs,
  getBlockedIds,
  countUnreadNotifications,
  getSiteSetting,
} from "@/lib/db";
import { isStaffRole } from "@/lib/permissions";
import { NotificationCountProvider } from "@/components/NotificationCount";
import {
  affiliateDisclosureText,
  amazonDisclosureText,
  getSiteSettings,
  needsCookieConsent,
  cookieCategories,
} from "@/lib/site-settings";
import { AffiliateNoteProvider } from "@/components/AffiliateNote";
import { getSiteName, getSiteUrl } from "@/lib/site-url";
import { headIcons } from "@/lib/site-brand";
import SiteScripts from "@/components/SiteScripts";
import ConsentBanner from "@/components/ConsentBanner";
import BannerStrip from "@/components/BannerStrip";
import PromoBanner from "@/components/PromoBanner";
import { getBannerPromo } from "@/lib/promo-site";
import { getAdSettings } from "@/lib/ad-serving";
import { PROMO_CLOSED_COOKIE } from "@/lib/promos";
import { BANNER_CLOSED_COOKIE } from "@/lib/banners";
import { HIDE_LOCAL_COOKIE, SHOW_EXPIRED_COOKIE } from "@/lib/remembered-filters";
import { getSiteBanner } from "@/lib/site-banner";
import { INSTALL_CAPTURE_SCRIPT } from "@/lib/install-prompt";
import { FIT_DECK_SCRIPT } from "@/lib/fit-deck";
import { isInApp } from "@/lib/app-shell";
import AppBridge from "@/components/AppBridge";
import TaxonomyProvider from "@/components/TaxonomyProvider";
import ClientErrorReporter from "@/components/ClientErrorReporter";
import { isStaging } from "@/lib/environment";
import { clientTree } from "@/lib/categories";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

// Only a few places use the code font (codes, two-step keys), so it isn't
// downloaded ahead of every page: it loads when one of them shows.
const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  preload: false,
});

// Title, description, search-engine visibility and Search Console verification
// all come from /admin/settings, so they can change without a code edit.
// Every page's own title gets "| DealSnap" added (the template); the address
// used for share previews comes from lib/site-url.ts.
export async function generateMetadata(): Promise<Metadata> {
  const settings = getSiteSettings();
  const siteName = getSiteName();
  return {
    metadataBase: new URL(await getSiteUrl()),
    title: { default: settings.siteTitle, template: `%s | ${siteName}` },
    description: settings.siteDescription,
    openGraph: {
      siteName,
      type: "website",
      locale: "en_GB",
      title: settings.siteTitle,
      description: settings.siteDescription,
    },
    twitter: { card: "summary_large_image" },
    robots: settings.hideFromSearchEngines || isStaging ? { index: false, follow: false } : undefined,
    verification: settings.searchConsoleToken ? { google: settings.searchConsoleToken } : undefined,
    // When added to an iPhone's Home Screen it opens like an app, named DealSnap.
    appleWebApp: { capable: true, title: siteName, statusBarStyle: "default" },
    // The browser tab and home-screen icon: uploaded in Admin → Settings →
    // General, or the built-in one (lib/site-brand.ts).
    icons: headIcons(),
  };
}

// The phone's top bar matches the header (white, or black in dark mode). In
// the phone apps the page also runs under the status bar, edge to edge, and
// makes room for it itself (globals.css, html[data-app]).
export async function generateViewport(): Promise<Viewport> {
  return {
    themeColor: [
      { media: "(prefers-color-scheme: light)", color: "#ffffff" },
      { media: "(prefers-color-scheme: dark)", color: "#000000" },
    ],
    ...((await isInApp()) ? { viewportFit: "cover" } : {}),
  };
}

export default async function RootLayout({ children }: LayoutProps<"/">) {
  const user = await getCurrentUser();
  const jar = await cookies();
  const viewMode = parseViewMode(jar.get(VIEW_COOKIE)?.value);
  const settings = getSiteSettings();
  const siteBanner = getSiteBanner();
  // Not drawn at all once this visitor has closed this version of it.
  const closedStamp = jar.get(BANNER_CLOSED_COOKIE)?.value ?? "";
  const closedIt = siteBanner && (closedStamp === siteBanner.stamp || closedStamp === encodeURIComponent(siteBanner.stamp));
  const banner = closedIt ? undefined : siteBanner;
  const promoBanner = getBannerPromo(jar.get(PROMO_CLOSED_COOKIE)?.value);
  const inApp = await isInApp();
  // The team can still see the site while maintenance mode is on (visitors get
  // the holding page), so remind them it's on, with the way to turn it off.
  const maintenanceOn = !!user && isStaffRole(user.role) && getSiteSetting("maintenance_mode") === "1";

  return (
    <html lang="en-GB" data-app={inApp ? "" : undefined} className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}>
      <body className="min-h-dvh flex flex-col bg-zinc-50 dark:bg-black">
        {/* Keeps Android's "install this app" offer for the phone menu (lib/install-prompt.ts). */}
        <Script id="install-capture" strategy="beforeInteractive">
          {INSTALL_CAPTURE_SCRIPT}
        </Script>
        <ClientErrorReporter />
        <TaxonomyProvider groups={clientTree()}>
        <AffiliateNoteProvider text={affiliateDisclosureText(settings)}>
          <ViewModeProvider initialMode={viewMode}>
            <ExpiredFilterProvider initial={{ showExpired: jar.get(SHOW_EXPIRED_COOKIE)?.value === "1", hideLocal: jar.get(HIDE_LOCAL_COOKIE)?.value === "1" }}>
              <UserVotesProvider
                key={user?.id ?? "guest"}
                loggedIn={!!user}
                initialVotes={user ? getVotesByUser(user.id) : {}}
                voteWeight={user ? getVoteWeight(user.id) : undefined}
                initialVoteWeights={user ? getVoteWeightsByUser(user.id) : {}}
                initialSaved={user ? getSavedDealSlugs(user.id).map((s) => s.dealSlug) : []}
                blockedUserIds={user ? getBlockedIds(user.id) : []}
              >
                <NotificationCountProvider initial={user ? countUnreadNotifications(user.id) : 0} enabled={!!user}>
                  {isStaging && (
                    <p className="bg-sky-800 px-4 py-1.5 text-center text-xs font-semibold text-white">
                      Test copy of DealSnap: nothing here is real, no emails or notifications are sent, and it can&apos;t change the live site.
                    </p>
                  )}
                  {maintenanceOn && (
                    <p className="bg-amber-700 px-4 py-1.5 text-center text-xs font-semibold text-white">
                      Maintenance mode is on: visitors see the holding page; only the team sees the site.{" "}
                      <Link href="/admin/settings" className="underline underline-offset-2">Turn it off</Link>
                    </p>
                  )}
                  {banner && <BannerStrip {...banner} />}
                  <Header />
                  {promoBanner && <PromoBanner {...promoBanner} />}
                  {children}
                  {/* Cards view: sizes the card to the screen before the first
                      draw, so a refresh doesn't show a guess that then snaps
                      (lib/fit-deck.ts; SwipeDeck keeps it fitted after). */}
                  <script dangerouslySetInnerHTML={{ __html: FIT_DECK_SCRIPT }} />
                  <Footer
                    showCookieSettings={needsCookieConsent(settings)}
                    showAdvertise={getAdSettings().page.on}
                    affiliateDisclosure={affiliateDisclosureText(settings)}
                    amazonDisclosure={amazonDisclosureText(settings)}
                  />
                  <ConsentBanner categories={cookieCategories(settings)} partners={settings.marketingPartners} />
                  {inApp && <AppBridge loggedIn={!!user} />}
                  <SiteScripts
                    gaId={settings.gaId}
                    gtmId={settings.gtmId}
                    headCode={settings.headCode}
                    footerCode={settings.footerCode}
                  />
                </NotificationCountProvider>
              </UserVotesProvider>
            </ExpiredFilterProvider>
          </ViewModeProvider>
        </AffiliateNoteProvider>
        </TaxonomyProvider>
      </body>
    </html>
  );
}
