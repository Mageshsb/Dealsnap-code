import { getSiteBrand, iconAt } from "@/lib/site-brand";
import { ICON_SIZES, type IconSize } from "@/lib/site-brand-shared";

// The site's uploaded browser and home-screen icon (Admin → Settings →
// General) in each size: /site-icon/<version>-<size>.png, kept by browsers
// for a year (the version changes with the icon). /site-icon/<size>.png is
// whichever icon is current (for notifications), checked again daily.
export async function GET(_request: Request, { params }: { params: Promise<{ file: string }> }) {
  const match = (await params).file.match(/^(?:([a-f0-9]{16})-)?([a-z0-9]+)\.png$/);
  const size = match?.[2] as IconSize | undefined;
  if (!match || !size || !ICON_SIZES.includes(size)) return new Response("Not found", { status: 404 });
  const icon = getSiteBrand().icon;
  if (!icon) {
    // None uploaded: the built-in one, for the unversioned address.
    if (!match[1]) return Response.redirect(new URL(size === "maskable" ? "/icons/maskable-512.png" : "/icons/icon-192.png", _request.url), 307);
    return new Response("Not found", { status: 404 });
  }
  const data = await iconAt(size);
  if (!data) return new Response("Not found", { status: 404 });
  return new Response(new Uint8Array(data), {
    headers: {
      "Content-Type": "image/png",
      "Cache-Control": match[1] === icon.v ? "public, max-age=31536000, immutable" : "public, max-age=86400",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
