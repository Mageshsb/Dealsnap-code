import { getSiteSetting } from "@/lib/db";
import { APP_BUNDLE_ID } from "@/lib/app-push";
import { APP_LINK_PATHS } from "@/lib/app-links";

// Tells iPhones that DealSnap links (a deal shared in WhatsApp, an alert
// email) may open in the DealSnap app instead of Safari. Apple reads it when
// the app is installed. The team ID is saved with the Apple key in Admin →
// Settings → Phone apps; until then there's nothing to say.
export function GET() {
  const teamId = getSiteSetting("app_apple_team_id");
  if (!teamId) return new Response("Not set up", { status: 404 });
  return Response.json(
    {
      applinks: {
        details: [{ appIDs: [`${teamId}.${APP_BUNDLE_ID}`], components: APP_LINK_PATHS.map((path) => ({ "/": path })) }],
      },
    },
    { headers: { "cache-control": "public, max-age=3600" } }
  );
}
