import { getSiteSetting } from "@/lib/db";
import { APP_BUNDLE_ID } from "@/lib/app-push";

// The same for Android (see apple-app-site-association): proves the app is
// DealSnap's, by the fingerprint of the key it's signed with, from Google
// Play Console → Test and release → App integrity. Saved in Admin → Settings
// → Phone apps.
export function GET() {
  const fingerprints = (getSiteSetting("app_android_sha256") ?? "").split(/[\s,]+/).filter(Boolean);
  if (!fingerprints.length) return new Response("Not set up", { status: 404 });
  return Response.json(
    [
      {
        relation: ["delegate_permission/common.handle_all_urls"],
        target: { namespace: "android_app", package_name: APP_BUNDLE_ID, sha256_cert_fingerprints: fingerprints },
      },
    ],
    { headers: { "cache-control": "public, max-age=3600" } }
  );
}
