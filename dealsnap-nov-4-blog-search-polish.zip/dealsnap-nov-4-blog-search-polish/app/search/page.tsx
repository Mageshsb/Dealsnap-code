import { redirect } from "next/navigation";
import { capSearch } from "@/lib/search-limits";

// Search lives on the homepage's list (/?q=…). People (and some apps and
// browsers) still try /search?q=…, so that goes to the same results rather
// than "page not found".
export const metadata = { robots: { index: false, follow: true } };

export default async function SearchRedirect({ searchParams }: { searchParams: Promise<{ q?: string | string[] }> }) {
  const { q } = await searchParams;
  const query = capSearch(Array.isArray(q) ? q[0] : q);
  redirect(query ? `/?q=${encodeURIComponent(query)}` : "/");
}
