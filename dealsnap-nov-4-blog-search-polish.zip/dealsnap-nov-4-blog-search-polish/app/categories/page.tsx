import { getCategoryGroups, categoryTheme } from "@/lib/categories";
import { getCategorySummary, getNewThisWeekCounts } from "@/lib/mock-deals";
import { getCategoryAlerts, getTagAlerts } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import Icon from "@/components/Icon";
import BrowseTop from "@/components/BrowseTop";
import YourFollows, { type FollowedItem } from "@/components/YourFollows";
import { slugify } from "@/lib/slug";
import CategoryDirectory, { type DirectoryCategory } from "@/components/CategoryDirectory";

export const metadata = {
  title: "Browse categories and tags",
  alternates: { canonical: "/categories" },
  description: "Browse every deal category and tag on DealSnap.",
};

export default async function CategoriesPage({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  // Drawn per visit, so the live-deal counts are current.
  await searchParams;
  const categories: DirectoryCategory[] = getCategoryGroups().map((g) => {
    const theme = categoryTheme(g.name);
    const summary = getCategorySummary(g.name);
    return {
      name: g.name,
      slug: slugify(g.name),
      icon: g.icon,
      tile: theme.tile,
      iconColour: theme.icon,
      count: summary.dealCount,
      // Every tag, each one's sub-tags straight after it (iPhone after Mobile Phone).
      tags: g.tags
        .flatMap((t) => [t, ...(t.subtags ?? [])])
        .map((t) => ({ name: t.name, slug: slugify(t.name), icon: t.icon, count: summary.tags[t.name.toLowerCase()] ?? 0 })),
    };
  });
  // The categories and tags this person has the bell on for, those with
  // something new first (capped, so a long list can't make the page heavy).
  const user = await getCurrentUser();
  let yours: FollowedItem[] = [];
  if (user) {
    const followedCategories = new Set(getCategoryAlerts(user.id));
    const followedTags = new Set(getTagAlerts(user.id).map((a) => a.tagSlug));
    if (followedCategories.size || followedTags.size) {
      const fresh = getNewThisWeekCounts();
      const tile = (c: DirectoryCategory, round: boolean, icon: DirectoryCategory["icon"]) => (
        <span className={`flex h-9 w-9 shrink-0 items-center justify-center ${round ? "rounded-full" : "rounded-lg"} ${c.tile}`}>
          <Icon name={icon} className={`size-5 ${c.iconColour}`} />
        </span>
      );
      for (const c of categories) {
        if (followedCategories.has(c.slug))
          yours.push({ key: `c:${c.slug}`, name: c.name, href: `/categories/${c.slug}`, leading: tile(c, false, c.icon), liveCount: c.count, newCount: fresh.categories[c.slug] ?? 0 });
        for (const t of c.tags)
          if (followedTags.has(t.slug))
            yours.push({ key: `t:${t.slug}`, name: t.name, href: `/tags/${t.slug}`, leading: tile(c, true, t.icon), liveCount: t.count, newCount: fresh.tags[t.slug] ?? 0 });
      }
      yours = yours.sort((a, b) => b.newCount - a.newCount || b.liveCount - a.liveCount || a.name.localeCompare(b.name)).slice(0, 12);
    }
  }
  const tagCount = categories.reduce((n, c) => n + c.tags.length, 0);

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-5 px-4 py-6">
      <BrowseTop show="categories">
        {categories.length} categories · {tagCount} tags
      </BrowseTop>
      <YourFollows id="your-categories" title="Your categories & tags" manageHref="/alerts#categories" items={yours} />
      {/* Reads its search from the address, so Back from a tag keeps it. */}
      <CategoryDirectory categories={categories} />
    </main>
  );
}
