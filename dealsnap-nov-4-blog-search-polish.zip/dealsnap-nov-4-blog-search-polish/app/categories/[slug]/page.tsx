import type { Metadata } from "next";
import { notFound, permanentRedirect } from "next/navigation";
import CategorySwitcher from "@/components/CategorySwitcher";
import TagPills from "@/components/TagPills";
import SidebarBoxes from "@/components/SidebarBoxes";
import BrowseExperience from "@/components/BrowseExperience";
import SwipeHeader from "@/components/SwipeHeader";
import SortAndFilters from "@/components/SortAndFilters";
import { getCategoryBySlug, movedCategory } from "@/lib/categories";
import { slugify } from "@/lib/slug";
import { parseView, parseLovedWindow, lovedDivider, DEFAULT_VIEW, DEFAULT_LOVED_WINDOW } from "@/lib/deal-views";
import { parseMinHearts, parseSlug, parseDealType, narrowDeals, narrowQuery, typeFacet, type Facet } from "@/lib/deal-filters";
import { getBarTags, getBrandFacet, getDealsForView, getStoreFacet } from "@/lib/mock-deals";
import { PAGE_SIZE } from "@/lib/pagination";
import InfoToggle from "@/components/InfoToggle";
import InfoSheetButton from "@/components/InfoSheetButton";
import { TopicPanel } from "@/components/InfoPanels";
import { panelDiscussions } from "@/lib/community-panel";
import { topicInfo } from "@/lib/topic-info";
import AlertButton from "@/components/AlertButton";
import { getCurrentUser } from "@/lib/auth";
import { hasCategoryAlert } from "@/lib/db";
import EmptyState from "@/components/EmptyState";
import JsonLd from "@/components/JsonLd";
import { breadcrumbStructuredData } from "@/lib/structured-data";
import { getSiteUrl } from "@/lib/site-url";
import { getListPromos } from "@/lib/promo-site";
import { getListAds } from "@/lib/ad-serving";


export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const category = getCategoryBySlug(slug);
  if (!category) return {};
  return {
    title: `${category.name} deals`,
    description: `The best ${category.name.toLowerCase()} deals and discount codes in the UK, found and rated by the DealSnap community.`,
    alternates: { canonical: `/categories/${slug}` },
  };
}

export default async function CategoryPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ view?: string; hearts?: string; when?: string; store?: string; brand?: string; type?: string }>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const view = parseView(sp.view);
  const when = parseLovedWindow(sp.when);
  const minHearts = parseMinHearts(sp.hearts);
  const store = parseSlug(sp.store);
  const brand = parseSlug(sp.brand);
  const type = parseDealType(sp.type);
  const category = getCategoryBySlug(slug);

  if (!category) {
    // A category that was renamed or merged: its old address goes to where it is now.
    const moved = movedCategory(slug);
    if (moved) permanentRedirect(`/categories/${slugify(moved.name)}`);
    notFound();
  }

  const basePath = `/categories/${slug}`;
  const facet: Facet = { param: "store", options: getStoreFacet({ category: category.name }, minHearts, store) };
  const brandFacet: Facet = { param: "brand", options: getBrandFacet({ category: category.name }, minHearts, brand) };
  const filterQuery = narrowQuery(store, "", type, brand);
  const listed = narrowDeals(getDealsForView(view, category.name, undefined, undefined, minHearts, when), store, "", "", brand);
  const facets = [facet, ...(brandFacet.options.length ? [brandFacet] : []), typeFacet(listed)];
  const deals = narrowDeals(listed, "", "", type);
  const firstPage = deals.slice(0, PAGE_SIZE);
  const hasMore = deals.length > firstPage.length;
  const user = await getCurrentUser();
  const alertOn = user ? hasCategoryAlert(user.id, slug) : false;

  const info = topicInfo({ category: category.name });

  // The ⓘ panel: under the title in the List view, a bottom sheet in Scroll.
  const infoLabel = `About ${category.name} deals`;
  const infoPanel = <TopicPanel name={category.name} {...info} discussions={panelDiscussions("category", slug, category.name)} />;
  // Most loved/New and the Filters pill above the card in the Scroll view
  // (stepped down a size on short screens, so the card keeps its room).
  const controls = <SortAndFilters active={view} when={when} minHearts={minHearts} filterQuery={filterQuery} facets={facets} basePath={basePath} />;
  // The List view's own row under the title, which also comes back under
  // the category strip when scrolling up from halfway down the list.
  const listRow = <SortAndFilters active={view} when={when} basePath={basePath} minHearts={minHearts} filterQuery={filterQuery} facets={facets} inList />;
  return (
    <>
    <BrowseExperience
      promos={await getListPromos({ kind: "category", slug: slug })}
      ads={await getListAds({ kind: "category", slug: slug })}
      controls={listRow}
      resetKey={`${slug}|${view}|${when}|${minHearts}|${filterQuery}`}
      minHearts={minHearts || undefined}
      filterQuery={filterQuery || undefined}
      view={view === DEFAULT_VIEW ? undefined : view}
      when={view === "hottest" && when !== DEFAULT_LOVED_WINDOW ? when : undefined}
      divider={lovedDivider(view, when)}
      initialDeals={firstPage}
      initialHasMore={hasMore}
      isEmpty={deals.length === 0}
      category={category.name}
      heading={
        <div key="heading">
          <InfoToggle label={infoLabel} panel={infoPanel}>
            <h1 className="flex min-w-0 items-center gap-2 text-xl font-bold sm:text-2xl">
              <span className="min-w-0 truncate sm:overflow-visible sm:whitespace-normal">{category.name}</span>
            </h1>
            <AlertButton kind="category" target={slug} name={category.name} nextPath={basePath} initialOn={alertOn} />
          </InfoToggle>
          <div className="mt-3">
            {listRow}
          </div>
        </div>
      }
      listFilterBar={
        <TagPills
          key="list-filter-bar"
          tags={getBarTags({ category: category.name })}
          leading={<CategorySwitcher activeSlug={slug} />}
          divided
        />
      }
      swipeLabel={
        <SwipeHeader
          key="swipe-label"
          controls={controls}
          title={
            <>
              <span className="min-w-0 truncate sm:overflow-visible sm:whitespace-normal">{category.name}</span>
              <AlertButton kind="category" target={slug} name={category.name} nextPath={basePath} initialOn={alertOn} className="px-2.5 py-1 text-xs font-semibold" />
              <InfoSheetButton label={infoLabel} panel={infoPanel} className="px-2.5 py-1 text-xs font-semibold" />
            </>
          }
        />
      }
      sidebar={<SidebarBoxes key="sidebar" facets={facets} />}
      emptyState={
        <EmptyState key="empty-state" icon="search">
          <p>No deals in this category yet.</p>
        </EmptyState>
      }
    />
    <JsonLd data={breadcrumbStructuredData([{ name: "Home", href: "/" }, { name: "Categories", href: "/categories" }, { name: category.name, href: basePath }], await getSiteUrl())} />
    </>
  );
}
