import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getTagAlerts, getKeywordAlerts, getStoreAlerts, getCategoryAlerts, getBrandAlerts, getAlertMinHearts } from "@/lib/db";
import { allTags as everyTag, getCategoryGroups } from "@/lib/categories";
import { getVisibleBrands } from "@/lib/brands";
import { slugify } from "@/lib/slug";
import { getDealsForView, getHotTopics, getStores } from "@/lib/mock-deals";
import { keywordMatchInfo } from "@/lib/keyword-matches";
import AccountShell, { AccountPageHeader } from "@/components/AccountShell";
import AlertsPanel from "@/components/AlertsPanel";
import { msAgo } from "@/lib/moderation";
import PushToggle from "@/components/PushToggle";
import { pushPublicKey } from "@/lib/push";

export const metadata = { title: "Alerts" };

export default async function AlertsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/alerts");

  const weekAgo = msAgo(7 * 24 * 60 * 60 * 1000);
  const alertSlugs = getTagAlerts(user.id).map((a) => a.tagSlug);
  const allTags = everyTag().map((t) => ({
    slug: slugify(t.tag.name),
    name: t.tag.name,
    icon: t.tag.icon,
    category: t.category.name,
    parent: t.parent?.name,
  }));
  const allBrands = getVisibleBrands().map((b) => ({ slug: b.slug, name: b.name, logoUrl: b.logoUrl }));
  const brandSlugs = getBrandAlerts(user.id);
  const brandNewThisWeek: Record<string, number> = {};
  for (const slug of brandSlugs) {
    brandNewThisWeek[slug] = getDealsForView("new", undefined, undefined, undefined, 0, undefined, slug).filter(
      (d) => new Date(d.postedAt).getTime() >= weekAgo
    ).length;
  }
  const allStores = [...getStores()]
    .sort((a, b) => b.dealCount - a.dealCount)
    .map((s) => ({ key: s.key, name: s.name, slug: s.slug, dealCount: s.dealCount, logoUrl: s.logoUrl }));
  const storeKeys = getStoreAlerts(user.id);
  const allCategories = getCategoryGroups().map((c) => ({ slug: slugify(c.name), name: c.name, icon: c.icon }));
  const categorySlugs = getCategoryAlerts(user.id);
  const categoryNewThisWeek: Record<string, number> = {};
  for (const slug of categorySlugs) {
    const c = allCategories.find((x) => x.slug === slug);
    if (!c) continue;
    categoryNewThisWeek[slug] = getDealsForView("new", c.name).filter(
      (d) => new Date(d.postedAt).getTime() >= weekAgo
    ).length;
  }
  const keywordAlerts = getKeywordAlerts(user.id).map((k) => ({ id: k.id, keyword: k.keyword, maxPrice: k.maxPrice }));

  const storeNewThisWeek: Record<string, number> = {};
  for (const key of storeKeys) {
    const s = allStores.find((x) => x.key === key);
    if (!s) continue;
    storeNewThisWeek[key] = getDealsForView("new", undefined, undefined, s.slug).filter(
      (d) => new Date(d.postedAt).getTime() >= weekAgo
    ).length;
  }
  const keywordInfo: Record<string, Awaited<ReturnType<typeof keywordMatchInfo>>> = {};
  for (const k of keywordAlerts) keywordInfo[k.id] = keywordMatchInfo(k.keyword, k.maxPrice);
  const newThisWeek: Record<string, number> = {};
  for (const slug of alertSlugs) {
    const tag = allTags.find((t) => t.slug === slug);
    if (!tag) continue;
    newThisWeek[slug] = getDealsForView("new", undefined, tag.name).filter(
      (d) => new Date(d.postedAt).getTime() >= weekAgo
    ).length;
  }

  const alertCount = alertSlugs.length + brandSlugs.length + storeKeys.length + categorySlugs.length + keywordAlerts.length;
  // Quick adds for an empty Alerts page: the topics and stores with the most
  // going on right now, a mix of both.
  const hot = getHotTopics({}, { tags: 3, stores: 2, brands: 0 });
  const quickStores = hot.stores.flatMap((h) => {
    const s = allStores.find((x) => x.slug === h.slug);
    return s ? [{ kind: "store" as const, id: s.key, label: s.name, icon: "store" as const }] : [];
  });
  const quickTags = hot.tags.map((t) => ({ kind: "tag" as const, id: t.slug, label: t.name, icon: t.icon }));
  const suggestions = [quickTags[0], quickStores[0], quickTags[1], quickStores[1], quickTags[2]].filter((x) => !!x);

  return (
    <AccountShell user={user} active="/alerts">
      <AccountPageHeader title="Alerts" description="Only you can see these. Get told when new deals match what you're after." />
      <AlertsPanel
        allTags={allTags}
        initialSlugs={alertSlugs}
        newThisWeek={newThisWeek}
        initialKeywords={keywordAlerts}
        keywordInfo={keywordInfo}
        allStores={allStores}
        initialStoreKeys={storeKeys}
        storeNewThisWeek={storeNewThisWeek}
        allCategories={allCategories}
        initialCategorySlugs={categorySlugs}
        categoryNewThisWeek={categoryNewThisWeek}
        allBrands={allBrands}
        initialBrandSlugs={brandSlugs}
        brandNewThisWeek={brandNewThisWeek}
        minHearts={getAlertMinHearts(user.id)}
        suggestions={suggestions}
      />
      {/* Alerts are what phone notifications are best for: once you have one,
          a one-line offer to turn them on (the full switch is in Settings). */}
      {alertCount > 0 && <PushToggle publicKey={pushPublicKey()} nudge />}
    </AccountShell>
  );
}
