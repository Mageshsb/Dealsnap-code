import { getBlogCover } from "@/lib/db";

// Serves an uploaded blog cover from the database. The second part of the
// address changes whenever the post is saved, so it can be cached for a year.
export async function GET(_request: Request, { params }: { params: Promise<{ id: string; v: string }> }) {
  const { id } = await params;
  const cover = /^[0-9a-f-]{36}$/.test(id) ? getBlogCover(id) : undefined;
  if (!cover) return new Response("Not found", { status: 404 });
  return new Response(Buffer.from(cover.data), {
    headers: { "Content-Type": cover.type, "Cache-Control": "public, max-age=31536000, immutable" },
  });
}
