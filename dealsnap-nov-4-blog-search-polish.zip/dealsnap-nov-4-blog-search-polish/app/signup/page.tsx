import Link from "next/link";
import { signupAction } from "@/lib/actions";
import GoogleButton from "@/components/GoogleButton";
import BotCheck from "@/components/BotCheck";
import { newFormCheck, turnstileSiteKey } from "@/lib/captcha";
import { MIN_AGE } from "@/lib/legal";
import { USERNAME_MAX, USERNAME_MIN, USERNAME_PATTERN, USERNAME_RULE } from "@/lib/username";

export const metadata = { title: "Join free" };

export default async function SignupPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; next?: string }>;
}) {
  const { error, next } = await searchParams;

  return (
    <main className="mx-auto flex w-full max-w-sm flex-1 flex-col gap-6 px-4 py-6">
      <div className="text-center">
        <h1 className="text-xl font-bold sm:text-2xl">Join free</h1>
        <p className="text-sm text-zinc-500">Post deals, leave comments, and earn badges.</p>
      </div>

      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </p>
      )}

      <GoogleButton next={next} />

      <form action={signupAction} className="flex flex-col gap-4">
        {next && <input type="hidden" name="next" value={next} />}
        <div className="flex flex-col gap-1">
          <label htmlFor="signup-username" className="text-sm font-medium">Username</label>
          <input
            id="signup-username"
            name="username"
            required
            minLength={USERNAME_MIN}
            maxLength={USERNAME_MAX}
            pattern={USERNAME_PATTERN}
            title={USERNAME_RULE}
            autoComplete="username"
            placeholder="dealhunter99"
            className="rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-900"
          />
          <p className="text-xs text-zinc-500 dark:text-zinc-400">Up to {USERNAME_MAX} characters: letters, numbers, _ and -</p>
        </div>
        <div className="flex flex-col gap-1">
          <label htmlFor="signup-email" className="text-sm font-medium">Email</label>
          <input
            id="signup-email"
            name="email"
            type="email"
            required
            autoComplete="email"
            placeholder="you@example.com"
            className="rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-900"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label htmlFor="signup-password" className="text-sm font-medium">Password</label>
          <input
            id="signup-password"
            name="password"
            type="password"
            required
            autoComplete="new-password"
            minLength={8}
            placeholder="At least 8 characters"
            className="rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-900"
          />
        </div>
        <label className="flex items-start gap-2 text-sm">
          <input
            type="checkbox"
            name="age"
            required
            className="mt-0.5 size-4 shrink-0 accent-orange-500"
          />
          <span>I&apos;m {MIN_AGE} or over</span>
        </label>
        {/* No sum to solve here: the confirmation email does that job. */}
        <BotCheck idPrefix="signup" check={newFormCheck(false)} siteKey={turnstileSiteKey()} />
        <button
          type="submit"
          className="mt-2 rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600"
        >
          Join free
        </button>
      </form>

      <p className="text-center text-xs leading-relaxed text-zinc-500 dark:text-zinc-400">
        By joining, you agree to our{" "}
        <Link href="/terms" className="underline underline-offset-2 hover:text-orange-500">Terms</Link> and confirm you’re{" "}
        {MIN_AGE} or over. See how we use your data in our{" "}
        <Link href="/privacy" className="underline underline-offset-2 hover:text-orange-500">Privacy policy</Link>.
      </p>

      <p className="text-center text-sm text-zinc-500">
        Already have an account?{" "}
        <Link href={next ? `/login?next=${encodeURIComponent(next)}` : "/login"} className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
          Log in
        </Link>
      </p>
    </main>
  );
}
