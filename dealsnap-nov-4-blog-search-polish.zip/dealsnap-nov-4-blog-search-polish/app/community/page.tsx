import type { Metadata } from "next";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { getBlockedIds } from "@/lib/db";
import { getPageAds } from "@/lib/ad-serving";
import { RAIL_SLOTS } from "@/lib/ads";
import { countUnreadFollowed, getCommunitySettings, getFollowedSpaceIds, getSpaceStats, getUnreadPositions, listSpaces, listThreads } from "@/lib/community-db";
import { SEARCH_MAX, THREADS_PER_PAGE, isThreadSort, pagesFor, searchWords, threadSorts } from "@/lib/community-rules";
import { overLimit } from "@/lib/rate-limit";
import { timeAgo } from "@/lib/format";
import { AdsProvider } from "@/components/AdUnit";
import AdRails from "@/components/AdRails";
import EmptyState from "@/components/EmptyState";
import Icon from "@/components/Icon";
import SortSelect from "@/components/SortSelect";
import CommunitySearch from "@/components/community/CommunitySearch";
import Pager from "@/components/community/Pager";
import ThreadList from "@/components/community/ThreadList";
import { startButton } from "@/components/community/styles";

const DESCRIPTION = "Ask, share and chat with other deal hunters: questions, tips, and talk about stores and brands.";

// A page of search results is for the person who searched, not for search engines.
export async function generateMetadata({ searchParams }: { searchParams: Promise<{ q?: string; view?: string }> }): Promise<Metadata> {
  const { q, view } = await searchParams;
  return { title: "Community", description: DESCRIPTION, alternates: { canonical: "/community" }, ...(q || view ? { robots: { index: false, follow: true } } : {}) };
}

// The two tiles above the list ("All" and "Following"), in the same orange as the other "which ones" tabs.
const tab = (on: boolean) =>
  `inline-flex min-h-9 items-center gap-1.5 whitespace-nowrap rounded-xl px-3 text-sm font-medium ${
    on ? "bg-orange-500 text-white" : "bg-orange-50 text-orange-800 hover:bg-orange-100 dark:bg-orange-950/30 dark:text-orange-300 dark:hover:bg-orange-950/50"
  }`;

// How many spaces sit across on a laptop, so the last row is never one lonely box.
const columns = (n: number) => (n <= 2 ? "lg:grid-cols-2" : n === 3 || n === 5 || n === 6 ? "lg:grid-cols-3" : "lg:grid-cols-4");

export default async function CommunityHome({ searchParams }: { searchParams: Promise<{ sort?: string; page?: string; q?: string; view?: string }> }) {
  const sp = await searchParams;
  if (!getCommunitySettings().on) {
    return (
      <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-5 px-4 py-6">
        <h1 className="text-xl font-bold sm:text-2xl">Community</h1>
        <EmptyState icon="replies">The Community is closed for the moment. Please check back soon.</EmptyState>
      </main>
    );
  }
  const user = await getCurrentUser();
  const sort = isThreadSort(sp.sort) ? sp.sort : "active";
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);
  // "Following" is a member's own list: the threads they started, replied in or followed.
  const view = user && sp.view === "following" ? "following" : "all";
  const newInFollowing = user ? countUnreadFollowed(user.id) : 0;
  const spaces = listSpaces();
  const stats = getSpaceStats();
  const followed = user ? getFollowedSpaceIds(user.id) : new Set<string>();
  const q = (sp.q ?? "").trim().slice(0, SEARCH_MAX);
  const searching = q.length > 0;
  const tooMany = searching && (await overLimit("community-search", 40));
  // A search with no usable word in it ("a", "?") finds nothing rather than everything.
  const searchable = !searching || (searchWords(q).length > 0 && !tooMany);
  const { rows, total } = searchable
    ? listThreads({ sort, page, search: q || undefined, followedBy: view === "following" ? user?.id : undefined, exclude: user ? getBlockedIds(user.id) : undefined })
    : { rows: [], total: 0 };
  const totalPages = pagesFor(total, THREADS_PER_PAGE);
  const unread = user ? getUnreadPositions(user.id, rows.map((r) => r.id)) : new Map<string, number>();
  // A tab keeps the sort; the search and page start again.
  const tabHref = (over: { view?: string }) => {
    const qs = new URLSearchParams(Object.entries({ sort: sort === "active" ? undefined : sort, ...over }).filter((e): e is [string, string] => !!e[1])).toString();
    return `/community${qs ? `?${qs}` : ""}`;
  };
  const ads = await getPageAds({ kind: "community", path: "/community", labels: {} }, ["community-list", ...RAIL_SLOTS]);

  return (
    <AdsProvider ads={ads}>
      <main className="relative mx-auto flex w-full max-w-5xl flex-1 flex-col gap-6 px-4 py-6">
        <AdRails />
        <header className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="text-xl font-bold sm:text-2xl">Community</h1>
            <p className="mt-1 text-sm text-zinc-500">Ask, share and chat with other deal hunters.</p>
          </div>
          <Link href={user ? "/community/new" : "/login?next=/community/new"} className={startButton}>
            <Icon name="plus" className="size-4" />
            Start a discussion
          </Link>
        </header>

        <section aria-labelledby="spaces" className="flex flex-col gap-3">
          <div>
            <h2 id="spaces" className="text-lg font-bold">
              Spaces
            </h2>
            <p className="text-sm text-zinc-500">Each space is for a different kind of conversation. Open one to see its threads.</p>
          </div>
          {/* One column on phones (so each space's purpose can be read), two on tablets, and across on laptops. */}
          <div className={`grid grid-cols-1 gap-2.5 sm:grid-cols-2 sm:gap-3 ${columns(spaces.length)}`}>
            {spaces.map((s) => {
              const st = stats.get(s.id);
              return (
                <Link
                  key={s.id}
                  href={`/community/${s.slug}`}
                  className="group grid min-w-0 items-center gap-x-3 gap-y-0.5 rounded-xl border border-zinc-200 bg-white p-3 transition-colors [grid-template-areas:'icon_name_chev'_'icon_blurb_chev'_'icon_meta_chev'] [grid-template-columns:auto_1fr_auto] hover:border-orange-300 sm:gap-y-1.5 sm:p-4 sm:[grid-template-areas:'icon_name_chev'_'blurb_blurb_blurb'_'meta_meta_meta'] sm:last:odd:col-span-2 lg:last:odd:col-span-1 dark:border-zinc-800 dark:bg-zinc-900 dark:hover:border-orange-700"
                >
                  <span className="flex size-10 shrink-0 items-center justify-center self-center rounded-xl bg-orange-100 text-orange-700 [grid-area:icon] dark:bg-orange-950/40 dark:text-orange-400">
                    <Icon name={s.icon} className="size-5" />
                  </span>
                  <span className="flex min-w-0 items-center gap-1.5 [grid-area:name]">
                    <span className="min-w-0 [overflow-wrap:anywhere] font-semibold leading-snug">{s.name}</span>
                    {followed.has(s.id) && <Icon name="bell-ring" className="size-3.5 shrink-0 text-orange-700 dark:text-orange-400" />}
                  </span>
                  {s.blurb && <span className="line-clamp-2 min-w-0 text-sm leading-snug text-zinc-500 [grid-area:blurb] sm:line-clamp-3">{s.blurb}</span>}
                  <span className="mt-0.5 min-w-0 text-xs text-zinc-500 dark:text-zinc-400 [grid-area:meta]">
                    {st ? (
                      <>
                        {st.threads.toLocaleString("en-GB")} {st.threads === 1 ? "thread" : "threads"} · active {timeAgo(st.lastAt!)}
                      </>
                    ) : (
                      "No threads yet"
                    )}
                  </span>
                  <Icon name="chevron-right" className="size-5 shrink-0 self-center text-zinc-300 transition-colors [grid-area:chev] group-hover:text-orange-500 dark:text-zinc-600" />
                </Link>
              );
            })}
          </div>
        </section>

        <section aria-labelledby="latest" className="flex flex-col gap-3">
          <div className="flex min-h-9 flex-wrap items-center justify-between gap-x-3 gap-y-2">
            {user ? (
              <>
                <h2 id="latest" className="sr-only">
                  Conversations
                </h2>
                <nav aria-label="Which conversations" className="flex gap-1.5">
                  <Link href={tabHref({ view: undefined })} aria-current={view === "all" ? "page" : undefined} className={tab(view === "all")}>
                    All
                  </Link>
                  <Link href={tabHref({ view: "following" })} aria-current={view === "following" ? "page" : undefined} className={tab(view === "following")}>
                    Following
                    {newInFollowing > 0 && (
                      <span className={`rounded-full px-1.5 text-xs font-semibold tabular-nums ${view === "following" ? "bg-white/25 text-white" : "bg-orange-500 text-white"}`}>
                        {newInFollowing}
                        <span className="sr-only"> with new replies</span>
                      </span>
                    )}
                  </Link>
                </nav>
              </>
            ) : (
              <h2 id="latest" className="text-lg font-bold">
                {searching ? "Results" : "All conversations"}
              </h2>
            )}
            <SortSelect current={sort} options={threadSorts("all")} label="Sort conversations" keep={{ q: q || undefined, view: view === "following" ? view : undefined }} />
          </div>
          <CommunitySearch action="/community" q={q} sort={sort} view={view === "following" ? view : undefined} placeholder={view === "following" ? "Search the conversations you follow" : "Search all conversations"} />
          {searching && !tooMany && (
            <p className="-mt-1 text-sm text-zinc-500">
              {total.toLocaleString("en-GB")} {total === 1 ? "result" : "results"} for &ldquo;{q}&rdquo;
            </p>
          )}
          {rows.length === 0 ? (
            <EmptyState icon={searching ? "search" : view === "following" ? "bell" : "comment"}>
              {tooMany
                ? "That's a lot of searches. Please wait a minute and try again."
                : searching
                  ? `Nothing matches “${q}”. Try fewer or different words${view === "following" ? ", or look in All" : ", or start the conversation yourself"}.`
                  : view === "following"
                    ? "You're not following any conversations yet. Reply to one, or tap Follow on it, and it will be listed here with any new replies."
                    : sort === "unanswered"
                      ? "Every conversation has a reply. Nicely done."
                      : "No conversations yet. Be the first to start one."}
            </EmptyState>
          ) : (
            <ThreadList rows={rows} unread={unread} ad={ads?.slots["community-list"]} />
          )}
          <Pager basePath="/community" page={page} totalPages={totalPages} keep={{ sort: sort === "active" ? undefined : sort, q: q || undefined, view: view === "following" ? view : undefined }} />
        </section>
      </main>
    </AdsProvider>
  );
}
