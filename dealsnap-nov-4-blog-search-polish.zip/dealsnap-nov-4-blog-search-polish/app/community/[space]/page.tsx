import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getBlockedIds } from "@/lib/db";
import { getPageAds } from "@/lib/ad-serving";
import { RAIL_SLOTS } from "@/lib/ads";
import { followsSpace, getCommunitySettings, getSpaceBySlug, getUnreadPositions, listSpaces, listThreads } from "@/lib/community-db";
import { DEFAULT_SPACE_RULES, SEARCH_MAX, THREADS_PER_PAGE, isThreadSort, pagesFor, searchWords, threadSorts } from "@/lib/community-rules";
import { overLimit } from "@/lib/rate-limit";
import { isStaffRole } from "@/lib/permissions";
import { AdsProvider } from "@/components/AdUnit";
import AdRails from "@/components/AdRails";
import BackLink from "@/components/BackLink";
import EmptyState from "@/components/EmptyState";
import Icon from "@/components/Icon";
import SortSelect from "@/components/SortSelect";
import CommunitySearch from "@/components/community/CommunitySearch";
import Pager from "@/components/community/Pager";
import SpaceFollow from "@/components/community/SpaceFollow";
import SpaceTabs from "@/components/community/SpaceTabs";
import ThreadList from "@/components/community/ThreadList";
import { startButton } from "@/components/community/styles";

export async function generateMetadata({ params, searchParams }: { params: Promise<{ space: string }>; searchParams: Promise<{ q?: string }> }): Promise<Metadata> {
  const [{ space: slug }, { q }] = await Promise.all([params, searchParams]);
  const space = getSpaceBySlug(slug);
  if (!space || space.archived) return { title: "Space not found", robots: { index: false } };
  return {
    title: `${space.name} | Community`,
    description: space.blurb || `Conversations about ${space.name.toLowerCase()} on DealSnap.`,
    alternates: { canonical: `/community/${space.slug}` },
    // A page of search results is for the person who searched, not for search engines.
    ...(q ? { robots: { index: false, follow: true } } : {}),
  };
}

export default async function SpacePage({
  params,
  searchParams,
}: {
  params: Promise<{ space: string }>;
  searchParams: Promise<{ sort?: string; page?: string; q?: string }>;
}) {
  const [{ space: slug }, sp] = await Promise.all([params, searchParams]);
  const space = getSpaceBySlug(slug);
  if (!space || space.archived || !getCommunitySettings().on) notFound();
  const user = await getCurrentUser();
  const sort = isThreadSort(sp.sort) ? sp.sort : "active";
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);
  const q = (sp.q ?? "").trim().slice(0, SEARCH_MAX);
  const searching = q.length > 0;
  const tooMany = searching && (await overLimit("community-search", 40));
  const searchable = !searching || (searchWords(q).length > 0 && !tooMany);
  const { rows, total } = searchable
    ? listThreads({ spaceId: space.id, sort, page, pinnedFirst: sort === "active" && !searching, search: q || undefined, exclude: user ? getBlockedIds(user.id) : undefined })
    : { rows: [], total: 0 };
  const totalPages = pagesFor(total, THREADS_PER_PAGE);
  const unread = user ? getUnreadPositions(user.id, rows.map((r) => r.id)) : new Map<string, number>();
  const canStart = space.who === "members" || (!!user && isStaffRole(user.role));
  const ads = await getPageAds({ kind: "community", path: `/community/${space.slug}`, labels: {} }, ["community-list", ...RAIL_SLOTS]);

  return (
    <AdsProvider ads={ads}>
      <main className="relative mx-auto flex w-full max-w-5xl flex-1 flex-col gap-5 px-4 py-6">
        <AdRails />
        <BackLink href="/community" exact className="sm:hidden">
          Community
        </BackLink>
        <SpaceTabs spaces={listSpaces()} current={space.slug} />
        <header className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex min-w-0 items-start gap-3">
            <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400">
              <Icon name={space.icon} className="size-6" />
            </span>
            <div className="min-w-0">
              <h1 className="text-xl font-bold sm:text-2xl">{space.name}</h1>
              <p className="mt-1 text-sm text-zinc-500">{space.blurb || `Conversations about ${space.name.toLowerCase()}.`}</p>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            {user && <SpaceFollow spaceId={space.id} following={followsSpace(user.id, space.id)} />}
            {canStart && (
              <Link href={user ? `/community/new?space=${space.slug}` : `/login?next=${encodeURIComponent(`/community/new?space=${space.slug}`)}`} className={startButton}>
                <Icon name="plus" className="size-4" />
                Start a discussion
              </Link>
            )}
          </div>
        </header>

        {/* The same box on every space (with a default text when none is written), so moving between spaces never shifts the page. */}
        <details className="group rounded-xl border border-zinc-200 bg-white px-4 py-3 text-sm dark:border-zinc-800 dark:bg-zinc-900">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-2 font-medium">
            <span className="flex items-center gap-2">
              <Icon name="info" className="size-4 text-zinc-500 dark:text-zinc-400" />
              Rules for this space
            </span>
            <Icon name="chevron-down" className="size-4 text-zinc-500 dark:text-zinc-400 transition-transform group-open:rotate-180" />
          </summary>
          <p className="mt-2 whitespace-pre-line leading-relaxed text-zinc-600 dark:text-zinc-400">{space.rules || DEFAULT_SPACE_RULES}</p>
        </details>

        <div className="flex min-h-9 items-center justify-between gap-3">
          <h2 className="text-lg font-bold">
            {total.toLocaleString("en-GB")} {searching ? (total === 1 ? "result" : "results") : total === 1 ? "thread" : "threads"}
          </h2>
          {(total > 1 || sort !== "active") && <SortSelect current={sort} options={threadSorts(space.kind)} label="Sort threads" keep={{ q: q || undefined }} />}
        </div>
        <CommunitySearch action={`/community/${space.slug}`} q={q} sort={sort} placeholder={`Search ${space.name}`} />
        {rows.length === 0 ? (
          <EmptyState icon={searching ? "search" : "comment"}>
            {tooMany
              ? "That's a lot of searches. Please wait a minute and try again."
              : searching
                ? `Nothing in ${space.name} matches “${q}”. Try fewer or different words.`
                : sort === "unanswered"
                  ? space.kind === "ask"
                    ? "Every question here has a best answer. Nicely done."
                    : "Every thread here has a reply. Nicely done."
                  : canStart
                    ? "Nothing here yet. Start the first conversation."
                    : "Nothing here yet."}
          </EmptyState>
        ) : (
          <ThreadList rows={rows} unread={unread} showSpace={false} ad={ads?.slots["community-list"]} />
        )}
        <Pager basePath={`/community/${space.slug}`} page={page} totalPages={totalPages} keep={{ sort: sort === "active" ? undefined : sort, q: q || undefined }} />
      </main>
    </AdsProvider>
  );
}
