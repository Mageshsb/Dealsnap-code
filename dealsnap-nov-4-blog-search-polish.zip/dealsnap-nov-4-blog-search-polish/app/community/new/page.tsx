import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { mayAddPictures } from "@/lib/post-pictures";
import { MAX_PICTURES } from "@/lib/deal-text";
import { newFormCheck, turnstileSiteKey } from "@/lib/captcha";
import { listSpaces } from "@/lib/community-db";
import { needsBotCheck, writerProblem } from "@/lib/community-access";
import { checkedLabel } from "@/lib/community-labels";
import { isStaffRole } from "@/lib/permissions";
import BackLink from "@/components/BackLink";
import EmptyState from "@/components/EmptyState";
import NewThreadForm from "@/components/community/NewThreadForm";

export const metadata: Metadata = { title: "Start a discussion | Community", robots: { index: false } };

export default async function NewThreadPage({ searchParams }: { searchParams: Promise<{ space?: string; store?: string; category?: string; tag?: string }> }) {
  const sp = await searchParams;
  const keep = new URLSearchParams(Object.entries(sp).filter((e): e is [string, string] => typeof e[1] === "string" && e[1].length > 0)).toString();
  const here = `/community/new${keep ? `?${keep}` : ""}`;
  const user = await getCurrentUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(here)}`);
  const problem = writerProblem(user);

  const staff = isStaffRole(user.role);
  const spaces = listSpaces().filter((s) => s.who === "members" || staff);
  const wanted = spaces.find((s) => s.slug === sp.space);
  const defaultSpace = (wanted ?? spaces.find((s) => s.slug === "deal-talk") ?? spaces[0])?.id ?? "";
  const label = sp.store ? checkedLabel("store", sp.store) : sp.category ? checkedLabel("category", sp.category) : sp.tag ? checkedLabel("tag", sp.tag) : undefined;
  const usingTurnstile = !!turnstileSiteKey();

  return (
    <main className="mx-auto flex w-full max-w-2xl flex-1 flex-col gap-5 px-4 py-6">
      <BackLink href={wanted ? `/community/${wanted.slug}` : "/community"} exact>
        {wanted ? wanted.name : "Community"}
      </BackLink>
      <h1 className="text-xl font-bold sm:text-2xl">Start a discussion</h1>
      {problem ? (
        <EmptyState icon="lock">{problem}</EmptyState>
      ) : (
        <NewThreadForm
          spaces={spaces.map((s) => ({
            value: s.id,
            label: s.name,
            hint: s.rules || s.blurb || undefined,
            askHint: s.kind === "ask",
          }))}
          defaultSpace={defaultSpace}
          maxPictures={mayAddPictures(user) ? MAX_PICTURES.thread : 0}
          label={label && { kind: label.kind, value: label.value, name: label.name }}
          initialCheck={needsBotCheck(user) ? newFormCheck(!usingTurnstile) : undefined}
          turnstileSiteKey={turnstileSiteKey()}
        />
      )}
    </main>
  );
}
