import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Fragment } from "react";
import { getCurrentUser } from "@/lib/auth";
import { getBlockedIds } from "@/lib/db";
import { getPageAds } from "@/lib/ad-serving";
import { RAIL_SLOTS } from "@/lib/ads";
import { adPositions } from "@/lib/ad-positions";
import {
  getLikedPostIds,
  getMostHelpfulPost,
  getPostSummary,
  getPostsPage,
  getReportCounts,
  getReportedPostIds,
  getThreadBySlug,
  getThreadParticipants,
  getCommunitySettings,
  getThreadFollow,
  listSpaces,
  markThreadSeen,
} from "@/lib/community-db";
import { teamMember, mayAct, threadVisibleTo, writerProblem } from "@/lib/community-access";
import { COMMUNITY_HELPFUL_LIKES, POSTS_PER_PAGE, isQuietClosed, pageOfSeq, pagesFor } from "@/lib/community-rules";
import { checkedLabel } from "@/lib/community-labels";
import { isStaffRole } from "@/lib/permissions";
import { getSiteHosts, getSiteUrl } from "@/lib/site-url";
import { getPicturesFor } from "@/lib/pictures";
import { mayAddPictures } from "@/lib/post-pictures";
import { plainDescription, MAX_PICTURES } from "@/lib/deal-text";
import { timeAgo } from "@/lib/format";
import { AdsProvider } from "@/components/AdUnit";
import AdRails from "@/components/AdRails";
import AdUnit from "@/components/AdUnit";
import BackLink from "@/components/BackLink";
import Icon from "@/components/Icon";
import JsonLd from "@/components/JsonLd";
import Pager from "@/components/community/Pager";
import PostItem, { StartedBy, type PostReader } from "@/components/community/PostItem";
import Replies from "@/components/community/Replies";
import ThreadTools, { ThreadStateBanner } from "@/components/community/ThreadTools";
import { card } from "@/components/community/styles";

type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ page?: string; held?: string }> };

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const [{ slug }, sp] = await Promise.all([params, searchParams]);
  const thread = getThreadBySlug(slug);
  if (!thread) return { title: "Thread not found", robots: { index: false } };
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);
  const open = thread.status === "live";
  const first = open ? getPostsPage(thread.id, 1)[0] : undefined;
  return {
    title: `${thread.title} | ${thread.spaceName} | Community`,
    description: first?.text ? first.text.replace(/\s+/g, " ").slice(0, 155) : undefined,
    alternates: { canonical: `/community/t/${thread.slug}${page > 1 ? `?page=${page}` : ""}` },
    // Threads waiting for a check or taken down are never for search engines.
    robots: open ? undefined : { index: false, follow: false },
  };
}

export default async function ThreadPage({ params, searchParams }: Props) {
  const [{ slug }, sp] = await Promise.all([params, searchParams]);
  const thread = getThreadBySlug(slug);
  const viewer = await getCurrentUser();
  if (!thread || !threadVisibleTo(thread, viewer)) notFound();

  const totalPages = pagesFor(thread.lastSeq);
  const page = Math.min(totalPages, Math.max(1, parseInt(sp.page ?? "1", 10) || 1));
  const posts = getPostsPage(thread.id, page);
  const ids = posts.map((p) => p.id);
  const tidy = teamMember(viewer, "forum.tidy");
  const moderate = teamMember(viewer, "forum.moderate");
  const siteUrl = await getSiteUrl();
  const reader: PostReader = {
    loggedIn: !!viewer,
    userId: viewer?.id,
    canReply: false,
    isAsker: !!viewer && viewer.id === thread.userId,
    canTidy: tidy,
    canModerate: moderate,
    mayAct: (p) => !!viewer && mayAct(viewer, p),
    liked: viewer ? getLikedPostIds(viewer.id, ids) : new Set(),
    reported: viewer ? getReportedPostIds(viewer.id, ids) : new Set(),
    reportCounts: moderate ? getReportCounts(ids) : new Map(),
    blocked: new Set(viewer ? getBlockedIds(viewer.id) : []),
    hosts: await getSiteHosts(),
    // The pictures in this page's posts, in one look-up.
    pictures: getPicturesFor("post", posts.filter((p) => p.text.includes("[[shot:")).map((p) => p.id)),
    picturesAllowed: mayAddPictures(viewer),
  };

  const problem = writerProblem(viewer);
  const live = thread.status === "live";
  const quietDays = getCommunitySettings().closeAfterDays;
  const quiet = live && isQuietClosed(thread.lastPostAt, quietDays);
  const canReply = live && !problem && ((!thread.locked && !quiet) || moderate);
  reader.canReply = canReply;
  const notice = !live
    ? null
    : !viewer
      ? (
          <>
            <Link href={`/login?next=${encodeURIComponent(`/community/t/${thread.slug}`)}`} className="font-medium text-orange-700 hover:underline dark:text-orange-400">
              Log in
            </Link>{" "}
            to reply.
          </>
        )
      : problem
        ? problem
        : thread.locked
          ? "This thread is locked, so there are no new replies."
          : quiet
            ? (
                <>
                  This thread has been quiet for over {quietDays} days, so it&apos;s closed to new replies.{" "}
                  <Link href={`/community/new?space=${thread.spaceSlug}`} className="font-medium text-orange-700 hover:underline dark:text-orange-400">
                    Start a new thread
                  </Link>{" "}
                  to pick it up again.
                </>
              )
            : null;

  // A follower has now seen as far as this page goes.
  const follow = viewer ? getThreadFollow(viewer.id, thread.id) : undefined;
  if (viewer && follow) markThreadSeen(viewer.id, thread.id, Math.min(page * POSTS_PER_PAGE, thread.lastSeq));

  const best = thread.solvedPostId && live ? getPostSummary(thread.solvedPostId) : undefined;
  const helpful = live && !best && thread.replyCount >= 3 ? getMostHelpfulPost(thread.id, COMMUNITY_HELPFUL_LIKES) : undefined;
  const helpfulPost = helpful ? getPostSummary(helpful.id) : undefined;

  const ads = live ? await getPageAds({ kind: "community", path: `/community/t/${thread.slug}`, labels: {} }, ["community-thread", "community-end", ...RAIL_SLOTS]) : undefined;
  const inThread = ads?.slots["community-thread"];
  const adsAfter = inThread ? adPositions(posts.length, inThread.first, inThread.every, [], true, inThread.max) : [];

  // Offered when "@" is typed in the reply box: people who have posted here (the only people a mention reaches), not yourself.
  const mentionNames = canReply
    ? getThreadParticipants(thread.id, 200)
        .map((p) => p.username)
        .filter((n) => /^[A-Za-z0-9_]{3,20}$/.test(n) && n !== viewer?.username)
    : [];

  const label = thread.labelKind ? checkedLabel(thread.labelKind, thread.labelValue) : undefined;
  const spaces = tidy ? listSpaces().filter((s) => s.who === "members" || isStaffRole(viewer!.role)).map((s) => ({ value: s.id, label: s.name })) : [];
  const pageHref = (seq: number) => `/community/t/${thread.slug}${pageOfSeq(seq) > 1 ? `?page=${pageOfSeq(seq)}` : ""}#post-${seq}`;
  const replies = posts.filter((p) => p.seq > 1 && p.status === "live" && p.text.length > 0);

  // What search engines read: the thread, and the replies on this page.
  const forumData =
    live && page === 1
      ? {
          "@context": "https://schema.org",
          "@type": "DiscussionForumPosting",
          headline: thread.title,
          url: `${siteUrl}/community/t/${thread.slug}`,
          datePublished: thread.createdAt,
          author: { "@type": "Person", name: thread.username, url: `${siteUrl}/u/${thread.username}` },
          ...(posts[0]?.status === "live" ? { text: plainDescription(posts[0].text) } : {}),
          isPartOf: { "@type": "CollectionPage", name: thread.spaceName, url: `${siteUrl}/community/${thread.spaceSlug}` },
          interactionStatistic: { "@type": "InteractionCounter", interactionType: "https://schema.org/CommentAction", userInteractionCount: thread.replyCount },
          comment: replies.map((p) => ({
            "@type": "Comment",
            url: `${siteUrl}/community/t/${thread.slug}${pageOfSeq(p.seq) > 1 ? `?page=${pageOfSeq(p.seq)}` : ""}#post-${p.seq}`,
            text: plainDescription(p.text),
            datePublished: p.createdAt,
            author: { "@type": "Person", name: p.username, url: `${siteUrl}/u/${p.username}` },
          })),
        }
      : undefined;

  return (
    <AdsProvider ads={ads}>
      <main className="relative mx-auto flex w-full max-w-3xl flex-1 flex-col gap-4 px-4 py-6">
        <AdRails />
        {forumData && <JsonLd data={forumData} />}
        <BackLink href={`/community/${thread.spaceSlug}`} exact>
          {thread.spaceName}
        </BackLink>

        {thread.status === "held" && (moderate ? <ThreadStateBanner threadId={thread.id} state="held" /> : (
          <p className="flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5 text-sm text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/20 dark:text-amber-200">
            <Icon name="eye" className="size-4 shrink-0" />
            Thanks! Your first thread is waiting for a quick check by our team. Only you can see it until then.
          </p>
        ))}
        {thread.status === "removed" && moderate && <ThreadStateBanner threadId={thread.id} state="removed" canDelete={teamMember(viewer, "forum.delete")} posts={thread.lastSeq} />}
        {thread.status === "deleted" && <p className="rounded-lg border border-zinc-200 px-3 py-2.5 text-sm text-zinc-500 dark:border-zinc-800">Deleted by its writer. Only moderators can see it.</p>}

        <header className="flex flex-col gap-3">
          <h1 className="text-xl font-bold leading-snug [overflow-wrap:anywhere] sm:text-2xl">{thread.title}</h1>
          <p className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-zinc-500">
            {thread.pinned && (
              <span className="flex items-center gap-1 font-medium text-orange-700 dark:text-orange-400">
                <Icon name="pin" className="size-3.5" />
                Pinned
              </span>
            )}
            {thread.locked && (
              <span className="flex items-center gap-1 font-medium">
                <Icon name="lock" className="size-3.5" />
                Locked
              </span>
            )}
            {quiet && !thread.locked && (
              <span className="flex items-center gap-1 font-medium">
                <Icon name="lock" className="size-3.5" />
                Closed (quiet for {quietDays}+ days)
              </span>
            )}
            {thread.solved && (
              <span className="flex items-center gap-1 font-medium text-green-700 dark:text-green-400">
                <Icon name="circle-check" className="size-3.5" />
                Answered
              </span>
            )}
            <span>
              {thread.replyCount.toLocaleString("en-GB")} {thread.replyCount === 1 ? "reply" : "replies"}
            </span>
            <span aria-hidden>·</span>
            <span>Last reply {timeAgo(thread.lastPostAt)}</span>
            {label && (
              <>
                <span aria-hidden>·</span>
                <Link href={label.href} className="font-medium text-orange-700 hover:underline dark:text-orange-400">
                  {label.name}
                </Link>
              </>
            )}
            {thread.replyCount > 4 && page < totalPages && (
              <Link href={pageHref(thread.lastSeq)} className="ml-auto font-medium text-orange-700 hover:underline dark:text-orange-400">
                Jump to latest
              </Link>
            )}
          </p>
          {live && (viewer || tidy || moderate) && (
            <ThreadTools
              threadId={thread.id}
              title={thread.title}
              spaceId={thread.spaceId}
              spaces={spaces}
              following={viewer ? !!follow : null}
              canTidy={tidy}
              canModerate={moderate}
              pinned={thread.pinned}
              locked={thread.locked}
            />
          )}
        </header>

        {best && (
          <Link href={pageHref(best.seq)} className="group flex flex-col gap-1 rounded-lg border border-green-200 bg-green-50 px-3 py-2.5 dark:border-green-900/50 dark:bg-green-950/20">
            <span className="flex items-center gap-1.5 text-xs font-semibold text-green-800 dark:text-green-400">
              <Icon name="circle-check" className="size-3.5" />
              Best answer
            </span>
            <span className="line-clamp-3 text-sm text-zinc-700 [overflow-wrap:anywhere] dark:text-zinc-300">{best.text}</span>
            <span className="flex min-w-0 items-center gap-1.5 text-xs text-zinc-500">
              <span className="min-w-0 truncate font-medium">{best.username}</span>
              <span aria-hidden>·</span>
              <span className="shrink-0 font-medium text-orange-700 group-hover:underline dark:text-orange-400">See in thread</span>
            </span>
          </Link>
        )}
        {helpfulPost && (
          <Link href={pageHref(helpfulPost.seq)} className="group flex flex-col gap-1 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5 dark:border-amber-900/50 dark:bg-amber-950/20">
            <span className="flex items-center gap-1.5 text-xs font-semibold text-amber-700 dark:text-amber-500">
              <Icon name="thumbs-up" className="size-3.5" />
              Most helpful
            </span>
            <span className="line-clamp-3 text-sm text-zinc-700 [overflow-wrap:anywhere] dark:text-zinc-300">{helpfulPost.text}</span>
            <span className="flex min-w-0 items-center gap-1.5 text-xs text-zinc-500">
              <span className="min-w-0 truncate font-medium">{helpfulPost.username}</span>
              <span aria-hidden>·</span>
              <span className="shrink-0">{helpfulPost.likeCount} likes</span>
              <span aria-hidden>·</span>
              <span className="shrink-0 font-medium text-orange-700 group-hover:underline dark:text-orange-400">See in thread</span>
            </span>
          </Link>
        )}

        <section className={`${card} flex flex-col gap-5`} aria-label="Posts">
          {page > 1 && <StartedBy thread={thread} />}
          <Replies threadSlug={thread.slug} page={page} canReply={canReply} mentionNames={mentionNames} notice={notice} maxPictures={reader.picturesAllowed ? MAX_PICTURES.reply : 0}>
            <div className="flex flex-col gap-5">
              {posts.map((p, i) => (
                <Fragment key={p.id}>
                  <PostItem post={p} thread={thread} reader={reader} />
                  {adsAfter.includes(i) && <AdUnit slot="community-thread" n={adsAfter.indexOf(i)} className="my-1" />}
                </Fragment>
              ))}
            </div>
          </Replies>
        </section>

        <Pager basePath={`/community/t/${thread.slug}`} page={page} totalPages={totalPages} />
        <AdUnit slot="community-end" className="my-2" />
      </main>
    </AdsProvider>
  );
}
