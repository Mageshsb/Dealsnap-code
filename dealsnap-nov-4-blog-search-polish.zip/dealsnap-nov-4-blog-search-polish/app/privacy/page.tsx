import Link from "next/link";
import { notFound } from "next/navigation";
import { InfoTable, type InfoSection } from "@/components/InfoPage";
import SitePageView from "@/components/SitePageView";
import CookieSettingsLink from "@/components/CookieSettingsLink";
import { getSiteSettings, needsCookieConsent } from "@/lib/site-settings";
import { getLegal, MIN_AGE, operatorLine, operatorName } from "@/lib/legal";
import { getSitePage, pageMetadata } from "@/lib/site-pages";
import { turnstileSiteKey } from "@/lib/captcha";
import { getAdSettings } from "@/lib/ad-serving";

export function generateMetadata() {
  return pageMetadata("privacy");
}

// The sections below are written here, from the site's real settings (cookies,
// analytics, ads, who data goes to), so the policy can't drift from what the
// site does. Admin → Pages adds the title, date and any sections of its own after them.
export default function PrivacyPage() {
  const page = getSitePage("privacy");
  if (!page) notFound();
  const legal = getLegal();
  const settings = getSiteSettings();
  const analytics = !!(settings.gaId || settings.gtmId);
  // The admin's custom code (a Meta pixel and the like): marketing cookies.
  const marketing = !!(settings.headCode || settings.footerCode);
  const turnstile = !!turnstileSiteKey();
  // Admin → Ads: said only once ads are on, and Google only once its ad network is.
  const ads = getAdSettings();
  const adNetwork = ads.on && ads.network === "gam";
  const cookieChoice = needsCookieConsent(settings);
  const privacyEmail = <a href={`mailto:${legal.email.privacy}`}>{legal.email.privacy}</a>;

  const sections: InfoSection[] = [
    {
      id: "who-we-are",
      title: "Who we are",
      body: (
        <>
          <p>
            DealSnap is run by {operatorLine()}. We decide how your personal information is used, which makes us the
            “controller” under UK data protection law (the UK GDPR and the Data Protection Act 2018).
          </p>
          <p>This policy covers our website, our iPhone and Android apps and our browser extension.</p>
          {legal.icoNumber && <p>We’re registered with the Information Commissioner’s Office (ICO), number {legal.icoNumber}.</p>}
          <p>Questions about your data, or want to use any of your rights? Email {privacyEmail}.</p>
        </>
      ),
    },
    {
      id: "what-we-collect",
      title: "What we collect",
      body: (
        <>
          <h3>When you browse</h3>
          <p>
            You don’t need an account to look at deals. We don’t ask who you are
            {analytics || marketing
              ? ", and analytics or marketing cookies only run if you say yes on the cookie banner (see Cookies below)"
              : ", and we don’t use advertising or tracking cookies"}
            . Like every
            website, our server briefly sees your IP address and browser details in order to send you the page.
          </p>
          <h3>When you make an account</h3>
          <ul>
            <li><strong>Sign-in details:</strong> your username, email address and password. Passwords are stored scrambled (hashed), so nobody at DealSnap can read them.</li>
            <li><strong>Continue with Google:</strong> if you use it, Google tells us your email address and an account number. We never see your Google password.</li>
            <li><strong>Two-step login:</strong> if you turn it on, we keep the secret your authenticator app uses, and your backup codes.</li>
            <li><strong>Your profile:</strong> anything you add, such as a bio or profile photo.</li>
          </ul>
          <h3>What you post and do</h3>
          <ul>
            <li>Deals you post (including photos), comments, and the reasons you give when reporting something.</li>
            <li>Deals you love, save or say have ended; members, stores and topics you follow; alerts you set up; members you block.</li>
            <li>Appeals you send us, and any moderation decisions about your account.</li>
          </ul>
          <h3>Clicks on “Get deal”</h3>
          <p>
            Every “Get deal” button goes through DealSnap on its way to the shop. We record which deal was clicked and
            when, and which account clicked it if you’re signed in. This shows us which deals people find useful.
          </p>
          <h3>Keeping accounts safe</h3>
          <p>
            When a sign-in fails, someone asks for a password reset or the contact form is used, we note the email address and the IP
            address it came from, to stop password guessing and spam. We also record when you last signed in.
          </p>
          <h3>When you contact us</h3>
          <p>
            Your name, email address, the topic and your message, whether you use the contact form or email us. If you’re signed in,
            we note which account sent it.
          </p>
          <h3>Notifications</h3>
          <p>
            Your notification settings: which kinds you want, and whether emails come straight away or as a daily summary. If you allow notifications, your browser (or, in
            our phone apps, Apple or Google) gives us a delivery address for your device. It doesn’t identify you by itself.
          </p>
          <h3>In our phone apps</h3>
          <p>
            The apps show the DealSnap website, so everything on this page applies to them. They tell our server they’re the app, so it
            can fit the page to your phone, which says nothing about you. Store links open in a browser inside the app, and Amazon and
            eBay deals may open in those companies’ own apps, under their own privacy policies.
          </p>
          <h3>Things kept only on your device</h3>
          <p>
            Some choices are saved in your own browser rather than with us: whether to show expired deals, your cookie
            choice, and a half-written deal so you don’t lose it.
          </p>
        </>
      ),
    },
    {
      id: "public",
      title: "What other people can see",
      body: (
        <>
          <p>DealSnap is a public community. Anyone, signed in or not, can see:</p>
          <ul>
            <li>your username, profile photo, bio, badges and when you joined;</li>
            <li>the deals you post and the comments you write;</li>
            <li>the deals you’ve loved and who you follow, on your profile page.</li>
          </ul>
          <p>
            Your email address, saved deals, alerts and blocks are never shown to other members. Please don’t put
            personal details like your phone number or address in posts, comments or your bio.
          </p>
        </>
      ),
    },
    {
      id: "why",
      title: "Why we use it",
      body: (
        <>
          <p>The law says we need a valid reason (a “lawful basis”) for each use. Ours are:</p>
          <InfoTable
            head={["What we do", "Our reason"]}
            rows={[
              ["Run your account, show your posts, send the alerts and summaries you set up", "To provide the service you signed up for (contract)"],
              ["Stop spam, fake deals, password guessing and abuse; moderate posts; deal with reports and appeals", "Keeping DealSnap safe and trustworthy (legitimate interests)"],
              ["Reply to messages you send us", "Helping you (legitimate interests)"],
              ["Count “Get deal” clicks and work out which deals and shops are popular", "Improving the site (legitimate interests)"],
              ["Send clicks through affiliate links so we earn commission", "Funding the site (legitimate interests); see below"],
              ["Use automated tools and AI to help fill in deals and spot spam", "Running the site well (legitimate interests); see below"],
              ["Phone and browser notifications", "Your permission, which you can take back in your browser at any time (consent)"],
              ...(analytics ? [["Visitor statistics with Google Analytics", "Only if you say yes on the cookie banner (consent)"]] : []),
              ...(marketing ? [["Measure how our adverts are doing", "Only if you say yes to marketing cookies on the cookie banner (consent)"]] : []),
              ["Keep records the law requires, or respond to lawful requests", "Legal obligation"],
            ]}
          />
          <p>
            We don’t send marketing emails. The only emails you’ll get from us are about your account (such as password
            resets) and the alerts and summaries you choose. Each alert email has a one-tap unsubscribe link.
          </p>
        </>
      ),
    },
    {
      id: "affiliate-links",
      title: "Affiliate links and the shops we link to",
      body: (
        <>
          <p>
            DealSnap is free to use because we earn a small commission when someone buys through some of our links.{" "}
            “<Link href="/terms#how-we-make-money">How we make money</Link>” in our Terms explains this in full. Here’s what it means for your data.
          </p>
          <ul>
            <li>
              When you tap “Get deal”, the link may pass through an affiliate network such as <strong>Amazon Associates</strong>, <strong>Awin</strong> or{" "}
              <strong>Skimlinks</strong> before reaching the shop.
            </li>
            <li>
              To credit us with the sale, the network and the shop may set their own cookies on your device and see your IP address
              and browser details. That happens on their websites, under their privacy policies.
            </li>
            <li>
              We pass on the deal reference only, never your name, username or email address. We get reports of total clicks and
              commission, not who bought what.
            </li>
          </ul>
          <p>
            Once you’re on a shop’s website, anything you buy, and the details you give them, is between you and that shop.
            Please read their privacy policy.
          </p>
        </>
      ),
    },
    ...(ads.on
      ? [
          {
            id: "adverts",
            title: "Adverts",
            body: (
              <>
                <p>
                  Some pages show adverts, always labelled “Ad” with who they&apos;re from. Advertisers pay us to show them.
                  The adverts we sell ourselves are chosen for the page you&apos;re on (a store&apos;s advert on its deals), never
                  for who you are: they use no cookies and nothing about you. We count how many times each advert is seen and
                  tapped, as totals only; your IP address is used for a few minutes to stop the same view or tap being counted
                  over and over, and isn&apos;t kept. Advertisers only ever get those totals.
                </p>
                {adNetwork && (
                  <p>
                    Spaces we haven&apos;t sold may show adverts from Google&apos;s ad network.{" "}
                    {ads.personalised
                      ? "Google may use cookies to choose them, only if you agree in the consent box Google shows."
                      : "These are “limited ads”: Google uses no cookies and nothing personal to choose them, though, like any website, it sees your IP address and browser details when it sends one."}
                  </p>
                )}
                {ads.membersFree && <p>Signed-in members don&apos;t see adverts.</p>}
              </>
            ),
          },
        ]
      : []),
    {
      id: "ai",
      title: "Automated tools and AI",
      body: (
        <>
          <p>
            We may use AI services to help with the tasks described in our{" "}
            <Link href="/terms#automated-tools">Terms</Link>, such as filling in a deal’s details from a link or spotting spam. When we
            do, only what that task needs is sent to the AI provider, for example a deal’s link, photo or description. The provider handles it
            for us under contract and isn’t allowed to use it to train its own AI.
          </p>
          <p>
            We don’t let AI make decisions about you or your account on its own. Our tools can flag things for our team to look at, but a
            person decides whether to suspend or close an account.
          </p>
        </>
      ),
    },
    {
      id: "extension",
      title: "Our browser extension",
      body: (
        <>
          <p>
            The DealSnap browser extension never sends us the pages you visit. The number on its icon comes from a list of shops it
            downloads from us every few hours and checks on your own computer.
          </p>
          <p>
            It only contacts us when you use it: when you open it on a page, it asks us what DealSnap has for that page (its address
            only); when you press “Post this deal” (or choose it when you right-click a page or a link), it sends us
            the product details from that page so we can fill in the post form (and when a shop won’t let our post form read a
            link you paste, the extension opens it in a tab behind and reads it the same way); and
            when you search, it sends us what you typed. The page is read in your browser, and we only keep what you then choose to post.
          </p>
          <p>
            If you’re signed in to DealSnap in the same browser, the extension uses that sign-in to love and save deals for you, and to
            show your notifications on your computer (it checks for new ones every few minutes).
          </p>
        </>
      ),
    },
    {
      id: "cookies",
      title: "Cookies",
      body: (
        <>
          <p>
            Cookies are small files a website saves in your browser. Browsers can also keep small notes for a site (“local
            storage”), and the same rules apply to those, so they’re all listed here.
          </p>
          <h3>Essential: always on</h3>
          <p>
            These make DealSnap work, keep it secure or remember a choice you’ve made yourself, so they don’t need your
            permission. They never track you or leave DealSnap.
          </p>
          <InfoTable
            head={["Name", "What it does", "How long"]}
            rows={[
              ["dealsnap_session", "Keeps you signed in", "30 days"],
              ["dealsnap_google", "Checks that a Google sign-in really came from you", "10 minutes"],
              ["dealsnap_2fa", "Remembers you’re half-way through a two-step sign-in", "10 minutes"],
              ["dealsnap_recovery", "Shows your new backup codes once, after setting up two-step login", "2 minutes"],
              ["dealsnap_view", "Remembers whether you chose List or Cards view", "1 year"],
              ["dealsnap:appPushToken", "Phone apps only: remembers this phone’s notification address, so notifications stop when you sign out (local storage)", "Until you sign out or turn notifications off"],
              ...(cookieChoice ? [["dealsnap:cookieConsent", "Remembers your cookie choices (local storage)", "6 months, then we ask again"]] : []),
              ["dealsnap:showExpired, dealsnap:hideLocal", "Remember the filters you picked (local storage)", "Until you change them"],
              ["ds_deal_draft", "Keeps a half-written deal so you don’t lose it (local storage)", "Until you post it or start again"],
              ["ds_banner_closed", "Remembers that you closed a site announcement (local storage)", "Until the next announcement"],
              ["deals-cache:…, swipe-cache:…", "Brings you back to the same deal when you press Back (session storage)", "Until you close the tab"],
            ]}
          />
          {(analytics || marketing) && (
            <>
              <h3>Optional: only if you say yes</h3>
              <p>
                These are off until you accept them on the cookie banner, and nothing from them runs before then. “Reject all”
                is as easy as “Accept all”, and saying no doesn’t change anything else about DealSnap.
              </p>
              <InfoTable
                head={["Name", "What it does", "How long"]}
                rows={[
                  ...(analytics ? [["_ga, _ga_*", "Analytics: Google Analytics counts visits and which pages get used, so we can improve the site. Google sees your IP address and browser details", "Up to 2 years"]] : []),
                  ...(marketing ? [[`Set by ${settings.marketingPartners || "our advertising partners"}`, "Marketing: shows them whether our adverts bring people here. They may use it to show you adverts elsewhere", "Set by them; see their cookie policy"]] : []),
                ]}
              />
              <p>
                You can change your mind at any time
                {cookieChoice && (
                  <>
                    {" "}with <CookieSettingsLink className="font-medium text-orange-700 underline-offset-2 hover:underline dark:text-orange-400">cookie settings</CookieSettingsLink> (also under Cookies at the bottom of every page)
                  </>
                )}
                . If you take a yes back, we delete the cookies those services left on DealSnap.
              </p>
            </>
          )}
          {!analytics && !marketing && <p>We don’t use analytics or advertising cookies. If that changes, we’ll ask you first.</p>}
          <p>
            The shops and affiliate networks you visit after tapping “Get deal” set their own cookies on their websites (see
            above). You can clear or block cookies in your browser settings. If you block ours, you won’t be able to stay signed in.
          </p>
        </>
      ),
    },
    {
      id: "sharing",
      title: "Who we share it with",
      body: (
        <>
          <p>We never sell your personal information. We share it only with companies that help us run DealSnap, and only what each one needs:</p>
          <ul>
            <li><strong>Our hosting provider</strong>, which runs the servers and stores the database.</li>
            <li><strong>Resend</strong>, which delivers our emails (your email address and the message).</li>
            <li><strong>Google</strong>, if you use Continue with Google{analytics ? ", or accept analytics cookies" : ""}.</li>
            {marketing && <li><strong>{settings.marketingPartners || "Our advertising partners"}</strong>, only if you accept marketing cookies.</li>}
            <li><strong>Notification services</strong> (Apple, Google, Mozilla or Microsoft, depending on your device), which deliver notifications to your browser or our phone apps.</li>
            <li><strong>Affiliate networks</strong> such as Amazon Associates, Awin and Skimlinks, as described above.</li>
            {adNetwork && <li><strong>Google&apos;s ad network</strong>, for adverts in spaces we haven&apos;t sold (see Adverts).</li>}
            {turnstile && (
              <li><strong>Cloudflare Turnstile</strong>, which checks our sign-up, contact and posting forms are being used by a person, not a bot. It sees your IP address and browser details, but doesn’t use tracking cookies.</li>
            )}
            <li><strong>AI providers</strong>, if we use them for the tasks described above. They get only what each task needs.</li>
          </ul>
          <p>
            We may also share information if the law requires it, to protect people from harm or fraud, or if DealSnap is ever sold
            or merged. In that case, this policy would still apply to your information.
          </p>
        </>
      ),
    },
    {
      id: "transfers",
      title: "Data stored outside the UK",
      body: (
        <p>
          Some of the companies above are based in, or store data in, the US or the EU. When your information leaves the UK, we make
          sure it’s protected to UK standards. That’s through the UK’s “adequacy” rules, the UK Extension to the EU–US Data Privacy
          Framework, or the UK’s approved contract terms (the International Data Transfer Agreement or Addendum).
        </p>
      ),
    },
    {
      id: "how-long",
      title: "How long we keep it",
      body: (
        <>
          <InfoTable
            head={["Information", "How long"]}
            rows={[
              ["Your account, posts and activity", "Until you delete your account"],
              ["Sign-in sessions", "30 days, or until you log out"],
              ["Failed sign-ins, password reset requests and contact form limits", "7 days"],
              ["“Get deal” click records", "As long as they’re useful for statistics. No longer linked to you once your account is deleted"],
              ["Reports, suspensions and the staff action log", "As long as needed to keep the site safe and deal with appeals"],
              ["Messages you send us", "12 months, then deleted automatically"],
            ]}
          />
          <h3>When you delete your account</h3>
          <p>
            You can delete your account yourself in <Link href="/settings">Settings</Link>. Straight away we erase your username,
            email address, password, bio, photo and two-step login details. We also take down your deals and replace your comments
            with “[comment deleted]”. Your loves, saved deals, alerts, follows and notifications are deleted too.
          </p>
          <p>
            We keep an empty, anonymous placeholder so replies to your comments still make sense, but it can’t be linked back to you.
            Copies in our backups are overwritten as those backups are replaced.
          </p>
        </>
      ),
    },
    {
      id: "your-rights",
      title: "Your rights",
      body: (
        <>
          <p>Under UK data protection law you can:</p>
          <ul>
            <li><strong>Get a copy of your data.</strong> Use “Download your data” in <Link href="/settings">Settings</Link> for a file of everything we hold about you, or email us.</li>
            <li><strong>Correct it.</strong> Edit your profile and settings, or ask us.</li>
            <li><strong>Delete it.</strong> Use “Delete my account” in <Link href="/settings">Settings</Link>.</li>
            <li><strong>Object</strong> to how we use it, or ask us to <strong>restrict</strong> what we do with it.</li>
            <li><strong>Take it with you.</strong> The download is a standard file (JSON) you can use elsewhere.</li>
            <li><strong>Take back your permission</strong> at any time, for notifications{analytics || marketing ? " or cookies" : ""}.</li>
          </ul>
          <p>
            For anything you can’t do yourself, email {privacyEmail} or use the{" "}
            <Link href="/contact?topic=privacy">contact form</Link>. It’s free, and we’ll reply within one month.
          </p>
          <h3>Complaints</h3>
          <p>
            If you’re unhappy with how we’ve handled your data, tell us the same way. We’ll confirm we’ve received your complaint within
            30 days, look into it and tell you the outcome. You can also complain to the Information Commissioner’s Office at{" "}
            <a href="https://ico.org.uk/make-a-complaint/" target="_blank" rel="noopener noreferrer">ico.org.uk</a> or on 0303 123 1113,
            though we’d appreciate the chance to sort it out first.
          </p>
        </>
      ),
    },
    {
      id: "children",
      title: "Children",
      body: (
        <p>
          You must be {MIN_AGE} or over to make a DealSnap account. If you think a child under {MIN_AGE} has made an account,
          tell us at {privacyEmail} and we’ll delete it.
        </p>
      ),
    },
    {
      id: "security",
      title: "Keeping it safe",
      body: (
        <ul>
          <li>The whole site uses an encrypted (https) connection.</li>
          <li>Passwords are stored scrambled, and repeated wrong guesses lock sign-in for a while.</li>
          <li>You can turn on two-step login for extra protection. Our staff can be required to use it.</li>
          <li>Only a small number of staff can see members’ private details, and everything they do in the admin area is logged.</li>
        </ul>
      ),
    },
    {
      id: "changes",
      title: "Changes to this policy",
      body: (
        <p>
          If we change how we use your information, we’ll update this page and the date at the top. For bigger changes, we’ll also
          tell members on the site or by email before they take effect.
        </p>
      ),
    },
    {
      id: "contact",
      title: "Contact",
      body: (
        <p>
          {operatorName()}: {privacyEmail}
          {legal.registeredAddress && <>, or write to us at {legal.registeredAddress}</>}.
        </p>
      ),
    },
  ];

  return (
    <SitePageView
      page={page}
      before={sections}
      summary={
        <ul>
          <li>
            Browsing doesn’t need an account
            {analytics || marketing ? ", and optional cookies only run if you say yes." : ", and we don’t use advertising cookies."}
          </li>
          <li>Your username, posts, comments and the deals you love are public. Your email address never is.</li>
          <li>“Get deal” links may go through affiliate networks so we earn commission. They never get your name or email.</li>
          <li>We never sell your data. You can download it or delete your account in Settings at any time.</li>
        </ul>
      }
    />
  );
}
