import type { Metadata } from "next";
import { notFound } from "next/navigation";
import MediaKit, { KIT_PRINT_CSS } from "@/components/MediaKit";
import { countKitOpen, getKitData, getKitSettings, kitForLink } from "@/lib/media-kit";
import { getAdSettings } from "@/lib/ad-serving";
import { sampleSponsoredDeal } from "@/lib/kit-sample";
import { overLimit } from "@/lib/rate-limit";

// A business's private media kit, from the link staff sent them (Admin → Ads
// → Selling). No sign-in: the signed link is the key (lib/media-kit.ts). Never
// indexed or cached, and the link isn't passed on to other sites.
type Props = { params: Promise<{ id: string; token: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id, token } = await params;
  const kit = kitForLink(id, token);
  return {
    // Also the PDF's file name when it's saved.
    title: { absolute: kit ? `DealSnap media kit for ${kit.recipient}` : "DealSnap media kit" },
    robots: { index: false, follow: false },
  };
}

export default async function MediaKitPage({ params }: Props) {
  if (await overLimit("media-kit", 60)) notFound();
  const { id, token } = await params;
  const kit = kitForLink(id, token);
  if (!kit) notFound();
  await countKitOpen(kit);
  const settings = getKitSettings();

  return (
    <main className="flex w-full flex-1 flex-col bg-zinc-100 px-2 py-4 sm:px-4 sm:py-6 dark:bg-black">
      <style>{KIT_PRINT_CSS}</style>
      <MediaKit
        recipient={kit.recipient}
        note={kit.note}
        rates={kit.showRates ? kit.rates || settings.rates || getAdSettings().page.rates : ""}
        showStats={kit.showStats}
        data={getKitData()}
        ads={getAdSettings()}
        kit={settings}
        sampleDeal={sampleSponsoredDeal()}
        expiresOn={kit.expiresOn}
      />
    </main>
  );
}
