import { getPicture } from "@/lib/picture-store";
import { pictureIsShown } from "@/lib/pictures";

// Serves a member's picture (in a deal's description, a Community post or a
// comment): "full.webp" (up to 1600px, for reading it) or "sm.webp" (480px,
// for a thumbnail). The id is random and a picture never changes (a new one
// gets a new id), so a copy is always still right, but a post can be taken
// down. So browsers keep a picture for a day and Cloudflare (or any shared
// cache) for an hour: a picture the team removes is gone from everywhere
// within the hour, and for anyone who already has it, within a day. After
// that, asking again costs almost nothing: the id is the version, so we
// answer "unchanged" without sending the picture. Not served at all once its
// post is taken down.
const BROWSER_SECONDS = 24 * 60 * 60;
const SHARED_CACHE_SECONDS = 60 * 60;

export async function GET(request: Request, { params }: { params: Promise<{ id: string; file: string }> }) {
  const { id, file } = await params;
  const small = file === "sm.webp";
  if (!/^[a-f0-9]{24}$/.test(id) || !(small || file === "full.webp") || !pictureIsShown(id)) {
    return new Response("Not found", { status: 404 });
  }
  const headers = {
    "Cache-Control": `public, max-age=${BROWSER_SECONDS}, s-maxage=${SHARED_CACHE_SECONDS}`,
    ETag: `"${id}-${small ? "sm" : "full"}"`,
    "X-Content-Type-Options": "nosniff",
  };
  if (request.headers.get("if-none-match") === headers.ETag) return new Response(null, { status: 304, headers });

  const data = await getPicture(id, small ? "sm" : "full");
  if (!data) return new Response("Not found", { status: 404 });

  return new Response(new Uint8Array(data), {
    headers: {
      ...headers,
      "Content-Type": "image/webp",
      // Only ever a picture: nothing in it can run as a page.
      "Content-Security-Policy": "default-src 'none'; sandbox",
    },
  });
}
