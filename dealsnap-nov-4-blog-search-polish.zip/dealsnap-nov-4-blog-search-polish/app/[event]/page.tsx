import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getAllDeals } from "@/lib/mock-deals";
import { getAllPosts } from "@/lib/mock-blog";
import { getCategoryGroups } from "@/lib/categories";
import { slugify } from "@/lib/slug";
import { isExpired } from "@/lib/format";
import { rankMostLoved } from "@/lib/deal-views";
import { alertKeyword, eventCountdown, eventIntro, eventTiming, inEvent, matchesEvent, openEvents } from "@/lib/events";
import { getCurrentUser } from "@/lib/auth";
import { getEventBySlug, getEventPicks, getKeywordAlerts, getLiveEvents } from "@/lib/db";
import { can } from "@/lib/permissions";
import { sameKeyword } from "@/lib/alert-match";
import type { Deal } from "@/lib/types";
import DealTile from "@/components/DealTile";
import ScrollRow from "@/components/ScrollRow";
import KeywordAlertButton from "@/components/KeywordAlertButton";
import EmptyState from "@/components/EmptyState";
import Icon, { type IconName } from "@/components/Icon";
import { plainDescription } from "@/lib/deal-text";

export async function generateMetadata({ params }: { params: Promise<{ event: string }> }): Promise<Metadata> {
  const event = getEventBySlug((await params).event);
  if (!event) return {};
  const { year } = eventTiming(event);
  return {
    robots: event.launched ? undefined : { index: false },
    title: `${event.name} deals ${year}: the best UK offers, rated by shoppers`,
    description: `The best ${event.name} ${year} deals in the UK. Every deal is checked and rated by the DealSnap community.`,
    alternates: { canonical: `/${event.slug}` },
  };
}

function Row({
  title,
  icon,
  deals,
  href,
  id,
}: {
  title: string;
  icon?: IconName;
  deals: Deal[];
  href?: string;
  id: string;
}) {
  return (
    <section className="flex flex-col gap-3" aria-labelledby={id}>
      <div className="flex items-baseline justify-between gap-3">
        <h2 id={id} className="flex items-center gap-2 text-lg font-bold">
          {icon && <Icon name={icon} className="size-5 text-orange-700 dark:text-orange-400" />}
          {title}
        </h2>
        {href && (
          <Link
            href={href}
            className="shrink-0 text-sm font-medium text-orange-700 hover:underline dark:text-orange-400"
          >
            See all →
          </Link>
        )}
      </div>
      <ScrollRow label={title}>
        {deals.map((d) => (
          <DealTile key={d.slug} deal={d} />
        ))}
      </ScrollRow>
    </section>
  );
}

// One page for each shopping event (lib/events.ts) that gathers its best live
// deals, so it can be shared and found on Google ("black friday deals uk")
// every year at the same address.
export default async function EventPage({ params }: { params: Promise<{ event: string }> }) {
  const event = getEventBySlug((await params).event);
  const user = await getCurrentUser();
  // An event that isn't launched (or has been taken down) is only there for the admins who run it.
  if (!event || (!event.launched && !can(user?.role, "content.manage"))) notFound();
  const countdown = eventCountdown(event);
  const { year } = eventTiming(event);

  const live = getAllDeals().filter((d) => !isExpired(d.expiresAt) && !d.endedByMembers && d.status !== "pending");
  const ranked = rankMostLoved(live);
  // In the event: ticked in, or the wording fits, unless a helper took it out.
  const picks = getEventPicks(event.slug);
  const inThisEvent = ranked.filter((d) => inEvent(event, `${d.title} ${plainDescription(d.description)}`, picks.get(d.slug)));
  // A sale event has little tagged yet while shops announce theirs, so the
  // page falls back on what's most loved; a theme only shows what fits.
  const pool = event.kind === "sale" ? ranked : inThisEvent;
  const top = event.kind === "sale" ? ranked.slice(0, 12) : [];
  const byCategory = getCategoryGroups()
    .map((g) => ({ group: g, deals: pool.filter((d) => d.category === g.name).slice(0, 8) }))
    .filter((c) => c.deals.length >= 2);
  const guides = getAllPosts().filter((p) => matchesEvent(event, `${p.title} ${p.excerpt}`));
  const alsoOn = openEvents(getLiveEvents()).filter((e) => e.slug !== event.slug);

  const existing = user
    ? getKeywordAlerts(user.id).find((k) => sameKeyword(k.keyword, alertKeyword(event)))
    : undefined;

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-8 px-4 py-6">
      {!event.launched && (
        <p className="rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
          <Icon name="eye" className="mr-1.5" />
          Not launched: only admins can see this page.{" "}
          <Link href={`/admin/events/${event.id}`} className="font-medium underline">
            Edit event
          </Link>
        </p>
      )}
      <header className="flex flex-col gap-3 rounded-2xl bg-zinc-900 p-5 text-white sm:p-7 dark:bg-zinc-900">
        <span
          className={`self-start rounded-full px-3 py-1 text-xs font-semibold ${
            countdown.live ? "bg-orange-500 text-white" : "bg-white/10 text-zinc-200"
          }`}
        >
          {countdown.label}
        </span>
        <h1 className="text-2xl font-extrabold leading-tight sm:text-4xl">
          {event.name} deals {year}
        </h1>
        <p className="max-w-2xl text-sm leading-relaxed text-zinc-300 sm:text-base">{eventIntro(event)}</p>
        <KeywordAlertButton
          keyword={alertKeyword(event)}
          label={`Get alerts for ${event.name} deals`}
          initialAlertId={existing?.id ?? null}
          nextPath={`/${event.slug}`}
        />
      </header>

      {inThisEvent.length > 0 ? (
        <Row id="ev-tagged" title={`${event.name} deals so far`} icon={event.icon} deals={inThisEvent.slice(0, 12)} />
      ) : (
        event.kind === "theme" && (
          <EmptyState icon={event.icon}>
            <p>No {event.name} deals yet.</p>
            <Link href="/submit" className="font-medium text-orange-700 hover:underline dark:text-orange-400">
              Be the first to post one
            </Link>
          </EmptyState>
        )
      )}
      {top.length > 0 && <Row id="ev-top" title="Most loved right now" deals={top} href="/" />}
      {byCategory.map(({ group, deals }) => (
        <Row
          key={group.name}
          id={`ev-${slugify(group.name)}`}
          title={group.name}
          icon={group.icon}
          deals={deals}
          href={`/categories/${slugify(group.name)}`}
        />
      ))}

      {guides.length > 0 && (
        <section className="flex flex-col gap-3" aria-labelledby="ev-guides">
          <h2 id="ev-guides" className="text-lg font-bold">
            {event.name} guides
          </h2>
          <ul className="flex flex-col gap-2">
            {guides.map((p) => (
              <li key={p.slug}>
                <Link
                  href={`/blog/${p.slug}`}
                  className="font-medium text-orange-700 hover:underline dark:text-orange-400"
                >
                  {p.title}
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="flex flex-col gap-2 rounded-xl border border-zinc-200 bg-white p-5 text-sm leading-relaxed text-zinc-600 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-400">
        <h2 className="text-base font-bold text-zinc-900 dark:text-zinc-100">
          {event.kind === "sale" ? `How to spot a real ${event.name} deal` : `Found a ${event.name} deal?`}
        </h2>
        {event.kind === "sale" && (
          <p>
            Lots of &ldquo;was&rdquo; prices are higher than what the item really sold for. Before you buy, check the
            deal&apos;s comments: members often say if it was cheaper last month or elsewhere. Deals with plenty of
            hearts have been checked by lots of shoppers.
          </p>
        )}
        <p>
          <Link href="/submit" className="font-medium text-orange-700 hover:underline dark:text-orange-400">
            Post it
          </Link>{" "}
          and tick &ldquo;{event.name}&rdquo; so everyone can rate it.
        </p>
        {alsoOn.length > 0 && (
          <p>
            Also on now:{" "}
            {alsoOn.map((e, i) => (
              <span key={e.slug}>
                {i > 0 && ", "}
                <Link href={`/${e.slug}`} className="font-medium text-orange-700 hover:underline dark:text-orange-400">
                  {e.name} deals
                </Link>
              </span>
            ))}
          </p>
        )}
      </section>
    </main>
  );
}
