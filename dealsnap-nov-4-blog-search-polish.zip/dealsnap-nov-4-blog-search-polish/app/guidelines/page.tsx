import { notFound } from "next/navigation";
import SitePageView from "@/components/SitePageView";
import { getSitePage, pageMetadata } from "@/lib/site-pages";

// Written in Admin → Pages (the starting text is in lib/page-defaults.ts).
export function generateMetadata() {
  return pageMetadata("guidelines");
}

export default function GuidelinesPage() {
  const page = getSitePage("guidelines");
  if (!page) notFound();
  return <SitePageView page={page} />;
}
