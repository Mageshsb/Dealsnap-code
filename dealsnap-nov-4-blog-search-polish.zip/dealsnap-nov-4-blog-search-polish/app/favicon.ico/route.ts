import { faviconIco } from "@/lib/site-brand";

// Built when asked, not at deploy time, so an icon uploaded in Admin shows up.
export const dynamic = "force-dynamic";

// /favicon.ico: browsers and apps ask for it even when the page names its
// icons. The uploaded icon (Admin → Settings → General) or the built-in one;
// rechecked daily, as the address doesn't change with the icon.
export async function GET() {
  return new Response(new Uint8Array(await faviconIco()), {
    headers: {
      "Content-Type": "image/x-icon",
      "Cache-Control": "public, max-age=86400",
    },
  });
}
