import { getStoreLogoImage } from "@/lib/db";

// Serves a store's logo from the database. Logos only change when an admin
// replaces one, and the address carries a ?v= that changes then, so browsers
// and CDNs can keep a copy for a year: after the first view, no repeat requests.
export async function GET(_request: Request, { params }: { params: Promise<{ key: string }> }) {
  const { key } = await params;
  const logo = /^[a-z0-9]+$/.test(key) ? getStoreLogoImage(key) : undefined;
  if (!logo) return new Response("Not found", { status: 404 });

  return new Response(Buffer.from(logo.data), {
    headers: {
      "Content-Type": logo.type,
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}
