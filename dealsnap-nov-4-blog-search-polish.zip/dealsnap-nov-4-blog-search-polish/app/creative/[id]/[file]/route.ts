import { getCampaignImage } from "@/lib/db";

// Serves an ad campaign's picture from the database: "image-<version>.webp"
// or "logo-<version>.webp". The version changes with each upload, so every
// address can be cached for a year.
export async function GET(_request: Request, { params }: { params: Promise<{ id: string; file: string }> }) {
  const { id, file } = await params;
  const match = /^[0-9a-f-]{36}$/.test(id) ? file.match(/^(image|logo)-([a-z0-9]{1,20})\.webp$/) : null;
  const image = match ? getCampaignImage(id, match[1] as "image" | "logo", match[2]) : undefined;
  if (!image) return new Response("Not found", { status: 404 });
  return new Response(Buffer.from(image.data), {
    headers: {
      "Content-Type": image.type,
      "Cache-Control": "public, max-age=31536000, immutable",
      // Only ever a picture: nothing in it can run as a page.
      "Content-Security-Policy": "default-src 'none'; sandbox",
    },
  });
}
