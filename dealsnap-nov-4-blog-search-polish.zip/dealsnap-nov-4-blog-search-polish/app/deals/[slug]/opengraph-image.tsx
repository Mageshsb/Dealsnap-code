import { ImageResponse } from "next/og";
import { getVisibleDeal } from "@/lib/deal-access";
import { isExpired } from "@/lib/format";
import { dealPriceTag } from "@/lib/deal-kinds";
import { OG_SIZE, clip, logoDataUri, publicImageDataUri } from "@/lib/og";
import { getSiteName } from "@/lib/site-url";

// The picture shown when a deal's link is shared (WhatsApp, Facebook, X,
// iMessage…): the photo, the price and the discount (or the offer, like "Up to
// 70% off"), so the preview sells the deal on its own.
export const alt = "Deal on DealSnap";
// Drawn at 720×378 (0.6 × the usual 1200×630): big enough for every app, while keeping
// photo previews under the ~300KB WhatsApp will show.
const S = 0.6;
const px = (n: number) => Math.round(n * S);
export const size = { width: px(OG_SIZE.width), height: px(OG_SIZE.height) };
export const contentType = "image/png";

export default async function Image({ params }: { params: Promise<{ slug: string }> }) {
  const deal = await getVisibleDeal((await params).slug);
  const [photo, logo] = await Promise.all([publicImageDataUri(deal?.image), logoDataUri()]);
  const siteName = getSiteName();

  if (!deal) {
    return new ImageResponse(
      (
        <div style={{ display: "flex", width: "100%", height: "100%", alignItems: "center", justifyContent: "center", background: "#fff7ed", fontSize: px(72), color: "#18181b" }}>
          {siteName}
        </div>
      ),
      size
    );
  }

  const tag = dealPriceTag(deal);
  const expired = isExpired(deal.expiresAt);

  return new ImageResponse(
    (
      <div style={{ display: "flex", width: "100%", height: "100%", background: "#ffffff", color: "#18181b" }}>
        <div
          style={{
            display: "flex",
            width: px(520),
            height: "100%",
            alignItems: "center",
            justifyContent: "center",
            background: "linear-gradient(135deg, #ffedd5, #fef3c7)",
            padding: px(40),
          }}
        >
          <img
            src={photo ?? logo}
            alt=""
            width={px(photo ? 440 : 260)}
            height={px(photo ? 440 : 260)}
            style={{ objectFit: photo ? "cover" : "contain", borderRadius: photo ? px(28) : 0, opacity: expired ? 0.5 : 1 }}
          />
        </div>

        <div style={{ display: "flex", flex: 1, flexDirection: "column", padding: `${px(56)}px ${px(56)}px ${px(48)}px` }}>
          <div style={{ display: "flex", fontSize: px(50), lineHeight: 1.2, fontWeight: 700 }}>{clip(deal.title, 80)}</div>

          <div style={{ display: "flex", alignItems: "baseline", gap: px(22), marginTop: px(34) }}>
            {/* An offer is smaller than a price so it fits in two lines at most. */}
            <span style={{ display: "flex", alignItems: "baseline", fontSize: px(tag.isOffer ? 64 : 92), lineHeight: 1.1, fontWeight: 700, color: expired ? "#71717a" : "#ea580c" }}>
              {tag.from && <span style={{ fontSize: px(44), marginRight: px(12) }}>from</span>}
              {tag.main}
              {tag.unit && <span style={{ fontSize: px(44) }}>{tag.unit}</span>}
            </span>
            {tag.note && <span style={{ fontSize: px(34), color: "#71717a" }}>{tag.note}</span>}
            {tag.was && (
              <span style={{ fontSize: px(40), color: "#a1a1aa", textDecoration: tag.wasRrp ? "none" : "line-through" }}>
                {tag.wasRrp ? `RRP ${tag.was}` : tag.was}
              </span>
            )}
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: px(18), marginTop: px(18), fontSize: px(34) }}>
            {expired ? (
              <span style={{ background: "#e4e4e7", color: "#52525b", borderRadius: px(999), padding: `${px(6)}px ${px(22)}px` }}>Expired</span>
            ) : (
              tag.off && <span style={{ background: "#dcfce7", color: "#15803d", borderRadius: px(999), padding: `${px(6)}px ${px(22)}px` }}>{tag.off}% off</span>
            )}
            <span style={{ color: "#71717a" }}>at {clip(deal.store, 28)}</span>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: px(14), marginTop: "auto", fontSize: px(36), color: "#3f3f46" }}>
            {logo && <img src={logo} alt="" width={px(52)} height={px(52)} />}
            <span>{siteName}</span>
            <span style={{ marginLeft: "auto", fontSize: px(30), color: "#a1a1aa" }}>
              {deal.hearts} {deal.hearts === 1 ? "heart" : "hearts"}
            </span>
          </div>
        </div>
      </div>
    ),
    size
  );
}
