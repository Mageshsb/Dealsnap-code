import type { Metadata } from "next";
import Link from "next/link";
import Icon from "@/components/Icon";
import { notFound } from "next/navigation";
import { getVisibleDeal } from "@/lib/deal-access";
import { findUserById, getCodeVerdicts, getDealCheckedAt, getDealEventPicks, getLiveEvents, getMyCodeReport, getUserDealBySlug, getUserStats } from "@/lib/db";
import { timeAgo } from "@/lib/format";
import { isUpcoming } from "@/lib/upcoming";
import LabelTrail from "@/components/LabelTrail";
import { inEvent, openEvents } from "@/lib/events";
import { tierOf } from "@/components/RoleBadge";
import { getCurrentUser } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { editBack, editFrom } from "@/lib/deal-edit-from";
import type { CommentSort } from "@/lib/db";
import BackLink from "@/components/BackLink";
import DealDetail from "@/components/DealDetail";
import { isExpired } from "@/lib/format";
import { dealPriceTag, priceTagText } from "@/lib/deal-kinds";
import JsonLd from "@/components/JsonLd";
import { breadcrumbStructuredData, dealStructuredData } from "@/lib/structured-data";
import { labelTrail } from "@/components/LabelTrail";
import { getSiteUrl } from "@/lib/site-url";
import { getDealSponsor, getPageAds } from "@/lib/ad-serving";
import { RAIL_SLOTS } from "@/lib/ads";
import { getTagByName } from "@/lib/categories";
import { slugify } from "@/lib/slug";
import { AdsProvider } from "@/components/AdUnit";
import AdRails from "@/components/AdRails";
import { AdTag } from "@/components/AdTag";
import { plainDescription } from "@/lib/deal-text";

// Each deal gets its own title and description for Google and for link
// previews (WhatsApp, Facebook, X…); the preview picture is opengraph-image.tsx.
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const deal = await getVisibleDeal((await params).slug);
  if (!deal) return {};
  // "£219.00 (42% off)", "from £25.00pp", or the offer: "Up to 70% off", "Free".
  const tag = dealPriceTag(deal);
  const price = priceTagText(tag);
  const expired = isExpired(deal.expiresAt);
  // Search results show about 60 characters, so a long title is clipped and the price and store stay.
  const name = deal.title.length > 55 ? `${deal.title.slice(0, 54).trimEnd()}…` : deal.title;
  const title = `${name} – ${price}${tag.off ? ` (${tag.off}% off)` : ""} at ${deal.store}${expired ? " [expired]" : ""}`;
  const summary = `${price}${tag.was ? `, ${tag.wasRrp ? "RRP" : "was"} ${tag.was}` : ""} at ${deal.store}. ${plainDescription(deal.description)}`;
  const description = summary.length > 160 ? `${summary.slice(0, 157).trimEnd()}…` : summary;
  return {
    title,
    description,
    alternates: { canonical: `/deals/${deal.slug}` },
    openGraph: { title, description, url: `/deals/${deal.slug}` },
    twitter: { card: "summary_large_image", title, description },
    // Not-yet-approved deals stay out of search results.
    robots: deal.status === "pending" ? { index: false } : undefined,
  };
}

export default async function DealPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ commentSort?: string; posted?: string; edited?: string; from?: string; hq?: string }>;
}) {
  const { slug } = await params;
  const deal = await getVisibleDeal(slug);

  if (!deal) {
    // The person who posted a removed deal sees why, instead of a dead link.
    const own = getUserDealBySlug(slug);
    const viewer = own?.status === "removed" ? await getCurrentUser() : null;
    if (own && viewer && own.postedByUserId === viewer.id) {
      return (
        <main className="mx-auto flex w-full max-w-2xl flex-1 flex-col gap-4 px-4 py-6">
          <h1 className="text-lg font-bold leading-snug sm:text-xl">{own.title}</h1>
          <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-900 dark:border-red-900 dark:bg-red-950/30 dark:text-red-200">
            <p className="font-semibold">This deal was removed by the DealSnap team, so only you can see this page.</p>
            {own.moderationReason && (
              <p className="mt-2">
                <span className="font-medium">Reason:</span> {own.moderationReason}
                {own.moderationNote ? ` (${own.moderationNote})` : ""}
              </p>
            )}
            <p className="mt-2">
              Check the{" "}
              <Link href="/guidelines" className="font-medium underline">
                community guidelines
              </Link>{" "}
              before posting again. If you think this was a mistake, please{" "}
              <Link href="/contact" className="font-medium underline">
                contact us
              </Link>
              .
            </p>
          </div>
          <BackLink href="/profile" exact>
            Back to your profile
          </BackLink>
        </main>
      );
    }
    notFound();
  }

  const { commentSort: commentSortParam, posted, edited, from: fromParam, hq } = await searchParams;
  // Opened (or saved) from the helper desk or admin list: "Back" says so and
  // returns to that list's same view, not "to deals".
  const from = editFrom(fromParam);
  const fromUser = from ? await getCurrentUser() : null;
  const backTo = from && fromUser && can(fromUser.role, from === "helper" ? "deals.fix" : "deals.review") ? editBack(from, hq) : undefined;
  const commentSort: CommentSort =
    commentSortParam === "new" || commentSortParam === "liked" ? commentSortParam : "old";
  // The poster's numbers for the About panel are worked out for this one
  // poster only; cards don't pay for them. Demo posters have no account, and
  // closed accounts show nothing.
  const poster = deal.postedByUserId ? findUserById(deal.postedByUserId) : undefined;
  const posterTier = tierOf(deal.postedByRole);
  const posterStats = poster && !poster.deletedAt ? getUserStats(poster.id) : undefined;
  const posterInfo = poster && posterStats && {
    username: poster.username,
    avatarUrl: poster.avatarUrl,
    joinedAt: poster.createdAt,
    dealCount: posterStats.dealCount,
    heartsReceived: posterStats.heartsReceived,
  };

  // Trust: when a helper or the team last looked it over, and what members
  // say about its code (two small lookups for this one deal).
  const checkedAt = getDealCheckedAt(deal.slug);
  const viewer = deal.voucherCode ? (fromUser ?? (await getCurrentUser())) : null;
  const verdict = deal.voucherCode ? getCodeVerdicts([{ slug: deal.slug, code: deal.voucherCode }]).get(deal.slug) : undefined;
  // (Not before an upcoming deal starts: nobody can try its code yet.)
  const codeTrust = deal.voucherCode && !isUpcoming(deal)
    ? {
        slug: deal.slug,
        initial: verdict ?? { worked: 0, failed: 0, recentWorked: 0, recentFailed: 0 },
        lastWorked: verdict?.lastWorkedAt ? timeAgo(verdict.lastWorkedAt) : undefined,
        mine: viewer ? getMyCodeReport(deal.slug, viewer.id, deal.voucherCode) : undefined,
        canAnswer: !!viewer && !viewer.suspended && viewer.id !== deal.postedByUserId && (deal.status ?? "live") === "live",
        signedIn: !!viewer,
        checkedAt,
      }
    : undefined;

  const eventPicks = getDealEventPicks(deal.slug);
  const events = openEvents(getLiveEvents())
    .filter((e) => inEvent(e, `${deal.title} ${plainDescription(deal.description)}`, eventPicks.get(e.slug)))
    .map(({ slug, name, icon }) => ({ slug, name, icon }));

  // Admin → Ads: aimed by the deal's store, category, tag and brand (none
  // while it's waiting to be checked).
  const labelInfo = getTagByName(deal.tag);
  const ads =
    deal.status === "pending"
      ? undefined
      : await getPageAds(
          {
            kind: "deal",
            path: `/deals/${deal.slug}`,
            labels: {
              store: slugify(deal.store),
              category: labelInfo || deal.category ? slugify(labelInfo?.category.name ?? deal.category) : undefined,
              tag: labelInfo ? slugify(labelInfo.tag.name) : undefined,
              brand: deal.brand ? slugify(deal.brand) : undefined,
            },
          },
          ["deal", "deal-end", ...RAIL_SLOTS],
          { description: deal.description.length, comments: deal.commentCount },
        );

  const sponsor = getDealSponsor(deal.slug);

  return (
    <AdsProvider ads={ads}>
      <main className="relative mx-auto flex w-full max-w-5xl flex-1 flex-col gap-6 px-4 py-6">
        <AdRails />
        {/* Straight after posting or editing, going "back" would mean the
            form, so it goes to the deals instead. The category trail shares the
            line (so it takes no height of its own); "to deals" is dropped on
            phones to leave it the room, and it never wraps. */}
        <div className="flex items-center justify-between gap-4">
          {posted || edited ? (
            <BackLink href={backTo?.href ?? "/"} exact className="shrink-0 whitespace-nowrap">
              Back<span className="max-sm:hidden"> to {backTo?.place ?? "deals"}</span>
            </BackLink>
          ) : (
            <BackLink href={backTo?.href ?? "/"} className="shrink-0 whitespace-nowrap">
              Back<span className="max-sm:hidden"> to {backTo?.place ?? "deals"}</span>
            </BackLink>
          )}
          <LabelTrail items={labelTrail(deal.category, deal.tag, deal.store)} />
        </div>

        {edited && (
          <p
            role="status"
            className="rounded-xl bg-green-50 px-4 py-3 text-sm text-green-800 dark:bg-green-950/40 dark:text-green-300"
          >
            <Icon name="check" className="mr-1.5" />
            Your changes are saved.
            {edited === "recheck" &&
              " As its link, store, photo, pictures or links changed, our team will check it again before it's back on the site."}
            {backTo && (
              <>
                {" "}
                <Link href={backTo.href} className="font-semibold underline">
                  {backTo.label}
                </Link>
              </>
            )}
          </p>
        )}

        {sponsor && (
          <div className="-mb-3 rounded-xl border border-zinc-200 bg-zinc-50 px-3 py-1.5 dark:border-zinc-800 dark:bg-zinc-900">
            <AdTag advertiser={`Sponsored by ${sponsor}`} />
          </div>
        )}

        <DealDetail
          deal={deal}
          posterTier={posterTier}
          posterInfo={posterInfo}
          events={events}
          commentSort={commentSort}
          checkedAgo={checkedAt ? timeAgo(checkedAt) : undefined}
          codeTrust={codeTrust}
        />
        {deal.status !== "pending" && <JsonLd data={dealStructuredData(deal, await getSiteUrl())} />}
        {deal.status !== "pending" && <JsonLd data={breadcrumbStructuredData(labelTrail(deal.category, deal.tag, deal.store), await getSiteUrl())} />}
      </main>
    </AdsProvider>
  );
}
