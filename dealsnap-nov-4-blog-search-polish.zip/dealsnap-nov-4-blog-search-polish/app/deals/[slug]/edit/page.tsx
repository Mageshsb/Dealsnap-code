import { notFound, redirect } from "next/navigation";
import { getVisibleBrands } from "@/lib/brands";
import BackLink from "@/components/BackLink";
import SubmitDealForm from "@/components/SubmitDealForm";
import WithdrawDealButton from "@/components/WithdrawDealButton";
import { getCurrentUser } from "@/lib/auth";
import { getDealEventPicks, getDealsBeingFixed, getLiveEvents, getUserDealBySlug, markDealFixing } from "@/lib/db";
import { seenNow } from "@/lib/collisions";
import { isoToLondonInput } from "@/lib/upcoming";
import { timeAgo } from "@/lib/format";
import Icon from "@/components/Icon";
import ClashNotice from "@/components/admin/ClashNotice";
import { eventChoices, inEvent, tickableEvents } from "@/lib/events";
import { canRedirectDeal, mayEditDeal } from "@/lib/permissions";
import { editBack, editFrom, editHq } from "@/lib/deal-edit-from";
import { getKnownStores, getStoreVariantMap } from "@/lib/mock-deals";
import { offerFieldsFromOffer, WHOLE_CATEGORY_PREFIX } from "@/lib/deal-kinds";
import type { DealDraft } from "@/lib/deal-draft";
import { missingTwoStep, TWO_STEP_NEEDED } from "@/lib/staff-two-step";
import { plainDescription } from "@/lib/deal-text";

export const metadata = { title: "Edit deal", robots: { index: false } };

// The person who posted a deal fixing or updating it, in the same form they
// posted it with. Helpers get the same form on other people's live deals.
export default async function EditOwnDealPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ error?: string; clash?: string; from?: string; hq?: string }>;
}) {
  const { slug } = await params;
  const { error, clash, from: fromParam, hq: hqParam } = await searchParams;
  const from = editFrom(fromParam);
  const hq = editHq(hqParam);
  const back = editBack(from, hq);
  const user = await getCurrentUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(`/deals/${slug}/edit`)}`);
  const deal = getUserDealBySlug(slug);
  const helping = !!deal && deal.postedByUserId !== user.id;
  if (!deal || !mayEditDeal(user, deal)) notFound();
  if (helping && missingTwoStep(user)) redirect(TWO_STEP_NEEDED);
  // Someone else already in here fixing it? Say so before any work is done.
  // A helper opening it marks it theirs for 15 minutes (cleared on save), so
  // the helper desk tells everyone else.
  const otherFixer = getDealsBeingFixed(user.id, slug).get(slug);
  if (helping) markDealFixing(slug, user.id);

  // Where the deal stands on the events on now: ticked, or its wording fits.
  const picks = getDealEventPicks(slug);
  const inEvents = tickableEvents(getLiveEvents())
    .filter((e) => inEvent(e, `${deal.title} ${plainDescription(deal.description)}`, picks.get(e.slug)))
    .map((e) => e.slug);

  const initial: DealDraft = {
    kind: deal.kind,
    offerFields: offerFieldsFromOffer(deal.kind, deal.offer),
    url: deal.url,
    title: deal.title,
    description: deal.description,
    price: deal.kind === "price" ? deal.price.toFixed(2) : "",
    originalPrice: deal.kind === "price" && deal.originalPrice > deal.price ? deal.originalPrice.toFixed(2) : "",
    wasRrp: deal.wasRrp,
    priceUnit: deal.priceUnit ?? "",
    priceFrom: deal.priceFrom,
    cashback: deal.cashback ? deal.cashback.toFixed(2) : "",
    conditions: deal.conditions ?? [],
    events: inEvents,
    store: deal.store,
    // A whole category goes to the picker as "category:Name"; no category
    // at all means it's for the whole store (lib/deal-kinds.ts).
    tag: deal.tag || (deal.category ? `${WHOLE_CATEGORY_PREFIX}${deal.category}` : ""),
    brand: deal.brand ?? "",
    scope: deal.category ? "products" : "store",
    expiresAt: deal.expiresAt?.slice(0, 10) ?? "",
    startsAt: deal.startsAt ? isoToLondonInput(deal.startsAt) : "",
    voucherCode: deal.voucherCode ?? "",
    whereToBuy: deal.whereToBuy,
    whereNote: deal.whereNote ?? "",
    delivery: deal.delivery,
    photo: deal.image,
  };

  return (
    <main className="mx-auto flex w-full max-w-lg flex-1 flex-col gap-6 px-4 py-6 lg:max-w-4xl">
      <BackLink href={back ? back.href : `/deals/${slug}`}>{back ? back.label : "Back to the deal"}</BackLink>

      <div>
        <h1 className="text-xl font-bold sm:text-2xl">{helping ? "Fix this deal" : "Edit your deal"}</h1>
        <p className="mt-1 text-sm text-zinc-500">
          {helping
            ? "Correct a mistake or update the details. Your changes are logged for the team."
            : "Fix a mistake, or update the price if it's changed."}
        </p>
      </div>

      <ClashNotice message={clash} />

      {otherFixer && !error && !clash && (
        <p role="status" className="flex gap-2 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-200">
          <Icon name="users" className="mt-0.5 size-4 shrink-0" />
          <span>
            <b>{otherFixer.username}</b> opened this to fix it {timeAgo(otherFixer.at)}. If you both save, the second save is stopped so
            nothing is lost, but it may be quicker to leave this one to them.
          </span>
        </p>
      )}

      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </p>
      )}

      <SubmitDealForm
        knownStores={getKnownStores()}
        brands={getVisibleBrands().map((b) => b.name)}
        storeVariants={getStoreVariantMap()}
        initial={initial}
        eventChoices={eventChoices(getLiveEvents())}
        editing={{ slug, live: deal.status === "live", helping, locked: helping && !canRedirectDeal(user), from, hq, backHref: back?.href, seen: seenNow() }}
      />

      {deal.status === "pending" && <WithdrawDealButton slug={slug} />}
    </main>
  );
}
