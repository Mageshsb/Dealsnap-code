import { permanentRedirect } from "next/navigation";

// /deals is the parent of every deal's address (/deals/<slug>), so someone
// trimming one lands here. The home page is the deals list.
export default function DealsIndex() {
  permanentRedirect("/");
}
