import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import { notFound } from "next/navigation";
import Icon, { type IconName } from "@/components/Icon";
import DealCard from "@/components/DealCard";
import { AdBox, AdRow, AdStrip } from "@/components/AdCreative";
import { getAdSettings } from "@/lib/ad-serving";
import { getAudienceNumbers } from "@/lib/db";
import { sampleSponsoredDeal } from "@/lib/kit-sample";
import { AD_PAGE_KINDS, AD_SLOTS, type AdCreative, type AdSlotId } from "@/lib/ads";

// "Advertise with us": what DealSnap offers advertisers, for sending to a
// store or brand, and for them to find. Only there while it's switched on in
// Admin → Ads → Advertise page; it lists only the ad spaces that are on, so it
// never offers something the site doesn't have.
export async function generateMetadata(): Promise<Metadata> {
  return {
    title: "Advertise with us",
    description: "Reach UK shoppers on DealSnap while they're choosing what to buy: sponsored deals and ads in the site's own style, clearly labelled, with no tracking.",
    robots: getAdSettings().page.on ? undefined : { index: false },
  };
}

// The sample everyone's formats are shown with.
const SAMPLE: AdCreative = {
  id: "sample",
  advertiser: "Your brand",
  headline: "Your offer, in your words",
  body: "A line about it, and a picture or your logo",
  ctaLabel: "Shop now",
  internal: true,
};

// Round numbers read better and say enough ("12,000+").
function round(n: number): string {
  if (n < 100) return String(n);
  const step = n < 1000 ? 50 : n < 10_000 ? 500 : n < 100_000 ? 1000 : 10_000;
  return `${(Math.floor(n / step) * step).toLocaleString("en-GB")}+`;
}

const WHY: { icon: IconName; title: string; body: string }[] = [
  { icon: "shopping-cart", title: "Shoppers ready to buy", body: "People come to DealSnap to spend: they're comparing prices and looking for a reason to choose." },
  { icon: "badge-check", title: "Clearly labelled", body: "Every ad says “Ad” and who it's from, so shoppers trust what they see, and trust you." },
  { icon: "lock", title: "No tracking", body: "Ads are chosen for the page, never the person: no cookies, no profiles, nothing to consent to." },
  { icon: "target", title: "In the right place", body: "Show on your own store's page and deals, a category, a brand, or a buying guide." },
  { icon: "eye", title: "Only real views counted", body: "A view counts when half the ad is on screen for a second. Bots and our own team never count." },
  { icon: "chart-line", title: "A live report", body: "Your own private link to your numbers, up to the minute, with a spreadsheet to download." },
];

// The short page shown while the full one is off (Admin → Ads → Selling): who
// to contact and the plain facts about the site, so a store that follows a link
// here lands on something useful instead of an error.
function HoldingPage({ intro }: { intro: string }) {
  return (
    <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col gap-6 px-4 py-10">
      <section className="flex flex-col items-start gap-4 rounded-2xl bg-zinc-900 p-6 text-white sm:p-10 dark:bg-zinc-800">
        <p className="text-xs font-semibold uppercase tracking-wide text-orange-300">Advertise with us</p>
        <h1 className="text-3xl font-bold text-balance sm:text-4xl">Looking to advertise?</h1>
        <p className="whitespace-pre-line text-zinc-300">
          {intro || "Please get in touch and tell us a little about your business. We'll come back to you with what's available."}
        </p>
        <Link href="/contact?topic=advertising" className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600">
          Get in touch
        </Link>
      </section>
      <ul className="flex flex-col gap-3 text-sm text-zinc-700 dark:text-zinc-300">
        <li>
          <strong className="font-semibold">About DealSnap:</strong> a UK community where shoppers share and check the best deals.
        </li>
        <li>
          <strong className="font-semibold">How ads work:</strong> every ad is labelled “Ad” and shown for the page, never the person: no cookies and no tracking.
        </li>
      </ul>
    </main>
  );
}

export default function AdvertisePage() {
  const settings = getAdSettings();
  if (!settings.page.on && !settings.page.holding) notFound();
  if (!settings.page.on) return <HoldingPage intro={settings.page.intro} />;

  // The spaces on offer: switched on, on at least one kind of page that's on.
  const on = (id: AdSlotId) => {
    const def = AD_SLOTS.find((d) => d.id === id)!;
    return settings.slots[id].enabled && def.pages.some((p) => !settings.offPages.includes(p));
  };
  const sampleDeal = on("sponsored") ? sampleSponsoredDeal() : undefined;
  const numbers = settings.page.stats ? getAudienceNumbers() : undefined;
  const stats = numbers
    ? ([
        ["Members", numbers.members],
        ["Deals shared, last 30 days", numbers.deals30],
        ["Taps through to stores, last 30 days", numbers.taps30],
        ["Ads seen, last 30 days", numbers.adViews30],
      ] as [string, number][]).filter(([, n]) => n > 0)
    : [];
  const pages = AD_PAGE_KINDS.filter((k) => !settings.offPages.includes(k.value)).map((k) => k.label.toLowerCase());
  const contact = "/contact?topic=advertising";

  const formats: { id: AdSlotId; title: string; body: string; sample: ReactNode }[] = [
    {
      id: "sponsored",
      title: "Sponsored deals",
      body: "One of your deals on DealSnap, placed among the others in the deal lists and Cards view, with “Ad · Sponsored by you”. Members can still heart, save and comment on it. Never the first deal in a list: that's always earned.",
      sample: sampleDeal && <DealCard deal={sampleDeal} sponsoredBy="Your brand" />,
    },
    { id: "list", title: "In the deal lists", body: "Your ad between the deals, the same size as a deal, on the Home page, searches and store, category, tag and brand pages.", sample: <AdRow ad={SAMPLE} /> },
    { id: "deal", title: "On deal pages", body: "Under a deal's details, or after its comments, where shoppers decide.", sample: <AdStrip ad={SAMPLE} /> },
    { id: "blog", title: "In buying guides", body: "Within and after our articles, alongside readers deciding what to buy.", sample: <AdStrip ad={SAMPLE} /> },
    { id: "community-list", title: "In the Community", body: "Between conversations, and inside long discussions, where members ask for advice and compare what they've found.", sample: <AdStrip ad={SAMPLE} /> },
    {
      id: "sidebar",
      title: "Beside the lists, on laptops",
      body: "Under the Filters, staying in view as people scroll; and on wide screens, a column either side of the page.",
      sample: (
        <div className="w-[240px] max-w-full">
          <AdBox ad={SAMPLE} />
        </div>
      ),
    },
  ];
  const offered = formats.filter((f) => on(f.id) || (f.id === "deal" && on("deal-end")) || (f.id === "blog" && on("blog-end")) || (f.id === "community-list" && (on("community-thread") || on("community-end"))) || (f.id === "sidebar" && (on("rail-left") || on("rail-right"))));

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-10 px-4 py-6">
      <section className="flex flex-col items-start gap-4 rounded-2xl bg-zinc-900 p-6 text-white sm:p-10 dark:bg-zinc-800">
        <p className="text-xs font-semibold uppercase tracking-wide text-orange-300">Advertise with us</p>
        <h1 className="max-w-2xl text-3xl font-bold text-balance sm:text-4xl">Reach UK shoppers while they&apos;re choosing what to buy</h1>
        <p className="max-w-2xl whitespace-pre-line text-zinc-300">
          {settings.page.intro ||
            "DealSnap is where UK shoppers share and check the best deals. Put your offer in front of them, in the site's own style, clearly labelled and without tracking anyone."}
        </p>
        <Link href={contact} className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600">
          Get in touch
        </Link>
      </section>

      {stats.length > 0 && (
        <dl className={`grid grid-cols-2 gap-3 ${stats.length > 2 ? "sm:grid-cols-4" : ""}`}>
          {stats.map(([k, n]) => (
            <div key={k} className="rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
              <dd className="text-2xl font-bold tabular-nums">{round(n)}</dd>
              <dt className="text-sm text-zinc-500">{k}</dt>
            </div>
          ))}
        </dl>
      )}

      <section className="flex flex-col gap-4">
        <h2 className="text-2xl font-bold">Ways to advertise</h2>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {offered.map((f) => (
            <article key={f.id} className="flex flex-col gap-3 rounded-2xl border border-zinc-200 bg-zinc-50 p-4 dark:border-zinc-800 dark:bg-zinc-950">
              <div>
                <h3 className="font-semibold">{f.title}</h3>
                <p className="text-sm text-zinc-600 dark:text-zinc-400">{f.body}</p>
              </div>
              {f.sample && <div aria-hidden className="pointer-events-none select-none">{f.sample}</div>}
            </article>
          ))}
        </div>
        <p className="text-sm text-zinc-500">
          You send your words and a picture or logo; we build the ad in DealSnap&apos;s style and show you before it goes
          live. Ads can run on {pages.join(", ")}, for a set number of views or a fixed period, aimed at your own store,
          a category, a brand or an article.
        </p>
      </section>

      <section className="flex flex-col gap-4">
        <h2 className="text-2xl font-bold">Why DealSnap</h2>
        <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {WHY.map((w) => (
            <li key={w.title} className="flex gap-3 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
              <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400">
                <Icon name={w.icon} className="size-5" />
              </span>
              <span className="flex flex-col gap-0.5">
                <span className="font-semibold">{w.title}</span>
                <span className="text-sm text-zinc-600 dark:text-zinc-400">{w.body}</span>
              </span>
            </li>
          ))}
        </ul>
      </section>

      <section className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="flex flex-col gap-3">
          <h2 className="text-2xl font-bold">How it works</h2>
          <ol className="flex flex-col gap-3">
            {[
              ["Tell us what you'd like", "What you're promoting, where, when, and roughly your budget."],
              ["See it before it runs", "We build the ad or pick your deal, and send you a preview to approve."],
              ["Watch it live", "It runs to the dates and views agreed, and your private report link shows every view and click."],
            ].map(([t, b], i) => (
              <li key={t} className="flex gap-3">
                <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-zinc-900 text-sm font-bold text-white dark:bg-zinc-100 dark:text-zinc-900">
                  {i + 1}
                </span>
                <span className="flex flex-col">
                  <span className="font-semibold">{t}</span>
                  <span className="text-sm text-zinc-600 dark:text-zinc-400">{b}</span>
                </span>
              </li>
            ))}
          </ol>
        </div>
        <div className="flex flex-col gap-3">
          <h2 className="text-2xl font-bold">{settings.page.rates ? "Rates" : "What we don't take"}</h2>
          {settings.page.rates && <p className="whitespace-pre-line text-zinc-700 dark:text-zinc-300">{settings.page.rates}</p>}
          <p className="text-sm text-zinc-600 dark:text-zinc-400">
            {settings.page.rates && <strong className="font-semibold text-zinc-800 dark:text-zinc-200">What we don&apos;t take: </strong>}
            Gambling, alcohol, tobacco and vapes, medicines and weight loss, or “less healthy” food and drink (UK law), and
            anything misleading. Paying for an ad never changes how members&apos; deals are ranked.
          </p>
        </div>
      </section>

      <section className="flex flex-col items-center gap-3 rounded-2xl border border-zinc-200 bg-white p-6 text-center dark:border-zinc-800 dark:bg-zinc-900">
        <h2 className="text-xl font-bold">Let&apos;s talk</h2>
        <p className="max-w-md text-sm text-zinc-600 dark:text-zinc-400">Tell us about your brand and what you have in mind. We&apos;ll reply with options and prices.</p>
        <Link href={contact} className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600">
          Get in touch
        </Link>
      </section>
    </main>
  );
}
