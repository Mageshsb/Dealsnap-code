import { notFound } from "next/navigation";
import SitePageView from "@/components/SitePageView";
import { getSitePage, pageMetadata } from "@/lib/site-pages";

// Written in Admin → Pages (the starting text is in lib/page-defaults.ts).
export function generateMetadata() {
  return pageMetadata("terms");
}

export default function TermsPage() {
  const page = getSitePage("terms");
  if (!page) notFound();
  return <SitePageView page={page} />;
}
