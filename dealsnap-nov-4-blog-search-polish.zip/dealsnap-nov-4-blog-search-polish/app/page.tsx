import type { Metadata } from "next";
import CategoryPills from "@/components/CategoryPills";
import JsonLd from "@/components/JsonLd";
import { siteStructuredData } from "@/lib/structured-data";
import { getShownLinks } from "@/lib/social-links";
import { getSiteName, getSiteUrl } from "@/lib/site-url";
import { getSiteSettings } from "@/lib/site-settings";
import CategorySwitcher from "@/components/CategorySwitcher";
import SidebarBoxes from "@/components/SidebarBoxes";
import BrowseExperience from "@/components/BrowseExperience";
import SwipeHeader from "@/components/SwipeHeader";
import SortAndFilters from "@/components/SortAndFilters";
import Link from "next/link";
import { searchDeals, searchCorrection, getDealsForView, getAllDeals } from "@/lib/mock-deals";
import { parseView, parseLovedWindow, parseSearchSort, lovedDivider, DEFAULT_VIEW, DEFAULT_LOVED_WINDOW } from "@/lib/deal-views";
import { parseMinHearts, parseDealType, narrowDeals, narrowQuery, typeFacet } from "@/lib/deal-filters";
import { PAGE_SIZE } from "@/lib/pagination";
import { getCurrentUser } from "@/lib/auth";
import JoinPill from "@/components/JoinPill";
import SearchCount from "@/components/SearchCount";
import { isExpired } from "@/lib/format";
import { capSearch } from "@/lib/search-limits";
import EmptyState from "@/components/EmptyState";
import { getListPromos } from "@/lib/promo-site";
import { getListAds } from "@/lib/ad-serving";
import { brandLogoPath } from "@/lib/site-brand";

// One main address for the home page, so filtered and sorted copies
// (?view=new, ?hearts=100) don't compete with it in Google. Search results
// pages aren't worth indexing at all.
export async function generateMetadata({ searchParams }: { searchParams: Promise<{ q?: string }> }): Promise<Metadata> {
  const q = capSearch((await searchParams).q);
  return {
    // The search in the tab and the browser's history ("Search: air fryer |
    // DealSnap"). In full: the layout's "| DealSnap" ending is only added to
    // pages below it, and this is its own page.
    ...(q && { title: { absolute: `Search: ${q} | ${getSiteName()}` } }),
    alternates: { canonical: "/" },
    robots: q ? { index: false, follow: true } : undefined,
  };
}

export default async function Home({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; view?: string; hearts?: string; when?: string; type?: string }>;
}) {
  const { q: rawQuery, view: viewParam, hearts, when: whenParam, type: typeParam } = await searchParams;
  const q = capSearch(rawQuery);
  const minHearts = parseMinHearts(hearts);
  // Search results have their own sort (Best match by default, then Most loved
  // and New with no time window); the browse list has Most loved / New.
  const view = parseView(viewParam);
  const when = parseLovedWindow(whenParam);
  const sort = parseSearchSort(viewParam);
  const type = parseDealType(typeParam);
  const filterQuery = narrowQuery("", "", type);
  const listed = q ? searchDeals(q, undefined, undefined, undefined, minHearts, sort) : getDealsForView(view, undefined, undefined, undefined, minHearts, when);
  const facets = [typeFacet(listed)];
  const deals = narrowDeals(listed, "", "", type);
  const firstPage = deals.slice(0, PAGE_SIZE);
  const hasMore = deals.length > firstPage.length;
  // Search lists live deals first; the expired matches after them are hidden
  // unless "Show expired" is ticked, so the count and the list say so.
  const expiredCount = q ? deals.filter((d) => isExpired(d.expiresAt)).length : 0;
  // Logged-out visitors get a "Join free" button where other pages have "Get alerts".
  const showJoin = !q && !(await getCurrentUser());

  // Most loved/New and the Filters pill above the card in the Scroll view
  // (stepped down a size on short screens, so the card keeps its room).
  const controls = <SortAndFilters active={q ? sort : view} when={when} minHearts={minHearts} filterQuery={filterQuery} facets={facets} searchQuery={q} />;
  // The List view's own row under the title, which also comes back under
  // the category strip when scrolling up from halfway down the list.
  const listRow = <SortAndFilters active={q ? sort : view} when={when} minHearts={minHearts} filterQuery={filterQuery} facets={facets} searchQuery={q} inList />;
  return (
    <>
    {!q && <JsonLd data={siteStructuredData(await getSiteUrl(), getSiteName(), getSiteSettings().siteDescription, getShownLinks().social.map((l) => l.url), brandLogoPath())} />}
    <BrowseExperience
      promos={await getListPromos({ kind: q ? "search" : "home" })}
      ads={await getListAds({ kind: q ? "search" : "home" })}
      controls={listRow}
      resetKey={`${q ?? ""}|${q ? sort : view}|${when}|${minHearts}|${filterQuery}`}
      minHearts={minHearts || undefined}
      filterQuery={filterQuery || undefined}
      view={q ? (sort !== "best" ? sort : undefined) : view !== DEFAULT_VIEW ? view : undefined}
      when={!q && view === "hottest" && when !== DEFAULT_LOVED_WINDOW ? when : undefined}
      divider={q ? undefined : lovedDivider(view, when)}
      initialDeals={firstPage}
      initialHasMore={hasMore}
      isEmpty={deals.length === 0}
      query={q}
      expiredCount={expiredCount}
      heading={
        <div key="heading">
          {q ? (
            <>
              {/* The count runs on from the title like a sentence, where other
                  pages have their buttons, so the sort chips land in the same
                  place as there. A long search carries on onto the next line
                  rather than being cut short. */}
              <div className="min-h-8 pt-0.5 sm:pt-0">
                <h1 className="inline text-xl font-bold sm:text-2xl">Search results</h1>
                <SearchCount total={deals.length} expired={expiredCount} query={searchCorrection(q) ?? q} />
              </div>
              <div className="mt-3">
                {listRow}
              </div>
            </>
          ) : (
            <>
              {/* The same title row as category, tag and store pages (fixed
                  height, button on the right), so moving between them
                  doesn't make the deals jump. */}
              <div className="flex h-8 items-center gap-3">
                <h1 className="flex min-w-0 items-center gap-2 text-xl font-bold sm:text-2xl">
                  <span className="min-w-0 truncate">All deals</span>
                  <span className="sr-only"> · deals, discounts and voucher codes, rated by shoppers</span>
                </h1>
                {showJoin && <JoinPill />}
              </div>
              <div className="mt-3">
                {listRow}
              </div>
            </>
          )}
        </div>
      }
      listFilterBar={
        <CategoryPills
          key="list-filter-bar"
          leading={<CategorySwitcher activeSlug="all" />}
        />
      }
      swipeLabel={
        <SwipeHeader
          key="swipe-label"
          controls={controls}
          title={
            q ? (
              <>
                Search results
              </>
            ) : (
              <>
                <span className="min-w-0 truncate">All deals</span>
                {showJoin && <JoinPill className="px-2.5 py-1 text-xs font-semibold" />}
              </>
            )
          }
        />
      }
      sidebar={
        // (The Filters box sticks beside the list itself; see SidebarBoxes.)
        <SidebarBoxes key="sidebar" facets={facets} />
      }
      emptyState={
        !q && getAllDeals().length === 0 ? (
          // A brand-new site, before anyone has posted: invite the first one.
          <EmptyState key="empty-state" icon="tag">
            <p className="font-medium text-zinc-700 dark:text-zinc-200">No deals yet.</p>
            <p>Found a bargain? Be the first to share it.</p>
            <Link href="/submit" className="mt-1 rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
              Post a deal
            </Link>
          </EmptyState>
        ) : (
          <EmptyState key="empty-state" icon="search">
            <p>No deals found. Try another search or category.</p>
          </EmptyState>
        )
      }
    />
    </>
  );
}
