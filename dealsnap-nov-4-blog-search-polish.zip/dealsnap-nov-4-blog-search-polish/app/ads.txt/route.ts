import { getSiteSetting } from "@/lib/db";

// /ads.txt: the companies allowed to sell DealSnap's ad space (Admin → Ads →
// Ad network). Ad buyers check it before they pay for a space, so ad networks
// ask for their line to be added. Every line was checked when it was saved.
export async function GET() {
  const text = getSiteSetting("ads_txt") ?? "";
  return new Response(text ? `${text}\n` : "# No ad partners yet.\n", {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "public, max-age=3600",
    },
  });
}
