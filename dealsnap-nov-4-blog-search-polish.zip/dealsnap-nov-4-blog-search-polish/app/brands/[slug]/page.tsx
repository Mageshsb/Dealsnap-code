import type { Metadata } from "next";
import { notFound } from "next/navigation";
import SidebarBoxes from "@/components/SidebarBoxes";
import BrowseExperience from "@/components/BrowseExperience";
import SwipeHeader from "@/components/SwipeHeader";
import SortAndFilters from "@/components/SortAndFilters";
import AlertButton from "@/components/AlertButton";
import TagPills from "@/components/TagPills";
import CategorySwitcher from "@/components/CategorySwitcher";
import BrandLogo from "@/components/BrandLogo";
import { getCurrentUser } from "@/lib/auth";
import { hasBrandAlert } from "@/lib/db";
import { getBrandBySlug } from "@/lib/brands";
import { allTags } from "@/lib/categories";
import { parseView, parseLovedWindow, lovedDivider, DEFAULT_VIEW, DEFAULT_LOVED_WINDOW } from "@/lib/deal-views";
import { parseMinHearts, parseSlug, parseDealType, narrowDeals, narrowQuery, typeFacet, type Facet } from "@/lib/deal-filters";
import { BRAND_TILE_DEALS, getBarTags, getBrandCounts, getCategoryFacet, getDealsForView, getStoreFacet, getStores } from "@/lib/mock-deals";
import { PAGE_SIZE } from "@/lib/pagination";
import InfoToggle from "@/components/InfoToggle";
import InfoSheetButton from "@/components/InfoSheetButton";
import { BrandPanel } from "@/components/InfoPanels";
import EmptyState from "@/components/EmptyState";
import JsonLd from "@/components/JsonLd";
import { breadcrumbStructuredData } from "@/lib/structured-data";
import { getSiteUrl } from "@/lib/site-url";
import { getListPromos } from "@/lib/promo-site";
import { getListAds } from "@/lib/ad-serving";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const brand = getBrandBySlug(slug);
  if (!brand) return {};
  // A brand with few deals isn't shown to search engines until it has enough
  // recent ones, so they never find a near-empty page.
  const busy = (getBrandCounts().get(slug)?.recent ?? 0) >= BRAND_TILE_DEALS;
  return {
    title: `${brand.name} deals`,
    description: `The latest ${brand.name} deals and discount codes from every store, found and rated by the DealSnap community.`,
    alternates: { canonical: `/brands/${slug}` },
    robots: busy ? undefined : { index: false, follow: true },
  };
}

export default async function BrandPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ view?: string; hearts?: string; when?: string; cat?: string; store?: string; type?: string }>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const view = parseView(sp.view);
  const when = parseLovedWindow(sp.when);
  const minHearts = parseMinHearts(sp.hearts);
  const cat = parseSlug(sp.cat);
  const store = parseSlug(sp.store);
  const type = parseDealType(sp.type);
  const brand = getBrandBySlug(slug);

  if (!brand) notFound();

  const basePath = `/brands/${slug}`;
  const user = await getCurrentUser();
  const alertOn = user ? hasBrandAlert(user.id, slug) : false;
  const catFacet: Facet = { param: "cat", options: getCategoryFacet({ brand: slug }, minHearts, cat) };
  const storeFacet: Facet = { param: "store", options: getStoreFacet({ brand: slug }, minHearts, store) };
  const filterQuery = narrowQuery(store, cat, type);
  const listed = narrowDeals(getDealsForView(view, undefined, undefined, undefined, minHearts, when, slug), store, cat);
  const facets = [catFacet, storeFacet, typeFacet(listed)];
  const deals = narrowDeals(listed, "", "", type);
  const firstPage = deals.slice(0, PAGE_SIZE);
  const hasMore = deals.length > firstPage.length;

  // The ⓘ panel: what the brand covers, where its deals come from, and the
  // brand's own shop if it has a store page here.
  const lines = allTags()
    .filter((t) => t.tag.maker === brand.name)
    .map((t) => t.tag.name);
  const stores = storeFacet.options.slice(0, 6).map((s) => ({ name: s.name, href: `/stores/${s.slug}` }));
  const own = getStores().find((s) => [slug, `${slug}-store`, `${slug}-uk`].includes(s.slug));
  const infoLabel = `About ${brand.name}`;
  const infoPanel = (
    <BrandPanel
      name={brand.name}
      categories={catFacet.options.slice(0, 2).map((c) => c.name)}
      lines={lines}
      stores={stores}
      ownStore={own ? { name: own.name, href: `/stores/${own.slug}` } : undefined}
    />
  );
  const title = (
    <>
      <BrandLogo name={brand.name} logoUrl={brand.logoUrl} className="h-6 w-6" />
      <span className="min-w-0 truncate sm:overflow-visible sm:whitespace-normal">{brand.name}</span>
    </>
  );
  // Most loved/New and the Filters pill above the card in the Scroll view
  // (stepped down a size on short screens, so the card keeps its room).
  const controls = <SortAndFilters active={view} when={when} minHearts={minHearts} filterQuery={filterQuery} facets={facets} basePath={basePath} />;
  // The List view's own row under the title, which also comes back under
  // the category strip when scrolling up from halfway down the list.
  const listRow = <SortAndFilters active={view} when={when} basePath={basePath} minHearts={minHearts} filterQuery={filterQuery} facets={facets} inList />;
  return (
    <>
    <BrowseExperience
      promos={await getListPromos({ kind: "brand", slug: slug })}
      ads={await getListAds({ kind: "brand", slug: slug })}
      controls={listRow}
      resetKey={`${slug}|${view}|${when}|${minHearts}|${filterQuery}`}
      minHearts={minHearts || undefined}
      filterQuery={filterQuery || undefined}
      view={view === DEFAULT_VIEW ? undefined : view}
      when={view === "hottest" && when !== DEFAULT_LOVED_WINDOW ? when : undefined}
      divider={lovedDivider(view, when)}
      initialDeals={firstPage}
      initialHasMore={hasMore}
      isEmpty={deals.length === 0}
      brand={slug}
      heading={
        <div key="heading">
          <InfoToggle label={infoLabel} panel={infoPanel}>
            <h1 className="flex min-w-0 items-center gap-2 text-xl font-bold sm:text-2xl">{title}</h1>
            <AlertButton kind="brand" target={slug} name={brand.name} nextPath={basePath} initialOn={alertOn} />
          </InfoToggle>
          <div className="mt-3">
            {listRow}
          </div>
        </div>
      }
      listFilterBar={
        // Brands › Nike, then what the brand has deals in.
        <TagPills
          key="list-filter-bar"
          tags={getBarTags({ brand: slug })}
          path={[{ name: "Brands", href: "/brands" }]}
          current={{ name: brand.name, href: basePath }}
          deselectHref="/"
          leading={<CategorySwitcher activeSlug="all" />}
          joined={false}
          divided
        />
      }
      swipeLabel={
        <SwipeHeader
          key="swipe-label"
          controls={controls}
          title={
            <>
              {title}
              <AlertButton kind="brand" target={slug} name={brand.name} nextPath={basePath} initialOn={alertOn} className="px-2.5 py-1 text-xs font-semibold" />
              <InfoSheetButton label={infoLabel} panel={infoPanel} className="px-2.5 py-1 text-xs font-semibold" />
            </>
          }
        />
      }
      sidebar={<SidebarBoxes key="sidebar" facets={facets} />}
      emptyState={
        <EmptyState key="empty-state" icon="search">
          <p>No {brand.name} deals right now.</p>
        </EmptyState>
      }
    />
    {/* The Brands › Nike trail above, for search results. */}
    <JsonLd data={breadcrumbStructuredData([{ name: "Home", href: "/" }, { name: "Brands", href: "/brands" }, { name: brand.name, href: basePath }], await getSiteUrl())} />
    </>
  );
}
