import BrandIndex from "@/components/BrandIndex";
import BrandLogo from "@/components/BrandLogo";
import BrowseTop from "@/components/BrowseTop";
import YourFollows from "@/components/YourFollows";
import { getCurrentUser } from "@/lib/auth";
import { getBrandAlerts } from "@/lib/db";
import { getVisibleBrands } from "@/lib/brands";
import { getBrandCounts, getNewThisWeekCounts } from "@/lib/mock-deals";
import { getCategoryGroups } from "@/lib/categories";
import { slugify } from "@/lib/slug";

export const metadata = {
  title: "Browse brands",
  alternates: { canonical: "/brands" },
  description: "Every brand on DealSnap, A to Z, with its live deals from every store.",
};

// Every brand with its logo and live deals (busiest first, or A–Z), with the
// brands this person has the bell on for at the top. Quiet brands are listed
// too (their pages can still alert you).
export default async function BrandsPage({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  // Drawn per visit, so the live-deal counts are current.
  await searchParams;
  const counts = getBrandCounts();
  const brands = getVisibleBrands().map((b) => ({
    name: b.name,
    slug: b.slug,
    logoUrl: b.logoUrl,
    count: counts.get(b.slug)?.live ?? 0,
    categories: counts.get(b.slug)?.categories ?? {},
  }));
  // Only categories some brand has live deals in, as on /stores.
  const categories = getCategoryGroups()
    .map((g) => ({ slug: slugify(g.name), name: g.name, icon: g.icon }))
    .filter((c) => brands.some((b) => b.categories[c.slug]));
  const user = await getCurrentUser();
  const followed = user ? new Set(getBrandAlerts(user.id)) : undefined;
  const fresh = followed?.size ? getNewThisWeekCounts().brands : {};
  const yours = brands
    .filter((b) => followed?.has(b.slug))
    .map((b) => ({ ...b, newCount: fresh[b.slug] ?? 0 }))
    .sort((a, b) => b.newCount - a.newCount || b.count - a.count || a.name.localeCompare(b.name))
    .slice(0, 12)
    .map((b) => ({
      key: b.slug,
      name: b.name,
      href: `/brands/${b.slug}`,
      leading: <BrandLogo name={b.name} logoUrl={b.logoUrl} className="h-9 w-9" />,
      liveCount: b.count,
      newCount: b.newCount,
    }));
  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-5 px-4 py-6">
      <BrowseTop show="brands">{brands.length} brands · deals from every store</BrowseTop>
      <YourFollows id="your-brands" title="Your brands" manageHref="/alerts#brands" items={yours} />
      <BrandIndex brands={brands} categories={categories} />
    </main>
  );
}
