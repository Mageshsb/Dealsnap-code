"use client";

import "./globals.css";

// The last resort, for when the whole site's frame fails to load (so the
// header and footer can't show either). Kept plain on purpose.
export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="en-GB">
      <body className="flex min-h-screen flex-col items-center justify-center gap-4 bg-zinc-50 px-4 text-center text-zinc-900 dark:bg-black dark:text-zinc-100">
        <h1 className="text-xl font-bold sm:text-2xl">Sorry, something went wrong</h1>
        <p className="max-w-sm text-sm text-zinc-500">DealSnap didn&apos;t load properly. Please try again in a moment.</p>
        <div className="flex gap-2">
          <button type="button" onClick={reset} className="rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
            Try again
          </button>
          {/* A full page load, as the app itself may be what failed. */}
          {/* eslint-disable-next-line @next/next/no-html-link-for-pages */}
          <a href="/" className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-medium dark:border-zinc-700">
            Home
          </a>
        </div>
      </body>
    </html>
  );
}
