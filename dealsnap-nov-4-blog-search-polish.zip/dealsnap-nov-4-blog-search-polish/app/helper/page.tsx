import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { can, isStaffRole } from "@/lib/permissions";
import { missingTwoStep, TWO_STEP_NEEDED } from "@/lib/staff-two-step";
import AccountShell from "@/components/AccountShell";
import HelperDesk, { type DeskParams } from "@/components/staff/HelperDesk";

export const metadata = { title: "Helper desk" };

// The helper desk in My account, for helpers. Moderators and admins have it
// inside the admin area, so they're sent there (with the same view, so links
// back from a deal and after each action land in the right place).
export default async function HelperDeskPage({ searchParams }: { searchParams: Promise<DeskParams> }) {
  const sp = await searchParams;
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/helper");
  if (!can(user.role, "deals.fix") || user.suspended) redirect("/");
  if (isStaffRole(user.role)) {
    const qs = new URLSearchParams(Object.entries(sp).filter((e): e is [string, string] => typeof e[1] === "string")).toString();
    redirect(qs ? `/admin/helper?${qs}` : "/admin/helper");
  }
  if (missingTwoStep(user)) redirect(TWO_STEP_NEEDED);

  return (
    <AccountShell user={user} active="/helper">
      <HelperDesk sp={sp} user={user} base="/helper" />
    </AccountShell>
  );
}
