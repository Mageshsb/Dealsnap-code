import { permanentRedirect } from "next/navigation";

// /tags is the parent of every tag's address (/tags/<slug>). The Categories
// page lists all the tags, so that's where this goes.
export default function TagsIndex() {
  permanentRedirect("/categories");
}
