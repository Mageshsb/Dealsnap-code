import Link from "next/link";
import InfoPage, { type InfoSection } from "@/components/InfoPage";
import Icon from "@/components/Icon";

export const metadata = {
  title: "Post from your iPhone",
  description: "Add DealSnap's free Shortcut, then post a deal from any app's Share button: Safari, Amazon, Argos and more.",
};

// iPhones don't let websites appear in the Share menu, so a Shortcut puts
// DealSnap there (made by scripts/build-shortcut.mjs). Android doesn't need
// one: the installed app is in its Share menu already (app/manifest.ts).
const sections: InfoSection[] = [
  {
    id: "add",
    title: "1. Add it (once)",
    body: (
      <>
        <a
          href="/shortcut/post-to-dealsnap.shortcut"
          className="flex min-h-11 items-center justify-center gap-2 self-start rounded-full bg-orange-500 px-5 text-sm font-semibold !text-white !no-underline hover:bg-orange-600"
        >
          <Icon name="plus" className="size-4" />
          Add the Shortcut
        </a>
        <p>
          Tap it on your iPhone, in Safari. Your iPhone opens the Shortcuts app: tap <strong>Add Shortcut</strong>.
        </p>
      </>
    ),
  },
  {
    id: "post",
    title: "2. Post a deal from anywhere",
    body: (
      <>
        <p>
          In Safari or a store&apos;s app, open the product, tap <strong>Share</strong>, then <strong>Post to DealSnap</strong>. DealSnap opens with the
          post form filling itself in from the link.
        </p>
        <p>
          The first time, your iPhone asks if the Shortcut can open DealSnap: choose <strong>Always Allow</strong>. Not in the Share menu? Scroll to
          the bottom of it, tap <strong>Edit Actions</strong> and add it to your favourites.
        </p>
      </>
    ),
  },
  {
    id: "privacy",
    title: "What it does",
    body: (
      <p>
        Only what you share: it takes the link and opens DealSnap&apos;s post form with it. Nothing else on your phone is read or sent. You can delete it
        any time in the Shortcuts app.
      </p>
    ),
  },
  {
    id: "android",
    title: "On Android?",
    body: (
      <p>
        No Shortcut needed. Add DealSnap to your home screen (in Chrome&apos;s menu, <strong>Add to Home screen</strong>) and it appears in the Share menu
        by itself. Or just <Link href="/submit">paste a link into the post form</Link>.
      </p>
    ),
  },
];

export default function IphonePage() {
  return (
    <InfoPage
      title="Post from your iPhone"
      intro="Spotted a deal in Safari or a store's app? Post it straight from the Share button, without copying links around."
      sections={sections}
      contents={false}
    />
  );
}
