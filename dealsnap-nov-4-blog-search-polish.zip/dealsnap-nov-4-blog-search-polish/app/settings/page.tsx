import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getBlockedIds, type UserRecord } from "@/lib/db";
import AccountShell, { AccountPageHeader } from "@/components/AccountShell";
import { SETTINGS_SECTIONS as SECTIONS, type SettingsKey } from "@/lib/account-links";
import YourDataPanel from "@/components/YourDataPanel";
import {
  ProfileSection,
  SecuritySection,
  NotificationsSection,
  BlockedSection,
} from "@/components/settings/SettingsSections";
import Icon from "@/components/Icon";

export const metadata = { title: "Settings" };

const card = "flex min-w-0 flex-col gap-5 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900 sm:p-6";

// A word beside a section in the phone list, when there's something worth knowing.
function sectionStatus(key: SettingsKey, user: UserRecord): string | undefined {
  if (key === "profile" && !user.avatarUrl) return "Add a photo";
  if (key === "security") return user.totpEnabled ? "Two-step on" : "Two-step off";
  if (key === "blocked") {
    const n = getBlockedIds(user.id).length;
    return n > 0 ? String(n) : undefined;
  }
  return undefined;
}

// Settings. Each section is its own page (/settings?s=…). On phones, plain
// /settings is the list of sections, like the My account page; on tablets
// and desktop the sections sit in the sidebar, so it opens on the first one.
export default async function SettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ s?: string; row?: string; error?: string; success?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/settings");
  const { s, row, error, success } = await searchParams;
  // Old section names (links in old emails, bookmarks…).
  const RENAMED: Record<string, string> = { privacy: "blocked", account: "security" };
  const key = (s && RENAMED[s]) ?? s;
  const chosen = SECTIONS.find((x) => x.key === key);
  const section = chosen ?? SECTIONS[0];

  const content = (
    <>
      <AccountPageHeader title={section.label} description={section.blurb} />
      <div className={card}>
        {error && !(section.key === "security" && (row === "email" || row === "password")) && (
          <p role="alert" className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
            {error}
          </p>
        )}
        {success && (
          <p role="status" className="flex items-center gap-1.5 rounded-lg bg-green-50 px-4 py-2 text-sm text-green-700 dark:bg-green-950/40 dark:text-green-400">
            <Icon name="circle-check" className="size-4" />
            {success}
          </p>
        )}
        {section.key === "profile" && <ProfileSection user={user} />}
        {section.key === "security" && <SecuritySection user={user} openRow={error ? row : undefined} error={error} />}
        {section.key === "notifications" && <NotificationsSection user={user} />}
        {section.key === "blocked" && <BlockedSection user={user} />}
        {section.key === "data" && <YourDataPanel />}
      </div>
    </>
  );

  if (chosen) {
    return (
      <AccountShell user={user} active="/settings" settingsSection={section.key} back={{ href: "/settings", label: "Settings" }}>
        {content}
      </AccountShell>
    );
  }

  return (
    <AccountShell user={user} active="/settings" settingsSection={section.key}>
      <div className="flex flex-col gap-5 md:hidden">
        <AccountPageHeader title="Settings" />
        <nav
          aria-label="Settings"
          className="flex flex-col divide-y divide-zinc-100 overflow-hidden rounded-xl border border-zinc-200 bg-white dark:divide-zinc-800 dark:border-zinc-800 dark:bg-zinc-900"
        >
          {SECTIONS.map((x) => {
            const status = sectionStatus(x.key, user);
            return (
              <Link key={x.key} href={`/settings?s=${x.key}`} className="flex min-h-14 items-center gap-3 px-4 hover:bg-zinc-50 dark:hover:bg-zinc-800/60">
                <Icon name={x.icon} className="size-5 shrink-0 text-zinc-500 dark:text-zinc-400" />
                <span className="flex-1">{x.label}</span>
                {status && <span className="shrink-0 text-sm text-zinc-500">{status}</span>}
                <Icon name="chevron-right" className="size-4 shrink-0 text-zinc-300 dark:text-zinc-600" />
              </Link>
            );
          })}
        </nav>
      </div>
      <div className="hidden min-w-0 flex-col gap-5 md:flex">{content}</div>
    </AccountShell>
  );
}
