import { getAffiliateProgrammes, getBlogRowBySlug } from "@/lib/db";
import { affiliateUrl } from "@/lib/affiliate";
import { countBlogClick, reader } from "@/lib/blog-stats";
import { LIMITS, overLimit } from "@/lib/rate-limit";
import { getSiteSettings } from "@/lib/site-settings";

// A "See the deal" button on a blog post's picks: counted for Admin → Blog,
// then on to the store through an affiliate link once those are set up
// (lib/affiliate.ts), the same as a deal's Get deal button. It only ever goes
// to a link an editor put on a pick of a live post, never to an address taken
// from the request, so it can't be used to bounce people to somewhere else.
export async function GET(request: Request, { params }: { params: Promise<{ slug: string; n: string }> }) {
  if (await overLimit("go", LIMITS.go)) {
    return new Response("Too many requests. Please try again in a minute.", { status: 429, headers: { "retry-after": "60" } });
  }
  const { slug, n } = await params;
  const post = getBlogRowBySlug(slug);
  const live = post && post.status === "published" && post.publishedAt <= new Date().toISOString();
  const pick = live && /^\d{1,2}$/.test(n) ? post.picks[Number(n)] : undefined;
  if (!post || !pick?.url || !/^https?:\/\//i.test(pick.url)) return Response.redirect(new URL(post && live ? `/blog/${post.slug}` : "/blog", request.url), 302);
  countBlogClick(post.id, await reader());
  return new Response(null, {
    status: 302,
    headers: { location: affiliateUrl(pick.url, getSiteSettings(), `blog-${post.slug}-${n}`, getAffiliateProgrammes()), "cache-control": "no-store" },
  });
}
