import type { Metadata } from "next";
import Link from "next/link";
import { resetPasswordAction } from "@/lib/actions";
import { getPasswordResetUser } from "@/lib/db";

export const metadata: Metadata = { title: "Choose a new password", robots: { index: false } };

export default async function ResetPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string; error?: string }>;
}) {
  const { token = "", error } = await searchParams;
  const user = token ? getPasswordResetUser(token) : undefined;

  return (
    <main className="mx-auto flex w-full max-w-sm flex-1 flex-col gap-6 px-4 py-6">
      <div className="text-center">
        <h1 className="text-xl font-bold sm:text-2xl">Choose a new password</h1>
        {user && <p className="text-sm text-zinc-500">For {user.username}</p>}
      </div>

      {!user ? (
        <div className="flex flex-col items-center gap-4 text-center">
          <p className="text-sm text-zinc-600 dark:text-zinc-400">
            This link has expired or was already used. Reset links work once, for an hour.
          </p>
          <Link href="/login/forgot" className="rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600">
            Send a new link
          </Link>
        </div>
      ) : (
        <>
          {error && (
            <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">{error}</p>
          )}
          <form action={resetPasswordAction} className="flex flex-col gap-4">
            <input type="hidden" name="token" value={token} />
            {/* Lets password managers save the new password against the right account. */}
            <input type="hidden" name="username" value={user.email} autoComplete="username" />
            <div className="flex flex-col gap-1">
              <label htmlFor="reset-password" className="text-sm font-medium">New password</label>
              <input
                id="reset-password"
                name="password"
                type="password"
                required
                minLength={8}
                autoFocus
                autoComplete="new-password"
                placeholder="At least 8 characters"
                className="rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-900"
              />
            </div>
            <button type="submit" className="rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600">
              Save new password
            </button>
            <p className="text-center text-xs text-zinc-500">You&apos;ll be logged out on your other devices.</p>
          </form>
        </>
      )}
    </main>
  );
}
