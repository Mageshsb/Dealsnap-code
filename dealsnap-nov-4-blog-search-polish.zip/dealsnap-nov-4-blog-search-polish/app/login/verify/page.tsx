import Link from "next/link";
import { verifyTwoStepAction } from "@/lib/actions";

export const metadata = { title: "Two-step login" };

export default async function VerifyLoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { error } = await searchParams;

  return (
    <main className="mx-auto flex w-full max-w-sm flex-1 flex-col gap-6 px-4 py-6">
      <div className="text-center">
        <h1 className="text-xl font-bold sm:text-2xl">Two-step login</h1>
        <p className="text-sm text-zinc-500">Enter the 6-digit code from your authenticator app.</p>
      </div>

      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">{error}</p>
      )}

      <form action={verifyTwoStepAction} className="flex flex-col gap-4">
        <input
          name="code"
          required
          autoFocus
          inputMode="numeric"
          autoComplete="one-time-code"
          placeholder="123 456"
          maxLength={12}
          aria-label="Code"
          className="rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-3 text-center font-mono text-xl tracking-[0.3em] outline-none focus:border-orange-500 dark:border-zinc-700 dark:bg-zinc-900"
        />
        <button type="submit" className="rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600">
          Continue
        </button>
      </form>

      <p className="text-center text-xs text-zinc-500">
        Lost your phone? Type one of your recovery codes instead (like ABCDE-12345).
        <br />
        <Link href="/login" className="mt-2 inline-block font-medium text-orange-700 dark:text-orange-400 hover:underline">
          Start again
        </Link>
      </p>
    </main>
  );
}
