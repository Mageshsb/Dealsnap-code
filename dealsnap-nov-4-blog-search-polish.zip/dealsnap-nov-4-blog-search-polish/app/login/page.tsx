import Link from "next/link";
import { loginAction } from "@/lib/actions";
import GoogleButton from "@/components/GoogleButton";

export const metadata = { title: "Log in" };

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; next?: string; suspended?: string; notice?: string }>;
}) {
  const { error, next, suspended, notice } = await searchParams;

  return (
    <main className="mx-auto flex w-full max-w-sm flex-1 flex-col gap-6 px-4 py-6">
      <div className="text-center">
        <h1 className="text-xl font-bold sm:text-2xl">Log in</h1>
        <p className="text-sm text-zinc-500">Welcome back to DealSnap.</p>
      </div>

      {notice && !error && (
        <p className="rounded-lg bg-green-50 px-4 py-2 text-sm text-green-700 dark:bg-green-950/40 dark:text-green-400">
          {notice}
        </p>
      )}

      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
          {error}
          {suspended && (
            <>
              {" "}
              <Link href="/contact?topic=appeal" className="font-semibold underline">
                Appeal this decision
              </Link>
            </>
          )}
        </p>
      )}

      <GoogleButton next={next} />

      <form action={loginAction} className="flex flex-col gap-4">
        {next && <input type="hidden" name="next" value={next} />}
        <div className="flex flex-col gap-1">
          <label htmlFor="login-email" className="text-sm font-medium">Email</label>
          <input
            id="login-email"
            name="email"
            type="email"
            required
            autoComplete="email"
            placeholder="you@example.com"
            className="rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-900"
          />
        </div>
        <div className="flex flex-col gap-1">
          <div className="flex items-baseline justify-between gap-3">
            <label htmlFor="login-password" className="text-sm font-medium">Password</label>
            <Link href="/login/forgot" className="text-sm text-orange-700 hover:underline dark:text-orange-400">
              Forgot password?
            </Link>
          </div>
          <input
            id="login-password"
            name="password"
            type="password"
            required
            autoComplete="current-password"
            className="rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-900"
          />
        </div>
        <button
          type="submit"
          className="mt-2 rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600"
        >
          Log in
        </button>
      </form>

      <p className="text-center text-sm text-zinc-500">
        New here?{" "}
        <Link href={next ? `/signup?next=${encodeURIComponent(next)}` : "/signup"} className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
          Join free
        </Link>
      </p>
    </main>
  );
}
