import type { Metadata } from "next";
import Link from "next/link";
import { requestPasswordResetAction } from "@/lib/actions";

export const metadata: Metadata = { title: "Forgot password", robots: { index: false } };

const input =
  "rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-900";

export default async function ForgotPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; sent?: string }>;
}) {
  const { error, sent } = await searchParams;

  return (
    <main className="mx-auto flex w-full max-w-sm flex-1 flex-col gap-6 px-4 py-6">
      <div className="text-center">
        <h1 className="text-xl font-bold sm:text-2xl">Forgot your password?</h1>
        <p className="text-sm text-zinc-500">We&apos;ll email you a link to choose a new one.</p>
      </div>

      {sent ? (
        <div className="flex flex-col gap-3 rounded-xl border border-green-200 bg-green-50 p-4 text-sm text-green-800 dark:border-green-900/60 dark:bg-green-950/40 dark:text-green-300">
          <p>
            If that email has a DealSnap account, a reset link is on its way. It works for the next hour.
          </p>
          <p className="text-green-700/80 dark:text-green-400/80">Can&apos;t see it? Check your spam folder, or try again in a few minutes.</p>
        </div>
      ) : (
        <>
          {error && (
            <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">{error}</p>
          )}
          <form action={requestPasswordResetAction} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1">
              <label htmlFor="forgot-email" className="text-sm font-medium">Email</label>
              <input id="forgot-email" name="email" type="email" required autoComplete="email" placeholder="you@example.com" className={input} />
            </div>
            <button type="submit" className="rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600">
              Send reset link
            </button>
          </form>
        </>
      )}

      <p className="text-center text-sm text-zinc-500">
        Remembered it?{" "}
        <Link href="/login" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
          Log in
        </Link>
      </p>
    </main>
  );
}
