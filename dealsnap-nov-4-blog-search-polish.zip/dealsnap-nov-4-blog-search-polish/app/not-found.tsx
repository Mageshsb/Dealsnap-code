import { searchBox } from "@/components/SearchBox";
import Link from "next/link";
import Icon from "@/components/Icon";
import { SEARCH_MAX } from "@/lib/search-limits";

export const metadata = { title: "Page not found" };

// Shown for any address that doesn't exist, such as a deal that's been
// deleted or a mistyped link: a way back in, rather than a dead end.
export default function NotFound() {
  return (
    <main className="mx-auto flex w-full max-w-md flex-1 flex-col items-center justify-center gap-5 px-4 py-16 text-center">
      <Icon name="search" strokeWidth={1.5} className="size-14 text-zinc-300 dark:text-zinc-600" />
      <div className="flex flex-col gap-2">
        <h1 className="text-xl font-bold sm:text-2xl">We couldn&apos;t find that page</h1>
        <p className="text-sm text-zinc-500">
          The deal may have been removed, or the link might be mistyped. Try searching for what you were after.
        </p>
      </div>

      <form action="/" className="flex w-full gap-2">
        <label htmlFor="not-found-search" className="sr-only">
          Search deals
        </label>
        <input
          id="not-found-search"
          name="q"
          type="search"
          maxLength={SEARCH_MAX}
          placeholder="Search deals"
          className={searchBox}
        />
        <button type="submit" className="shrink-0 rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
          Search
        </button>
      </form>

      <div className="flex flex-wrap justify-center gap-2">
        <Link
          href="/"
          className="inline-flex items-center gap-0.5 rounded-full border border-zinc-300 py-2 pl-3 pr-4 text-sm font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
        >
          <Icon name="chevron-left" className="size-4" />
          Today&apos;s deals
        </Link>
        <Link
          href="/categories"
          className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
        >
          Browse categories
        </Link>
      </div>
    </main>
  );
}
