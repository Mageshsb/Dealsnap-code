import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { findUserByUsername } from "@/lib/db";
import ProfileContent, { type ProfileParams } from "@/components/ProfileContent";
import AccountShell from "@/components/AccountShell";


export async function generateMetadata({ params }: { params: Promise<{ username: string }> }): Promise<Metadata> {
  const user = findUserByUsername(decodeURIComponent((await params).username));
  if (!user || user.deletedAt) return {};
  return {
    title: `${user.username}’s profile`,
    description: `Deals posted and loved by ${user.username}.`,
    alternates: { canonical: `/u/${encodeURIComponent(user.username)}` },
  };
}

export default async function PublicProfilePage({
  params,
  searchParams,
}: {
  params: Promise<{ username: string }>;
  searchParams: Promise<ProfileParams>;
}) {
  const { username } = await params;
  const profileUser = findUserByUsername(decodeURIComponent(username));
  if (!profileUser || profileUser.deletedAt) notFound();

  const viewer = await getCurrentUser();
  const content = <ProfileContent profileUser={profileUser} viewer={viewer} params={await searchParams} />;

  // Your own profile is "My profile" in My account: same menu and back link as
  // the rest of it, while the page itself is exactly what everyone else sees.
  if (viewer?.id === profileUser.id) {
    return (
      <AccountShell user={viewer} active="/profile">
        {content}
      </AccountShell>
    );
  }
  return <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-5 px-4 py-6">{content}</main>;
}
