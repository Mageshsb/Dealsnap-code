import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { findUserByUsername, getFollowers, getFollowEdge } from "@/lib/db";
import BackLink from "@/components/BackLink";
import UsernameLink from "@/components/UsernameLink";
import FollowButton from "@/components/FollowButton";
import EmptyState from "@/components/EmptyState";

export async function generateMetadata({ params }: { params: Promise<{ username: string }> }): Promise<Metadata> {
  const user = findUserByUsername(decodeURIComponent((await params).username));
  return { title: `${user?.username ?? "Member"}'s followers` };
}

export default async function FollowersPage({
  params,
}: {
  params: Promise<{ username: string }>;
}) {
  const { username } = await params;
  const profileUser = findUserByUsername(username);
  if (!profileUser) notFound();

  const viewer = await getCurrentUser();
  const isOwner = viewer?.id === profileUser.id;
  const followers = getFollowers(profileUser.id);

  return (
    <main className="mx-auto flex w-full max-w-2xl flex-1 flex-col gap-4 px-4 py-6">
      <BackLink href={`/u/${profileUser.username}`}>Back to {profileUser.username}&apos;s profile</BackLink>
      <h1 className="text-xl font-bold sm:text-2xl">{profileUser.username}&apos;s followers</h1>

      {followers.length === 0 ? (
        <EmptyState icon="users">
          <p>No followers yet.</p>
        </EmptyState>
      ) : (
        <div className="flex flex-col gap-2">
          {followers.map((f) => {
            const alreadyFollowing = isOwner ? getFollowEdge(viewer!.id, f.id) !== null : false;
            return (
              <div
                key={f.id}
                className="flex items-center justify-between gap-2 rounded-lg border border-zinc-200 p-3 dark:border-zinc-800"
              >
                <UsernameLink
                  username={f.username}
                  userId={f.id}
                  size="h-8 w-8"
                  className="flex items-center gap-2 text-sm font-medium"
                />
                {isOwner && f.id !== viewer!.id && (
                  <FollowButton
                    targetUserId={f.id}
                    initialFollowing={alreadyFollowing}
                    initialMuted={false}
                  />
                )}
              </div>
            );
          })}
        </div>
      )}
    </main>
  );
}
