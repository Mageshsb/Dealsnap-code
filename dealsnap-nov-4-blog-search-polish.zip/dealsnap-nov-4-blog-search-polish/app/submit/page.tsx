import BackLink from "@/components/BackLink";
import { getVisibleBrands } from "@/lib/brands";
import SubmitDealArea from "@/components/SubmitDealArea";
import { getCurrentUser } from "@/lib/auth";
import { isStaffRole } from "@/lib/permissions";
import { isTrustedPoster } from "@/lib/trust";
import { getKnownStores, getStoreVariantMap, storesWithWebsite } from "@/lib/mock-deals";
import { eventChoices } from "@/lib/events";
import { getLiveEvents } from "@/lib/db";
import { turnstileSiteKey } from "@/lib/captcha";
import { linkIn } from "@/lib/pasted-link";
import { extensionUrlFor, getSiteSettings } from "@/lib/site-settings";
import { headers } from "next/headers";

export const metadata = { title: "Post a deal" };

export default async function SubmitPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; draft?: string; read?: string; url?: string; text?: string }>;
}) {
  const user = await getCurrentUser();
  const { error, draft, read, url, text } = await searchParams;
  // A link shared to DealSnap from a phone's share menu (see app/manifest.ts),
  // or pasted into the search box. Apps put it in "url" or somewhere in "text".
  const sharedUrl = linkIn(url) ?? linkIn(text);
  // The browser extension for this browser, once it's published (not on phones).
  const userAgent = (await headers()).get("user-agent") ?? "";
  const extension = extensionUrlFor(getSiteSettings(), userAgent);

  return (
    <main className="mx-auto flex w-full max-w-lg flex-1 flex-col gap-6 px-4 py-6 lg:max-w-4xl">
      <BackLink href="/">Back to deals</BackLink>

      <div>
        <h1 className="text-xl font-bold sm:text-2xl">Post a deal</h1>
        <p className="mt-1 text-sm text-zinc-500">Found a bargain? Share it with the community.</p>
      </div>

      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </p>
      )}
      {!user && (
        <p className="rounded-lg bg-orange-50 px-4 py-2 text-sm text-zinc-700 dark:bg-orange-950/30 dark:text-zinc-300">
          Fill it in now. We&apos;ll ask you to join (free, a few seconds) before it goes up, and keep what you&apos;ve
          entered.
        </p>
      )}
      <SubmitDealArea
        knownStores={getKnownStores()}
        brands={getVisibleBrands().map((b) => b.name)}
        storeVariants={getStoreVariantMap()}
        storesWithSite={storesWithWebsite()}
        goesLiveImmediately={
          user ? (isStaffRole(user.role) ? "staff" : isTrustedPoster(user) ? "trusted" : undefined) : undefined
        }
        guest={!user}
        eventChoices={eventChoices(getLiveEvents())}
        restoreDraft={
          user && draft === "1" ? "joined" : user && error ? "error" : !read && !sharedUrl ? "started" : false
        }
        botCheckKey={user && !isStaffRole(user.role) ? turnstileSiteKey() : undefined}
        extensionTicket={read}
        sharedUrl={sharedUrl}
        extension={extension}
        iphone={/iPhone|iPod/.test(userAgent)}
      />
    </main>
  );
}
