import type { Metadata } from "next";
import { notFound } from "next/navigation";
import BlogListing, { pageNumber } from "@/components/blog/BlogListing";
import JsonLd from "@/components/JsonLd";
import { BLOG_KINDS, blogKindBySlug } from "@/lib/blog";
import { blogListStructuredData, breadcrumbStructuredData } from "@/lib/structured-data";
import { getBlogKindCounts, listBlogCards } from "@/lib/db";
import { getSiteUrl } from "@/lib/site-url";

export function generateStaticParams() {
  return BLOG_KINDS.map((k) => ({ kind: k.slug }));
}

export async function generateMetadata({ params, searchParams }: { params: Promise<{ kind: string }>; searchParams: Promise<{ page?: string }> }): Promise<Metadata> {
  const topic = blogKindBySlug((await params).kind);
  if (!topic) return {};
  const n = pageNumber((await searchParams).page);
  return {
    title: n > 1 ? `${topic.label}, page ${n} | Blog` : `${topic.label} | Blog`,
    description: topic.blurb,
    alternates: { canonical: `/blog/topic/${topic.slug}${n > 1 ? `?page=${n}` : ""}` },
    // A topic with no posts yet isn't worth listing in search.
    ...((getBlogKindCounts().get(topic.key) ?? 0) === 0 ? { robots: { index: false, follow: true } } : {}),
  };
}

// One kind of post on its own page (/blog/topic/guides): its own address,
// title and introduction, which is what search engines list for the subject.
export default async function BlogTopicPage({ params, searchParams }: { params: Promise<{ kind: string }>; searchParams: Promise<{ page?: string }> }) {
  const topic = blogKindBySlug((await params).kind);
  if (!topic) notFound();
  const page = pageNumber((await searchParams).page);
  const siteUrl = await getSiteUrl();
  const path = `/blog/topic/${topic.slug}`;
  return (
    <>
      <JsonLd data={blogListStructuredData(topic.label, topic.blurb, path, listBlogCards({ kind: topic.key, limit: 12, offset: 0 }).rows, siteUrl)} />
      <JsonLd data={breadcrumbStructuredData([{ name: "Blog", href: "/blog" }, { name: topic.label, href: path }], siteUrl)} />
      <BlogListing kind={topic.key} q="" page={page} basePath={path} />
    </>
  );
}
