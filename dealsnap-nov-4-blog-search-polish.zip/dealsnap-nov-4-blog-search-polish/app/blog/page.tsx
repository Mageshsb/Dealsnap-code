import type { Metadata } from "next";
import BlogListing, { pageNumber } from "@/components/blog/BlogListing";
import JsonLd from "@/components/JsonLd";
import { blogListStructuredData } from "@/lib/structured-data";
import { getRecentBlogCards } from "@/lib/db";
import { SEARCH_MAX } from "@/lib/community-rules";
import { getSiteUrl } from "@/lib/site-url";

const DESCRIPTION = "Buying guides, money-saving tips and sale dates from the DealSnap team and community.";

type Search = { q?: string; page?: string };

// A page of search results is for the person who searched, not for search
// engines; later pages of the list are their own pages (so every post can be found).
export async function generateMetadata({ searchParams }: { searchParams: Promise<Search> }): Promise<Metadata> {
  const { q, page } = await searchParams;
  const n = pageNumber(page);
  return {
    title: n > 1 ? `Blog, page ${n}` : "Blog",
    description: DESCRIPTION,
    alternates: { canonical: n > 1 && !q ? `/blog?page=${n}` : "/blog" },
    ...(q ? { robots: { index: false, follow: true } } : {}),
  };
}

export default async function BlogIndex({ searchParams }: { searchParams: Promise<Search> }) {
  const sp = await searchParams;
  const q = (sp.q ?? "").trim().slice(0, SEARCH_MAX);
  return (
    <>
      <JsonLd data={blogListStructuredData("Blog", DESCRIPTION, "/blog", getRecentBlogCards(12), await getSiteUrl())} />
      <BlogListing q={q} page={pageNumber(sp.page)} basePath="/blog" />
    </>
  );
}
