import { ImageResponse } from "next/og";
import { getPostBySlug } from "@/lib/mock-blog";
import { OG_SIZE, clip, logoDataUri, publicImageDataUri } from "@/lib/og";
import { getSiteName } from "@/lib/site-url";

// Blog covers are SVGs, which link previews won't show, so the preview is
// drawn here as a PNG: the cover with the post's title under it.
export const alt = "DealSnap blog post";
export const size = OG_SIZE;
export const contentType = "image/png";

export default async function Image({ params }: { params: Promise<{ slug: string }> }) {
  const post = getPostBySlug((await params).slug);
  const [cover, logo] = await Promise.all([publicImageDataUri(post?.cover), logoDataUri()]);

  return new ImageResponse(
    (
      <div style={{ display: "flex", flexDirection: "column", width: "100%", height: "100%", background: "#ffffff", color: "#18181b" }}>
        {cover && <img src={cover} alt="" width={1200} height={400} style={{ objectFit: "cover" }} />}
        <div style={{ display: "flex", flex: 1, alignItems: "center", gap: 28, padding: "0 56px" }}>
          {logo && <img src={logo} alt="" width={72} height={72} />}
          <div style={{ display: "flex", flexDirection: "column" }}>
            <span style={{ fontSize: 26, color: "#ea580c" }}>{getSiteName()} blog</span>
            <span style={{ fontSize: 48, lineHeight: 1.15 }}>{clip(post?.title ?? getSiteName(), 70)}</span>
          </div>
        </div>
      </div>
    ),
    size
  );
}
