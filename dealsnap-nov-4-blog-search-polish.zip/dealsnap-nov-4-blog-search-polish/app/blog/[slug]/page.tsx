import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { after } from "next/server";
import { blogCard, getPostBySlug } from "@/lib/mock-blog";
import { getBlogDealCards } from "@/lib/blog-deals";
import { getCurrentUser } from "@/lib/auth";
import { getKeywordAlerts, getRecentBlogCards } from "@/lib/db";
import { countBlogView, reader } from "@/lib/blog-stats";
import { getDealBySlug, searchDeals } from "@/lib/mock-deals";
import { formatDate } from "@/lib/format";
import { getCategoryBySlug } from "@/lib/categories";
import { slugify } from "@/lib/slug";
import { blogKind, blogKindHref, daysSince, dealSlugsIn, faqFromBlocks, parseBlogContent, plainBlogText, relatedPosts, safeHref, wordCount } from "@/lib/blog";
import { sameKeyword } from "@/lib/alert-match";
import { affiliateDisclosureText, getSiteSettings } from "@/lib/site-settings";
import { articleStructuredData, breadcrumbStructuredData, faqStructuredData } from "@/lib/structured-data";
import { getSiteName, getSiteUrl } from "@/lib/site-url";
import BlogCard from "@/components/BlogCard";
import BlogContent from "@/components/BlogContent";
import DealTile from "@/components/DealTile";
import JsonLd from "@/components/JsonLd";
import KeywordAlertButton from "@/components/KeywordAlertButton";
import ShareButton from "@/components/ShareButton";
import Icon from "@/components/Icon";
import { ContentsFolded, ContentsSide } from "@/components/ContentsNav";
import PostFeedback from "@/components/blog/PostFeedback";
import ReadingProgress from "@/components/ReadingProgress";
import { getPageAds } from "@/lib/ad-serving";
import { RAIL_SLOTS } from "@/lib/ads";
import { articlePositions } from "@/lib/ad-positions";
import AdUnit, { AdsProvider } from "@/components/AdUnit";
import AdRails from "@/components/AdRails";
import { brandLogoPath } from "@/lib/site-brand";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const post = getPostBySlug((await params).slug);
  if (!post) return {};
  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: `/blog/${post.slug}` },
    openGraph: { type: "article", title: post.title, description: post.excerpt, publishedTime: post.publishedAt, modifiedTime: post.updatedAt, authors: [post.author], section: blogKind(post.kind).label },
    twitter: { card: "summary_large_image", title: post.title, description: post.excerpt },
  };
}

const DAY = 24 * 60 * 60 * 1000;
// A post whose prices were checked longer ago than this says so.
const STALE_DAYS = 120;

// The Pick's product name without the "Best under £200:" lead-in, for finding its deals.
const productOf = (name: string) => (name.includes(":") ? name.slice(name.lastIndexOf(":") + 1) : name).trim();

export default async function BlogPostPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ preview?: string }>;
}) {
  const { slug } = await params;
  const { preview } = await searchParams;
  const user = await getCurrentUser();
  // Admins can preview drafts and scheduled posts before they go live.
  const post = getPostBySlug(slug, { includeDrafts: !!preview && user?.role === "admin" });
  if (!post) notFound();
  // Counted after the page is sent, so it never slows a reader; not for a
  // preview or for staff looking at their own work. Who's asking is read now,
  // as the request can't be read once the page has gone.
  if (!preview && user?.role !== "admin") {
    const who = await reader();
    after(() => countBlogView(post.id, who));
  }

  const kind = blogKind(post.kind);
  const blocks = parseBlogContent(post.content);
  const headings = blocks.filter((b) => b.type === "heading");
  const faq = faqFromBlocks(blocks);
  const words = wordCount(plainBlogText(post.content.join("\n\n")));
  const updated = new Date(post.updatedAt).getTime() - new Date(post.publishedAt).getTime() > DAY;
  const disclosure = affiliateDisclosureText(getSiteSettings());
  const siteUrl = await getSiteUrl();
  const checkedDaysAgo = post.checkedAt ? daysSince(post.checkedAt) : undefined;
  const stale = checkedDaysAgo !== undefined && checkedDaysAgo > STALE_DAYS;

  // Deals to go with the post: the editor's words if they gave some,
  // otherwise the post's category.
  const deals = (post.dealsQuery ? searchDeals(post.dealsQuery) : post.category ? searchDeals(undefined, post.category) : []).slice(0, 8);
  const categoryPage = post.category && getCategoryBySlug(slugify(post.category)) ? `/categories/${slugify(post.category)}` : undefined;
  const alertWord = post.dealsQuery.trim();
  const existingAlert = user && alertWord ? getKeywordAlerts(user.id).find((k) => sameKeyword(k.keyword, alertWord)) : undefined;
  const embedded = getBlogDealCards(dealSlugsIn(blocks), getDealBySlug);

  // Each pick's button: a link the editor gave (through /pick, so it earns
  // and is counted), a page on the site, or, with none, the live deals for
  // that product, when there are some.
  const picks = (post.picks ?? []).map((pick, i) => {
    if (safeHref(pick.url)) {
      return pick.url!.startsWith("/")
        ? { pick, href: pick.url!, label: "See the deal →", sponsored: false }
        : { pick, href: `/pick/${post.slug}/${i}`, label: "See the deal →", sponsored: true };
    }
    const query = productOf(pick.name);
    const found = query ? searchDeals(query).length : 0;
    return found > 0 ? { pick, href: `/?q=${encodeURIComponent(query)}`, label: "Find live deals →", sponsored: false } : { pick, href: undefined, label: "", sponsored: false };
  });

  // More reading: the same subject first, then the same kind, then the newest.
  const more = relatedPosts(
    { slug: post.slug, title: post.title, kind: post.kind, category: post.category, publishedAt: post.publishedAt },
    getRecentBlogCards(60, post.id),
    3
  ).map(blogCard);

  // Admin → Ads: between paragraphs, after the article, and the side columns
  // (none on a draft being previewed).
  const ads = preview
    ? undefined
    : await getPageAds({ kind: "blog", path: `/blog/${post.slug}`, labels: { blog: post.slug } }, ["blog", "blog-end", ...RAIL_SLOTS]);
  const inArticle = ads?.slots.blog;
  const adsAfter = inArticle ? articlePositions(blocks, inArticle.first, inArticle.every, inArticle.max) : [];

  const contents = [...headings.map((h) => ({ id: h.id, text: h.text })), ...(picks.length ? [{ id: "our-picks", text: "Our picks" }] : [])];

  return (
    <AdsProvider ads={ads}>
      <ReadingProgress targetId="article-body" />
      <main className="relative mx-auto flex w-full max-w-5xl flex-1 flex-col gap-10 px-4 py-6">
        <AdRails />
        <JsonLd data={articleStructuredData({ ...post, words, section: kind.label }, siteUrl, getSiteName(), brandLogoPath())} />
        <JsonLd
          data={breadcrumbStructuredData(
            [
              { name: "Blog", href: "/blog" },
              { name: kind.label, href: blogKindHref(post.kind) },
              { name: post.title, href: `/blog/${post.slug}` },
            ],
            siteUrl
          )}
        />
        {faq.length >= 2 && <JsonLd data={faqStructuredData(faq)} />}

        {/* The article sits in a reading-width column (about 70 characters a
            line, which is what the eye follows comfortably); on a laptop the
            contents and alert stay beside it as you read. */}
        <div className="grid grid-cols-1 items-start gap-10 lg:grid-cols-[minmax(0,44rem)_minmax(0,1fr)] lg:gap-12">
          <article className="flex min-w-0 flex-col gap-6">
            <header className="flex flex-col gap-3">
              <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-1.5 text-sm text-zinc-500">
                <Link href="/blog" className="hover:text-zinc-900 hover:underline dark:hover:text-zinc-100">
                  Blog
                </Link>
                <span aria-hidden>›</span>
                <Link href={blogKindHref(post.kind)} className="font-medium text-orange-700 hover:underline dark:text-orange-400">
                  <Icon name={kind.icon} className="mr-1" />
                  {kind.label}
                </Link>
              </nav>

              <h1 className="text-balance text-2xl font-extrabold leading-tight sm:text-4xl">{post.title}</h1>
              {post.excerpt && <p className="text-base leading-relaxed text-zinc-600 sm:text-lg dark:text-zinc-400">{post.excerpt}</p>}

              <div className="flex items-center gap-3 border-y border-zinc-200 py-3 dark:border-zinc-800">
                <span aria-hidden className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-orange-500 text-sm font-bold text-white">
                  {post.author.charAt(0).toUpperCase()}
                </span>
                <div className="flex min-w-0 flex-1 flex-col">
                  <span className="truncate text-sm font-semibold">{post.author}</span>
                  <span className="text-xs text-zinc-500">
                    <time dateTime={post.publishedAt}>{formatDate(post.publishedAt)}</time>
                    {updated && (
                      <>
                        {" "}
                        · Updated <time dateTime={post.updatedAt}>{formatDate(post.updatedAt)}</time>
                      </>
                    )}{" "}
                    · {post.readMinutes} min read
                  </span>
                </div>
                <ShareButton url={`/blog/${post.slug}`} title={post.title} round label="Share this post" />
              </div>
            </header>

            <div className="relative aspect-[16/9] w-full overflow-hidden rounded-xl">
              <Image src={post.cover} alt="" fill className="object-cover" sizes="(min-width: 1024px) 704px, 100vw" unoptimized={post.cover.startsWith("/blog-cover/")} loading="eager" fetchPriority="high" />
            </div>

            {(disclosure || post.checkedAt) && (
              <p className="-mt-3 text-xs text-zinc-500">
                {post.checkedAt && (
                  <>
                    <Icon name="circle-check" className="mr-1 text-green-700 dark:text-green-400" />
                    Prices checked <time dateTime={post.checkedAt}>{formatDate(post.checkedAt)}</time>.{" "}
                  </>
                )}
                {disclosure}
              </p>
            )}

            {stale && (
              <p className="rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
                <Icon name="clock" className="mr-1.5" />
                The prices here were last checked a while ago and may have changed. The live deals further down are up to date.
              </p>
            )}

            {post.takeaways.length > 0 && (
              <aside aria-labelledby="takeaways" className="rounded-xl border border-orange-200 bg-orange-50 p-4 sm:p-5 dark:border-orange-900/60 dark:bg-orange-950/30">
                <h2 id="takeaways" className="mb-2 flex items-center gap-2 font-bold">
                  <Icon name="zap" className="size-4 text-orange-700 dark:text-orange-400" />
                  Key takeaways
                </h2>
                <ul className="flex flex-col gap-1.5 text-[15px] leading-relaxed text-zinc-700 dark:text-zinc-300">
                  {post.takeaways.map((t, i) => (
                    <li key={i} className="flex gap-2">
                      <Icon name="check" className="mt-[0.3em] size-4 shrink-0 text-orange-700 dark:text-orange-400" />
                      <span>{t}</span>
                    </li>
                  ))}
                </ul>
              </aside>
            )}

            {contents.length >= 3 && <ContentsFolded title="In this post" items={contents} />}

            <div id="article-body" className="flex flex-col gap-10">
              <BlogContent blocks={blocks} adsAfter={adsAfter} deals={embedded} />

              {picks.length > 0 && (
                <section aria-labelledby="our-picks" className="flex flex-col gap-3">
                  <h2 id="our-picks" className="flex scroll-mt-24 items-center gap-2 text-xl font-bold sm:text-2xl">
                    <Icon name="trophy" className="size-5 text-orange-700 dark:text-orange-400" />
                    Our picks
                  </h2>
                  <ol className="flex flex-col gap-3">
                    {picks.map(({ pick, href, label, sponsored }, i) => (
                      <li key={`${pick.name}-${i}`} className="flex gap-3 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
                        <span aria-hidden className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-zinc-900 text-sm font-bold text-white dark:bg-zinc-100 dark:text-zinc-900">
                          {i + 1}
                        </span>
                        <div className="flex min-w-0 flex-1 flex-col gap-1">
                          <div className="flex items-start justify-between gap-3">
                            <p className="font-semibold leading-snug">{pick.name}</p>
                            {pick.price && <span className="shrink-0 text-lg font-bold text-orange-700 dark:text-orange-400">{pick.price}</span>}
                          </div>
                          {pick.blurb && <p className="text-sm leading-relaxed text-zinc-600 dark:text-zinc-400">{pick.blurb}</p>}
                          {href && (
                            <a
                              href={href}
                              {...(sponsored ? { target: "_blank", rel: "sponsored nofollow noopener noreferrer" } : {})}
                              className="mt-1 self-start rounded-full bg-orange-500 px-4 py-1.5 text-sm font-semibold text-white hover:bg-orange-600"
                            >
                              {label}
                            </a>
                          )}
                        </div>
                      </li>
                    ))}
                  </ol>
                </section>
              )}
            </div>

            {(deals.length > 0 || alertWord) && (
              <section aria-labelledby="post-deals" className="flex flex-col gap-3 rounded-xl bg-zinc-50 p-4 sm:p-5 dark:bg-zinc-900/60">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h2 id="post-deals" className="flex items-center gap-2 text-lg font-bold">
                    <Icon name="shopping-bag" className="size-5 text-orange-700 dark:text-orange-400" />
                    Deals right now
                  </h2>
                  {post.dealsQuery ? (
                    <Link href={`/?q=${encodeURIComponent(post.dealsQuery)}`} className="text-sm font-semibold text-orange-700 hover:underline dark:text-orange-400">
                      See all →
                    </Link>
                  ) : (
                    categoryPage && (
                      <Link href={categoryPage} className="text-sm font-semibold text-orange-700 hover:underline dark:text-orange-400">
                        See all →
                      </Link>
                    )
                  )}
                </div>
                {deals.length > 0 && (
                  <div role="list" className="-mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-1 sm:-mx-5 sm:px-5 [scrollbar-width:thin]">
                    {deals.map((deal) => (
                      <DealTile key={deal.id} deal={deal} />
                    ))}
                  </div>
                )}
                {alertWord && (
                  <KeywordAlertButton keyword={alertWord} label={`Get alerts for new ${alertWord} deals`} initialAlertId={existingAlert?.id ?? null} nextPath={`/blog/${post.slug}`} />
                )}
              </section>
            )}

            <PostFeedback slug={post.slug} />

            <AdUnit slot="blog-end" />
          </article>

          <aside aria-label="Around this post" className="hidden flex-col gap-6 lg:sticky lg:top-24 lg:flex">
            {contents.length >= 3 && <ContentsSide title="In this post" items={contents} />}
            {alertWord && (
              <div className="flex flex-col gap-2 rounded-xl border border-orange-200 bg-orange-50 p-4 dark:border-orange-900/60 dark:bg-orange-950/30">
                <p className="flex items-center gap-2 text-sm font-semibold">
                  <Icon name="bell" className="size-4 text-orange-700 dark:text-orange-400" />
                  Waiting for a price drop?
                </p>
                <KeywordAlertButton keyword={alertWord} label={`Alert me: ${alertWord}`} initialAlertId={existingAlert?.id ?? null} nextPath={`/blog/${post.slug}`} />
              </div>
            )}
          </aside>
        </div>

        {more.length > 0 && (
          <section aria-labelledby="more-posts" className="flex flex-col gap-3 border-t border-zinc-200 pt-6 dark:border-zinc-800">
            <h2 id="more-posts" className="text-lg font-bold">
              Keep reading
            </h2>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 sm:gap-4">
              {more.map((p) => (
                <BlogCard key={p.id} post={p} />
              ))}
            </div>
          </section>
        )}
      </main>
    </AdsProvider>
  );
}
