import { getUserAvatar } from "@/lib/db";

// Serves a member's profile picture from the database: "<version>.webp". The
// version changes whenever the picture does, so each address can be cached
// for a year and the server only ever sends it once or twice.
export async function GET(_request: Request, { params }: { params: Promise<{ id: string; file: string }> }) {
  const { id, file } = await params;
  const match = /^[a-z0-9-]{1,64}$/.test(id) ? file.match(/^([a-z0-9]{1,20})\.webp$/) : null;
  const data = match ? getUserAvatar(id, match[1]) : undefined;
  if (!data) return new Response("Not found", { status: 404 });

  return new Response(Buffer.from(data), {
    headers: {
      "Content-Type": "image/webp",
      "Cache-Control": "public, max-age=31536000, immutable",
      // Only ever a picture: nothing in it can run as a page.
      "Content-Security-Policy": "default-src 'none'; sandbox",
    },
  });
}
