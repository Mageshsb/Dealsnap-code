import fs from "node:fs";
import path from "node:path";
import { Readable, Transform } from "node:stream";
import { pipeline } from "node:stream/promises";
import { getCurrentUser } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { can } from "@/lib/permissions";
import { missingTwoStep } from "@/lib/staff-two-step";
import { inspectBackup, uploadTarget } from "@/lib/backups";
import { MAX_UPLOAD_BYTES, sizeLabel } from "@/lib/backup-limits";

// Receives a backup file the owner downloaded earlier, so it can be restored
// (Admin → Settings → Data & backups). The file is streamed straight to disk, never
// held in memory, and it's checked before it's kept.
//
// This address is left out of proxy.ts on purpose: with the proxy in front, Next
// buffers only the first 10MB of a request body, which would cut a real backup
// short. So everything the proxy would have checked is checked here: signed in,
// not suspended, allowed to restore, two-step login if the site requires it, and
// the request must come from this site's own pages (a same-origin fetch that
// carries our header), so another website can't send one.
const bad = (error: string, status: number) => Response.json({ error }, { status, headers: { "cache-control": "no-store" } });

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user || user.suspended || !can(user.role, "data.restore") || missingTwoStep(user)) return bad("Not allowed.", 403);
  if (request.headers.get("sec-fetch-site") !== "same-origin" || request.headers.get("x-dealsnap-upload") !== "1") return bad("Not allowed.", 403);

  const length = Number(request.headers.get("content-length"));
  if (!Number.isFinite(length) || length <= 0) return bad("The file's size wasn't sent.", 411);
  if (length > MAX_UPLOAD_BYTES) return bad(`That file is too big (the limit is ${sizeLabel(MAX_UPLOAD_BYTES)}).`, 413);
  if (!request.body) return bad("No file was sent.", 400);

  const { dir, file } = uploadTarget();
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const temp = path.join(dir, `.upload-${process.pid}-${Date.now()}.part`);
  let received = 0;
  const counted = new Transform({
    transform(chunk, _enc, done) {
      received += chunk.length;
      if (received > MAX_UPLOAD_BYTES) done(new Error("too big"));
      else done(null, chunk);
    },
  });
  try {
    await pipeline(Readable.fromWeb(request.body as Parameters<typeof Readable.fromWeb>[0]), counted, fs.createWriteStream(temp, { mode: 0o600 }));
  } catch {
    fs.rmSync(temp, { force: true });
    return bad("The upload didn't finish. Try again.", 400);
  }
  const check = inspectBackup(temp, user.id);
  if (!check.ok) {
    fs.rmSync(temp, { force: true });
    return bad(check.reason, 400);
  }
  fs.renameSync(temp, file);
  logAudit(user, "backup.upload", { label: `${(received / 1048576).toFixed(1)}MB`, url: "/admin/settings?tab=data", detail: `${check.members} members, ${check.deals} deals` });
  return Response.json({ ok: true }, { headers: { "cache-control": "no-store" } });
}
