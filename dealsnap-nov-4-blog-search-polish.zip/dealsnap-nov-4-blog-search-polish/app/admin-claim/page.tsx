import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getAdminCount } from "@/lib/db";
import { claimAdminAction } from "@/lib/admin-actions";
import { mayClaimAdmin } from "@/lib/admin-claim";

export const metadata = { title: "Set up admin access" };

export default async function AdminClaimPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin-claim");
  if (user.role === "admin") redirect("/admin");

  const adminCount = getAdminCount();
  const owner = mayClaimAdmin(user);

  return (
    <main className="mx-auto flex w-full max-w-sm flex-1 flex-col gap-6 px-4 py-12">
      <div className="text-center">
        <h1 className="text-xl font-bold sm:text-2xl">Set up admin access</h1>
        <p className="text-sm text-zinc-500">
          One-time step for whoever launches DealSnap — claim the first admin account.
        </p>
      </div>

      {(error || adminCount > 0 || !owner) && (
        <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
          {adminCount > 0
            ? "An admin account already exists — ask them for access."
            : !owner
              ? "Only the site's owner can do this: the account whose confirmed email is set as ADMIN_EMAIL on the server."
              : "Something went wrong — refresh and try again."}
        </p>
      )}

      {adminCount === 0 && owner && (
        <form action={claimAdminAction} className="flex flex-col gap-4">
          <p className="rounded-lg border border-zinc-200 bg-white p-4 text-sm text-zinc-600 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-400">
            Signed in as <span className="font-semibold text-zinc-900 dark:text-zinc-100">{user.username}</span>.
            This will make this account a permanent site admin, with access to moderate deals, manage
            users, and take the site into maintenance mode.
          </p>
          <button
            type="submit"
            className="rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600"
          >
            Claim admin access
          </button>
        </form>
      )}
    </main>
  );
}
