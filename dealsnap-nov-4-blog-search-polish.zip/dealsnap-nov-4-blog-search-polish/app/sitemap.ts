import type { MetadataRoute } from "next";
import { getAdSettings } from "@/lib/ad-serving";
import { BRAND_TILE_DEALS, STORE_INDEX_DEALS, getAllDeals, getBrandCounts, getStoreBySlug, getStores } from "@/lib/mock-deals";
import { getVisibleBrands } from "@/lib/brands";
import { getPostsForSitemap } from "@/lib/mock-blog";
import { BLOG_KINDS } from "@/lib/blog";
import { getBlogKindCounts } from "@/lib/db";
import { getCategoryGroups } from "@/lib/categories";
import { slugify } from "@/lib/slug";
import { getSiteSettings } from "@/lib/site-settings";
import { getSiteUrl } from "@/lib/site-url";
import { getLiveEvents } from "@/lib/db";
import { getAllSitePages, pageHref } from "@/lib/site-pages";
import { getCommunitySettings, getRecentThreadsForSitemap, listSpaces } from "@/lib/community-db";

// Served at /sitemap.xml (robots.txt points to it): every public page Google
// should know about, so new deals get found quickly. Empty while the site is
// hidden from search engines. With tens of thousands of deals it's a few MB,
// so it's made at most every 10 minutes (search engines read it far less
// often than that) rather than on every request. It stops at 40,000 deals
// (newest first), as search engines stop reading one file at 50,000 addresses.
// Made on request, not when the site is built: a build-time sitemap would be
// frozen at whatever deals existed on deploy day. (Next prerenders this file
// unless it opts out.) The 10-minute memo below keeps it cheap.
export const dynamic = "force-dynamic";
const REMAKE_MS = 10 * 60 * 1000;
const MAX_DEAL_ADDRESSES = 40_000;
let kept: { at: number; hidden: boolean; map: MetadataRoute.Sitemap } | undefined;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const hidden = getSiteSettings().hideFromSearchEngines;
  if (kept && kept.hidden === hidden && Date.now() - kept.at < REMAKE_MS) return kept.map;
  const map = await makeSitemap(hidden);
  kept = { at: Date.now(), hidden, map };
  return map;
}

async function makeSitemap(hidden: boolean): Promise<MetadataRoute.Sitemap> {
  if (hidden) return [];
  const base = await getSiteUrl();
  const page = (path: string, extra: Omit<MetadataRoute.Sitemap[number], "url"> = {}) => ({ url: `${base}${path}`, ...extra });

  return [
    page("/", { changeFrequency: "hourly", priority: 1 }),
    page("/categories"),
    page("/stores"),
    page("/vouchers", { changeFrequency: "daily", priority: 0.8 }),
    page("/brands"),
    page("/blog"),
    ...(getCommunitySettings().on
      ? [
          page("/community", { changeFrequency: "hourly", priority: 0.6 }),
          ...listSpaces().map((s) => page(`/community/${s.slug}`, { changeFrequency: "daily", priority: 0.5 })),
          ...getRecentThreadsForSitemap().map((t) => page(`/community/t/${t.slug}`, { lastModified: t.lastPostAt, priority: 0.4 })),
        ]
      : []),
    ...getLiveEvents().map((e) => page(`/${e.slug}`, { changeFrequency: "daily", priority: 0.8 })),
    ...getAllSitePages().filter((p) => p.published).map((p) => page(pageHref(p), { changeFrequency: "yearly", priority: 0.2 })),
    ...(getAdSettings().page.on ? [page("/advertise", { changeFrequency: "monthly", priority: 0.2 })] : []),
    ...getCategoryGroups().flatMap((g) => [
      page(`/categories/${slugify(g.name)}`, { changeFrequency: "daily", priority: 0.7 }),
      ...g.tags.flatMap((t) => [t, ...(t.subtags ?? [])]).map((t) => page(`/tags/${slugify(t.name)}`, { changeFrequency: "daily", priority: 0.5 })),
    ]),
    // Only brands with enough recent deals: quiet ones aren't shown to search engines.
    ...(() => {
      const counts = getBrandCounts();
      return getVisibleBrands()
        .filter((b) => (counts.get(b.slug)?.recent ?? 0) >= BRAND_TILE_DEALS)
        .map((b) => page(`/brands/${b.slug}`, { changeFrequency: "daily", priority: 0.5 }));
    })(),
    ...getStores()
      // Enough live deals, and an address that doesn't redirect to another store's.
      .filter((s) => s.dealCount >= STORE_INDEX_DEALS && getStoreBySlug(s.slug)?.slug === s.slug)
      .map((s) => page(`/stores/${s.slug}`, { changeFrequency: "daily", priority: 0.5 })),
    // The newest deals first, and never more than search engines will read from one file
    // (50,000 addresses in all); the lists only reach back as far as Settings says anyway.
    ...[...getAllDeals()]
      .sort((a, b) => b.postedAt.localeCompare(a.postedAt))
      .slice(0, MAX_DEAL_ADDRESSES)
      .map((d) => page(`/deals/${d.slug}`, { lastModified: d.postedAt, priority: 0.6 })),
    ...BLOG_KINDS.filter((k) => (getBlogKindCounts().get(k.key) ?? 0) > 0).map((k) => page(`/blog/topic/${k.slug}`, { changeFrequency: "weekly", priority: 0.5 })),
    ...getPostsForSitemap().map((p) => page(`/blog/${p.slug}`, { lastModified: p.updatedAt > p.publishedAt ? p.updatedAt : p.publishedAt, priority: 0.6 })),
  ];
}
