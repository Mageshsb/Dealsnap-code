import Link from "next/link";
import { mustConfirmEmail } from "@/lib/email";
import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { getCurrentUser } from "@/lib/auth";
import { getCategoryAlerts } from "@/lib/db";
import { getCategoryGroups, categoryTheme } from "@/lib/categories";
import { slugify } from "@/lib/slug";
import { saveInterestsAction } from "@/lib/actions";
import Icon from "@/components/Icon";
import { localPath } from "@/lib/local-path";

export const metadata: Metadata = { title: "What are you into?", robots: { index: false } };

// Straight after signing up: tap the kinds of deals you care about (like picking
// shows on Netflix) and each becomes a category alert, so the site is useful
// from day one. Skippable, and changeable later on the Alerts page.
export default async function WelcomePage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; named?: string }>;
}) {
  const { next: nextParam, named } = await searchParams;
  const next = localPath(nextParam);
  const user = await getCurrentUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(`/welcome${next === "/" ? "" : `?next=${encodeURIComponent(next)}`}`)}`);

  const already = new Set(getCategoryAlerts(user.id));

  return (
    <main className="mx-auto flex w-full max-w-2xl flex-1 flex-col gap-6 px-4 py-6">
      <div className="text-center">
        <h1 className="text-xl font-bold sm:text-2xl">What are you into?</h1>
        <p className="mt-1 text-sm text-zinc-500">
          Pick a few and we&apos;ll tell you when a deal there gets 25+ hearts. You can change this any time in{" "}
          <Link href="/alerts" className="font-medium text-orange-700 hover:underline dark:text-orange-400">
            Alerts
          </Link>
          .
        </p>
        {mustConfirmEmail(user) && (
          <p className="mt-3 text-xs text-zinc-500">
            We&apos;ve sent a link to <span className="font-semibold text-zinc-700 dark:text-zinc-300">{user.email}</span> to confirm
            your email.
          </p>
        )}
        {named && (
          <p className="mt-3 text-xs text-zinc-500">
            We&apos;ve called you <span className="font-semibold text-zinc-700 dark:text-zinc-300">{user.username}</span>.{" "}
            <Link href="/settings?s=profile" className="font-medium text-orange-700 hover:underline dark:text-orange-400">
              Change it
            </Link>
          </p>
        )}
      </div>

      <form action={saveInterestsAction} className="flex flex-col gap-6">
        <input type="hidden" name="next" value={next} />
        {/* Seven categories: on a phone the last one spans the row rather than sitting alone. */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {getCategoryGroups().map((group) => {
            const slug = slugify(group.name);
            return (
              <label
                key={slug}
                className="relative flex cursor-pointer flex-col items-center gap-1.5 rounded-xl border-2 max-sm:last:odd:col-span-2 border-zinc-200 bg-white px-2 py-4 text-center transition-colors select-none hover:border-zinc-300 has-checked:border-orange-500 has-checked:bg-orange-50 has-focus-visible:ring-2 has-focus-visible:ring-orange-400 dark:border-zinc-800 dark:bg-zinc-900 dark:hover:border-zinc-700 dark:has-checked:border-orange-500 dark:has-checked:bg-orange-950/30"
              >
                <input type="checkbox" name="category" value={slug} defaultChecked={already.has(slug)} className="peer sr-only" />
                <span
                  aria-hidden
                  className="absolute right-2 top-2 flex h-5 w-5 items-center justify-center rounded-full border border-zinc-300 text-white peer-checked:border-orange-500 peer-checked:bg-orange-500 dark:border-zinc-600"
                >
                  <svg viewBox="0 0 16 16" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m3.5 8.5 3 3 6-7" />
                  </svg>
                </span>
                <Icon name={group.icon} strokeWidth={1.75} className={`size-8 ${categoryTheme(group.name).icon}`} />
                <span className="text-sm font-semibold leading-tight">{group.name}</span>
                <span className="line-clamp-2 text-xs text-zinc-500">
                  {group.tags
                    .slice(0, 3)
                    .map((t) => t.name)
                    .join(", ")}
                </span>
              </label>
            );
          })}
        </div>

        <div className="flex flex-col items-center gap-3">
          <button
            type="submit"
            className="w-full max-w-xs rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600"
          >
            Done
          </button>
          <Link href={next} className="text-sm text-zinc-500 hover:text-zinc-700 hover:underline dark:hover:text-zinc-300">
            Skip for now
          </Link>
        </div>
      </form>
    </main>
  );
}
