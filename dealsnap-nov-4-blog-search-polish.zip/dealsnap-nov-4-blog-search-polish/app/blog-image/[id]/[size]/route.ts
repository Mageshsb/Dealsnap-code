import { getBlogImage } from "@/lib/db";

// A picture inside a blog post. The id never changes what it shows (a new
// upload gets a new id), so it can be cached for a year. The size part of the
// address is only there so the post knows the picture's shape before it loads.
export async function GET(_request: Request, { params }: { params: Promise<{ id: string; size: string }> }) {
  const { id, size } = await params;
  const image = /^[0-9a-f-]{36}$/.test(id) && /^\d{2,5}x\d{2,5}$/.test(size) ? getBlogImage(id) : undefined;
  if (!image) return new Response("Not found", { status: 404 });
  return new Response(Buffer.from(image.data), {
    headers: { "Content-Type": image.type, "Cache-Control": "public, max-age=31536000, immutable", "X-Content-Type-Options": "nosniff" },
  });
}
