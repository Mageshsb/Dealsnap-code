import type { Metadata } from "next";
import Link from "next/link";
import CategoryPills from "@/components/CategoryPills";
import CategorySwitcher from "@/components/CategorySwitcher";
import SidebarBoxes from "@/components/SidebarBoxes";
import BrowseExperience from "@/components/BrowseExperience";
import SwipeHeader from "@/components/SwipeHeader";
import SortAndFilters from "@/components/SortAndFilters";
import EmptyState from "@/components/EmptyState";
import Icon from "@/components/Icon";
import JsonLd from "@/components/JsonLd";
import { getDealsForView, getStoreFacet } from "@/lib/mock-deals";
import { parseView, parseLovedWindow, lovedDivider, DEFAULT_VIEW, DEFAULT_LOVED_WINDOW } from "@/lib/deal-views";
import { parseMinHearts, parseSlug, narrowDeals, narrowQuery, type Facet } from "@/lib/deal-filters";
import { isExpired } from "@/lib/format";
import { PAGE_SIZE } from "@/lib/pagination";
import { getListPromos } from "@/lib/promo-site";
import { getListAds } from "@/lib/ad-serving";
import { breadcrumbStructuredData } from "@/lib/structured-data";
import { getSiteUrl } from "@/lib/site-url";

// Voucher codes: the All deals list, vouchers only (deals whose code is the
// deal: money off a basket, % off, free delivery). The same title row, Most
// loved / New, Filters, List and Cards views and cards as every other list,
// so there's nothing new to learn, and its own address to be found by.
//
// A price drop with a code isn't here: its code is usually for that one
// product, no use to someone after a store's code. It's in the normal lists,
// with its code.
//
// Filters: Deal type shows "Vouchers only" (fixed here), then a Store choice
// (the question people bring here: "is there a Currys code?"), then the
// usual hearts and switches. No Category choice: most vouchers are for the
// whole store and have no category (lib/deal-kinds.ts), so one would hide
// exactly the codes people come here for ("20% off everything at ASOS").
//
// Filtered and sorted copies point search engines at /vouchers itself.
export function generateMetadata(): Metadata {
  const month = new Date().toLocaleDateString("en-GB", { month: "long", year: "numeric" });
  const title = `Voucher codes and discount codes for ${month}`;
  const description = "Voucher codes for UK stores, posted and rated by the DealSnap community. Members say which codes work, so you know before you shop.";
  return {
    title,
    description,
    alternates: { canonical: "/vouchers" },
    openGraph: { title, description, url: "/vouchers" },
    twitter: { card: "summary_large_image", title, description },
  };
}

export default async function VouchersPage({
  searchParams,
}: {
  searchParams: Promise<{ view?: string; hearts?: string; when?: string; store?: string }>;
}) {
  const sp = await searchParams;
  const view = parseView(sp.view);
  const when = parseLovedWindow(sp.when);
  const minHearts = parseMinHearts(sp.hearts);
  const store = parseSlug(sp.store);
  const basePath = "/vouchers";

  // One pass over the list already built for this view (cached per build of
  // the deals), as on every other list page.
  const listed = narrowDeals(getDealsForView(view, undefined, undefined, undefined, minHearts, when), "", "", "voucher");
  const deals = narrowDeals(listed, store);
  const firstPage = deals.slice(0, PAGE_SIZE);
  const hasMore = deals.length > firstPage.length;
  const live = listed.filter((d) => !isExpired(d.expiresAt) && !d.endedByMembers).length;

  const facets: Facet[] = [
    { param: "type", locked: true, options: [{ slug: "voucher", name: "Vouchers", icon: "ticket", count: live }] },
    { param: "store", options: getStoreFacet({ kind: "voucher" }, minHearts, store) },
  ];
  const filterQuery = narrowQuery(store);

  const controls = <SortAndFilters active={view} when={when} minHearts={minHearts} filterQuery={filterQuery} facets={facets} basePath={basePath} />;
  const listRow = <SortAndFilters active={view} when={when} basePath={basePath} minHearts={minHearts} filterQuery={filterQuery} facets={facets} inList />;

  return (
    <>
    <JsonLd data={breadcrumbStructuredData([{ name: "Home", href: "/" }, { name: "Voucher codes", href: basePath }], await getSiteUrl())} />
    <BrowseExperience
      fixedType="voucher"
      promos={await getListPromos({ kind: "home" })}
      ads={await getListAds({ kind: "home" })}
      controls={listRow}
      resetKey={`vouchers|${view}|${when}|${minHearts}|${filterQuery}`}
      minHearts={minHearts || undefined}
      filterQuery={filterQuery || undefined}
      view={view !== DEFAULT_VIEW ? view : undefined}
      when={view === "hottest" && when !== DEFAULT_LOVED_WINDOW ? when : undefined}
      divider={lovedDivider(view, when)}
      initialDeals={firstPage}
      initialHasMore={hasMore}
      isEmpty={deals.length === 0}
      heading={
        <div key="heading">
          {/* The same title row as All deals and the browse pages (fixed
              height), so moving between them doesn't make the deals jump. */}
          <div className="flex h-8 items-center gap-3">
            <h1 className="flex min-w-0 items-center gap-2 text-xl font-bold sm:text-2xl">
              <span className="min-w-0 truncate">Voucher codes</span>
              <span className="sr-only"> and discount codes for UK stores, rated by shoppers</span>
            </h1>
          </div>
          <div className="mt-3">{listRow}</div>
        </div>
      }
      listFilterBar={<CategoryPills key="list-filter-bar" activeSlug="vouchers" leading={<CategorySwitcher activeSlug="vouchers" />} />}
      swipeLabel={<SwipeHeader key="swipe-label" controls={controls} title={<span className="min-w-0 truncate">Voucher codes</span>} />}
      sidebar={<SidebarBoxes key="sidebar" facets={facets} />}
      emptyState={
        <EmptyState key="empty-state" icon="ticket">
          <p className="font-medium text-zinc-700 dark:text-zinc-200">No voucher codes right now.</p>
          <p>Found a code anyone can use? Share it.</p>
          <Link href="/submit" className="mt-1 inline-flex items-center gap-1.5 rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
            <Icon name="ticket" className="size-4" />
            Post a voucher
          </Link>
        </EmptyState>
      }
    />
    </>
  );
}
