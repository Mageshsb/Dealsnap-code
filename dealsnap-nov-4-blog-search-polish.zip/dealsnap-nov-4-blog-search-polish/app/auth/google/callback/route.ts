import crypto from "crypto";
import { cookies } from "next/headers";
import { getSiteUrl } from "@/lib/site-url";
import { setSessionCookie } from "@/lib/auth";
import {
  createLoginChallenge,
  createSession,
  createUser,
  findUserByEmail,
  findUserByGoogleSub,
  findUserById,
  linkGoogleAccount,
  setEmailVerified,
  changeUserPassword,
  deleteSessionsForUser,
  type UserRecord,
} from "@/lib/db";
import { GOOGLE_STATE_COOKIE, exchangeGoogleCode, googleSignInReady, suggestUsername } from "@/lib/google-auth";

const TWO_STEP_COOKIE = "dealsnap_2fa";

// Step 2: Google sends the visitor back here. Signs in the member who has
// used this Google account before, or the member with the same (Google-
// checked) email, or makes a new account.
export async function GET(request: Request) {
  const site = await getSiteUrl();
  const fail = (message: string) =>
    Response.redirect(`${site}/login?error=${encodeURIComponent(message)}`, 302);
  if (!googleSignInReady()) return fail("Google sign-in isn't switched on yet.");

  const url = new URL(request.url);
  const jar = await cookies();
  const saved = jar.get(GOOGLE_STATE_COOKIE)?.value;
  jar.delete(GOOGLE_STATE_COOKIE);
  let expected: { state: string; next: string } | null = null;
  try {
    expected = saved ? JSON.parse(saved) : null;
  } catch {
    expected = null;
  }
  const state = url.searchParams.get("state") ?? "";
  const code = url.searchParams.get("code");
  // Pressing Cancel on Google's screen comes back with ?error=access_denied.
  if (url.searchParams.get("error")) return Response.redirect(`${site}/login`, 302);
  if (!expected || !code || expected.state.length !== state.length ||
      !crypto.timingSafeEqual(Buffer.from(expected.state), Buffer.from(state))) {
    return fail("That sign-in took too long. Please try again.");
  }

  const profile = await exchangeGoogleCode(code, `${site}/auth/google/callback`);
  if (!profile) return fail("Google sign-in didn't work. Please try again.");
  if (!profile.emailVerified || !profile.email) return fail("Your Google account's email isn't verified yet.");

  let user: UserRecord | undefined = findUserByGoogleSub(profile.sub);
  let isNew = false;
  if (!user) {
    const byEmail = findUserByEmail(profile.email);
    if (byEmail) {
      user = findUserById(byEmail.id);
      if (user) {
        linkGoogleAccount(user.id, profile.sub);
        // Google has checked the address, so it's confirmed too. An account
        // that hadn't confirmed it may have been opened by someone else in
        // this person's name, waiting for them to arrive: its password is
        // replaced and anyone signed in to it is signed out, so it's theirs
        // alone.
        if (!user.emailVerified) {
          setEmailVerified(user.id);
          changeUserPassword(user.id, crypto.randomBytes(24).toString("base64url"));
          deleteSessionsForUser(user.id);
        }
      }
    } else {
      // A password nobody knows: they sign in with Google, or set one with
      // "Forgot password?" later if they'd like.
      user = createUser(suggestUsername(profile), profile.email, crypto.randomBytes(24).toString("base64url"), { emailVerified: true });
      linkGoogleAccount(user.id, profile.sub);
      isNew = true;
    }
  }
  if (!user || user.deletedAt) return fail("This account has been closed.");
  if (user.suspended) {
    return Response.redirect(`${site}/login?suspended=1&error=${encodeURIComponent("This account is suspended.")}`, 302);
  }

  // Staff with two-step login still need their code.
  if (user.totpEnabled) {
    const challenge = createLoginChallenge(user.id, expected.next);
    jar.set(TWO_STEP_COOKIE, challenge, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 10 * 60,
    });
    return Response.redirect(`${site}/login/verify`, 302);
  }

  await setSessionCookie(createSession(user.id));
  // New members get the "what are you into?" step first, which also tells them
  // the username we picked and where to change it. Then on to where they were going.
  if (isNew) {
    const next = expected.next === "/" ? "" : `&next=${encodeURIComponent(expected.next)}`;
    return Response.redirect(`${site}/welcome?named=1${next}`, 302);
  }
  return Response.redirect(`${site}${expected.next}`, 302);
}
