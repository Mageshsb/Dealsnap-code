import { cookies } from "next/headers";
import { getSiteUrl } from "@/lib/site-url";
import { GOOGLE_STATE_COOKIE, googleSignInReady, newOAuthState } from "@/lib/google-auth";
import { localPath } from "@/lib/local-path";

// Step 1 of "Continue with Google": send the visitor to Google's account
// picker, remembering (in a short-lived cookie) a random check value and
// where to bring them back to afterwards.
export async function GET(request: Request) {
  const site = await getSiteUrl();
  if (!googleSignInReady()) return Response.redirect(`${site}/login`, 302);

  const next = new URL(request.url).searchParams.get("next") ?? "/";
  const safeNext = localPath(next);
  const state = newOAuthState();
  (await cookies()).set(GOOGLE_STATE_COOKIE, JSON.stringify({ state, next: safeNext }), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 10 * 60,
  });

  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID!,
    redirect_uri: `${site}/auth/google/callback`,
    response_type: "code",
    scope: "openid email profile",
    state,
    prompt: "select_account",
  });
  return Response.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`, 302);
}
