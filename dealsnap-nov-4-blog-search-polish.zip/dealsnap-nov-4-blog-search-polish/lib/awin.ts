import {
  getAffiliateProgrammes,
  getAwinFeeds,
  removeAffiliateProgramme,
  setAffiliateProgramme,
  setAwinFeedOn,
  setAwinFeedResult,
  setProgrammeHasList,
  getSiteSetting,
  setSiteSetting,
} from "./db";
import { getSiteSettings } from "./site-settings";
import { logAutomatic } from "./audit";
import { countListedProducts, dropOtherListedProducts, findListedProductRow, writeListedProducts, type AwinProductRow } from "./product-lists";
import { readSecret } from "./secrets";
import {
  CsvReader,
  feedError,
  feedLinkFor,
  feedListLink,
  readCsvProduct,
  readFeedLink,
  readFeedList,
  readFeedProduct,
  readProgramme,
  type AwinProgramme,
  type FeedLink,
  type ListedFeed,
} from "./awin-data";
import { productKey, urlKey } from "./scrape-deal";
import { programmeDomain, unwrapLink } from "./affiliate";

// DealSnap's connection to Awin, with the API token saved in Admin →
// Settings (lib/secrets.ts) and our publisher ID:
//   - check the token works (and fill in the publisher ID if it's missing)
//   - "Sync my stores": every store that has accepted us gets its Awin
//     programme for "Get deal" clicks (lib/affiliate.ts), and stores that
//     drop us lose it
//   - product lists: for the stores switched on, the store's whole list is
//     downloaded each night into its own file (lib/product-lists.ts), so the post form can
//     fill in a product from a store that won't let us read its pages
//     (lib/deal-read.ts). Once the cofounders' deal engine holds every
//     store's products, the form can ask that instead and this part goes.
//
// Awin allows 20 API calls a minute and 5 product-list downloads a minute;
// we stay under both. Only ever talks to api.awin.com.

const API = "https://api.awin.com";

export class AwinError extends Error {}

// ---- staying under Awin's limits ----

type Turns = { api: number[]; feed: number[] };
const TURNS: Turns = ((globalThis as { dealsnapAwinTurns?: Turns }).dealsnapAwinTurns ??= { api: [], feed: [] });
const PER_MINUTE = { api: 15, feed: 4 };

function takeTurn(kind: keyof Turns): boolean {
  const now = Date.now();
  TURNS[kind] = TURNS[kind].filter((t) => now - t < 60_000);
  if (TURNS[kind].length >= PER_MINUTE[kind]) return false;
  TURNS[kind].push(now);
  return true;
}

function credentials(): { token: string; publisherId: string } {
  const token = readSecret("awin_api_token");
  if (!token) throw new AwinError("Save your Awin API token first.");
  return { token, publisherId: getSiteSettings().awinPublisherId };
}

async function awinGet(path: string, token: string, timeoutMs = 15_000): Promise<Response> {
  if (!takeTurn("api")) throw new AwinError("We've asked Awin a lot in the last minute. Try again in a minute.");
  return send(path, token, timeoutMs);
}

async function send(path: string, token: string, timeoutMs: number): Promise<Response> {
  let res: Response;
  try {
    res = await fetch(`${API}${path}`, {
      headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
      signal: AbortSignal.timeout(timeoutMs),
      redirect: "error",
      cache: "no-store",
    });
  } catch {
    throw new AwinError("We couldn't reach Awin just now. Try again in a few minutes.");
  }
  if (res.status === 401 || res.status === 403) {
    throw new AwinError("Awin didn't accept the token. Check it was copied in full, or make a new one in Awin.");
  }
  if (res.status === 429) throw new AwinError("Awin says we've asked too often. Try again in a minute.");
  return res;
}

async function readJson(res: Response): Promise<unknown> {
  if (!res.ok) throw new AwinError(`Awin couldn't answer (error ${res.status}). Try again later.`);
  try {
    return await res.json();
  } catch {
    throw new AwinError("Awin sent back something we couldn't read. Try again later.");
  }
}

// ---- checking the connection ----

export type AwinCheck = { message: string; publisherIdFilled?: string };

export async function checkAwinConnection(): Promise<AwinCheck> {
  const { token, publisherId: saved } = credentials();
  let publisherId = saved;
  // The publisher accounts this token can see (a token belongs to a person,
  // who may be on more than one site's account).
  const body = (await readJson(await awinGet("/accounts?type=publisher", token))) as { accounts?: unknown };
  const accounts = (Array.isArray(body?.accounts) ? body.accounts : [])
    .map((a) => {
      const x = (a ?? {}) as { accountId?: unknown; id?: unknown; accountName?: unknown; name?: unknown };
      const id = String(x.accountId ?? x.id ?? "");
      const name = typeof x.accountName === "string" ? x.accountName : typeof x.name === "string" ? x.name : "";
      return /^[0-9]{1,10}$/.test(id) ? { id, name } : undefined;
    })
    .filter((a): a is { id: string; name: string } => !!a);
  const list = accounts.map((a) => (a.name ? `${a.name} (${a.id})` : a.id)).join(", ");
  let publisherIdFilled: string | undefined;
  if (!publisherId) {
    if (accounts.length !== 1) {
      throw new AwinError(
        accounts.length
          ? `The token works. Which site is this? Add its publisher ID above: ${list}.`
          : "The token works, but it doesn't belong to a publisher account."
      );
    }
    publisherId = publisherIdFilled = accounts[0].id;
    setSiteSetting("awin_publisher_id", publisherId);
  } else if (accounts.length && !accounts.some((a) => a.id === publisherId)) {
    throw new AwinError(`The token works, but not for publisher ID ${publisherId}. It can see: ${list}.`);
  }
  const joined = await joinedProgrammes(token, publisherId);
  const who = accounts.find((a) => a.id === publisherId)?.name;
  return {
    message: `Connected to Awin${who ? ` as ${who}` : ""} (publisher ${publisherId}). ${
      joined.length === 1 ? "1 store has" : `${joined.length} stores have`
    } accepted you so far.${publisherIdFilled ? " We've filled in your publisher ID." : ""}`,
    publisherIdFilled,
  };
}

async function joinedProgrammes(token: string, publisherId: string): Promise<AwinProgramme[]> {
  if (!publisherId) throw new AwinError("Add your Awin publisher ID above first.");
  const body = await readJson(await awinGet(`/publishers/${encodeURIComponent(publisherId)}/programmes?relationship=joined`, token));
  if (!Array.isArray(body)) throw new AwinError("Awin sent back something we couldn't read. Try again later.");
  return body
    .map(readProgramme)
    .filter((p): p is AwinProgramme => !!p)
    .flatMap((p) => {
      const domains = storeDomains(p.domains);
      // (One whose only websites aren't stores, like Awin's own, is left out.)
      return domains.length || !p.domains.length ? [{ ...p, domains }] : [];
    });
}

// Addresses that are never a store's own: Awin itself (its programme for
// publishers shows up as a "store"), and the hosting services stores put
// test and preview copies of their sites on.
const NOT_A_STORE = /(^|\.)(awin1?\.com|affiliatewindow\.com|zanox\.com|vercel\.app|netlify\.app|herokuapp\.com|mybigcommerce\.com|myshopify\.com|azurewebsites\.net|cloudfront\.net|pages\.dev|github\.io)$/;
// Test and preview copies on a store's own address ("securepreview.…", "staging.…").
const TEST_COPY = /^(staging|stage|preview|securepreview|test|uat|dev|qa)[.-]/;

// Awin's websites for a store as "argos.co.uk", once each, without ones a
// website above already covers ("secure.mobiles.co.uk" is in "mobiles.co.uk").
function storeDomains(listed: string[]): string[] {
  const domains = [...new Set(listed.map((d) => programmeDomain(d)))].filter(
    (d): d is string => !!d && !NOT_A_STORE.test(d) && !TEST_COPY.test(d)
  );
  return domains.filter((d) => !domains.some((other) => other !== d && d.endsWith(`.${other}`)));
}

// ---- "Sync my stores" ----

// added and dropped: stores' names, once each, however many websites they have.
export type AwinSync = { added: string[]; dropped: string[]; keptOwn: string[]; noWebsite: string[] };

// Every website of every store that has accepted us gets its Awin programme.
// A store set up by hand isn't changed (someone chose it), and a synced one
// whose store no longer has us is taken off, along with its product list.
export async function syncAwinStores(): Promise<AwinSync> {
  const { token, publisherId } = credentials();
  const joined = await joinedProgrammes(token, publisherId);
  const current = new Map(getAffiliateProgrammes().map((p) => [p.domain, p]));
  const result: AwinSync = { added: [], dropped: [], keptOwn: [], noWebsite: [] };
  const joinedIds = new Set(joined.map((p) => p.merchantId));

  for (const programme of joined) {
    if (!programme.domains.length) result.noWebsite.push(programme.name);
    for (const domain of programme.domains) {
      const was = current.get(domain);
      if (was && !was.synced) {
        // Set up by hand: kept. (Its name is filled in if it's the same store.)
        if (was.network === "awin" && was.merchantId === programme.merchantId) setAffiliateProgramme({ ...was, name: programme.name });
        else result.keptOwn.push(domain);
        continue;
      }
      if (!was && !result.added.includes(programme.name)) result.added.push(programme.name);
      setAffiliateProgramme({ domain, network: "awin", merchantId: programme.merchantId, name: programme.name, synced: true });
    }
  }
  for (const p of current.values()) {
    if (p.synced && p.merchantId && !joinedIds.has(p.merchantId)) {
      removeAffiliateProgramme(p.domain);
      const name = p.name ?? p.domain;
      if (!result.dropped.includes(name)) result.dropped.push(name);
    }
  }
  // A product list is kept only for a store we still have a programme for.
  const left = new Set(getAffiliateProgrammes().map((p) => p.merchantId));
  for (const feed of getAwinFeeds()) if (!left.has(feed.merchantId)) setAwinFeedOn(feed.merchantId, false);
  // Which stores share a product list, so Admin only offers one where
  // there is one. (Only known with the Create-a-Feed link; a failure here
  // doesn't stop the sync.)
  const link = savedFeedLink();
  if (link) {
    try {
      const withList = new Set((await listedFeeds(link)).filter((f) => f.joined).map((f) => f.merchantId));
      for (const id of joinedIds) setProgrammeHasList(id, withList.has(id));
    } catch {
      // Tried again at the next sync.
    }
  }
  return result;
}

// What a sync did, in a sentence or two.
export function describeSync(r: AwinSync): string {
  return [
    r.added.length ? `Added ${r.added.length} store${r.added.length === 1 ? "" : "s"}: ${r.added.join(", ")}.` : "No new stores.",
    r.dropped.length && `No longer with you, so taken off: ${r.dropped.join(", ")}.`,
    r.keptOwn.length && `Left as you set them up: ${r.keptOwn.join(", ")}.`,
    r.noWebsite.length && `Awin gave no website for: ${r.noWebsite.join(", ")}. Add those by hand below.`,
  ]
    .filter(Boolean)
    .join(" ");
}

// A sync, from the button or the nightly check, remembered for Admin: when
// it last ran, what it did, and what went wrong if it failed.
export async function runStoreSync(): Promise<AwinSync> {
  try {
    const result = await syncAwinStores();
    setSiteSetting("awin_synced_at", new Date().toISOString());
    setSiteSetting("awin_sync_note", describeSync(result).slice(0, 1000));
    setSiteSetting("awin_sync_error", "");
    return result;
  } catch (e) {
    setSiteSetting("awin_sync_error", e instanceof AwinError ? e.message : "Something went wrong syncing stores from Awin.");
    throw e;
  }
}

export function lastStoreSync(): { at?: string; note?: string; error?: string } {
  return {
    at: getSiteSetting("awin_synced_at") || undefined,
    note: getSiteSetting("awin_sync_note") || undefined,
    error: getSiteSetting("awin_sync_error") || undefined,
  };
}

// ---- product lists ----

// A link as the products are filed: the store's own product number where its
// links carry one, else the tidied link. Used for both the list and the
// link pasted into the post form, so the two meet.
export function productListKeys(link: string): string[] {
  const shop = unwrapLink(link);
  return [productKey(shop), urlKey(shop)].filter((k): k is string => !!k);
}

const keyOf = (link: string) => productListKeys(link)[0];

export function findListedProduct(link: string): (AwinProductRow & { run: string }) | undefined {
  return findListedProductRow(productListKeys(link));
}

// Enough for the biggest UK stores; a list longer than this is cut short.
const MAX_PRODUCTS = 400_000;
const MAX_LINE = 200_000;
const BATCH = 2_000;
const DOWNLOAD_MS = 20 * 60 * 1000;
// Checked hourly (instrumentation.ts); each list is downloaded about daily.
const REFRESH_EVERY_MS = 23 * 60 * 60 * 1000;
// A list that failed is tried again after this long.
const RETRY_AFTER_MS = 6 * 60 * 60 * 1000;

// One download at a time, whichever started it.
const g = globalThis as { dealsnapAwinRefreshing?: boolean };

export function isRefreshingProductLists(): boolean {
  return !!g.dealsnapAwinRefreshing;
}

// Where a download's products go: written in batches, with a pause between,
// so a big list never holds up the site. The old list stays until the new
// one is fully in, and stays if the download fails.
function productWriter(merchantId: string) {
  const run = Date.now();
  let batch: AwinProductRow[] = [];
  let count = 0;
  return {
    add(product: AwinProductRow | undefined) {
      if (product) batch.push(product);
    },
    full: () => count + batch.length >= MAX_PRODUCTS,
    async flush(all = false) {
      if (!batch.length || (!all && batch.length < BATCH)) return;
      writeListedProducts(merchantId, run, batch);
      count += batch.length;
      batch = [];
      await new Promise((resolve) => setImmediate(resolve));
    },
    finish(): number {
      if (!count) throw new AwinError("The product list came through empty.");
      dropOtherListedProducts(merchantId, run);
      return countListedProducts(merchantId);
    },
  };
}

// A store's product list: from the Create-a-Feed link if one's saved (Awin's
// standard lists, which most stores have), else Awin's newer "enhanced" list
// through the API token (which not every account or store has yet).
async function downloadProductList(merchantId: string): Promise<number> {
  const link = savedFeedLink();
  if (link) return downloadStandardList(merchantId, link);
  const { token, publisherId } = credentials();
  return downloadEnhancedList(merchantId, token, publisherId);
}

function savedFeedLink(): FeedLink | undefined {
  const saved = readSecret("awin_feed_link");
  return saved ? readFeedLink(saved) : undefined;
}

async function fetchFeedFile(url: string, timeoutMs: number): Promise<Response> {
  try {
    return await fetch(url, { signal: AbortSignal.timeout(timeoutMs), cache: "no-store" });
  } catch {
    throw new AwinError("We couldn't reach Awin's product lists just now. It'll be tried again later.");
  }
}

// Which feeds each store has, and whether we're on its programme (kept for
// an hour, as it's the same for every store).
type FeedListCache = { at: number; key: string; feeds: ListedFeed[] };
const feedCache = globalThis as { dealsnapAwinFeedList?: FeedListCache };

async function listedFeeds(link: FeedLink): Promise<ListedFeed[]> {
  const cached = feedCache.dealsnapAwinFeedList;
  if (cached && cached.key === link.key && Date.now() - cached.at < 60 * 60 * 1000) return cached.feeds;
  if (!takeTurn("api")) throw new AwinError("We've asked Awin a lot in the last minute. Try again in a minute.");
  const res = await fetchFeedFile(feedListLink(link), 60_000);
  if (res.status === 401 || res.status === 403) throw new AwinError("Awin didn't accept the product list link. Copy a new one from Create-a-Feed.");
  if (!res.ok) throw new AwinError(`Awin couldn't send its list of product lists (error ${res.status}). Try again later.`);
  const feeds = readFeedList((await res.text()).slice(0, 20_000_000));
  feedCache.dealsnapAwinFeedList = { at: Date.now(), key: link.key, feeds };
  return feeds;
}

// The stores whose product lists the link can fetch (for checking it works).
export async function checkFeedLink(): Promise<{ message: string }> {
  const link = savedFeedLink();
  if (!link) throw new AwinError("Save your Create-a-Feed link first.");
  const feeds = (await listedFeeds(link)).filter((f) => f.joined);
  const stores = new Set(feeds.map((f) => f.merchantId)).size;
  return {
    message: `The product list link works. ${stores === 1 ? "1 of your stores shares" : `${stores} of your stores share`} a product list. Turn one on below with “Use product list”.`,
  };
}

async function downloadStandardList(merchantId: string, link: FeedLink): Promise<number> {
  const feeds = (await listedFeeds(link)).filter((f) => f.merchantId === merchantId && f.joined);
  if (!feeds.length) {
    throw new AwinError("This store doesn't share a product list with you on Awin (a newly joined store can take an hour to appear).");
  }
  if (!takeTurn("feed")) throw new AwinError("Lots of product lists were asked for just now. It'll be tried again soon.");
  const res = await fetchFeedFile(feedLinkFor(link, feeds.map((f) => f.feedId)), DOWNLOAD_MS);
  if (!res.ok || !res.body) throw new AwinError(`Awin couldn't send the product list (error ${res.status}). It'll be tried again later.`);
  const body = link.gzip ? res.body.pipeThrough(new DecompressionStream("gzip")) : res.body;

  const csv = new CsvReader(link.delimiter);
  const decoder = new TextDecoder();
  const writer = productWriter(merchantId);
  let header: string[] | undefined;
  const take = (rows: string[][]) => {
    for (const row of rows) {
      if (!header) header = row.map((h) => h.replace(/^\uFEFF/, "").trim().toLowerCase());
      else writer.add(readCsvProduct(Object.fromEntries(header.map((h, i) => [h, row[i] ?? ""])), keyOf));
    }
  };
  try {
    for await (const chunk of body as unknown as AsyncIterable<Uint8Array>) {
      take(csv.push(decoder.decode(chunk, { stream: true })));
      await writer.flush();
      if (writer.full()) break;
    }
  } catch {
    throw new AwinError("The product list download broke off. It'll be tried again later.");
  }
  take(csv.push(decoder.decode()));
  take(csv.end());
  await writer.flush(true);
  return writer.finish();
}

async function downloadEnhancedList(merchantId: string, token: string, publisherId: string): Promise<number> {
  if (!publisherId) throw new AwinError("Add your Awin publisher ID first.");
  if (!takeTurn("feed")) throw new AwinError("Lots of product lists were asked for just now. It'll be tried again soon.");
  const res = await send(
    `/publishers/${encodeURIComponent(publisherId)}/awinfeeds/download/${encodeURIComponent(merchantId)}-retail-en_GB.jsonl`,
    token,
    DOWNLOAD_MS
  );
  if (res.status === 404 || res.status === 406) {
    throw new AwinError("Awin's newer product lists aren't on for this store. Save your Create-a-Feed link above to use its standard one.");
  }
  if (!res.ok || !res.body) throw new AwinError(`Awin couldn't send the product list (error ${res.status}). It'll be tried again later.`);

  const decoder = new TextDecoder();
  const writer = productWriter(merchantId);
  let rest = "";
  let stoppedWith: string | undefined;
  const take = (line: string) => {
    if (!line.trim() || line.length > MAX_LINE) return;
    let obj: unknown;
    try {
      obj = JSON.parse(line);
    } catch {
      return;
    }
    stoppedWith = feedError(obj);
    if (!stoppedWith) writer.add(readFeedProduct(obj, keyOf));
  };
  try {
    for await (const chunk of res.body as unknown as AsyncIterable<Uint8Array>) {
      rest += decoder.decode(chunk, { stream: true });
      const lines = rest.split("\n");
      rest = lines.pop() ?? "";
      if (rest.length > MAX_LINE) rest = "";
      for (const line of lines) take(line);
      await writer.flush();
      if (writer.full()) break;
    }
  } catch {
    throw new AwinError("The product list download broke off. It'll be tried again later.");
  }
  take(rest + decoder.decode());
  await writer.flush(true);
  if (stoppedWith) throw new AwinError(stoppedWith);
  return writer.finish();
}

// One store's product list, now (Admin's "Refresh" button, or the hourly check).
export async function refreshProductList(merchantId: string): Promise<void> {
  if (g.dealsnapAwinRefreshing) return;
  g.dealsnapAwinRefreshing = true;
  const store = getAffiliateProgrammes().find((p) => p.merchantId === merchantId)?.name ?? `Awin store ${merchantId}`;
  const record = (detail: string) => logAutomatic("auto.list", { label: store, url: "/admin/earnings?show=lists#stores", detail });
  try {
    const products = await downloadProductList(merchantId);
    setAwinFeedResult(merchantId, { products });
    record(`${products.toLocaleString("en-GB")} products`);
  } catch (e) {
    const error = e instanceof AwinError ? e.message : "Something went wrong downloading the product list.";
    setAwinFeedResult(merchantId, { error });
    record(`Didn't work: ${error}`);
  } finally {
    g.dealsnapAwinRefreshing = false;
  }
}

// The hourly check (instrumentation.ts): stores synced about once a day, so
// new approvals start earning without anyone pressing a button, then every
// switched-on list that's due.
const SYNC_EVERY_MS = 23 * 60 * 60 * 1000;

export async function awinUpkeep(): Promise<void> {
  if (g.dealsnapAwinRefreshing) return;
  const { at } = lastStoreSync();
  if (readSecret("awin_api_token") && (!at || Date.now() - new Date(at).getTime() >= SYNC_EVERY_MS)) {
    // (A failure is kept for Admin's dashboard, and tried again next day.)
    await runStoreSync()
      .then((r) => logAutomatic("auto.sync", { label: "Awin", url: "/admin/earnings", detail: describeSync(r) }))
      .catch((e) => {
        setSiteSetting("awin_synced_at", new Date().toISOString());
        logAutomatic("auto.sync", { label: "Awin", url: "/admin/earnings", detail: `Didn't work: ${e instanceof AwinError ? e.message : "something went wrong"}` });
      });
  }
  await refreshDueProductLists();
}

// Every switched-on list that's due, one after another.
async function refreshDueProductLists(): Promise<void> {
  if (g.dealsnapAwinRefreshing || (!readSecret("awin_api_token") && !savedFeedLink())) return;
  const now = Date.now();
  for (const feed of getAwinFeeds()) {
    const age = feed.refreshedAt ? now - new Date(feed.refreshedAt).getTime() : Infinity;
    if (age >= (feed.error ? RETRY_AFTER_MS : REFRESH_EVERY_MS)) await refreshProductList(feed.merchantId);
  }
}
