import { headers } from "next/headers";

// The visitor's address, for the limits on signing up, logging in, reading
// links and the like. How to work it out depends on what the site sits behind:
//   - Cloudflare in front of the live site: set TRUST_CLOUDFLARE_IP=1 and it
//     uses CF-Connecting-IP, which visitors can't set themselves. (Only do this
//     when the site can't be reached except through Cloudflare: otherwise anyone
//     could send that header and dodge every limit by making an address up.)
//   - Otherwise: the last address in X-Forwarded-For, the one the nearest proxy
//     added. The first is whatever the visitor claimed, so using it would let
//     anyone dodge every limit by making one up.
export async function clientIp(): Promise<string> {
  const h = await headers();
  const behindCloudflare = process.env.TRUST_CLOUDFLARE_IP === "1";
  return (behindCloudflare ? h.get("cf-connecting-ip")?.trim() : "") || h.get("x-forwarded-for")?.split(",").at(-1)?.trim() || "unknown";
}
