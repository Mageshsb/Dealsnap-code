"use server";

import { cleanWebsite } from "./stores";
import { MIN_AGE } from "./legal";
import { passwordProblem } from "./password-rules";
import { matchCategoryAndTag, SIGNAL_WEIGHT } from "./categorize-deal";
import { overLimit } from "./rate-limit";
import { BLOCKED_EMAIL_MESSAGE, BLOCKED_WORD_MESSAGE, blockedEmailDomain, blockedWordIn } from "./site-blocks";
import { cookies } from "next/headers";
import { redirect, RedirectType } from "next/navigation";
import { revalidatePath } from "next/cache";
import { missingTwoStep } from "./staff-two-step";
import { keywordMatchInfo, type KeywordMatchInfo } from "./keyword-matches";
import {
  createUser,
  clearDealFixing,
  clearDealCheck,
  markDealChecked,
  findUserByEmail,
  findUserByUsername,
  verifyPassword,
  createSession,
  deleteSession,
  createDeal,
  updateDbDeal,
  setLabelsUnsure,
  markDealEdited,
  recordDealEdit,
  setDbDealStatus,
  deleteDbDeal,
  getUserDealBySlug,
  createComment,
  getCommentOwner,
  editComment,
  deleteComment,
  reportComment,
  withdrawCommentReport,
  withdrawDealReport,
  reportDeal,
  ENDED_REASON,
  hasReportedEnded,
  withdrawEndedReport,
  toggleCommentLike,
  getCommentLikeCount,
  followUser,
  addTagAlert,
  addBrandAlert,
  addStoreAlert,
  addCategoryAlert,
  removeCategoryAlert,
  removeStoreAlert,
  addKeywordAlert,
  removeKeywordAlert,
  getKeywordAlerts,
  setKeywordAlertMaxPrice,
  removeTagAlert,
  removeBrandAlert,
  unfollowUser,
  setFollowMuted,
  updateUserBio,
  clearUserAvatar,
  updateUsername,
  updateUserEmail,
  changeUserPassword,
  nextUsernameChangeAt,
  upsertDealVote,
  clearDealVote,
  recordFailedLogin,
  clearFailedLogins,
  getRecentFailedLogins,
  findUserById,
  countDealsByUserSince,
  countCommentsByUserSince,
  createLoginChallenge,
  getLoginChallenge,
  bumpLoginChallenge,
  deleteLoginChallenge,
  getTotpState,
  setTotpPending,
  enableTotp,
  disableTotp,
  setTotpRecoveryHashes,
  anonymiseAccount,
  getAdminCount,
  isBlockedEitherWay,
  createPasswordReset,
  getPasswordResetUser,
  deletePasswordResets,
  deleteSessionsForUser,
  createEmailConfirmation,
  setEmailVerified,
  getDealEventPicks,
  getLiveEvents,
  setEventPick,
  type VoteDirection,
} from "./db";
import { eraseCommunityMember } from "./community-db";
import { sendEmail, mustConfirmEmail } from "./email";
import { buildConfirmEmailEmail, buildEmailChangedEmail, buildPasswordChangedEmail, buildPasswordResetEmail } from "./account-emails";
import { checkFormTicket, turnstileSiteKey, verifyTurnstile } from "./captcha";
import { getSiteUrl } from "./site-url";
import { setSessionCookie, clearSessionCookie, getSessionToken, getCurrentUser } from "./auth";
import { getCategoryByName, getCategoryGroups, getCategoryBySlug, getTagByName, getTagBySlug } from "./categories";
import { getBrandBySlug, resolvePickedBrand } from "./brands";
import { labelDoubts } from "./deal-labels";
import { slugify } from "./slug";
import { getSiteSettings } from "./site-settings";
import { canRedirectDeal, isStaffRole, mayEditDeal } from "./permissions";
import { dealChanges } from "./deal-changes";
import { editFrom, editHq } from "./deal-edit-from";
import { clashText, dealClash, seenFrom } from "./collisions";
import { MAX_DAYS_AHEAD, londonInputToIso } from "./upcoming";
import { pickAfterTick, tickableEvents } from "./events";
import { isKnownShop, isTrustedPoster } from "./trust";
import { logAudit } from "./audit";
import { canModerateComments, removeCommentAsTeam } from "./comment-moderation";
import { EDIT_WINDOW_MINUTES, MAX_COMMENT_LENGTH, editableUntil } from "./comment-rules";
import { notifyAlertMatches, onDealHeartsChanged, notifyNewComment, notifyNewFollower } from "./notifications";
import { verifyTotp, generateTotpSecret, generateRecoveryCodes, hashRecoveryCode } from "./totp";
import { autofillFromUrl, cleanUrl } from "./scrape-deal";
import { unwrapLink } from "./affiliate";
import { recordAutofillReport } from "./autofill-report";
import {
  getKnownStores,
  getDealBySlug,
  getFreshHearts,
  canonicalStoreName,
  getStores,
  getLearnedCategoryIndex,
  storeWebsiteFor,
  findLiveCode,
} from "./mock-deals";
import { normalizeKeyword, sameKeyword, MAX_ALERT_PRICE, MAX_KEYWORD_LENGTH, MAX_KEYWORD_ALERTS } from "./alert-match";
import { saveAvatar, AvatarUploadError } from "./avatar-storage";
import { cleanDealPhoto, DealPhotoError, fetchDealPhoto, photoDataUrl, type CleanPhoto } from "./deal-images";
import { DEAL_LINK_MAX, DEAL_TITLE_MAX, DESCRIPTION_MAX, MAX_PICTURES, STORE_NAME_MAX, plainDescription } from "./deal-text";
import { clearDealPhoto, getPictures, saveDealPhoto, savePictures, type NewPicture } from "./pictures";
import { mayAddPictures, readAttachedPictures, readInlinePictures, sentPictures } from "./post-pictures";
import { MAX_LINKS, outsideLinks } from "./rich-text";
import { getSiteHosts } from "./site-url";
import { finishRead, getExtensionRead, type DealMetadataResult } from "./deal-read";
import { parseWhereToBuy, parseWhereNote } from "./where-to-buy";
import { parseVoucherCode, parseDelivery } from "./deal-extras";
import { buildOffer, canBeWholeStore, WHOLE_CATEGORY_PREFIX, parseConditions, parseDealKind, parsePriceUnit, OFFER_FIELD_NAMES, type OfferFields } from "./deal-kinds";
import { isValidUsername, USERNAME_RULE } from "./username";
import { formatDate } from "./format";
import { localPath } from "./local-path";
import { clientIp } from "./client-ip";

// New and changed passwords only — existing members keep working as they are.
const SIGNUPS_PER_HOUR_FROM_ONE_PLACE = 5;

// Emails the member a link to confirm their address (see mustConfirmEmail).
async function sendEmailConfirmation(user: { id: string; email: string; username: string }) {
  const link = `${await getSiteUrl()}/confirm-email?token=${createEmailConfirmation(user.id, user.email)}`;
  await sendEmail(buildConfirmEmailEmail(user.email, user.username, link));
}

// Tells the owner their password or email was changed, so they find out at
// once if it wasn't them. The button leads to "Forgot password?". Never allowed
// to get in the way of the change itself.
async function warnAccountChange(kind: "password" | "email", user: { email: string; username: string }, newEmail?: string) {
  try {
    const link = `${await getSiteUrl()}/login/forgot`;
    await sendEmail(
      kind === "password"
        ? buildPasswordChangedEmail(user.email, user.username, link)
        : buildEmailChangedEmail(user.email, user.username, newEmail ?? "", link)
    );
  } catch {
    // The change has been made; a missing warning email is not worth failing it.
  }
}

// "Send it again", from wherever we ask them to confirm. A few times an hour
// at most, so it can't be used to flood an inbox. Returns what to show.
export async function resendEmailConfirmationAction(): Promise<string> {
  const user = await getCurrentUser();
  if (!user) return "Please log in first.";
  if (user.emailVerified) return "Your email is already confirmed.";
  const key = `confirm:${user.id}`;
  if (getRecentFailedLogins(key, 60 * 60 * 1000).count >= 3) return "We've sent a few already. Please check your spam folder, or try again in an hour.";
  recordFailedLogin(key);
  await sendEmailConfirmation(user);
  return `Sent! Check ${user.email}.`;
}
const TWO_STEP_COOKIE = "dealsnap_2fa";

export async function signupAction(formData: FormData) {
  const nextParam = String(formData.get("next") ?? "");
  const back = (message: string): never =>
    redirect(`/signup?error=${encodeURIComponent(message)}${nextParam ? `&next=${encodeURIComponent(nextParam)}` : ""}`);
  const username = String(formData.get("username") ?? "").trim();
  const email = String(formData.get("email") ?? "").trim();
  const password = String(formData.get("password") ?? "");

  // Robot checks: a hidden box only bots fill in, a form sent too fast to be
  // a person, Cloudflare's check once it's set up, and a few sign-ups an hour
  // from one place at most.
  if (String(formData.get("website") ?? "")) back("Something went wrong. Please try again.");
  const check = checkFormTicket(String(formData.get("ticket") ?? ""));
  if (check === "too-fast") back("That was very quick! Please check your details and try again.");
  if (check !== "ok") back("This page timed out. Please try again.");
  const ip = await clientIp();
  if (turnstileSiteKey() && !(await verifyTurnstile(String(formData.get("cf-turnstile-response") ?? ""), ip))) {
    back("We couldn't confirm you're not a robot. Please try again.");
  }
  const ipKey = `signup-ip:${ip}`;
  if (getRecentFailedLogins(ipKey, 60 * 60 * 1000).count >= SIGNUPS_PER_HOUR_FROM_ONE_PLACE) {
    back("Lots of accounts have been made from here recently. Please try again in an hour.");
  }

  // Adults only (alcohol and other age-limited deals are posted here).
  if (formData.get("age") !== "on") back(`Please confirm you're ${MIN_AGE} or over to join.`);
  if (!isValidUsername(username)) {
    back(`Usernames must be ${USERNAME_RULE}`);
  }
  if (!email.includes("@")) {
    back("Enter a valid email address");
  }
  if (blockedEmailDomain(email)) back(BLOCKED_EMAIL_MESSAGE);
  const weak = passwordProblem(password, { username, email });
  if (weak) back(weak);
  if (findUserByUsername(username)) {
    back("That username is already taken");
  }
  if (findUserByEmail(email)) {
    back("An account with that email already exists");
  }

  const user = createUser(username, email, password);
  recordFailedLogin(ipKey);
  await sendEmailConfirmation(user);
  const token = createSession(user.id);
  await setSessionCookie(token);
  // One quick "what are you into?" step, then back to where they were heading
  // (e.g. the deal they'd started posting).
  const next = safeNext(nextParam);
  redirect(next === "/" ? "/welcome" : `/welcome?next=${encodeURIComponent(next)}`);
}

// A same-site path to send someone on to, or the homepage.
function safeNext(raw: string): string {
  return localPath(raw);
}

export async function loginAction(formData: FormData) {
  const email = String(formData.get("email") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  const next = String(formData.get("next") ?? "");

  const settings = getSiteSettings();
  const ip = await clientIp();
  const emailKey = `email:${email.toLowerCase()}`;
  const ipKey = `ip:${ip}`;

  // Lock out password guessing: too many recent failures for this email, or a
  // much larger number from one address (which could be many different emails).
  if (settings.loginProtection) {
    const windowMs = settings.loginLockoutMinutes * 60 * 1000;
    for (const [key, limit] of [[emailKey, settings.loginMaxAttempts], [ipKey, settings.loginMaxAttempts * 4]] as const) {
      const { count, oldest } = getRecentFailedLogins(key, windowMs);
      if (count >= limit) {
        const minutes = Math.max(1, Math.ceil(((oldest ?? Date.now()) + windowMs - Date.now()) / 60000));
        redirect(
          `/login?error=${encodeURIComponent(`Too many failed attempts. Try again in ${minutes} minute${minutes === 1 ? "" : "s"}.`)}`
        );
      }
    }
  }

  const user = verifyPassword(email, password);
  if (!user) {
    if (settings.loginProtection) {
      recordFailedLogin(emailKey);
      recordFailedLogin(ipKey);
    }
    redirect(`/login?error=${encodeURIComponent("Incorrect email or password")}`);
  }
  clearFailedLogins(emailKey);
  if (user.deletedAt) {
    redirect(`/login?error=${encodeURIComponent("Incorrect email or password")}`);
  }
  if (user.suspended) {
    const until = user.suspendedUntil
      ? `until ${new Date(user.suspendedUntil).toLocaleString("en-GB", { dateStyle: "long", timeStyle: "short" })}`
      : "until staff lift it";
    const why = user.suspensionReason ? ` Reason: ${user.suspensionReason}.` : "";
    redirect(`/login?suspended=1&error=${encodeURIComponent(`This account is suspended ${until}.${why}`)}`);
  }

  const safeNext = localPath(next);
  // Two-step login: the password was right, now ask for the authenticator code.
  if (user.totpEnabled) {
    const challenge = createLoginChallenge(user.id, safeNext);
    (await cookies()).set(TWO_STEP_COOKIE, challenge, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 10 * 60,
    });
    redirect("/login/verify");
  }

  const token = createSession(user.id);
  await setSessionCookie(token);
  redirect(safeNext);
}

export async function verifyTwoStepAction(formData: FormData) {
  const jar = await cookies();
  const challengeToken = jar.get(TWO_STEP_COOKIE)?.value ?? "";
  const challenge = challengeToken ? getLoginChallenge(challengeToken) : undefined;
  if (!challenge) redirect(`/login?error=${encodeURIComponent("That sign-in took too long. Please log in again.")}`);
  if (challenge.attempts >= 5) {
    deleteLoginChallenge(challengeToken);
    jar.delete(TWO_STEP_COOKIE);
    redirect(`/login?error=${encodeURIComponent("Too many wrong codes. Please log in again.")}`);
  }

  const code = String(formData.get("code") ?? "").trim();
  const user = findUserById(challenge.userId);
  const state = getTotpState(challenge.userId);
  if (!user || !state.secret) redirect("/login");

  let ok = verifyTotp(state.secret, code);
  if (!ok && code.replace(/[^A-Za-z0-9]/g, "").length === 10) {
    // A one-time recovery code, used instead of the phone. Each works once.
    const hash = hashRecoveryCode(code);
    if (state.recoveryHashes.includes(hash)) {
      setTotpRecoveryHashes(user.id, state.recoveryHashes.filter((h) => h !== hash));
      ok = true;
    }
  }
  if (!ok) {
    bumpLoginChallenge(challengeToken);
    redirect(`/login/verify?error=${encodeURIComponent("That code didn't work. Check your app and try again.")}`);
  }

  deleteLoginChallenge(challengeToken);
  jar.delete(TWO_STEP_COOKIE);
  if (user.suspended) redirect(`/login?suspended=1&error=${encodeURIComponent("This account is suspended.")}`);
  const token = createSession(user.id);
  await setSessionCookie(token);
  redirect(challenge.nextPath || "/");
}

// "Forgot password?": always answers the same way, whether or not the email
// has an account, so the form can't be used to find out who's a member. Limited
// to a few requests an hour per email (and more per network) to stop it being
// used to flood someone's inbox.
export async function requestPasswordResetAction(formData: FormData) {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  if (!email.includes("@")) redirect(`/login/forgot?error=${encodeURIComponent("Enter the email address you signed up with")}`);

  const ip = await clientIp();
  const hour = 60 * 60 * 1000;
  const emailKey = `reset:${email}`;
  const ipKey = `reset-ip:${ip}`;
  const limited = getRecentFailedLogins(emailKey, hour).count >= 3 || getRecentFailedLogins(ipKey, hour).count >= 10;
  if (!limited) {
    recordFailedLogin(emailKey);
    recordFailedLogin(ipKey);
    const row = findUserByEmail(email);
    const user = row ? findUserById(row.id) : undefined;
    if (user && !user.deletedAt) {
      const link = `${await getSiteUrl()}/login/reset?token=${createPasswordReset(user.id)}`;
      await sendEmail(buildPasswordResetEmail(user.email, user.username, link));
    }
  }
  redirect("/login/forgot?sent=1");
}

// Choosing the new password. Every device is signed out (in case someone else
// had the old password), then the member logs in again with the new one.
export async function resetPasswordAction(formData: FormData) {
  const token = String(formData.get("token") ?? "");
  const password = String(formData.get("password") ?? "");
  const user = token ? getPasswordResetUser(token) : undefined;
  if (!user) redirect(`/login/forgot?error=${encodeURIComponent("That link has expired or was already used. Ask for a new one below.")}`);
  const weak = passwordProblem(password, { username: user.username, email: user.email });
  if (weak) redirect(`/login/reset?token=${encodeURIComponent(token)}&error=${encodeURIComponent(weak)}`);
  changeUserPassword(user.id, password);
  await warnAccountChange("password", user);
  // The link came to their inbox, so the address is theirs.
  setEmailVerified(user.id);
  deletePasswordResets(user.id);
  deleteSessionsForUser(user.id);
  clearFailedLogins(`email:${user.email}`);
  redirect(`/login?notice=${encodeURIComponent("Password changed. Log in with your new password.")}`);
}

// Setting up two-step login from profile settings: step 1 makes a secret and
// shows it as a QR code, step 2 confirms the app works by entering a code.
export async function startTwoStepSetupAction() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  setTotpPending(user.id, generateTotpSecret());
  redirect("/settings?s=security");
}

export async function confirmTwoStepSetupAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const state = getTotpState(user.id);
  if (!state.pending) redirect("/settings?s=security");
  if (!verifyTotp(state.pending, String(formData.get("code") ?? ""))) {
    redirect(`/settings?s=security&error=${encodeURIComponent("That code didn't match. Make sure you scanned the latest QR code.")}`);
  }
  const codes = generateRecoveryCodes();
  enableTotp(user.id, state.pending, codes.map(hashRecoveryCode));
  // Shown once, straight after setup. Kept in a short-lived cookie rather than the URL.
  (await cookies()).set("dealsnap_recovery", codes.join(","), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/settings",
    maxAge: 120,
  });
  redirect(`/settings?s=security&success=${encodeURIComponent("Two-step login is on.")}`);
}

export async function cancelTwoStepSetupAction() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  setTotpPending(user.id, null);
  redirect("/settings?s=security");
}

export async function disableTwoStepAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!verifyPassword(user.email, String(formData.get("password") ?? ""))) {
    redirect(`/settings?s=security&row=two-step&error=${encodeURIComponent("Password is incorrect")}`);
  }
  disableTotp(user.id);
  redirect(`/settings?s=security&success=${encodeURIComponent("Two-step login is off.")}`);
}

// UK GDPR: let members take away a copy of their data, or erase their account.
export async function deleteAccountAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const fail = (msg: string): never => redirect(`/settings?s=data&error=${encodeURIComponent(msg)}`);
  if (String(formData.get("confirm") ?? "").trim().toUpperCase() !== "DELETE") fail('Type DELETE to confirm.');
  if (!verifyPassword(user.email, String(formData.get("password") ?? ""))) fail("Password is incorrect.");
  if (user.role === "admin" && getAdminCount() <= 1) fail("You're the only admin. Make someone else an admin first.");
  anonymiseAccount(user.id);
  eraseCommunityMember(user.id);
  await clearSessionCookie();
  revalidatePath("/", "layout");
  redirect("/?accountDeleted=1");
}

export async function logoutAction() {
  const token = await getSessionToken();
  if (token) deleteSession(token);
  await clearSessionCookie();
  redirect("/");
}

export type { DealMetadataResult };

// Called directly from the submit form (not as a <form action>) to pre-fill
// the fields from a pasted link, best-effort. Never throws — every failure
// path returns a user-facing `error` string instead. `editing` is the deal
// being changed, which isn't a duplicate of itself.
// Reading a link makes DealSnap fetch someone else's page, so it's limited
// per visitor: plenty for posting deals, but no use as a free page fetcher
// (or for pointing at one shop over and over).
const LINK_READS_PER_HOUR = 60;

export async function fetchDealMetadataAction(rawUrl: string, editing?: string): Promise<DealMetadataResult> {
  const key = `read-link:${await clientIp()}`;
  if (getRecentFailedLogins(key, 60 * 60 * 1000).count >= LINK_READS_PER_HOUR) {
    return { error: "That's a lot of links in an hour, so we've paused reading them. You can still fill in the details yourself." };
  }
  recordFailedLogin(key);
  try {
    return await finishRead(await autofillFromUrl(rawUrl, getKnownStores(), getLearnedCategoryIndex()), rawUrl, editing);
  } catch {
    return { error: "Something went wrong reading that link, but you can fill in the details yourself." };
  }
}

// "What is it?" on the post form: the tag that some words most likely mean
// ("air fryer" → Small Appliances), from the same word lists autofill uses.
// Used while someone types in the picker, and to pre-fill it from the title.
// Names a tag that exists, and nothing else; limited per visitor.
export async function guessTagAction(text: string): Promise<{ tag: string; confidence: "high" | "check" } | null> {
  const words = String(text ?? "").trim().slice(0, 200);
  if (words.length < 3) return null;
  if (await overLimit("tag-guess", 90)) return null;
  const match = matchCategoryAndTag([{ text: words, weight: SIGNAL_WEIGHT.title }], { learned: getLearnedCategoryIndex(), title: words });
  return match ? { tag: match.tag, confidence: match.confidence } : null;
}

// The post form's "Already posted" note: a live deal at the same store with
// the same code, so a second copy isn't posted. Only live deals (which anyone
// can see anyway), and limited per visitor so it can't be used to sweep codes.
const CODE_CHECKS_PER_HOUR = 120;

export async function codeAlreadyPostedAction(store: string, code: string, editing?: string): Promise<{ slug: string; title: string } | null> {
  const s = String(store ?? "").slice(0, 100);
  const c = String(code ?? "").replace(/\s+/g, "").slice(0, 30);
  if (!s.trim() || c.length < 3) return null;
  const key = `code-check:${await clientIp()}`;
  if (getRecentFailedLogins(key, 60 * 60 * 1000).count >= CODE_CHECKS_PER_HOUR) return null;
  recordFailedLogin(key);
  return findLiveCode(s, c, typeof editing === "string" ? editing : undefined) ?? null;
}

// "Paste image link" in the post form's photo box: downloads a picture from
// its address, through the same safe fetcher as photos found on a deal's link
// (public addresses only, size-capped, re-encoded), and hands the cleaned copy
// back to the form. Limited per visitor like link reading is.
const PHOTO_LINKS_PER_HOUR = 30;

export async function fetchPhotoFromUrlAction(rawUrl: string): Promise<{ photo: string } | { error: string }> {
  const address = String(rawUrl ?? "").trim();
  let url: URL;
  try {
    url = new URL(address);
  } catch {
    return { error: "That doesn't look like a web address. Paste the image's full link, starting with https://" };
  }
  if ((url.protocol !== "https:" && url.protocol !== "http:") || address.length > 2000) {
    return { error: "That doesn't look like a web address. Paste the image's full link, starting with https://" };
  }
  const key = `read-photo:${await clientIp()}`;
  if (getRecentFailedLogins(key, 60 * 60 * 1000).count >= PHOTO_LINKS_PER_HOUR) {
    return { error: "That's a lot of image links in an hour. Please try again a little later, or upload the photo instead." };
  }
  recordFailedLogin(key);
  const photo = await fetchDealPhoto(url.toString());
  if (!photo) return { error: "We couldn't get a picture from that link. Try the image's own address, or upload the photo." };
  return { photo: photoDataUrl(photo) };
}

// A page the browser extension read for the post form (/submit?read=…).
export async function getExtensionReadAction(ticket: string): Promise<DealMetadataResult | null> {
  return getExtensionRead(ticket) ?? null;
}

// How old an account is, in days.
// Whether a description now has a link to another website it didn't have.
function newLinks(before: string, after: string, hosts: string[]): boolean {
  const options = { format: true, hosts, cards: 0 };
  const had = outsideLinks(before, options);
  return outsideLinks(after, options).some((link) => !had.includes(link));
}

function accountAgeDays(createdAt: string): number {
  return (Date.now() - new Date(createdAt).getTime()) / (24 * 60 * 60 * 1000);
}

// Posting limits that stop a brand-new account flooding the site. Staff are exempt.
function postingLimitError(
  user: { id: string; role: string; createdAt: string },
  kind: "deal" | "comment",
  text?: string
): string | null {
  const s = getSiteSettings();
  if (!s.spamProtection || user.role !== "user") return null;
  const isNew = accountAgeDays(user.createdAt) < s.newAccountDays;
  if (kind === "deal") {
    const limit = isNew ? s.newAccountDealsPerDay : s.dealsPerDay;
    const used = countDealsByUserSince(user.id, new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());
    if (used >= limit) {
      return isNew
        ? `New accounts can post ${limit} deal${limit === 1 ? "" : "s"} a day while they get started. Please try again tomorrow.`
        : `You've hit the limit of ${limit} deals a day. Please try again tomorrow.`;
    }
  } else {
    const limit = isNew ? s.newAccountCommentsPerHour : s.commentsPerHour;
    const used = countCommentsByUserSince(user.id, new Date(Date.now() - 60 * 60 * 1000).toISOString());
    if (used >= limit) return `You're commenting very quickly. Please wait a little while before posting again.`;
    if (text) return commentLinkError(user, text);
  }
  return null;
}

// New accounts can't put links in comments (a favourite of spammers).
function commentLinkError(user: { role: string; createdAt: string }, text: string): string | null {
  const s = getSiteSettings();
  if (!s.spamProtection || user.role !== "user" || accountAgeDays(user.createdAt) >= s.newAccountDays) return null;
  if (s.blockLinksFromNewAccounts && /(https?:\/\/|www\.)|\b[a-z0-9-]+\.(com|co\.uk|net|org|io|uk|shop|store|xyz)\b/i.test(text)) {
    return `New accounts can't include links in comments yet. Post the deal itself with "+ Post a deal" instead.`;
  }
  return null;
}

// No more than MAX_LINKS links to other websites in one comment.
async function commentLinksError(text: string): Promise<string | null> {
  const links = outsideLinks(text, { format: false, hosts: await getSiteHosts(), cards: 2 });
  return links.length > MAX_LINKS ? `A comment can have up to ${MAX_LINKS} links to other websites.` : null;
}

// The post form's answers, checked and tidied, for a new deal or a poster's
// changes to one. `keepEnd` is the end date the deal already has, which can
// stay as it is even once it's passed.
type DealForm = {
  deal: Parameters<typeof updateDbDeal>[1];
  photo?: CleanPhoto;
  removePhoto: boolean;
  // The shopping events (Black Friday…) they ticked; only ones on now count.
  events: string[];
  // The pictures in the description, in order (their ids), and the new ones
  // among them, cleaned and given their ids.
  shotOrder: string[];
  shots: NewPicture[];
};

// `ownShots`: the pictures the deal already has (when it's being changed);
// only those can stay in its description.
async function readDealForm(
  formData: FormData,
  keepEnd?: string,
  keepStart?: string,
  ownShots: string[] = []
): Promise<DealForm | { error: string }> {
  const title = String(formData.get("title") ?? "").trim();
  let description = String(formData.get("description") ?? "").replace(/\r\n?/g, "\n").trim();
  // Words the team has blocked site-wide (Admin → Settings → Security).
  if (blockedWordIn(`${title}\n${description}\n${String(formData.get("whereNote") ?? "")}`)) return { error: BLOCKED_WORD_MESSAGE };
  // Only a price drop has prices; the other types have their offer instead.
  const kind = parseDealKind(formData.get("kind"));
  const priced = kind === "price";
  const price = priced ? parseFloat(String(formData.get("price") ?? "")) : 0;
  // The "was" price is optional: with none, the deal simply shows no discount.
  const originalPriceInput = String(formData.get("originalPrice") ?? "").trim();
  const originalPrice = priced && originalPriceInput ? parseFloat(originalPriceInput) : price;
  // The "was" price is the store's RRP (shown as "RRP £x", not crossed out).
  const wasRrp = priced && !!originalPriceInput && formData.get("wasRrp") === "1";
  const offerFields = Object.fromEntries(
    OFFER_FIELD_NAMES.map((name) => [name, String(formData.get(name) ?? "")])
  ) as OfferFields;
  const { offer, error: offerError } = buildOffer(kind, offerFields);
  // A price can be per month/person…, a "from" price, or have cashback to
  // claim afterwards; any type can be limited to new customers, the app…
  const priceUnit = priced ? parsePriceUnit(formData.get("priceUnit")) : undefined;
  const priceFrom = priced && formData.get("priceFrom") === "1";
  const cashbackInput = priced ? String(formData.get("cashback") ?? "").trim() : "";
  const cashback = cashbackInput ? Math.round(parseFloat(cashbackInput) * 100) / 100 : undefined;
  const conditions = parseConditions(formData.getAll("conditions"));
  // A variant of an existing store ("Amazon UK") is saved under its name ("Amazon").
  const store = canonicalStoreName(String(formData.get("store") ?? ""));
  // What it is: a tag or sub-tag from the list (its category comes with it),
  // and who makes it: a brand from the list, or the tag's own maker. A
  // voucher or sale can instead cover a whole category (no tag), or the whole
  // store (neither, and no brand) (lib/deal-kinds.ts).
  const broad = canBeWholeStore(kind);
  const wholeStore = broad && formData.get("scope") === "store";
  const picked = String(formData.get("tag") ?? "");
  const wholeCategory = broad && !wholeStore && picked.startsWith(WHOLE_CATEGORY_PREFIX) ? getCategoryByName(picked.slice(WHOLE_CATEGORY_PREFIX.length)) : undefined;
  const tagInfo = wholeStore || wholeCategory ? undefined : getTagByName(picked);
  const tag = tagInfo?.tag.name ?? "";
  const category = wholeCategory?.name ?? tagInfo?.category.name ?? "";
  const brand = category ? resolvePickedBrand(tag, String(formData.get("brand") ?? "")) : undefined;
  // An in-store deal can go up without a link: it then points at the store's
  // own website (its homepage, which never counts as the same product as
  // anything else), from what we know of the store or what the poster typed.
  const noLink = formData.get("noLink") === "1";
  let rawUrl = String(formData.get("url") ?? "").trim();
  const expiresAtInput = String(formData.get("expiresAt") ?? "").trim();
  const whereToBuy = parseWhereToBuy(formData.get("whereToBuy"));
  const whereNote = parseWhereNote(formData.get("whereNote"), whereToBuy);
  const voucherCode = parseVoucherCode(formData.get("voucherCode"));
  const delivery = parseDelivery(formData.get("delivery"), formData.get("deliveryCost"));
  // A voucher is a code to enter at checkout; money off that comes off by
  // itself is a Sale (the form says so too, with a one-tap switch).
  if (kind === "voucher" && !voucherCode) return { error: "A voucher needs its code. No code to enter? Post it as a Sale" };

  if (noLink && !rawUrl) {
    if (whereToBuy !== "instore") return { error: "Add the link to the deal, or choose In store only" };
    const site = (store && storeWebsiteFor(store)) || cleanWebsite(String(formData.get("storeSite") ?? ""));
    if (!site) return { error: "Add the store's website, like bmstores.co.uk, so people can find it" };
    rawUrl = `https://${site.replace(/^https?:\/\//, "")}/`;
  }

  // What's missing, said plainly (the form checks first, so this is rare).
  if (!rawUrl) return { error: "Add the link to the deal" };
  if (!title) return { error: "Add a title" };
  if (!store) return { error: "Add the store" };
  if (!wholeStore && !category) return { error: canBeWholeStore(kind) ? "Choose which products it's for, or Whole store" : "Choose what it is" };
  if (!wholeCategory && !wholeStore && !tag) return { error: "Choose what it is" };
  if (!description) return { error: "Say why it's a good deal" };
  if (title.length > DEAL_TITLE_MAX) return { error: `Keep the title to ${DEAL_TITLE_MAX} characters or fewer` };
  if (store.length > STORE_NAME_MAX) return { error: `Keep the store's name to ${STORE_NAME_MAX} characters or fewer` };
  if (rawUrl.length > DEAL_LINK_MAX) return { error: "That link is too long. Copy it again from the store's page" };
  if (priced && (!Number.isFinite(price) || !Number.isFinite(originalPrice) || price <= 0 || originalPrice <= 0)) {
    return { error: "Enter valid prices" };
  }
  if (offerError) return { error: offerError };
  if (cashback !== undefined && (!Number.isFinite(cashback) || cashback <= 0 || cashback >= price)) {
    return { error: "Cashback must be less than the price" };
  }
  // Only real web links: the shop's own (taken out of anyone's affiliate
  // link), with tracking/referral tags stripped.
  let url: string;
  try {
    const parsed = new URL(unwrapLink(rawUrl));
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") throw new Error("not a web link");
    url = cleanUrl(parsed);
  } catch {
    return { error: "Enter a valid link starting with http:// or https://" };
  }

  let expiresAt: string | undefined;
  if (expiresAtInput) {
    // End-of-day on the chosen date — a deal posted as expiring "today"
    // should still show for the rest of today, not vanish immediately.
    const parsed = new Date(`${expiresAtInput}T23:59:59`);
    if (Number.isNaN(parsed.getTime())) return { error: "Enter a valid expiry date" };
    if (parsed.getTime() <= Date.now() && expiresAtInput !== keepEnd) return { error: "Expiry date must be in the future" };
    expiresAt = parsed.toISOString();
  }

  // An upcoming deal: when it starts, in UK time (lib/upcoming.ts). A start
  // that's already passed can stay as it was when the deal is edited.
  const startsAtInput = String(formData.get("startsAt") ?? "").trim();
  let startsAt: string | undefined;
  if (startsAtInput) {
    startsAt = londonInputToIso(startsAtInput);
    if (!startsAt) return { error: "Enter a valid start date and time" };
    const at = Date.parse(startsAt);
    if (startsAt !== keepStart) {
      if (at <= Date.now()) return { error: "The start time has passed. Leave it blank if the deal is on now." };
      if (at > Date.now() + MAX_DAYS_AHEAD * 24 * 60 * 60 * 1000) return { error: `A deal can start up to ${MAX_DAYS_AHEAD} days ahead` };
    }
    if (expiresAt && Date.parse(expiresAt) <= at) return { error: "The end date must be after the deal starts" };
  }

  // The photo, from the link or their own, cleaned up into fresh copies (see
  // lib/deal-images.ts). Members' photos are seen by the team along with
  // the rest of the deal before it goes live.
  const photoFile = formData.get("photo");
  let photo: CleanPhoto | undefined;
  if (photoFile instanceof File && photoFile.size > 0) {
    try {
      photo = await cleanDealPhoto(Buffer.from(await photoFile.arrayBuffer()));
    } catch (e) {
      if (e instanceof DealPhotoError) return { error: e.message };
      throw e;
    }
  }

  // Pictures in the description (lib/deal-text.ts): each on its own line.
  // One the deal already has stays; a new one ("[[new:key]]") is the file
  // sent as "<key>.jpg", cleaned like a photo (lib/deal-images.ts) and given
  // its id. Anything else that looks like a picture is dropped, as is a
  // second copy of the same one.
  const pictures = await readInlinePictures(description, sentPictures(formData, "shots"), { max: MAX_PICTURES.deal, own: ownShots });
  if ("error" in pictures) return { error: pictures.error };
  const { order: shotOrder, added: shots } = pictures;
  description = pictures.text;
  if (!plainDescription(description)) return { error: "Say why it's a good deal, as well as adding pictures" };
  if (outsideLinks(description, { format: true, hosts: await getSiteHosts(), cards: 0 }).length > MAX_LINKS) {
    return { error: `The description can have up to ${MAX_LINKS} links to other websites` };
  }
  if (description.length > DESCRIPTION_MAX) return { error: `Keep the description under ${DESCRIPTION_MAX.toLocaleString("en-GB")} characters` };

  return {
    deal: {
      title,
      description,
      kind,
      offer,
      price,
      // A "was" price below the deal price is a typo; show no discount instead.
      originalPrice: Math.max(originalPrice, price),
      wasRrp: wasRrp && originalPrice > price,
      priceUnit,
      priceFrom,
      cashback,
      conditions,
      store,
      category,
      tag,
      brand,
      url,
      expiresAt,
      startsAt,
      whereToBuy,
      whereNote,
      voucherCode,
      delivery,
    },
    photo,
    removePhoto: !photo && formData.get("photoRemoved") === "1",
    shotOrder,
    shots,
    events: formData.getAll("events").filter((v): v is string => typeof v === "string" && tickableEvents(getLiveEvents()).some((e) => e.slug === v)),
  };
}

// Saves the post form's event ticks (Black Friday…) for a deal.
function saveEventTicks(slug: string, form: DealForm, how: { helping: boolean; deliberate: boolean }) {
  const text = `${form.deal.title} ${plainDescription(form.deal.description)}`;
  const current = getDealEventPicks(slug);
  for (const event of tickableEvents(getLiveEvents())) {
    const next = pickAfterTick(event, text, form.events.includes(event.slug), current.get(event.slug), how);
    if (next) setEventPick(slug, event.slug, next);
  }
}

export async function postDealAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const limitError = postingLimitError(user, "deal");
  if (limitError) redirect(`/submit?error=${encodeURIComponent(limitError)}`);
  // Robot checks: the hidden box only bots fill in, and Cloudflare's check
  // once it's set up (staff skip it).
  if (String(formData.get("website") ?? "")) redirect(`/submit?error=${encodeURIComponent("Something went wrong. Please try again.")}`);
  if (turnstileSiteKey() && !isStaffRole(user.role)) {
    const ip = await clientIp();
    if (!(await verifyTurnstile(String(formData.get("cf-turnstile-response") ?? ""), ip))) {
      redirect(`/submit?error=${encodeURIComponent("We couldn't confirm you're not a robot. Please try again.")}`);
    }
  }

  const form = await readDealForm(formData);
  if ("error" in form) redirect(`/submit?error=${encodeURIComponent(form.error)}`);

  // Staff are trusted to post without waiting in the review queue; it's
  // still written to the activity log so admins can see what went up. So are
  // trusted members (see lib/trust.ts), unless the shop is new to the site:
  // those go on the dashboard's "went up without a check" list instead.
  const isStaff = isStaffRole(user.role);
  const trusted = !isStaff && isTrustedPoster(user) && isKnownShop(form.deal.url);
  const goesLive = isStaff || trusted;
  // A second opinion on the type and brand: if autofill disagrees, helpers check it.
  const labelsUnsure = labelDoubts(form.deal).length > 0;
  const slug = createDeal({ ...form.deal, labelsUnsure, userId: user.id, status: goesLive ? "live" : "pending", trusted });
  if (form.photo?.small) await saveDealPhoto(slug, { ...form.photo, small: form.photo.small });
  if (form.shots.length) {
    const id = getUserDealBySlug(slug)?.id;
    if (id) await savePictures("deal", id, form.shotOrder, form.shots, user.id);
  }
  saveEventTicks(slug, form, { helping: false, deliberate: false });
  recordAutofillReport(slug, form.deal.url, String(formData.get("autofillReport") ?? "").slice(0, 2000));
  if (isStaff) {
    logAudit(user, "deal.post", { label: form.deal.title, url: `/deals/${slug}`, targetId: slug });
  }
  if (goesLive) notifyAlertMatches(slug);

  revalidatePath("/");
  // Replace the form in the browser's history, and say it's just been
  // posted: "Back to deals" on the new deal then goes to the deals, not
  // back into the form (or the join pages a guest came through).
  redirect(`/deals/${slug}?posted=1`, RedirectType.replace);
}

// The poster changing their own deal, in the post form. Changes show
// straight away, except a new link, shop or photo on a live deal: those go
// back to the team to check first, so an approved deal can't be swapped for
// somewhere (or something) else. Like OzBargain, which sends link changes to
// moderators, and Pepper (hotukdeals), which locks details once approved.
// The link as the form saves it, so one nobody touched isn't taken for a change.
function tidyLink(raw: string): string {
  try {
    return cleanUrl(new URL(raw));
  } catch {
    return raw;
  }
}

export async function editOwnDealAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const slug = String(formData.get("slug") ?? "");
  const from = editFrom(formData.get("from"));
  const hq = editHq(formData.get("hq"));
  const fromQuery = from ? `from=${from}${hq ? `&hq=${encodeURIComponent(hq)}` : ""}` : "";
  const deal = getUserDealBySlug(slug);
  if (!deal || !mayEditDeal(user, deal) || (deal.postedByUserId !== user.id && missingTwoStep(user))) redirect(`/deals/${slug}`);
  // Someone else changed it after this form was opened: saving now would
  // quietly undo their change, so stop and show their version instead.
  const clash = dealClash(slug, seenFrom(formData), user.id);
  if (clash) {
    const message = clashText(clash, "after you opened this. The form now shows their version: check it, then make your change again if it's still needed.");
    redirect(`/deals/${slug}/edit?clash=${encodeURIComponent(message)}${fromQuery && `&${fromQuery}`}`);
  }
  // Whoever isn't the poster is helping. A helper can't change where a deal
  // points (its link or shop), so whatever was sent for those is ignored and
  // they stay as they are (the form doesn't even show them).
  const helping = deal.postedByUserId !== user.id;
  const locked = helping && !canRedirectDeal(user);
  if (locked) {
    formData.set("url", deal.url);
    formData.set("store", deal.store);
  }

  const form = await readDealForm(
    formData,
    deal.expiresAt?.slice(0, 10),
    deal.startsAt,
    getPictures("deal", deal.id).map((s) => s.id)
  );
  if ("error" in form) {
    redirect(`/deals/${slug}/edit?error=${encodeURIComponent(form.error)}${fromQuery && `&${fromQuery}`}`);
  }
  if (locked) {
    form.deal.url = deal.url;
    form.deal.store = deal.store;
  }

  const photoChange = form.photo ? (deal.image ? "replaced" : "added") : form.removePhoto && deal.image ? "removed" : undefined;
  // The pictures now match the description: new ones in, ones taken out gone.
  const shotChange = await savePictures("deal", deal.id, form.shotOrder, form.shots, user.id);
  const changes = dealChanges(deal, form.deal, photoChange, shotChange);
  updateDbDeal(deal.id, form.deal);
  // A helper saving the deal has checked its labels; a poster changing them
  // gets the same second opinion as a new deal.
  if (helping) setLabelsUnsure(deal.id, false);
  else if (changes.fields.includes("category") || changes.fields.includes("brand")) setLabelsUnsure(deal.id, labelDoubts(form.deal).length > 0);
  saveEventTicks(slug, form, { helping, deliberate: true });
  if (form.photo?.small) await saveDealPhoto(slug, { ...form.photo, small: form.photo.small });
  else if (form.removePhoto && deal.image) clearDealPhoto(slug);
  // The poster changing where their live deal points, or its photo, sends it
  // back to the team (staff and helpers fixing it don't).
  const recheck =
    deal.status === "live" &&
    !helping &&
    !isStaffRole(user.role) &&
    (tidyLink(form.deal.url) !== tidyLink(deal.url) ||
      form.deal.store !== deal.store ||
      !!form.photo ||
      (form.removePhoto && !!deal.image) ||
      // New pictures are checked like a new photo; taking one away isn't.
      shotChange.added > 0 ||
      // So is a new link to another website in the description.
      newLinks(deal.description, form.deal.description, await getSiteHosts()));
  if (recheck) setDbDealStatus(deal.id, "pending");

  // Only a real change shows as "edited", is logged and counts towards
  // anyone's numbers: a save that changes nothing (or only spacing, capitals
  // or punctuation) leaves no trace.
  // A helper or the team saving it has looked it over ("Checked by DealSnap
  // helpers"); the poster changing it means what was checked has changed.
  if (helping) markDealChecked(slug, user.id);
  else if (changes.fields.length > 0) clearDealCheck(slug);
  if (changes.fields.length > 0) {
    markDealEdited(deal.id);
    recordDealEdit(slug, user.id, changes.fields, !helping);
    if (helping) logAudit(user, "deal.edit", { label: form.deal.title, url: `/deals/${slug}`, targetId: slug, detail: changes.text });
  }

  clearDealFixing(slug, user.id);
  revalidatePath("/");
  revalidatePath(`/deals/${slug}`);
  // From the helper desk, straight back to the same view of it, saying what
  // was saved: it's a list to work through, so the next one is right there.
  if (from === "helper" && helping) {
    revalidatePath("/helper");
    redirect(`/helper?${hq ? `${hq}&` : ""}saved=${encodeURIComponent(slug)}`, RedirectType.replace);
  }
  redirect(`/deals/${slug}?edited=${recheck ? "recheck" : "1"}${fromQuery && `&${fromQuery}`}`, RedirectType.replace);
}

// Taking back a deal that's still waiting for the team. Once it's live,
// people may have loved it or commented, so it's marked as ended instead.
export async function withdrawOwnDealAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const slug = String(formData.get("slug") ?? "");
  const deal = getUserDealBySlug(slug);
  if (!deal || deal.postedByUserId !== user.id || deal.status !== "pending") redirect(`/deals/${slug}`);
  deleteDbDeal(deal.id);
  revalidatePath("/profile");
  redirect("/profile", RedirectType.replace);
}

// A new comment, or a reply to one (targetId), from the box under the deal or
// in a thread. No page reload: it hands back the new comment's id, so the box
// can bring it into view, or the problem to show under the box.
export async function postCommentAction(
  dealSlug: string,
  targetId: string | null,
  rawText: string,
  sent?: FormData
): Promise<{ id: string } | { error: string }> {
  const user = await getCurrentUser();
  if (!user) return { error: "Log in to join in." };
  if (mustConfirmEmail(user)) return { error: "Confirm your email address before commenting." };
  const deal = getDealBySlug(dealSlug);
  if (!deal || deal.status === "pending") return { error: "You can't comment on this deal." };

  const text = String(rawText ?? "").trim();
  if (!text) return { error: "Write something first." };
  if (text.length > MAX_COMMENT_LENGTH) return { error: `Comments can be up to ${MAX_COMMENT_LENGTH} characters.` };
  if (blockedWordIn(text)) return { error: BLOCKED_WORD_MESSAGE };
  const limitError = postingLimitError(user, "comment", text) ?? (await commentLinksError(text));
  if (limitError) return { error: limitError };
  // Pictures under it (lib/post-pictures.ts), cleaned before anything is saved.
  const files = sent instanceof FormData ? sent.getAll("pictures").filter((f): f is File => f instanceof File && f.size > 0) : [];
  if (files.length && !mayAddPictures(user)) return { error: "New accounts can add pictures once they've been here a little while." };
  const pictures = files.length ? await readAttachedPictures(files, MAX_PICTURES.comment) : [];
  if ("error" in pictures) return { error: pictures.error };

  const comment = createComment(dealSlug, user.id, text, targetId);
  if (!comment) return { error: "That comment has been deleted, so it can't be replied to." };
  if (pictures.length) await savePictures("comment", comment.id, pictures.map((p) => p.id), pictures, user.id);
  notifyNewComment({ dealSlug, commentId: comment.id, rootId: comment.parentId, replyToId: comment.replyToId, author: user, text });
  revalidatePath(`/deals/${dealSlug}`);
  return { id: comment.id };
}

// A member changing or deleting their own comment, from the comment itself
// (no page reload). Returns the error to show, or null once it's saved.
export async function editOwnCommentAction(commentId: string, text: string): Promise<string | null> {
  const user = await getCurrentUser();
  const comment = getCommentOwner(commentId);
  if (!user || !comment || comment.userId !== user.id || comment.deleted) return "You can't change this comment.";
  if (Date.now() > editableUntil(comment.createdAt)) {
    return `Comments can only be changed for ${EDIT_WINDOW_MINUTES} minutes after posting. You can still delete it.`;
  }
  const clean = text.trim();
  if (!clean) return "Write something, or delete the comment instead.";
  if (clean.length > MAX_COMMENT_LENGTH) return `Comments can be up to ${MAX_COMMENT_LENGTH} characters.`;
  if (blockedWordIn(clean)) return BLOCKED_WORD_MESSAGE;
  const linkError = commentLinkError(user, clean) ?? (await commentLinksError(clean));
  if (linkError) return linkError;
  editComment(commentId, clean);
  revalidatePath(`/deals/${comment.dealSlug}`);
  return null;
}

export async function deleteOwnCommentAction(commentId: string): Promise<boolean> {
  const user = await getCurrentUser();
  const comment = getCommentOwner(commentId);
  if (!user || !comment || comment.userId !== user.id) return false;
  deleteComment(commentId);
  revalidatePath(`/deals/${comment.dealSlug}`);
  return true;
}

// A moderator or admin removing a comment from its "⋯" menu on the deal
// page: the same rules and log entry as removing it in the admin area.
export async function removeCommentAction(commentId: string): Promise<boolean> {
  const user = await getCurrentUser();
  if (!canModerateComments(user)) return false;
  return removeCommentAsTeam(user, commentId);
}

// Called from a comment's "⋯" menu: reports (or, for Undo, un-reports) a
// comment without leaving or refreshing the page (the link already shows the
// change). Returns the new state, or null for guests.
export async function setCommentReportAction(commentId: string, reported: boolean): Promise<boolean | null> {
  const user = await getCurrentUser();
  if (!user) return null;
  if (reported) reportComment(commentId, user.id);
  else withdrawCommentReport(commentId, user.id);
  return reported;
}

// Called directly from CommentLikeButton (a client component), mirroring
// voteOnDealAction — the caller renders its own optimistic state, this just
// persists the like and hands back the authoritative count to reconcile
// against. Returns null for guests.
export async function likeCommentAction(
  commentId: string
): Promise<{ liked: boolean; likeCount: number } | null> {
  const user = await getCurrentUser();
  if (!user) return null;

  const liked = toggleCommentLike(commentId, user.id);
  return { liked, likeCount: getCommentLikeCount(commentId) };
}

// Called from DealTellUs (the Report link under a deal). Report is for
// anything other than "it's ended" (which has its own link), so there's no
// reason to pick; staff read the deal. reported=false takes it back (Undo).
// Returns the new state, or null for guests. Like setDealEndedAction it
// doesn't refresh the page: the link already shows the change, and a refresh
// could shift the page under the reader's thumb.
export async function setDealReportAction(dealSlug: string, reported: boolean): Promise<boolean | null> {
  const user = await getCurrentUser();
  if (!user) return null;
  if (reported) reportDeal(dealSlug, user.id, "Other");
  else withdrawDealReport(dealSlug, user.id);
  return reported;
}

// "Deal ended?" on the deal page, called straight from DealTellUs (a
// client component). ended=false takes it back. It deliberately doesn't
// refresh the page: the link already shows the change, and a refresh would
// slide in the "members say this may have ended" line above the reader and
// shake the page. Lists and the deal page are rendered fresh on every visit,
// so everyone else sees it next time they load. Enough members (or one member
// of staff, or the deal's poster) mark the deal expired — see
// applyEndedReports in lib/mock-deals.ts. Returns null for guests, which puts
// the button back how it was.
export async function setDealEndedAction(dealSlug: string, ended: boolean): Promise<boolean | null> {
  const user = await getCurrentUser();
  if (!user) return null;
  const deal = getDealBySlug(dealSlug);
  if (!deal) return null;

  const already = hasReportedEnded(dealSlug, user.id);
  if (!ended && already) {
    withdrawEndedReport(dealSlug, user.id);
  } else if (ended && !already) {
    reportDeal(dealSlug, user.id, ENDED_REASON);
    if (isStaffRole(user.role) || user.role === "helper") logAudit(user, "deal.ended", { label: deal.title, url: `/deals/${dealSlug}`, targetId: dealSlug });
  }
  return ended;
}

// Called directly from VoteButton (a client component) rather than bound to
// a <form> — the caller already renders its own optimistic state, this just
// persists the vote and hands back the authoritative total to reconcile
// against, so a mis-predicted optimistic delta can't drift from reality.
// Returns null for guests, who keep the old local-only (non-persisted) vote
// behavior unchanged.
// `vote` is the member's vote after the tap: null when they took it back.
// Also returns what the vote was worth, so the button can take back exactly
// that much later.
export async function voteOnDealAction(
  dealSlug: string,
  vote: VoteDirection | null
): Promise<{ hearts: number; weight: number | null } | null> {
  const user = await getCurrentUser();
  if (!user) return null;

  const weight = vote ? upsertDealVote(user.id, dealSlug, vote) : null;
  if (!vote) clearDealVote(user.id, dealSlug);
  if (vote === "love") onDealHeartsChanged(dealSlug);
  // The true count, read fresh: the kept lists can be a few seconds behind, which
  // used to snap the number back after a quick tap-and-untap.
  const hearts = getFreshHearts(dealSlug);
  return hearts === undefined ? null : { hearts, weight };
}

// Bell button on tag pages and the Alerts tab. Logged-out visitors get
// { needsLogin } back so the button can send them to sign in and return.
export async function setTagAlertAction(tagSlug: string, on: boolean): Promise<{ ok: boolean; needsLogin?: boolean }> {
  const user = await getCurrentUser();
  if (!user) return { ok: false, needsLogin: true };
  if (!getTagBySlug(tagSlug)) return { ok: false };
  if (on) addTagAlert(user.id, tagSlug);
  else removeTagAlert(user.id, tagSlug);
  return { ok: true };
}

// Same as the tag bell, for a category page. New category alerts wait for 25 hearts
// (the table's default), since a whole category is a lot of deals.
export async function setCategoryAlertAction(categorySlug: string, on: boolean): Promise<{ ok: boolean; needsLogin?: boolean }> {
  const user = await getCurrentUser();
  if (!user) return { ok: false, needsLogin: true };
  if (!getCategoryBySlug(categorySlug)) return { ok: false };
  if (on) addCategoryAlert(user.id, categorySlug);
  else removeCategoryAlert(user.id, categorySlug);
  return { ok: true };
}

// The welcome step after signing up: the categories ticked become category
// alerts (waiting for 25 hearts, like the bell on a category page), and any they
// unticked on a second visit are switched off. Then on to where they were going.
export async function saveInterestsAction(formData: FormData) {
  const user = await getCurrentUser();
  const next = safeNext(String(formData.get("next") ?? ""));
  if (!user) redirect("/login");
  const picked = new Set(formData.getAll("category").map(String));
  for (const group of getCategoryGroups()) {
    const slug = slugify(group.name);
    if (picked.has(slug)) addCategoryAlert(user.id, slug);
    else removeCategoryAlert(user.id, slug);
  }
  redirect(next);
}

// Same as the tag bell, for a brand page.
export async function setBrandAlertAction(brandSlug: string, on: boolean): Promise<{ ok: boolean; needsLogin?: boolean }> {
  const user = await getCurrentUser();
  if (!user) return { ok: false, needsLogin: true };
  if (!getBrandBySlug(brandSlug)) return { ok: false };
  if (on) addBrandAlert(user.id, brandSlug);
  else removeBrandAlert(user.id, brandSlug);
  return { ok: true };
}

// Same as the tag bell, for a store page. storeKey is the store's stable key.
export async function setStoreAlertAction(storeKey: string, on: boolean): Promise<{ ok: boolean; needsLogin?: boolean }> {
  const user = await getCurrentUser();
  if (!user) return { ok: false, needsLogin: true };
  if (!getStores().some((s) => s.key === storeKey)) return { ok: false };
  if (on) addStoreAlert(user.id, storeKey);
  else removeStoreAlert(user.id, storeKey);
  return { ok: true };
}

export async function addKeywordAlertAction(
  raw: string
): Promise<{ ok: true; alert: { id: string; keyword: string }; info: KeywordMatchInfo } | { ok: false; error: string; needsLogin?: boolean }> {
  const user = await getCurrentUser();
  if (!user) return { ok: false, error: "Log in to add alerts.", needsLogin: true };
  if (raw.trim().length > MAX_KEYWORD_LENGTH) return { ok: false, error: `Keep it under ${MAX_KEYWORD_LENGTH} characters.` };
  const keyword = normalizeKeyword(raw);
  if (keyword.length < 2) return { ok: false, error: "Type at least 2 letters or numbers." };
  const existing = getKeywordAlerts(user.id);
  if (existing.some((k) => sameKeyword(k.keyword, keyword))) return { ok: false, error: "You already have that alert." };
  if (existing.length >= MAX_KEYWORD_ALERTS) {
    return { ok: false, error: `You can have up to ${MAX_KEYWORD_ALERTS} keyword alerts — remove one first.` };
  }
  const alert = addKeywordAlert(user.id, keyword);
  if (!alert) return { ok: false, error: "You already have that alert." };
  return { ok: true, alert: { id: alert.id, keyword }, info: keywordMatchInfo(keyword) };
}

// "Up to £700" on a keyword alert, or any price (null).
export async function setKeywordAlertPriceAction(
  id: string,
  maxPrice: number | null
): Promise<{ ok: true; info: KeywordMatchInfo } | { ok: false }> {
  const user = await getCurrentUser();
  if (!user) return { ok: false };
  const alert = getKeywordAlerts(user.id).find((k) => k.id === id);
  if (!alert) return { ok: false };
  const price = maxPrice === null ? null : Math.round(maxPrice * 100) / 100;
  if (price !== null && !(price >= 1 && price <= MAX_ALERT_PRICE)) return { ok: false };
  setKeywordAlertMaxPrice(user.id, id, price);
  return { ok: true, info: keywordMatchInfo(alert.keyword, price ?? undefined) };
}

export async function removeKeywordAlertAction(id: string): Promise<{ ok: boolean }> {
  const user = await getCurrentUser();
  if (!user) return { ok: false };
  removeKeywordAlert(user.id, id);
  return { ok: true };
}

export async function followAction(targetUserId: string) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.id === targetUserId || isBlockedEitherWay(user.id, targetUserId)) return;
  followUser(user.id, targetUserId);
  notifyNewFollower(user, targetUserId);
}

export async function unfollowAction(targetUserId: string) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  unfollowUser(user.id, targetUserId);
}

export async function setFollowMutedAction(targetUserId: string, muted: boolean) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  setFollowMuted(user.id, targetUserId, muted);
}

// Settings → Name, photo & bio: one Save for the photo, bio and username.
// The username is checked first, so nothing is saved if it's refused.
export async function updateProfileAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const fail = (message: string): never => redirect(`/settings?s=profile&error=${encodeURIComponent(message)}`);

  const bio = String(formData.get("bio") ?? "").trim().slice(0, 280);
  const newUsername = String(formData.get("username") ?? user.username).trim();
  const renaming = newUsername !== user.username;
  if (renaming) {
    const cooldownUntil = nextUsernameChangeAt(user.usernameChangedAt);
    if (cooldownUntil) fail(`You can change your username again on ${formatDate(cooldownUntil)}`);
    if (!isValidUsername(newUsername)) fail(`Usernames must be ${USERNAME_RULE}`);
    const taken = findUserByUsername(newUsername);
    if (taken && taken.id !== user.id) fail("That username is already taken");
  }

  const avatarFile = formData.get("avatar");
  if (avatarFile instanceof File && avatarFile.size > 0) {
    let message: string | undefined;
    try {
      await saveAvatar(user.id, avatarFile);
    } catch (err) {
      message = err instanceof AvatarUploadError ? err.message : "Couldn't upload that image.";
    }
    if (message) fail(message);
  }

  updateUserBio(user.id, bio);
  if (renaming) updateUsername(user.id, newUsername);
  // The photo and name also show in the header on every page via the root
  // layout — a page-level revalidation wouldn't reach that.
  revalidatePath("/", "layout");
  redirect(`/settings?s=profile&success=${encodeURIComponent("Saved")}`);
}

export async function removeAvatarAction() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  clearUserAvatar(user.id);
  revalidatePath("/", "layout");
  redirect(`/settings?s=profile&success=${encodeURIComponent("Profile picture removed")}`);
}

export async function changeEmailAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const newEmail = String(formData.get("email") ?? "").trim();
  const currentPassword = String(formData.get("currentPassword") ?? "");

  if (!newEmail.includes("@")) {
    redirect(`/settings?s=security&row=email&error=${encodeURIComponent("Enter a valid email address")}`);
  }
  if (blockedEmailDomain(newEmail)) {
    redirect(`/settings?s=security&row=email&error=${encodeURIComponent(BLOCKED_EMAIL_MESSAGE)}`);
  }
  if (!verifyPassword(user.email, currentPassword)) {
    redirect(`/settings?s=security&row=email&error=${encodeURIComponent("Current password is incorrect")}`);
  }
  if (newEmail.toLowerCase() !== user.email && findUserByEmail(newEmail)) {
    redirect(
      `/settings?s=security&row=email&error=${encodeURIComponent("An account with that email already exists")}`
    );
  }

  const changed = newEmail.toLowerCase() !== user.email;
  updateUserEmail(user.id, newEmail, { verified: !changed && user.emailVerified });
  if (changed) {
    // The old address hears about it too: if someone else did this, that's how the owner finds out.
    await warnAccountChange("email", user, newEmail.toLowerCase());
    await sendEmailConfirmation({ ...user, email: newEmail.toLowerCase() });
  }
  revalidatePath("/profile");
  redirect(
    `/settings?s=security&success=${encodeURIComponent(changed ? "Email updated. We've sent a link to confirm it." : "Email updated")}`
  );
}

export async function changePasswordAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const currentPassword = String(formData.get("currentPassword") ?? "");
  const newPassword = String(formData.get("newPassword") ?? "");
  const confirmPassword = String(formData.get("confirmPassword") ?? "");

  if (!verifyPassword(user.email, currentPassword)) {
    redirect(`/settings?s=security&row=password&error=${encodeURIComponent("Current password is incorrect")}`);
  }
  const weak = passwordProblem(newPassword, { username: user.username, email: user.email });
  if (weak) redirect(`/settings?s=security&row=password&error=${encodeURIComponent(weak)}`);
  if (newPassword !== confirmPassword) {
    redirect(`/settings?s=security&row=password&error=${encodeURIComponent("New passwords don't match")}`);
  }

  changeUserPassword(user.id, newPassword);
  await warnAccountChange("password", user);
  // Anyone else signed in with the old password is signed out (this device
  // stays signed in).
  deleteSessionsForUser(user.id, await getSessionToken());
  redirect(`/settings?s=security&success=${encodeURIComponent("Password updated. Any other devices have been signed out.")}`);
}
