import { getCampaign, getCampaignReport, type AdCampaignRow } from "./db";
import { sign, signatureMatches } from "./secrets";
import { flushAdCounts } from "./ad-serving";
import { ukDay } from "./events";
import { earned, slotName } from "./ads";

// An advertiser's report link: /ad-report/<campaign>/<signature>. Anyone with
// the link sees that one campaign's live numbers (read-only), so it can be
// emailed to the advertiser instead of spreadsheets. The signature is made
// with the site's secret key (lib/secrets.ts), so links can't be guessed or
// made from a copy of the database, and nothing secret is stored. Making a
// new link, or turning it off, stops the old one; it also stops 90 days after
// the campaign ends.
const PURPOSE = "ad-report";
const KEEP_DAYS_AFTER_END = 90;

export function reportPath(c: Pick<AdCampaignRow, "id" | "reportKey">): string | undefined {
  if (!c.reportKey) return undefined;
  return `/ad-report/${c.id}/${sign(PURPOSE, `${c.id}:${c.reportKey}`)}`;
}

export function reportExpires(c: Pick<AdCampaignRow, "endsOn">): string | undefined {
  if (!c.endsOn) return undefined;
  return ukDay(new Date(Date.parse(`${c.endsOn}T12:00:00Z`) + KEEP_DAYS_AFTER_END * 86_400_000));
}

// The campaign a report link is for, if the link is real and still works.
export function campaignForReport(id: string, token: string): AdCampaignRow | undefined {
  if (!/^[0-9a-f-]{36}$/.test(id) || !/^[A-Za-z0-9_-]{20,64}$/.test(token)) return undefined;
  const c = getCampaign(id);
  if (!c?.reportKey || !signatureMatches(PURPOSE, `${c.id}:${c.reportKey}`, token)) return undefined;
  const expires = reportExpires(c);
  if (expires && ukDay() > expires) return undefined;
  return c;
}

// The report's numbers, up to the moment (counts waiting in memory are saved first).
export function reportFor(c: AdCampaignRow) {
  flushAdCounts();
  const report = getCampaignReport(c.id);
  const views = report.days.reduce((n, d) => n + d.views, 0);
  const clicks = report.days.reduce((n, d) => n + d.clicks, 0);
  return { ...report, views, clicks, today: report.days.find((d) => d.day === ukDay())?.views ?? 0, cost: earned(c, views) };
}

// A spreadsheet (CSV) of the report, one row a day. `costs`: include the money.
const cell = (v: string | number) => {
  const s = String(v);
  // Quoted, and a leading = + - @ is defused so a spreadsheet never runs it as a formula.
  return `"${(/^[=+\-@\t\r]/.test(s) ? `'${s}` : s).replace(/"/g, '""')}"`;
};

export function reportCsv(c: AdCampaignRow, costs: boolean): { body: string; filename: string } {
  const r = reportFor(c);
  const rate = (v: number, k: number) => (v ? ((k / v) * 100).toFixed(2) : "0");
  const lines = [["Campaign", "Advertiser", "Day", "Views", "Clicks", "Click rate %"].map(cell).join(",")];
  for (const d of [...r.days].reverse()) lines.push([c.name, c.shownName, d.day, d.views, d.clicks, rate(d.views, d.clicks)].map(cell).join(","));
  lines.push("");
  lines.push([cell("Total"), "", "", cell(r.views), cell(r.clicks), cell(rate(r.views, r.clicks))].join(","));
  if (costs && c.pricing !== "none") lines.push([cell("Cost so far (£)"), "", "", cell((r.cost / 100).toFixed(2))].join(","));
  lines.push([cell("Ad spaces"), cell(r.slots.map((s) => slotName(s.slot)).join("; "))].join(","));
  const filename = `${c.name.replace(/[^A-Za-z0-9-]+/g, "-").slice(0, 60) || "campaign"}-report.csv`;
  return { body: lines.join("\r\n"), filename };
}

export function csvResponse({ body, filename }: { body: string; filename: string }): Response {
  return new Response(body, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "private, no-store",
      "X-Robots-Tag": "noindex",
    },
  });
}
