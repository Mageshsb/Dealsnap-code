import type { IconName } from "@/components/Icon";

// "My account": one place for everything about a signed-in member. This one
// list, in this order, is the desktop sidebar and the phone My account page.
export const ACCOUNT_LINKS = [
  { href: "/profile", icon: "id-card" as IconName, label: "My profile", badge: false },
  { href: "/notifications", icon: "bell" as IconName, label: "Notifications", badge: true },
  { href: "/saved", icon: "bookmark" as IconName, label: "Saved deals", badge: false },
  { href: "/alerts", icon: "target" as IconName, label: "Alerts", badge: false },
  { href: "/feed", icon: "users" as IconName, label: "Following feed", badge: false },
  { href: "/settings", icon: "settings" as IconName, label: "Settings", badge: false },
] as const;

// "/helper": the Helper desk, shown in the menu for helpers only.
export type AccountHref = (typeof ACCOUNT_LINKS)[number]["href"] | "/account" | "/helper";

export const SETTINGS_SECTIONS = [
  { key: "profile", label: "Name, photo & bio", icon: "image" as IconName, blurb: "Your username, photo and bio: what other people see." },
  { key: "security", label: "Sign-in & security", icon: "lock-keyhole" as IconName, blurb: "Your email, password and two-step login." },
  { key: "notifications", label: "Notification settings", icon: "bell" as IconName, blurb: "What you're told about, and how." },
  { key: "blocked", label: "Blocked members", icon: "ban" as IconName, blurb: "People you've blocked, and what blocking does." },
  { key: "data", label: "Your data", icon: "download" as IconName, blurb: "Download a copy, or close your account." },
] as const;

export type SettingsKey = (typeof SETTINGS_SECTIONS)[number]["key"];
