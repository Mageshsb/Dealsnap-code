// The category › tag › sub-tag tree, read from the database (Admin → Tags and
// brands), with the lookups over it. This is the server's copy: the rules
// themselves live in lib/taxonomy-shared.ts, which the browser shares (it is
// handed the tree by components/TaxonomyProvider.tsx, as it can't read the
// database).
//
// The tree is read once and kept. Saving here drops it at once; a change made
// by another copy of the site (or by hand) is seen within a second, because
// every change moves a counter in the database.

import { getLabelAliases, getTaxonomyRows, getTaxonomyVersion } from "./db";
import { isIconName } from "@/components/Icon";
import { slugify } from "./slug";
import { buildTaxonomy, type CategoryGroup, type Tag, type TagInfo, type Taxonomy } from "./taxonomy-shared";

export type { CategoryGroup, CategorySuggestion, DealLook, Tag, TagInfo, TagSuggestion, Taxonomy } from "./taxonomy-shared";

type Built = { version: number; tax: Taxonomy; client: CategoryGroup[]; aliases: { tag: Map<string, number>; category: Map<string, number> } };
let built: Built | undefined;
let checkedAt = 0;
const RECHECK_MS = 1000;

function loadGroups(): CategoryGroup[] {
  const { categories, tags } = getTaxonomyRows();
  const icon = (name: string) => (isIconName(name) ? name : "tag");
  const subs = new Map<number, Tag[]>();
  for (const t of tags) {
    if (t.parentId === undefined) continue;
    const list = subs.get(t.parentId) ?? [];
    list.push({ id: t.id, name: t.name, icon: icon(t.icon), maker: t.maker, builtin: t.builtin });
    subs.set(t.parentId, list);
  }
  return categories.map((c) => ({
    id: c.id,
    name: c.name,
    icon: icon(c.icon),
    hue: c.hue,
    builtin: c.builtin,
    tags: tags
      .filter((t) => t.categoryId === c.id && t.parentId === undefined)
      .map((t) => ({ id: t.id, name: t.name, icon: icon(t.icon), maker: t.maker, builtin: t.builtin, subtags: subs.get(t.id) })),
  }));
}

// What the browser needs of a tag: no ids, no built-in names.
function trimmed(t: Tag): Tag {
  return { name: t.name, icon: t.icon, ...(t.maker ? { maker: t.maker } : {}), ...(t.subtags ? { subtags: t.subtags.map(trimmed) } : {}) };
}

function current(): Built {
  const now = Date.now();
  if (built && now - checkedAt < RECHECK_MS) return built;
  checkedAt = now;
  const version = getTaxonomyVersion();
  if (!built || built.version !== version) {
    const groups = loadGroups();
    built = {
      version,
      tax: buildTaxonomy(groups),
      client: groups.map((g) => ({ name: g.name, icon: g.icon, hue: g.hue, tags: g.tags.map(trimmed) })),
      aliases: { tag: getLabelAliases("tag"), category: getLabelAliases("category") },
    };
  }
  return built;
}

// Call after saving the tree, so the next read sees it.
export function forgetTaxonomy() {
  built = undefined;
}

export function getTaxonomy(): Taxonomy {
  return current().tax;
}

// Goes up each time the tree changes: anything worked out from it (the demo
// deals' labels, autofill's word index) knows to work it out again.
export function taxonomyVersion(): number {
  return current().version;
}

// The tree as handed to the browser (components/TaxonomyProvider.tsx).
export const clientTree = (): CategoryGroup[] => current().client;
export const getCategoryGroups = (): CategoryGroup[] => current().tax.groups;
export const allTags = (): TagInfo[] => current().tax.allTags();
export const getCategoryBySlug = (slug: string) => current().tax.getCategoryBySlug(slug);
export const getCategoryByName = (name: string) => current().tax.getCategoryByName(name);
export const getTagBySlug = (slug: string) => current().tax.getTagBySlug(slug);
export const getTagByName = (name: string) => current().tax.getTagByName(name);
export const getTagById = (id: number) => current().tax.getTagById(id);
export const getTagByBuiltin = (name: string) => current().tax.getTagByBuiltin(name);
export const getCategoryByBuiltin = (name: string) => current().tax.getCategoryByBuiltin(name);
export const tagFamily = (name: string) => current().tax.tagFamily(name);
export const tagAndParent = (name: string) => current().tax.tagAndParent(name);
export const tagMaker = (name: string) => current().tax.tagMaker(name);
export const isKnownTag = (category: string, tag: string) => current().tax.isKnownTag(category, tag);
export const searchCategoriesAndTags = (query: string) => current().tax.searchCategoriesAndTags(query);
export const dealIcon = (deal: { category: string; tag?: string }) => current().tax.dealIcon(deal);
export const dealLook = (deal: { category: string; tag?: string }) => current().tax.dealLook(deal);
export const categoryTheme = (category: string) => current().tax.categoryTheme(category);

// A tag as it was named before a rename or merge ("Toy" after it became
// "Toys"): how the demo deals, written in code with the old names, find their
// tag, and how an old /tags/ address finds where it went.
export function movedTag(name: string): TagInfo | undefined {
  const { tax, aliases } = current();
  const id = aliases.tag.get(slugify(name));
  return id === undefined ? undefined : tax.getTagById(id);
}

export function movedCategory(name: string): CategoryGroup | undefined {
  const { tax, aliases } = current();
  const id = aliases.category.get(slugify(name));
  return id === undefined ? undefined : tax.groups.find((g) => g.id === id);
}

// A tag as found by name, or by an old name.
export const findTag = (name: string): TagInfo | undefined => getTagByName(name) ?? movedTag(name);
export const findCategory = (name: string): CategoryGroup | undefined => getCategoryByName(name) ?? movedCategory(name);
