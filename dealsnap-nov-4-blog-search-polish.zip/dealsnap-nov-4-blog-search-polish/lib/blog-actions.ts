"use server";

import { getBlogRowBySlug } from "./db";
import { countBlogVote, reader } from "./blog-stats";
import { overLimit } from "./rate-limit";

// "Was this useful?" under a post. No sign-in needed (it's one tap), so it's
// limited per visitor, counted once per person per post, and only for a live
// post. Only a total is kept (Admin → Blog), never who answered.
export async function blogVoteAction(slug: string, useful: boolean): Promise<{ ok: boolean }> {
  if (await overLimit("blog-vote", 20)) return { ok: false };
  const post = typeof slug === "string" && slug.length <= 120 ? getBlogRowBySlug(slug) : undefined;
  if (!post || post.status !== "published" || post.publishedAt > new Date().toISOString()) return { ok: false };
  countBlogVote(post.id, useful === true, await reader());
  return { ok: true };
}
