import {
  DEAL_SELECT,
  getAllDealOverrides,
  getCatalogVersion,
  getCommentCountsFor,
  getEndedReports,
  getHeroSlug,
  getAddedStoreKeys,
  getReportCountsFor,
  getStoreAliasRows,
  getStoreProfiles,
  getVoteDeltasFor,
  rowToDeal,
  sqlite as db,
} from "./db";
import {
  applySeedOverride,
  dbDealToDeal,
  deals as seedDeals,
  endedPatch,
  getAdminDealsView,
  getStoreNaming,
  identityKey,
  markHero,
  type AdminDealRow,
  type StoreIdentity,
} from "./mock-deals";
import { getDealStatus } from "./format";
import { hasSinglePrice } from "./deal-kinds";
import { slugify } from "./slug";
import { taxonomyVersion } from "./categories";
import { getBrandListVersion } from "./brands";
import type { Deal } from "./types";

// Admin → Deals, answered by the database.
//
// The list used to be built by loading every deal into memory, filtering and
// sorting it there, and cutting out one page. That is fine for hundreds of
// deals and slow for hundreds of thousands. Now the database does the
// filtering, sorting and counting with its indexes and hands back only the
// rows for the page being shown, so the page costs the same at 500 deals or
// 500,000. (How the big deal sites do it too: indexed queries and one page at
// a time; a search engine only for free-text search, which this list doesn't
// need, as it matches on a few short fields.)
//
// Two small things are still worked out in memory, both tiny however big the
// catalogue gets:
//   - the demo deals that ship with the code (a few hundred, gone at launch),
//     which aren't in the database, so they're filtered here and merged in;
//   - what the admins' settings say about every deal: each store's single
//     display name, which deals members have ended, the Hero deal. These come
//     from small tables (names, reports) and are kept between visits.
// `referenceFindAdminDeals` is the slow, obvious version: the tests check the
// fast one gives exactly its answers for every filter and sort.

export const ADMIN_DEAL_SORTS = {
  newest: "Newest first",
  oldest: "Oldest first",
  "price-asc": "Price: low to high",
  "price-desc": "Price: high to low",
  "hearts-desc": "Most hearts",
  "comments-desc": "Most comments",
  "reports-desc": "Most reported",
} as const;
export type AdminDealSort = keyof typeof ADMIN_DEAL_SORTS;

export type AdminDealFilters = {
  q: string;
  status: string; // all | live | pending | expired | removed | featured | hero
  category: string; // all | a category name
  tag: string; // all | a tag name
  brand: string; // all | none | a brand's slug
  kind: string; // all | a deal type
  source: string; // all | user | seed
  store: string; // "" | a store's slug
  flag: string; // all | reported | ended | labels | comments
  sort: AdminDealSort;
};

export type AdminDealRowPlus = AdminDealRow & { realCommentCount: number; reportCount: number };

// ---- the rules, in plain code (the demo deals, and the tests' reference) ------

export function matchesFilters(d: AdminDealRowPlus, f: AdminDealFilters): boolean {
  if (f.q.trim()) {
    const needle = f.q.trim().toLowerCase();
    // The title, store, brand, tag or the person who posted it.
    if (!(
      d.title.toLowerCase().includes(needle) ||
      d.store.toLowerCase().includes(needle) ||
      (d.brand ?? "").toLowerCase().includes(needle) ||
      d.tag.toLowerCase().includes(needle) ||
      (d.postedByUsername ?? "").toLowerCase().includes(needle)
    )) {
      return false;
    }
  }
  const status = getDealStatus(d);
  // "Live" means anything the public can see, Featured and the Hero deal included.
  if (f.status === "live" && !["live", "featured", "hero"].includes(status)) return false;
  if (["pending", "expired", "removed", "featured", "hero"].includes(f.status) && status !== f.status) return false;
  if (f.category !== "all" && d.category !== f.category) return false;
  if (f.tag !== "all" && d.tag !== f.tag) return false;
  if (f.brand !== "all" && (f.brand === "none" ? !!d.brand : slugify(d.brand ?? "") !== f.brand)) return false;
  if (f.kind !== "all" && (d.kind ?? "price") !== f.kind) return false;
  if (f.source !== "all" && d.source !== f.source) return false;
  if (f.store && slugify(d.store) !== f.store) return false;
  if (f.flag === "reported" && d.reportCount <= 0) return false;
  if (f.flag === "ended" && !d.endedByMembers) return false;
  if (f.flag === "labels" && !d.labelsUnsure) return false;
  if (f.flag === "comments" && d.realCommentCount <= 0) return false;
  return true;
}

function postedMs(d: { postedAt: string }): number {
  return new Date(d.postedAt).getTime();
}

// Sales, multi-buys, vouchers and freebies have no price: they go last. Ties
// keep the newest first.
export function compareDeals(a: AdminDealRowPlus, b: AdminDealRowPlus, sort: AdminDealSort): number {
  const newest = postedMs(b) - postedMs(a);
  switch (sort) {
    case "oldest":
      return -newest;
    case "price-asc":
      return Number(hasSinglePrice(b)) - Number(hasSinglePrice(a)) || a.price - b.price || newest;
    case "price-desc":
      return Number(hasSinglePrice(b)) - Number(hasSinglePrice(a)) || b.price - a.price || newest;
    case "hearts-desc":
      return b.hearts - a.hearts || newest;
    case "comments-desc":
      return b.realCommentCount - a.realCommentCount || newest;
    case "reports-desc":
      return b.reportCount - a.reportCount || newest;
    default:
      return newest;
  }
}

// The simple version: every deal in memory, filtered and sorted there.
export function referenceFindAdminDeals(f: AdminDealFilters, page: number, pageSize: number): { rows: AdminDealRowPlus[]; total: number } {
  const all = getAdminDealsView();
  const slugs = all.map((d) => d.slug);
  const comments = getCommentCountsFor(slugs);
  const reports = getReportCountsFor(slugs);
  const rows = all
    .map((d): AdminDealRowPlus => ({ ...d, realCommentCount: comments.get(d.slug) ?? 0, reportCount: reports.get(d.slug) ?? 0 }))
    .filter((d) => matchesFilters(d, f))
    .sort((a, b) => compareDeals(a, b, f.sort));
  return { rows: rows.slice((page - 1) * pageSize, page * pageSize), total: rows.length };
}

// ---- what the settings say about every deal (small, kept between visits) -----

type Context = {
  stamp: { hard: number; soft: number; brands: number; taxonomy: number; at: number };
  id: StoreIdentity;
  names: Map<string, string>; // store identity -> the one name it shows under
  displayStore: (raw: string) => string;
  storeRaws: Map<string, string[]>; // a store's slug -> every spelling in the database
  endedPatches: Map<string, Partial<Deal>>; // deals members/staff ended (database ones)
  endedSlugs: string[];
  heroSlug: string;
  seeds: AdminDealRowPlus[]; // the demo deals, fully worked out
  storeChecks: { newStores: number; missingLogos: number };
  storeIndex: { slug: string; name: string; others: string[]; approved: number; pending: number }[]; // for Admin search
  facets?: AdminDealFacets;
};

let kept: Context | undefined;
const SOFT_REFRESH_MS = 5_000;
const MAX_AGE_MS = 60_000;

function context(): Context {
  const version = getCatalogVersion();
  const brands = getBrandListVersion();
  const taxonomy = taxonomyVersion();
  if (
    kept &&
    kept.stamp.hard === version.hard &&
    kept.stamp.brands === brands &&
    kept.stamp.taxonomy === taxonomy &&
    Date.now() - kept.stamp.at < MAX_AGE_MS &&
    (kept.stamp.soft === version.soft || Date.now() - kept.stamp.at < SOFT_REFRESH_MS)
  ) {
    return kept;
  }
  kept = buildContext({ ...version, brands, taxonomy, at: Date.now() });
  return kept;
}

function buildContext(stamp: Context["stamp"]): Context {
  const overrides = getAllDealOverrides();
  const seedBase = seedDeals.map((d) => ({ ...applySeedOverride(d, overrides), source: "seed" as const }));

  // One display name per store, worked out from every deal (shared with the public lists).
  const { id, names, tally, rows: storeTotals, displayStore } = getStoreNaming();
  // For the dashboard's checks on stores: which have nothing approved yet
  // (only deals waiting), and which approved ones have no logo.
  const standing = new Map<string, { approved: number; pending: number }>();
  const stand = (raw: string, status: string, count: number) => {
    const key = identityKey(raw, id);
    if (!key) return;
    const have = standing.get(key) ?? { approved: 0, pending: 0 };
    if (status === "live") have.approved += count;
    else if (status === "pending") have.pending += count;
    standing.set(key, have);
  };
  for (const r of storeTotals) stand(r.store, r.status, r.count);
  const profiles = getStoreProfiles();
  const storeChecks = {
    newStores: [...standing.values()].filter((s) => s.approved === 0 && s.pending > 0).length,
    missingLogos: [...standing].filter(([key, s]) => s.approved > 0 && !profiles.get(key)?.logoUrl).length,
  };
  const aliasNames = new Map<string, string[]>();
  for (const a of getStoreAliasRows()) aliasNames.set(a.targetKey, [...(aliasNames.get(a.targetKey) ?? []), a.aliasName]);
  const addedKeys = getAddedStoreKeys();
  const storeIndex: Context["storeIndex"] = [];
  for (const [key, name] of names) {
    const have = standing.get(key) ?? { approved: 0, pending: 0 };
    // A store whose deals have all been taken down is left out (unless added by hand).
    if (have.approved + have.pending === 0 && !addedKeys.has(key)) continue;
    const others = [...(tally.get(key)?.keys() ?? []), ...(aliasNames.get(key) ?? [])].filter((n) => n !== name);
    storeIndex.push({ slug: slugify(name), name, others, ...have });
  }
  for (const key of addedKeys) {
    const name = id.names.get(key);
    if (name && !names.has(key)) storeIndex.push({ slug: slugify(name), name, others: aliasNames.get(key) ?? [], approved: 0, pending: 0 });
  }
  const storeRaws = new Map<string, string[]>();
  for (const raw of new Set(storeTotals.map((r) => r.store))) {
    const slug = slugify(displayStore(raw));
    storeRaws.set(slug, [...(storeRaws.get(slug) ?? []), raw]);
  }

  // Which deals members (or staff, or the poster) have ended: from the reports
  // table, which only has rows for deals someone has reported.
  const reports = getEndedReports();
  const reported = [...reports.keys()];
  const dbBits = new Map<string, { hearts: number; expiresAt?: string }>();
  if (reported.length) {
    const rows = db.prepare("SELECT slug, hearts, expires_at FROM deals WHERE slug IN (SELECT value FROM json_each(?))").all(JSON.stringify(reported)) as {
      slug: string;
      hearts: number;
      expires_at: string | null;
    }[];
    const deltas = getVoteDeltasFor(rows.map((r) => r.slug));
    for (const r of rows) dbBits.set(r.slug, { hearts: r.hearts + (deltas.get(r.slug) ?? 0), expiresAt: r.expires_at ?? undefined });
  }
  const endedPatches = new Map<string, Partial<Deal>>();
  for (const [slug, bits] of dbBits) {
    const patch = endedPatch(bits, reports.get(slug));
    if (patch?.endedByMembers) endedPatches.set(slug, patch);
  }

  // The demo deals, worked out in full (they are few).
  const seedSlugs = seedBase.map((d) => d.slug);
  const seedDeltas = getVoteDeltasFor(seedSlugs);
  const seedComments = getCommentCountsFor(seedSlugs);
  const seedReports = getReportCountsFor(seedSlugs);
  const seeds = markHero(
    seedBase.map((d) => {
      let row = { ...d, store: displayStore(d.store) };
      row = { ...row, hearts: row.hearts + (seedDeltas.get(row.slug) ?? 0) };
      const patch = endedPatch(row, reports.get(row.slug));
      return patch ? { ...row, ...patch } : row;
    }),
  ).map((d): AdminDealRowPlus => ({ ...d, realCommentCount: seedComments.get(d.slug) ?? 0, reportCount: seedReports.get(d.slug) ?? 0 }));

  return { stamp, id, names, displayStore, storeRaws, endedPatches, endedSlugs: [...endedPatches.keys()], heroSlug: getHeroSlug() ?? "", seeds, storeChecks, storeIndex };
}

// ---- the database's side ----------------------------------------------------

type Bind = Record<string, string | number>;

// SQLite refuses a value for a name the query doesn't use, so each query is
// given only its own.
function only(bind: Bind, sql: string): Bind {
  return Object.fromEntries(Object.entries(bind).filter(([name]) => sql.includes("$" + name)));
}

// Node's SQLite accepts named values (an object) as well as listed ones; its
// type definitions here only know the listed kind.
type Statement = { get(...values: unknown[]): unknown; all(...values: unknown[]): unknown[] };
const prepare = (sql: string) => db.prepare(sql) as unknown as Statement;

const escapeLike = (text: string) => `%${text.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;

function dbWhere(f: AdminDealFilters, ctx: Context): { sql: string; bind: Bind } | undefined {
  // Demo deals aren't in the database.
  if (f.source === "seed") return undefined;
  const where: string[] = [];
  const bind: Bind = { now: new Date().toISOString(), ended: JSON.stringify(ctx.endedSlugs), hero: ctx.heroSlug };
  // Out of date: its end date has passed, or members/staff ended it.
  const expired = "((deals.expires_at IS NOT NULL AND deals.expires_at <= $now) OR deals.slug IN (SELECT value FROM json_each($ended)))";
  const needle = f.q.trim().toLowerCase();
  if (needle) {
    bind.like = escapeLike(needle);
    const stores = [...ctx.storeRaws.values()].flat().filter((raw) => ctx.displayStore(raw).toLowerCase().includes(needle));
    bind.qstores = JSON.stringify(stores);
    where.push(
      `(LOWER(deals.title) LIKE $like ESCAPE '\\' OR LOWER(COALESCE(deals.brand, '')) LIKE $like ESCAPE '\\' OR LOWER(deals.tag) LIKE $like ESCAPE '\\'
        OR LOWER(users.username) LIKE $like ESCAPE '\\' OR deals.store IN (SELECT value FROM json_each($qstores)))`,
    );
  }
  switch (f.status) {
    case "pending":
      where.push("deals.status = 'pending'");
      break;
    case "removed":
      where.push("deals.status = 'removed'");
      break;
    case "expired":
      where.push(`deals.status = 'live' AND ${expired}`);
      break;
    case "live":
      where.push(`deals.status = 'live' AND NOT ${expired}`);
      break;
    case "featured":
      where.push(`deals.status = 'live' AND NOT ${expired} AND deals.featured = 1 AND deals.slug != $hero`);
      break;
    case "hero":
      where.push(`deals.status = 'live' AND NOT ${expired} AND deals.slug = $hero`);
      break;
  }
  if (f.category !== "all") {
    where.push("deals.category = $category");
    bind.category = f.category;
  }
  if (f.tag !== "all") {
    where.push("deals.tag = $tag");
    bind.tag = f.tag;
  }
  if (f.brand === "none") where.push("(deals.brand IS NULL OR deals.brand = '')");
  else if (f.brand !== "all") {
    const brands = (db.prepare("SELECT DISTINCT brand FROM deals WHERE brand IS NOT NULL AND brand != ''").all() as { brand: string }[])
      .map((r) => r.brand)
      .filter((b) => slugify(b) === f.brand);
    bind.brands = JSON.stringify(brands);
    where.push("deals.brand IN (SELECT value FROM json_each($brands))");
  }
  if (f.kind !== "all") {
    where.push("deals.kind = $kind");
    bind.kind = f.kind;
  }
  if (f.store) {
    bind.stores = JSON.stringify(ctx.storeRaws.get(f.store) ?? []);
    where.push("deals.store IN (SELECT value FROM json_each($stores))");
  }
  if (f.flag === "reported") where.push("EXISTS (SELECT 1 FROM deal_reports r WHERE r.deal_slug = deals.slug)");
  else if (f.flag === "ended") where.push("deals.slug IN (SELECT value FROM json_each($ended))");
  else if (f.flag === "labels") where.push("deals.labels_unsure = 1");
  else if (f.flag === "comments") where.push("EXISTS (SELECT 1 FROM comments c WHERE c.deal_slug = deals.slug AND c.deleted_at IS NULL)");
  return { sql: where.length ? `WHERE ${where.join(" AND ")}` : "", bind };
}

const FROM = "FROM deals JOIN users ON users.id = deals.user_id";
const ORDER: Record<AdminDealSort, { join: string; by: string }> = {
  newest: { join: "", by: "deals.posted_at DESC" },
  oldest: { join: "", by: "deals.posted_at ASC" },
  "price-asc": {
    join: "",
    by: "(deals.kind = 'price' AND deals.price_from = 0 AND COALESCE(deals.price_unit, '') = '') DESC, deals.price ASC, deals.posted_at DESC",
  },
  "price-desc": {
    join: "",
    by: "(deals.kind = 'price' AND deals.price_from = 0 AND COALESCE(deals.price_unit, '') = '') DESC, deals.price DESC, deals.posted_at DESC",
  },
  "hearts-desc": { join: "", by: "(deals.hearts + deals.vote_delta) DESC, deals.posted_at DESC" },
  "comments-desc": {
    join: "",
    by: "(SELECT COUNT(*) FROM comments c WHERE c.deal_slug = deals.slug AND c.deleted_at IS NULL) DESC, deals.posted_at DESC",
  },
  "reports-desc": { join: "", by: "(SELECT COUNT(*) FROM deal_reports r WHERE r.deal_slug = deals.slug) DESC, deals.posted_at DESC" },
};

// The first `limit` deals the database has for these filters, worked out in full
// (the store's one name, hearts with votes, ended, Hero), with the count of all.
function dbDeals(f: AdminDealFilters, ctx: Context, limit: number, offset: number): { rows: AdminDealRowPlus[]; total: number } {
  const filter = dbWhere(f, ctx);
  if (!filter) return { rows: [], total: 0 };
  const order = ORDER[f.sort];
  // Only the ids are sorted and cut; the full rows are read for just those.
  const countSql = `SELECT COUNT(*) AS c ${FROM} ${filter.sql}`;
  const total = (prepare(countSql).get(only(filter.bind, countSql)) as { c: number }).c;
  const idsSql = `SELECT deals.id AS id ${FROM} ${order.join} ${filter.sql} ORDER BY ${order.by} LIMIT $limit OFFSET $offset`;
  const ids = (prepare(idsSql).all(only({ ...filter.bind, limit, offset }, idsSql)) as { id: string }[]).map((r) => r.id);
  if (!ids.length) return { rows: [], total };
  const found = new Map(
    (db.prepare(`${DEAL_SELECT} WHERE deals.id IN (SELECT value FROM json_each(?))`).all(JSON.stringify(ids)) as Record<string, unknown>[]).map((r) => [
      r.id as string,
      rowToDeal(r),
    ]),
  );
  return { rows: completeRows(ids.map((id) => found.get(id)!), ctx), total };
}

// Database deals, worked out in full: the store's one name, hearts with the
// members' votes, ended, Hero, and the counts of reports.
function completeRows(raws: ReturnType<typeof rowToDeal>[], ctx: Context): AdminDealRowPlus[] {
  const slugs = raws.map((r) => r.slug);
  const reports = getReportCountsFor(slugs);
  return markHero(
    raws.map((raw): AdminDealRowPlus => {
      const base = dbDealToDeal(raw);
      let d: Deal = { ...base, hearts: base.hearts + raw.voteDelta, store: ctx.displayStore(raw.store) };
      const patch = ctx.endedPatches.get(raw.slug);
      if (patch) d = { ...d, ...patch };
      return { ...d, source: "user", dbId: raw.id, realCommentCount: raw.commentCount, reportCount: reports.get(raw.slug) ?? 0 };
    }),
  );
}

// One deal by its address, demo or not (what a button or the dashboard needs), without loading the rest.
export function getAdminDeal(slug: string): AdminDealRowPlus | undefined {
  const ctx = context();
  const demo = ctx.seeds.find((d) => d.slug === slug);
  if (demo) return demo;
  const row = db.prepare(`${DEAL_SELECT} WHERE deals.slug = ?`).get(slug) as Record<string, unknown> | undefined;
  return row ? completeRows([rowToDeal(row)], ctx)[0] : undefined;
}

// When the longest-waiting deal was posted, for the dashboard.
export function oldestPendingAt(): string | undefined {
  const row = db.prepare("SELECT MIN(posted_at) AS at FROM deals WHERE status = 'pending'").get() as { at: string | null };
  return row.at ?? undefined;
}

// One page of Admin → Deals.
export function findAdminDeals(f: AdminDealFilters, page: number, pageSize: number): { rows: AdminDealRowPlus[]; total: number } {
  const ctx = context();
  const offset = (page - 1) * pageSize;
  const demo = f.source === "user" ? [] : ctx.seeds.filter((d) => matchesFilters(d, f)).sort((a, b) => compareDeals(a, b, f.sort));
  // No demo deals in the way (the live site): the database cuts out the page itself.
  if (!demo.length) return dbDeals(f, ctx, pageSize, offset);
  // Otherwise take enough from each side to fill this page and merge them.
  const fromDb = dbDeals(f, ctx, offset + pageSize, 0);
  const merged = [...demo, ...fromDb.rows].sort((a, b) => compareDeals(a, b, f.sort));
  return { rows: merged.slice(offset, offset + pageSize), total: demo.length + fromDb.total };
}

// ---- what the filter menus offer, with how many each has ----------------------

export type AdminDealFacets = {
  total: number;
  // What each deal shows as (Live here means live but neither Featured nor the Hero deal).
  states: { live: number; featured: number; hero: number; pending: number; expired: number; removed: number };
  tags: { tag: string; category: string; count: number }[];
  stores: { slug: string; name: string; count: number }[];
  brands: { slug: string; name: string; count: number }[];
  kinds: Map<string, number>;
};

export function getAdminDealFacets(): AdminDealFacets {
  const ctx = context();
  if (ctx.facets) return ctx.facets;
  const now = new Date().toISOString();
  const bind = { now, ended: JSON.stringify(ctx.endedSlugs), hero: ctx.heroSlug };
  const expired = "((expires_at IS NOT NULL AND expires_at <= $now) OR slug IN (SELECT value FROM json_each($ended)))";
  const s = prepare(
    `SELECT COUNT(*) AS total,
         COALESCE(SUM(status = 'pending'), 0) AS pending,
         COALESCE(SUM(status = 'removed'), 0) AS removed,
         COALESCE(SUM(status = 'live' AND ${expired}), 0) AS expired,
         COALESCE(SUM(status = 'live' AND NOT ${expired}), 0) AS active,
         COALESCE(SUM(status = 'live' AND NOT ${expired} AND featured = 1 AND slug != $hero), 0) AS featured,
         COALESCE(SUM(status = 'live' AND NOT ${expired} AND slug = $hero), 0) AS hero
       FROM deals`,
  ).get(bind) as Record<"total" | "pending" | "removed" | "expired" | "active" | "featured" | "hero", number>;
  const states = { live: s.active - s.featured - s.hero, featured: s.featured, hero: s.hero, pending: s.pending, expired: s.expired, removed: s.removed };
  let total = s.total;

  const tags = new Map<string, { tag: string; category: string; count: number }>();
  const addTag = (tag: string, category: string, count: number) => {
    // Whole-store vouchers and sales have no type to filter by.
    if (!tag) return;
    const key = `${category}\u0000${tag}`;
    const have = tags.get(key);
    if (have) have.count += count;
    else tags.set(key, { tag, category, count });
  };
  for (const r of db.prepare("SELECT category, tag, COUNT(*) AS c FROM deals GROUP BY category, tag").all() as { category: string; tag: string; c: number }[])
    addTag(r.tag, r.category, r.c);

  const stores = new Map<string, { slug: string; name: string; count: number }>();
  const addStore = (name: string, count: number) => {
    const slug = slugify(name);
    const have = stores.get(slug);
    if (have) have.count += count;
    else stores.set(slug, { slug, name, count });
  };
  for (const r of db.prepare("SELECT store, COUNT(*) AS c FROM deals GROUP BY store").all() as { store: string; c: number }[])
    addStore(ctx.displayStore(r.store), r.c);

  const brandLabels = new Map<string, Map<string, number>>();
  const addBrand = (name: string, count: number) => {
    const slug = slugify(name);
    const labels = brandLabels.get(slug) ?? new Map<string, number>();
    labels.set(name, (labels.get(name) ?? 0) + count);
    brandLabels.set(slug, labels);
  };
  for (const r of db.prepare("SELECT brand, COUNT(*) AS c FROM deals WHERE brand IS NOT NULL AND brand != '' GROUP BY brand").all() as {
    brand: string;
    c: number;
  }[])
    addBrand(r.brand, r.c);

  const kinds = new Map<string, number>();
  for (const r of db.prepare("SELECT kind, COUNT(*) AS c FROM deals GROUP BY kind").all() as { kind: string; c: number }[]) kinds.set(r.kind, r.c);

  // The demo deals, counted the same way.
  for (const d of ctx.seeds) {
    total++;
    const state = getDealStatus(d);
    states[state]++;
    addTag(d.tag, d.category, 1);
    addStore(d.store, 1);
    if (d.brand) addBrand(d.brand, 1);
    kinds.set(d.kind ?? "price", (kinds.get(d.kind ?? "price") ?? 0) + 1);
  }

  ctx.facets = {
    total,
    states,
    tags: [...tags.values()],
    stores: [...stores.values()],
    brands: [...brandLabels.entries()].map(([slug, labels]) => {
      const [name] = [...labels.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0];
      return { slug, name, count: [...labels.values()].reduce((n, c) => n + c, 0) };
    }),
    kinds,
  };
  return ctx.facets;
}

// Which of these stores (by slug) already have an approved deal: a waiting
// deal from any other is a new store, worth a look for a duplicate spelling.
export function establishedStoreSlugs(slugs: string[]): Set<string> {
  const ctx = context();
  const found = new Set<string>();
  for (const d of ctx.seeds) if (d.status === "live") found.add(slugify(d.store));
  const hasLive = prepare("SELECT 1 FROM deals WHERE status = 'live' AND store IN (SELECT value FROM json_each(?)) LIMIT 1");
  for (const slug of new Set(slugs)) {
    const raws = ctx.storeRaws.get(slug);
    if (!found.has(slug) && raws?.length && hasLive.get(JSON.stringify(raws))) found.add(slug);
  }
  return found;
}

// How many stores have nothing approved yet (only deals waiting), and how many
// approved stores have no logo: counted from small totals, not by reading every deal.
export function getStoreChecks(): { newStores: number; missingLogos: number } {
  return context().storeChecks;
}

// Stores whose name, other spellings or merged names contain these words (Admin search).
export function searchAdminStores(word: string, limit: number): { total: number; stores: { slug: string; name: string; approved: number; pending: number }[] } {
  const needle = word.trim().toLowerCase();
  const found = context()
    .storeIndex.filter((s) => s.name.toLowerCase().includes(needle) || s.others.some((n) => n.toLowerCase().includes(needle)))
    .sort((a, b) => a.name.localeCompare(b.name));
  return { total: found.length, stores: found.slice(0, limit) };
}

// The links of just these deals (the ones that had clicks), not all of them.
export function getDealUrls(slugs: string[]): Map<string, string> {
  const wanted = new Set(slugs);
  const urls = new Map<string, string>();
  for (const d of seedDeals) if (wanted.has(d.slug)) urls.set(d.slug, d.url);
  if (slugs.length) {
    for (const r of prepare("SELECT slug, url FROM deals WHERE slug IN (SELECT value FROM json_each(?))").all(JSON.stringify(slugs)) as { slug: string; url: string }[]) urls.set(r.slug, r.url);
  }
  return urls;
}
