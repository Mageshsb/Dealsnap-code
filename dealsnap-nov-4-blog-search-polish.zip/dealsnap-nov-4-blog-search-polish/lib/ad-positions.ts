// Where ads fall inside a list or an article. Kept apart from lib/ads.ts so
// the deal lists, which run in every visitor's browser, carry only these few
// lines, not the rest of the ad rules.

// Which deals an ad follows in a list, as positions in the deals showing:
// after deal `first`, then every `every` deals, at most `max` in all (0 is no
// limit). A position the promo card or sign-up tile already has moves down
// one, so two extras never sit together. An ad never goes after the last deal
// while more are still to load (it would sit at the bottom, then end up
// between deals as they arrive).
export function adPositions(shown: number, first: number, every: number, taken: number[], moreToLoad: boolean, max = 0): number[] {
  const out: number[] = [];
  if (first < 1 || every < 1) return out;
  for (let after = first; after <= shown && (!max || out.length < max); after += every) {
    let i = after - 1;
    while (taken.includes(i)) i++;
    if (i < shown - 1 || (i === shown - 1 && !moreToLoad)) out.push(i);
  }
  return out;
}

// Which blocks of a blog article an ad follows: after the `first`th paragraph
// (or list), then every `every` more, at most `max` (0 is no limit). Never
// straight after a heading (it would part the heading from its words), and
// never in the last two blocks (the space after the article covers the end).
export function articlePositions(blocks: { type: string }[], first: number, every: number, max = 0): number[] {
  const out: number[] = [];
  if (first < 1 || every < 1) return out;
  let text = 0;
  let next = first;
  for (let i = 0; i < blocks.length - 2 && (!max || out.length < max); i++) {
    if (blocks[i].type !== "paragraph" && blocks[i].type !== "list") continue;
    text++;
    if (text >= next) {
      out.push(i);
      next = text + every;
    }
  }
  return out;
}
