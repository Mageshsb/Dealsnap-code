import sharp from "sharp";
import { MAX_PIXELS, isAcceptedImage } from "./deal-images";

// Pictures inside blog posts. As with deal photos, nothing is stored as it
// arrived: the file is opened as pixels and saved again as a brand-new WebP,
// so anything else it carried (scripts, a disguised program, the place a
// phone photo was taken) isn't copied across. Wide enough for the reading
// column on a sharp screen, and served as it is, cached for a year.
export const BLOG_IMAGE_MAX_BYTES = 8 * 1024 * 1024;
const MAX_WIDTH = 1400;
const MIN_WIDTH = 240;

export class BlogImageError extends Error {}

export async function cleanBlogImage(bytes: Buffer): Promise<{ data: Buffer; width: number; height: number }> {
  if (bytes.length === 0) throw new BlogImageError("That picture is empty. Please choose another.");
  if (bytes.length > BLOG_IMAGE_MAX_BYTES) throw new BlogImageError("That picture is too big. Please use one under 8MB.");
  if (!isAcceptedImage(bytes)) throw new BlogImageError("Use a JPG, PNG or WEBP picture.");
  try {
    const out = await sharp(bytes, { limitInputPixels: MAX_PIXELS, failOn: "error", animated: false })
      .rotate()
      .resize({ width: MAX_WIDTH, withoutEnlargement: true })
      .webp({ quality: 80 })
      .toBuffer({ resolveWithObject: true });
    if (out.info.width < MIN_WIDTH) throw new BlogImageError("That picture is too small. Please use one at least 240 pixels wide.");
    return { data: out.data, width: out.info.width, height: out.info.height };
  } catch (e) {
    if (e instanceof BlogImageError) throw e;
    throw new BlogImageError("We couldn't open that picture. Please try another.");
  }
}
