import { cookies, headers } from "next/headers";
import { getCurrentUser } from "./auth";
import { clientIp } from "./client-ip";
import { BOT_AGENT } from "./deal-click";
import { isInApp } from "./app-shell";
import { isStaffRole } from "./permissions";
import { ukDay } from "./events";
import { getDealBySlug } from "./mock-deals";
import { isExpired } from "./format";
import {
  addAdStats,
  getAdSlotSettings,
  getDelivered,
  getRunningCampaigns,
  getSiteSetting,
  type AdCampaignRow,
} from "./db";
import {
  AD_PAGE_KINDS,
  AD_SLOTS,
  COMPACT_SIZES,
  MAX_EVERY,
  MAX_FIRST,
  MAX_PER_PAGE,
  RAIL_SLOTS,
  adFit,
  deliveryBoost,
  isPagePath,
  isRailSlot,
  minEvery,
  minFirst,
  pageBlocked,
  creativeImageUrl,
  listAdPage,
  isAdUnitPath,
  isNetworkCode,
  paceAllows,
  pickCampaigns,
  ukDayFraction,
  type AdCreative,
  type AdPage,
  type AdPageKind,
  type AdScreens,
  type AdSize,
  type AdSlotId,
  type Candidate,
  type Delivered,
  type PageAds,
  type SlotFill,
  type SponsoredDeal,
} from "./ads";
import type { ListPage } from "./promos";

// Picking the ads for a page, and counting their views and clicks. Built to
// cost a page next to nothing: the running campaigns and the settings are
// kept in memory, counts are added up in memory and saved every few seconds
// in one go, and nothing is looked up per ad.

// ---------------------------------------------------------------------------
// Settings (Admin → Ads), kept in site_settings and the ad_slots table.
// ---------------------------------------------------------------------------
export const ADS_PREVIEW_COOKIE = "ds_ads_preview";

export type AdSettings = {
  on: boolean; // the master switch
  membersFree: boolean; // signed-in members see no ads
  blockedCategories: string[]; // category address names with no ads at all
  offPages: AdPageKind[]; // kinds of page with no ads at all
  blockedPaths: string[]; // single pages with no ads (a store's page also covers its deals)
  network: "off" | "gam";
  networkCode: string;
  personalised: boolean; // a Google-certified consent tool is on the site
  page: { on: boolean; holding: boolean; stats: boolean; intro: string; rates: string }; // the public "Advertise with us" page: the full page (on), or a short "get in touch" holding page
  slots: Record<AdSlotId, { enabled: boolean; first: number; every: number; max: number; screens: AdScreens; cond: number; size: AdSize; unit: string }>;
};

const jsonList = (key: string): string[] => {
  try {
    const parsed = JSON.parse(getSiteSetting(key) ?? "[]");
    return Array.isArray(parsed) ? parsed.filter((v) => typeof v === "string") : [];
  } catch {
    return [];
  }
};

const g = globalThis as unknown as {
  __dealsnapAdSettings?: { at: number; value: AdSettings };
  __dealsnapAdCounts?: Map<string, { views: number; clicks: number }>;
  __dealsnapAdDelivered?: Map<string, Delivered & { day: string }>;
  __dealsnapAdFlush?: ReturnType<typeof setInterval>;
  __dealsnapAdSeen?: Map<string, { day: string; n: number }>;
  __dealsnapAdClicked?: Map<string, number>;
};

export function getAdSettings(): AdSettings {
  const memo = g.__dealsnapAdSettings;
  if (memo && Date.now() - memo.at < 60_000) return memo.value;
  const saved = new Map(getAdSlotSettings().map((s) => [s.id, s]));
  const slots = Object.fromEntries(
    AD_SLOTS.map((def) => {
      const s = saved.get(def.id);
      const r = def.repeats;
      const first = r ? Math.min(MAX_FIRST, Math.max(minFirst(def), s?.first ?? r.first)) : 0;
      const every = r ? Math.min(MAX_EVERY, Math.max(minEvery(def), s?.every ?? r.every)) : 0;
      const max = r ? Math.min(MAX_PER_PAGE, Math.max(0, s?.max ?? r.max)) : 0;
      const screens: AdScreens = def.screenChoice && (s?.screens === "phones" || s?.screens === "laptops") ? s.screens : "all";
      const cond = def.condition ? Math.min(def.condition.max, Math.max(0, s?.cond ?? def.condition.value)) : 0;
      const size: AdSize = def.size ? (s?.size === "compact" || s?.size === "standard" ? s.size : def.size) : "standard";
      return [def.id, { enabled: s?.enabled ?? true, first, every, max, screens, cond, size, unit: s && isAdUnitPath(s.unit) ? s.unit : "" }];
    }),
  ) as AdSettings["slots"];
  const networkCode = getSiteSetting("ads_network_code") ?? "";
  const kinds = AD_PAGE_KINDS.map((k) => k.value as string);
  const value: AdSettings = {
    on: getSiteSetting("ads_on") === "1",
    membersFree: getSiteSetting("ads_members_free") === "1",
    blockedCategories: jsonList("ads_blocked_categories"),
    offPages: jsonList("ads_off_pages").filter((k): k is AdPageKind => kinds.includes(k)),
    blockedPaths: jsonList("ads_blocked_paths").filter(isPagePath),
    network: getSiteSetting("ads_network") === "gam" && isNetworkCode(networkCode) ? "gam" : "off",
    networkCode,
    personalised: getSiteSetting("ads_personalised") === "1",
    page: {
      on: getSiteSetting("ads_page_on") === "1",
      holding: getSiteSetting("ads_page_holding") === "1",
      stats: getSiteSetting("ads_page_stats") === "1",
      intro: getSiteSetting("ads_page_intro") ?? "",
      rates: getSiteSetting("ads_page_rates") ?? "",
    },
    slots,
  };
  g.__dealsnapAdSettings = { at: Date.now(), value };
  return value;
}

export function forgetAdSettings() {
  g.__dealsnapAdSettings = undefined;
}

// ---------------------------------------------------------------------------
// Counting
// ---------------------------------------------------------------------------
// Counts waiting to be saved, keyed "campaign|day|slot".
const pending = (g.__dealsnapAdCounts ??= new Map());
// Each running campaign's views so far (from the database, plus what's been
// counted since), so a goal or a day's share stops it straight away.
const delivered = (g.__dealsnapAdDelivered ??= new Map());

export function flushAdCounts() {
  if (!pending.size) return;
  const rows = [...pending].map(([key, c]) => {
    const [campaignId, day, slot] = key.split("|");
    return { campaignId, day, slot, ...c };
  });
  pending.clear();
  try {
    addAdStats(rows);
  } catch {
    // The database was busy: put them back for the next go.
    for (const r of rows) bump(r.campaignId, r.day, r.slot as AdSlotId, r.views, r.clicks);
  }
}
g.__dealsnapAdFlush ??= setInterval(flushAdCounts, 5_000);
g.__dealsnapAdFlush.unref?.();

function bump(campaignId: string, day: string, slot: AdSlotId, views: number, clicks: number) {
  const key = `${campaignId}|${day}|${slot}`;
  const c = pending.get(key) ?? { views: 0, clicks: 0 };
  c.views += views;
  c.clicks += clicks;
  pending.set(key, c);
}

function deliveredFor(campaigns: AdCampaignRow[], today: string): Map<string, Delivered> {
  const missing = campaigns.filter((c) => delivered.get(c.id)?.day !== today).map((c) => c.id);
  if (missing.length) {
    const fromDb = getDelivered(missing, today);
    for (const id of missing) {
      const before = delivered.get(id);
      const saved = fromDb.get(id) ?? { total: 0, today: 0 };
      // (Counts still waiting to be saved are in neither, so keep them.)
      const waiting = [...pending].filter(([k]) => k.startsWith(`${id}|`)).reduce((n, [k, c]) => n + (k.includes(`|${today}|`) ? c.views : 0), 0);
      delivered.set(id, { day: today, total: Math.max(saved.total + waiting, before?.total ?? 0), today: saved.today + waiting });
    }
  }
  return delivered;
}

// Bots and staff aren't counted; one person can only add so many views a day
// to one campaign (a page left reloading can't run down someone's budget);
// a click counts once per person per campaign every 10 minutes.
const VIEWS_PER_PERSON_PER_DAY = 40;
const CLICK_REPEAT_MS = 10 * 60 * 1000;
const MAX_REMEMBERED = 100_000;
const seen = (g.__dealsnapAdSeen ??= new Map());
const clicked = (g.__dealsnapAdClicked ??= new Map());

async function countable(): Promise<string | undefined> {
  const agent = (await headers()).get("user-agent") ?? "";
  if (!agent || BOT_AGENT.test(agent)) return undefined;
  const user = await getCurrentUser();
  if (user && isStaffRole(user.role)) return undefined;
  return user?.id ?? (await clientIp());
}

function trim<V>(map: Map<string, V>) {
  if (map.size <= MAX_REMEMBERED) return;
  for (const k of map.keys()) {
    map.delete(k);
    if (map.size <= MAX_REMEMBERED * 0.9) break;
  }
}

// Views seen in the browser (at least half of the ad on screen for a second,
// the industry's "viewable" measure). Only campaigns running today count.
export async function countViews(views: { id: string; slot: AdSlotId }[]) {
  const who = await countable();
  if (!who) return;
  const today = ukDay();
  const running = new Map(getRunningCampaigns(today).map((c) => [c.id, c]));
  const counts = deliveredFor([...running.values()], today);
  for (const v of views) {
    const c = running.get(v.id);
    if (!c || !c.slots.includes(v.slot)) continue;
    const key = `${who}|${v.id}`;
    const mine = seen.get(key);
    const n = mine?.day === today ? mine.n : 0;
    if (n >= VIEWS_PER_PERSON_PER_DAY) continue;
    seen.delete(key);
    seen.set(key, { day: today, n: n + 1 });
    bump(v.id, today, v.slot, 1, 0);
    const d = counts.get(v.id);
    if (d) {
      d.total++;
      d.today++;
    }
  }
  trim(seen);
}

// Taps on a sponsored deal (it links to the deal and the store, not through
// /visit), sent with the views.
export async function countClicks(taps: { id: string; slot: AdSlotId }[]) {
  if (!taps.length) return;
  const running = new Map(getRunningCampaigns(ukDay()).map((c) => [c.id, c]));
  for (const t of taps.slice(0, 5)) {
    const c = running.get(t.id);
    if (c && c.slots.includes(t.slot)) await countClick(c, t.slot);
  }
}

export async function countClick(campaign: AdCampaignRow, slot: AdSlotId) {
  // Only a space the campaign is actually booked in.
  if (!campaign.slots.includes(slot)) return;
  const who = await countable();
  if (!who) return;
  const key = `${who}|${campaign.id}`;
  const now = Date.now();
  const last = clicked.get(key);
  if (last !== undefined && now - last < CLICK_REPEAT_MS) return;
  clicked.delete(key);
  clicked.set(key, now);
  trim(clicked);
  bump(campaign.id, ukDay(), slot, 0, 1);
}

// ---------------------------------------------------------------------------
// Picking
// ---------------------------------------------------------------------------
const toCreative = (c: AdCampaignRow): AdCreative => ({
  id: c.id,
  advertiser: c.shownName,
  headline: c.headline,
  body: c.body,
  ctaLabel: c.ctaLabel,
  imageUrl: c.imageVersion ? creativeImageUrl(c.id, "image", c.imageVersion) : undefined,
  logoUrl: c.logoVersion ? creativeImageUrl(c.id, "logo", c.logoVersion) : undefined,
  internal: c.linkUrl.startsWith("/"),
});

// A sponsored deal's deal, as the lists draw it: only while it's live and
// not expired, and without the Featured and Deal of the Day looks (the team's
// own picks, which can't be bought).
function sponsoredDeal(c: AdCampaignRow): SponsoredDeal | undefined {
  const deal = c.dealSlug ? getDealBySlug(c.dealSlug) : undefined;
  if (!deal || (deal.status ?? "live") !== "live" || isExpired(deal.expiresAt)) return undefined;
  return { id: c.id, advertiser: c.shownName, deal: { ...deal, featured: false, hero: false } };
}

// What each ad space on a page shows. `wanted` is the spaces this page has;
// `facts` what a space's condition is checked against (a deal's description
// length and comment count). Returns nothing when ads are off, this kind of
// page or this page has none, or this visitor doesn't get them, so the page
// draws no ad space at all and the browser never loads any ad code. Staff
// with "show the ad spaces" on see outlines where ads would go (even with ads
// off), following every rule here, so what they see is what visitors would get.
export async function getPageAds(
  page: AdPage,
  wanted: AdSlotId[],
  facts: { description?: number; comments?: number } = {},
): Promise<PageAds | undefined> {
  const settings = getAdSettings();
  const jar = await cookies();
  const previewing = jar.get(ADS_PREVIEW_COOKIE)?.value === "1";
  if (!settings.on && !previewing) return undefined;
  if (settings.offPages.includes(page.kind) || pageBlocked(page, settings.blockedPaths)) return undefined;
  if (page.labels.category && settings.blockedCategories.includes(page.labels.category)) return undefined;

  const user = previewing || settings.membersFree ? await getCurrentUser() : null;
  const outline = previewing && !!user && isStaffRole(user.role);
  if (!settings.on && !outline) return undefined;
  if (settings.membersFree && user && !outline) return undefined;

  const today = ukDay();
  const running = settings.on ? getRunningCampaigns(today) : [];
  const counts = deliveredFor(running, today);
  const clock = ukDayFraction();
  const showable = running.filter((c) => paceAllows(c, counts.get(c.id) ?? { total: 0, today: 0 }, today, clock));
  // A campaign that has fallen behind its schedule gets more turns.
  const boost = new Map(showable.map((c) => [c.id, deliveryBoost(c, counts.get(c.id) ?? { total: 0, today: 0 }, today)]));
  // The ad network isn't used inside the phone apps (Google's rules for apps differ).
  const network = settings.on && settings.network === "gam" && !(await isInApp());

  // A sponsored deal is looked up once per page, however many spaces ask.
  const deals = new Map<string, SponsoredDeal | undefined>();
  const dealOf = (c: AdCampaignRow) => (deals.has(c.id) ? deals.get(c.id) : deals.set(c.id, sponsoredDeal(c)).get(c.id));

  // Spaces that sit side by side on screen are filled first, then the rest in
  // the page's order, and a campaign already placed is put at the back of the
  // queue for the next space (pickCampaigns), so a page shows different
  // advertisers where there's a choice. Each side column is its own space.
  const first = (id: AdSlotId) => (isRailSlot(id) ? 0 : id === "sidebar" ? 1 : 2);
  const order = [...wanted].sort((a, b) => first(a) - first(b));
  const used = new Set<string>();

  const slots: PageAds["slots"] = {};
  for (const id of order) {
    const s = settings.slots[id];
    if (!s.enabled) continue;
    if (id === "deal" && (facts.description ?? 0) < s.cond) continue;
    if (id === "deal-end" && (facts.comments ?? 0) < s.cond) continue;
    // The sponsored space takes sponsored deals; every other space, ads.
    const kind = id === "sponsored" ? "deal" : "ad";
    const candidates = showable.flatMap((c): (Candidate & { c: AdCampaignRow })[] => {
      const fit = c.kind === kind && c.slots.includes(id) ? adFit(c, page) : 0;
      return fit && (kind === "ad" || dealOf(c)) ? [{ c, id: c.id, fit, priority: c.priority, weight: c.weight, boost: boost.get(c.id) ?? 1 }] : [];
    });
    // A repeating space goes round several.
    const def = AD_SLOTS.find((d) => d.id === id)!;
    const picked = pickCampaigns(candidates, def.repeats ? 6 : 1, { avoid: used }).map((x) => x.c);
    for (const c of picked) used.add(c.id);
    // The ad network is asked first when it can fill the space; house ads (the
    // site's own promos, free) then only cover what it leaves empty.
    const wantsNetwork = network && !!s.unit && def.sizes.length > 0;
    const houseOnly = picked.length > 0 && picked.every((c) => c.priority === "house");
    const creatives = kind === "ad" && !(houseOnly && wantsNetwork) ? picked.map(toCreative) : [];
    const fallback = kind === "ad" && houseOnly && wantsNetwork ? picked.map(toCreative) : undefined;
    const sponsored = kind === "deal" ? picked.flatMap((c) => dealOf(c) ?? []) : undefined;
    const fill: SlotFill = { creatives, deals: sponsored, fallback, first: s.first, every: s.every, max: s.max, screens: s.screens, size: s.size };
    if (sponsored?.length) {
      slots[id] = fill;
      continue;
    }
    if (!creatives.length && wantsNetwork) {
      const compact = s.size === "compact";
      fill.network = { unit: s.unit, sizes: compact ? [...COMPACT_SIZES.laptop, ...COMPACT_SIZES.phone] : def.sizes, compact };
    }
    if (!creatives.length && !fill.network) {
      if (!outline) continue;
      fill.outline = true;
    }
    slots[id] = fill;
  }
  if (!Object.keys(slots).length) return undefined;
  return { slots, personalised: settings.personalised };
}

// Who is paying to place this deal, if a sponsorship for it is running now
// (ads on, the Sponsored deals space on, the campaign live and inside its
// dates). The deal's own page shows "Ad · Sponsored by …" too, so the label
// goes with the deal and isn't left behind in the list. It doesn't depend on
// who is looking or on pacing: if the store is paying, the page says so.
export function getDealSponsor(slug: string): string | undefined {
  const settings = getAdSettings();
  if (!settings.on || !settings.slots.sponsored.enabled) return undefined;
  return getRunningCampaigns(ukDay()).find((c) => c.kind === "deal" && c.dealSlug === slug)?.shownName;
}

// A deal list's spaces: sponsored deals and ads between the deals (List and
// Cards view), under the sidebar boxes, and the side columns.
export function getListAds(page: ListPage): Promise<PageAds | undefined> {
  return getPageAds(listAdPage(page), ["sponsored", "list", "cards", "sidebar", ...RAIL_SLOTS]);
}
