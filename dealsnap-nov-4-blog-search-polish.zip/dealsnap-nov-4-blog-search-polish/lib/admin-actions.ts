"use server";

import { bounceWithClash, clashText, dealClash, seenFrom, targetClash } from "./collisions";
import { saveBlockedDomains, saveBlockedWords } from "./site-blocks";
import { BrandImageError, getSiteBrand, removeBrandPicture, saveIcon, saveLogo, setShowSiteName } from "./site-brand";

import { notifyAlertMatches, notifyDealStatus } from "./notifications";
import { AMAZON_TAG_PATTERN, AWIN_ID_PATTERN, SKIMLINKS_ID_PATTERN, programmeDomain, validLinkTemplate } from "./affiliate";
import { redirect } from "next/navigation";
import { blogImagePath, dealSlugsIn, isBlogKind, parseBlogContent, safeHref } from "./blog";
import { BlogImageError, cleanBlogImage } from "./blog-images";
import { overLimit } from "./rate-limit";
import { revalidatePath } from "next/cache";
import { requirePermission, getCurrentUser } from "./auth";
import { ROLE_LABELS, mayManageAccount, mayManageComment, mayManageDeal } from "./permissions";
import {
  setContactMessageHandled,
  deleteContactMessage,
  clearUserBio,
  resetUsernameByStaff,
  resolveProfileReports,
  clearUserAvatar,
  claimAdmin,
  findUserById,
  verifyPassword,
  recordFailedLogin,
  clearFailedLogins,
  getRecentFailedLogins,
  getDbDealById,
  createEscalation,
  setModProbation,
  suspendUser,
  saveBlogRow,
  blogSlugTaken,
  setBlogCover,
  saveBlogImage,
  getBlogRowById,
  deleteBlogRow,
  addUserNote,
  deleteSessionsForUser,
  disableTotp,
  markAuditReviewed,
  deleteAllSessions,
  unsuspendUser,
  getEscalationById,
  resolveEscalation,
  getCommentForModeration,
  setUserRole,
  setDbDealStatus,
  setDbDealFeatured,
  deleteDbDeal,
  setSeedDealStatus,
  setSeedDealFeatured,
  setSiteSetting,
  setAffiliateProgramme,
  removeAffiliateProgramme,
  getAffiliateProgrammes,
  setAwinFeedOn,
  setProgrammesStopped,
  getHeroSlug,
  setHeroSlug,
  setStoreNameOverride,
  addStoreAlias,
  removeStoreAlias,
  setStoreWebsite,
  setStoreLogo,
  clearStoreLogo,
  dismissCommentReports,
  clearEndedReports,
  reportDeal,
  ENDED_REASON,
} from "./db";
import { logAudit } from "./audit";
import { removeCommentAsTeam } from "./comment-moderation";
import { imageMimeType } from "./store-logo";
import { getSiteSettings, MIN_LIST_DAYS } from "./site-settings";
import { dealRemovalReasons, ENDED_REMOVAL_REASON, suspensionReasons, readReason, describeReason, suspensionEnds } from "./moderation";
import { getAdminDealsView, getAdminStores, getDealBySlug } from "./mock-deals";
import { storeKey } from "./stores";
import { STORE_DETAIL_LIMITS, STORE_FACTS, type StoreDetails } from "./store-details";
import { cleanPerks } from "./store-perks";
import { clearDealCheck, deleteStoreRows, getStoreAliasRows, markDealChecked, setStoreAdded, setStoreDetailsRow, setStorePerks } from "./db";
import { checkStoreLogo, readLogoUpload, fetchStoreLogo, cleanWebsite, StoreLogoError } from "./store-logo";
import { slugify } from "./slug";
import { formatDate, getDealStatus } from "./format";
import { AFFILIATE_DISCLOSURE_MAX, extractGoogleIds, extractSearchConsoleToken, isExtensionStoreUrl, looksLikeOldAnalytics } from "./site-settings";
import { mayClaimAdmin } from "./admin-claim";
import { forgetSecret, saveSecret } from "./secrets";
import { checkAppleKey, checkGoogleAccount } from "./app-push";
import { AwinError, checkAwinConnection, checkFeedLink, describeSync, refreshProductList, runStoreSync } from "./awin";
import { readFeedLink } from "./awin-data";
import { resolveAllErrors, resolveError } from "./error-log";

// Lets the very first user become admin with no CLI/database access needed.
// claimAdmin() itself re-checks that no admin exists yet, so this stays safe
// even if two people race to submit the form.
export async function claimAdminAction() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin-claim");
  if (!mayClaimAdmin(user)) redirect("/admin-claim?error=owner");

  const claimed = claimAdmin(user.id);
  redirect(claimed ? "/admin" : "/admin-claim?error=taken");
}

function revalidateDealSurfaces(slug?: string) {
  revalidatePath("/admin");
  revalidatePath("/");
  revalidatePath("/admin/deals");
  if (slug) revalidatePath(`/deals/${slug}`);
}

// Approve / reject / take down / restore one deal. Removing a deal needs a
// reason, which the poster sees on their profile.
// The deal is found from its slug alone (never from an id the form sent), and
// nothing changes, returning false, for a deal by someone the actor doesn't
// outrank: they escalate those instead.
function applyDealStatus(
  actor: Parameters<typeof logAudit>[0] & { id: string },
  slug: string,
  status: "live" | "pending" | "removed",
  reason: { reason: string; note: string } | null
): boolean {
  const before = getAdminDealsView().find((d) => d.slug === slug);
  if (!before || !mayManageDeal(actor, before)) return false;
  const deal = { slug, source: before.source, id: before.dbId ?? "" };
  const was = before ? getDealStatus(before) : "unknown";
  // A live deal that has only ended (not the poster's fault) is marked as
  // ended, exactly as when staff tap "Deal ended?", rather than taken down: it
  // stays up labelled as expired and still counts for its poster. "Clear ended
  // reports" undoes it. Rejecting a pending deal for this reason still rejects.
  if (status === "removed" && reason?.reason === ENDED_REMOVAL_REASON && was !== "pending" && was !== "removed") {
    reportDeal(deal.slug, actor.id, ENDED_REASON);
    logAudit(actor, "deal.ended", { label: before?.title ?? deal.slug, url: `/deals/${deal.slug}`, targetId: deal.slug });
    return true;
  }
  if (deal.source === "seed") {
    // Seed deals are pre-curated, not user submissions — they're never
    // "pending", so this only ever narrows to "live" or "removed" here.
    if (status !== "pending") setSeedDealStatus(deal.slug, status);
  } else {
    setDbDealStatus(deal.id, status, status === "removed" && reason ? reason : undefined);
  }
  if (status !== "pending" && status !== was) {
    // Tell the poster, and once a deal goes live, anyone whose alerts match it.
    const change = status === "removed" ? (was === "pending" ? "rejected" : "removed") : was === "pending" ? "approved" : "restored";
    if (before && deal.source !== "seed") {
      notifyDealStatus(before, change, reason?.reason);
      if (status === "live") notifyAlertMatches(deal.slug);
    }
  }
  // Approved or restored by the team: checked. Taken down: not any more.
  if (status === "live") markDealChecked(deal.slug, actor.id);
  else if (status === "removed") clearDealCheck(deal.slug);
  if (status !== "pending") {
    const action =
      status === "removed" ? (was === "pending" ? "deal.reject" : "deal.takedown") : was === "pending" ? "deal.approve" : "deal.restore";
    logAudit(actor, action, {
      label: before?.title ?? deal.slug,
      url: `/deals/${deal.slug}`,
      targetId: deal.slug,
      detail: reason ? `${describeReason(reason)} · was ${was}` : `Was ${was}`,
    });
  }
  return true;
}

export async function setDealStatusAction(formData: FormData) {
  const actor = await requirePermission("deals.review");
  const status = String(formData.get("status")) as "live" | "pending" | "removed";
  const slug = String(formData.get("slug") ?? "");
  const reason = status === "removed" ? readReason(formData, dealRemovalReasons()) : null;
  if (status === "removed" && !reason) {
    redirect("/admin/deals?error=" + encodeURIComponent('Pick a reason (and add a note if you chose "Other").'));
  }
  // Someone else dealt with it since this page was shown: change nothing, say so.
  const clash = dealClash(slug, seenFrom(formData), actor.id);
  if (clash) await bounceWithClash(clashText(clash, undefined, getDealBySlug(slug)?.title), "/admin/deals");
  applyDealStatus(actor, slug, status, reason);
  revalidateDealSurfaces(slug);
}

// The same, for every ticked deal in the pending queue at once.
export async function bulkDealStatusAction(formData: FormData) {
  const actor = await requirePermission("deals.review");
  const status = String(formData.get("status")) === "removed" ? "removed" : "live";
  const reason = status === "removed" ? readReason(formData, dealRemovalReasons()) : null;
  if (status === "removed" && !reason) {
    redirect("/admin/deals?status=pending&error=" + encodeURIComponent("Pick a reason for rejecting."));
  }
  const picked = formData.getAll("pick").map(String).slice(0, 100);
  if (picked.length === 0) {
    redirect("/admin/deals?status=pending&error=" + encodeURIComponent("Tick at least one deal first."));
  }
  // Any that someone else dealt with since the queue was shown are left alone.
  const seen = seenFrom(formData);
  const checked = picked.map((slug) => ({ slug, clash: dealClash(slug, seen, actor.id) }));
  const clashes = checked.flatMap((c) => (c.clash ? [c.clash] : []));
  const free = checked.filter((c) => !c.clash).map((c) => c.slug);
  const done = free.filter((slug) => applyDealStatus(actor, slug, status, reason)).length;
  revalidateDealSurfaces();
  const left = clashes.length
    ? ` ${clashes.length} had already been dealt with by ${[...new Set(clashes.map((c) => c.username))].join(" and ")}, so ${clashes.length === 1 ? "it was" : "they were"} left alone.`
    : "";
  redirect(
    "/admin/deals?status=pending&notice=" +
      encodeURIComponent(`${status === "live" ? "Approved" : "Rejected"} ${done} deal${done === 1 ? "" : "s"}.${left}`)
  );
}

// A moderator hands something to the admins with a note.
export async function escalateAction(formData: FormData) {
  const actor = await requirePermission("deals.review");
  const kind = String(formData.get("kind"));
  if (kind !== "deal" && kind !== "user" && kind !== "comment") return;
  const note = String(formData.get("note") ?? "").trim();
  const back = String(formData.get("back") ?? "/admin");
  const safeBack = back.startsWith("/admin") ? back : "/admin";
  if (!note) redirect(`${safeBack}${safeBack.includes("?") ? "&" : "?"}error=${encodeURIComponent("Add a note for the admins.")}`);
  const targetId = String(formData.get("targetId") ?? "");
  const targetLabel = String(formData.get("targetLabel") ?? targetId);
  const targetUrl = String(formData.get("targetUrl") ?? "") || undefined;
  createEscalation({ kind, targetId, targetLabel, targetUrl, note, by: actor });
  logAudit(actor, "escalation.create", { label: targetLabel, url: targetUrl, targetId, detail: note.slice(0, 200) });
  revalidatePath("/admin");
  redirect(`${safeBack}${safeBack.includes("?") ? "&" : "?"}notice=${encodeURIComponent("Sent to the admins.")}`);
}

export async function resolveEscalationAction(formData: FormData) {
  const admin = await requirePermission("escalations.resolve");
  const id = parseInt(String(formData.get("id")), 10);
  const resolution = String(formData.get("note") ?? "").trim() || "Resolved";
  const esc = getEscalationById(id);
  if (!esc) return;
  if (esc.resolvedAt) {
    await bounceWithClash(
      clashText({ username: esc.resolvedByUsername ?? "Another admin", did: "resolved it", at: esc.resolvedAt }, "so nothing was changed."),
      "/admin"
    );
  }
  resolveEscalation(id, admin.username, resolution);
  logAudit(admin, "escalation.resolve", { label: esc.targetLabel, url: esc.targetUrl ?? undefined, targetId: esc.targetId, detail: resolution });
  revalidatePath("/admin");
}

export async function setDealFeaturedAction(formData: FormData) {
  const actor = await requirePermission("deals.curate");
  const featured = formData.get("featured") === "true";
  const slug = String(formData.get("slug") ?? "");
  // The deal is found from its slug alone (never from an id or source the form
  // sent), so a doctored form can't feature one deal and log another, and
  // someone the actor doesn't outrank can't be changed behind a form.
  const deal = getAdminDealsView().find((d) => d.slug === slug);
  if (!deal || !mayManageDeal(actor, deal)) return;
  const clash = dealClash(slug, seenFrom(formData), actor.id);
  if (clash) await bounceWithClash(clashText(clash, undefined, deal.title), "/admin/deals");

  if (deal.source === "seed") {
    setSeedDealFeatured(slug, featured);
  } else {
    setDbDealFeatured(deal.dbId ?? "", featured);
  }
  logAudit(actor, featured ? "deal.feature" : "deal.unfeature", {
    targetId: slug,
    label: deal.title,
    url: `/deals/${slug}`,
  });
  revalidateDealSurfaces(slug);
}

// Makes one deal the site's Hero deal, replacing whichever one held the slot —
// or, with hero=false, empties the slot. Only a publicly live deal can be Hero.
export async function setDealHeroAction(formData: FormData) {
  const actor = await requirePermission("deals.curate");
  const slug = String(formData.get("slug") ?? "");
  const makeHero = formData.get("hero") === "true";
  const previous = getHeroSlug();

  if (makeHero) {
    const deal = getAdminDealsView().find((d) => d.slug === slug);
    const status = deal ? getDealStatus(deal) : undefined;
    if (!deal || (status !== "live" && status !== "featured" && status !== "hero")) return;
    setHeroSlug(slug);
    logAudit(actor, "deal.hero", { label: deal.title, url: `/deals/${slug}`, targetId: slug });
  } else if (previous === slug) {
    setHeroSlug("");
    logAudit(actor, "deal.unhero", { targetId: slug, label: getAdminDealsView().find((d) => d.slug === slug)?.title ?? slug, url: `/deals/${slug}` });
  }

  revalidateDealSurfaces(slug);
  if (previous && previous !== slug) revalidatePath(`/deals/${previous}`);
  revalidatePath("/admin");
}

export async function deleteDealAction(formData: FormData) {
  const actor = await requirePermission("deals.delete");
  const doomed = getDbDealById(String(formData.get("id")));
  if (!doomed || !mayManageDeal(actor, doomed)) return;
  deleteDbDeal(doomed.id);
  logAudit(actor, "deal.delete", {
    targetId: doomed.slug,
    label: doomed.title,
    detail: `Posted by ${doomed.postedByUsername ?? "unknown"} · ${doomed.store}`,
  });
  revalidateDealSurfaces(doomed.slug);
}

// Members (or staff) said a deal had ended but it hasn't: clear those reports
// so it's live again.
export async function clearEndedReportsAction(formData: FormData) {
  const actor = await requirePermission("deals.review");
  const slug = String(formData.get("slug") ?? "");
  const deal = getDealBySlug(slug);
  if (deal && !mayManageDeal(actor, deal)) return;
  const clash = dealClash(slug, seenFrom(formData), actor.id);
  if (clash) await bounceWithClash(clashText(clash, undefined, deal?.title), "/admin/deals");
  // Only a deal members actually ended earns its reporters a strike — not one
  // the team ended, even if some members had also reported it.
  clearEndedReports(slug, !!deal?.endedByMembers && !deal.endedByStaff && !deal.endedByPoster);
  markDealChecked(slug, actor.id);
  logAudit(actor, "deal.unended", { targetId: slug, label: deal?.title ?? slug, url: `/deals/${slug}` });
  revalidateDealSurfaces(slug);
}

// Taking staff access away (moderator or admin back to member). Giving it is
// deliberately NOT done here — see promoteUserAction, which asks for several
// confirmations. Admins only.
export async function setUserRoleAction(formData: FormData) {
  const admin = await requirePermission("users.roles");
  const userId = String(formData.get("userId"));
  const role = String(formData.get("role"));
  if (role !== "user") return; // giving moderator/admin goes through promoteUserAction

  // Prevent an admin from locking themselves out as the last admin.
  if (userId === admin.id) {
    redirect("/admin/users?error=" + encodeURIComponent("You can't change your own role"));
  }

  const target = findUserById(userId);
  if (!target) return;
  setUserRole(userId, role);
  setModProbation(userId, null);
  logAudit(admin, "user.demote", { targetId: target.id, label: target.username, detail: `Was ${target.role}` });
  console.warn(`[admin] ${admin.username} (${admin.id}) set ${target.username} (${target.id}) to ${role}`);
  revalidatePath("/admin/users");
}

// Giving someone staff powers (moderator or admin) needs a deliberate,
// multi-step confirmation: tick the box, type the person's exact username, and
// re-enter YOUR password (so an unattended or hijacked browser session can't
// hand out access). Wrong passwords are rate-limited. Admins only.
const PROMOTE_MAX_ATTEMPTS = 3;
const PROMOTE_WINDOW_MS = 15 * 60 * 1000;

export async function promoteUserAction(formData: FormData) {
  const admin = await requirePermission("users.roles");
  const userId = String(formData.get("userId") ?? "");
  const newRole = String(formData.get("role") ?? "");
  if (newRole !== "moderator" && newRole !== "admin") return;
  const typedUsername = String(formData.get("username") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  const understood = formData.get("understood") === "on";
  const back = `/admin/users/${encodeURIComponent(userId)}/make-${newRole}`;
  const fail = (message: string): never => redirect(`${back}?error=${encodeURIComponent(message)}`);
  const word = newRole === "admin" ? "an admin" : "a moderator";

  const target = findUserById(userId);
  if (!target) redirect("/admin/users?error=" + encodeURIComponent("That user no longer exists"));
  if (target.id === admin.id) redirect("/admin/users?error=" + encodeURIComponent("You can't change your own role"));
  if (target.role === newRole) redirect("/admin/users?error=" + encodeURIComponent(`${target.username} is already ${word}`));
  if (target.role === "admin") redirect("/admin/users?error=" + encodeURIComponent(`${target.username} is already an admin`));
  if (target.suspended) fail(`Unsuspend this account before making it ${word}.`);
  if (!understood) fail("Tick the box to confirm you understand what this access allows.");
  if (typedUsername !== target.username) fail("The username you typed doesn't match. Type it exactly as shown.");

  const key = `promote:${admin.id}`;
  const { count, oldest } = getRecentFailedLogins(key, PROMOTE_WINDOW_MS);
  if (count >= PROMOTE_MAX_ATTEMPTS) {
    const minutes = Math.max(1, Math.ceil(((oldest ?? Date.now()) + PROMOTE_WINDOW_MS - Date.now()) / 60000));
    fail(`Too many wrong passwords. Try again in ${minutes} minute${minutes === 1 ? "" : "s"}.`);
  }
  if (!verifyPassword(admin.email, password)) {
    recordFailedLogin(key);
    fail("That password isn't right. Enter your own admin password.");
  }
  clearFailedLogins(key);

  setUserRole(target.id, newRole);
  const probationDays = getSiteSettings().probationDays;
  const probationUntil =
    newRole === "moderator" && formData.get("probation") === "on" && probationDays > 0
      ? new Date(Date.now() + probationDays * 24 * 60 * 60 * 1000).toISOString()
      : null;
  setModProbation(target.id, probationUntil);
  logAudit(admin, "user.promote", { targetId: target.id, label: target.username, detail: `Made ${newRole}` });
  console.warn(`[admin] ${admin.username} (${admin.id}) made ${target.username} (${target.id}) ${word}`);
  revalidatePath("/admin/users");
  redirect("/admin/users?notice=" + encodeURIComponent(`${target.username} is now ${word}.`));
}

// Making a member a helper (see lib/permissions.ts): fix details on live
// deals and mark them ended, nothing that removes or reaches into /admin, so
// it's one confirmed click rather than promoteUserAction's several steps.
// Taking it away is setUserRoleAction. Admins only.
export async function makeHelperAction(formData: FormData) {
  const admin = await requirePermission("users.roles");
  const target = findUserById(String(formData.get("userId") ?? ""));
  const back = (key: "notice" | "error", message: string): never =>
    redirect(`/admin/users?${key}=${encodeURIComponent(message)}`);
  if (!target) redirect("/admin/users?error=" + encodeURIComponent("That user no longer exists"));
  if (target.id === admin.id) back("error", "You can't change your own role");
  if (target.role !== "user") back("error", `${target.username} is already ${target.role === "helper" ? "a helper" : "on the team"}`);
  if (target.suspended || target.deletedAt) back("error", `${target.username}'s account isn't active`);

  setUserRole(target.id, "helper");
  logAudit(admin, "user.promote", { targetId: target.id, label: target.username, detail: "Made helper" });
  revalidatePath("/admin/users");
  back("notice", `${target.username} is now a ${ROLE_LABELS.helper}.`);
}

export async function setUserSuspendedAction(formData: FormData) {
  const actor = await requirePermission("users.suspend");
  const userId = String(formData.get("userId"));
  const suspended = formData.get("suspended") === "true";
  const back = String(formData.get("back") ?? "/admin/users");
  const safeBack = back.startsWith("/admin") ? back : "/admin/users";
  const go = (key: "error" | "notice", msg: string): never =>
    redirect(`${safeBack}${safeBack.includes("?") ? "&" : "?"}${key}=${encodeURIComponent(msg)}`);

  if (userId === actor.id) go("error", "You can't suspend your own account");

  // Moderators can only act on regular members, never on other staff.
  const target = findUserById(userId);
  if (!target) return;
  if (!mayManageAccount(actor.role, target.role)) go("error", "Only an admin can suspend other staff");

  if (suspended) {
    const reason = readReason(formData, suspensionReasons()) ?? go("error", 'Pick a reason (and add a note if you chose "Other").');
    const until = suspensionEnds(String(formData.get("duration") ?? "7"));
    suspendUser(userId, { until, reason: describeReason(reason) });
    logAudit(actor, "user.suspend", {
      targetId: target.id,
      label: target.username,
      detail: `${describeReason(reason)} · ${until ? `until ${formatDate(until)}` : "until lifted"}`,
    });
  } else {
    unsuspendUser(userId);
    logAudit(actor, "user.unsuspend", { targetId: target.id, label: target.username, detail: `Was ${target.role}` });
  }
  revalidatePath("/admin/users");
  go("notice", `${target.username} ${suspended ? "is suspended and has been signed out" : "is no longer suspended"}.`);
}

export async function deleteCommentAction(formData: FormData) {
  const actor = await requirePermission("comments.moderate");
  const id = String(formData.get("id"));
  await stopIfCommentHandled(id, formData, actor.id);
  removeCommentAsTeam(actor, id);
}

// A comment someone else deleted or cleared since the page was shown: say who,
// change nothing. (Its log entries are kept against the commenter's id.)
async function stopIfCommentHandled(commentId: string, formData: FormData, actorId: string) {
  const comment = getCommentForModeration(commentId);
  if (!comment) return;
  const clash = targetClash(comment.userId, seenFrom(formData), actorId, ["comment.delete", "comment.dismiss"]);
  if (clash || comment.deleted) {
    await bounceWithClash(
      clash ? clashText({ ...clash, did: comment.deleted ? "deleted this comment" : clash.did === "dismissed its reports" ? "dismissed this comment's reports" : clash.did }) : "This comment was already deleted, so nothing was changed.",
      "/admin/comments"
    );
  }
}

export async function dismissCommentReportsAction(formData: FormData) {
  const actor = await requirePermission("comments.moderate");
  const commentId = String(formData.get("commentId"));
  await stopIfCommentHandled(commentId, formData, actor.id);
  const comment = getCommentForModeration(commentId);
  if (!comment || comment.deleted || !mayManageComment(actor, comment)) return;
  dismissCommentReports(commentId);
  logAudit(actor, "comment.dismiss", {
    targetId: comment.userId,
    label: comment.username,
    url: `/deals/${comment.dealSlug}`,
    detail: `Dismissed ${comment.reportCount} report${comment.reportCount === 1 ? "" : "s"} on "${comment.text.slice(0, 120)}"`,
  });
  revalidatePath("/admin/comments");
  revalidatePath(`/deals/${comment.dealSlug}`);
}

export async function setMaintenanceModeAction(formData: FormData) {
  const actor = await requirePermission("settings.security");
  const enabled = formData.get("enabled") === "true";
  const message = String(formData.get("message") ?? "").trim();

  setSiteSetting("maintenance_mode", enabled ? "1" : "0");
  setSiteSetting(
    "maintenance_message",
    message || "We're doing some quick maintenance and will be back shortly."
  );
  logAudit(actor, "settings.change", { label: `Maintenance mode turned ${enabled ? "on" : "off"}` });
  revalidatePath("/admin/settings");
  settingsRedirect("general", { saved: "1" });
}

// ---------------------------------------------------------------------------
// Site settings forms (General / Tracking & code / Security tabs)
// ---------------------------------------------------------------------------

function settingsRedirect(tab: string, params: Record<string, string> = {}): never {
  const query = new URLSearchParams({ tab, ...params });
  redirect(`/admin/settings?${query.toString()}`);
}

// Admin → Earnings (affiliate links, Awin and each store's programme).
function earningsPage(params: Record<string, string> = {}): never {
  const query = new URLSearchParams(params).toString();
  redirect(query ? `/admin/earnings?${query}` : "/admin/earnings");
}

function checked(formData: FormData, name: string): "1" | "0" {
  return formData.get(name) === "on" ? "1" : "0";
}

export async function saveGeneralSettingsAction(formData: FormData) {
  const actor = await requirePermission("settings.manage");

  setSiteSetting("site_title", String(formData.get("siteTitle") ?? "").trim().slice(0, 120));
  setSiteSetting("site_description", String(formData.get("siteDescription") ?? "").trim().slice(0, 300));
  setSiteSetting("hide_from_search_engines", checked(formData, "hideFromSearchEngines"));
  setSiteSetting("search_console_token", extractSearchConsoleToken(String(formData.get("searchConsole") ?? "")));

  logAudit(actor, "settings.change", { label: "General: site details and search engines" });
  revalidatePath("/", "layout");
  settingsRedirect("general", { saved: "1" });
}

// The logo and browser icon (lib/site-brand.ts): any picture chosen is
// saved, the name-beside-it tick is kept, and "remove" puts one back to the
// built-in one.
export async function saveSiteBrandAction(formData: FormData) {
  const actor = await requirePermission("settings.manage");
  const remove = String(formData.get("remove") ?? "");
  if (remove === "logo" || remove === "logoDark" || remove === "icon") {
    removeBrandPicture(remove);
    logAudit(actor, "settings.change", { label: remove === "icon" ? "Browser icon: back to the standard one" : remove === "logo" ? "Logo: back to the standard one" : "Logo: dark mode copy removed" });
    revalidatePath("/", "layout");
    settingsRedirect("general", { note: remove === "icon" ? "The standard icon is back." : remove === "logo" ? "The standard logo is back." : "The dark mode logo is gone: the usual one shows in dark mode too." });
  }
  const chosen = (name: string) => {
    const file = formData.get(name);
    return file instanceof File && file.size > 0 ? file : null;
  };
  const changed: string[] = [];
  try {
    const logo = chosen("logo");
    if (logo) {
      await saveLogo(logo);
      changed.push("logo");
    } else {
      setShowSiteName(formData.get("showName") === "1");
    }
    const dark = chosen("logoDark");
    if (dark) {
      if (!getSiteBrand().logo) throw new BrandImageError("Upload the logo first, then its dark mode copy.");
      await saveLogo(dark, true);
      changed.push("dark mode logo");
    }
    const icon = chosen("icon");
    if (icon) {
      await saveIcon(icon);
      changed.push("browser icon");
    }
  } catch (e) {
    if (e instanceof BrandImageError) settingsRedirect("general", { error: e.message });
    throw e;
  }
  logAudit(actor, "settings.change", { label: changed.length ? `New ${changed.join(", ")}` : "Logo: site name beside it" });
  revalidatePath("/", "layout");
  settingsRedirect("general", { saved: "1" });
}

export async function saveTrackingSettingsAction(formData: FormData) {
  const actor = await requirePermission("settings.revenue");

  const googleInput = String(formData.get("googleCode") ?? "").trim();
  const { gaId, gtmId } = extractGoogleIds(googleInput);
  if (googleInput && !gaId && !gtmId) {
    settingsRedirect("tracking", {
      error: looksLikeOldAnalytics(googleInput)
        ? "That's an old Universal Analytics code (UA-…), which Google stopped collecting data for in 2023. Use the Google Analytics 4 ID that starts with G-, or a Tag Manager ID starting GTM-."
        : "Couldn't find a Google Analytics ID (G-…) or Tag Manager ID (GTM-…) in that. Paste the snippet Google gave you, or just the ID.",
    });
  }

  // The cookie banner has to name who gets visitors' data, so custom code
  // can't be saved without saying who it's from.
  const headCode = String(formData.get("headCode") ?? "").trim().slice(0, 20000);
  const footerCode = String(formData.get("footerCode") ?? "").trim().slice(0, 20000);
  const partners = String(formData.get("marketingPartners") ?? "").replace(/\s+/g, " ").trim().slice(0, 120);
  if ((headCode || footerCode) && !partners) {
    settingsRedirect("tracking", {
      error: "Say who the custom code is from (for example Meta), so the cookie banner can tell visitors who gets their data.",
    });
  }

  setSiteSetting("ga_id", gaId);
  setSiteSetting("gtm_id", gtmId);
  setSiteSetting("head_code", headCode);
  setSiteSetting("footer_code", footerCode);
  setSiteSetting("marketing_partners", partners);

  logAudit(actor, "settings.change", { label: "Tracking and custom code" });
  revalidatePath("/", "layout");
  settingsRedirect("tracking", { saved: "1" });
}

export async function saveSecuritySettingsAction(formData: FormData) {
  const actor = await requirePermission("settings.security");

  const attempts = Math.min(20, Math.max(3, parseInt(String(formData.get("loginMaxAttempts")), 10) || 5));
  const minutes = Math.min(1440, Math.max(1, parseInt(String(formData.get("loginLockoutMinutes")), 10) || 15));

  setSiteSetting("login_protection", checked(formData, "loginProtection"));
  setSiteSetting("login_max_attempts", String(attempts));
  setSiteSetting("login_lockout_minutes", String(minutes));

  logAudit(actor, "settings.change", { label: "Security: login protection" });
  settingsRedirect("security", { saved: "1" });
}


// ---------------------------------------------------------------------------
// Stores
// ---------------------------------------------------------------------------

// A store's name shows on every card, so a change touches the whole site.
function revalidateStoreSurfaces() {
  revalidatePath("/", "layout");
}

function storesRedirect(path: string, params: Record<string, string>): never {
  redirect(`${path}?${new URLSearchParams(params).toString()}`);
}

// Renames a store everywhere. The old name keeps pointing at it (alias), so
// old links and anyone typing the old name still land on the same store.
export async function renameStoreAction(formData: FormData) {
  const actor = await requirePermission("stores.manage");
  const key = String(formData.get("key") ?? "");
  const name = String(formData.get("name") ?? "").replace(/\s+/g, " ").trim();
  const store = getAdminStores().find((s) => s.key === key);
  if (!store) storesRedirect("/admin/stores", { error: "That store no longer exists." });
  const here = `/admin/stores/${store.slug}`;

  if (!name) storesRedirect(here, { error: "Enter a name for the store." });
  if (name.length > 60) storesRedirect(here, { error: "Store names can be up to 60 characters." });

  const clash = getAdminStores().find((s) => s.key !== key && (s.key === storeKey(name) || slugify(s.name) === slugify(name)));
  if (clash) {
    storesRedirect(here, { error: `"${clash.name}" is already a store. Use "Merge into another store" to combine them.` });
  }

  setStoreNameOverride(key, name);
  // Typing the new name later must resolve to this same store.
  if (storeKey(name) !== key) addStoreAlias(storeKey(name), name, key);

  logAudit(actor, "store.change", { label: name, url: `/admin/stores/${slugify(name)}`, detail: `Renamed from ${store.name}` });
  revalidateStoreSurfaces();
  storesRedirect(`/admin/stores/${slugify(name)}`, { saved: "renamed" });
}

// Folds one store into another: its deals show under the target's name and
// its page redirects to the target's. Reversible with "Unmerge".
export async function mergeStoreAction(formData: FormData) {
  const actor = await requirePermission("stores.manage");
  const fromKey = String(formData.get("fromKey") ?? "");
  const intoKey = String(formData.get("intoKey") ?? "");
  const stores = getAdminStores();
  const from = stores.find((s) => s.key === fromKey);
  const into = stores.find((s) => s.key === intoKey);
  if (!from || !into || from.key === into.key) {
    storesRedirect("/admin/stores", { error: "Pick two different stores to merge." });
  }

  // Keep the target's current name, rather than letting whichever spelling has
  // more deals win once the two are combined.
  setStoreNameOverride(into.key, into.name);
  addStoreAlias(from.key, from.name, into.key);
  for (const alias of from.aliases) addStoreAlias(alias.key, alias.name, into.key);

  logAudit(actor, "store.change", { label: into.name, url: `/admin/stores/${into.slug}`, detail: `Merged ${from.name} into it` });
  revalidateStoreSurfaces();
  storesRedirect(`/admin/stores/${into.slug}`, { saved: "merged" });
}

// Splits a merged name back out into a store of its own.
export async function unmergeStoreAction(formData: FormData) {
  const actor = await requirePermission("stores.manage");
  const aliasKey = String(formData.get("aliasKey") ?? "");
  const returnTo = String(formData.get("slug") ?? "");
  removeStoreAlias(aliasKey);
  logAudit(actor, "store.change", { label: aliasKey, detail: "Unmerged a store" });
  revalidateStoreSurfaces();
  storesRedirect(returnTo ? `/admin/stores/${returnTo}` : "/admin/stores", { saved: "unmerged" });
}

// Store logos: uploaded by hand, or fetched from the store's own website.
export async function uploadStoreLogoAction(formData: FormData) {
  const actor = await requirePermission("stores.manage");
  const key = String(formData.get("key") ?? "");
  const store = getAdminStores().find((s) => s.key === key);
  if (!store) storesRedirect("/admin/stores", { error: "That store no longer exists." });
  const file = formData.get("logo");
  if (!(file instanceof File) || file.size === 0) {
    storesRedirect(`/admin/stores/${store.slug}`, { error: "Choose an image to upload." });
  }
  try {
    const bytes = await readLogoUpload(file);
    setStoreLogo(key, bytes, checkStoreLogo(bytes));
  } catch (e) {
    if (e instanceof StoreLogoError) storesRedirect(`/admin/stores/${store.slug}`, { error: e.message });
    throw e;
  }
  logAudit(actor, "store.change", { label: store.name, url: `/admin/stores/${store.slug}`, detail: "Uploaded a logo" });
  revalidateStoreSurfaces();
  storesRedirect(`/admin/stores/${store.slug}`, { saved: "logo" });
}

export async function fetchStoreLogoAction(formData: FormData) {
  const actor = await requirePermission("stores.manage");
  const key = String(formData.get("key") ?? "");
  const store = getAdminStores().find((s) => s.key === key);
  if (!store) storesRedirect("/admin/stores", { error: "That store no longer exists." });
  const here = `/admin/stores/${store.slug}`;

  const website = cleanWebsite(String(formData.get("website") ?? ""));
  if (!website) storesRedirect(here, { error: "Enter the store's website, like currys.co.uk." });

  setStoreWebsite(key, website);
  const bytes = await fetchStoreLogo(website);
  if (!bytes) {
    storesRedirect(here, { error: `Couldn't find a logo on ${website}. Check the address, or upload one instead.` });
  }
  setStoreLogo(key, bytes, checkStoreLogo(bytes));
  logAudit(actor, "store.change", { label: store.name, url: here, detail: `Fetched a logo from ${website}` });
  revalidateStoreSurfaces();
  storesRedirect(here, { saved: "logo" });
}

// The store page's "About" text and quick facts (delivery, returns…). A fact
// with no short version is left off the page.
export async function saveStoreDetailsAction(formData: FormData) {
  const actor = await requirePermission("stores.manage");
  const key = String(formData.get("key") ?? "");
  const store = getAdminStores().find((s) => s.key === key);
  if (!store) storesRedirect("/admin/stores", { error: "That store no longer exists." });
  const text = (name: string, max: number) => String(formData.get(name) ?? "").replace(/\s+/g, " ").trim().slice(0, max);
  const facts: StoreDetails["facts"] = {};
  for (const f of STORE_FACTS) {
    const short = text(`${f.key}_short`, STORE_DETAIL_LIMITS.short);
    const detail = text(`${f.key}_detail`, STORE_DETAIL_LIMITS.detail);
    if (short) facts[f.key] = { short, detail };
  }
  setStoreDetailsRow(key, { about: text("about", STORE_DETAIL_LIMITS.about), facts });
  // The yes/no facts the Stores page filters by; cleanPerks keeps only known values.
  setStorePerks(
    key,
    cleanPerks({
      delivery: formData.get("perk_delivery"),
      deliveryMin: formData.get("perk_min"),
      collect: formData.get("perk_collect") === "1",
      freeReturns: formData.get("perk_returns") === "1",
      student: formData.get("perk_student") === "1",
      priceMatch: formData.get("perk_match") === "1",
    })
  );
  logAudit(actor, "store.change", { label: store.name, url: `/admin/stores/${store.slug}`, detail: "Updated the store details" });
  revalidateStoreSurfaces();
  storesRedirect(`/admin/stores/${store.slug}`, { saved: "details" });
}

export async function removeStoreLogoAction(formData: FormData) {
  const actor = await requirePermission("stores.manage");
  const key = String(formData.get("key") ?? "");
  const store = getAdminStores().find((s) => s.key === key);
  clearStoreLogo(key);
  logAudit(actor, "store.change", { label: store?.name ?? key, detail: "Removed the logo" });
  revalidateStoreSurfaces();
  storesRedirect(store ? `/admin/stores/${store.slug}` : "/admin/stores", { saved: "logo-removed" });
}

// One click for every store that has no logo yet, using the website its deal
// links point at (or the one set on the store). Stores it can't find stay as they are.
export async function fetchMissingStoreLogosAction() {
  const actor = await requirePermission("stores.manage");
  const todo = getAdminStores().filter((s) => !s.logoUrl && s.website && s.live + s.expired > 0);
  let found = 0;
  for (let i = 0; i < todo.length; i += 6) {
    await Promise.all(
      todo.slice(i, i + 6).map(async (s) => {
        const domain = cleanWebsite(s.website!);
        const bytes = domain ? await fetchStoreLogo(domain) : undefined;
        if (!bytes) return;
        setStoreLogo(s.key, bytes, checkStoreLogo(bytes));
        found++;
      })
    );
  }
  logAudit(actor, "store.change", { label: "All stores", detail: `Fetched missing logos (${found} found)` });
  revalidateStoreSurfaces();
  storesRedirect("/admin/stores", {
    notice: todo.length === 0 ? "Every store already has a logo." : `Found logos for ${found} of ${todo.length} stores.${found < todo.length ? " Open the others to fix their website or upload a logo." : ""}`,
  });
}

// ---------------------------------------------------------------------------
// One member: notes, sessions, two-step reset
// ---------------------------------------------------------------------------

// Handling a reported profile: tidy the offending part, or dismiss the reports.
// Either way the open reports are closed. Moderators can't touch staff profiles.
export async function handleProfileReportAction(formData: FormData) {
  const actor = await requirePermission("users.suspend");
  const userId = String(formData.get("userId"));
  const task = String(formData.get("task"));
  const target = findUserById(userId);
  if (!target) redirect("/admin/users");
  const back = (msg: string, kind: "notice" | "error" = "notice"): never =>
    redirect(`/admin/users/${userId}?${kind}=${encodeURIComponent(msg)}`);
  if (!mayManageAccount(actor.role, target.role)) back("Only admins can change a staff member's profile.", "error");
  const clash = targetClash(target.id, seenFrom(formData), actor.id, ["profile.clean", "profile.dismiss"]);
  if (clash) redirect(`/admin/users/${userId}?clash=${encodeURIComponent(clashText(clash))}`);

  let done: string;
  if (task === "photo") {
    clearUserAvatar(target.id);
    done = "Removed profile picture";
  } else if (task === "bio") {
    clearUserBio(target.id);
    done = "Cleared bio";
  } else if (task === "username") {
    const name = resetUsernameByStaff(target.id);
    done = `Reset username to ${name}`;
  } else {
    resolveProfileReports(target.id, actor.username);
    logAudit(actor, "profile.dismiss", { targetId: target.id, label: target.username });
    revalidatePath("/admin", "layout");
    return back("Reports dismissed.");
  }
  resolveProfileReports(target.id, actor.username);
  logAudit(actor, "profile.clean", { targetId: target.id, label: target.username, detail: done });
  revalidatePath("/", "layout");
  return back(`${done}.`);
}

export async function addUserNoteAction(formData: FormData) {
  const actor = await requirePermission("users.view");
  const userId = String(formData.get("userId"));
  const text = String(formData.get("text") ?? "").trim();
  const target = findUserById(userId);
  if (!target || !text) redirect(`/admin/users/${userId}`);
  addUserNote(userId, actor, text);
  logAudit(actor, "user.note", { targetId: userId, label: target.username, detail: text.slice(0, 200) });
  revalidatePath(`/admin/users/${userId}`);
}

export async function signOutUserAction(formData: FormData) {
  const admin = await requirePermission("users.security");
  const userId = String(formData.get("userId"));
  const target = findUserById(userId);
  if (!target) return;
  deleteSessionsForUser(userId);
  logAudit(admin, "user.signout", { targetId: userId, label: target.username });
  redirect(`/admin/users/${userId}?notice=${encodeURIComponent(`${target.username} has been signed out everywhere.`)}`);
}

export async function resetTwoStepAction(formData: FormData) {
  const admin = await requirePermission("users.security");
  const userId = String(formData.get("userId"));
  const target = findUserById(userId);
  if (!target) return;
  disableTotp(userId);
  deleteSessionsForUser(userId);
  logAudit(admin, "user.2fa-reset", { targetId: userId, label: target.username });
  redirect(`/admin/users/${userId}?notice=${encodeURIComponent(`Two-step login was reset for ${target.username}.`)}`);
}

// Admins mark a probation moderator's actions as checked.
export async function markReviewedAction(formData: FormData) {
  const admin = await requirePermission("activity.view");
  const actorId = String(formData.get("actorId"));
  markAuditReviewed(actorId, admin.username);
  revalidatePath("/admin");
  revalidatePath("/admin/activity");
}

// Emergency buttons in Settings → Security.
export async function signOutEveryoneAction(formData: FormData) {
  const admin = await requirePermission("settings.security");
  const staffOnly = formData.get("scope") === "staff";
  const { getSessionToken } = await import("./auth");
  deleteAllSessions({ staffOnly, keepToken: (await getSessionToken()) ?? undefined });
  logAudit(admin, "settings.change", { label: staffOnly ? "Signed out all staff" : "Signed out everyone" });
  settingsRedirect("security", { saved: "1" });
}

// ---------------------------------------------------------------------------
// More settings: affiliate disclosure, spam limits, moderators
// ---------------------------------------------------------------------------

function wholeFrom(formData: FormData, name: string, fallback: number, min: number, max: number): string {
  const n = parseInt(String(formData.get(name)), 10);
  return String(Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback);
}

export async function saveAffiliateSettingsAction(formData: FormData) {
  const actor = await requirePermission("settings.revenue");
  const amazonTag = String(formData.get("amazonTag") ?? "").trim();
  const skimlinksId = String(formData.get("skimlinksId") ?? "").trim().toUpperCase();
  const template = String(formData.get("affiliateLinkTemplate") ?? "").trim();
  const awinId = String(formData.get("awinPublisherId") ?? "").trim();
  if (amazonTag && !AMAZON_TAG_PATTERN.test(amazonTag)) {
    earningsPage({ error: "That Amazon tag doesn't look right. It's usually your name then -21, like dealsnap-21." });
  }
  if (skimlinksId && !SKIMLINKS_ID_PATTERN.test(skimlinksId)) {
    earningsPage({ error: "That Skimlinks ID doesn't look right. It's numbers with an X in the middle, like 123456X1234567." });
  }
  if (template && !validLinkTemplate(template)) {
    earningsPage({ error: "The other network's link must start with https:// and include {url} where the store's link goes." });
  }
  if (awinId && !AWIN_ID_PATTERN.test(awinId)) {
    earningsPage({ error: "That Awin publisher ID doesn't look right. It's just numbers, like 123456." });
  }
  setSiteSetting("amazon_tag", amazonTag);
  setSiteSetting("awin_publisher_id", awinId);
  setSiteSetting("skimlinks_id", skimlinksId);
  setSiteSetting("affiliate_link_template", template);
  setSiteSetting("show_affiliate_disclosure", checked(formData, "showAffiliateDisclosure"));
  setSiteSetting("affiliate_disclosure", String(formData.get("affiliateDisclosure") ?? "").trim().slice(0, AFFILIATE_DISCLOSURE_MAX));
  logAudit(actor, "settings.change", { label: "Affiliate links" });
  revalidatePath("/", "layout");
  earningsPage({ saved: "1" });
}

// A shop's own affiliate programme: its website, and either its Awin
// merchant ID or any network's link for it (with {url}).
export async function addAffiliateProgrammeAction(formData: FormData) {
  const actor = await requirePermission("settings.revenue");
  const domain = programmeDomain(String(formData.get("domain") ?? ""));
  const merchantId = String(formData.get("merchantId") ?? "").trim();
  const template = String(formData.get("template") ?? "").trim();
  if (!domain) earningsPage({ error: "Add the store's website, like argos.co.uk." });
  if (merchantId && template) earningsPage({ error: "Fill in the Awin merchant ID or the other network's link, not both." });
  if (merchantId && !AWIN_ID_PATTERN.test(merchantId)) {
    earningsPage({ error: "That Awin merchant ID doesn't look right. It's just numbers, like 1599." });
  }
  if (template && !validLinkTemplate(template)) {
    earningsPage({ error: "The network's link must start with https:// and include {url} where the store's link goes." });
  }
  if (!merchantId && !template) earningsPage({ error: "Add the store's Awin merchant ID, or its link from another network." });
  setAffiliateProgramme(merchantId ? { domain, network: "awin", merchantId } : { domain, network: "link", template });
  logAudit(actor, "settings.change", { label: `Affiliate programme for ${domain}` });
  earningsPage({ saved: "1" });
}

// The store programmes list's own actions. A store is picked by its key
// ("m:1599" for an Awin store, "d:argos.co.uk" for one added by hand), and
// its websites are looked up here, never taken from the form. The list's
// search and filter come back with the answer.
function storeProgrammes(formData: FormData) {
  const key = String(formData.get("store") ?? "");
  const all = getAffiliateProgrammes();
  const rows = key.startsWith("m:")
    ? all.filter((p) => p.network === "awin" && p.merchantId === key.slice(2))
    : all.filter((p) => p.domain === key.slice(2));
  if (!key || !rows.length) earningsRedirect(formData, { error: "That store isn't in the list any more." });
  return { rows, name: rows[0].name ?? rows[0].domain };
}

function earningsRedirect(formData: FormData, params: Record<string, string>): never {
  const keep = Object.fromEntries(
    ["q", "show"].map((k) => [k, String(formData.get(k) ?? "").slice(0, 100)]).filter(([, v]) => v)
  );
  earningsPage({ ...keep, ...params });
}

// Stopping a store sends its clicks through the catch-all network instead
// (Skimlinks), and "Sync my stores" leaves it stopped. Its product list goes.
export async function setProgrammeStoppedAction(formData: FormData) {
  const actor = await requirePermission("settings.revenue");
  const { rows, name } = storeProgrammes(formData);
  const stop = formData.get("turn") === "stop";
  setProgrammesStopped(rows.map((r) => r.domain), stop);
  if (stop && rows[0].merchantId && rows[0].network === "awin") setAwinFeedOn(rows[0].merchantId, false);
  logAudit(actor, "settings.change", { label: `${stop ? "Stopped" : "Restarted"} the affiliate programme for ${name}` });
  earningsRedirect(formData, { note: stop ? `${name} stopped: its clicks go through your catch-all network now.` : `${name} is earning through its own programme again.` });
}

// Only for a store added by hand (a synced one would come straight back).
export async function removeStoreProgrammeAction(formData: FormData) {
  const actor = await requirePermission("settings.revenue");
  const { rows, name } = storeProgrammes(formData);
  for (const r of rows) removeAffiliateProgramme(r.domain);
  // Its product list goes too, unless the store has another website here.
  const id = rows[0].merchantId;
  if (id && !getAffiliateProgrammes().some((p) => p.merchantId === id)) setAwinFeedOn(id, false);
  logAudit(actor, "settings.change", { label: `Removed the affiliate programme for ${name}` });
  earningsRedirect(formData, { note: `${name} removed.` });
}

// ---- the Awin connection (lib/awin.ts) ----

// What Awin's API tokens look like: a long run of letters, numbers and dashes.
const AWIN_TOKEN_PATTERN = /^[A-Za-z0-9._~-]{20,500}$/;

// Saved, then tried straight away, so a wrong one shows up at once.
export async function saveAwinTokenAction(formData: FormData) {
  const actor = await requirePermission("settings.revenue");
  const token = String(formData.get("token") ?? "").trim();
  if (!AWIN_TOKEN_PATTERN.test(token)) {
    earningsPage({ error: "That doesn't look like an Awin API token. Copy the whole token from Awin's API credentials page." });
  }
  saveSecret("awin_api_token", token, actor.username);
  logAudit(actor, "settings.change", { label: "Saved the Awin API token" });
  await awinOutcome(actor, "Tested the Awin connection", checkAwinConnection);
}

export async function removeAwinTokenAction() {
  const actor = await requirePermission("settings.revenue");
  forgetSecret("awin_api_token");
  logAudit(actor, "settings.change", { label: "Removed the Awin API token" });
  earningsPage({ note: "Awin token removed. Stores already set up keep earning; product lists stop updating." });
}

// Awin's Create-a-Feed download link, for stores' standard product lists.
// Saved (it holds a key), then tried straight away.
export async function saveAwinFeedLinkAction(formData: FormData) {
  const actor = await requirePermission("settings.revenue");
  const link = readFeedLink(String(formData.get("feedLink") ?? ""));
  if (!link) {
    earningsPage({
      error:
        "That isn't a Create-a-Feed download link. In Create-a-Feed, choose CSV and gzip (or no compression), then copy the whole link (it starts https://productdata.awin.com/).",
    });
  }
  saveSecret("awin_feed_link", link.href, actor.username, link.key.slice(-4));
  logAudit(actor, "settings.change", { label: "Saved the Awin product list link" });
  await awinOutcome(actor, "Tested the Awin product list link", checkFeedLink);
}

export async function removeAwinFeedLinkAction() {
  const actor = await requirePermission("settings.revenue");
  forgetSecret("awin_feed_link");
  logAudit(actor, "settings.change", { label: "Removed the Awin product list link" });
  earningsPage({ note: "Product list link removed. Product lists already downloaded stay until they're turned off." });
}

export async function checkAwinAction() {
  const actor = await requirePermission("settings.revenue");
  await awinOutcome(actor, "Tested the Awin connection", checkAwinConnection);
}

export async function syncAwinStoresAction() {
  const actor = await requirePermission("settings.revenue");
  await awinOutcome(actor, "Synced stores from Awin", async () => ({ message: describeSync(await runStoreSync()) }));
}

// Runs a call to Awin and comes back to Settings with what it said.
async function awinOutcome(actor: Parameters<typeof logAudit>[0], label: string, run: () => Promise<{ message: string }>): Promise<never> {
  let outcome: { note: string } | { error: string };
  try {
    outcome = { note: (await run()).message };
  } catch (e) {
    outcome = { error: e instanceof AwinError ? e.message : "Something went wrong talking to Awin. Try again in a few minutes." };
  }
  logAudit(actor, "settings.change", { label, detail: "error" in outcome ? outcome.error : outcome.note.slice(0, 200) });
  revalidatePath("/admin/earnings");
  earningsPage(outcome);
}

// A store's product list on or off (only for a store with an Awin
// programme), and "Refresh". Downloads run in the background.
export async function setProductListAction(formData: FormData) {
  const actor = await requirePermission("settings.revenue");
  const merchantId = String(formData.get("merchantId") ?? "");
  const turn = String(formData.get("turn") ?? "");
  const store = getAffiliateProgrammes().find((p) => p.network === "awin" && p.merchantId === merchantId);
  if (!store) earningsRedirect(formData, { error: "That store isn't set up with Awin here." });
  const name = store.name ?? store.domain;
  if (turn === "off") {
    setAwinFeedOn(merchantId, false);
    logAudit(actor, "settings.change", { label: `Turned off the product list for ${name}` });
    earningsRedirect(formData, { note: `${name}'s product list is off and deleted.` });
  }
  setAwinFeedOn(merchantId, true);
  void refreshProductList(merchantId);
  logAudit(actor, "settings.change", { label: `${turn === "refresh" ? "Refreshed" : "Turned on"} the product list for ${name}` });
  earningsRedirect(formData, { note: `${name}'s product list is downloading in the background. Reload this page in a few minutes to see how it went.` });
}

export async function saveExtensionSettingsAction(formData: FormData) {
  const actor = await requirePermission("settings.manage");
  const chrome = String(formData.get("extensionChromeUrl") ?? "").trim();
  const firefox = String(formData.get("extensionFirefoxUrl") ?? "").trim();
  for (const link of [chrome, firefox]) {
    if (link && !isExtensionStoreUrl(link)) {
      settingsRedirect("general", { error: "Paste the extension's page from the Chrome Web Store or Firefox Add-ons (starting https://)." });
    }
  }
  setSiteSetting("extension_chrome_url", chrome);
  setSiteSetting("extension_firefox_url", firefox);
  logAudit(actor, "settings.change", { label: "Browser extension links" });
  revalidatePath("/submit");
  settingsRedirect("general", { saved: "1" });
}

// Admin alert emails (lib/admin-alerts.ts): on or off.
export async function saveEmailSettingsAction(formData: FormData) {
  const actor = await requirePermission("settings.manage");
  const on = checked(formData, "adminAlerts");
  setSiteSetting("admin_alert_emails", on);
  logAudit(actor, "settings.change", { label: `Admin alert emails turned ${on === "1" ? "on" : "off"}` });
  settingsRedirect("general", { saved: "1" });
}

// Daily backups kept on the server (lib/backups.ts): on or off.
export async function saveBackupSettingsAction(formData: FormData) {
  const actor = await requirePermission("data.export");
  const on = checked(formData, "autoBackups");
  setSiteSetting("auto_backups", on);
  logAudit(actor, "settings.change", { label: `Daily backups turned ${on === "1" ? "on" : "off"}` });
  settingsRedirect("data", { saved: "1" });
}

export async function saveSpamSettingsAction(formData: FormData) {
  const actor = await requirePermission("settings.security");
  setSiteSetting("spam_protection", checked(formData, "spamProtection"));
  setSiteSetting("block_links_new_accounts", checked(formData, "blockLinksFromNewAccounts"));
  setSiteSetting("new_account_days", wholeFrom(formData, "newAccountDays", 7, 0, 90));
  setSiteSetting("new_account_deals_per_day", wholeFrom(formData, "newAccountDealsPerDay", 3, 1, 100));
  setSiteSetting("deals_per_day", wholeFrom(formData, "dealsPerDay", 15, 1, 500));
  setSiteSetting("new_account_comments_per_hour", wholeFrom(formData, "newAccountCommentsPerHour", 10, 1, 500));
  setSiteSetting("comments_per_hour", wholeFrom(formData, "commentsPerHour", 40, 1, 1000));
  saveBlockedWords(String(formData.get("blockedWords") ?? ""));
  saveBlockedDomains(String(formData.get("blockedDomains") ?? ""));
  logAudit(actor, "settings.change", { label: "Security: spam protection" });
  settingsRedirect("security", { saved: "1" });
}

// Settings → Security: two-step login as a must for everyone with extra
// powers (moderators and admins, and helpers, who change live deals).
export async function saveTwoStepRuleAction(formData: FormData) {
  const actor = await requirePermission("settings.security");
  const turningOn = checked(formData, "requireTwoStepForStaff") === "1";
  if (turningOn && !actor.totpEnabled) {
    settingsRedirect("security", {
      error: "Turn on two-step login for your own account first (Settings → Sign-in & security), so you don't lock yourself out.",
    });
  }
  setSiteSetting("require_two_step_staff", turningOn ? "1" : "0");
  logAudit(actor, "settings.change", { label: `Two-step login for the team ${turningOn ? "required" : "no longer required"}` });
  settingsRedirect("security", { saved: "1" });
}

// Settings → General: how many members saying a deal has ended marks it ended.
export async function saveDealRulesAction(formData: FormData) {
  const actor = await requirePermission("settings.manage");
  setSiteSetting("ended_reports_to_expire", wholeFrom(formData, "endedReportsToExpire", 3, 1, 50));
  setSiteSetting("ended_reports_max", wholeFrom(formData, "endedReportsMax", 8, 1, 50));
  setSiteSetting("deal_list_days", wholeFrom(formData, "dealListDays", MIN_LIST_DAYS, MIN_LIST_DAYS, 1000));
  logAudit(actor, "settings.change", { label: "Deal rules: marking deals ended, and how far back the lists reach" });
  settingsRedirect("general", { saved: "1" });
}

// Team → Rules: probation, the unusual-activity warnings and the guidelines.
export async function saveTeamRulesAction(formData: FormData) {
  const actor = await requirePermission("settings.manage");
  setSiteSetting("probation_days", wholeFrom(formData, "probationDays", 30, 0, 365));
  setSiteSetting("flag_removals_per_hour", wholeFrom(formData, "flagRemovalsPerHour", 10, 2, 500));
  setSiteSetting("flag_actions_per_hour", wholeFrom(formData, "flagActionsPerHour", 30, 5, 1000));
  setSiteSetting("mod_guidelines", String(formData.get("modGuidelines") ?? "").trim().slice(0, 8000));
  logAudit(actor, "settings.change", { label: "Team rules and guidelines" });
  revalidatePath("/admin/guidelines");
  redirect("/admin/team/rules?saved=1");
}

// ---------------------------------------------------------------------------
// Blog
// ---------------------------------------------------------------------------

export async function saveBlogPostAction(formData: FormData) {
  const admin = await requirePermission("blog.manage");
  const id = String(formData.get("id") ?? "") || undefined;
  const back = id ? `/admin/blog/${id}` : "/admin/blog/new";
  const fail = (msg: string): never => redirect(`${back}?error=${encodeURIComponent(msg)}`);

  const title = String(formData.get("title") ?? "").trim().slice(0, 160);
  const slug = slugify(String(formData.get("slug") ?? "").trim() || title).slice(0, 80);
  const excerpt = String(formData.get("excerpt") ?? "").trim().slice(0, 300);
  const category = String(formData.get("category") ?? "");
  const author = String(formData.get("author") ?? "").trim().slice(0, 60) || "DealSnap Team";
  const content = String(formData.get("content") ?? "").replace(/\r\n/g, "\n").trim().slice(0, 50000);
  const status = formData.get("status") === "published" ? "published" : "draft";
  const dateInput = String(formData.get("publishedAt") ?? "").trim();
  const publishedAt = dateInput ? new Date(`${dateInput}T09:00:00`).toISOString() : new Date().toISOString();
  const picks = String(formData.get("picks") ?? "")
    .split("\n")
    .map((line) => line.split("|").map((part) => part.trim()))
    .filter((parts) => parts[0])
    .slice(0, 10)
    .map(([name, price = "", blurb = "", url = ""]) => ({
      name: name.slice(0, 80),
      price: price.slice(0, 20),
      blurb: blurb.slice(0, 240),
      ...(safeHref(url) ? { url: url.slice(0, 500) } : {}),
    }));
  const kindInput = String(formData.get("kind") ?? "");
  const kind = isBlogKind(kindInput) ? kindInput : "tips";
  const takeaways = String(formData.get("takeaways") ?? "")
    .split("\n")
    .map((t) => t.replace(/^[-•*]\s*/, "").trim().slice(0, 200))
    .filter(Boolean)
    .slice(0, 5);
  const featured = formData.get("featured") === "on";
  const dealsQuery = String(formData.get("dealsQuery") ?? "").trim().slice(0, 60);
  const badLink = String(formData.get("picks") ?? "")
    .split("\n")
    .map((line) => line.split("|")[3]?.trim())
    .find((url) => url && !safeHref(url));

  if (!title) fail("Give the post a title.");
  if (!slug) fail("The web address needs some letters or numbers.");
  if (!content) fail("Write the post before saving.");
  if (Number.isNaN(new Date(publishedAt).getTime())) fail("Pick a valid date.");
  if (blogSlugTaken(slug, id)) fail(`Another post already uses the address /blog/${slug}.`);

  // "Prices checked today" stamps the date; left alone, the earlier date stays.
  const checkedAt = formData.get("pricesChecked") === "on" ? new Date().toISOString() : (id ? getBlogRowById(id)?.checkedAt : null) ?? null;
  const savedId = saveBlogRow({ id, slug, title, excerpt, category, author, publishedAt, status, content, picks, kind, takeaways, featured, dealsQuery, checkedAt });

  const file = formData.get("cover");
  if (file instanceof File && file.size > 0) {
    if (file.size > 3 * 1024 * 1024) fail("Cover images must be under 3MB.");
    const bytes = Buffer.from(await file.arrayBuffer());
    const type = imageMimeType(bytes);
    if (!type) fail("Use a PNG, JPG or WEBP image for the cover.");
    setBlogCover(savedId, bytes, type!);
  }

  logAudit(admin, "blog.save", { label: title, url: `/blog/${slug}`, targetId: savedId, detail: status === "published" ? "Published" : "Draft" });
  revalidatePath("/blog");
  revalidatePath(`/blog/${slug}`);
  // A bad pick link is left out rather than refusing the save, so a long post
  // is never lost over one link.
  const saved = status === "published" ? "Saved and published." : "Draft saved.";
  const skipped = badLink ? ` One pick link was left out because it isn't a web address (${badLink.slice(0, 40)}): start links with https://.` : "";
  // A deal card for a deal that isn't on the site draws nothing, so say so.
  const missing = dealSlugsIn(parseBlogContent(content.split(/\n\s*\n/))).filter((d) => !getDealBySlug(d));
  const noDeal = missing.length ? ` A deal card points at a deal that isn't on the site (${missing[0].slice(0, 40)}), so it won't show.` : "";
  redirect(`/admin/blog/${savedId}?notice=${encodeURIComponent(saved + skipped + noDeal)}`);
}

// A picture for inside a post, from the editor's toolbar. The picture is made
// again as a fresh WebP (lib/blog-images.ts); what comes back is the line to
// put in the post.
export async function uploadBlogImageAction(formData: FormData): Promise<{ markup: string } | { error: string }> {
  await requirePermission("blog.manage");
  if (await overLimit("blog-image", 20)) return { error: "That's a lot of pictures at once. Give it a minute." };
  const file = formData.get("image");
  if (!(file instanceof File) || file.size === 0) return { error: "Choose a picture first." };
  const alt = String(formData.get("alt") ?? "").replace(/[\[\]()\n\r]/g, " ").replace(/\s+/g, " ").trim().slice(0, 160);
  try {
    const clean = await cleanBlogImage(Buffer.from(await file.arrayBuffer()));
    const id = saveBlogImage(clean.data, "image/webp");
    return { markup: `![${alt}](${blogImagePath(id, clean.width, clean.height)})` };
  } catch (e) {
    return { error: e instanceof BlogImageError ? e.message : "That picture couldn't be added. Please try another." };
  }
}

export async function deleteBlogPostAction(formData: FormData) {
  const admin = await requirePermission("blog.manage");
  const id = String(formData.get("id"));
  const row = getBlogRowById(id);
  if (!row) redirect("/admin/blog");
  deleteBlogRow(id);
  logAudit(admin, "blog.delete", { label: row.title, targetId: id });
  revalidatePath("/blog");
  redirect(`/admin/blog?notice=${encodeURIComponent(`Deleted "${row.title}".`)}`);
}

// ---- Contact form messages (Admin → Messages) ------------------------------

export async function setContactMessageHandledAction(formData: FormData) {
  await requirePermission("messages.handle");
  const id = Number(formData.get("id"));
  if (!id) return;
  setContactMessageHandled(id, formData.get("handled") === "1");
  revalidatePath("/admin", "layout");
}

export async function deleteContactMessageAction(formData: FormData) {
  await requirePermission("messages.handle");
  const id = Number(formData.get("id"));
  if (!id) return;
  deleteContactMessage(id);
  revalidatePath("/admin", "layout");
}

// ---- the phone apps (mobile/, lib/app-push.ts) ----

// Apple's notification key: the .p8 file from Apple Developer → Keys, with
// its key ID and the team ID. The team ID also lets DealSnap links open in
// the iPhone app (app/.well-known/apple-app-site-association).
export async function saveApplePushKeyAction(formData: FormData) {
  const actor = await requirePermission("settings.security");
  const keyId = String(formData.get("keyId") ?? "").trim().toUpperCase();
  const teamId = String(formData.get("teamId") ?? "").trim().toUpperCase();
  const key = String(formData.get("key") ?? "").trim();
  if (!/^[A-Z0-9]{10}$/.test(keyId) || !/^[A-Z0-9]{10}$/.test(teamId)) {
    settingsRedirect("general", { error: "The key ID and team ID are 10 letters and numbers each, from Apple Developer → Keys and → Membership." });
  }
  if (key.length > 1000 || !key.includes("PRIVATE KEY") || !checkAppleKey(key)) {
    settingsRedirect("general", { error: "That isn't an Apple key. Open the .p8 file in TextEdit and paste all of it, including the BEGIN and END lines." });
  }
  saveSecret("apple_push_key", JSON.stringify({ keyId, teamId, key }), actor.username, keyId.slice(-4));
  setSiteSetting("app_apple_team_id", teamId);
  logAudit(actor, "settings.change", { label: "Saved the iPhone app's notification key" });
  settingsRedirect("general", { saved: "1" });
}

export async function removeApplePushKeyAction() {
  const actor = await requirePermission("settings.security");
  forgetSecret("apple_push_key");
  logAudit(actor, "settings.change", { label: "Removed the iPhone app's notification key" });
  settingsRedirect("general", { note: "Apple key removed. The iPhone app's notifications stop until a new one is saved." });
}

// Google's: the Firebase project's service account (.json file), which sends
// to Android phones.
export async function saveGooglePushAccountAction(formData: FormData) {
  const actor = await requirePermission("settings.security");
  const json = String(formData.get("account") ?? "").trim();
  const account = json.length <= 10_000 ? checkGoogleAccount(json) : undefined;
  if (!account) {
    settingsRedirect("general", {
      error: "That isn't a Firebase service account. In Firebase → Project settings → Service accounts, generate a new private key and paste all of the .json file.",
    });
  }
  saveSecret("google_push_account", json, actor.username, account.project_id.slice(-4));
  logAudit(actor, "settings.change", { label: "Saved the Android app's notification account" });
  settingsRedirect("general", { saved: "1" });
}

export async function removeGooglePushAccountAction() {
  const actor = await requirePermission("settings.security");
  forgetSecret("google_push_account");
  logAudit(actor, "settings.change", { label: "Removed the Android app's notification account" });
  settingsRedirect("general", { note: "Firebase account removed. The Android app's notifications stop until a new one is saved." });
}

// The Android app's signing fingerprint(s), so DealSnap links open in it
// (app/.well-known/assetlinks.json).
export async function saveAndroidAppLinksAction(formData: FormData) {
  const actor = await requirePermission("settings.security");
  const prints = String(formData.get("fingerprints") ?? "")
    .split(/[\s,]+/)
    .filter(Boolean)
    .map((p) => p.toUpperCase());
  if (prints.length > 4 || prints.some((p) => !/^([0-9A-F]{2}:){31}[0-9A-F]{2}$/.test(p))) {
    settingsRedirect("general", { error: "Paste the SHA-256 fingerprint from Play Console → App integrity: 32 pairs of letters and numbers with colons between." });
  }
  setSiteSetting("app_android_sha256", prints.join(" "));
  logAudit(actor, "settings.change", { label: "Saved the Android app's link fingerprint" });
  settingsRedirect("general", { saved: "1" });
}

// Adds a store by hand, before any deal names it: its name, and (if given) its
// website, from which the logo is fetched. It's offered on the post form and
// listed here at once, and gets a public page when its first deal goes live.
export async function addStoreAction(formData: FormData) {
  const actor = await requirePermission("stores.manage");
  const name = String(formData.get("name") ?? "").replace(/[\u0000-\u001f<>]/g, "").replace(/\s+/g, " ").trim();
  if (!name) storesRedirect("/admin/stores/new", { error: "Enter the store's name." });
  if (name.length > 60) storesRedirect("/admin/stores/new", { error: "Store names can be up to 60 characters." });
  const key = storeKey(name);
  const slug = slugify(name);
  if (!key || !slug || slug === "new") storesRedirect("/admin/stores/new", { error: "Use some letters or numbers in the name, and not just \"new\"." });

  const stores = getAdminStores();
  // A store whose deals have all been taken down can be added again.
  const clash = stores.find((s) => !s.gone && (s.key === key || s.slug === slug));
  if (clash) storesRedirect(`/admin/stores/${clash.slug}`, { error: `${clash.name} is already a store.` });
  const merged = getStoreAliasRows().find((r) => r.aliasKey === key);
  if (merged) {
    const into = stores.find((s) => s.key === merged.targetKey);
    storesRedirect("/admin/stores/new", { error: `That name is already merged into ${into?.name ?? "another store"}.` });
  }
  const websiteText = String(formData.get("website") ?? "").trim();
  const website = websiteText ? cleanWebsite(websiteText) : undefined;
  if (websiteText && !website) storesRedirect("/admin/stores/new", { error: "Enter the store's website like currys.co.uk, or leave it empty." });

  setStoreNameOverride(key, name);
  setStoreAdded(key, true);
  let logo = true;
  if (website) {
    setStoreWebsite(key, website);
    const bytes = await fetchStoreLogo(website);
    if (bytes) setStoreLogo(key, bytes, checkStoreLogo(bytes));
    else logo = false;
  }
  logAudit(actor, "store.change", { label: name, url: `/admin/stores/${slug}`, detail: "Added the store" });
  revalidateStoreSurfaces();
  storesRedirect(`/admin/stores/${slug}`, { saved: logo ? "added" : "added-no-logo" });
}

// Takes a store off the site: every deal it still has is taken down (the same
// way the Deals page does it: the reason is recorded, posters are told, and each
// goes in the activity log), and the store drops out of the lists. Restoring
// any one of those deals brings the store back. One that never had a deal is
// simply deleted. Deals by members who outrank the actor are left for an admin.
const MAX_STORE_TAKEDOWN = 1000;
export async function removeStoreAction(formData: FormData) {
  const actor = await requirePermission("stores.manage");
  const key = String(formData.get("key") ?? "");
  const store = getAdminStores().find((s) => s.key === key);
  if (!store) storesRedirect("/admin/stores", { error: "That store no longer exists." });
  const here = `/admin/stores/${store.slug}`;

  const deals = getAdminDealsView().filter((d) => slugify(d.store) === store.slug);
  const open = deals.filter((d) => d.status !== "removed");
  if (deals.length === 0) {
    deleteStoreRows(key);
    logAudit(actor, "store.change", { label: store.name, detail: "Deleted the store (it had no deals)" });
    revalidateStoreSurfaces();
    storesRedirect("/admin/stores", { notice: `Deleted ${store.name}.` });
  }

  const reason = { reason: "Other", note: "The store was removed from the site" };
  let done = 0;
  let skipped = 0;
  for (const deal of open.slice(0, MAX_STORE_TAKEDOWN)) {
    if (applyDealStatus(actor, deal.slug, "removed", reason)) done++;
    else skipped++;
  }
  const more = Math.max(0, open.length - MAX_STORE_TAKEDOWN);
  setStoreAdded(key, false);
  logAudit(actor, "store.change", {
    label: store.name,
    url: here,
    detail: `Removed the store: ${done} deal${done === 1 ? "" : "s"} taken down${skipped ? `, ${skipped} left for an admin` : ""}${more ? `, ${more} still to do` : ""}`,
  });
  revalidateDealSurfaces();
  revalidateStoreSurfaces();
  const left = skipped + more;
  storesRedirect(left ? here : "/admin/stores", {
    [left ? "error" : "notice"]: left
      ? `Took down ${done} deal${done === 1 ? "" : "s"}, but ${left} remain${left === 1 ? "s" : ""}${skipped ? " (posted by someone who outranks you: ask an admin)" : ""}${more ? ". Remove it again to carry on" : ""}.`
      : `Removed ${store.name}: ${done} deal${done === 1 ? "" : "s"} taken down. Restore a deal and the store comes back.`,
  });
}


// Site health: mark one logged error (or all of them) as dealt with. It comes
// back by itself if it happens again.
export async function resolveErrorAction(formData: FormData) {
  const actor = await requirePermission("settings.manage");
  const id = parseInt(String(formData.get("id")), 10);
  if (!Number.isInteger(id)) return;
  resolveError(id);
  logAudit(actor, "settings.change", { label: "marked a site error as dealt with" });
  revalidatePath("/admin/errors");
  revalidatePath("/admin");
}

export async function resolveAllErrorsAction() {
  const actor = await requirePermission("settings.manage");
  resolveAllErrors();
  logAudit(actor, "settings.change", { label: "marked every site error as dealt with" });
  revalidatePath("/admin/errors");
  revalidatePath("/admin");
}
