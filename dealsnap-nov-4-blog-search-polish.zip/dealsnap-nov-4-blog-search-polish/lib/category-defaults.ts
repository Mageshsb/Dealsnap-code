// The starting category › tag › sub-tag tree. It's copied into the database the
// first time the site starts (lib/db.ts); after that Admin → Tags and brands
// owns it, and this file is only read for two things: the seed, and the names
// the built-in autofill word lists (lib/categorize-deal.ts) were written
// against. A tag keeps its seed name as its "built-in" name however it's
// renamed later, so renaming never switches its words off.

import type { CategoryGroup } from "./taxonomy-shared";

export const DEFAULT_CATEGORIES: CategoryGroup[] = [
  {
    name: "Electronics & Computers",
    icon: "laptop",
    hue: "blue",
    tags: [
      {
        name: "Mobile Phone",
        icon: "smartphone",
        subtags: [
          { name: "iPhone", icon: "smartphone", maker: "Apple" },
          { name: "Galaxy Phone", icon: "smartphone", maker: "Samsung" },
        ],
      },
      { name: "Computer", icon: "monitor" },
      {
        name: "Laptop",
        icon: "laptop",
        subtags: [
          { name: "MacBook", icon: "laptop", maker: "Apple" },
          { name: "Chromebook", icon: "laptop" },
        ],
      },
      { name: "Tablet", icon: "tablet", subtags: [{ name: "iPad", icon: "tablet", maker: "Apple" }] },
      { name: "Headphone", icon: "headphones", subtags: [{ name: "AirPods", icon: "headphones", maker: "Apple" }] },
      { name: "Speaker", icon: "speaker" },
      { name: "Camera", icon: "camera" },
      { name: "TV", icon: "tv" },
      { name: "Smartwatch", icon: "watch", subtags: [{ name: "Apple Watch", icon: "watch", maker: "Apple" }] },
      { name: "Storage Device", icon: "hard-drive" },
      { name: "Digital Product", icon: "disc" },
    ],
  },
  {
    name: "Gaming & Entertainment",
    icon: "gamepad",
    hue: "purple",
    tags: [
      { name: "Playstation", icon: "gamepad", maker: "Sony", subtags: [{ name: "PS5", icon: "gamepad" }] },
      { name: "Xbox", icon: "gamepad-classic", maker: "Microsoft", subtags: [{ name: "Xbox Series", icon: "gamepad-classic" }] },
      { name: "Nintendo", icon: "joystick", maker: "Nintendo", subtags: [{ name: "Switch 2", icon: "joystick" }] },
      { name: "PC Game", icon: "mouse" },
      { name: "Mobile Game", icon: "smartphone" },
      { name: "Toy", icon: "toy-brick" },
      { name: "Sport", icon: "ball" },
      { name: "Book and eBook", icon: "book-open" },
    ],
  },
  {
    name: "Clothing & Accessories",
    icon: "shirt",
    hue: "pink",
    tags: [
      { name: "Women's Clothing", icon: "shirt" },
      { name: "Men's Clothing", icon: "shirt" },
      { name: "Kid's Clothing", icon: "baby" },
      { name: "Girl's Clothing", icon: "shirt" },
      { name: "Boy's Clothing", icon: "shirt" },
      { name: "Lingerie", icon: "heart" },
      { name: "Women's Footwear", icon: "footprints" },
      { name: "Men's Footwear", icon: "footprints" },
      { name: "Women's Accessories", icon: "handbag" },
      { name: "Men's Accessories", icon: "glasses" },
    ],
  },
  {
    name: "Health & Beauty",
    icon: "perfume-bottle",
    hue: "teal",
    tags: [
      { name: "Perfume", icon: "perfume-bottle" },
      { name: "Women's Grooming", icon: "scissors" },
      { name: "Men's Grooming", icon: "scissors" },
      { name: "Personal Care", icon: "droplets" },
      { name: "Cosmetic", icon: "tube-lotion" },
    ],
  },
  {
    name: "Home & Living",
    icon: "house",
    hue: "amber",
    tags: [
      { name: "Furniture", icon: "sofa" },
      { name: "Small Appliances", icon: "plug" },
      { name: "Large Appliances", icon: "fridge" },
      { name: "Household Product", icon: "brush" },
      { name: "Home Accessories", icon: "frame" },
      { name: "Kitchenware", icon: "utensils" },
      { name: "Tool", icon: "wrench" },
    ],
  },
  {
    name: "Food, Groceries & Gifting",
    icon: "basket",
    hue: "green",
    tags: [
      { name: "Alcohol", icon: "wine" },
      { name: "Groceries", icon: "basket" },
      { name: "Confectionery", icon: "candy" },
      { name: "Food and Drink", icon: "hamburger" },
      { name: "Flower", icon: "flower" },
      { name: "Hamper", icon: "gift" },
    ],
  },
  {
    name: "Leisure & Travel",
    icon: "plane",
    hue: "sky",
    tags: [
      { name: "Flights", icon: "plane" },
      { name: "Hotels", icon: "hotel" },
      { name: "Holiday Packages", icon: "luggage" },
      { name: "Car Hire", icon: "car" },
    ],
  },
];
