import { headers } from "next/headers";
import { addBlogStats, type BlogCounts } from "./db";
import { BOT_AGENT } from "./deal-click";
import { clientIp } from "./client-ip";

// What readers do with a post, for Admin → Blog and the blog's "Popular" row:
// views, clicks on its picks, and "was this useful?" answers. Counted in memory
// and saved every few seconds in one go (as the ads are), so a busy post
// never means a database write per visitor. Only totals are kept, never who.

const g = globalThis as unknown as {
  __dealsnapBlogCounts?: Map<string, BlogCounts>;
  __dealsnapBlogFlush?: ReturnType<typeof setInterval>;
  __dealsnapBlogSeen?: Map<string, number>;
};
const pending = (g.__dealsnapBlogCounts ??= new Map());
const seen = (g.__dealsnapBlogSeen ??= new Map());

const day = () => new Date().toISOString().slice(0, 10);

function bump(postId: string, d: string, add: Partial<BlogCounts>) {
  const key = `${postId}|${d}`;
  const c = pending.get(key) ?? { views: 0, clicks: 0, yes: 0, no: 0 };
  c.views += add.views ?? 0;
  c.clicks += add.clicks ?? 0;
  c.yes += add.yes ?? 0;
  c.no += add.no ?? 0;
  pending.set(key, c);
}

export function flushBlogCounts() {
  if (!pending.size) return;
  const rows = [...pending].map(([key, c]) => {
    const [postId, d] = key.split("|");
    return { postId, day: d, ...c };
  });
  pending.clear();
  try {
    addBlogStats(rows);
  } catch {
    // The database was busy: put them back for the next go.
    for (const r of rows) bump(r.postId, r.day, r);
  }
}
g.__dealsnapBlogFlush ??= setInterval(flushBlogCounts, 5_000);
g.__dealsnapBlogFlush.unref?.();

// One person is counted once per post per action every half hour (a refresh
// isn't a new reader), and crawlers and link-preview bots never are. Kept in
// memory, so a restart only means one extra count.
const REPEAT_MS = 30 * 60 * 1000;
const MAX_REMEMBERED = 50_000;

// Who is asking, read while the request is still being handled (the page
// counts its view after it has been sent, when the request can no longer be
// read), so it's read first and handed over.
export type Reader = { agent: string; ip: string };

export async function reader(): Promise<Reader> {
  return { agent: (await headers()).get("user-agent") ?? "", ip: await clientIp() };
}

function firstTime(postId: string, action: string, who: Reader): boolean {
  if (!who.agent || BOT_AGENT.test(who.agent)) return false;
  const key = `${action}:${postId}:${who.ip}`;
  const now = Date.now();
  const last = seen.get(key);
  if (last !== undefined && now - last < REPEAT_MS) return false;
  seen.delete(key);
  seen.set(key, now);
  if (seen.size > MAX_REMEMBERED) {
    for (const [k, at] of seen) {
      if (seen.size <= MAX_REMEMBERED * 0.9 && now - at < REPEAT_MS) break;
      seen.delete(k);
    }
  }
  return true;
}

export function countBlogView(postId: string, who: Reader) {
  if (firstTime(postId, "view", who)) bump(postId, day(), { views: 1 });
}

export function countBlogClick(postId: string, who: Reader) {
  if (firstTime(postId, "click", who)) bump(postId, day(), { clicks: 1 });
}

// "Was this useful?": one answer per person per post per half hour.
export function countBlogVote(postId: string, useful: boolean, who: Reader): boolean {
  if (!firstTime(postId, "vote", who)) return false;
  bump(postId, day(), useful ? { yes: 1 } : { no: 1 });
  return true;
}
