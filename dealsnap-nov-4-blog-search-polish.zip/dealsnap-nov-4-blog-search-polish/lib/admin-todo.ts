import { getCatalogVersion } from "./db";
import { findAdminDeals, getAdminDealFacets, getStoreChecks } from "./admin-deals";

// The two numbers in the admin menu that need every deal looked at: deals to
// review (waiting for approval, or reported and still up) and stores with
// nothing approved yet. Counting them rebuilds the whole admin view of the
// catalog, and the menu is on every admin page, so it was done on every click.
// Now it's done once and kept until a deal changes (the catalog's own "hard"
// counter, bumped by database triggers whatever does the saving) or a minute
// has passed (a deal can end with no change at all).
const MAX_AGE_MS = 60_000;
let memo: { hard: number; at: number; deals: number; stores: number } | undefined;

export function getAdminTodo(): { deals: number; stores: number } {
  const { hard } = getCatalogVersion();
  if (memo && memo.hard === hard && Date.now() - memo.at < MAX_AGE_MS) return memo;
  // Counted by the database (lib/admin-deals.ts): deals waiting, plus ones
  // reported and still up.
  const everything = { q: "", status: "all", category: "all", tag: "all", brand: "all", kind: "all", source: "all", store: "", flag: "all", sort: "newest" } as const;
  memo = {
    hard,
    at: Date.now(),
    deals: getAdminDealFacets().states.pending + findAdminDeals({ ...everything, status: "live", flag: "reported" }, 1, 1).total,
    stores: getStoreChecks().newStores,
  };
  return memo;
}
