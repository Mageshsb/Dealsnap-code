import { getLegal } from "./legal";
import { getSiteName } from "./site-url";
import type { Email } from "./email";
import { CONTACT_TOPICS, contactTopic } from "./contact";

function escapeHtml(text: string): string {
  return text.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}

// The email the team gets for each message. "Reply" goes to the visitor.
export function buildContactEmail(m: { name: string; email: string; topic: string; message: string; username?: string }): Email {
  const topic = contactTopic(m.topic) ?? CONTACT_TOPICS[0];
  const siteName = getSiteName();
  const who = `${m.name} <${m.email}>${m.username ? ` (member: ${m.username})` : ""}`;
  const html = `<!doctype html><html><head><meta charset="utf-8"></head><body style="margin:0;background:#fafafa;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px 12px">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:16px;padding:24px">
      <tr><td style="font-size:13px;color:#a1a1aa;padding-bottom:4px">${escapeHtml(siteName)} contact form · ${escapeHtml(topic.label)}</td></tr>
      <tr><td style="font-size:16px;font-weight:700;color:#18181b;padding-bottom:16px">${escapeHtml(who)}</td></tr>
      <tr><td style="font-size:15px;line-height:1.6;color:#3f3f46;white-space:pre-wrap">${escapeHtml(m.message)}</td></tr>
      <tr><td style="font-size:12px;color:#a1a1aa;padding-top:20px">Reply to this email to answer them directly. It's also in Admin → Messages.</td></tr>
    </table>
  </td></tr></table></body></html>`;
  const text = [`${siteName} contact form · ${topic.label}`, `From: ${who}`, "", m.message, "", "Reply to this email to answer them directly."].join("\n");
  return {
    to: getLegal().email[topic.inbox],
    replyTo: m.email,
    subject: `[${siteName}] ${topic.label}: ${m.name}`,
    html,
    text,
  };
}
