import { getSiteName } from "./site-url";
import type { Email } from "./email";
import { fillEmailWords, getEmailWords, type EmailId, type EmailWords } from "./email-wording";

function escapeHtml(text: string): string {
  return text.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}

// One layout for every account email: the site's name, a sentence, one button,
// and a small print line. The words come from lib/email-wording.ts (standard
// wording, or what Admin → Site content → Email wording changed it to). None
// of these are marketing emails, so none has an unsubscribe link: people
// always get them.
//
// "words" can be passed in to preview wording that isn't saved yet.
export function buildAccountEmail(
  id: EmailId,
  to: string,
  vars: { name: string; email?: string },
  link: string,
  words: EmailWords = getEmailWords(id)
): Email {
  const siteName = getSiteName();
  const fill = (t: string) => fillEmailWords(t, { name: vars.name, site: siteName, email: vars.email ?? "" });
  const subject = fill(words.subject);
  const intro = fill(words.intro);
  const button = fill(words.button);
  const footer = fill(words.footer);

  const html = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body style="margin:0;background:#fafafa;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px 12px">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;background:#ffffff;border-radius:16px;padding:24px">
      <tr><td style="font-size:20px;font-weight:800;color:#18181b;padding-bottom:12px">${escapeHtml(siteName)}</td></tr>
      <tr><td style="font-size:15px;line-height:1.5;color:#3f3f46;padding-bottom:16px">${escapeHtml(intro)}</td></tr>
      <tr><td style="padding-bottom:16px"><a href="${escapeHtml(link)}" style="display:inline-block;background:#f97316;color:#ffffff;text-decoration:none;font-weight:600;font-size:14px;padding:10px 20px;border-radius:999px">${escapeHtml(button)}</a></td></tr>
      <tr><td style="font-size:12px;line-height:1.5;color:#71717a">${escapeHtml(footer)}</td></tr>
    </table>
  </td></tr></table></body></html>`;
  const text = [intro, "", `${button}:`, link, "", footer].join("\n");
  return { to, subject, html, text };
}

// The "Forgot password?" email: one button, valid for an hour.
export function buildPasswordResetEmail(to: string, username: string, link: string): Email {
  return buildAccountEmail("reset", to, { name: username }, link);
}

// "Confirm your email": sent on joining (and after changing the address).
export function buildConfirmEmailEmail(to: string, username: string, link: string): Email {
  return buildAccountEmail("confirm", to, { name: username }, link);
}

// "Your password was changed": the owner's warning if it wasn't them. The
// button leads to "Forgot password?" so they can take the account back.
export function buildPasswordChangedEmail(to: string, username: string, link: string): Email {
  return buildAccountEmail("passwordChanged", to, { name: username }, link);
}

// "The email on your account was changed": sent to the address it USED to be.
export function buildEmailChangedEmail(oldAddress: string, username: string, newAddress: string, link: string): Email {
  return buildAccountEmail("emailChanged", oldAddress, { name: username, email: newAddress }, link);
}
