import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { backupDatabaseTo, getSiteSetting, restoreDatabaseFrom, type RestoreResult } from "./db";
import { logAutomatic } from "./audit";
import { forgetTaxonomy } from "./categories";
import { forgetBrands } from "./brands";
import { forgetExtraWords } from "./categorize-deal";
import { forgetPages } from "./site-pages";
import { forgetLegal } from "./legal";
import { bringPicturesUpToDate } from "./pictures";

// A copy of the site's database made once a day on the server itself
// (checked every hour from instrumentation.ts), the last week of them kept:
// data/backups/dealsnap-2026-10-28.db. They undo a mistake (a bad bulk
// change, a deleted member), but they sit on the same server as the site, so
// losing the server loses them too: the host's own backups, or copies
// downloaded from Admin → Settings → Data & backups, cover that. Stores'
// product lists aren't in them (lib/product-lists.ts): Awin rebuilds those.
// Turned off with Settings → Data & backups ("auto_backups" = "0").

const DIR = path.join(process.env.DEALSNAP_DATA_DIR ?? path.join(process.cwd(), "data"), "backups");
const KEEP = 7;
const NAME = /^dealsnap-(\d{4}-\d{2}-\d{2})\.db$/;

export type ServerBackup = { name: string; day: string; bytes: number };

export function autoBackupsOn(): boolean {
  return getSiteSetting("auto_backups") !== "0";
}

export function listServerBackups(): ServerBackup[] {
  let names: string[];
  try {
    names = fs.readdirSync(DIR);
  } catch {
    return [];
  }
  return names
    .map((name) => ({ name, day: name.match(NAME)?.[1] }))
    .filter((b): b is { name: string; day: string } => !!b.day)
    .map((b) => ({ ...b, bytes: fs.statSync(path.join(DIR, b.name)).size }))
    .sort((a, b) => b.day.localeCompare(a.day));
}

// The full path of one of them, only ever by its exact name.
export function serverBackupPath(name: string): string | undefined {
  return NAME.test(name) && listServerBackups().some((b) => b.name === name) ? path.join(DIR, name) : undefined;
}

// Today's backup, if it isn't made yet; then only the newest few are kept.
export function makeDailyBackup(): void {
  if (!autoBackupsOn()) return;
  const day = new Date().toISOString().slice(0, 10);
  const name = `dealsnap-${day}.db`;
  if (listServerBackups().some((b) => b.name === name)) return;
  fs.mkdirSync(DIR, { recursive: true, mode: 0o700 });
  // Made under a temporary name, so a half-written copy never looks finished.
  const temp = path.join(DIR, `.${name}.part`);
  try {
    fs.rmSync(temp, { force: true });
    backupDatabaseTo(temp);
    fs.chmodSync(temp, 0o600);
    fs.renameSync(temp, path.join(DIR, name));
  } catch {
    fs.rmSync(temp, { force: true });
    logAutomatic("auto.backup", { label: day, url: "/admin/settings?tab=data", detail: "Didn't work: the copy couldn't be made." });
    return;
  }
  for (const old of listServerBackups().slice(KEEP)) fs.rmSync(path.join(DIR, old.name), { force: true });
  const bytes = fs.statSync(path.join(DIR, name)).size;
  logAutomatic("auto.backup", { label: day, url: "/admin/settings?tab=data", detail: `${(bytes / 1048576).toFixed(1)}MB` });
}

// ---------------------------------------------------------------------------
// Restoring the whole site from a backup (Admin → Settings → Data & backups).
// ---------------------------------------------------------------------------
// Where a restore can come from: one of the daily backups above, a safety copy
// made automatically just before an earlier restore (so a restore can itself be
// undone), or one file the owner uploaded (the copy they downloaded earlier).

const SAFETY = /^dealsnap-before-restore-(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-\d{3})\.db$/;
const SAFETY_KEEP = 3;
const UPLOAD_DIR = path.join(DIR, "uploads");
const UPLOAD_FILE = path.join(UPLOAD_DIR, "dealsnap-upload.db");

export type RestorePoint = { id: string; kind: "daily" | "safety" | "upload"; label: string; at: string; bytes: number; file: string };

const fullDate = (d: Date) => d.toLocaleString("en-GB", { weekday: "short", day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: "Europe/London" });

export function listRestorePoints(): RestorePoint[] {
  const points: RestorePoint[] = [];
  const add = (id: string, kind: RestorePoint["kind"], label: string, file: string) => {
    const stat = fs.statSync(file);
    points.push({ id, kind, label, at: stat.mtime.toISOString(), bytes: stat.size, file });
  };
  try {
    if (fs.existsSync(UPLOAD_FILE)) add("upload", "upload", `The file you uploaded (${fullDate(fs.statSync(UPLOAD_FILE).mtime)})`, UPLOAD_FILE);
    for (const b of listServerBackups()) add(`daily-${b.day}`, "daily", `Daily backup of ${new Date(`${b.day}T12:00:00Z`).toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "UTC" })}`, path.join(DIR, b.name));
    for (const name of safetyCopyNames()) {
      const stamp = name.match(SAFETY)![1];
      add(`safety-${stamp}`, "safety", `Safety copy from before a restore (${fullDate(new Date(`${stamp.slice(0, 10)}T${stamp.slice(11, 19).replace(/-/g, ":")}Z`))})`, path.join(DIR, name));
    }
  } catch {
    // A file vanished while listing; show what's there.
  }
  return points;
}

function safetyCopyNames(): string[] {
  try {
    return fs.readdirSync(DIR).filter((n) => SAFETY.test(n)).sort().reverse();
  } catch {
    return [];
  }
}

// By its exact id only, never a path someone typed.
export function restorePointById(id: string): RestorePoint | undefined {
  return listRestorePoints().find((p) => p.id === id);
}

// Where an uploaded file is kept while it waits to be restored (replacing any earlier one).
export function uploadTarget(): { dir: string; file: string } {
  return { dir: UPLOAD_DIR, file: UPLOAD_FILE };
}

export type BackupCheck =
  | { ok: true; members: number; deals: number; comments: number; newestDeal: string | null; includesYou: boolean }
  | { ok: false; reason: string };

// Looks inside a file before anything trusts it: really a SQLite database, not damaged,
// and holding the site's core tables. `userId` is who's about to restore it, to say
// whether they'd still be signed in afterwards.
export function inspectBackup(file: string, userId?: string): BackupCheck {
  try {
    const fd = fs.openSync(file, "r");
    const head = Buffer.alloc(16);
    fs.readSync(fd, head, 0, 16, 0);
    fs.closeSync(fd);
    if (head.toString("latin1") !== "SQLite format 3\u0000") return { ok: false, reason: "That isn't a DealSnap backup file." };
    // `readOnly` is in Node 24 but not yet in the type definitions installed here.
    const src = new DatabaseSync(file, { readOnly: true } as ConstructorParameters<typeof DatabaseSync>[1]);
    try {
      const rows = src.prepare("PRAGMA quick_check").all() as { quick_check: string }[];
      if (rows.length !== 1 || rows[0].quick_check !== "ok") return { ok: false, reason: "The file is damaged, so it can't be restored." };
      const tables = new Set((src.prepare("SELECT name FROM sqlite_master WHERE type = 'table'").all() as { name: string }[]).map((r) => r.name));
      for (const t of ["users", "deals", "comments", "site_settings"]) {
        if (!tables.has(t)) return { ok: false, reason: `That file isn't a DealSnap backup (it has no ${t} table).` };
      }
      const n = (sql: string, ...args: string[]) => (src.prepare(sql).get(...args) as { n: number }).n;
      const newest = src.prepare("SELECT MAX(posted_at) AS d FROM deals").get() as { d: string | null };
      return {
        ok: true,
        members: n("SELECT COUNT(*) AS n FROM users"),
        deals: n("SELECT COUNT(*) AS n FROM deals"),
        comments: n("SELECT COUNT(*) AS n FROM comments"),
        newestDeal: newest.d,
        includesYou: userId ? n("SELECT COUNT(*) AS n FROM users WHERE id = ?", userId) > 0 : true,
      };
    } finally {
      src.close();
    }
  } catch {
    return { ok: false, reason: "That file couldn't be read as a backup." };
  }
}

let restoring = false;

// Saves a safety copy of the site as it is now, restores from the file, then
// makes everything the site remembers read the new data. Only one at a time.
export function restoreFromBackup(point: RestorePoint): RestoreResult & { safetyCopy: string } {
  if (restoring) throw new Error("A restore is already running.");
  restoring = true;
  try {
    fs.mkdirSync(DIR, { recursive: true, mode: 0o700 });
    // Named to the millisecond, and never reusing a name: a safety copy must never be
    // able to overwrite another (or the very file being restored).
    let moment = Date.now();
    const nameAt = (ms: number) => `dealsnap-before-restore-${new Date(ms).toISOString().slice(0, 23).replace(/[:.]/g, "-")}.db`;
    while (fs.existsSync(path.join(DIR, nameAt(moment)))) moment++;
    const safetyCopy = nameAt(moment);
    const temp = path.join(DIR, `.${safetyCopy}.part`);
    try {
      backupDatabaseTo(temp);
      fs.chmodSync(temp, 0o600);
      fs.renameSync(temp, path.join(DIR, safetyCopy));
    } catch (e) {
      fs.rmSync(temp, { force: true });
      throw e;
    }
    let result: RestoreResult;
    try {
      result = restoreDatabaseFrom(point.file);
    } catch (e) {
      // Nothing changed, so the copy protects nothing: don't leave it lying about.
      fs.rmSync(path.join(DIR, safetyCopy), { force: true });
      throw e;
    }
    forgetTaxonomy();
    forgetBrands();
    forgetExtraWords();
    forgetPages();
    forgetLegal();
    // A backup from before pictures were files: move them out again.
    bringPicturesUpToDate();
    // Only the newest few safety copies are kept.
    for (const old of safetyCopyNames().slice(SAFETY_KEEP)) fs.rmSync(path.join(DIR, old), { force: true });
    return { ...result, safetyCopy };
  } finally {
    restoring = false;
  }
}
