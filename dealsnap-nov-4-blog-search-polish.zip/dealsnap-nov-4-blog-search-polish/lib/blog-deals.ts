import type { Deal } from "./types";

// The deals a post's "::deal" cards show. A deal waiting for a helper's check
// or taken down is left out (its card then isn't drawn), so a post can never
// show something the deals pages don't. At most 12 cards are read.
export function getBlogDealCards(slugs: string[], find: (slug: string) => Deal | undefined): Map<string, Deal> {
  const out = new Map<string, Deal>();
  for (const slug of slugs.slice(0, 12)) {
    const deal = find(slug);
    if (deal && deal.status !== "pending" && deal.status !== "removed") out.set(slug, deal);
  }
  return out;
}
