import sharp from "sharp";
import { isAcceptedImage, MAX_PIXELS } from "./deal-images";
import { setUserAvatar } from "./db";

// Profile pictures. Like deal photos (lib/deal-images.ts), an upload is never
// kept as it arrived: it's opened as pixels and saved again as a small square
// WebP, so nothing else hidden in the file comes along, and neither do the
// camera's details, including where a phone photo was taken. The picture is
// kept in the database and served by app/avatar/[id]/[file]/route.ts.

const MAX_AVATAR_BYTES = 2 * 1024 * 1024;
// Avatars show at up to 64px; 256 keeps them sharp on any screen.
const SIDE = 256;

export class AvatarUploadError extends Error {}

export async function saveAvatar(userId: string, file: File) {
  if (file.size === 0) throw new AvatarUploadError("Choose an image to upload.");
  if (file.size > MAX_AVATAR_BYTES) throw new AvatarUploadError("Image must be under 2MB.");

  const bytes = Buffer.from(await file.arrayBuffer());
  if (!isAcceptedImage(bytes)) throw new AvatarUploadError("Use a JPG, PNG, WEBP or GIF image.");

  let data: Buffer;
  try {
    data = await sharp(bytes, { limitInputPixels: MAX_PIXELS, failOn: "error", animated: false })
      // Stand phone photos the right way up, from their own tilt setting.
      .rotate()
      .resize(SIDE, SIDE, { fit: "cover" })
      .webp({ quality: 80 })
      .toBuffer();
  } catch {
    throw new AvatarUploadError("We couldn't open that image. Please try another.");
  }
  setUserAvatar(userId, data);
}
