// The phone apps' native features, as the site's own scripts see them. The
// app's shell (mobile/) puts `window.Capacitor` on every page it shows, with
// its plugins on it, so the site needs no extra code to load: on the website
// these helpers simply find nothing and do nothing.

type Listener = { remove: () => Promise<void> };

type PushToken = { value: string };
type PushAction = { notification: { data?: Record<string, unknown> } };

type CapacitorGlobal = {
  isNativePlatform?: () => boolean;
  getPlatform?: () => string;
  Plugins: {
    Browser?: { open: (o: { url: string; toolbarColor?: string; presentationStyle?: "fullscreen" | "popover" }) => Promise<void> };
    AppLauncher?: { openUrl: (o: { url: string }) => Promise<{ completed: boolean }> };
    App?: { addListener: (event: "appUrlOpen", fn: (e: { url: string }) => void) => Promise<Listener> };
    PushNotifications?: {
      checkPermissions: () => Promise<{ receive: "granted" | "denied" | "prompt" | "prompt-with-rationale" }>;
      requestPermissions: () => Promise<{ receive: "granted" | "denied" | "prompt" | "prompt-with-rationale" }>;
      register: () => Promise<void>;
      unregister: () => Promise<void>;
      addListener(event: "registration", fn: (t: PushToken) => void): Promise<Listener>;
      addListener(event: "registrationError", fn: (e: unknown) => void): Promise<Listener>;
      addListener(event: "pushNotificationActionPerformed", fn: (a: PushAction) => void): Promise<Listener>;
    };
  };
};

export type AppPlatform = "ios" | "android";

export function nativeApp(): { platform: AppPlatform; plugins: CapacitorGlobal["Plugins"] } | undefined {
  if (typeof window === "undefined") return undefined;
  const cap = (window as unknown as { Capacitor?: CapacitorGlobal }).Capacitor;
  if (!cap?.isNativePlatform?.()) return undefined;
  const platform = cap.getPlatform?.();
  if (platform !== "ios" && platform !== "android") return undefined;
  return { platform, plugins: cap.Plugins };
}

// This device's notification address, kept so the app can tell whether
// notifications are on, and forget the address after signing out.
const TOKEN_KEY = "dealsnap:appPushToken";

export function savedAppPushToken(): string | undefined {
  try {
    return localStorage.getItem(TOKEN_KEY) ?? undefined;
  } catch {
    return undefined;
  }
}

export function rememberAppPushToken(token: string | undefined) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    // Storage blocked: it's asked for again next time.
  }
}

// Asks Apple or Google for this device's address and waits for it (the
// "registration" event); undefined if it doesn't come.
export async function registerAppPush(): Promise<string | undefined> {
  const push = nativeApp()?.plugins.PushNotifications;
  if (!push) return undefined;
  return new Promise((resolve) => {
    const listeners: Promise<Listener>[] = [];
    const done = (token: string | undefined) => {
      clearTimeout(timer);
      listeners.forEach((l) => l.then((x) => x.remove()).catch(() => {}));
      resolve(token);
    };
    const timer = setTimeout(() => done(undefined), 15_000);
    listeners.push(push.addListener("registration", (t) => done(t.value)));
    listeners.push(push.addListener("registrationError", () => done(undefined)));
    push.register().catch(() => done(undefined));
  });
}
