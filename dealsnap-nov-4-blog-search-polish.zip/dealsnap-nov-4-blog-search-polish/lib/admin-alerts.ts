import {
  countOpenContactMessages,
  countPendingDeals,
  countReportedComments,
  getAdminEmails,
  getAwinFeeds,
  getDealReportCounts,
  getOpenProfileReports,
  getSiteSetting,
  setSiteSetting,
} from "./db";
import { emailBaseUrl, sendEmail } from "./email";
import { getSiteName } from "./site-url";
import { countOpenErrors } from "./error-log";

// An email to the admins when something urgent is waiting in Admin (deals to
// approve, reports, messages, an Awin problem), so nobody has to keep checking.
// Checked every hour (instrumentation.ts), sent at most every 6 hours, and
// only when what's waiting has changed since the last one. Off until turned
// on in Settings → General → Email. Until email is set up (lib/email.ts) it
// lands in the email-outbox folder like every other email.

const EVERY_MS = 6 * 60 * 60 * 1000;

export function adminAlertsOn(): boolean {
  return getSiteSetting("admin_alert_emails") === "1";
}

function waiting(): { label: string; count: number; href: string }[] {
  const items = [
    { label: "deals waiting for review", count: countPendingDeals(), href: "/admin/deals?status=pending" },
    { label: "deals with reports", count: getDealReportCounts().size, href: "/admin/deals?sort=reports-desc" },
    { label: "reported comments", count: countReportedComments(), href: "/admin/comments?reported=true" },
    { label: "reported profiles", count: getOpenProfileReports().length, href: "/admin/users?status=reported" },
    { label: "messages to answer", count: countOpenContactMessages(), href: "/admin/messages" },
    { label: "things that broke on the site in the last day", count: countOpenErrors(), href: "/admin/errors" },
    { label: "product lists that didn't download", count: getAwinFeeds().filter((f) => f.error).length, href: "/admin/earnings" },
  ];
  return items.filter((i) => i.count > 0);
}

const escape = (text: string) => text.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);

export async function sendAdminAlerts(): Promise<void> {
  if (!adminAlertsOn()) return;
  const items = waiting();
  const sig = items.map((i) => `${i.label}:${i.count}`).join("|");
  const lastAt = getSiteSetting("admin_alert_sent_at");
  if (!items.length || sig === getSiteSetting("admin_alert_sig")) return;
  if (lastAt && Date.now() - new Date(lastAt).getTime() < EVERY_MS) return;
  const to = getAdminEmails();
  if (!to.length) return;

  const base = emailBaseUrl();
  const total = items.reduce((n, i) => n + i.count, 0);
  const subject = `${getSiteName()} Admin: ${total} thing${total === 1 ? "" : "s"} waiting for you`;
  const lines = items.map((i) => `${i.count} ${i.label}: ${base}${i.href}`);
  const html = `<p>Waiting for you in ${escape(getSiteName())} Admin:</p><ul>${items
    .map((i) => `<li><a href="${escape(base + i.href)}">${i.count} ${escape(i.label)}</a></li>`)
    .join("")}</ul><p style="color:#71717a;font-size:13px">Turn these emails off in Admin → Settings → General → Email.</p>`;
  const text = `Waiting for you in ${getSiteName()} Admin:\n\n${lines.join("\n")}\n\nTurn these emails off in Admin → Settings → General → Email.`;
  for (const address of to) await sendEmail({ to: address, subject, html, text });
  setSiteSetting("admin_alert_sent_at", new Date().toISOString());
  setSiteSetting("admin_alert_sig", sig);
}
