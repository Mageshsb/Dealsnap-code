import { hasSinglePrice } from "./deal-kinds";
import { slugify } from "./slug";
import type { Deal } from "./types";

// Custom keyword alerts look at the deal's title, store, category and tag —
// the same things hotukdeals alerts match (its help centre: deal titles,
// category names and merchant names). The description is NOT searched.
// Deliberately a bit more forgiving than theirs, whose exact-phrase matching is
// a common complaint: every word of the keyword must start a word somewhere in
// that text, in any order, ignoring case ("macbook air m5" finds "MacBook Air
// 512GB/16GB M5", "amazon laptop" finds a laptop sold at Amazon, "laptop" finds
// "Laptops", but "air" won't match "chair"). Common alternative spellings are
// treated as the same word (see SPELLINGS / FAMILIES below).

export const MAX_KEYWORD_LENGTH = 60;
export const MAX_KEYWORD_ALERTS = 20;

function plainWords(s: string): string[] {
  return s
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .split(/[^a-z0-9£]+/)
    .filter(Boolean);
}

// Different ways of writing the same thing, folded to one spelling on BOTH the
// keyword and the deal text before comparing — so "playstation 4", "PS 4" and
// "ps4" are the same, but ps4 and ps5 stay different.
const SPELLINGS: [RegExp, string][] = [
  [/\bplay\s?station\s?(\d)\b/g, "ps$1"],
  [/\bps\s(\d)\b/g, "ps$1"],
  [/\bx\s?box\b/g, "xbox"],
  [/\btelevisions?\b/g, "tv"],
  [/\bnotebooks?\b/g, "laptop"],
  [/\b(smart\s?phones?|cell\s?phones?|mobiles?)\b/g, "phone"],
  [/\b(earbuds?|earphones?)\b/g, "headphone"],
  [/\bhoovers?\b/g, "vacuum"],
];

// A broad word also stands for its family: "playstation" finds PS4/PS5/PSVR
// deals. (The reverse isn't true — a "ps4" alert ignores PS5.)
const FAMILIES: Record<string, RegExp> = {
  playstation: /^(playstation|ps\d|psvr)/,
};

function words(s: string): string[] {
  let text = s.toLowerCase();
  for (const [re, to] of SPELLINGS) text = text.replace(re, to);
  return plainWords(text);
}

function wordMatches(need: string, have: string[]): boolean {
  const family = FAMILIES[need];
  return have.some((h) => h.startsWith(need) || (family ? family.test(h) : false));
}

export function normalizeKeyword(raw: string): string {
  return plainWords(raw).join(" ");
}

// Same words in a different order are the same alert.
export function sameKeyword(a: string, b: string): boolean {
  return words(a).sort().join(" ") === words(b).sort().join(" ");
}

export function dealMatchesKeyword(
  keyword: string,
  deal: { title: string; store: string; category: string; tag: string; brand?: string }
): boolean {
  const need = words(keyword);
  if (need.length === 0) return false;
  const have = words(`${deal.title} ${deal.store} ${deal.category} ${deal.tag} ${deal.brand ?? ""}`);
  return need.every((n) => wordMatches(n, have));
}

// A keyword alert's price limit ("iphone 17 256gb, up to £700") only lets
// through a deal with one clear price at or under it: not a sale, voucher or
// "from" price with nothing to compare, and not a plan ("£29.99 a month"
// isn't a £30 phone).
export const MAX_ALERT_PRICE = 100000;

export function dealWithinPrice(maxPrice: number | undefined, deal: Pick<Deal, "price" | "kind" | "priceFrom" | "priceUnit">): boolean {
  return maxPrice === undefined || (hasSinglePrice(deal) && deal.price <= maxPrice + 0.005);
}

// "up to £700", "up to £64.99".
export function alertPriceText(maxPrice: number): string {
  return `up to £${Number.isInteger(maxPrice) ? maxPrice.toLocaleString("en-GB") : maxPrice.toFixed(2)}`;
}

// Whether one alert is for this deal. `tagSlugs` are the deal's tag and its
// parent (a MacBook deal is news to anyone following MacBook or Laptop) and
// `storeKey` its store's stable key. A whole-store voucher or sale has no
// category or tag (lib/deal-kinds.ts), so only store, brand and keyword
// alerts can be for it.
export function alertHits(
  a: { kind: "category" | "tag" | "brand" | "store" | "keyword"; value: string; maxPrice?: number },
  deal: Deal,
  labels: { tagSlugs: Set<string>; storeKey: string }
): boolean {
  switch (a.kind) {
    case "category":
      return !!deal.category && a.value === slugify(deal.category);
    case "tag":
      return labels.tagSlugs.has(a.value);
    case "brand":
      return !!deal.brand && a.value === slugify(deal.brand);
    case "store":
      return a.value === labels.storeKey;
    default:
      return dealMatchesKeyword(a.value, deal) && dealWithinPrice(a.maxPrice, deal);
  }
}
