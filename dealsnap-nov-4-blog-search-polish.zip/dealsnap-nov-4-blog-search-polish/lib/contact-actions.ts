"use server";

import { getCurrentUser } from "./auth";
import { checkFormTicket, newFormCheck, turnstileSiteKey, verifyTurnstile, type FormCheck } from "./captcha";
import { CONTACT_LIMITS, contactTopic } from "./contact";
import { buildContactEmail } from "./contact-email";
import { getRecentFailedLogins, recordFailedLogin, saveContactMessage } from "./db";
import { sendEmail } from "./email";
import { clientIp } from "./client-ip";
import { getLegal } from "./legal";

export type ContactState = {
  status: "idle" | "error" | "sent";
  error?: string;
  field?: "name" | "email" | "topic" | "message" | "check";
  sentTo?: string;
  replyFrom?: string; // the address our answer will come from, so a fake one stands out
  check?: FormCheck; // a fresh bot check after a failed attempt
  values?: { name: string; email: string; topic: string; message: string }; // so nothing typed is lost
};

const HOUR = 60 * 60 * 1000;
const PER_HOUR_FROM_ONE_PLACE = 5;
const PER_HOUR_FROM_ONE_EMAIL = 3;

export async function sendContactMessageAction(_prev: ContactState, formData: FormData): Promise<ContactState> {
  const usingTurnstile = !!turnstileSiteKey();
  // Line breaks and other control characters are flattened, as the name goes
  // into the email's subject line.
  const name = String(formData.get("name") ?? "")
    .replace(/[\u0000-\u001f\u007f]+/g, " ")
    .trim()
    .slice(0, CONTACT_LIMITS.name);
  const email = String(formData.get("email") ?? "").trim().toLowerCase().slice(0, CONTACT_LIMITS.email + 1);
  const topic = String(formData.get("topic") ?? "");
  const message = String(formData.get("message") ?? "").trim().slice(0, CONTACT_LIMITS.message);
  const fail = (error: string, field?: ContactState["field"]): ContactState => ({
    status: "error",
    error,
    field,
    check: newFormCheck(!usingTurnstile),
    values: { name, email, topic, message },
  });

  // The hidden "website" field is invisible to people; only bots fill it in.
  // Pretend it worked so they don't learn anything.
  if (String(formData.get("website") ?? "")) return { status: "sent", sentTo: email };

  if (!name) return fail("Please tell us your name.", "name");
  if (email.length > CONTACT_LIMITS.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("Please enter an email address we can reply to.", "email");
  if (!contactTopic(topic)) return fail("Please choose what it’s about.", "topic");
  if (message.length < CONTACT_LIMITS.minMessage) return fail("Please write a little more so we can help.", "message");

  const ip = await clientIp();
  const ipKey = `contact-ip:${ip}`;
  const emailKey = `contact:${email}`;
  if (getRecentFailedLogins(ipKey, HOUR).count >= PER_HOUR_FROM_ONE_PLACE || getRecentFailedLogins(emailKey, HOUR).count >= PER_HOUR_FROM_ONE_EMAIL) {
    return fail("You’ve sent a few messages already. Please wait an hour and try again, or email us instead.");
  }

  // Bot checks: the timing ticket always, plus Turnstile or the sum.
  const ticket = String(formData.get("ticket") ?? "");
  const answer = usingTurnstile ? undefined : String(formData.get("answer") ?? "");
  const check = checkFormTicket(ticket, answer);
  if (check === "wrong-answer") return fail("That answer to the sum isn’t right. Here’s a new one.", "check");
  if (check === "too-fast") return fail("That was very quick! Please check your message and send it again.", "check");
  if (check !== "ok") return fail("This form timed out. Please send it again.", "check");
  if (usingTurnstile && !(await verifyTurnstile(String(formData.get("cf-turnstile-response") ?? ""), ip))) {
    return fail("We couldn’t confirm you’re not a robot. Please try again.", "check");
  }

  recordFailedLogin(ipKey);
  recordFailedLogin(emailKey);

  const user = await getCurrentUser();
  saveContactMessage({ name, email, topic, message, userId: user?.id ?? null });
  await sendEmail(buildContactEmail({ name, email, topic, message, username: user?.username }));

  return { status: "sent", sentTo: email, replyFrom: getLegal().email[contactTopic(topic)!.inbox] };
}
