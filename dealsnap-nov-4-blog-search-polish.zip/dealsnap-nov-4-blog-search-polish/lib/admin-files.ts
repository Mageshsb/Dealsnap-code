import { getCurrentUser } from "./auth";
import { can } from "./permissions";
import { logAudit } from "./audit";
import { missingTwoStep } from "./staff-two-step";

// Route handlers can't use the redirect-based guards, so they check here.
// (Including the rule, when an admin has turned it on, that staff must use
// two-step login, as for the rest of the admin area.)
export async function adminForDownload() {
  const user = await getCurrentUser();
  if (!user || !can(user.role, "data.export") || user.suspended) return null;
  if (missingTwoStep(user)) return null;
  return user;
}

export function recordDownload(user: Parameters<typeof logAudit>[0], what: string) {
  logAudit(user, "data.export", { label: what });
}

// Spreadsheet apps treat cells starting with = + - @ as formulas, so those are
// prefixed to stop a crafted deal title running as a formula when opened.
function cell(value: unknown): string {
  let text = value === null || value === undefined ? "" : String(value);
  if (/^[=+\-@\t\r]/.test(text)) text = `'${text}`;
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

export function toCsv(headers: string[], rows: unknown[][]): string {
  return [headers, ...rows].map((r) => r.map(cell).join(",")).join("\r\n");
}
