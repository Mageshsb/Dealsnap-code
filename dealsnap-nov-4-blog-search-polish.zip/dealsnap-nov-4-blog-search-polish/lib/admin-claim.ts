// Only the owner can claim the first admin account: the account whose
// (confirmed) email is ADMIN_EMAIL on the server. Otherwise, on a brand-new
// site, whoever got to /admin-claim first would be in charge.
export function mayClaimAdmin(user: { email: string; emailVerified: boolean }): boolean {
  const owner = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  return !!owner && user.emailVerified && user.email.toLowerCase() === owner;
}
