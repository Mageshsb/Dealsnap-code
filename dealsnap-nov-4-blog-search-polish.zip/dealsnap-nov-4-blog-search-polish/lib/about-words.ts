import { getSiteSetting, setSiteSetting } from "./db";
import { getSiteName } from "./site-url";

// The words on the About page. The page's design (pictures, steps, layout)
// stays as it is; the team changes what it says in Admin → Wording → About
// page, and "Use the standard words" puts every line back. {site} in a line
// is the site's name (so a rename doesn't mean editing each line).

export type AboutField = { key: string; label: string; group: string; kind: "line" | "text"; max: number; standard: string };

const f = (key: string, label: string, group: string, kind: "line" | "text", max: number, standard: string): AboutField => ({ key, label, group, kind, max, standard });

export const ABOUT_FIELDS: AboutField[] = [
  f("headline", "Big heading", "At the top", "line", 90, "Bargains are better shared."),
  f("intro", "Opening line", "At the top", "text", 300, "{site} is where UK shoppers swap the best deals they find, and everyone else decides which ones are actually worth it."),

  f("story1", "First paragraph", "How it started", "text", 600, "You know the feeling. You finally buy the air fryer, and two days later it’s £30 cheaper. Or a friend mentions a voucher code a week after you paid full price. Somewhere out there, someone always knew."),
  f("story2", "Second paragraph", "How it started", "text", 600, "The trouble is, a lot of deal pages feel like adverts. Everything is “unmissable”, and you can’t tell whether a deal is any good or just well paid for."),
  f("story3", "Third paragraph", "How it started", "text", 600, "So we built {site}, a place where the people who find the bargains share them, and the people who’d buy them decide which ones are good. No store paying to be at the top. Just a lot of sharp-eyed shoppers looking out for each other."),
  f("quote", "Pull quote (big text beside the story, computers only)", "How it started", "line", 120, "Somewhere out there, someone always knew."),
  f("quoteBy", "Under the quote", "How it started", "line", 80, "Now they tell everyone."),

  f("step1Title", "Step 1: title", "How it works (four steps)", "line", 30, "Spot it"),
  f("step1Body", "Step 1: sentence", "How it works (four steps)", "text", 200, "A price drop, a voucher code, a clearance shelf at the back of the store."),
  f("step2Title", "Step 2: title", "How it works (four steps)", "line", 30, "Snap it"),
  f("step2Body", "Step 2: sentence", "How it works (four steps)", "text", 200, "Post it with the price, the store and a link, so everyone else can grab it too."),
  f("step3Title", "Step 3: title", "How it works (four steps)", "line", 30, "Love it"),
  f("step3Body", "Step 3: sentence", "How it works (four steps)", "text", 200, "Everyone gets a say. Great deals rise to Most loved, and the duds quietly sink."),
  f("step4Title", "Step 4: title", "How it works (four steps)", "line", 30, "Bag it"),
  f("step4Body", "Step 4: sentence", "How it works (four steps)", "text", 200, "Tap Get deal and head straight to the store. When it’s gone, the community marks it ended."),

  f("belief1Title", "First: title", "What we care about (four boxes)", "line", 50, "Shoppers first"),
  f("belief1Body", "First: sentence", "What we care about (four boxes)", "text", 220, "{site} is built around a community of shoppers sharing, checking and loving deals."),
  f("belief2Title", "Second: title", "What we care about (four boxes)", "line", 50, "Nobody can buy the top spot"),
  f("belief2Body", "Second: sentence", "What we care about (four boxes)", "text", 220, "Deals climb with loves from members. Stores can’t pay their way up: any paid spot is extra, and labelled “Ad”."),
  f("belief3Title", "Third: title", "What we care about (four boxes)", "line", 50, "The comments are half the fun"),
  f("belief3Body", "Third: sentence", "What we care about (four boxes)", "text", 220, "That’s where people point out the catch, find it cheaper or tell you whether it’s actually any good."),
  f("belief4Title", "Fourth: title", "What we care about (four boxes)", "line", 50, "Made for UK shoppers"),
  f("belief4Body", "Fourth: sentence", "What we care about (four boxes)", "text", 220, "UK stores, UK prices, in pounds, online and on the high street."),
  f("moneyLine", "Line about earning commission (it links to “How we make money”)", "What we care about (four boxes)", "text", 200, "{site} is free. Some links earn us a small commission, at no cost to you."),

  f("joinTitle", "Heading", "The invitation at the bottom", "line", 60, "Spotted a bargain?"),
  f("joinLine", "Sentence", "The invitation at the bottom", "text", 160, "Share it, and help someone else save."),
];

const SETTING = "about_words";

// The lines that differ from the standard words.
export function savedAboutWords(): Record<string, string> {
  try {
    const parsed = JSON.parse(getSiteSetting(SETTING) ?? "{}") as Record<string, unknown>;
    const out: Record<string, string> = {};
    for (const field of ABOUT_FIELDS) {
      const v = parsed[field.key];
      if (typeof v === "string" && v.trim()) out[field.key] = v.trim().slice(0, field.max);
    }
    return out;
  } catch {
    return {};
  }
}

// Every line as the editor shows it ({site} not yet filled in).
export function aboutWordsRaw(): Record<string, string> {
  const saved = savedAboutWords();
  return Object.fromEntries(ABOUT_FIELDS.map((field) => [field.key, saved[field.key] ?? field.standard]));
}

// Every line as the page shows it, with {site} filled in.
export function getAboutWords(): Record<string, string> {
  const site = getSiteName();
  return Object.fromEntries(Object.entries(aboutWordsRaw()).map(([k, v]) => [k, v.replaceAll("{site}", site)]));
}

// Saves the lines that differ from the standard; one left the same (or empty) follows the standard.
export function saveAboutWords(input: Record<string, string>): void {
  const keep: Record<string, string> = {};
  for (const field of ABOUT_FIELDS) {
    const v = String(input[field.key] ?? "").replace(/\s+/g, " ").trim().slice(0, field.max);
    if (v && v !== field.standard) keep[field.key] = v;
  }
  setSiteSetting(SETTING, Object.keys(keep).length ? JSON.stringify(keep) : "");
}

export function resetAboutWords(): void {
  setSiteSetting(SETTING, "");
}
