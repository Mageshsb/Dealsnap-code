import crypto from "node:crypto";
import http2 from "node:http2";
import { readSecret } from "./secrets";
import type { PushMessage } from "./push";

// Notifications for the phone apps (mobile/). The website's notifications go
// through the browser makers (lib/push.ts); the apps' go through Apple (APNs)
// for iPhones and Google (Firebase) for Android. Their keys are pasted into
// Admin → Settings → Phone apps and kept encrypted (lib/secrets.ts).
//
// An app's device is saved like a browser's, in push_subscriptions, with an
// endpoint of "app:ios:<token>" or "app:android:<token>".

export const APP_BUNDLE_ID = "uk.co.dealsnap.app";

export type AppPlatform = "ios" | "android";

export function appEndpoint(platform: AppPlatform, token: string): string {
  return `app:${platform}:${token}`;
}

// The device's address, as Apple or Google gave it to the app: hex for
// Apple, Firebase's own letters for Google. Anything else is turned down.
export function validAppToken(platform: AppPlatform, token: string): boolean {
  return platform === "ios" ? /^[0-9a-f]{64,200}$/i.test(token) : /^[A-Za-z0-9:_-]{100,400}$/.test(token);
}

type AppleKey = { keyId: string; teamId: string; key: string };
type GoogleAccount = { project_id: string; client_email: string; private_key: string };

export function readAppleKey(): AppleKey | undefined {
  try {
    const k = JSON.parse(readSecret("apple_push_key") ?? "");
    return k?.keyId && k?.teamId && k?.key ? k : undefined;
  } catch {
    return undefined;
  }
}

export function readGoogleAccount(): GoogleAccount | undefined {
  try {
    const a = JSON.parse(readSecret("google_push_account") ?? "");
    return a?.project_id && a?.client_email && a?.private_key ? a : undefined;
  } catch {
    return undefined;
  }
}

// Checks a pasted Apple key (.p8 file) or Google service account (.json file)
// can actually sign, before it's saved.
export function checkAppleKey(key: string): boolean {
  try {
    crypto.sign("sha256", Buffer.from("x"), { key, dsaEncoding: "ieee-p1363" });
    return true;
  } catch {
    return false;
  }
}

export function checkGoogleAccount(json: string): GoogleAccount | undefined {
  try {
    const a = JSON.parse(json);
    if (a?.type !== "service_account" || !a.project_id || !a.client_email || !a.private_key) return undefined;
    crypto.sign("sha256", Buffer.from("x"), a.private_key);
    return a;
  } catch {
    return undefined;
  }
}

function base64url(value: string | Buffer): string {
  return Buffer.from(value).toString("base64url");
}

// Apple's sign-in for sending: a short token signed with the key, good for up
// to an hour (Apple turns down new ones made more often than every 20 minutes).
let appleToken: { value: string; made: number; keyId: string } | undefined;
function appleAuth(k: AppleKey): string {
  if (appleToken && appleToken.keyId === k.keyId && Date.now() - appleToken.made < 40 * 60 * 1000) return appleToken.value;
  const head = base64url(JSON.stringify({ alg: "ES256", kid: k.keyId }));
  const claims = base64url(JSON.stringify({ iss: k.teamId, iat: Math.floor(Date.now() / 1000) }));
  const signature = crypto.sign("sha256", Buffer.from(`${head}.${claims}`), { key: k.key, dsaEncoding: "ieee-p1363" });
  appleToken = { value: `${head}.${claims}.${base64url(signature)}`, made: Date.now(), keyId: k.keyId };
  return appleToken.value;
}

// One connection per Apple server, kept open between notifications as Apple
// asks; made again if it drops.
const appleSessions = new Map<string, http2.ClientHttp2Session>();
function appleSession(host: string): http2.ClientHttp2Session {
  const open = appleSessions.get(host);
  if (open && !open.closed && !open.destroyed) return open;
  const session = http2.connect(`https://${host}`);
  session.on("error", () => appleSessions.delete(host));
  session.on("close", () => appleSessions.delete(host));
  // Let the server shut down without waiting on it.
  session.unref();
  appleSessions.set(host, session);
  return session;
}

function sendToAppleHost(host: string, token: string, k: AppleKey, body: string, tag?: string): Promise<{ status: number; reason?: string }> {
  return new Promise((resolve) => {
    let req: http2.ClientHttp2Stream;
    try {
      req = appleSession(host).request({
        ":method": "POST",
        ":path": `/3/device/${token}`,
        authorization: `bearer ${appleAuth(k)}`,
        "apns-topic": APP_BUNDLE_ID,
        "apns-push-type": "alert",
        "apns-priority": "10",
        "apns-expiration": String(Math.floor(Date.now() / 1000) + 12 * 60 * 60),
        ...(tag ? { "apns-collapse-id": tag.slice(0, 64) } : {}),
        "content-type": "application/json",
      });
    } catch {
      resolve({ status: 0 });
      return;
    }
    let status = 0;
    let data = "";
    req.setTimeout(10_000, () => req.close(http2.constants.NGHTTP2_CANCEL));
    req.on("response", (h) => (status = Number(h[":status"]) || 0));
    req.on("data", (chunk) => (data += chunk));
    req.on("end", () => {
      let reason: string | undefined;
      try {
        reason = data ? JSON.parse(data).reason : undefined;
      } catch {
        // No reason given.
      }
      resolve({ status, reason });
    });
    req.on("error", () => resolve({ status: 0 }));
    req.end(body);
  });
}

// "gone": the app was deleted or notifications turned off, so forget the device.
export async function sendToApple(token: string, message: PushMessage): Promise<"sent" | "gone" | "failed"> {
  const k = readAppleKey();
  if (!k) return "failed";
  const body = JSON.stringify({
    aps: { alert: { title: message.title, body: message.body }, sound: "default", ...(message.tag ? { "thread-id": message.tag } : {}) },
    url: message.url,
  });
  let res = await sendToAppleHost("api.push.apple.com", token, k, body, message.tag);
  // Apps run from Xcode get their address from Apple's test servers.
  if (res.status === 400 && res.reason === "BadDeviceToken") res = await sendToAppleHost("api.sandbox.push.apple.com", token, k, body, message.tag);
  if (res.status === 200) return "sent";
  if (res.status === 410 || (res.status === 400 && res.reason === "BadDeviceToken")) return "gone";
  console.error("[app-push] Apple said no:", res.status, res.reason ?? "");
  return "failed";
}

// Google's sign-in for sending: a token swapped for a signed request, good
// for an hour.
let googleToken: { value: string; expires: number; email: string } | undefined;
async function googleAuth(a: GoogleAccount): Promise<string | undefined> {
  if (googleToken && googleToken.email === a.client_email && Date.now() < googleToken.expires) return googleToken.value;
  const now = Math.floor(Date.now() / 1000);
  const head = base64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claims = base64url(
    JSON.stringify({
      iss: a.client_email,
      scope: "https://www.googleapis.com/auth/firebase.messaging",
      aud: "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3600,
    })
  );
  const signature = crypto.sign("sha256", Buffer.from(`${head}.${claims}`), a.private_key);
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: `${head}.${claims}.${base64url(signature)}` }),
    signal: AbortSignal.timeout(10_000),
  }).catch(() => undefined);
  if (!res?.ok) {
    console.error("[app-push] Google sign-in failed:", res?.status ?? "no answer");
    return undefined;
  }
  const json = (await res.json()) as { access_token?: string; expires_in?: number };
  if (!json.access_token) return undefined;
  googleToken = { value: json.access_token, expires: Date.now() + ((json.expires_in ?? 3600) - 300) * 1000, email: a.client_email };
  return googleToken.value;
}

export async function sendToGoogle(token: string, message: PushMessage): Promise<"sent" | "gone" | "failed"> {
  const a = readGoogleAccount();
  if (!a) return "failed";
  const auth = await googleAuth(a);
  if (!auth) return "failed";
  const res = await fetch(`https://fcm.googleapis.com/v1/projects/${encodeURIComponent(a.project_id)}/messages:send`, {
    method: "POST",
    headers: { authorization: `Bearer ${auth}`, "content-type": "application/json" },
    body: JSON.stringify({
      message: {
        token,
        notification: { title: message.title, body: message.body },
        data: { url: message.url },
        android: {
          ttl: `${12 * 60 * 60}s`,
          notification: { color: "#f97316", ...(message.tag ? { tag: message.tag } : {}) },
        },
      },
    }),
    signal: AbortSignal.timeout(10_000),
  }).catch(() => undefined);
  if (res?.ok) return "sent";
  if (res?.status === 404) return "gone";
  if (res?.status === 400) {
    const text = await res.text().catch(() => "");
    if (text.includes("UNREGISTERED") || text.includes("registration token")) return "gone";
  }
  console.error("[app-push] Google said no:", res?.status ?? "no answer");
  return "failed";
}
