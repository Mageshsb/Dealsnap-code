import type { ListPage } from "./promos";
import type { Deal } from "./types";

// Ads (Admin → Ads). Two ways an ad space gets filled:
//   1. Campaigns: an advertiser pays DealSnap directly (per thousand views, or
//      a flat fee) and the ad is built here from their words and picture, in
//      the site's own look. No cookies and nothing about the visitor is used:
//      an ad is picked for the page it's on (a Currys ad on Currys deals), so
//      no consent is needed.
//   2. An ad network (Google Ad Manager), for the spaces no campaign fills.
//      Off until it's set up in Admin.
// Every ad space has a fixed size, so nothing on the page moves when an ad
// arrives (or doesn't), and every ad says "Ad" and who it's from.
//
// This file holds the shared rules and shapes. It has no database or page
// code, so the admin screens, the pages, the browser and the tests can all use it.

export type AdSlotId =
  | "list"
  | "cards"
  | "sponsored"
  | "sidebar"
  | "rail-left"
  | "rail-right"
  | "deal"
  | "deal-end"
  | "blog"
  | "blog-end"
  | "community-list"
  | "community-thread"
  | "community-end";

// What a campaign is: an ad built from the advertiser's words and picture,
// or a sponsored deal (one of the site's real deals, placed among the others
// and labelled "Ad"). A sponsored deal only goes in the "sponsored" space.
export type CampaignKind = "ad" | "deal";

export type NetworkSize = [number, number] | "fluid";

// The kinds of page ads can be on. Each can be switched off as a whole in
// Admin → Ads → Ad spaces.
export const AD_PAGE_KINDS = [
  { value: "home", label: "Home" },
  { value: "search", label: "Search results" },
  { value: "store", label: "Store pages" },
  { value: "category", label: "Category pages" },
  { value: "tag", label: "Tag pages" },
  { value: "brand", label: "Brand pages" },
  { value: "deal", label: "Deal pages" },
  { value: "blog", label: "Blog articles" },
  { value: "community", label: "Community" },
] as const;
export type AdPageKind = (typeof AD_PAGE_KINDS)[number]["value"];
const LIST_PAGES: AdPageKind[] = ["home", "search", "store", "category", "tag", "brand"];
const RAIL_PAGES: AdPageKind[] = [...LIST_PAGES, "deal", "blog", "community"];

// Which screens a space shows on, where that's a choice: "phones" is
// phones and tablets (narrower than a laptop, where the Filters box sits
// beside the list).
export type AdScreens = "all" | "phones" | "laptops";
export const AD_SCREENS: { value: AdScreens; label: string }[] = [
  { value: "all", label: "All screens" },
  { value: "phones", label: "Phones and tablets only" },
  { value: "laptops", label: "Laptops only" },
];

// How big a space is, where that's a choice (deal pages and blog articles,
// where nothing depends on a space matching a deal's size). Compact is a
// strip about half the height: a campaign's ad as one line with a small
// picture, or a banner from the ad network (728×90 on laptops, 320×100 on
// phones). Standard is a deal-sized ad, or the network's 300×250.
export type AdSize = "compact" | "standard";
export const AD_SIZES: { value: AdSize; label: string; hint: string }[] = [
  { value: "compact", label: "Compact", hint: "A strip about half the height. Less in the way; earns less." },
  { value: "standard", label: "Standard", hint: "Deal-sized, or the ad network's 300×250, the size advertisers buy most." },
];
// The ad network's sizes for a compact space, by screen: [laptops, phones and tablets].
export const COMPACT_SIZES: { laptop: NetworkSize[]; phone: NetworkSize[] } = {
  laptop: [[728, 90], [468, 60]],
  phone: [[320, 100], [320, 50]],
};

export type AdSlotDef = {
  id: AdSlotId;
  name: string;
  where: string;
  screens: string; // which screens, in words (for a space where it's fixed)
  pages: AdPageKind[];
  repeats?: { first: number; every: number; max: number; of: "deals" | "cards" | "paragraphs" | "threads" | "posts" }; // defaults
  screenChoice?: boolean; // staff can pick phones or laptops only
  size?: AdSize; // staff can pick compact or standard; this is the default
  // A space that only shows when the page has enough on it (a long enough
  // description, enough comments): the default and what it counts.
  condition?: { label: string; hint: string; value: number; max: number };
  sizes: NetworkSize[]; // what an ad network may put in it
};

// The ad spaces. Their ids are kept for ever (reports and the ad network's
// codes point at them), so never rename one: retire it and add a new one.
export const AD_SLOTS: AdSlotDef[] = [
  {
    id: "list",
    name: "In the deal lists",
    where: "Between the deals in List view. The same size as a deal.",
    screens: "Phones, tablets and laptops",
    pages: LIST_PAGES,
    repeats: { first: 6, every: 10, max: 0, of: "deals" },
    screenChoice: true,
    sizes: [[300, 250], "fluid"],
  },
  {
    id: "cards",
    name: "In Cards view",
    where: "A card of its own between the deals in Cards view, the same size as a deal's card.",
    screens: "Phones, tablets and laptops",
    pages: LIST_PAGES,
    repeats: { first: 8, every: 12, max: 0, of: "cards" },
    screenChoice: true,
    sizes: [[300, 250]],
  },
  {
    id: "sponsored",
    name: "Sponsored deals",
    where:
      "A real deal a store pays to place among the others, in List and Cards view, labelled “Ad · Sponsored by…”. Never first in a list: the top spot is always earned by members' loves.",
    screens: "Phones, tablets and laptops",
    pages: LIST_PAGES,
    repeats: { first: 3, every: 15, max: 2, of: "deals" },
    sizes: [],
  },
  {
    id: "sidebar",
    name: "Under Filters",
    where: "Beside the deal lists, under the Filters and Explore boxes. Stays in view as you scroll.",
    screens: "Laptops",
    pages: LIST_PAGES,
    sizes: [[250, 250], [200, 200]],
  },
  {
    id: "rail-left",
    name: "Side column 1 (left)",
    where: "The column left of the page on deal lists, deal pages, blog articles and the Community. Stays in view as you scroll. Runs on its own, apart from side column 2.",
    screens: "Wide screens (1,420px and up)",
    pages: RAIL_PAGES,
    sizes: [[160, 600], [120, 600]],
  },
  {
    id: "rail-right",
    name: "Side column 2 (right)",
    where: "The column right of the page, on the same pages. Stays in view as you scroll. Runs on its own, apart from side column 1.",
    screens: "Wide screens (1,420px and up)",
    pages: RAIL_PAGES,
    sizes: [[160, 600], [120, 600]],
  },
  {
    id: "deal",
    name: "Deal page",
    where: "Under “About this deal”.",
    screens: "Phones, tablets and laptops",
    pages: ["deal"],
    screenChoice: true,
    size: "compact",
    condition: {
      label: "Only when the description is at least this many characters",
      hint: "0 shows it on every deal. Around 300 keeps it off short deals, where it would crowd the deal.",
      value: 0,
      max: 2000,
    },
    sizes: [[300, 250], [336, 280], "fluid"],
  },
  {
    id: "deal-end",
    name: "Deal page, after the comments",
    where: "Between the comments and “More deals”.",
    screens: "Phones, tablets and laptops",
    pages: ["deal"],
    screenChoice: true,
    size: "standard",
    condition: {
      label: "Only when the deal has at least this many comments",
      hint: "0 shows it on every deal. With a few comments, people are already scrolling and reading.",
      value: 0,
      max: 100,
    },
    sizes: [[300, 250], [336, 280], "fluid"],
  },
  {
    id: "blog",
    name: "In blog articles",
    where: "Between paragraphs of an article, never straight after a heading or in the last lines.",
    screens: "Phones, tablets and laptops",
    pages: ["blog"],
    repeats: { first: 3, every: 6, max: 3, of: "paragraphs" },
    screenChoice: true,
    size: "standard",
    sizes: [[300, 250], [336, 280], "fluid"],
  },
  {
    id: "blog-end",
    name: "End of blog articles",
    where: "After an article and its deals, before “More from the blog”.",
    screens: "Phones, tablets and laptops",
    pages: ["blog"],
    screenChoice: true,
    size: "standard",
    sizes: [[300, 250], [336, 280], "fluid"],
  },
  {
    id: "community-list",
    name: "In Community lists",
    where: "A slim strip between the conversations on the Community home and in each space. Never first.",
    screens: "Phones, tablets and laptops",
    pages: ["community"],
    repeats: { first: 4, every: 8, max: 0, of: "threads" },
    screenChoice: true,
    size: "compact",
    sizes: [[300, 250], "fluid"],
  },
  {
    id: "community-thread",
    name: "Inside long Community threads",
    where: "Between replies in a long thread, never among the first few and never beside the opening post.",
    screens: "Phones, tablets and laptops",
    pages: ["community"],
    repeats: { first: 6, every: 12, max: 3, of: "posts" },
    screenChoice: true,
    size: "compact",
    sizes: [[300, 250], [336, 280], "fluid"],
  },
  {
    id: "community-end",
    name: "End of Community threads",
    where: "At the bottom of a thread's page, after the last reply and the reply box.",
    screens: "Phones, tablets and laptops",
    pages: ["community"],
    screenChoice: true,
    size: "standard",
    sizes: [[300, 250], [336, 280], "fluid"],
  },
];

// What a repeating space counts, in the singular ("every 8 threads").
export const repeatUnit = (of: "deals" | "cards" | "paragraphs" | "threads" | "posts") =>
  of === "paragraphs" ? "paragraph" : of === "cards" ? "card" : of === "threads" ? "thread" : of === "posts" ? "reply" : "deal";

// …and in the plural ("every 12 replies").
export const repeatUnits = (of: "deals" | "cards" | "paragraphs" | "threads" | "posts") => (of === "posts" ? "replies" : of);

export const AD_SLOT_IDS = AD_SLOTS.map((s) => s.id);
export const isAdSlotId = (v: unknown): v is AdSlotId => typeof v === "string" && (AD_SLOT_IDS as string[]).includes(v);
export const adSlot = (id: AdSlotId) => AD_SLOTS.find((s) => s.id === id)!;

// The two side columns are separate spaces: each is on or off, filled and
// counted by itself, and a campaign can take either or both.
export const RAIL_SLOTS: AdSlotId[] = ["rail-left", "rail-right"];
export const isRailSlot = (id: AdSlotId) => RAIL_SLOTS.includes(id);

// Spaces that no longer exist but whose views are still in the reports: the
// side columns were once one space called "rails".
const RETIRED_SLOT_NAMES: Record<string, string> = { rails: "Side columns (before they were split in two)" };
export const slotName = (id: string) => (isAdSlotId(id) ? adSlot(id).name : RETIRED_SLOT_NAMES[id] ?? id);

// The fewest deals (or paragraphs) between two ads, whatever is set, so a
// list or an article never turns into mostly ads.
export const MIN_EVERY = 3;
export const MIN_EVERY_DEALS = 5;
export const MAX_FIRST = 30;
export const MAX_EVERY = 50;
export const MAX_PER_PAGE = 20;
export const minEvery = (def: AdSlotDef) => (def.repeats?.of === "paragraphs" ? MIN_EVERY : MIN_EVERY_DEALS);
// A sponsored deal never takes the top of a list.
export const minFirst = (def: AdSlotDef) => (def.id === "sponsored" ? 2 : 1);
// Spaces the ad network can fill (a sponsored deal is always a real deal).
export const networkSlots = () => AD_SLOTS.filter((s) => s.sizes.length > 0);

// Where a campaign shows: the same choices as a promo card (lib/promos.ts),
// and a campaign aimed at one store, category, tag or brand also shows on
// its deals' pages (one aimed at "currys" shows on Currys deals).
export const AD_SCOPES = [
  { value: "all", label: "Every page with an ad space" },
  { value: "home", label: "The Home page" },
  { value: "search", label: "Search results" },
  { value: "store", label: "Store pages" },
  { value: "category", label: "Category pages" },
  { value: "tag", label: "Tag pages" },
  { value: "brand", label: "Brand pages" },
  { value: "blog", label: "Blog articles" },
  { value: "community", label: "Community" },
] as const;
export type AdScope = (typeof AD_SCOPES)[number]["value"];
export const AD_TARGETED_SCOPES: AdScope[] = ["store", "category", "tag", "brand", "blog"];

// The page an ad is for: its kind, its address, and its labels (a deal page
// carries all four of its deal's; a blog article its own address name).
export type AdLabels = { store?: string; category?: string; tag?: string; brand?: string; blog?: string };
export type AdPage = { kind: AdPageKind; path: string; labels: AdLabels };

const LABEL_PATHS: Record<Exclude<keyof AdLabels, "blog">, string> = { store: "stores", category: "categories", tag: "tags", brand: "brands" };

export const listAdPage = (page: ListPage): AdPage => {
  const labelled = page.slug && page.kind !== "home" && page.kind !== "search";
  return {
    kind: page.kind,
    path: labelled ? `/${LABEL_PATHS[page.kind as keyof typeof LABEL_PATHS]}/${page.slug}` : "/",
    labels: labelled ? { [page.kind]: page.slug } : {},
  };
};

// Whether a page is on the "no ads here" list: its own address, or (for a
// deal page) the page of its store, category, tag or brand.
export function pageBlocked(page: AdPage, blockedPaths: string[]): boolean {
  if (!blockedPaths.length) return false;
  if (blockedPaths.includes(page.path)) return true;
  return (Object.keys(LABEL_PATHS) as (keyof typeof LABEL_PATHS)[]).some(
    (k) => !!page.labels[k] && blockedPaths.includes(`/${LABEL_PATHS[k]}/${page.labels[k]}`),
  );
}

// An address for the "no ads here" list: a page on the site, as it shows
// in the address bar (no query, no #).
export const isPagePath = (v: string) => /^\/[a-z0-9][a-z0-9/_-]{0,199}$/.test(v) && !v.includes("//");

// How well a campaign fits a page: 0 not at all, 1 a general match, 2 a match
// for this very store, category, tag, brand or article (which beats a general one).
export function adFit(c: { scope: string; target: string }, page: AdPage): 0 | 1 | 2 {
  if (c.scope === "all") return 1;
  if (c.scope === "home" || c.scope === "search") return page.kind === c.scope ? 1 : 0;
  const label = page.labels[c.scope as keyof AdLabels];
  if (!c.target) return page.kind === c.scope ? 1 : 0;
  return label === c.target ? 2 : 0;
}

export type Pacing = "even" | "fast";
// How a campaign shares a space: a sponsorship takes it outright; standard
// campaigns take turns; a house ad (DealSnap's own promo, free) only fills a
// space nothing paid wants.
export type Priority = "sponsorship" | "standard" | "house";
export const PRIORITIES: { value: Priority; label: string; hint: string }[] = [
  { value: "standard", label: "Take turns with other campaigns", hint: "Ones aimed at the exact page come first; otherwise turns go by weight." },
  { value: "sponsorship", label: "Sponsorship: has its spaces to itself", hint: "For a takeover, like a store sponsoring its own page for a week." },
  { value: "house", label: "House ad: fills spaces nothing paid wants", hint: "DealSnap's own promo (Post a deal, the Community, the app). Free; it steps aside whenever a paying campaign or the ad network can fill the space." },
];
export type Pricing = "cpm" | "flat" | "none";
export type CampaignStatus = "draft" | "live" | "paused" | "archived";

// UK days (YYYY-MM-DD) from a to b, counting both.
export function daysInclusive(a: string, b: string): number {
  return Math.round((Date.parse(`${b}T12:00:00Z`) - Date.parse(`${a}T12:00:00Z`)) / 86_400_000) + 1;
}

export type Delivered = { total: number; today: number };

// How far through the UK day it is, 0 to 1 (so a day's views build up
// through the day instead of all going in the morning).
const UK_CLOCK = new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/London", hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
export function ukDayFraction(now = Date.now()): number {
  const parts = UK_CLOCK.formatToParts(new Date(now));
  const at = (t: string) => Number(parts.find((p) => p.type === t)?.value ?? 0);
  return Math.min(1, (at("hour") * 60 + at("minute")) / 1440);
}

// Whether a campaign with a goal may show more today. "Fast" shows it
// whenever it fits until the goal is reached. "Even" spreads what's left over
// the days left, so a month's campaign doesn't run out in a week (a little over
// is allowed each day, to make up for quiet hours), and, given how far through
// the day it is, builds each day's share up through the day, so it isn't all
// gone by breakfast and nobody sees it in the evening. The last day isn't held
// back at all: whatever is left has to go.
export function paceAllows(
  c: { goal?: number; pacing: Pacing; endsOn?: string },
  d: Delivered,
  today: string,
  dayFraction?: number,
): boolean {
  if (!c.goal) return true;
  if (d.total >= c.goal) return false;
  if (c.pacing === "fast" || !c.endsOn || c.endsOn < today) return true;
  const daysLeft = Math.max(1, daysInclusive(today, c.endsOn));
  const leftAtStartOfDay = c.goal - (d.total - d.today);
  const full = Math.ceil((leftAtStartOfDay / daysLeft) * 1.15);
  const cap = dayFraction === undefined || daysLeft <= 1 ? full : Math.ceil(full * Math.min(1, 0.1 + dayFraction * 1.2));
  return d.today < cap;
}

// How much more often a campaign that has fallen behind its schedule comes up:
// 1 (no change) up to 4 times, growing with the days behind. Without it a
// low-weight campaign sharing a busy space with heavier ones never catches up,
// and the advertiser is short-changed. Only "even" campaigns with a goal and
// both dates have a schedule to be behind.
export function deliveryBoost(
  c: { goal?: number; pacing: Pacing; startsOn?: string; endsOn?: string },
  d: Delivered,
  today: string,
): number {
  if (!c.goal || c.pacing === "fast" || !c.startsOn || !c.endsOn || today <= c.startsOn || today > c.endsOn) return 1;
  const total = daysInclusive(c.startsOn, c.endsOn);
  const gone = daysInclusive(c.startsOn, today) - 1; // whole days before today
  const perDay = c.goal / total;
  const behindDays = (perDay * gone - (d.total - d.today)) / perDay;
  return behindDays > 0.5 ? 1 + Math.min(3, behindDays) : 1;
}

// A campaign that could fill a space on a page, as the picker sees it.
export type Candidate = { id: string; fit: number; priority: Priority; weight: number; boost: number };

// Up to `count` campaigns for one space, in the order they take turns.
//   1. A paying campaign beats a house ad: house ads are picked only when no
//      paying campaign wants the space.
//   2. A sponsorship takes the space outright (several share it by weight).
//   3. Otherwise the campaigns aimed at this very page beat general ones.
//   4. The rest are drawn in a weighted random order (a weight-10 campaign comes
//      up about twice as often as a weight-5 one, more if it's behind schedule).
//   5. Campaigns already shown elsewhere on this page (`avoid`) go to the back,
//      so one page shows different advertisers where there's a choice, instead
//      of the same ad in three places. It only reorders: nothing is left out.
export function pickCampaigns<T extends Candidate>(
  candidates: T[],
  count: number,
  { avoid, random = Math.random }: { avoid?: ReadonlySet<string>; random?: () => number } = {},
): T[] {
  if (!candidates.length || count < 1) return [];
  const paid = candidates.filter((x) => x.priority !== "house");
  const pool = paid.length ? paid : candidates;
  const sponsors = pool.filter((x) => x.priority === "sponsorship");
  const tier = sponsors.length ? sponsors : pool;
  const best = Math.max(...tier.map((x) => x.fit));
  const drawn = tier
    .filter((x) => x.fit === best)
    .map((x) => ({ x, key: random() ** (1 / Math.max(0.1, x.weight * x.boost)) }))
    .sort((a, b) => b.key - a.key)
    .map((d) => d.x);
  const fresh = avoid?.size ? drawn.filter((x) => !avoid.has(x.id)) : drawn;
  const seen = avoid?.size ? drawn.filter((x) => avoid.has(x.id)) : [];
  return [...fresh, ...seen].slice(0, count);
}

export type CampaignState = "draft" | "scheduled" | "live" | "paused" | "full" | "finished" | "archived";

export function campaignState(
  c: { status: CampaignStatus; startsOn?: string; endsOn?: string; goal?: number },
  d: Delivered,
  today: string,
): CampaignState {
  if (c.status === "archived") return "archived";
  if (c.status === "draft") return "draft";
  if (c.endsOn && today > c.endsOn) return "finished";
  if (c.goal && d.total >= c.goal) return "full";
  if (c.status === "paused") return "paused";
  if (c.startsOn && today < c.startsOn) return "scheduled";
  return "live";
}

// What an advertiser is charged so far, in pence.
export function earned(c: { pricing: Pricing; pricePence: number }, views: number): number {
  if (c.pricing === "cpm") return Math.round((views / 1000) * c.pricePence);
  if (c.pricing === "flat") return c.pricePence;
  return 0;
}

export const pounds = (pence: number) =>
  `£${(pence / 100).toLocaleString("en-GB", { minimumFractionDigits: pence % 100 ? 2 : 0, maximumFractionDigits: 2 })}`;

export const clickRate = (views: number, clicks: number) => (views ? `${((clicks / views) * 100).toFixed(2)}%` : "–");

// ---------------------------------------------------------------------------
// What needs the team's eye, and how campaigns share
// ---------------------------------------------------------------------------
export type Attention = { level: "warn" | "info"; text: string; short: string };

// Things worth a look on a campaign that is running or about to: behind its
// schedule (with the views a day it now needs), ending soon, nearly full, or
// live without anything to show. Shown on the Overview and beside the campaign.
export function campaignAttention(
  c: { status: CampaignStatus; kind?: CampaignKind; goal?: number; pacing: Pacing; startsOn?: string; endsOn?: string; priority?: Priority; slots?: string[] },
  d: Delivered,
  today: string,
): Attention[] {
  const state = campaignState(c, d, today);
  const out: Attention[] = [];
  if (state === "live") {
    if (c.goal && c.endsOn) {
      const left = c.goal - d.total;
      const daysLeft = Math.max(1, daysInclusive(today, c.endsOn));
      if (deliveryBoost(c, d, today) > 1.5) {
        out.push({
          level: "warn",
          short: "Behind schedule",
          text: `Behind schedule: it needs about ${Math.ceil(left / daysLeft).toLocaleString("en-GB")} views a day to finish on time. It is being given more turns; if it stays behind, widen its spaces or pages.`,
        });
      }
    }
    if (c.endsOn) {
      // Days until its last day (today is 0).
      const until = daysInclusive(today, c.endsOn) - 1;
      if (until <= 2) {
        const text = until <= 0 ? "Ends today" : until === 1 ? "Ends tomorrow" : `Ends in ${until} days`;
        out.push({ level: "info", text: `${text}.`, short: text });
      }
    }
    if (c.goal && d.total >= c.goal * 0.9) out.push({ level: "info", text: "Nearly at its views goal.", short: "Nearly at its goal" });
  }
  if (state === "scheduled" && c.startsOn) {
    const daysTo = daysInclusive(today, c.startsOn) - 1;
    if (daysTo <= 2) {
      const text = daysTo <= 0 ? "Starts today" : `Starts in ${daysTo} day${daysTo === 1 ? "" : "s"}`;
      out.push({ level: "info", text: `${text}.`, short: text });
    }
  }
  return out;
}

// A campaign as the "who shares with it" check sees it.
export type CampaignLike = {
  id: string;
  name: string;
  advertiserName?: string;
  kind: CampaignKind;
  status: CampaignStatus;
  slots: string[];
  scope: string;
  target: string;
  startsOn?: string;
  endsOn?: string;
  priority: Priority;
  weight: number;
};

const DEAL_PAGE_SCOPES = ["store", "category", "tag", "brand"];

// Whether two campaigns could ever be picked for the same page. "Every page"
// meets everything; the same kind of page meets itself unless they're aimed at
// two different things; and two campaigns each aimed at one store, category,
// tag or brand meet on a deal page that has both.
export function scopesOverlap(a: { scope: string; target: string }, b: { scope: string; target: string }): boolean {
  if (a.scope === "all" || b.scope === "all") return true;
  if (a.scope === b.scope) return !a.target || !b.target || a.target === b.target;
  return !!a.target && !!b.target && DEAL_PAGE_SCOPES.includes(a.scope) && DEAL_PAGE_SCOPES.includes(b.scope);
}

export function datesOverlap(a: { startsOn?: string; endsOn?: string }, b: { startsOn?: string; endsOn?: string }): boolean {
  return (a.startsOn ?? "0000-00-00") <= (b.endsOn ?? "9999-99-99") && (b.startsOn ?? "0000-00-00") <= (a.endsOn ?? "9999-99-99");
}

// What another campaign does to this one where they meet:
//   outranks   it takes the space, so this one doesn't show there
//   outranked  this one takes the space and the other doesn't show
//   shares     they take turns (by weight; the more specific aim wins on its own page)
//   backfill   it's a house ad: it only fills what this one leaves
export type Rival = { campaign: CampaignLike; slots: string[]; effect: "outranks" | "outranked" | "shares" | "backfill" };

export function rivalsOf(c: CampaignLike, others: CampaignLike[], today: string): Rival[] {
  const out: Rival[] = [];
  for (const o of others) {
    if (o.id === c.id || o.kind !== c.kind || o.status === "archived" || (o.endsOn && o.endsOn < today)) continue;
    if (!datesOverlap(c, o) || !scopesOverlap(c, o)) continue;
    const slots = c.slots.filter((s) => o.slots.includes(s));
    if (!slots.length) continue;
    const rank = (x: CampaignLike) => (x.priority === "sponsorship" ? 2 : x.priority === "standard" ? 1 : 0);
    const effect = rank(o) > rank(c) ? "outranks" : rank(o) < rank(c) ? (o.priority === "house" ? "backfill" : "outranked") : "shares";
    out.push({ campaign: o, slots, effect });
  }
  return out;
}

// Roughly how many of the turns this campaign gets in each space it shares
// with others of the same rank, from 0 to 1 (by weight; it leaves out delivery
// catch-up and the more specific aim winning, which depend on the page). Rivals
// in another space don't count: only those in the same one take its turns. A
// space where a sponsorship has the turns shows 0, and one with nobody to share
// with isn't listed. Paused and draft campaigns aren't counted.
export function turnShares(c: CampaignLike, rivals: Rival[]): { slot: string; share: number }[] {
  return c.slots.flatMap((slot) => {
    // Only live campaigns take turns now; a paused or draft one is listed but not counted.
    const here = rivals.filter((r) => r.slots.includes(slot) && r.campaign.status === "live");
    if (here.some((r) => r.effect === "outranks")) return [{ slot, share: 0 }];
    const sharing = here.filter((r) => r.effect === "shares");
    if (!sharing.length) return [];
    return [{ slot, share: c.weight / (c.weight + sharing.reduce((n, r) => n + r.campaign.weight, 0)) }];
  });
}

// What the site needs to draw one ad (nothing private; safe to send to the browser).
export type AdCreative = {
  id: string; // the campaign
  advertiser: string; // shown beside "Ad"
  headline: string;
  body?: string;
  ctaLabel: string;
  imageUrl?: string;
  logoUrl?: string;
  internal: boolean; // links to a page on DealSnap (opens in the same tab)
};

// What one ad space on a page gets: campaigns to take turns (a list's ads go
// round them), else the ad network's code, else (staff previewing) an outline.
// A sponsored deal as the page draws it: the deal (without Featured or Deal of
// the Day looks, which are the team's picks, never paid for) and who's paying.
export type SponsoredDeal = { id: string; advertiser: string; deal: Deal };

export type SlotFill = {
  creatives: AdCreative[];
  deals?: SponsoredDeal[]; // the "sponsored" space
  network?: { unit: string; sizes: NetworkSize[]; compact?: boolean };
  // House ads shown only if the ad network has nothing for the space (so an
  // unsold space still says something useful instead of folding away).
  fallback?: AdCreative[];
  outline?: boolean;
  first: number;
  every: number;
  max: number; // most in one list or article (0 is no limit)
  screens: AdScreens;
  size: AdSize;
};

export type PageAds = {
  slots: Partial<Record<AdSlotId, SlotFill>>;
  personalised: boolean; // the ad network may use cookies (only with a certified consent tool)
};

// Pictures are served from /creative/<campaign>/<slot>-<version>.webp.
export const creativeImageUrl = (id: string, slot: "image" | "logo", version: string) => `/creative/${id}/${slot}-${version}.webp`;

// Where a tap on an ad goes first (counted, then sent on to the advertiser).
export const adClickUrl = (id: string, slot: AdSlotId) => `/visit/${id}?s=${slot}`;

export const AD_TEXT = { advertiser: 30, headline: 70, body: 120, cta: 20, name: 80 } as const;

// Google Ad Manager's network code and ad unit codes ("/12345678/dealsnap_list").
export const isNetworkCode = (v: string) => /^\d{3,12}$/.test(v);
export const isAdUnitPath = (v: string) => /^\/\d{3,12}(\/[A-Za-z0-9_.\-]{1,100}){1,5}$/.test(v) && v.length <= 300;

// ads.txt: who may sell DealSnap's ad space (https://iabtechlab.com/ads-txt).
// Each line is "domain, account id, DIRECT or RESELLER[, certification id]",
// a variable like "contact=…", or a # comment. Anything else is refused, so
// the file can't be used to serve something else.
const ADS_TXT_RECORD = /^[a-z0-9.-]+\.[a-z]{2,}\s*,\s*[A-Za-z0-9._-]{1,100}\s*,\s*(DIRECT|RESELLER)(\s*,\s*[A-Za-z0-9]{1,40})?$/i;
const ADS_TXT_VARIABLE = /^(contact|subdomain|inventorypartnerdomain|ownerdomain|managerdomain)\s*=\s*[^\s<>"']{1,200}$/i;
export const ADS_TXT_MAX_LINES = 500;

export function checkAdsTxt(text: string): { clean: string; errors: string[] } {
  const errors: string[] = [];
  const lines = text.replace(/\r\n?/g, "\n").split("\n").map((l) => l.trim());
  if (lines.length > ADS_TXT_MAX_LINES) errors.push(`Keep it to ${ADS_TXT_MAX_LINES} lines.`);
  lines.slice(0, ADS_TXT_MAX_LINES).forEach((line, i) => {
    const record = line.split("#")[0].trim();
    if (!line || line.startsWith("#")) return;
    if (!ADS_TXT_RECORD.test(record) && !ADS_TXT_VARIABLE.test(record)) errors.push(`Line ${i + 1} doesn't look right: “${line.slice(0, 60)}”`);
  });
  return { clean: lines.join("\n").trim(), errors: errors.slice(0, 5) };
}
