import type { IconName } from "@/components/Icon";
import { recordAudit, getAuditSince, type AuditEntry, type UserRecord } from "./db";
import { getSiteSettings } from "./site-settings";

// Every thing a member of staff can do that gets written to the activity log.
// `removal` marks the actions that take something away from the community, which
// is what the unusual-activity check counts.
export const AUDIT_ACTIONS = {
  "deal.post": { icon: "send" as IconName, text: "posted (live straight away)", group: "deals", removal: false },
  "deal.approve": { icon: "circle-check" as IconName, text: "approved", group: "deals", removal: false },
  "deal.reject": { icon: "ban" as IconName, text: "rejected", group: "deals", removal: true },
  "deal.takedown": { icon: "arrow-down" as IconName, text: "took down", group: "deals", removal: true },
  "deal.restore": { icon: "undo" as IconName, text: "restored", group: "deals", removal: false },
  "deal.edit": { icon: "pencil" as IconName, text: "edited", group: "deals", removal: false },
  "deal.feature": { icon: "star" as IconName, text: "featured", group: "deals", removal: false },
  "deal.unfeature": { icon: "star-off" as IconName, text: "unfeatured", group: "deals", removal: false },
  "deal.hero": { icon: "crown" as IconName, text: "set as Deal of the Day:", group: "deals", removal: false },
  "deal.unhero": { icon: "crown" as IconName, text: "removed from Deal of the Day:", group: "deals", removal: false },
  "deal.ended": { icon: "hourglass" as IconName, text: "marked as ended", group: "deals", removal: true },
  "deal.unended": { icon: "rewind" as IconName, text: "cleared the ended reports on", group: "deals", removal: false },
  "deal.delete": { icon: "trash" as IconName, text: "permanently deleted", group: "deals", removal: true },
  "deal.labels": { icon: "check" as IconName, text: "checked the type and brand of", group: "deals", removal: false },
  "comment.delete": { icon: "trash" as IconName, text: "deleted a comment by", group: "comments", removal: true },
  "comment.dismiss": { icon: "flag-off" as IconName, text: "dismissed reports on a comment by", group: "comments", removal: false },
  "forum.thread-remove": { icon: "trash" as IconName, text: "removed a Community thread:", group: "community", removal: true },
  "forum.thread-delete": { icon: "trash" as IconName, text: "permanently deleted a Community thread:", group: "community", removal: true },
  "forum.thread-restore": { icon: "undo" as IconName, text: "restored a Community thread:", group: "community", removal: false },
  "forum.thread-approve": { icon: "circle-check" as IconName, text: "approved a first thread:", group: "community", removal: false },
  "forum.post-remove": { icon: "trash" as IconName, text: "removed a Community post by", group: "community", removal: true },
  "forum.post-hide": { icon: "eye-off" as IconName, text: "hid a Community post by", group: "community", removal: false },
  "forum.post-restore": { icon: "undo" as IconName, text: "restored a Community post by", group: "community", removal: false },
  "forum.post-edit": { icon: "pencil" as IconName, text: "edited a Community post by", group: "community", removal: false },
  "forum.dismiss": { icon: "flag-off" as IconName, text: "dismissed reports on a Community post by", group: "community", removal: false },
  "forum.tidy": { icon: "pen-line" as IconName, text: "tidied Community thread:", group: "community", removal: false },
  "forum.pin": { icon: "pin" as IconName, text: "pinned or unpinned Community thread:", group: "community", removal: false },
  "forum.lock": { icon: "lock" as IconName, text: "locked or unlocked Community thread:", group: "community", removal: false },
  "forum.mute": { icon: "ban" as IconName, text: "muted from the Community:", group: "community", removal: true },
  "forum.unmute": { icon: "circle-check" as IconName, text: "let back into the Community:", group: "community", removal: false },
  "forum.space": { icon: "folder" as IconName, text: "changed Community space:", group: "site", removal: false },
  "forum.settings": { icon: "settings" as IconName, text: "changed Community limits", group: "site", removal: false },
  "user.suspend": { icon: "ban" as IconName, text: "suspended", group: "users", removal: true },
  "user.unsuspend": { icon: "circle-check" as IconName, text: "unsuspended", group: "users", removal: false },
  "user.promote": { icon: "arrow-up" as IconName, text: "promoted", group: "users", removal: false },
  "user.demote": { icon: "arrow-down" as IconName, text: "removed staff access from", group: "users", removal: false },
  "escalation.create": { icon: "hand" as IconName, text: "escalated to admins:", group: "site", removal: false },
  "escalation.resolve": { icon: "circle-check" as IconName, text: "resolved an escalation about", group: "site", removal: false },
  "profile.clean": { icon: "eraser" as IconName, text: "cleaned up the profile of", group: "users", removal: true },
  "profile.dismiss": { icon: "flag-off" as IconName, text: "dismissed profile reports on", group: "users", removal: false },
  "user.note": { icon: "note" as IconName, text: "added a staff note on", group: "users", removal: false },
  "user.signout": { icon: "lock" as IconName, text: "signed out all sessions of", group: "users", removal: false },
  "user.2fa-reset": { icon: "key" as IconName, text: "reset two-step login for", group: "users", removal: false },
  "data.export": { icon: "download" as IconName, text: "downloaded", group: "site", removal: false },
  "blog.save": { icon: "pen-line" as IconName, text: "saved blog post", group: "site", removal: false },
  "blog.delete": { icon: "trash" as IconName, text: "deleted blog post", group: "site", removal: true },
  "event.change": { icon: "calendar" as IconName, text: "changed event:", group: "site", removal: false },
  "event.delete": { icon: "trash" as IconName, text: "deleted event:", group: "site", removal: true },
  "banner.change": { icon: "megaphone" as IconName, text: "changed banner:", group: "site", removal: false },
  "banner.delete": { icon: "trash" as IconName, text: "deleted banner:", group: "site", removal: true },
  "promo.change": { icon: "sparkles" as IconName, text: "changed promo:", group: "site", removal: false },
  "promo.delete": { icon: "trash" as IconName, text: "deleted promo:", group: "site", removal: true },
  "ad.change": { icon: "target" as IconName, text: "changed ad campaign:", group: "site", removal: false },
  "ad.delete": { icon: "trash" as IconName, text: "deleted ad campaign:", group: "site", removal: true },
  "ad.settings": { icon: "target" as IconName, text: "changed ad settings:", group: "site", removal: false },
  "advertiser.change": { icon: "handshake" as IconName, text: "changed advertiser:", group: "site", removal: false },
  "kit.change": { icon: "file-text" as IconName, text: "changed media kit:", group: "site", removal: false },
  "settings.change": { icon: "settings" as IconName, text: "changed settings:", group: "site", removal: false },
  "store.change": { icon: "store" as IconName, text: "changed store:", group: "site", removal: false },
  "labels.change": { icon: "tag" as IconName, text: "changed tags and brands:", group: "site", removal: false },
  "page.change": { icon: "file-text" as IconName, text: "changed page:", group: "site", removal: false },
  "page.delete": { icon: "trash" as IconName, text: "deleted page:", group: "site", removal: true },
  "company.change": { icon: "building" as IconName, text: "changed the company details", group: "site", removal: false },
  "links.change": { icon: "link" as IconName, text: "changed the footer's social and app links", group: "site", removal: false },
  "backup.upload": { icon: "upload" as IconName, text: "uploaded a backup file:", group: "site", removal: false },
  "backup.restore": { icon: "history" as IconName, text: "restored the whole site from", group: "site", removal: false },
  // Done by the site itself (SYSTEM_ACTOR), on its hourly and daily checks.
  "auto.sync": { icon: "store" as IconName, text: "synced stores from", group: "site", removal: false },
  "auto.list": { icon: "download" as IconName, text: "downloaded the product list for", group: "site", removal: false },
  "auto.backup": { icon: "save" as IconName, text: "saved the daily backup", group: "site", removal: false },
} as const;

export type AuditAction = keyof typeof AUDIT_ACTIONS;

export const AUDIT_GROUPS = {
  deals: "Deals",
  comments: "Comments",
  community: "Community",
  users: "Members & roles",
  site: "Stores & settings",
} as const;
export type AuditGroup = keyof typeof AUDIT_GROUPS;

export function actionsInGroup(group: AuditGroup): AuditAction[] {
  return (Object.keys(AUDIT_ACTIONS) as AuditAction[]).filter((a) => AUDIT_ACTIONS[a].group === group);
}

// A moderator is flagged when, within one hour, they remove this many things or
// do this many things in total — far more than normal day-to-day moderating.
// Both numbers can be changed in Team → Rules.
export function flagThresholds() {
  const s = getSiteSettings();
  return { removals: s.flagRemovalsPerHour, actions: s.flagActionsPerHour };
}

export function logAudit(
  actor: Pick<UserRecord, "id" | "username" | "role">,
  action: AuditAction,
  target: { label?: string; url?: string; detail?: string; targetId?: string } = {}
) {
  recordAudit({
    actorId: actor.id,
    actorUsername: actor.username,
    actorRole: actor.role,
    action,
    targetLabel: target.label,
    targetUrl: target.url,
    targetId: target.targetId,
    detail: target.detail,
  });
}

// Who the site's own jobs are recorded as: the nightly Awin sync, product
// list downloads, the daily backup.
export const SYSTEM_ACTOR = { id: "system", username: "DealSnap (automatic)", role: "system" } as const;

export function logAutomatic(
  action: Extract<AuditAction, `auto.${string}`>,
  target: { label?: string; url?: string; detail?: string } = {}
) {
  recordAudit({
    actorId: SYSTEM_ACTOR.id,
    actorUsername: SYSTEM_ACTOR.username,
    actorRole: SYSTEM_ACTOR.role,
    action,
    targetLabel: target.label,
    targetUrl: target.url,
    detail: target.detail?.slice(0, 300),
  });
}

export type StaffActivity = {
  actorId: string;
  hour: number;
  hourRemovals: number;
  day: number;
  week: number;
  flagged: boolean;
};

// Counts per person over the last hour / day / week, plus whether they look unusual.
export function summariseActivity(): Map<string, StaffActivity> {
  const now = Date.now();
  const entries: AuditEntry[] = getAuditSince(new Date(now - 7 * 24 * 60 * 60 * 1000).toISOString());
  const out = new Map<string, StaffActivity>();
  for (const e of entries) {
    // (The site's own jobs aren't a person to keep an eye on.)
    if (e.actorId === SYSTEM_ACTOR.id) continue;
    const row = out.get(e.actorId) ?? { actorId: e.actorId, hour: 0, hourRemovals: 0, day: 0, week: 0, flagged: false };
    const age = now - new Date(e.at).getTime();
    row.week++;
    if (age <= 24 * 60 * 60 * 1000) row.day++;
    if (age <= 60 * 60 * 1000) {
      row.hour++;
      if (AUDIT_ACTIONS[e.action as AuditAction]?.removal) row.hourRemovals++;
    }
    out.set(e.actorId, row);
  }
  const t = flagThresholds();
  for (const row of out.values()) {
    row.flagged = row.hourRemovals >= t.removals || row.hour >= t.actions;
  }
  return out;
}
