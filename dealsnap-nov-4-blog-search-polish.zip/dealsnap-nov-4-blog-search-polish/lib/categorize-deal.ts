// Maps a product's text (title, retailer breadcrumbs, link) onto our fixed
// category/tag taxonomy, for the submit form's autofill. Only ever picks from
// getCategoryGroups() — never invents a category — and says how sure it is, so the
// form can ask the poster to double-check rather than silently guess.
//
// How it decides, in short:
//  - Every tag has a list of everyday words ("trainer", "vacuum cleaner"…).
//    Plurals match automatically ("vacuum cleaners"), apostrophes don't matter
//    ("men's" = "mens"), and hyphens count as spaces ("air-fryer").
//  - Text from the product title and the retailer's own category trail counts
//    far more than the marketing blurb, so a stray "hair removal" in a Dyson
//    vacuum's description can't outvote "Vacuum Cleaners" in its breadcrumbs.
//  - Once a tag wins, its popular product lines get a look in: "MacBook Air"
//    is the MacBook sub-tag of Laptop. Accessories stay on the tag ("iPhone
//    case" is Mobile Phone, not iPhone). Who makes it is worked out separately
//    (lib/brands.ts).
//  - Admins can add words to any tag or sub-tag (Admin → Tags and brands).
//  - Clothing, footwear, accessories and grooming are split by gender in our
//    taxonomy, so those words resolve to the men's/women's/kids' tag from
//    whatever the text says (and ask for a check when it doesn't say).

import { getCategoryGroups, getTagByBuiltin, getTagByName, taxonomyVersion } from "./categories";
import { getTagWords } from "./db";

export type CategorySignal = { text: string | undefined; weight: number };
export type CategoryMatch = { category: string; tag: string; confidence: "high" | "check" };

// Signal weights the callers use — exported so they stay in one place.
export const SIGNAL_WEIGHT = {
  title: 4,
  trail: 4, // retailer breadcrumbs / schema.org product category
  link: 3, // words in the URL path
  keywords: 1,
  description: 0.5,
} as const;

// ---------------------------------------------------------------------------
// Word lists. Terms are written in plain singular form, lowercase, no
// apostrophes. Anything with a "@" prefix is a gendered family (see below).
// ---------------------------------------------------------------------------

const TERMS: Record<string, string[]> = {
  // Electronics & Computers
  "Mobile Phone": [
    "phone", "smartphone", "iphone", "android phone", "galaxy s#", "galaxy a#", "galaxy z#", "pixel", "sim only",
    "mobile phone", "oneplus", "xiaomi", "redmi", "oppo", "motorola", "phone case", "screen protector",
    "power bank", "phone charger", "magsafe",
  ],
  Computer: [
    "desktop pc", "desktop computer", "pc tower", "all in one pc", "gaming pc", "mini pc", "monitor", "keyboard",
    "mouse", "webcam", "printer", "router", "mesh wifi", "graphics card", "gpu", "motherboard", "processor",
    "ram", "usb hub", "docking station", "ink cartridge", "toner cartridge", "wifi extender", "mac mini", "imac",
    "raspberry pi", "computer", "pc",
  ],
  Laptop: ["laptop", "notebook", "macbook", "chromebook", "ultrabook", "surface laptop", "surface pro", "thinkpad"],
  Tablet: ["tablet", "ipad", "galaxy tab", "fire hd", "kindle fire"],
  Headphone: [
    "headphone", "earbud", "earphone", "airpod", "over ear", "in ear", "noise cancelling", "galaxy buds",
    "wireless buds", "headset", "bone conduction", "beats studio", "beats solo",
  ],
  Speaker: ["speaker", "soundbar", "sound bar", "bluetooth speaker", "smart speaker", "echo dot", "homepod", "sonos", "boombox", "subwoofer", "home cinema"],
  Camera: ["camera", "dslr", "mirrorless", "gopro", "camcorder", "dash cam", "action cam", "polaroid", "instax", "drone", "lens", "tripod", "security camera", "ring doorbell", "video doorbell"],
  TV: ["tv", "television", "oled", "qled", "smart tv", "4k tv", "bravia", "fire stick", "fire tv", "chromecast", "projector", "tv box"],
  Smartwatch: ["smartwatch", "smart watch", "fitness tracker", "fitbit", "garmin", "apple watch", "galaxy watch", "running watch", "gps watch", "sports watch", "activity tracker", "whoop"],
  "Storage Device": ["ssd", "hard drive", "hdd", "usb drive", "flash drive", "memory card", "sd card", "microsd", "external drive", "nas", "usb stick", "pen drive", "portable drive", "nvme"],
  "Digital Product": [
    "software", "licence", "license", "digital download", "subscription", "digital code", "gift card", "e gift", "voucher",
    "antivirus", "vpn", "microsoft office", "microsoft 365", "windows 11", "windows 10", "netflix", "disney plus",
    "spotify", "prime video", "now tv", "audible", "online course", "streaming", "nordvpn", "expressvpn", "surfshark",
  ],

  // Gaming & Entertainment
  Playstation: ["playstation", "ps5", "ps4", "ps3", "dualsense", "ps vr", "psvr", "ps plus", "psn"],
  Xbox: ["xbox", "game pass", "series x", "series s"],
  Nintendo: ["nintendo", "nintendo switch", "switch oled", "switch lite", "joy con", "mario", "zelda", "pokemon", "animal crossing"],
  "PC Game": ["pc game", "steam key", "steam deck", "steam gift", "steam wallet", "epic games", "pc gaming", "gaming headset", "gaming mouse", "gaming keyboard", "gaming chair"],
  "Mobile Game": ["mobile game", "app store", "google play", "in app purchase"],
  Toy: [
    "toy", "lego", "action figure", "plush", "board game", "jigsaw puzzle", "puzzle", "doll", "playset", "play doh",
    "nerf", "barbie", "hot wheels", "teddy", "playmobil", "fisher price", "peppa pig", "paw patrol", "trampoline",
    "scooter", "ride on", "card game", "monopoly", "building set", "construction set", "baby toy", "kids toy",
  ],
  Sport: [
    "football", "rugby", "cricket", "tennis", "golf", "badminton", "yoga mat", "dumbbell", "kettlebell", "treadmill",
    "exercise bike", "cycling", "bicycle", "bike", "e bike", "gym equipment", "fitness equipment", "weights", "resistance band",
    "protein powder", "swimming", "camping", "tent", "sleeping bag", "hiking", "fishing", "skateboard", "boxing",
    "running machine", "rowing machine", "pickleball", "padel",
  ],
  "Book and eBook": ["book", "ebook", "e book", "novel", "paperback", "hardback", "hardcover", "audiobook", "kindle", "e reader", "ereader", "box set", "cookbook", "colouring book", "annual"],

  // Home & Living
  Furniture: [
    "furniture", "sofa", "armchair", "dining table", "bed frame", "wardrobe", "office desk", "desk", "mattress",
    "chest of drawers", "bookcase", "bedside table", "coffee table", "tv stand", "shoe rack", "office chair",
    "gaming desk", "bunk bed", "divan", "ottoman", "headboard", "sideboard", "dining chair", "bar stool", "recliner",
    "garden furniture", "bean bag",
  ],
  "Small Appliances": [
    "kettle", "toaster", "blender", "microwave", "air fryer", "coffee machine", "vacuum", "vacuum cleaner",
    "robot vacuum", "stick vacuum", "cordless vacuum", "steam mop", "steam iron", "slow cooker", "pressure cooker",
    "rice cooker", "food processor", "stand mixer", "hand mixer", "hand blender", "juicer", "sandwich maker",
    "soup maker", "hot chocolate maker", "hot chocolate machine", "ice cream maker", "heater", "fan heater",
    "dehumidifier", "air purifier", "humidifier", "tower fan", "electric blanket", "bread maker", "waffle maker",
    "coffee maker", "espresso machine", "nespresso machine", "pod machine", "airfryer", "multi cooker", "sodastream",
    "electric fan", "oil heater", "radiator", "dyson", "dual zone air fryer", "kmix",
  ],
  "Large Appliances": [
    "fridge", "refrigerator", "washing machine", "washer dryer", "dishwasher", "tumble dryer", "freezer", "fridge freezer",
    "oven", "hob", "cooker", "range cooker", "cooker hood", "built in oven", "american fridge", "wine cooler", "integrated",
  ],
  "Household Product": [
    "detergent", "washing powder", "washing up liquid", "laundry", "fabric conditioner", "bin bag", "bin liner", "kitchen roll",
    "toilet roll", "cleaning spray", "bleach", "air freshener", "battery", "light bulb", "nappy", "diaper", "baby wipe",
    "wipes", "cleaning product", "household product", "dishwasher tablet", "dishwasher salt", "washing machine cleaner",
    "bathroom cleaner", "mop", "sponge", "refuse sack", "pet food", "cat litter", "dog food", "cat food", "lightbulb",
    "fairy liquid", "ariel", "persil", "dettol", "domestos",
  ],
  "Home Accessories": [
    "home decor", "cushion", "rug", "curtain", "blind", "wall art", "home accessories", "photo frame", "mirror", "candle",
    "vase", "lamp", "lampshade", "bedding", "duvet", "pillow", "towel", "throw", "blanket", "clock", "plant pot",
    "smart bulb", "led strip", "smart plug", "garden", "patio", "bbq", "barbecue", "parasol", "fire pit", "doormat",
    "storage box", "storage basket", "hanging basket", "planter", "artificial plant", "fairy lights", "christmas tree",
    "christmas decoration", "wreath", "bath mat", "shower curtain", "hue", "led bulb", "night light", "wallpaper",
    "duvet cover", "bed sheet", "mattress topper", "bean bag",
  ],
  Kitchenware: [
    "kitchenware", "cookware", "saucepan", "frying pan", "pan", "cutlery", "kitchen utensil", "utensil", "casserole",
    "baking tray", "knife set", "kitchen knife", "dinner set", "dinner service", "mug", "tumbler", "water bottle",
    "lunch box", "chopping board", "wok", "dutch oven", "roasting tin", "storage jar", "tupperware", "cafetiere",
    "teapot", "plate", "bowl", "wine glass", "gin glass", "drinking glass", "pint glass", "glassware", "champagne flute",
    "cocktail shaker", "le creuset", "tefal", "pyrex", "bakeware", "cake tin", "colander", "measuring jug", "thermos",
    "flask", "kitchen scale", "food storage", "casserole dish", "baking dish", "salad bowl", "serving dish", "coffee press",
  ],
  Tool: [
    "power tool", "drill", "screwdriver", "toolkit", "tool kit", "tool set", "spanner", "socket set", "impact driver",
    "hammer", "saw", "sander", "workbench", "ladder", "lawn mower", "lawnmower", "strimmer", "hedge trimmer",
    "garden hose", "hose", "pressure washer", "wrench", "toolbox", "multi tool", "combi drill", "angle grinder",
    "cordless drill", "chainsaw", "leaf blower", "wheelbarrow", "paint", "dewalt", "makita", "bosch professional",
    "workmate", "tool box", "pliers", "jump starter", "car battery charger", "car accessory", "dash mount",
  ],

  // Food, Groceries & Gifting
  Alcohol: [
    "wine", "beer", "lager", "ale", "cider", "whisky", "whiskey", "vodka", "gin", "rum", "champagne", "prosecco",
    "brandy", "tequila", "liqueur", "spirits", "cocktail", "craft beer", "bourbon", "sherry", "cognac",
    "alcohol", "baileys", "jagermeister", "gordons", "smirnoff", "guinness", "stout", "ipa", "pale ale", "rose wine", "red wine", "white wine",
  ],
  Groceries: [
    "groceries", "grocery", "supermarket", "weekly shop", "meal deal", "milk", "bread", "eggs", "rice", "pasta", "cereal",
    "fruit", "vegetable", "meat", "chicken", "fish", "butter", "cheese", "yoghurt", "yogurt", "bacon", "sausage",
    "mince", "ham", "salmon", "steak", "cooking oil", "flour", "sugar", "tinned", "frozen food", "ready meal",
    "food shop", "big shop", "clubcard", "nectar", "baked beans", "beans", "soup", "noodle", "tomato", "potato", "veg", "ketchup", "baked beans",
  ],
  Confectionery: [
    "chocolate", "candy", "sweets", "confectionery", "lindor", "haribo", "cadbury", "maltesers", "truffle", "fudge",
    "toffee", "gummy", "gummies", "chewing gum", "hotel chocolat", "celebrations", "quality street", "ferrero",
    "kinder", "easter egg", "liquorice", "marshmallow", "jelly babies", "lollipop", "mints", "milk chocolate",
  ],
  "Food and Drink": [
    "snack", "coffee", "tea", "coffee beans", "tea bag", "crisps", "biscuit", "juice", "soft drink", "energy drink", "cola",
    "protein bar", "cereal bar", "vinegar", "olive oil", "sauce", "pizza", "burger", "takeaway", "restaurant",
    "dining", "coffee pod", "dominos", "mcdonalds", "greggs", "kfc", "nandos", "pret", "starbucks", "costa", "deliveroo",
    "uber eats", "just eat", "food and drink", "ground coffee", "instant coffee", "hot chocolate", "nuts", "popcorn", "oats",
    "honey", "jam", "peanut butter", "apple cider vinegar", "squash", "sparkling water", "kombucha",
  ],
  Flower: ["flower", "bouquet", "flower delivery", "bunch of flowers", "roses delivery", "interflora", "bloom", "bloomon", "plant delivery", "houseplant"],
  Hamper: ["hamper", "gift basket", "gift hamper", "gift box", "letterbox gift", "christmas hamper", "treat box", "afternoon tea gift"],

  // Leisure & Travel
  Flights: ["flight", "airline", "airline ticket", "ryanair", "easyjet", "british airways", "wizz air", "return flight", "one way flight", "airfare", "jet2 flights"],
  Hotels: [
    "hotel", "holiday inn", "hotel stay", "bed and breakfast", "premier inn", "travelodge", "hostel", "airbnb", "night stay", "spa break",
    "staycation", "glamping", "cottage", "booking com", "lodge", "b and b", "overnight stay", "spa day", "resort stay",
  ],
  "Holiday Packages": [
    "holiday", "holiday package", "package holiday", "all inclusive", "all inclusive holiday", "vacation", "cruise", "jet2 holidays",
    "tui", "city break", "weekend break", "lastminute com", "villa", "fly and stay", "ski trip", "tenerife", "majorca", "benidorm",
  ],
  "Car Hire": ["car hire", "rental car", "car rental", "hire car", "van hire", "airport parking", "car park", "enterprise", "hertz", "europcar", "avis"],

  // Health & Beauty (non-gendered)
  Perfume: ["perfume", "fragrance", "eau de parfum", "eau de toilette", "cologne", "aftershave", "body mist", "parfum", "edp", "edt", "scent", "gift set perfume"],
  Cosmetic: [
    "makeup", "make up", "cosmetic", "lipstick", "foundation", "mascara", "eyeshadow", "concealer", "blusher", "blush", "lip gloss",
    "eyeliner", "nail polish", "palette", "primer", "setting spray", "brow", "bronzer", "highlighter", "false lashes", "lash", "nail",
    "lip liner", "bb cream", "contour", "makeup brush", "beauty blender", "maybelline", "l oreal", "revlon", "nyx",
  ],
  "Personal Care": [
    "personal care", "toothbrush", "toothpaste", "mouthwash", "skincare", "skin care", "serum", "moisturiser", "moisturizer",
    "cleanser", "toner", "spf", "sunscreen", "sun cream", "face wash", "body wash", "shower gel", "shampoo", "conditioner",
    "deodorant", "hand wash", "hand cream", "body lotion", "lotion", "soap", "vitamin", "supplement", "sanitary", "tampon",
    "condom", "cotton pad", "face mask", "lip balm", "paracetamol", "ibuprofen", "plaster", "first aid", "oral b", "colgate",
    "sensodyne", "niacinamide", "retinol", "hyaluronic", "the ordinary", "face cream", "night cream", "day cream",
    "eye cream", "body butter", "bath bomb", "bubble bath", "dental floss", "cerave", "nivea", "dove", "aveeno", "hair mask",
    "hair oil", "hair dye", "hair colour", "contact lens", "cold and flu", "hay fever", "baby lotion",
  ],
};

// Words for the sub-tags, looked at only once their tag has won.
const SUBTAG_TERMS: Record<string, string[]> = {
  iPhone: ["iphone"],
  "Galaxy Phone": ["galaxy s#", "galaxy a#", "galaxy z#", "galaxy z fold", "galaxy z fold#", "galaxy z flip", "galaxy z flip#", "galaxy fold", "galaxy flip", "galaxy phone"],
  MacBook: ["macbook"],
  Chromebook: ["chromebook"],
  iPad: ["ipad"],
  AirPods: ["airpod"],
  "Apple Watch": ["apple watch"],
  PS5: ["ps5", "playstation 5", "dualsense", "ps vr2", "psvr2"],
  "Xbox Series": ["xbox series", "series x", "series s"],
  "Switch 2": ["switch 2", "nintendo switch 2"],
};

// Words that make a product an accessory for a product line rather than the
// thing itself, so it stays on the broader tag.
const ACCESSORY = /(?<![a-z0-9])(?:case|cases|cover|covers|screen protector|protector|charger|charging|cable|adapter|strap|band|sleeve|stand|holder|mount|skin|stylus|keyboard case|dock)(?![a-z0-9])/;

// Gendered families. Each term says who it defaults to when the text doesn't
// say ("m" men, "f" women, "k" kids, none = no default, so ask for a check).
type Gender = "m" | "f" | "k" | "g" | "b";
const FAMILIES: Record<string, { tags: Partial<Record<Gender, string>>; fallback: Gender; terms: string[] }> = {
  "@footwear": {
    tags: { m: "Men's Footwear", f: "Women's Footwear", k: "Kid's Clothing", g: "Girl's Clothing", b: "Boy's Clothing" },
    fallback: "m",
    terms: [
      "trainer", "shoe", "boot", "sandal", "sneaker", "slipper", "heel|f", "loafer", "clog", "flip flop", "wellington",
      "wellie", "running shoe", "football boot", "ankle boot", "chelsea boot", "court shoe|f", "ballet flat|f", "sliders",
      "air max", "air force", "air jordan", "adidas samba", "new balance", "converse", "vans", "crocs", "ugg", "birkenstock", "footwear",
    ],
  },
  "@clothing": {
    tags: { m: "Men's Clothing", f: "Women's Clothing", k: "Kid's Clothing", g: "Girl's Clothing", b: "Boy's Clothing" },
    fallback: "m",
    terms: [
      "hoodie", "jumper", "jacket", "jeans", "shirt", "t shirt", "tshirt", "tee", "trousers", "shorts", "coat", "dress|f",
      "skirt|f", "blouse|f", "leggings|f", "joggers", "tracksuit", "sweatshirt", "cardigan", "sock", "pyjama", "pajama",
      "polo", "gilet", "puffer", "fleece", "parka", "swimwear", "swimsuit|f", "bikini|f", "activewear", "gym wear", "sports bra|f",
      "crop top", "tank top", "vest top", "knitwear", "sweater", "chinos", "suit", "waistcoat", "cargo", "denim", "clothing", "clothes", "jersey", "boxers|m",
      "bodysuit|f", "jumpsuit|f", "playsuit|f", "romper", "onesie", "dressing gown", "nightwear",
    ],
  },
  "@accessories": {
    tags: { m: "Men's Accessories", f: "Women's Accessories", k: "Kid's Clothing", g: "Girl's Clothing", b: "Boy's Clothing" },
    fallback: "f",
    terms: [
      "handbag|f", "purse|f", "jewellery|f", "jewelry|f", "necklace|f", "bracelet|f", "earring|f", "wallet|m", "belt", "tie|m",
      "sunglasses", "scarf|f", "hat", "cap", "backpack", "bag", "tote|f", "watch", "wrist watch", "analogue watch", "analog watch",
      "chronograph", "cufflink|m", "umbrella", "gloves", "beanie", "luggage", "suitcase", "satchel", "rucksack", "crossbody|f",
      "clutch|f", "hair accessories|f", "pandora|f", "swarovski|f", "ray ban", "oakley", "casio", "g shock",
    ],
  },
  "@lingerie": {
    tags: { f: "Lingerie", m: "Men's Clothing", k: "Kid's Clothing" },
    fallback: "f",
    terms: ["lingerie", "bra|f", "bralette|f", "knickers|f", "underwear", "briefs", "thong|f", "nightie|f", "corset|f", "shapewear|f", "tights|f", "stockings|f", "pants|f"],
  },
  "@grooming": {
    tags: { m: "Men's Grooming", f: "Women's Grooming" },
    fallback: "f",
    terms: [
      "razor|m", "shaver|m", "trimmer|m", "clippers|m", "beard|m", "shaving|m", "epilator|f", "hair dryer|f", "straightener|f",
      "hair curler|f", "curling tong|f", "ipl|f", "hair removal|f", "hair straightener|f", "hair clipper|m", "wax strip|f",
      "grooming", "braun", "philips norelco", "gillette|m", "wahl|m", "ghd|f", "babyliss|f", "supersonic|f", "airwrap|f", "dyson airwrap|f",
    ],
  },
};

// Phrases that would otherwise trip a single-word rule ("apple" in apple
// cider vinegar, "hotel" in Hotel Chocolat, "tablet" in dishwasher tablets).
// Each says which tag it really is, and is wiped from the text afterwards so
// its words can't score on their own.
const PHRASES: { phrase: string; tag: string }[] = [
  // Product lines that are only ever one thing, however the rest of the title reads.
  { phrase: "lego", tag: "Toy" },
  { phrase: "playstation", tag: "Playstation" },
  { phrase: "xbox", tag: "Xbox" },
  { phrase: "nintendo", tag: "Nintendo" },
  { phrase: "airpods", tag: "Headphone" },
  { phrase: "iphone", tag: "Mobile Phone" },
  { phrase: "macbook", tag: "Laptop" },
  { phrase: "ipad", tag: "Tablet" },
  { phrase: "hotel chocolat", tag: "Confectionery" },
  { phrase: "apple cider vinegar", tag: "Food and Drink" },
  { phrase: "apple cider", tag: "Alcohol" },
  { phrase: "dishwasher tablet", tag: "Household Product" },
  { phrase: "dishwasher cleaner", tag: "Household Product" },
  { phrase: "dishwasher salt", tag: "Household Product" },
  { phrase: "washing machine cleaner", tag: "Household Product" },
  { phrase: "washing up liquid", tag: "Household Product" },
  { phrase: "tumble dryer sheet", tag: "Household Product" },
  { phrase: "vitamin tablet", tag: "Personal Care" },
  { phrase: "coffee table", tag: "Furniture" },
  { phrase: "tea towel", tag: "Home Accessories" },
  { phrase: "tea light", tag: "Home Accessories" },
  { phrase: "hot water bottle", tag: "Home Accessories" },
  { phrase: "gin glass", tag: "Kitchenware" },
  { phrase: "wine glass", tag: "Kitchenware" },
  { phrase: "wine rack", tag: "Furniture" },
  { phrase: "wine cooler", tag: "Large Appliances" },
  { phrase: "book case", tag: "Furniture" },
  { phrase: "bookshelf", tag: "Furniture" },
  { phrase: "phone holder", tag: "Mobile Phone" },
  { phrase: "pet bowl", tag: "Household Product" },
  { phrase: "sleeping bag", tag: "Sport" },
  { phrase: "hair dryer", tag: "@grooming" },
  { phrase: "bin bag", tag: "Household Product" },
  { phrase: "stand mixer", tag: "Small Appliances" },
  { phrase: "coffee machine", tag: "Small Appliances" },
  { phrase: "coffee maker", tag: "Small Appliances" },
  { phrase: "coffee grinder", tag: "Small Appliances" },
  { phrase: "espresso machine", tag: "Small Appliances" },
  { phrase: "hot chocolate machine", tag: "Small Appliances" },
  { phrase: "hot chocolate maker", tag: "Small Appliances" },
  { phrase: "air fryer", tag: "Small Appliances" },
  { phrase: "slow cooker", tag: "Small Appliances" },
  { phrase: "pressure cooker", tag: "Small Appliances" },
  { phrase: "rice cooker", tag: "Small Appliances" },
  { phrase: "milk chocolate", tag: "Confectionery" },
  { phrase: "white chocolate", tag: "Confectionery" },
  { phrase: "dark chocolate", tag: "Confectionery" },
  { phrase: "hot chocolate", tag: "Food and Drink" },
  { phrase: "coffee cup", tag: "Kitchenware" },
  { phrase: "coffee mug", tag: "Kitchenware" },
  { phrase: "pizza oven", tag: "Large Appliances" },
];

// Words that mean who a product is for. Checked in the title first, then the
// retailer's category trail, then the link.
const GENDER_WORDS: [Gender, RegExp][] = [
  ["f", /(?<![a-z0-9])(?:womens?|woman|ladies|lady|female)(?![a-z0-9])/],
  ["m", /(?<![a-z0-9])(?:mens?|gents|male)(?![a-z0-9])/],
  ["g", /(?<![a-z0-9])(?:girls?|girl s)(?![a-z0-9])/],
  ["b", /(?<![a-z0-9])(?:boys?|boy s)(?![a-z0-9])/],
  ["k", /(?<![a-z0-9])(?:kids?|child|children|childrens|baby|babies|toddler|junior|infant)(?![a-z0-9])/],
];

// ---------------------------------------------------------------------------
// Matching
// ---------------------------------------------------------------------------

function normalise(text: string): string {
  return ` ${text
    .toLowerCase()
    .replace(/[’‘`´]/g, "'")
    .replace(/'s\b/g, "s")
    .replace(/'/g, "")
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9£#]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()} `;
}

// "#" in a term stands for a run of digits ("galaxy s#" = Galaxy S24, S9…).
// Plurals match too: nappy/nappies, knife/knives, shelf/shelves, box/boxes.
function termRegex(term: string): RegExp {
  const t = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/#/g, "[0-9]+");
  let body = `${t}(?:s|es)?`;
  if (/[^aeiou]y$/.test(t)) body = `(?:${t.slice(0, -1)}(?:y|ies)|${t}s?)`;
  else if (/fe$/.test(t)) body = `(?:${t}s?|${t.slice(0, -2)}ves)`;
  else if (/[^f]f$/.test(t)) body = `(?:${t}s?|${t.slice(0, -1)}ves)`;
  return new RegExp(`(?<![a-z0-9])${body}(?![a-z0-9])`);
}

function termWeight(term: string): number {
  const words = term.split(" ").length;
  return words >= 3 ? 2 : words === 2 ? 1.5 : 1;
}

type CompiledTerm = { re: RegExp; w: number; target: string; gender?: Gender };
type Family = { tags: Partial<Record<Gender, string>>; fallback: Gender };

// Everything compiled from the word lists above and the live tree. The lists
// are written against the tags' built-in names: a tag renamed or moved in Admin
// keeps its words (it's found by its built-in name), one that's been removed
// loses them, and one added later is found by its own name and whatever extra
// words an admin gives it. Rebuilt whenever the tree or those words change.
type Index = {
  version: number;
  terms: CompiledTerm[];
  phrases: { re: RegExp; tag: string }[];
  tagToCategory: Map<string, string>;
  subtagTerms: Map<string, RegExp[]>;
  families: Map<string, Family>;
  familyTags: Set<string>;
  extra: { tags: CompiledTerm[]; subtags: Map<string, RegExp[]> };
};
let index: Index | undefined;

function getIndex(): Index {
  const version = taxonomyVersion();
  if (index && index.version === version) return index;

  const nameOf = (builtin: string) => getTagByBuiltin(builtin)?.tag.name;
  const terms: CompiledTerm[] = [];
  const seen = new Set<string>();
  const addTerm = (term: string, target: string, gender?: Gender) => {
    const key = `${target}|${term}`;
    if (seen.has(key)) return;
    seen.add(key);
    terms.push({ re: termRegex(term), w: termWeight(term), target, gender });
  };
  for (const [builtin, list] of Object.entries(TERMS)) {
    const target = nameOf(builtin);
    if (target) for (const raw of list) addTerm(normalise(raw).trim(), target);
  }
  // The tag's own name always counts too ("Headphone", "Furniture").
  const tagToCategory = new Map<string, string>();
  for (const group of getCategoryGroups()) {
    for (const tag of group.tags) {
      tagToCategory.set(tag.name, group.name);
      const term = normalise(tag.name).trim();
      // "Women's Clothing" etc. are resolved through the gender families instead.
      if (/^(womens|mens|kids|girls|boys) /.test(term) || /lingerie/.test(term)) continue;
      addTerm(term, tag.name);
    }
  }
  const families = new Map<string, Family>();
  for (const [family, def] of Object.entries(FAMILIES)) {
    const tags: Partial<Record<Gender, string>> = {};
    for (const [gender, builtin] of Object.entries(def.tags) as [Gender, string][]) {
      const name = nameOf(builtin);
      if (name) tags[gender] = name;
    }
    const available = Object.keys(tags) as Gender[];
    if (!available.length) continue;
    families.set(family, { tags, fallback: tags[def.fallback] ? def.fallback : available[0] });
    for (const raw of def.terms) {
      const [text, g] = raw.split("|");
      addTerm(normalise(text).trim(), family, g as Gender | undefined);
    }
  }
  const phrases = PHRASES.flatMap((p) => {
    const tag = p.tag.startsWith("@") ? p.tag : nameOf(p.tag);
    return tag ? [{ re: termRegex(normalise(p.phrase).trim()), tag }] : [];
  });
  const subtagTerms = new Map(
    Object.entries(SUBTAG_TERMS).flatMap(([builtin, list]) => {
      const name = nameOf(builtin);
      return name ? [[name, list.map((t) => termRegex(normalise(t).trim()))] as const] : [];
    })
  );

  // Words admins have added (Admin → Tags and brands).
  const extraTags: CompiledTerm[] = [];
  const extraSubtags = new Map<string, RegExp[]>();
  for (const [name, words] of getTagWords()) {
    const info = getTagByName(name);
    if (!info) continue;
    const res = words.map((w) => normalise(w).trim()).filter(Boolean);
    if (info.parent) extraSubtags.set(info.tag.name, res.map(termRegex));
    else for (const w of res) extraTags.push({ re: termRegex(w), w: termWeight(w), target: info.tag.name });
  }

  index = {
    version,
    terms,
    phrases,
    tagToCategory,
    subtagTerms,
    families,
    familyTags: new Set([...families.values()].flatMap((f) => Object.values(f.tags) as string[])),
    extra: { tags: extraTags, subtags: extraSubtags },
  };
  return index;
}
// An admin changed a tag's extra words: compile again on the next use.
export function forgetExtraWords() {
  index = undefined;
}

// The most specific sub-tag of `tag` the strongest signals name, if any.
function pickSubtag(tag: string, live: { text: string; weight: number }[]): string | undefined {
  const subtags = getTagByName(tag)?.tag.subtags;
  if (!subtags?.length) return undefined;
  const strong = live.filter((s) => s.weight >= SIGNAL_WEIGHT.link);
  // Title first: a case "for iPhone" is still a case.
  if (strong.some((s) => s.weight === SIGNAL_WEIGHT.title && ACCESSORY.test(s.text))) return undefined;
  const { subtagTerms, extra } = getIndex();
  let best: { name: string; score: number } | undefined;
  for (const sub of subtags) {
    const res = [...(subtagTerms.get(sub.name) ?? []), ...(extra.subtags.get(sub.name) ?? []), termRegex(normalise(sub.name).trim())];
    const score = strong.reduce((n, s) => n + (res.some((re) => re.test(s.text)) ? s.weight : 0), 0);
    if (score >= 3 && (!best || score > best.score)) best = { name: sub.name, score };
  }
  return best?.name;
}

// Learns from deals already on the site: a word that has only ever appeared
// in titles of one tag (seen at least twice) nudges new titles to that tag.
export type LearnedIndex = Map<string, Map<string, number>>;

const STOP = new Set(["with", "from", "that", "this", "your", "pack", "set", "free", "deal", "offer", "size", "black", "white", "blue", "red", "green", "grey", "gray", "pink", "silver", "gold", "just", "only", "new", "the", "and", "for", "plus", "pro", "max", "mini", "ultra", "edition"]);

function learnTokens(title: string): string[] {
  return [...new Set(normalise(title).trim().split(" "))].filter((w) => w.length >= 4 && !/\d/.test(w) && !STOP.has(w));
}

export function buildLearnedIndex(deals: { title: string; tag: string }[]): LearnedIndex {
  const index: LearnedIndex = new Map();
  for (const deal of deals) {
    // A sub-tag's deals teach its tag; the sub-tag is picked afterwards.
    const info = getTagByName(deal.tag);
    const tag = info?.parent?.name ?? info?.tag.name;
    if (!tag || !getIndex().tagToCategory.has(tag)) continue;
    for (const token of learnTokens(deal.title)) {
      const counts = index.get(token) ?? new Map<string, number>();
      counts.set(tag, (counts.get(tag) ?? 0) + 1);
      index.set(token, counts);
    }
  }
  return index;
}

function detectGender(texts: string[]): Gender | undefined {
  for (const text of texts) {
    for (const [gender, re] of GENDER_WORDS) if (re.test(text)) return gender;
  }
  return undefined;
}

export function matchCategoryAndTag(
  signals: CategorySignal[],
  opts: { learned?: LearnedIndex; title?: string } = {}
): CategoryMatch | undefined {
  const idx = getIndex();
  const live = signals
    .filter((s): s is { text: string; weight: number } => !!s.text && s.text.trim().length > 0)
    .map((s) => ({ text: normalise(s.text), weight: s.weight }));
  if (live.length === 0) return undefined;

  const score = new Map<string, number>();
  const add = (target: string, n: number) => score.set(target, (score.get(target) ?? 0) + n);
  // Per family: which gender its matched terms lean towards, strongest first.
  const familyLean = new Map<string, Map<Gender, number>>();

  for (const signal of live) {
    let text = signal.text;

    // Whole phrases first, then wipe them so their words don't count again.
    for (const phrase of idx.phrases) {
      if (phrase.re.test(text)) {
        add(phrase.tag, signal.weight * 2.5);
        text = text.replace(new RegExp(phrase.re.source, "g"), " ");
      }
    }

    // A term counts once per signal, however often the text repeats it.
    for (const term of [...idx.terms, ...idx.extra.tags]) {
      if (!term.re.test(text)) continue;
      add(term.target, signal.weight * term.w);
      if (term.gender) {
        const lean = familyLean.get(term.target) ?? new Map<Gender, number>();
        lean.set(term.gender, (lean.get(term.gender) ?? 0) + signal.weight * term.w);
        familyLean.set(term.target, lean);
      }
    }
  }

  // Words the site has learned from its own deals.
  if (opts.learned && opts.title) {
    const learnedByTag = new Map<string, number>();
    for (const token of learnTokens(opts.title)) {
      const counts = opts.learned.get(token);
      if (!counts) continue;
      const total = [...counts.values()].reduce((a, b) => a + b, 0);
      const [topTag, top] = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];
      if (total >= 2 && top / total >= 0.8) learnedByTag.set(topTag, (learnedByTag.get(topTag) ?? 0) + 1.5);
    }
    for (const [tag, n] of learnedByTag) add(tag, Math.min(n, 3));
  }

  // Turn gendered families into a real tag.
  // Only the title, retailer trail and link say who a product is for — never the blurb.
  const gender = detectGender(live.filter((s) => s.weight >= SIGNAL_WEIGHT.link).map((s) => s.text));
  let genderGuessed = false;
  const resolved = new Map<string, number>();
  for (const [target, value] of score) {
    if (!target.startsWith("@")) {
      resolved.set(target, (resolved.get(target) ?? 0) + value);
      continue;
    }
    const def = idx.families.get(target);
    if (!def) continue;
    let g: Gender | undefined = gender;
    if (g === "g" || g === "b" || g === "k") {
      // kids' wording applies to every family that has a kids tag
    } else if (!g || !def.tags[g]) {
      const lean = familyLean.get(target);
      g = lean ? [...lean.entries()].sort((a, b) => b[1] - a[1])[0][0] : undefined;
      if (g && !def.tags[g]) g = undefined;
    }
    if (!g) {
      g = def.fallback;
      genderGuessed = true;
    }
    const tag = def.tags[g] ?? def.tags[def.fallback]!;
    resolved.set(tag, (resolved.get(tag) ?? 0) + value);
  }

  const ranked = [...resolved.entries()]
    .filter(([tag]) => idx.tagToCategory.has(tag))
    .sort((a, b) => b[1] - a[1]);

  const MIN = 3; // roughly: one product-type word in the title or retailer trail
  if (ranked.length && ranked[0][1] >= MIN) {
    const [tag, s1] = ranked[0];
    const s2 = ranked[1]?.[1] ?? 0;
    const sameCategory = ranked[1] && idx.tagToCategory.get(ranked[1][0]) === idx.tagToCategory.get(tag);
    let confidence: "high" | "check" = s1 >= 8 || s1 >= s2 * 1.6 || (sameCategory && s1 >= 6 && s1 > s2) ? "high" : "check";
    if (genderGuessed && idx.familyTags.has(tag)) confidence = "check";
    return { category: idx.tagToCategory.get(tag)!, tag: pickSubtag(tag, live) ?? tag, confidence };
  }
  if (ranked.length && ranked[0][1] >= 1.5) {
    const [tag] = ranked[0];
    return { category: idx.tagToCategory.get(tag)!, tag: pickSubtag(tag, live) ?? tag, confidence: "check" };
  }
  return undefined;
}

