// The Community's rules and shapes. No database or page code, so the pages,
// the browser (composer counters), the admin screens and the tests all use the
// same numbers and the same text handling.

export const TITLE_MIN = 8;
export const TITLE_MAX = 120;
export const THREAD_BODY_MAX = 8000;
export const REPLY_MAX = 5000;
export const POSTS_PER_PAGE = 25;
export const THREADS_PER_PAGE = 20;

// A post can be changed for this long after it's posted, then it's fixed so
// replies and likes keep meaning what they did. Deleting your own is always allowed.
export const COMMUNITY_EDIT_MINUTES = 60;
export const communityEditableUntil = (createdAt: string) => new Date(createdAt).getTime() + COMMUNITY_EDIT_MINUTES * 60 * 1000;

// A reply with this many likes is picked out as the "Most helpful" one.
export const COMMUNITY_HELPFUL_LIKES = 3;

// The author of a post is told when it reaches each of these many likes
// (once each; nothing is sent for every single like).
export const LIKE_MILESTONES = [5, 25, 100];
export const isLikeMilestone = (count: number) => LIKE_MILESTONES.includes(count);

// A thread with no reply for `days` days is closed to new replies (0 is never),
// so an old conversation can't be dragged back up by a stray reply: people
// start a fresh thread instead. Worked out when asked, so nothing has to run
// in the background and turning the setting off reopens everything at once.
export function isQuietClosed(lastPostAt: string, days: number, now = Date.now()): boolean {
  return days > 0 && now - new Date(lastPostAt).getTime() > days * 24 * 60 * 60 * 1000;
}

// A thread nobody has answered, a day old, shows up for helpers.
export const UNANSWERED_AFTER_HOURS = 24;

// How many people one post can ping with @, and how many deal cards it can open.
export const MAX_MENTIONS = 5;
export const MAX_DEAL_CARDS = 3;

export const SPACE_NAME_MAX = 40;
export const SPACE_BLURB_MAX = 140;
export const SPACE_RULES_MAX = 1200;

// What a space's rules box says when its team hasn't written any, so every space
// has the same box in the same place (a page that gains or loses it jumps as you
// move between spaces).
export const DEFAULT_SPACE_RULES = "Be kind and keep it honest. No spam, referral codes or advertising. Keep personal details private. Report anything that breaks these rules.";

// "talk" is ordinary conversation; "ask" threads are questions that can get a
// best answer.
export type SpaceKind = "talk" | "ask";
export const SPACE_KINDS: { value: SpaceKind; label: string; hint: string }[] = [
  { value: "talk", label: "Talk", hint: "Ordinary conversation." },
  { value: "ask", label: "Questions", hint: "Threads are questions; the asker or a helper can mark the best answer." },
];

// Who may start a thread in a space (anyone confirmed can always reply).
export type SpaceWho = "members" | "staff";
export const SPACE_WHO: { value: SpaceWho; label: string }[] = [
  { value: "members", label: "Any member" },
  { value: "staff", label: "Our team only (announcements)" },
];

// The status of one post.
//   live     ordinary
//   hidden   a helper hid it while a moderator checks it (shows a placeholder)
//   removed  taken down by the team (placeholder "Removed by our team")
//   deleted  deleted by its writer (placeholder "Deleted")
export type PostStatus = "live" | "hidden" | "removed" | "deleted";

// What a post looks like to a reader, whatever its status.
export const PLACEHOLDER: Record<Exclude<PostStatus, "live">, string> = {
  hidden: "Hidden while the team checks it",
  removed: "Removed by our team",
  deleted: "Deleted",
};

export type ThreadSort = "active" | "new" | "top" | "unanswered";

// Which list is being sorted: every space together, a talk space, or a questions
// space. "Unanswered" means two different things, so it is named for each:
//   - in a questions space it is a question nobody's answer has been picked for
//     (it may have replies), which is what that space's helpers look for;
//   - everywhere else it is a thread with no reply at all yet, "No replies yet",
//     which is the one that is clear to anyone, and what a welcome is for.
export type SortContext = "all" | SpaceKind;
export const threadSorts = (context: SortContext): { value: ThreadSort; label: string }[] => [
  { value: "active", label: "Latest activity" },
  { value: "new", label: "Newest" },
  { value: "top", label: "Top this week" },
  { value: "unanswered", label: context === "ask" ? "Unanswered" : "No replies yet" },
];
export const isThreadSort = (v: unknown): v is ThreadSort => v === "active" || v === "new" || v === "top" || v === "unanswered";

// ---------------------------------------------------------------------------
// Searching the Community (by title)
// ---------------------------------------------------------------------------
export const SEARCH_MAX = 80;

// The words of a search: lower case, letters and numbers only, up to five of
// two characters or more. The same words are used for a search and for the
// "already being discussed" hints while a title is typed.
export function searchWords(raw: string, max = 5): string[] {
  const words = String(raw ?? "")
    .slice(0, 200)
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .split(/[^a-z0-9£]+/)
    .filter((w) => w.length >= 2 && w.length <= 30);
  return [...new Set(words)].slice(0, max);
}

// Everyday words that say nothing about what a title is about.
const STOP_WORDS = new Set(
  "the and for with that this what where which who whom when how why can does did you your any are was were has have had not but from about best good cheap cheapest looking need want anyone recommend recommendations deal deals buy get".split(" ")
);

// The words worth matching other titles on: no filler, longest first, at most four.
export const significantWords = (title: string): string[] =>
  searchWords(title, 12)
    .filter((w) => w.length >= 3 && !STOP_WORDS.has(w))
    .sort((a, b) => b.length - a.length)
    .slice(0, 4);

// A word as the pattern of a LIKE search, with its own % and _ taken literally.
export const likeContains = (word: string) => `%${word.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;

// ---------------------------------------------------------------------------
// Welcome threads: one pinned thread per space, so a visitor never lands in an
// empty room. Staff can change every word before it's posted.
// ---------------------------------------------------------------------------
export function welcomeDefaults(space: { slug: string; name: string; kind: SpaceKind; blurb: string }): { title: string; text: string } {
  switch (space.slug) {
    case "deal-talk":
      return {
        title: "Welcome to Deals & vouchers talk: start here",
        text: `This is the place to talk about deals, vouchers, stores and brands: is it a good price, how was the delivery, what do you make of the store?

To share a deal or voucher itself, use + Post a deal at the top of the site, so it can be voted on and checked. You can then link to it here by pasting its address on a line of its own, and it will show as a card.

A few things that help everyone:
- Say what you paid, and where you bought it.
- If a deal has ended or a code has stopped working, say so on the deal itself (\"Deal ended?\" or \"Did the code work?\"), so everyone who finds it sees it.
- Keep it friendly. Disagree with the deal, not the person.

Reply below to say hello, or start a thread of your own.`,
      };
    case "ask":
      return {
        title: "How to ask a question that gets a great answer",
        text: `Ask away: someone here has probably bought the same thing.

A good question says:
- What you are looking for.
- Your budget.
- What you have already tried or looked at.
- Anything that matters most, like size, delivery time or brand.

When an answer helps, tap Best answer under it, so the next person with the same question finds it quickly. One question per thread keeps things easy to follow.`,
      };
    case "money-saving-tips":
      return {
        title: "Share your best money-saving tip",
        text: `Everyday ways to spend less: swaps, loyalty tricks, timing, and things you wish you had known sooner.

What is one thing you do that saves you real money? Tell us what it is and roughly how much it saves.

Please share tips you have tried yourself, and leave out referral codes and affiliate links.`,
      };
    case "chat":
      return {
        title: "New here? Say hello",
        text: `Welcome to DealSnap. Tell us a little about yourself: what you like hunting for, the best deal you have found, or the one that got away.

You do not have to be a deal expert. Everyone here started as a beginner, and a friendly hello goes a long way.

Be kind to newcomers, and keep politics and religion out of it, please.`,
      };
    default:
      return {
        title: `Welcome to ${space.name}`.slice(0, 120),
        text: `${space.blurb ? `${space.blurb}\n\n` : ""}${space.kind === "ask" ? "Ask your question in a new thread, and mark the answer that helped." : "Start a thread, or reply below to say hello."}`,
      };
  }
}

// Names a space can't have as its address: they're the Community's own pages.
export const RESERVED_SPACE_SLUGS = ["t", "new", "search", "latest", "rules"];

// ---------------------------------------------------------------------------
// Text
// ---------------------------------------------------------------------------

// Tidies what a member typed: one line ending, no control characters, no more
// than one blank line in a row, no spaces at the line ends.
export function tidyText(raw: string): string {
  return String(raw ?? "")
    .replace(/\r\n?/g, "\n")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F​-‏‪-‮⁦-⁩﻿]/g, "")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export function tidyTitle(raw: string): string {
  return tidyText(raw).replace(/\s+/g, " ");
}

export function titleError(title: string): string | null {
  if (title.length < TITLE_MIN) return `Give the thread a title of at least ${TITLE_MIN} characters, so people know what it's about.`;
  if (title.length > TITLE_MAX) return `Keep the title to ${TITLE_MAX} characters or fewer.`;
  // A title in capitals reads as shouting.
  const letters = title.replace(/[^A-Za-z]/g, "");
  if (letters.length >= 12 && letters === letters.toUpperCase()) return "Please don't write the whole title in capitals.";
  return null;
}

// Whether a post has a link in it (a web address, with or without https://).
export const LINK_PATTERN = /(https?:\/\/|www\.)|\b[a-z0-9-]+\.(com|co\.uk|net|org|io|uk|shop|store|xyz|app|dev|info|biz|me|ly|link)\b/i;
export const hasLink = (text: string) => LINK_PATTERN.test(text);

// Hardly anything but capitals, repeated characters or a wall of one word is
// spam or shouting; the check is deliberately loose.
export function looksLikeSpam(text: string): boolean {
  const compact = text.replace(/\s+/g, "");
  if (compact.length >= 20 && /^(.{1,3})\1{9,}$/.test(compact)) return true;
  if (/(.)\1{14,}/.test(compact)) return true;
  const words = text.toLowerCase().split(/\s+/).filter(Boolean);
  if (words.length >= 12 && new Set(words).size <= 2) return true;
  return false;
}

// A post, split for display: plain text, web addresses as links, @names as
// links to profiles. Never HTML. Returns pieces for the page to turn into
// elements, so nothing a member typed is ever put in the page as markup.
export type Piece =
  | { type: "text"; text: string }
  | { type: "link"; href: string; label: string }
  | { type: "mention"; username: string };

const URL_OR_MENTION = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"']+)|(?<![A-Za-z0-9_])@([A-Za-z0-9_]{3,20})\b/g;
const TRAILING = /[.,;:!?)\]}'"]+$/;

export function splitPostText(text: string): Piece[] {
  const out: Piece[] = [];
  let last = 0;
  for (const m of text.matchAll(URL_OR_MENTION)) {
    const at = m.index ?? 0;
    if (at > last) out.push({ type: "text", text: text.slice(last, at) });
    if (m[1]) {
      let raw = m[1];
      const trail = raw.match(TRAILING)?.[0] ?? "";
      // Keep a closing bracket that belongs to the address ("…/page_(1)").
      if (trail.startsWith(")") && /\(/.test(raw.slice(0, raw.length - trail.length))) raw = raw.slice(0, raw.length - trail.length + 1);
      else raw = raw.slice(0, raw.length - trail.length);
      const href = raw.startsWith("www.") ? `https://${raw}` : raw;
      let valid = true;
      try {
        const u = new URL(href);
        valid = (u.protocol === "https:" || u.protocol === "http:") && !u.username && !u.password && u.hostname.includes(".");
      } catch {
        valid = false;
      }
      if (valid) {
        out.push({ type: "link", href, label: shortLink(href) });
        last = at + raw.length;
        continue;
      }
      out.push({ type: "text", text: m[0] });
    } else {
      out.push({ type: "mention", username: m[2] });
    }
    last = at + m[0].length;
  }
  if (last < text.length) out.push({ type: "text", text: text.slice(last) });
  return out;
}

// "https://www.argos.co.uk/product/123?x=1" shown as "argos.co.uk/product/123…".
export function shortLink(href: string): string {
  try {
    const u = new URL(href);
    const path = `${u.pathname === "/" ? "" : u.pathname}`;
    const label = `${u.hostname.replace(/^www\./, "")}${path}`;
    const long = label.length > 48 || !!u.search || !!u.hash;
    return long ? `${label.slice(0, 48).replace(/[/.?&=-]+$/, "")}…` : label;
  } catch {
    return href.slice(0, 48);
  }
}

// Names @mentioned in a post, in order, at most MAX_MENTIONS, without repeats.
export function mentionsIn(text: string): string[] {
  const seen = new Set<string>();
  for (const m of text.matchAll(/(?<![A-Za-z0-9_])@([A-Za-z0-9_]{3,20})\b/g)) {
    seen.add(m[1].toLowerCase());
    if (seen.size >= MAX_MENTIONS) break;
  }
  return [...seen];
}

// A line that is only a DealSnap deal's address ("/deals/some-deal", or a full
// address ending that way) opens as a deal card. Returns the deal's slug, or
// undefined for any other line. `host` is the site's own host name, so a link
// to somewhere else with "/deals/" in it never counts.
export function dealSlugOfLine(line: string, host: string): string | undefined {
  const m = line.trim().match(/^(?:https?:\/\/([^/\s]+))?\/deals\/([a-z0-9][a-z0-9-]{0,120})\/?(?:[?#]\S*)?$/i);
  if (!m) return undefined;
  if (m[1] && m[1].toLowerCase().replace(/^www\./, "") !== host.toLowerCase().replace(/^www\./, "")) return undefined;
  return m[2];
}

// The deal cards a post opens: their slugs in order, at most MAX_DEAL_CARDS.
export function dealSlugsIn(text: string, host: string): string[] {
  const slugs: string[] = [];
  for (const line of text.split("\n")) {
    const slug = dealSlugOfLine(line, host);
    if (slug && !slugs.includes(slug)) slugs.push(slug);
    if (slugs.length >= MAX_DEAL_CARDS) break;
  }
  return slugs;
}

// A thread's address: its title in words, then a short piece of its id so two
// threads with the same title never clash.
export function threadSlug(title: string, id: string): string {
  const words = title
    .toLowerCase()
    .replace(/'/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 60)
    .replace(/-$/, "");
  return `${words || "thread"}-${id.replace(/-/g, "").slice(0, 8)}`;
}

// How many pages a thread has, and which page a post (by its number in the
// thread) falls on.
export const pagesFor = (count: number, per = POSTS_PER_PAGE) => Math.max(1, Math.ceil(count / per));
export const pageOfSeq = (seq: number, per = POSTS_PER_PAGE) => Math.max(1, Math.ceil(seq / per));

// Space slug / name checks used by the admin screens.
export function spaceSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/'/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 40);
}
