import crypto from "crypto";
import { sqlite as db, duringSetup, getSiteSetting, setSiteSetting, type UserRole } from "./db";
import type { IconName } from "@/components/Icon";
import {
  POSTS_PER_PAGE,
  THREADS_PER_PAGE,
  likeContains,
  searchWords,
  significantWords,
  threadSlug,
  type PostStatus,
  type SpaceKind,
  type SpaceWho,
  type ThreadSort,
} from "./community-rules";
import { plainDescription } from "./deal-text";

// The Community's tables and every question asked of them. Kept apart from
// lib/db.ts, which is already enormous; it shares that file's connection.
//
// How it is built to stay quick as it grows:
//   - A thread keeps its own counters (replies, likes, last activity) so a
//     list never counts posts, and a post keeps its like count.
//   - Posts are numbered inside their thread (seq), so a page of a thread is
//     one range read on an index, however long the thread is.
//   - Lists page with LIMIT/OFFSET on indexes that match the sort, and only
//     one page is ever read.
//   - Nothing here reads the whole table to answer a page.

db.exec(`
  CREATE TABLE IF NOT EXISTS forum_spaces (
    id TEXT PRIMARY KEY,
    slug TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    blurb TEXT NOT NULL DEFAULT '',
    icon TEXT NOT NULL DEFAULT 'comment',
    rules TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL DEFAULT 'talk',
    who TEXT NOT NULL DEFAULT 'members',
    position INTEGER NOT NULL DEFAULT 0,
    archived INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );

  -- status: live, held (waiting for a first-post check), removed (the team), deleted (its starter).
  -- next_seq numbers the posts; reply_count counts live replies only.
  CREATE TABLE IF NOT EXISTS forum_threads (
    id TEXT PRIMARY KEY,
    slug TEXT UNIQUE NOT NULL,
    space_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'live',
    pinned INTEGER NOT NULL DEFAULT 0,
    locked INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    last_post_at TEXT NOT NULL,
    last_user_id TEXT NOT NULL,
    next_seq INTEGER NOT NULL DEFAULT 2,
    reply_count INTEGER NOT NULL DEFAULT 0,
    like_total INTEGER NOT NULL DEFAULT 0,
    solved_post_id TEXT,
    label_kind TEXT NOT NULL DEFAULT '',
    label_value TEXT NOT NULL DEFAULT '',
    removed_by TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_forum_threads_space ON forum_threads (space_id, status, pinned DESC, last_post_at DESC);
  CREATE INDEX IF NOT EXISTS idx_forum_threads_active ON forum_threads (status, last_post_at DESC);
  CREATE INDEX IF NOT EXISTS idx_forum_threads_new ON forum_threads (status, created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_forum_threads_user ON forum_threads (user_id, created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_forum_threads_label ON forum_threads (label_kind, label_value, status, last_post_at DESC);
  -- Finds the thread a post was picked as best answer in (a member's "best answers" count) without reading every thread.
  CREATE INDEX IF NOT EXISTS idx_forum_threads_solved ON forum_threads (solved_post_id) WHERE solved_post_id IS NOT NULL;

  CREATE TABLE IF NOT EXISTS forum_posts (
    id TEXT PRIMARY KEY,
    thread_id TEXT NOT NULL,
    seq INTEGER NOT NULL,
    user_id TEXT NOT NULL,
    text TEXT NOT NULL,
    created_at TEXT NOT NULL,
    edited_at TEXT,
    edited_by TEXT,
    reply_to_id TEXT,
    status TEXT NOT NULL DEFAULT 'live',
    status_by TEXT,
    like_count INTEGER NOT NULL DEFAULT 0,
    UNIQUE (thread_id, seq)
  );
  -- Per-member questions name this index (INDEXED BY): with no statistics the database would otherwise start from "every live post".
  CREATE INDEX IF NOT EXISTS idx_forum_posts_user ON forum_posts (user_id, created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_forum_posts_status ON forum_posts (status, created_at DESC);

  CREATE TABLE IF NOT EXISTS forum_post_likes (
    user_id TEXT NOT NULL,
    post_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (user_id, post_id)
  );
  CREATE INDEX IF NOT EXISTS idx_forum_post_likes_post ON forum_post_likes (post_id);

  CREATE TABLE IF NOT EXISTS forum_post_reports (
    post_id TEXT NOT NULL,
    reporter_user_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (post_id, reporter_user_id)
  );

  -- A member follows a thread by posting in it (or the Follow button); last_seq
  -- is the last post number they have seen, which is how "new replies" is known.
  CREATE TABLE IF NOT EXISTS forum_thread_follows (
    user_id TEXT NOT NULL,
    thread_id TEXT NOT NULL,
    last_seq INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    PRIMARY KEY (user_id, thread_id)
  );
  CREATE INDEX IF NOT EXISTS idx_forum_thread_follows_thread ON forum_thread_follows (thread_id);

  CREATE TABLE IF NOT EXISTS forum_space_follows (
    user_id TEXT NOT NULL,
    space_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (user_id, space_id)
  );
  CREATE INDEX IF NOT EXISTS idx_forum_space_follows_space ON forum_space_follows (space_id);

  -- A helper saying "this report looks fine" hides that post from their own desk until
  -- it is reported again (sig is how many reports it had) or \`until\` passes.
  CREATE TABLE IF NOT EXISTS forum_desk_snoozes (
    user_id TEXT NOT NULL,
    post_id TEXT NOT NULL,
    sig INTEGER NOT NULL,
    until TEXT NOT NULL,
    PRIMARY KEY (user_id, post_id)
  );

  -- Kept out of the Community (not the whole site) until \`until\`.
  CREATE TABLE IF NOT EXISTS forum_mutes (
    user_id TEXT PRIMARY KEY,
    until TEXT NOT NULL,
    reason TEXT NOT NULL DEFAULT '',
    by_user_id TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
`);

const newId = () => crypto.randomUUID();
const now = () => new Date().toISOString();

// A change that has to happen all together or not at all.
function atomically<T>(work: () => T): T {
  db.exec("BEGIN IMMEDIATE");
  try {
    const result = work();
    db.exec("COMMIT");
    return result;
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}

// ---------------------------------------------------------------------------
// Settings (Admin → Community → Limits)
// ---------------------------------------------------------------------------

export type CommunitySettings = {
  on: boolean;
  newThreadsPerDay: number;
  threadsPerDay: number;
  newRepliesPerHour: number;
  repliesPerHour: number;
  holdFirstThreads: boolean;
  holdCount: number;
  autoHideReports: number;
  // Threads with no reply for this many days are closed to new replies (0: never).
  closeAfterDays: number;
  bannedWords: string;
};

const flag = (key: string, fallback: boolean) => {
  const raw = getSiteSetting(key);
  return raw === undefined ? fallback : raw === "1";
};
const whole = (key: string, fallback: number, min: number, max: number) => {
  const n = parseInt(getSiteSetting(key) ?? "", 10);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};

export function getCommunitySettings(): CommunitySettings {
  return {
    on: flag("community_on", true),
    newThreadsPerDay: whole("community_new_threads_per_day", 2, 1, 50),
    threadsPerDay: whole("community_threads_per_day", 10, 1, 200),
    newRepliesPerHour: whole("community_new_replies_per_hour", 8, 1, 200),
    repliesPerHour: whole("community_replies_per_hour", 30, 1, 500),
    holdFirstThreads: flag("community_hold_first", false),
    holdCount: whole("community_hold_count", 2, 1, 10),
    autoHideReports: whole("community_auto_hide_reports", 3, 2, 20),
    closeAfterDays: (() => {
      const n = whole("community_close_after_days", 0, 0, 730);
      return n === 0 ? 0 : Math.max(30, n);
    })(),
    bannedWords: getSiteSetting("community_banned_words") ?? "",
  };
}

export function saveCommunitySettings(s: CommunitySettings) {
  setSiteSetting("community_on", s.on ? "1" : "0");
  setSiteSetting("community_new_threads_per_day", String(s.newThreadsPerDay));
  setSiteSetting("community_threads_per_day", String(s.threadsPerDay));
  setSiteSetting("community_new_replies_per_hour", String(s.newRepliesPerHour));
  setSiteSetting("community_replies_per_hour", String(s.repliesPerHour));
  setSiteSetting("community_hold_first", s.holdFirstThreads ? "1" : "0");
  setSiteSetting("community_hold_count", String(s.holdCount));
  setSiteSetting("community_auto_hide_reports", String(s.autoHideReports));
  setSiteSetting("community_close_after_days", String(s.closeAfterDays));
  setSiteSetting("community_banned_words", s.bannedWords);
}

// The banned words as a list: one per line, lower case, no blanks.
export const bannedWordList = (raw: string) =>
  raw
    .split("\n")
    .map((w) => w.trim().toLowerCase())
    .filter(Boolean)
    .slice(0, 200);

// The first banned word a text contains (whole words only), or undefined.
export function bannedWordIn(text: string, words: string[]): string | undefined {
  if (!words.length) return undefined;
  const lower = text.toLowerCase();
  return words.find((w) => new RegExp(`(^|[^a-z0-9])${w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^a-z0-9]|$)`).test(lower));
}

// ---------------------------------------------------------------------------
// Spaces
// ---------------------------------------------------------------------------

export type SpaceRow = {
  id: string;
  slug: string;
  name: string;
  blurb: string;
  icon: IconName;
  rules: string;
  kind: SpaceKind;
  who: SpaceWho;
  position: number;
  archived: boolean;
};

const spaceFrom = (r: Record<string, unknown>): SpaceRow => ({
  id: r.id as string,
  slug: r.slug as string,
  name: r.name as string,
  blurb: r.blurb as string,
  icon: r.icon as IconName,
  rules: r.rules as string,
  kind: r.kind === "ask" ? "ask" : "talk",
  who: r.who === "staff" ? "staff" : "members",
  position: r.position as number,
  archived: !!r.archived,
});

// What a brand-new Community starts with: four spaces, each with its own
// purpose, so nobody has to wonder where a post goes. Fewer is better early on:
// every extra space splits a small crowd and leaves more of them looking empty.
// Topics (a store, a category, a tag) aren't spaces: a thread is tied to those
// instead, so it shows on that page too. Everything here can be changed in
// Admin → Community → Spaces.
const STARTER_SPACES: Omit<SpaceRow, "id" | "position" | "archived">[] = [
  { slug: "deal-talk", name: "Deals & vouchers talk", blurb: "Is it a good price? How was the delivery? Talk about deals, vouchers, stores and brands.", icon: "tag", rules: "Post the deal or voucher itself with + Post a deal. Use this space to talk about deals, codes and stores.", kind: "talk", who: "members" },
  { slug: "ask", name: "Ask the community", blurb: "Looking for something? Ask, and mark the answer that helped.", icon: "lightbulb", rules: "One question per thread. Say what you've tried and your budget.", kind: "ask", who: "members" },
  { slug: "money-saving-tips", name: "Money-saving tips", blurb: "Everyday ways to spend less: swaps, loyalty tricks, timing.", icon: "pound", rules: "Share tips you have tried yourself. No referral codes or affiliate links, please.", kind: "talk", who: "members" },
  { slug: "chat", name: "Chat and introductions", blurb: "New here? Say hello. Anything else on your mind goes here too.", icon: "hand-helping", rules: "Be kind to newcomers. No politics or religion debates, please.", kind: "talk", who: "members" },
];

function seedSpaces() {
  const have = (db.prepare("SELECT COUNT(*) AS c FROM forum_spaces").get() as { c: number }).c;
  if (have) return;
  const insert = db.prepare(
    "INSERT INTO forum_spaces (id, slug, name, blurb, icon, rules, kind, who, position, archived, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)"
  );
  const at = now();
  STARTER_SPACES.forEach((s, i) => insert.run(newId(), s.slug, s.name, s.blurb, s.icon, s.rules, s.kind, s.who, i + 1, at));
}
// Two copies of the site starting together take turns (see duringSetup).
duringSetup(seedSpaces);

export function listSpaces(includeArchived = false): SpaceRow[] {
  const rows = db
    .prepare(`SELECT * FROM forum_spaces ${includeArchived ? "" : "WHERE archived = 0"} ORDER BY position, name`)
    .all() as Record<string, unknown>[];
  return rows.map(spaceFrom);
}

export function getSpaceBySlug(slug: string): SpaceRow | undefined {
  const r = db.prepare("SELECT * FROM forum_spaces WHERE slug = ?").get(slug) as Record<string, unknown> | undefined;
  return r ? spaceFrom(r) : undefined;
}

export function getSpaceById(id: string): SpaceRow | undefined {
  const r = db.prepare("SELECT * FROM forum_spaces WHERE id = ?").get(id) as Record<string, unknown> | undefined;
  return r ? spaceFrom(r) : undefined;
}

export type SpaceStats = { threads: number; lastAt: string | null; lastTitle: string | null; lastSlug: string | null };

// Thread counts and the latest conversation of every space, in one pass. Kept
// for half a minute: the home page asks on every visit, and "12 threads, active
// 3 minutes ago" doesn't need to be fresher than that.
let spaceStatsKept: { at: number; value: Map<string, SpaceStats> } | undefined;

export function getSpaceStats(): Map<string, SpaceStats> {
  if (spaceStatsKept && Date.now() - spaceStatsKept.at < 30_000) return spaceStatsKept.value;
  const rows = db
    .prepare(
      `SELECT t.space_id, COUNT(*) AS threads, MAX(t.last_post_at) AS last_at
       FROM forum_threads t WHERE t.status = 'live' GROUP BY t.space_id`
    )
    .all() as { space_id: string; threads: number; last_at: string }[];
  const latest = db.prepare("SELECT title, slug FROM forum_threads WHERE space_id = ? AND status = 'live' ORDER BY last_post_at DESC LIMIT 1");
  const out = new Map<string, SpaceStats>();
  for (const r of rows) {
    const t = latest.get(r.space_id) as { title: string; slug: string } | undefined;
    out.set(r.space_id, { threads: r.threads, lastAt: r.last_at, lastTitle: t?.title ?? null, lastSlug: t?.slug ?? null });
  }
  spaceStatsKept = { at: Date.now(), value: out };
  return out;
}

// Forgets the kept space numbers (a test, or the team changing spaces).
export function forgetSpaceStats() {
  spaceStatsKept = undefined;
}

export function slugTakenBySpace(slug: string, exceptId?: string): boolean {
  return Boolean(db.prepare("SELECT 1 FROM forum_spaces WHERE slug = ? AND id != ?").get(slug, exceptId ?? ""));
}

export function saveSpace(input: Omit<SpaceRow, "id" | "position" | "archived"> & { id?: string }): string {
  if (input.id) {
    db.prepare("UPDATE forum_spaces SET slug = ?, name = ?, blurb = ?, icon = ?, rules = ?, kind = ?, who = ? WHERE id = ?").run(
      input.slug, input.name, input.blurb, input.icon, input.rules, input.kind, input.who, input.id
    );
    return input.id;
  }
  const id = newId();
  const last = (db.prepare("SELECT COALESCE(MAX(position), 0) AS p FROM forum_spaces").get() as { p: number }).p;
  db.prepare(
    "INSERT INTO forum_spaces (id, slug, name, blurb, icon, rules, kind, who, position, archived, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)"
  ).run(id, input.slug, input.name, input.blurb, input.icon, input.rules, input.kind, input.who, last + 1, now());
  return id;
}

export function setSpaceArchived(id: string, archived: boolean) {
  db.prepare("UPDATE forum_spaces SET archived = ? WHERE id = ?").run(archived ? 1 : 0, id);
}

// Moves a space one place up or down the list.
export function moveSpace(id: string, direction: "up" | "down") {
  const all = listSpaces(true);
  const i = all.findIndex((s) => s.id === id);
  const j = direction === "up" ? i - 1 : i + 1;
  if (i < 0 || j < 0 || j >= all.length) return;
  atomically(() => {
    const set = db.prepare("UPDATE forum_spaces SET position = ? WHERE id = ?");
    // Positions are rewritten 1..n so they never collide.
    const order = all.map((s) => s.id);
    [order[i], order[j]] = [order[j], order[i]];
    order.forEach((sid, k) => set.run(k + 1, sid));
  });
}

export function threadCountInSpace(spaceId: string): number {
  return (db.prepare("SELECT COUNT(*) AS c FROM forum_threads WHERE space_id = ?").get(spaceId) as { c: number }).c;
}

// ---------------------------------------------------------------------------
// Threads
// ---------------------------------------------------------------------------

export type ThreadStatus = "live" | "held" | "removed" | "deleted";
export type LabelKind = "store" | "category" | "tag";

export type ThreadRow = {
  id: string;
  slug: string;
  spaceId: string;
  spaceSlug: string;
  spaceName: string;
  spaceKind: SpaceKind;
  userId: string;
  username: string;
  avatarUrl: string | null;
  role: UserRole;
  title: string;
  status: ThreadStatus;
  pinned: boolean;
  locked: boolean;
  createdAt: string;
  lastPostAt: string;
  lastUsername: string;
  replyCount: number;
  likeTotal: number;
  solved: boolean;
  solvedPostId: string | null;
  labelKind: LabelKind | "";
  labelValue: string;
  // The latest post number, so a list can tell a follower there is something new.
  lastSeq: number;
};

const THREAD_SELECT = `
  SELECT t.*, s.slug AS space_slug, s.name AS space_name, s.kind AS space_kind,
         u.username, u.avatar_url, u.role, lu.username AS last_username
  FROM forum_threads t
  JOIN forum_spaces s ON s.id = t.space_id
  JOIN users u ON u.id = t.user_id
  JOIN users lu ON lu.id = t.last_user_id`;

const threadFrom = (r: Record<string, unknown>): ThreadRow => ({
  id: r.id as string,
  slug: r.slug as string,
  spaceId: r.space_id as string,
  spaceSlug: r.space_slug as string,
  spaceName: r.space_name as string,
  spaceKind: r.space_kind === "ask" ? "ask" : "talk",
  userId: r.user_id as string,
  username: r.username as string,
  avatarUrl: (r.avatar_url as string | null) ?? null,
  role: (r.role as UserRole) ?? "user",
  title: r.title as string,
  status: r.status as ThreadStatus,
  pinned: !!r.pinned,
  locked: !!r.locked,
  createdAt: r.created_at as string,
  lastPostAt: r.last_post_at as string,
  lastUsername: r.last_username as string,
  replyCount: r.reply_count as number,
  likeTotal: r.like_total as number,
  solved: !!r.solved_post_id,
  solvedPostId: (r.solved_post_id as string | null) ?? null,
  labelKind: (r.label_kind as LabelKind | "") ?? "",
  labelValue: (r.label_value as string) ?? "",
  lastSeq: (r.next_seq as number) - 1,
});

export function getThreadBySlug(slug: string): ThreadRow | undefined {
  const r = db.prepare(`${THREAD_SELECT} WHERE t.slug = ?`).get(slug) as Record<string, unknown> | undefined;
  return r ? threadFrom(r) : undefined;
}

export function getThreadById(id: string): ThreadRow | undefined {
  const r = db.prepare(`${THREAD_SELECT} WHERE t.id = ?`).get(id) as Record<string, unknown> | undefined;
  return r ? threadFrom(r) : undefined;
}

export type ThreadFilter = {
  spaceId?: string;
  userId?: string;
  label?: { kind: LabelKind; value: string };
  sort?: ThreadSort;
  page?: number;
  per?: number;
  // Within a space, pinned threads lead.
  pinnedFirst?: boolean;
  // Hide threads by these members (people the reader has blocked).
  exclude?: string[];
  // Words that every title must contain (a search).
  search?: string;
  // Only threads this member follows (they started it, replied in it, or tapped Follow).
  followedBy?: string;
};

const WEEK_MS = 7 * 24 * 60 * 60 * 1000;

export function listThreads(f: ThreadFilter): { rows: ThreadRow[]; total: number } {
  const per = f.per ?? THREADS_PER_PAGE;
  const page = Math.max(1, f.page ?? 1);
  const where: string[] = ["t.status = 'live'", "s.archived = 0"];
  const args: (string | number)[] = [];
  if (f.spaceId) {
    where.push("t.space_id = ?");
    args.push(f.spaceId);
  }
  if (f.userId) {
    where.push("t.user_id = ?");
    args.push(f.userId);
  }
  if (f.label) {
    where.push("t.label_kind = ? AND t.label_value = ?");
    args.push(f.label.kind, f.label.value);
  }
  if (f.exclude?.length) {
    where.push(`t.user_id NOT IN (${f.exclude.map(() => "?").join(",")})`);
    args.push(...f.exclude);
  }
  const sort = f.sort ?? "active";
  if (sort === "top") {
    where.push("t.last_post_at > ?");
    args.push(new Date(Date.now() - WEEK_MS).toISOString());
  }
  // "Unanswered": inside one questions space, a question with no best answer
  // picked (it may have replies); anywhere else, a thread with no reply yet.
  if (sort === "unanswered") {
    where.push(f.spaceId ? "(CASE WHEN s.kind = 'ask' THEN t.solved_post_id IS NULL ELSE t.reply_count = 0 END)" : "t.reply_count = 0");
  }
  if (f.followedBy) {
    where.push("t.id IN (SELECT thread_id FROM forum_thread_follows WHERE user_id = ?)");
    args.push(f.followedBy);
  }
  for (const word of f.search ? searchWords(f.search) : []) {
    where.push("t.title LIKE ? ESCAPE '\\'");
    args.push(likeContains(word));
  }

  const lead = f.pinnedFirst ? "t.pinned DESC, " : "";
  const order =
    sort === "new"
      ? "t.created_at DESC"
      : sort === "top"
        ? "(t.reply_count + t.like_total * 2) DESC, t.last_post_at DESC"
        : "t.last_post_at DESC";
  const clause = where.join(" AND ");
  const total = (
    db.prepare(`SELECT COUNT(*) AS c FROM forum_threads t JOIN forum_spaces s ON s.id = t.space_id WHERE ${clause}`).get(...args) as { c: number }
  ).c;
  const rows = db
    .prepare(`${THREAD_SELECT} WHERE ${clause} ORDER BY ${lead}${order}, t.rowid DESC LIMIT ? OFFSET ?`)
    .all(...args, per, (page - 1) * per) as Record<string, unknown>[];
  return { rows: rows.map(threadFrom), total };
}

// Threads waiting for a quick check (the "hold first posts" switch).
export function listHeldThreads(): ThreadRow[] {
  const rows = db.prepare(`${THREAD_SELECT} WHERE t.status = 'held' ORDER BY t.created_at`).all() as Record<string, unknown>[];
  return rows.map(threadFrom);
}

export function countThreadsByUserSince(userId: string, sinceIso: string): number {
  return (db.prepare("SELECT COUNT(*) AS c FROM forum_threads WHERE user_id = ? AND created_at > ?").get(userId, sinceIso) as { c: number }).c;
}

export function countPostsByUserSince(userId: string, sinceIso: string): number {
  return (db.prepare("SELECT COUNT(*) AS c FROM forum_posts WHERE user_id = ? AND created_at > ?").get(userId, sinceIso) as { c: number }).c;
}

// How many live threads this member has started, ever (for the "first posts" check).
export function countLiveThreadsByUser(userId: string): number {
  return (
    db.prepare("SELECT COUNT(*) AS c FROM forum_threads WHERE user_id = ? AND status IN ('live', 'held')").get(userId) as { c: number }
  ).c;
}

// The same words, posted again recently by this member (a double-click, or a
// paste of the same message): anything identical in their last day is refused.
export function hasRecentDuplicate(userId: string, text: string): boolean {
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  return Boolean(db.prepare("SELECT 1 FROM forum_posts WHERE user_id = ? AND created_at > ? AND text = ? LIMIT 1").get(userId, since, text));
}

export function createThread(input: {
  spaceId: string;
  userId: string;
  title: string;
  text: string;
  status?: "live" | "held";
  label?: { kind: LabelKind; value: string };
}): { threadId: string; postId: string; slug: string } {
  const threadId = newId();
  const postId = newId();
  const slug = threadSlug(input.title, threadId);
  const at = now();
  atomically(() => {
    db.prepare(
      `INSERT INTO forum_threads (id, slug, space_id, user_id, title, status, created_at, last_post_at, last_user_id, next_seq, reply_count, label_kind, label_value)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 2, 0, ?, ?)`
    ).run(threadId, slug, input.spaceId, input.userId, input.title, input.status ?? "live", at, at, input.userId, input.label?.kind ?? "", input.label?.value ?? "");
    db.prepare("INSERT INTO forum_posts (id, thread_id, seq, user_id, text, created_at) VALUES (?, ?, 1, ?, ?, ?)").run(postId, threadId, input.userId, input.text, at);
    db.prepare("INSERT OR IGNORE INTO forum_thread_follows (user_id, thread_id, last_seq, created_at) VALUES (?, ?, 1, ?)").run(input.userId, threadId, at);
  });
  return { threadId, postId, slug };
}

export function setThreadStatus(id: string, status: ThreadStatus, removedBy: string | null = null) {
  db.prepare("UPDATE forum_threads SET status = ?, removed_by = ? WHERE id = ?").run(status, status === "removed" ? removedBy : null, id);
}

// Threads the team has taken down, newest first (Admin → Community → Removed).
export function listRemovedThreads(limit = 50): ThreadRow[] {
  const rows = db.prepare(`${THREAD_SELECT} WHERE t.status = 'removed' ORDER BY t.last_post_at DESC LIMIT ?`).all(limit) as Record<string, unknown>[];
  return rows.map(threadFrom);
}

export function countRemovedThreads(): number {
  return (db.prepare("SELECT COUNT(*) AS c FROM forum_threads WHERE status = 'removed'").get() as { c: number }).c;
}

// Gone for good: the thread, every post in it, and everything hung on them
// (likes, reports, follows, and the notifications that linked to it). Callers
// decide who may; nothing here can be undone.
export function purgeThread(id: string) {
  const slug = (db.prepare("SELECT slug FROM forum_threads WHERE id = ?").get(id) as { slug: string } | undefined)?.slug;
  if (!slug) return;
  atomically(() => {
    const inThread = "SELECT id FROM forum_posts WHERE thread_id = ?";
    db.prepare(`DELETE FROM forum_post_likes WHERE post_id IN (${inThread})`).run(id);
    db.prepare(`DELETE FROM forum_post_reports WHERE post_id IN (${inThread})`).run(id);
    db.prepare("DELETE FROM forum_posts WHERE thread_id = ?").run(id);
    db.prepare("DELETE FROM forum_thread_follows WHERE thread_id = ?").run(id);
    db.prepare("DELETE FROM forum_threads WHERE id = ?").run(id);
    db.prepare("DELETE FROM notifications WHERE url LIKE ?").run(`/community/t/${slug}%`);
  });
}

// A writer deleting their own thread. Their words go at once. With no one
// else's posts in it there is nothing left to keep, so it goes completely;
// otherwise it stays hidden (moderators can see it) so other people's replies
// aren't silently lost. Returns which.
export function deleteOwnThread(id: string): "purged" | "hidden" {
  const others = (db.prepare("SELECT COUNT(*) AS c FROM forum_posts WHERE thread_id = ? AND seq > 1").get(id) as { c: number }).c;
  if (others === 0) {
    purgeThread(id);
    return "purged";
  }
  db.prepare("UPDATE forum_posts SET text = '[post deleted]', status = 'deleted' WHERE thread_id = ? AND seq = 1").run(id);
  setThreadStatus(id, "deleted");
  return "hidden";
}

// A writer deleting their own reply: it shows as "Deleted" and its words are wiped.
export function deleteOwnReply(postId: string, byUserId: string) {
  setPostStatus(postId, "deleted", byUserId);
  db.prepare("UPDATE forum_posts SET text = '[post deleted]' WHERE id = ?").run(postId);
}

// The welcome thread posted for a space from Admin → Community → Spaces (kept
// as a setting that names the thread). Only one that is still up counts, so a
// deleted or removed welcome can be written again.
export function getWelcomeThread(spaceId: string): ThreadRow | undefined {
  const id = getSiteSetting(`community_welcome_${spaceId}`);
  const thread = id ? getThreadById(id) : undefined;
  return thread && (thread.status === "live" || thread.status === "held") ? thread : undefined;
}

export function setWelcomeThread(spaceId: string, threadId: string) {
  setSiteSetting(`community_welcome_${spaceId}`, threadId);
}

export function setThreadPinned(id: string, pinned: boolean) {
  db.prepare("UPDATE forum_threads SET pinned = ? WHERE id = ?").run(pinned ? 1 : 0, id);
}

export function setThreadLocked(id: string, locked: boolean) {
  db.prepare("UPDATE forum_threads SET locked = ? WHERE id = ?").run(locked ? 1 : 0, id);
}

export function setThreadTitle(id: string, title: string) {
  db.prepare("UPDATE forum_threads SET title = ? WHERE id = ?").run(title, id);
}

export function moveThreadToSpace(id: string, spaceId: string) {
  db.prepare("UPDATE forum_threads SET space_id = ? WHERE id = ?").run(spaceId, id);
}

export function setThreadLabel(id: string, label: { kind: LabelKind; value: string } | null) {
  db.prepare("UPDATE forum_threads SET label_kind = ?, label_value = ? WHERE id = ?").run(label?.kind ?? "", label?.value ?? "", id);
}

export function setThreadSolved(id: string, postId: string | null) {
  db.prepare("UPDATE forum_threads SET solved_post_id = ? WHERE id = ?").run(postId, id);
}

// ---------------------------------------------------------------------------
// Posts
// ---------------------------------------------------------------------------

export type PostRow = {
  id: string;
  threadId: string;
  seq: number;
  userId: string;
  username: string;
  avatarUrl: string | null;
  role: UserRole;
  text: string;
  createdAt: string;
  edited: boolean;
  editedByTeam: boolean;
  status: PostStatus;
  likeCount: number;
  replyToId: string | null;
  replyToUsername: string | null;
  replyToSeq: number | null;
  replyToSnippet: string | null;
};

const POST_SELECT = `
  SELECT p.*, u.username, u.avatar_url, u.role,
         ru.username AS reply_username, rp.seq AS reply_seq,
         CASE WHEN rp.status = 'live' THEN substr(rp.text, 1, 160) ELSE NULL END AS reply_snippet
  FROM forum_posts p
  JOIN users u ON u.id = p.user_id
  LEFT JOIN forum_posts rp ON rp.id = p.reply_to_id
  LEFT JOIN users ru ON ru.id = rp.user_id`;

const postFrom = (r: Record<string, unknown>): PostRow => ({
  id: r.id as string,
  threadId: r.thread_id as string,
  seq: r.seq as number,
  userId: r.user_id as string,
  username: r.username as string,
  avatarUrl: (r.avatar_url as string | null) ?? null,
  role: (r.role as UserRole) ?? "user",
  // A post that isn't live never sends its words to a reader's page.
  text: r.status === "live" ? (r.text as string) : "",
  createdAt: r.created_at as string,
  edited: !!r.edited_at,
  editedByTeam: !!r.edited_at && !!r.edited_by && r.edited_by !== r.user_id,
  status: r.status as PostStatus,
  likeCount: r.like_count as number,
  replyToId: (r.reply_to_id as string | null) ?? null,
  replyToUsername: (r.reply_username as string | null) ?? null,
  replyToSeq: (r.reply_seq as number | null) ?? null,
  replyToSnippet: r.reply_snippet ? plainDescription(r.reply_snippet as string) : null,
});

// One page of a thread: posts numbered `from` to `to`, in order.
export function getPostsPage(threadId: string, page: number): PostRow[] {
  const from = (page - 1) * POSTS_PER_PAGE + 1;
  const rows = db
    .prepare(`${POST_SELECT} WHERE p.thread_id = ? AND p.seq BETWEEN ? AND ? ORDER BY p.seq`)
    .all(threadId, from, from + POSTS_PER_PAGE - 1) as Record<string, unknown>[];
  return rows.map(postFrom);
}

export function getPostById(id: string): PostRow | undefined {
  const r = db.prepare(`${POST_SELECT} WHERE p.id = ?`).get(id) as Record<string, unknown> | undefined;
  return r ? postFrom(r) : undefined;
}

// The words of a post, for the writer or staff to edit (never sent for a post
// that isn't live to anyone else: callers check who is asking).
export function getPostTextRaw(id: string): string | undefined {
  return (db.prepare("SELECT text FROM forum_posts WHERE id = ?").get(id) as { text: string } | undefined)?.text;
}

// A thread's opening post (its words included: only for pages that check who is reading).
export function getOpeningPost(threadId: string): { id: string; text: string } | undefined {
  return db.prepare("SELECT id, text FROM forum_posts WHERE thread_id = ? AND seq = 1").get(threadId) as { id: string; text: string } | undefined;
}

export function getPostSeqInThread(threadId: string, postId: string): number | undefined {
  return (db.prepare("SELECT seq FROM forum_posts WHERE id = ? AND thread_id = ?").get(postId, threadId) as { seq: number } | undefined)?.seq;
}

// How many posts a thread has numbered so far (including ones since removed).
export const postsInThread = (t: Pick<ThreadRow, "lastSeq">) => t.lastSeq;

export function addReply(input: {
  threadId: string;
  userId: string;
  text: string;
  replyToId?: string | null;
}): { postId: string; seq: number } | undefined {
  return atomically(() => {
    const t = db.prepare("SELECT status, locked, next_seq FROM forum_threads WHERE id = ?").get(input.threadId) as
      | { status: string; locked: number; next_seq: number }
      | undefined;
    if (!t || t.status !== "live") return undefined;
    let replyToId: string | null = null;
    if (input.replyToId) {
      const target = db.prepare("SELECT thread_id, status FROM forum_posts WHERE id = ?").get(input.replyToId) as
        | { thread_id: string; status: string }
        | undefined;
      if (target && target.thread_id === input.threadId && target.status === "live") replyToId = input.replyToId;
    }
    const postId = newId();
    const seq = t.next_seq;
    const at = now();
    db.prepare("INSERT INTO forum_posts (id, thread_id, seq, user_id, text, created_at, reply_to_id) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
      postId, input.threadId, seq, input.userId, input.text, at, replyToId
    );
    db.prepare("UPDATE forum_threads SET next_seq = next_seq + 1, reply_count = reply_count + 1, last_post_at = ?, last_user_id = ? WHERE id = ?").run(
      at, input.userId, input.threadId
    );
    // Posting in a thread follows it; the writer has seen everything up to their own post.
    db.prepare(
      `INSERT INTO forum_thread_follows (user_id, thread_id, last_seq, created_at) VALUES (?, ?, ?, ?)
       ON CONFLICT(user_id, thread_id) DO UPDATE SET last_seq = excluded.last_seq`
    ).run(input.userId, input.threadId, seq, at);
    return { postId, seq };
  });
}

export function editPostText(id: string, text: string, editedBy: string) {
  db.prepare("UPDATE forum_posts SET text = ?, edited_at = ?, edited_by = ? WHERE id = ? AND status = 'live'").run(text, now(), editedBy, id);
}

// Puts a thread's "last activity" back to its latest post that is still showing.
// Without it, a spam reply on an old thread that a helper then hides would keep
// the thread bumped to the top for nothing.
function refreshLastPost(threadId: string) {
  const last = db.prepare("SELECT created_at, user_id FROM forum_posts WHERE thread_id = ? AND status = 'live' ORDER BY seq DESC LIMIT 1").get(threadId) as
    | { created_at: string; user_id: string }
    | undefined;
  if (last) db.prepare("UPDATE forum_threads SET last_post_at = ?, last_user_id = ? WHERE id = ?").run(last.created_at, last.user_id, threadId);
}

// Changes a post's standing and keeps the thread's reply count right. A
// thread's opening post (number 1) isn't handled here: its thread's status is.
export function setPostStatus(id: string, status: PostStatus, by: string | null) {
  atomically(() => {
    const p = db.prepare("SELECT thread_id, seq, status FROM forum_posts WHERE id = ?").get(id) as
      | { thread_id: string; seq: number; status: string }
      | undefined;
    if (!p || p.status === status) return;
    db.prepare("UPDATE forum_posts SET status = ?, status_by = ? WHERE id = ?").run(status, status === "live" ? null : by, id);
    if (p.seq > 1) {
      const wasLive = p.status === "live";
      const isLive = status === "live";
      if (wasLive && !isLive) db.prepare("UPDATE forum_threads SET reply_count = MAX(0, reply_count - 1) WHERE id = ?").run(p.thread_id);
      if (!wasLive && isLive) db.prepare("UPDATE forum_threads SET reply_count = reply_count + 1 WHERE id = ?").run(p.thread_id);
    }
    if ((p.status === "live") !== (status === "live")) refreshLastPost(p.thread_id);
    if (status !== "live") {
      // The likes on it stop counting, and it can't stay the best answer.
      const likes = (db.prepare("SELECT like_count FROM forum_posts WHERE id = ?").get(id) as { like_count: number }).like_count;
      if (p.status === "live" && likes) db.prepare("UPDATE forum_threads SET like_total = MAX(0, like_total - ?) WHERE id = ?").run(likes, p.thread_id);
      db.prepare("UPDATE forum_threads SET solved_post_id = NULL WHERE id = ? AND solved_post_id = ?").run(p.thread_id, id);
      db.prepare("DELETE FROM forum_post_reports WHERE post_id = ?").run(id);
    } else if (p.status !== "live") {
      const likes = (db.prepare("SELECT like_count FROM forum_posts WHERE id = ?").get(id) as { like_count: number }).like_count;
      if (likes) db.prepare("UPDATE forum_threads SET like_total = like_total + ? WHERE id = ?").run(likes, p.thread_id);
    }
  });
}

// ---------------------------------------------------------------------------
// Likes, reports, following
// ---------------------------------------------------------------------------

export function togglePostLike(postId: string, userId: string): { liked: boolean; likeCount: number } | undefined {
  return atomically(() => {
    const p = db.prepare("SELECT thread_id, status, user_id FROM forum_posts WHERE id = ?").get(postId) as
      | { thread_id: string; status: string; user_id: string }
      | undefined;
    if (!p || p.status !== "live") return undefined;
    const had = db.prepare("SELECT 1 FROM forum_post_likes WHERE user_id = ? AND post_id = ?").get(userId, postId);
    const delta = had ? -1 : 1;
    if (had) db.prepare("DELETE FROM forum_post_likes WHERE user_id = ? AND post_id = ?").run(userId, postId);
    else db.prepare("INSERT INTO forum_post_likes (user_id, post_id, created_at) VALUES (?, ?, ?)").run(userId, postId, now());
    db.prepare("UPDATE forum_posts SET like_count = MAX(0, like_count + ?) WHERE id = ?").run(delta, postId);
    db.prepare("UPDATE forum_threads SET like_total = MAX(0, like_total + ?) WHERE id = ?").run(delta, p.thread_id);
    const likeCount = (db.prepare("SELECT like_count FROM forum_posts WHERE id = ?").get(postId) as { like_count: number }).like_count;
    return { liked: !had, likeCount };
  });
}

export function getLikedPostIds(userId: string, postIds: string[]): Set<string> {
  if (!postIds.length) return new Set();
  const rows = db
    .prepare(`SELECT post_id FROM forum_post_likes WHERE user_id = ? AND post_id IN (${postIds.map(() => "?").join(",")})`)
    .all(userId, ...postIds) as { post_id: string }[];
  return new Set(rows.map((r) => r.post_id));
}

export function reportPost(postId: string, reporterId: string) {
  db.prepare(
    `INSERT INTO forum_post_reports (post_id, reporter_user_id, created_at) VALUES (?, ?, ?)
     ON CONFLICT(post_id, reporter_user_id) DO UPDATE SET created_at = excluded.created_at`
  ).run(postId, reporterId, now());
}

export function withdrawPostReport(postId: string, reporterId: string) {
  db.prepare("DELETE FROM forum_post_reports WHERE post_id = ? AND reporter_user_id = ?").run(postId, reporterId);
}

export function getReportedPostIds(userId: string, postIds: string[]): Set<string> {
  if (!postIds.length) return new Set();
  const rows = db
    .prepare(`SELECT post_id FROM forum_post_reports WHERE reporter_user_id = ? AND post_id IN (${postIds.map(() => "?").join(",")})`)
    .all(userId, ...postIds) as { post_id: string }[];
  return new Set(rows.map((r) => r.post_id));
}

// Reports on a post from members who have been around a while (an account
// younger than `minAgeDays` can report, but doesn't count towards hiding a
// post, so a pile of new accounts can't silence someone).
export function trustedReportCount(postId: string, minAgeDays: number): number {
  const cutoff = new Date(Date.now() - minAgeDays * 24 * 60 * 60 * 1000).toISOString();
  return (
    db
      .prepare(
        `SELECT COUNT(*) AS c FROM forum_post_reports r JOIN users u ON u.id = r.reporter_user_id
         WHERE r.post_id = ? AND u.created_at < ? AND u.suspended = 0`
      )
      .get(postId, cutoff) as { c: number }
  ).c;
}

// How many reports each of these posts has (for the team reading a thread).
export function getReportCounts(postIds: string[]): Map<string, number> {
  if (!postIds.length) return new Map();
  const rows = db
    .prepare(`SELECT post_id, COUNT(*) AS c FROM forum_post_reports WHERE post_id IN (${postIds.map(() => "?").join(",")}) GROUP BY post_id`)
    .all(...postIds) as { post_id: string; c: number }[];
  return new Map(rows.map((r) => [r.post_id, r.c]));
}

export function clearPostReports(postId: string) {
  db.prepare("DELETE FROM forum_post_reports WHERE post_id = ?").run(postId);
}

export function followThread(userId: string, threadId: string, seenSeq: number) {
  db.prepare(
    `INSERT INTO forum_thread_follows (user_id, thread_id, last_seq, created_at) VALUES (?, ?, ?, ?)
     ON CONFLICT(user_id, thread_id) DO NOTHING`
  ).run(userId, threadId, seenSeq, now());
}

export function unfollowThread(userId: string, threadId: string) {
  db.prepare("DELETE FROM forum_thread_follows WHERE user_id = ? AND thread_id = ?").run(userId, threadId);
}

export function getThreadFollow(userId: string, threadId: string): { lastSeq: number } | undefined {
  const r = db.prepare("SELECT last_seq FROM forum_thread_follows WHERE user_id = ? AND thread_id = ?").get(userId, threadId) as { last_seq: number } | undefined;
  return r ? { lastSeq: r.last_seq } : undefined;
}

// Moves a follower's "seen up to" mark forward (never back).
export function markThreadSeen(userId: string, threadId: string, seq: number) {
  // Only when it moves forward: opening a thread already read changes nothing, so it writes nothing.
  db.prepare("UPDATE forum_thread_follows SET last_seq = ? WHERE user_id = ? AND thread_id = ? AND last_seq < ?").run(seq, userId, threadId, seq);
}

// Who follows a thread and has seen everything up to just before post `seq`
// (to tell them about it). Someone who hasn't caught up already has a
// notification waiting, so they aren't sent another.
export function getThreadFollowerIds(threadId: string, seq: number, limit = 500): string[] {
  return (
    db.prepare("SELECT user_id FROM forum_thread_follows WHERE thread_id = ? AND last_seq >= ? LIMIT ?").all(threadId, seq - 1, limit) as { user_id: string }[]
  ).map((r) => r.user_id);
}

// People who have posted in a thread (they can be @mentioned in it), starter first.
export function getThreadParticipants(threadId: string, limit = 200): { userId: string; username: string }[] {
  return (
    db
      .prepare(
        `SELECT DISTINCT p.user_id, u.username FROM forum_posts p JOIN users u ON u.id = p.user_id
         WHERE p.thread_id = ? AND p.status = 'live' ORDER BY p.seq LIMIT ?`
      )
      .all(threadId, limit) as { user_id: string; username: string }[]
  ).map((r) => ({ userId: r.user_id, username: r.username }));
}

// For a page of threads: which ones this member follows and has unread replies in.
export function getUnreadThreadIds(userId: string, threadIds: string[]): Set<string> {
  return new Set(getUnreadPositions(userId, threadIds).keys());
}

// For each of these threads the member follows and hasn't finished: the number
// of the last post they have seen, so a list can take them to the first new one.
export function getUnreadPositions(userId: string, threadIds: string[]): Map<string, number> {
  if (!threadIds.length) return new Map();
  const rows = db
    .prepare(
      `SELECT f.thread_id, f.last_seq FROM forum_thread_follows f JOIN forum_threads t ON t.id = f.thread_id
       WHERE f.user_id = ? AND f.thread_id IN (${threadIds.map(() => "?").join(",")}) AND t.next_seq - 1 > f.last_seq`
    )
    .all(userId, ...threadIds) as { thread_id: string; last_seq: number }[];
  return new Map(rows.map((r) => [r.thread_id, r.last_seq]));
}

// How many of the threads a member follows have replies they haven't read yet.
export function countUnreadFollowed(userId: string): number {
  return (
    db
      .prepare(
        `SELECT COUNT(*) AS c FROM forum_thread_follows f JOIN forum_threads t ON t.id = f.thread_id
         WHERE f.user_id = ? AND t.status = 'live' AND t.next_seq - 1 > f.last_seq`
      )
      .get(userId) as { c: number }
  ).c;
}

export type SimilarThread = { title: string; slug: string; replyCount: number; solved: boolean; spaceName: string };

// Live threads whose titles share the words of a title being typed, best match
// first: "already being discussed" hints for the new-thread form. A thread has to
// share at least two of the title's words (or the one it has, for a short title).
export function findSimilarThreads(title: string, limit = 3): SimilarThread[] {
  const words = significantWords(title);
  if (!words.length) return [];
  const matches = words.map(() => "(t.title LIKE ? ESCAPE '\\')");
  const needed = words.length >= 3 ? 2 : 1;
  const rows = db
    .prepare(
      `SELECT t.title, t.slug, t.reply_count, t.solved_post_id, s.name AS space_name, (${matches.join(" + ")}) AS score
       FROM forum_threads t JOIN forum_spaces s ON s.id = t.space_id
       WHERE t.status = 'live' AND s.archived = 0 AND (${matches.join(" + ")}) >= ?
       ORDER BY score DESC, t.last_post_at DESC LIMIT ?`
    )
    .all(...words.map(likeContains), ...words.map(likeContains), needed, limit) as Record<string, unknown>[];
  return rows.map((r) => ({
    title: r.title as string,
    slug: r.slug as string,
    replyCount: r.reply_count as number,
    solved: !!r.solved_post_id,
    spaceName: r.space_name as string,
  }));
}

export function followSpace(userId: string, spaceId: string) {
  db.prepare("INSERT OR IGNORE INTO forum_space_follows (user_id, space_id, created_at) VALUES (?, ?, ?)").run(userId, spaceId, now());
}

export function unfollowSpace(userId: string, spaceId: string) {
  db.prepare("DELETE FROM forum_space_follows WHERE user_id = ? AND space_id = ?").run(userId, spaceId);
}

export function followsSpace(userId: string, spaceId: string): boolean {
  return Boolean(db.prepare("SELECT 1 FROM forum_space_follows WHERE user_id = ? AND space_id = ?").get(userId, spaceId));
}

export function getFollowedSpaceIds(userId: string): Set<string> {
  return new Set((db.prepare("SELECT space_id FROM forum_space_follows WHERE user_id = ?").all(userId) as { space_id: string }[]).map((r) => r.space_id));
}

export function getSpaceFollowerIds(spaceId: string, limit = 500): string[] {
  return (db.prepare("SELECT user_id FROM forum_space_follows WHERE space_id = ? LIMIT ?").all(spaceId, limit) as { user_id: string }[]).map((r) => r.user_id);
}

// ---------------------------------------------------------------------------
// Muting from the Community
// ---------------------------------------------------------------------------

export type CommunityMute = { userId: string; until: string; reason: string };

export function getActiveMute(userId: string): CommunityMute | undefined {
  const r = db.prepare("SELECT * FROM forum_mutes WHERE user_id = ? AND until > ?").get(userId, now()) as
    | { user_id: string; until: string; reason: string }
    | undefined;
  return r ? { userId: r.user_id, until: r.until, reason: r.reason } : undefined;
}

export function muteMember(userId: string, untilIso: string, reason: string, byUserId: string) {
  db.prepare(
    `INSERT INTO forum_mutes (user_id, until, reason, by_user_id, created_at) VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET until = excluded.until, reason = excluded.reason, by_user_id = excluded.by_user_id, created_at = excluded.created_at`
  ).run(userId, untilIso, reason, byUserId, now());
}

export function unmuteMember(userId: string) {
  db.prepare("DELETE FROM forum_mutes WHERE user_id = ?").run(userId);
}

export function listMutes(): (CommunityMute & { username: string; by: string })[] {
  const rows = db
    .prepare(
      `SELECT m.user_id, m.until, m.reason, u.username, b.username AS by_name
       FROM forum_mutes m JOIN users u ON u.id = m.user_id JOIN users b ON b.id = m.by_user_id
       WHERE m.until > ? ORDER BY m.until`
    )
    .all(now()) as { user_id: string; until: string; reason: string; username: string; by_name: string }[];
  return rows.map((r) => ({ userId: r.user_id, until: r.until, reason: r.reason, username: r.username, by: r.by_name }));
}

// ---------------------------------------------------------------------------
// The moderation queue and the overview (Admin → Community)
// ---------------------------------------------------------------------------

export type QueuePost = {
  postId: string;
  threadSlug: string;
  threadTitle: string;
  seq: number;
  userId: string;
  username: string;
  role: UserRole;
  text: string;
  status: PostStatus;
  reports: number;
  createdAt: string;
};

// Posts that need a person: reported ones still showing, and ones a helper
// hid. The text is included here (staff read it to decide).
// The posts that need a moderator: hidden ones, and any that someone has
// reported. Found from those two short lists (the hidden ones by their index,
// the reports by their own small table), never by walking every post, because the
// admin menu counts them on every page it draws.
const NEEDS_A_LOOK = "(SELECT id FROM forum_posts WHERE status = 'hidden' UNION SELECT post_id FROM forum_post_reports)";
// (…and the query starts from that list and keeps that order (CROSS JOIN), with a "+" on p.status: left to itself, with no statistics, the database walks every thread or every live post instead.)

export function getModerationQueue(): QueuePost[] {
  const rows = db
    .prepare(
      `SELECT p.id, p.seq, p.user_id, p.text, p.status, p.created_at, t.slug AS thread_slug, t.title AS thread_title,
              u.username, u.role,
              (SELECT COUNT(*) FROM forum_post_reports r WHERE r.post_id = p.id) AS reports
       FROM ${NEEDS_A_LOOK} c CROSS JOIN forum_posts p ON p.id = c.id CROSS JOIN forum_threads t ON t.id = p.thread_id CROSS JOIN users u ON u.id = p.user_id
       WHERE t.status IN ('live', 'held') AND +p.status IN ('live', 'hidden')
       ORDER BY (p.status = 'hidden') DESC, reports DESC, p.created_at DESC LIMIT 100`
    )
    .all() as Record<string, unknown>[];
  return rows.map((r) => ({
    postId: r.id as string,
    threadSlug: r.thread_slug as string,
    threadTitle: r.thread_title as string,
    seq: r.seq as number,
    userId: r.user_id as string,
    username: r.username as string,
    role: (r.role as UserRole) ?? "user",
    text: plainDescription(r.text as string),
    status: r.status as PostStatus,
    reports: r.reports as number,
    createdAt: r.created_at as string,
  }));
}

export function countModerationQueue(): number {
  return (
    db
      .prepare(
        `SELECT COUNT(*) AS c FROM ${NEEDS_A_LOOK} c CROSS JOIN forum_posts p ON p.id = c.id CROSS JOIN forum_threads t ON t.id = p.thread_id
         WHERE t.status IN ('live', 'held') AND +p.status IN ('live', 'hidden')`
      )
      .get() as { c: number }
  ).c;
}

export function countHeldThreads(): number {
  return (db.prepare("SELECT COUNT(*) AS c FROM forum_threads WHERE status = 'held'").get() as { c: number }).c;
}

// ---------------------------------------------------------------------------
// The helper desk (Community side)
// ---------------------------------------------------------------------------

export type ReportedPost = {
  postId: string;
  seq: number;
  threadSlug: string;
  threadTitle: string;
  spaceName: string;
  userId: string;
  username: string;
  role: UserRole;
  snippet: string;
  createdAt: string;
  reports: number;
};

// Live posts that members have reported, most reported first. Found from the
// (small) reports table, so it never walks the posts.
export function getReportedLivePosts(limit = 60): ReportedPost[] {
  const rows = db
    .prepare(
      `SELECT p.id, p.seq, p.user_id, substr(p.text, 1, 240) AS snippet, p.created_at, c.reports,
              t.slug AS thread_slug, t.title AS thread_title, s.name AS space_name, u.username, u.role
       FROM (SELECT post_id AS id, COUNT(*) AS reports FROM forum_post_reports GROUP BY post_id) c
       CROSS JOIN forum_posts p ON p.id = c.id
       CROSS JOIN forum_threads t ON t.id = p.thread_id
       CROSS JOIN forum_spaces s ON s.id = t.space_id
       CROSS JOIN users u ON u.id = p.user_id
       WHERE +p.status = 'live' AND t.status IN ('live', 'held')
       ORDER BY c.reports DESC, p.created_at DESC LIMIT ?`
    )
    .all(limit) as Record<string, unknown>[];
  return rows.map((r) => ({
    postId: r.id as string,
    seq: r.seq as number,
    threadSlug: r.thread_slug as string,
    threadTitle: r.thread_title as string,
    spaceName: r.space_name as string,
    userId: r.user_id as string,
    username: r.username as string,
    role: (r.role as UserRole) ?? "user",
    snippet: plainDescription(r.snippet as string),
    createdAt: r.created_at as string,
    reports: r.reports as number,
  }));
}

export type WaitingThread = { slug: string; title: string; spaceName: string; username: string; snippet: string; createdAt: string };

// Live threads from the last two weeks that nobody has replied to yet (not the
// helper's own), newest first: where a friendly reply counts most.
export function getThreadsWaitingForReply(exceptUserId: string, limit = 20): WaitingThread[] {
  const since = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString();
  const rows = db
    .prepare(
      `SELECT t.slug, t.title, t.created_at, s.name AS space_name, u.username,
              (SELECT CASE WHEN p.status = 'live' THEN substr(p.text, 1, 200) ELSE '' END FROM forum_posts p WHERE p.thread_id = t.id AND p.seq = 1) AS snippet
       FROM forum_threads t
       CROSS JOIN forum_spaces s ON s.id = t.space_id
       CROSS JOIN users u ON u.id = t.user_id
       WHERE t.status = 'live' AND t.reply_count = 0 AND t.user_id != ? AND s.archived = 0 AND t.created_at > ?
       ORDER BY t.created_at DESC LIMIT ?`
    )
    .all(exceptUserId, since, limit) as Record<string, unknown>[];
  return rows.map((r) => ({
    slug: r.slug as string,
    title: r.title as string,
    spaceName: r.space_name as string,
    username: r.username as string,
    snippet: plainDescription((r.snippet as string) ?? ""),
    createdAt: r.created_at as string,
  }));
}

export function getPostSnoozes(userId: string): Map<string, number> {
  const rows = db.prepare("SELECT post_id, sig FROM forum_desk_snoozes WHERE user_id = ? AND until > ?").all(userId, now()) as { post_id: string; sig: number }[];
  return new Map(rows.map((r) => [r.post_id, r.sig]));
}

export function snoozePost(userId: string, postId: string, sig: number, until: string) {
  db.prepare(
    `INSERT INTO forum_desk_snoozes (user_id, post_id, sig, until) VALUES (?, ?, ?, ?)
     ON CONFLICT(user_id, post_id) DO UPDATE SET sig = excluded.sig, until = excluded.until`
  ).run(userId, postId, sig, until);
}

export type CommunityOverview = {
  threadsWeek: number;
  repliesWeek: number;
  membersPostingWeek: number;
  threadsTotal: number;
  postsTotal: number;
  noReplyYet: number;
  waiting: number;
  held: number;
};

export function getCommunityOverview(): CommunityOverview {
  const week = new Date(Date.now() - WEEK_MS).toISOString();
  const one = (sql: string, ...a: string[]) => (db.prepare(sql).get(...a) as { c: number }).c;
  return {
    threadsWeek: one("SELECT COUNT(*) AS c FROM forum_threads WHERE status = 'live' AND created_at > ?", week),
    repliesWeek: one("SELECT COUNT(*) AS c FROM forum_posts WHERE seq > 1 AND status = 'live' AND created_at > ?", week),
    membersPostingWeek: one("SELECT COUNT(DISTINCT user_id) AS c FROM forum_posts WHERE status = 'live' AND created_at > ?", week),
    threadsTotal: one("SELECT COUNT(*) AS c FROM forum_threads WHERE status = 'live'"),
    postsTotal: one("SELECT COUNT(*) AS c FROM forum_posts WHERE status = 'live'"),
    noReplyYet: one("SELECT COUNT(*) AS c FROM forum_threads WHERE status = 'live' AND reply_count = 0 AND created_at > ?", week),
    waiting: countModerationQueue(),
    held: countHeldThreads(),
  };
}

// Threads with no reply a day on: where a helper's welcome counts most.
export function listUnansweredOlderThan(hours: number, limit = 20): ThreadRow[] {
  const cutoff = new Date(Date.now() - hours * 60 * 60 * 1000).toISOString();
  const rows = db
    .prepare(`${THREAD_SELECT} WHERE t.status = 'live' AND t.reply_count = 0 AND t.created_at < ? ORDER BY t.created_at DESC LIMIT ?`)
    .all(cutoff, limit) as Record<string, unknown>[];
  return rows.map(threadFrom);
}

// ---------------------------------------------------------------------------
// Profiles, badges, sitemap
// ---------------------------------------------------------------------------

export type MemberPost = {
  postId: string;
  seq: number;
  threadSlug: string;
  threadTitle: string;
  spaceName: string;
  text: string;
  createdAt: string;
  likeCount: number;
};

// A member's Community posts, newest first (a page of them; a negative limit means all of them).
export function getPostsByMember(userId: string, limit: number, offset = 0): MemberPost[] {
  const rows = db
    .prepare(
      `SELECT p.id, p.seq, p.text, p.created_at, p.like_count, t.slug AS thread_slug, t.title AS thread_title, s.name AS space_name
       FROM forum_posts p INDEXED BY idx_forum_posts_user JOIN forum_threads t ON t.id = p.thread_id JOIN forum_spaces s ON s.id = t.space_id
       WHERE p.user_id = ? AND p.status = 'live' AND t.status = 'live'
       ORDER BY p.created_at DESC LIMIT ? OFFSET ?`
    )
    .all(userId, limit, offset) as Record<string, unknown>[];
  return rows.map((r) => ({
    postId: r.id as string,
    seq: r.seq as number,
    threadSlug: r.thread_slug as string,
    threadTitle: r.thread_title as string,
    spaceName: r.space_name as string,
    text: plainDescription(r.text as string),
    createdAt: r.created_at as string,
    likeCount: r.like_count as number,
  }));
}

export type CommunityStats = {
  threadsStarted: number;
  replies: number;
  bestAnswers: number;
  likesReceived: number;
  welcomes: number;
};

export function getCommunityStats(userId: string): CommunityStats {
  const one = (sql: string) => (db.prepare(sql).get(userId) as { c: number | null }).c ?? 0;
  return {
    threadsStarted: one("SELECT COUNT(*) AS c FROM forum_threads WHERE user_id = ? AND status = 'live'"),
    replies: one("SELECT COUNT(*) AS c FROM forum_posts p INDEXED BY idx_forum_posts_user JOIN forum_threads t ON t.id = p.thread_id WHERE p.user_id = ? AND p.seq > 1 AND p.status = 'live' AND t.status = 'live'"),
    bestAnswers: one(
      `SELECT COUNT(*) AS c FROM forum_posts p INDEXED BY idx_forum_posts_user JOIN forum_threads t ON t.solved_post_id = p.id
       WHERE p.user_id = ? AND p.status = 'live' AND t.status = 'live' AND t.user_id != p.user_id`
    ),
    likesReceived: one("SELECT COALESCE(SUM(like_count), 0) AS c FROM forum_posts INDEXED BY idx_forum_posts_user WHERE user_id = ? AND status = 'live'"),
    // Replies someone gave to a member's very first thread.
    welcomes: one(
      `SELECT COUNT(*) AS c FROM forum_posts p INDEXED BY idx_forum_posts_user JOIN forum_threads t ON t.id = p.thread_id
       WHERE p.user_id = ? AND p.seq = 2 AND p.status = 'live' AND t.status = 'live' AND t.user_id != p.user_id
         AND t.id = (SELECT id FROM forum_threads f WHERE f.user_id = t.user_id AND f.status = 'live' ORDER BY f.created_at LIMIT 1)`
    ),
  };
}

export function getRecentThreadsForSitemap(limit = 5000): { slug: string; lastPostAt: string }[] {
  const rows = db
    .prepare(
      `SELECT t.slug, t.last_post_at FROM forum_threads t JOIN forum_spaces s ON s.id = t.space_id
       WHERE t.status = 'live' AND s.archived = 0 ORDER BY t.last_post_at DESC LIMIT ?`
    )
    .all(limit) as { slug: string; last_post_at: string }[];
  return rows.map((r) => ({ slug: r.slug, lastPostAt: r.last_post_at }));
}

export function getAuthorOfPost(postId: string): { userId: string; username: string } | undefined {
  const r = db.prepare("SELECT p.user_id, u.username FROM forum_posts p JOIN users u ON u.id = p.user_id WHERE p.id = ?").get(postId) as
    | { user_id: string; username: string }
    | undefined;
  return r ? { userId: r.user_id, username: r.username } : undefined;
}

// The most helpful reply of a thread: the live reply with the most likes, if
// it has enough.
export function getMostHelpfulPost(threadId: string, minLikes: number): { id: string; seq: number; likeCount: number } | undefined {
  const r = db
    .prepare("SELECT id, seq, like_count FROM forum_posts WHERE thread_id = ? AND seq > 1 AND status = 'live' AND like_count >= ? ORDER BY like_count DESC, seq LIMIT 1")
    .get(threadId, minLikes) as { id: string; seq: number; like_count: number } | undefined;
  return r ? { id: r.id, seq: r.seq, likeCount: r.like_count } : undefined;
}

export function getPostSummary(postId: string): { id: string; seq: number; username: string; text: string; likeCount: number } | undefined {
  const r = db
    .prepare("SELECT p.id, p.seq, p.text, p.like_count, u.username FROM forum_posts p JOIN users u ON u.id = p.user_id WHERE p.id = ? AND p.status = 'live'")
    .get(postId) as { id: string; seq: number; text: string; like_count: number; username: string } | undefined;
  return r ? { id: r.id, seq: r.seq, username: r.username, text: plainDescription(r.text), likeCount: r.like_count } : undefined;
}

// ---------------------------------------------------------------------------
// A member's own data: the download from their settings, and deleting the account
// ---------------------------------------------------------------------------

// Everything the Community holds about one member, for "Download my data".
export function exportCommunityData(userId: string) {
  const all = (sql: string) => db.prepare(sql).all(userId) as Record<string, unknown>[];
  return {
    threads: all("SELECT t.slug, t.title, t.created_at, t.status, s.name AS space FROM forum_threads t JOIN forum_spaces s ON s.id = t.space_id WHERE t.user_id = ?"),
    posts: all("SELECT p.id, t.slug AS thread, p.seq, p.text, p.created_at, p.edited_at, p.status FROM forum_posts p JOIN forum_threads t ON t.id = p.thread_id WHERE p.user_id = ?"),
    likes: all("SELECT post_id, created_at FROM forum_post_likes WHERE user_id = ?"),
    reports: all("SELECT post_id, created_at FROM forum_post_reports WHERE reporter_user_id = ?"),
    followedThreads: all("SELECT thread_id, created_at FROM forum_thread_follows WHERE user_id = ?"),
    followedSpaces: all("SELECT space_id, created_at FROM forum_space_follows WHERE user_id = ?"),
  };
}

// Deleting an account: their posts and threads go (the words are wiped and
// they show as "Deleted", so replies by other people still make sense), and
// their likes, reports, follows and any mute are removed. Counters stay right.
export function eraseCommunityMember(userId: string) {
  atomically(() => {
    db.prepare("UPDATE forum_threads SET status = 'deleted' WHERE user_id = ?").run(userId);
    const posts = db.prepare("SELECT id FROM forum_posts INDEXED BY idx_forum_posts_user WHERE user_id = ? AND status = 'live'").all(userId) as { id: string }[];
    for (const p of posts) {
      const row = db.prepare("SELECT thread_id, seq, like_count FROM forum_posts WHERE id = ?").get(p.id) as { thread_id: string; seq: number; like_count: number };
      db.prepare("UPDATE forum_posts SET status = 'deleted', status_by = ? WHERE id = ?").run(userId, p.id);
      if (row.seq > 1) db.prepare("UPDATE forum_threads SET reply_count = MAX(0, reply_count - 1) WHERE id = ?").run(row.thread_id);
      if (row.like_count) db.prepare("UPDATE forum_threads SET like_total = MAX(0, like_total - ?) WHERE id = ?").run(row.like_count, row.thread_id);
      db.prepare("UPDATE forum_threads SET solved_post_id = NULL WHERE id = ? AND solved_post_id = ?").run(row.thread_id, p.id);
    }
    db.prepare("UPDATE forum_posts SET text = '[post deleted]' WHERE user_id = ?").run(userId);
    for (const t of new Set(posts.map((p) => (db.prepare("SELECT thread_id FROM forum_posts WHERE id = ?").get(p.id) as { thread_id: string }).thread_id))) refreshLastPost(t);
    // Likes they gave to other people's posts stop counting.
    const liked = db
      .prepare("SELECT l.post_id, p.thread_id FROM forum_post_likes l JOIN forum_posts p ON p.id = l.post_id WHERE l.user_id = ? AND p.status = 'live'")
      .all(userId) as { post_id: string; thread_id: string }[];
    for (const l of liked) {
      db.prepare("UPDATE forum_posts SET like_count = MAX(0, like_count - 1) WHERE id = ?").run(l.post_id);
      db.prepare("UPDATE forum_threads SET like_total = MAX(0, like_total - 1) WHERE id = ?").run(l.thread_id);
    }
    for (const sql of [
      "DELETE FROM forum_post_likes WHERE user_id = ?",
      "DELETE FROM forum_post_reports WHERE reporter_user_id = ?",
      "DELETE FROM forum_thread_follows WHERE user_id = ?",
      "DELETE FROM forum_space_follows WHERE user_id = ?",
      "DELETE FROM forum_mutes WHERE user_id = ?",
      "DELETE FROM forum_desk_snoozes WHERE user_id = ?",
    ]) {
      db.prepare(sql).run(userId);
    }
  });
}
