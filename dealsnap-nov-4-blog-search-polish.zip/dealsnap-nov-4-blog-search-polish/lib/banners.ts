import type { BannerRow } from "./db";

export type BannerState = "off" | "scheduled" | "live" | "ended";

// Where a banner stands on a day (YYYY-MM-DD): switched off, waiting for its
// start date, showing on the site, or past its end date.
export function bannerState(b: Pick<BannerRow, "live" | "showFrom" | "showUntil">, today: string): BannerState {
  if (!b.live) return "off";
  if (b.showFrom && today < b.showFrom) return "scheduled";
  if (b.showUntil && today > b.showUntil) return "ended";
  return "live";
}

// The colours a new top-strip message starts with.
// Closing the banner is remembered in this cookie (the banner's stamp), so
// the page is drawn without it rather than drawn with it and then hidden.
export const BANNER_CLOSED_COOKIE = "ds_banner_closed";

export const DEFAULT_BANNER_BG = "#c2410c";
export const DEFAULT_BANNER_FG = "#ffffff";

export const isHexColour = (v: string) => /^#[0-9a-f]{6}$/i.test(v);

function luminance(hex: string): number {
  const [r, g, b] = [1, 3, 5].map((i) => {
    const c = parseInt(hex.slice(i, i + 2), 16) / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

// How easy text is to read on a colour (1 to 21; 4.5 and up is comfortable).
export function contrastRatio(a: string, b: string): number {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}

export const MIN_READABLE = 4.5;
