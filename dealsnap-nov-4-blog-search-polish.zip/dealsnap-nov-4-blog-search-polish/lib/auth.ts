import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { getUserBySession, sessionSecondsLeft, type UserRecord } from "./db";
import { can, isStaffRole, type Permission } from "./permissions";
import { missingTwoStep } from "./staff-two-step";

const SESSION_COOKIE = "dealsnap_session";

export async function getCurrentUser(): Promise<UserRecord | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return getUserBySession(token);
}

// Defense in depth alongside proxy.ts, which is the primary gate for
// /admin/* routes and admin Server Actions — see the note on Server
// Functions in node_modules/next/dist/docs/.../file-conventions/proxy.md.
// Anyone on the admin side (admin or moderator), as long as they aren't suspended.
export async function requireStaff(): Promise<UserRecord> {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin");
  if (!isStaffRole(user.role) || user.suspended) redirect("/");
  // Admins can insist that every staff account uses two-step login.
  if (missingTwoStep(user)) {
    redirect(
      `/settings?s=security&error=${encodeURIComponent("Turn on two-step login to use the admin area.")}`
    );
  }
  return user;
}

// Staff who hold a specific permission. Staff without it are sent to the
// dashboard rather than the public site, since they are allowed in /admin.
export async function requirePermission(permission: Permission): Promise<UserRecord> {
  const user = await requireStaff();
  if (!can(user.role, permission)) redirect("/admin");
  return user;
}

export async function setSessionCookie(token: string) {
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    // Only sent over HTTPS on the live site (plain http://localhost still works in dev).
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    // As long as the site will honour it (a week for staff, a month otherwise).
    maxAge: sessionSecondsLeft(token) ?? 30 * 24 * 60 * 60,
  });
}

export async function clearSessionCookie() {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE);
}

export async function getSessionToken(): Promise<string | undefined> {
  const cookieStore = await cookies();
  return cookieStore.get(SESSION_COOKIE)?.value;
}
