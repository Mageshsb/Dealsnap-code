import { addAutofillReport, getAutofillReportsSince } from "./db";

// How well autofill does, shop by shop (Admin → Insights). The post form
// sends, with each deal posted from a link, how the link was read and, for
// each box autofill fills, whether the poster kept what it put there,
// changed it, added it themselves or left it empty. A shop whose details
// keep being changed, or keep having to be added, is the one to fix next.

export const REPORTED_FIELDS = ["title", "price", "originalPrice", "store", "category"] as const;
export type ReportedField = (typeof REPORTED_FIELDS)[number];
const OUTCOMES = ["kept", "changed", "added", "empty"] as const;
type Outcome = (typeof OUTCOMES)[number];
// page: we read the shop's page; link: it turned us away, so only the link
// was read; extension: the shopper's browser read it; list: the store's
// product list (from Awin) filled it in.
const VIAS = ["page", "link", "extension", "list"] as const;

export const FIELD_LABELS: Record<ReportedField, string> = {
  title: "title",
  price: "price",
  originalPrice: "was price",
  store: "store",
  category: "category",
};

// What the form sent, checked, then kept against the deal.
export function recordAutofillReport(dealSlug: string, dealUrl: string, sent: string) {
  if (!sent) return;
  let host: string;
  let report: { via?: unknown; fields?: Record<string, unknown> };
  try {
    host = new URL(dealUrl).hostname.replace(/^(www|m)\./, "").toLowerCase();
    report = JSON.parse(sent);
  } catch {
    return;
  }
  const via = VIAS.find((v) => v === report.via);
  if (!via || !report.fields) return;
  const fields: Partial<Record<ReportedField, Outcome>> = {};
  for (const name of REPORTED_FIELDS) {
    const outcome = OUTCOMES.find((o) => o === report.fields![name]);
    if (outcome) fields[name] = outcome;
  }
  addAutofillReport(dealSlug, host, via, fields);
}

export type ShopAutofill = {
  host: string;
  posts: number;
  // Posted with everything autofill filled in left as it was.
  allKept: number;
  // How often the page couldn't be read, and only the link was.
  linkOnly: number;
  // How often the store's product list filled it in instead (lib/awin.ts).
  fromList: number;
  // The boxes posters most often had to fix or fill in, most first.
  fixes: { field: ReportedField; times: number }[];
};

export function autofillByShop(sinceMs: number): ShopAutofill[] {
  const shops = new Map<string, ShopAutofill & { counts: Map<ReportedField, number> }>();
  for (const r of getAutofillReportsSince(new Date(sinceMs).toISOString())) {
    const shop = shops.get(r.host) ?? { host: r.host, posts: 0, allKept: 0, linkOnly: 0, fromList: 0, fixes: [], counts: new Map() };
    shop.posts++;
    if (r.via === "link") shop.linkOnly++;
    if (r.via === "list") shop.fromList++;
    let fixed = false;
    for (const name of REPORTED_FIELDS) {
      if (r.fields[name] === "changed" || r.fields[name] === "added") {
        fixed = true;
        shop.counts.set(name, (shop.counts.get(name) ?? 0) + 1);
      }
    }
    if (!fixed) shop.allKept++;
    shops.set(r.host, shop);
  }
  return [...shops.values()]
    .map(({ counts, ...shop }) => ({
      ...shop,
      fixes: [...counts.entries()].map(([field, times]) => ({ field, times })).sort((a, b) => b.times - a.times),
    }))
    // The shops that need the most fixing first: most fixed posts.
    .sort((a, b) => b.posts - b.allKept - (a.posts - a.allKept) || b.posts - a.posts);
}
