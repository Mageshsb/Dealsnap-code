// The starter brand list. Each brand is added to the database once (see
// lib/db.ts) and from then on is looked after in Admin → Tags and brands, so
// editing a brand here only changes sites that haven't got it yet.
//
// words: other ways titles spell the brand (its own name always counts).
// Only add a word that never means anything else.
// categories: where the brand can be detected. Leave it out for brands that
// make all sorts; set it when the name is also an everyday word ("Apple",
// "Shark", "Dove") so "apple cider vinegar" can't become an Apple deal.
// website: where the brand's logo is fetched from (Admin → Tags and brands).

export type BrandDefault = { name: string; words?: string[]; categories?: string[]; website?: string };

const ELECTRONICS = "Electronics & Computers";
const GAMING = "Gaming & Entertainment";
const CLOTHING = "Clothing & Accessories";
const BEAUTY = "Health & Beauty";
const HOME = "Home & Living";
const FOOD = "Food, Groceries & Gifting";

export const BRAND_DEFAULTS: BrandDefault[] = [
  // Phones, computers and gadgets
  { name: "Apple", categories: [ELECTRONICS, GAMING], website: "apple.com" },
  { name: "Samsung", website: "samsung.com" },
  { name: "Sony", words: ["bravia"], website: "sony.co.uk" },
  { name: "Microsoft", website: "microsoft.com" },
  { name: "Nintendo", categories: [GAMING, ELECTRONICS], website: "nintendo.com" },
  { name: "Google", words: ["google pixel", "google nest", "chromecast"], categories: [ELECTRONICS], website: "google.com" },
  { name: "Amazon", words: ["echo dot", "echo show", "echo pop", "kindle", "fire tv", "fire stick", "fire hd"], categories: [ELECTRONICS, GAMING], website: "amazon.co.uk" },
  { name: "LG", categories: [ELECTRONICS, HOME], website: "lg.com" },
  { name: "Panasonic", website: "panasonic.com" },
  { name: "Philips", words: ["philips hue"], website: "philips.co.uk" },
  { name: "Bose", website: "bose.co.uk" },
  { name: "JBL", website: "jbl.com" },
  { name: "Sonos", website: "sonos.com" },
  { name: "Beats", words: ["beats by dre"], categories: [ELECTRONICS], website: "beatsbydre.com" },
  { name: "Lenovo", words: ["thinkpad", "ideapad", "legion"], website: "lenovo.com" },
  { name: "HP", categories: [ELECTRONICS], website: "hp.com" },
  { name: "Dell", words: ["alienware"], website: "dell.com" },
  { name: "Asus", words: ["rog ally", "zenbook", "vivobook"], website: "asus.com" },
  { name: "Acer", words: ["predator helios"], website: "acer.com" },
  { name: "Logitech", website: "logitech.com" },
  { name: "Anker", website: "anker.com" },
  { name: "Garmin", website: "garmin.com" },
  { name: "Fitbit", website: "fitbit.com" },
  { name: "GoPro", website: "gopro.com" },
  { name: "Canon", categories: [ELECTRONICS], website: "canon.co.uk" },
  { name: "Nikon", website: "nikon.co.uk" },
  { name: "Hisense", website: "hisense.co.uk" },
  { name: "TCL", website: "tcl.com" },
  { name: "Xiaomi", words: ["redmi"], website: "mi.com" },
  { name: "OnePlus", website: "oneplus.com" },
  { name: "Motorola", website: "motorola.com" },

  // Home and kitchen
  { name: "Dyson", categories: [HOME, BEAUTY], website: "dyson.co.uk" },
  { name: "Ninja", categories: [HOME], website: "ninjakitchen.co.uk" },
  { name: "Shark", words: ["shark vacuum"], categories: [HOME], website: "sharkclean.co.uk" },
  { name: "Tefal", categories: [HOME], website: "tefal.co.uk" },
  { name: "Breville", categories: [HOME], website: "breville.co.uk" },
  { name: "De'Longhi", words: ["delonghi"], website: "delonghi.com" },
  { name: "Nespresso", website: "nespresso.com" },
  { name: "Russell Hobbs", website: "russellhobbs.com" },
  { name: "Morphy Richards", website: "morphyrichards.co.uk" },
  { name: "Kenwood", website: "kenwoodworld.com" },
  { name: "KitchenAid", website: "kitchenaid.co.uk" },
  { name: "Le Creuset", website: "lecreuset.co.uk" },
  { name: "Bosch", website: "bosch-home.co.uk" },
  { name: "Hotpoint", website: "hotpoint.co.uk" },
  { name: "Beko", website: "beko.com" },
  { name: "Indesit", website: "indesit.co.uk" },
  { name: "Smeg", website: "smeg.co.uk" },
  { name: "DeWalt", website: "dewalt.co.uk" },
  { name: "Makita", website: "makitauk.com" },
  { name: "Ryobi", website: "ryobitools.eu" },
  { name: "Karcher", website: "kaercher.com" },

  // Toys and games
  { name: "LEGO", website: "lego.com" },
  { name: "Playmobil", website: "playmobil.co.uk" },

  // Clothing and shoes
  { name: "Nike", words: ["air max", "air force 1", "air jordan"], website: "nike.com" },
  { name: "Adidas", words: ["samba", "gazelle"], website: "adidas.co.uk" },
  { name: "Puma", categories: [CLOTHING, GAMING], website: "puma.com" },
  { name: "New Balance", website: "newbalance.co.uk" },
  { name: "Converse", website: "converse.com" },
  { name: "Vans", categories: [CLOTHING], website: "vans.co.uk" },
  { name: "Skechers", website: "skechers.com" },
  { name: "Under Armour", website: "underarmour.co.uk" },
  { name: "The North Face", words: ["north face"], website: "thenorthface.co.uk" },
  { name: "Levi's", words: ["levis"], website: "levi.com" },
  { name: "Ray-Ban", words: ["rayban", "ray ban"], website: "ray-ban.com" },
  { name: "Crocs", website: "crocs.co.uk" },
  { name: "Ugg", categories: [CLOTHING], website: "ugg.com" },
  { name: "Dr. Martens", words: ["dr martens", "doc martens"], website: "drmartens.com" },

  // Health and beauty
  { name: "Oral-B", words: ["oral b"], website: "oralb.co.uk" },
  { name: "Gillette", website: "gillette.co.uk" },
  { name: "Braun", website: "braun.com" },
  { name: "Remington", categories: [BEAUTY], website: "remington-europe.com" },
  { name: "BaByliss", words: ["babyliss"], website: "babyliss.co.uk" },
  { name: "ghd", categories: [BEAUTY], website: "ghdhair.com" },
  { name: "L'Oréal", words: ["loreal", "l oreal"], website: "loreal.com" },
  { name: "Nivea", website: "nivea.co.uk" },
  { name: "CeraVe", website: "cerave.com" },
  { name: "Clinique", website: "clinique.co.uk" },
  { name: "Dior", categories: [BEAUTY, CLOTHING], website: "dior.com" },
  { name: "Hugo Boss", words: ["boss bottled"], website: "hugoboss.com" },
  { name: "Dove", categories: [BEAUTY], website: "dove.com" },

  // Food and drink
  { name: "Cadbury", website: "cadbury.co.uk" },
  { name: "Lindt", website: "lindt.co.uk" },
  { name: "Heinz", website: "heinz.co.uk" },
  { name: "Coca-Cola", words: ["coca cola", "coke zero"], categories: [FOOD], website: "coca-cola.com" },
];
