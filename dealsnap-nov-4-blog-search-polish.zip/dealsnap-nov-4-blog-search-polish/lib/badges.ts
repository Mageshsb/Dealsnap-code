import type { IconName } from "@/components/Icon";

export type BadgeStats = {
  dealCount: number;
  commentCount: number;
  heartsReceived: number;
  followerCount: number;
  codeCount: number;
  commentLikesReceived: number;
  // The Community (lib/community-db.ts getCommunityStats).
  threadCount: number;
  bestAnswerCount: number;
  welcomeCount: number;
};

type Metric = keyof BadgeStats;

// Tiers go up in this order. Each badge's `tiers` list says how many it takes
// to reach each one, so a badge can have fewer tiers than this, and adding a
// tier VI later means one more entry here (and its colour in TierBadge) plus
// one more number on the badges that should have it.
export const TIER_NAMES = ["Bronze", "Silver", "Gold", "Platinum", "DealSnap"];

// Badges, one per thing we count. Showing only the highest tier reached keeps
// a busy member's profile to one chip per badge. A new badge is one more row.
//
// The numbers are set by effort, so no badge is the easy one or the slog:
//   I    a first go: a few minutes
//   II   hooked: within a couple of weeks
//   III  a regular: a few months
//   IV   a veteran: about half a year of steady effort
//   V    a legend: a year or more of steady effort, a proud moment
// Counting: 100 deals is the yardstick (about two a week for a year). Hearts are
// the points on a member's deals (each vote is 4–7 of them, and one hit deal
// can reach 800), so that top tier is about what 100 deals of ordinary pull
// earn, not one lucky deal. Comments take a minute, so they run to 1,000.
// Codes are only on about one deal in eight, so half the deals. Likes on
// comments come at about half the rate of comments. Followers cost nothing to
// give and depend on how big the site is, not just on effort, so they are set
// for a young community (200 is a community favourite). As the site grows, add
// a tier VI rather than moving these, so nobody loses a tier they have earned.
// Each step up is roughly 2.5 to 5 times the last.
const BADGE_DEFS: { key: string; icon: IconName; name: string; metric: Metric; unit: string; tiers: number[] }[] = [
  { key: "deals", icon: "tag", name: "Deal Hunter", metric: "dealCount", unit: "deals posted", tiers: [1, 5, 15, 50, 100] },
  { key: "hearts", icon: "heart", name: "Crowd Pleaser", metric: "heartsReceived", unit: "hearts", tiers: [50, 250, 1000, 3000, 10000] },
  { key: "codes", icon: "ticket", name: "Code Cracker", metric: "codeCount", unit: "codes shared", tiers: [1, 3, 8, 20, 50] },
  { key: "comments", icon: "comment", name: "Commentator", metric: "commentCount", unit: "comments", tiers: [5, 25, 100, 400, 1000] },
  { key: "helpful", icon: "thumbs-up", name: "Helpful", metric: "commentLikesReceived", unit: "likes on posts", tiers: [5, 25, 100, 250, 500] },
  { key: "followers", icon: "users", name: "Well Followed", metric: "followerCount", unit: "followers", tiers: [3, 10, 25, 75, 200] },
  // The Community. A thread takes longer than a comment, so these run lower.
  // A best answer is chosen by the person who asked (or a helper), so it can't
  // be farmed; a welcome is the first reply to someone's first thread.
  { key: "threads", icon: "pen-line", name: "Conversation Starter", metric: "threadCount", unit: "threads started", tiers: [1, 5, 15, 40, 100] },
  { key: "answers", icon: "lightbulb", name: "Problem Solver", metric: "bestAnswerCount", unit: "best answers", tiers: [1, 3, 10, 25, 75] },
  { key: "welcomes", icon: "hand-helping", name: "Welcomer", metric: "welcomeCount", unit: "new members welcomed", tiers: [1, 5, 20, 60, 150] },
];

export function romanNumeral(n: number): string {
  const parts: [number, string][] = [[10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"]];
  let out = "";
  for (const [value, letters] of parts) {
    while (n >= value) {
      out += letters;
      n -= value;
    }
  }
  return out;
}

// "1 comment", "25 comments", "1 more like on comments": every unit above
// starts with a plural word ending in "s".
export function countOf(n: number, unit: string, more = false) {
  return `${n.toLocaleString("en-GB")}${more ? " more" : ""} ${n === 1 ? unit.replace(/s\b/, "") : unit}`;
}

export type BadgeProgress = {
  key: string;
  icon: IconName;
  name: string;
  unit: string;
  value: number;
  tiers: number[];
  // How many tiers are reached: 0 is none yet, tiers.length is the top.
  tier: number;
  // The count needed for the next tier, or null once at the top.
  nextTarget: number | null;
};

// An earned badge as shown on the profile: its highest tier only.
export type Badge = { key: string; icon: IconName; name: string; tier: number; description: string };

export function getBadgeProgress(stats: BadgeStats): BadgeProgress[] {
  return BADGE_DEFS.map((b) => {
    const value = stats[b.metric];
    const tier = b.tiers.filter((t) => value >= t).length;
    return {
      key: b.key,
      icon: b.icon,
      name: b.name,
      unit: b.unit,
      value,
      tiers: b.tiers,
      tier,
      nextTarget: b.tiers[tier] ?? null,
    };
  });
}

export function getBadges(stats: BadgeStats): Badge[] {
  return getBadgeProgress(stats)
    .filter((b) => b.tier > 0)
    .map((b) => ({
      key: b.key,
      icon: b.icon,
      name: b.name,
      tier: b.tier,
      description: `${b.name} ${romanNumeral(b.tier)}: ${b.tiers[b.tier - 1].toLocaleString("en-GB")}+ ${b.unit}`,
    }));
}
