import { getCommunitySettings, listThreads, type LabelKind } from "./community-db";
import type { PanelDiscussions } from "@/components/InfoPanels";

// The Community block in a store, category or tag page's ⓘ panel: its latest
// three threads, or nothing at all when the Community is closed.
export function panelDiscussions(kind: LabelKind, value: string, name: string): PanelDiscussions | undefined {
  if (!getCommunitySettings().on) return undefined;
  const { rows } = listThreads({ label: { kind, value }, per: 3 });
  return {
    name,
    items: rows.map((t) => ({ title: t.title, href: `/community/t/${t.slug}`, replies: t.replyCount })),
    startHref: `/community/new?${kind}=${encodeURIComponent(value)}`,
  };
}
