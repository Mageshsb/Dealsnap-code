"use server";

import { after } from "next/server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { getCurrentUser } from "./auth";
import { logAudit } from "./audit";
import { checkFormTicket, newFormCheck, turnstileSiteKey, verifyTurnstile, type FormCheck } from "./captcha";
import { clientIp } from "./client-ip";
import { findUserById, type UserRecord } from "./db";
import { can, isStaffRole } from "./permissions";
import { mayAct, needsBotCheck, teamMember, writerProblem } from "./community-access";
import { getSiteSettings } from "./site-settings";
import { overLimit } from "./rate-limit";
import { BLOCKED_WORD_MESSAGE, blockedWordIn } from "./site-blocks";
import { checkedLabel } from "./community-labels";
import { notifyBestAnswer, notifyCommunityReply, notifyNewThread, notifyPostLikes } from "./notifications";

// Tells people about something once the response has gone: a reply never waits for
// its notifications to be written (one to a busy thread's followers is hundreds of
// them), and a problem writing one can't turn a reply that was posted into an error.
function later(work: () => void) {
  after(() => {
    try {
      work();
    } catch (e) {
      console.error("Community notification failed:", e);
    }
  });
}
import {
  COMMUNITY_EDIT_MINUTES,
  REPLY_MAX,
  THREAD_BODY_MAX,
  TITLE_MAX,
  communityEditableUntil,
  hasLink,
  isLikeMilestone,
  isQuietClosed,
  looksLikeSpam,
  pageOfSeq,
  spaceSlug,
  tidyText,
  tidyTitle,
  titleError,
  SPACE_BLURB_MAX,
  SPACE_NAME_MAX,
  SPACE_RULES_MAX,
  RESERVED_SPACE_SLUGS,
} from "./community-rules";
import {
  addReply,
  bannedWordIn,
  bannedWordList,
  clearPostReports,
  countLiveThreadsByUser,
  countPostsByUserSince,
  countThreadsByUserSince,
  createThread,
  deleteOwnReply,
  deleteOwnThread,
  purgeThread,
  editPostText,
  followSpace,
  forgetSpaceStats,
  findSimilarThreads,
  followThread,
  getCommunitySettings,
  getWelcomeThread,
  setWelcomeThread,
  getOpeningPost,
  getPostById,
  getPostTextRaw,
  getSpaceById,
  getThreadById,
  getThreadBySlug,
  hasRecentDuplicate,
  moveSpace,
  moveThreadToSpace,
  muteMember,
  reportPost,
  saveCommunitySettings,
  saveSpace,
  setPostStatus,
  setSpaceArchived,
  setThreadLocked,
  setThreadPinned,
  setThreadSolved,
  setThreadStatus,
  setThreadTitle,
  slugTakenBySpace,
  togglePostLike,
  trustedReportCount,
  unfollowSpace,
  unfollowThread,
  unmuteMember,
  withdrawPostReport,
} from "./community-db";
import { isIconName } from "@/components/Icon";
import type { SimilarThread } from "./community-db";
import { MAX_PICTURES, plainDescription } from "./deal-text";
import { getPictures, savePictures, type NewPicture } from "./pictures";
import { mayAddPictures, readInlinePictures, sentPictures } from "./post-pictures";
import { MAX_LINKS, outsideLinks } from "./rich-text";
import { getSiteHosts } from "./site-url";
import { MAX_DEAL_CARDS } from "./community-rules";

// A post's words and pictures as they'll be kept: new pictures cleaned and
// given ids (only for someone allowed to add them), and the checks every
// post gets on its words and links. Returns the problem to show instead.
async function readPost(
  user: UserRecord,
  rawText: string,
  files: Map<string, File>,
  { max, own = [] }: { max: number; own?: string[] }
): Promise<{ text: string; words: string; order: string[]; added: NewPicture[] } | { error: string }> {
  const allowed = mayAddPictures(user);
  if (!allowed && files.size > 0) return { error: "New accounts can add pictures once they've been here a little while. Say it in words for now." };
  const read = await readInlinePictures(tidyText(rawText), files, { max: allowed ? max : own.length, own });
  if ("error" in read) return read;
  const words = plainDescription(read.text);
  if (outsideLinks(read.text, { format: true, hosts: await getSiteHosts(), cards: MAX_DEAL_CARDS }).length > MAX_LINKS) {
    return { error: `A post can have up to ${MAX_LINKS} links to other websites.` };
  }
  return { ...read, words };
}

// Everything a member or the team can do in the Community. Each action checks
// for itself who is asking and what they may do (never trusting the page that
// called it), and every team action is written to the activity log.

const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;
const FAR_TOO_QUICK = 90; // posts a minute from one place, whoever is signed in

function accountAgeDays(createdAt: string): number {
  return (Date.now() - new Date(createdAt).getTime()) / DAY;
}

// The new-member limits and the same checks for every post. Staff and helpers
// are exempt from the numbers, never from the word filter.
function textProblem(user: UserRecord, text: string, kind: "thread" | "reply" | "edit", title?: string): string | null {
  const settings = getCommunitySettings();
  const site = getSiteSettings();
  const all = title ? `${title}\n${text}` : text;
  // The Community's own list, and the site-wide one (Admin → Settings → Security).
  if (bannedWordIn(all, bannedWordList(settings.bannedWords)) || blockedWordIn(all)) return BLOCKED_WORD_MESSAGE;
  if (looksLikeSpam(all)) return "That looks like spam. Please write it out properly.";
  if (user.role === "user" && site.spamProtection) {
    const isNew = accountAgeDays(user.createdAt) < site.newAccountDays;
    if (isNew && site.blockLinksFromNewAccounts && hasLink(all)) {
      return "New accounts can't put links in the Community yet. Say what it is in words, or post it with + Post a deal.";
    }
    if (kind === "thread") {
      const limit = isNew ? settings.newThreadsPerDay : settings.threadsPerDay;
      if (countThreadsByUserSince(user.id, new Date(Date.now() - DAY).toISOString()) >= limit) {
        return isNew
          ? `New accounts can start ${limit} thread${limit === 1 ? "" : "s"} a day while they settle in. Please try again tomorrow.`
          : `You've started ${limit} threads today. Please try again tomorrow, or add to one that's already open.`;
      }
    } else if (kind === "reply") {
      const limit = isNew ? settings.newRepliesPerHour : settings.repliesPerHour;
      if (countPostsByUserSince(user.id, new Date(Date.now() - HOUR).toISOString()) >= limit) {
        return "You're posting very quickly. Please wait a little while before posting again.";
      }
    }
  }
  // (Changing a post is neither a new post nor a repeat of one.)
  if (kind !== "edit" && hasRecentDuplicate(user.id, text)) return "You've already posted exactly that.";
  return null;
}

// ---------------------------------------------------------------------------
// Starting a thread
// ---------------------------------------------------------------------------

export type NewThreadState = {
  error?: string;
  field?: "space" | "title" | "text" | "check";
  check?: FormCheck;
  values?: { space: string; title: string; text: string };
};

export async function createThreadAction(_prev: NewThreadState, formData: FormData): Promise<NewThreadState> {
  const user = await getCurrentUser();
  const spaceId = String(formData.get("space") ?? "");
  const title = tidyTitle(String(formData.get("title") ?? ""));
  let text = tidyText(String(formData.get("text") ?? ""));
  const usingTurnstile = !!turnstileSiteKey();
  const wantsCheck = !!user && needsBotCheck(user);
  const fail = (error: string, field?: NewThreadState["field"]): NewThreadState => ({
    error,
    field,
    check: wantsCheck ? newFormCheck(!usingTurnstile) : undefined,
    values: { space: spaceId, title, text },
  });

  // Only bots fill in the hidden box; they're told it worked.
  if (String(formData.get("website") ?? "")) return { values: { space: "", title: "", text: "" } };

  const problem = writerProblem(user);
  if (problem || !user) return fail(problem ?? "Log in to join in.");
  if (await overLimit("community-post", FAR_TOO_QUICK)) return fail("That's a lot of posts from one place. Please wait a minute.");

  const space = getSpaceById(spaceId);
  if (!space || space.archived) return fail("Choose where this belongs.", "space");
  if (space.who === "staff" && !isStaffRole(user.role)) return fail("Only our team can start threads in this space.", "space");
  const titleProblem = titleError(title);
  if (titleProblem) return fail(titleProblem, "title");
  const read = await readPost(user, text, sentPictures(formData, "pictures"), { max: MAX_PICTURES.thread });
  if ("error" in read) return fail(read.error, "text");
  if (!read.words) return fail("Write something to start the conversation.", "text");
  if (read.text.length > THREAD_BODY_MAX) return fail(`Keep it to ${THREAD_BODY_MAX.toLocaleString("en-GB")} characters or fewer.`, "text");
  const textIssue = textProblem(user, read.words, "thread", title);
  if (textIssue) return fail(textIssue, "text");
  text = read.text;

  if (wantsCheck) {
    const ip = await clientIp();
    const result = checkFormTicket(String(formData.get("ticket") ?? ""), usingTurnstile ? undefined : String(formData.get("answer") ?? ""));
    if (result === "wrong-answer") return fail("That answer to the sum isn't right. Here's a new one.", "check");
    if (result === "too-fast") return fail("That was very quick! Please check what you've written and post it again.", "check");
    if (result !== "ok") return fail("This form timed out. Please post it again.", "check");
    if (usingTurnstile && !(await verifyTurnstile(String(formData.get("cf-turnstile-response") ?? ""), ip))) {
      return fail("We couldn't confirm you're not a robot. Please try again.", "check");
    }
  }

  const settings = getCommunitySettings();
  const held = user.role === "user" && settings.holdFirstThreads && countLiveThreadsByUser(user.id) < settings.holdCount;
  const label = checkedLabel(String(formData.get("labelKind") ?? ""), String(formData.get("labelValue") ?? ""));
  const made = createThread({ spaceId: space.id, userId: user.id, title, text, status: held ? "held" : "live", label: label && { kind: label.kind, value: label.value } });
  if (read.added.length) await savePictures("post", made.postId, read.order, read.added, user.id);
  if (!held) {
    const thread = getThreadById(made.threadId);
    if (thread) later(() => notifyNewThread({ thread, author: user }));
  }
  revalidatePath("/community");
  redirect(`/community/t/${made.slug}${held ? "?held=1" : ""}`);
}

// While a title is typed in the new-discussion form: up to three live threads whose
// titles share its words, so a question that is already being talked about is
// found before it is asked again. Members only, and limited, as each is a search.
export async function similarThreadsAction(title: string): Promise<SimilarThread[]> {
  const user = await getCurrentUser();
  if (!user || user.suspended) return [];
  const clean = tidyTitle(String(title ?? "")).slice(0, TITLE_MAX);
  if (clean.length < 10) return [];
  if (await overLimit("community-similar", 40)) return [];
  return findSimilarThreads(clean, 3);
}

// ---------------------------------------------------------------------------
// Replying, editing, deleting
// ---------------------------------------------------------------------------

// A reply from the box under a thread. No page reload: it hands back where the
// new post is, so the box can take the reader to it, or the problem to show.
export async function replyAction(
  threadSlug: string,
  replyToId: string | null,
  rawText: string,
  sent?: FormData
): Promise<{ seq: number; page: number } | { error: string }> {
  const user = await getCurrentUser();
  const problem = writerProblem(user);
  if (problem || !user) return { error: problem ?? "Log in to join in." };
  if (await overLimit("community-post", FAR_TOO_QUICK)) return { error: "That's a lot of posts from one place. Please wait a minute." };
  const thread = getThreadBySlug(threadSlug);
  if (!thread || thread.status !== "live") return { error: "This thread isn't open." };
  if (thread.locked && !can(user.role, "forum.moderate")) return { error: "This thread is locked." };
  const quietDays = getCommunitySettings().closeAfterDays;
  if (isQuietClosed(thread.lastPostAt, quietDays) && !can(user.role, "forum.moderate")) {
    return { error: `This thread has been quiet for over ${quietDays} days, so it's closed. Start a new thread and link back to this one.` };
  }
  const read = await readPost(user, rawText, sent instanceof FormData ? sentPictures(sent, "pictures") : new Map(), { max: MAX_PICTURES.reply });
  if ("error" in read) return read;
  const text = read.text;
  if (!read.words) return { error: "Write something first." };
  if (text.length > REPLY_MAX) return { error: `Replies can be up to ${REPLY_MAX.toLocaleString("en-GB")} characters.` };
  const issue = textProblem(user, read.words, "reply");
  if (issue) return { error: issue };

  const made = addReply({ threadId: thread.id, userId: user.id, text, replyToId });
  if (!made) return { error: "That thread has just been closed." };
  if (read.added.length) await savePictures("post", made.postId, read.order, read.added, user.id);
  const page = pageOfSeq(made.seq);
  later(() => notifyCommunityReply({ thread, postId: made.postId, seq: made.seq, page, replyToId, author: user, text: read.words }));
  revalidatePath(`/community/t/${thread.slug}`);
  return { seq: made.seq, page };
}

// A member changing their own post, or the team editing one by someone they
// outrank (shown to readers as "edited by our team"). Returns the problem, or null.
export async function editPostAction(postId: string, rawText: string, sent?: FormData): Promise<string | null> {
  const user = await getCurrentUser();
  const post = getPostById(postId);
  if (!user || !post || post.status !== "live" || user.suspended) return "You can't change this post.";
  const thread = getThreadById(post.threadId);
  if (!thread || thread.status === "removed" || thread.status === "deleted") return "You can't change this post.";
  const own = post.userId === user.id;
  const asTeam = !own && teamMember(user, "forum.moderate") && mayAct(user, post);
  if (!own && !asTeam) return "You can't change this post.";
  if (own && writerProblem(user)) return writerProblem(user);
  if (own && Date.now() > communityEditableUntil(post.createdAt)) {
    return `Posts can only be changed for ${COMMUNITY_EDIT_MINUTES} minutes after posting. You can still delete it.`;
  }
  const own_pictures = getPictures("post", postId).map((p) => p.id);
  // The team editing someone's post keep its pictures, and add none.
  const files = own && sent instanceof FormData ? sentPictures(sent, "pictures") : new Map<string, File>();
  const read = await readPost(user, rawText, files, { max: post.seq === 1 ? MAX_PICTURES.thread : MAX_PICTURES.reply, own: own_pictures });
  if ("error" in read) return read.error;
  const text = read.text;
  const max = post.seq === 1 ? THREAD_BODY_MAX : REPLY_MAX;
  if (!read.words) return "Write something, or delete the post instead.";
  if (text.length > max) return `Keep it to ${max.toLocaleString("en-GB")} characters or fewer.`;
  const issue = textProblem(user, read.words, "edit");
  if (issue) return issue;
  const before = getPostTextRaw(postId) ?? "";
  await savePictures("post", postId, read.order, read.added, own ? user.id : post.userId);
  editPostText(postId, text, user.id);
  if (asTeam) {
    logAudit(user, "forum.post-edit", { targetId: post.userId, label: post.username, url: `/community/t/${thread.slug}#post-${post.seq}`, detail: `was: "${before.slice(0, 160)}"` });
  }
  revalidatePath(`/community/t/${thread.slug}`);
  return null;
}

// A member deleting their own post. Their opening post takes the whole thread
// with it; a reply stays as "Deleted" so the posts after it still make sense.
export async function deletePostAction(postId: string): Promise<{ thread: boolean } | null> {
  const user = await getCurrentUser();
  const post = getPostById(postId);
  if (!user || !post || post.userId !== user.id || post.status !== "live") return null;
  const thread = getThreadById(post.threadId);
  if (!thread) return null;
  if (post.seq === 1) {
    deleteOwnThread(thread.id);
    revalidatePath("/community");
    return { thread: true };
  }
  deleteOwnReply(postId, user.id);
  revalidatePath(`/community/t/${thread.slug}`);
  return { thread: false };
}

export async function likePostAction(postId: string): Promise<{ liked: boolean; likeCount: number } | null> {
  const user = await getCurrentUser();
  if (!user || user.suspended) return null;
  if (await overLimit("community-like", 120)) return null;
  const post = getPostById(postId);
  if (!post || post.userId === user.id) return null;
  const thread = getThreadById(post.threadId);
  if (thread?.status !== "live") return null;
  const result = togglePostLike(postId, user.id) ?? null;
  // A milestone (5, 25, 100 likes) tells the author, once each.
  if (result?.liked && isLikeMilestone(result.likeCount)) {
    later(() => notifyPostLikes({ thread, postId, seq: post.seq, page: pageOfSeq(post.seq), likes: result.likeCount }));
  }
  return result;
}

// Report / un-report from a post's "⋯". Enough reports from established
// members hide the post until a moderator looks (the Community's quick
// answer to spam, without waiting for staff to be awake).
export async function setPostReportAction(postId: string, reported: boolean): Promise<boolean | null> {
  const user = await getCurrentUser();
  if (!user || user.suspended) return null;
  const post = getPostById(postId);
  if (!post || post.userId === user.id) return null;
  if (!reported) {
    withdrawPostReport(postId, user.id);
    return false;
  }
  if (await overLimit("community-report", 30)) return null;
  reportPost(postId, user.id);
  if (post.status === "live" && post.role === "user" && post.seq > 1 && trustedReportCount(postId, 7) >= getCommunitySettings().autoHideReports) {
    setPostStatus(postId, "hidden", null);
    const thread = getThreadById(post.threadId);
    if (thread) revalidatePath(`/community/t/${thread.slug}`);
  }
  return true;
}

export async function followThreadAction(threadId: string, follow: boolean): Promise<boolean | null> {
  const user = await getCurrentUser();
  const thread = getThreadById(threadId);
  if (!user || user.suspended || !thread || thread.status !== "live") return null;
  if (await overLimit("community-follow", 60)) return null;
  if (follow) followThread(user.id, threadId, thread.lastSeq);
  else unfollowThread(user.id, threadId);
  return follow;
}

export async function followSpaceAction(spaceId: string, follow: boolean): Promise<boolean | null> {
  const user = await getCurrentUser();
  const space = getSpaceById(spaceId);
  if (!user || user.suspended || !space) return null;
  if (await overLimit("community-follow", 60)) return null;
  if (follow) followSpace(user.id, spaceId);
  else unfollowSpace(user.id, spaceId);
  return follow;
}

// ---------------------------------------------------------------------------
// Helpers and the team, from the thread itself
// ---------------------------------------------------------------------------

// Marks (or clears) the best answer in a question space: the person who asked,
// or a helper and above.
export async function markBestAnswerAction(threadId: string, postId: string | null): Promise<boolean> {
  const user = await getCurrentUser();
  const thread = getThreadById(threadId);
  if (!user || !thread || thread.status !== "live" || thread.spaceKind !== "ask" || user.suspended) return false;
  const asker = thread.userId === user.id;
  if (!asker && !teamMember(user, "forum.tidy")) return false;
  if (postId) {
    const post = getPostById(postId);
    if (!post || post.threadId !== threadId || post.status !== "live" || post.seq === 1) return false;
    setThreadSolved(threadId, postId);
    if (post.userId !== user.id) {
      later(() => notifyBestAnswer({ thread, postId, seq: post.seq, page: pageOfSeq(post.seq), answerer: post.username, markedBy: user }));
    }
  } else {
    setThreadSolved(threadId, null);
  }
  if (!asker) logAudit(user, "forum.tidy", { label: thread.title, url: `/community/t/${thread.slug}`, detail: postId ? "marked the best answer" : "cleared the best answer" });
  revalidatePath(`/community/t/${thread.slug}`);
  return true;
}

// A helper hiding a post for a moderator to check, or a moderator removing it.
export async function hidePostAction(postId: string): Promise<boolean> {
  const user = await getCurrentUser();
  const post = getPostById(postId);
  if (!teamMember(user, "forum.tidy") || !post || post.status !== "live" || post.seq === 1 || !mayAct(user, post)) return false;
  const thread = getThreadById(post.threadId);
  if (!thread) return false;
  setPostStatus(postId, "hidden", user.id);
  logAudit(user, "forum.post-hide", { targetId: post.userId, label: post.username, url: `/community/t/${thread.slug}#post-${post.seq}` });
  revalidatePath(`/community/t/${thread.slug}`);
  return true;
}

export async function restorePostAction(postId: string): Promise<boolean> {
  const user = await getCurrentUser();
  const post = getPostById(postId);
  if (!teamMember(user, "forum.moderate") || !post || (post.status !== "hidden" && post.status !== "removed") || !mayAct(user, post)) return false;
  const thread = getThreadById(post.threadId);
  if (!thread) return false;
  setPostStatus(postId, "live", user.id);
  logAudit(user, "forum.post-restore", { targetId: post.userId, label: post.username, url: `/community/t/${thread.slug}#post-${post.seq}` });
  revalidatePath(`/community/t/${thread.slug}`);
  revalidatePath("/admin/community");
  return true;
}

export async function removePostAction(postId: string): Promise<boolean> {
  const user = await getCurrentUser();
  const post = getPostById(postId);
  if (!teamMember(user, "forum.moderate") || !post || post.status === "removed" || post.status === "deleted" || !mayAct(user, post)) return false;
  const thread = getThreadById(post.threadId);
  if (!thread) return false;
  const was = getPostTextRaw(postId) ?? "";
  if (post.seq === 1) {
    setThreadStatus(thread.id, "removed", user.id);
    logAudit(user, "forum.thread-remove", { targetId: post.userId, label: thread.title, url: `/community/t/${thread.slug}`, detail: `by ${post.username}: "${was.slice(0, 160)}"` });
    revalidatePath("/community");
  } else {
    setPostStatus(postId, "removed", user.id);
    logAudit(user, "forum.post-remove", { targetId: post.userId, label: post.username, url: `/community/t/${thread.slug}#post-${post.seq}`, detail: `"${was.slice(0, 160)}"` });
  }
  clearPostReports(postId);
  revalidatePath(`/community/t/${thread.slug}`);
  revalidatePath("/admin/community");
  return true;
}

// Permanently deleting a thread the team has already removed: owners only, and
// only from the removed state, so it is always two deliberate steps. The log
// keeps who wrote it, where, how big it was and the start of its words.
export async function deleteThreadForeverAction(threadId: string): Promise<boolean> {
  const user = await getCurrentUser();
  const thread = getThreadById(threadId);
  if (!teamMember(user, "forum.delete") || !thread || thread.status !== "removed") return false;
  const opening = getOpeningPost(threadId);
  const posts = thread.lastSeq;
  purgeThread(threadId);
  logAudit(user, "forum.thread-delete", {
    targetId: thread.userId,
    label: thread.title,
    url: "/admin/community",
    detail: `by ${thread.username} in ${thread.spaceName} · ${posts} post${posts === 1 ? "" : "s"}${opening ? ` · "${opening.text.slice(0, 120)}"` : ""}`,
  });
  revalidatePath("/community");
  revalidatePath("/admin/community");
  return true;
}

export async function dismissPostReportsAction(postId: string): Promise<boolean> {
  const user = await getCurrentUser();
  const post = getPostById(postId);
  if (!teamMember(user, "forum.moderate") || !post) return false;
  const thread = getThreadById(post.threadId);
  if (!thread) return false;
  clearPostReports(postId);
  // A post a helper hid that the moderator finds fine comes back.
  if (post.status === "hidden") setPostStatus(postId, "live", user.id);
  logAudit(user, "forum.dismiss", { targetId: post.userId, label: post.username, url: `/community/t/${thread.slug}#post-${post.seq}` });
  revalidatePath(`/community/t/${thread.slug}`);
  revalidatePath("/admin/community");
  return true;
}

export type ThreadChange = "pin" | "unpin" | "lock" | "unlock" | "restore" | "approve";

// Pin, lock, bring back a removed thread, or let a held first thread through.
export async function changeThreadAction(threadId: string, change: ThreadChange): Promise<boolean> {
  const user = await getCurrentUser();
  const thread = getThreadById(threadId);
  if (!teamMember(user, "forum.moderate") || !thread) return false;
  const url = `/community/t/${thread.slug}`;
  if (change === "pin" || change === "unpin") {
    setThreadPinned(threadId, change === "pin");
    logAudit(user, "forum.pin", { label: thread.title, url, detail: change === "pin" ? "pinned" : "unpinned" });
  } else if (change === "lock" || change === "unlock") {
    setThreadLocked(threadId, change === "lock");
    logAudit(user, "forum.lock", { label: thread.title, url, detail: change === "lock" ? "locked" : "unlocked" });
  } else if (change === "restore") {
    if (thread.status !== "removed" || !mayAct(user, thread)) return false;
    setThreadStatus(threadId, "live");
    logAudit(user, "forum.thread-restore", { targetId: thread.userId, label: thread.title, url });
  } else if (change === "approve") {
    if (thread.status !== "held") return false;
    setThreadStatus(threadId, "live");
    logAudit(user, "forum.thread-approve", { targetId: thread.userId, label: thread.title, url });
    later(() => notifyNewThread({ thread, author: { id: thread.userId, username: thread.username } }));
  }
  revalidatePath("/community");
  revalidatePath(url);
  revalidatePath("/admin/community");
  return true;
}

// A helper or moderator renaming a thread or moving it to a better space.
export async function tidyThreadAction(threadId: string, input: { title?: string; spaceId?: string }): Promise<string | null> {
  const user = await getCurrentUser();
  const thread = getThreadById(threadId);
  if (!teamMember(user, "forum.tidy") || !thread || thread.status === "removed" || thread.status === "deleted") return "You can't change this thread.";
  if (!mayAct(user, thread)) return "You can only tidy threads by people below you.";
  const notes: string[] = [];
  if (input.title !== undefined) {
    const title = tidyTitle(input.title);
    const problem = titleError(title);
    if (problem) return problem;
    if (title !== thread.title) {
      setThreadTitle(threadId, title);
      notes.push(`title was "${thread.title}"`);
    }
  }
  if (input.spaceId !== undefined && input.spaceId !== thread.spaceId) {
    const space = getSpaceById(input.spaceId);
    if (!space || space.archived) return "Choose a space.";
    if (space.who === "staff" && !isStaffRole(user.role)) return "Only our team can put threads there.";
    moveThreadToSpace(threadId, space.id);
    // A thread moved out of a question space can't keep a best answer it no longer asks for.
    if (space.kind !== "ask") setThreadSolved(threadId, null);
    notes.push(`moved from ${thread.spaceName} to ${space.name}`);
  }
  if (notes.length) logAudit(user, "forum.tidy", { targetId: thread.userId, label: input.title ?? thread.title, url: `/community/t/${thread.slug}`, detail: notes.join("; ") });
  revalidatePath("/community");
  revalidatePath(`/community/t/${thread.slug}`);
  return null;
}

export async function muteMemberAction(userId: string, days: number, reason: string): Promise<boolean> {
  const actor = await getCurrentUser();
  const target = findUserById(userId);
  if (!teamMember(actor, "forum.moderate") || !target || !mayAct(actor, { userId: target.id, role: target.role }) || target.id === actor.id) return false;
  const length = Math.min(90, Math.max(1, Math.round(days)));
  muteMember(userId, new Date(Date.now() + length * DAY).toISOString(), reason.trim().slice(0, 140), actor.id);
  logAudit(actor, "forum.mute", { targetId: userId, label: target.username, url: `/admin/users/${userId}`, detail: `${length} day${length === 1 ? "" : "s"}${reason.trim() ? ` · ${reason.trim().slice(0, 140)}` : ""}` });
  revalidatePath("/admin/community");
  return true;
}

export async function unmuteMemberAction(userId: string): Promise<boolean> {
  const actor = await getCurrentUser();
  const target = findUserById(userId);
  if (!teamMember(actor, "forum.moderate") || !target) return false;
  unmuteMember(userId);
  logAudit(actor, "forum.unmute", { targetId: userId, label: target.username, url: `/admin/users/${userId}` });
  revalidatePath("/admin/community");
  return true;
}

// ---------------------------------------------------------------------------
// Admin → Community: spaces and limits
// ---------------------------------------------------------------------------

export type SpaceFormState = { error?: string; saved?: boolean };

export async function saveSpaceAction(_prev: SpaceFormState, formData: FormData): Promise<SpaceFormState> {
  const user = await getCurrentUser();
  if (!teamMember(user, "forum.manage")) return { error: "You can't change the Community's spaces." };
  const id = String(formData.get("id") ?? "") || undefined;
  const name = tidyTitle(String(formData.get("name") ?? "")).slice(0, SPACE_NAME_MAX);
  const blurb = tidyTitle(String(formData.get("blurb") ?? "")).slice(0, SPACE_BLURB_MAX);
  const rules = tidyText(String(formData.get("rules") ?? "")).slice(0, SPACE_RULES_MAX);
  const iconRaw = String(formData.get("icon") ?? "comment");
  const kind = formData.get("kind") === "ask" ? "ask" : "talk";
  const who = formData.get("who") === "staff" ? "staff" : "members";
  if (name.length < 3) return { error: "Give the space a name of at least 3 characters." };
  const slug = spaceSlug(name);
  if (!slug || RESERVED_SPACE_SLUGS.includes(slug)) return { error: "Please choose a different name; that one is used by the Community itself." };
  if (slugTakenBySpace(slug, id)) return { error: "There is already a space with that name." };
  if (id && !getSpaceById(id)) return { error: "That space no longer exists." };
  saveSpace({ id, slug, name, blurb, icon: isIconName(iconRaw) ? iconRaw : "comment", rules, kind, who });
  forgetSpaceStats();
  logAudit(user, "forum.space", { label: name, url: "/admin/community/spaces", detail: id ? "edited" : "added" });
  revalidatePath("/community");
  revalidatePath("/admin/community/spaces");
  return { saved: true };
}

// A space's welcome thread, written by an admin from the Spaces page: posted under
// their name, pinned to the top of its space, and only one per space.
export async function postWelcomeThreadAction(formData: FormData): Promise<void> {
  const user = await getCurrentUser();
  const back = "/admin/community/spaces";
  const fail = (message: string): never => redirect(`${back}?error=${encodeURIComponent(message)}#welcome`);
  if (!user || !teamMember(user, "forum.manage")) return fail("You can't change the Community's spaces.");
  const space = getSpaceById(String(formData.get("space") ?? ""));
  if (!space || space.archived) return fail("That space isn't open any more.");
  if (getWelcomeThread(space.id)) return fail(`${space.name} already has a welcome thread.`);
  const title = tidyTitle(String(formData.get("title") ?? "")).slice(0, TITLE_MAX);
  const text = tidyText(String(formData.get("text") ?? ""));
  const problem = titleError(title);
  if (problem) return fail(problem);
  if (!text) return fail("Write the welcome message.");
  if (text.length > THREAD_BODY_MAX) return fail(`Keep the message to ${THREAD_BODY_MAX.toLocaleString("en-GB")} characters or fewer.`);
  const made = createThread({ spaceId: space.id, userId: user.id, title, text, status: "live" });
  setThreadPinned(made.threadId, true);
  setWelcomeThread(space.id, made.threadId);
  forgetSpaceStats();
  logAudit(user, "forum.pin", { label: title, url: `/community/t/${made.slug}`, detail: `posted and pinned a welcome thread in ${space.name}` });
  revalidatePath("/community");
  revalidatePath(`/community/${space.slug}`);
  redirect(`${back}?notice=${encodeURIComponent(`Posted and pinned in ${space.name}.`)}#welcome`);
}

export async function moveSpaceAction(spaceId: string, direction: "up" | "down"): Promise<void> {
  const user = await getCurrentUser();
  if (!teamMember(user, "forum.manage")) return;
  moveSpace(spaceId, direction);
  revalidatePath("/community");
  revalidatePath("/admin/community/spaces");
}

// Archiving hides a space and its threads from the public pages; nothing is
// deleted, and bringing it back brings everything back.
export async function archiveSpaceAction(spaceId: string, archived: boolean): Promise<string | null> {
  const user = await getCurrentUser();
  const space = getSpaceById(spaceId);
  if (!teamMember(user, "forum.manage") || !space) return "You can't change the Community's spaces.";
  setSpaceArchived(spaceId, archived);
  forgetSpaceStats();
  logAudit(user, "forum.space", { label: space.name, url: "/admin/community/spaces", detail: archived ? "archived" : "brought back" });
  revalidatePath("/community");
  revalidatePath("/admin/community/spaces");
  return null;
}

const wholeFrom = (formData: FormData, name: string, fallback: number, min: number, max: number) => {
  const n = parseInt(String(formData.get(name) ?? ""), 10);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};

export async function saveCommunitySettingsAction(_prev: SpaceFormState, formData: FormData): Promise<SpaceFormState> {
  const user = await getCurrentUser();
  if (!teamMember(user, "forum.manage")) return { error: "You can't change the Community's limits." };
  const current = getCommunitySettings();
  saveCommunitySettings({
    on: formData.get("on") === "on",
    newThreadsPerDay: wholeFrom(formData, "newThreadsPerDay", current.newThreadsPerDay, 1, 50),
    threadsPerDay: wholeFrom(formData, "threadsPerDay", current.threadsPerDay, 1, 200),
    newRepliesPerHour: wholeFrom(formData, "newRepliesPerHour", current.newRepliesPerHour, 1, 200),
    repliesPerHour: wholeFrom(formData, "repliesPerHour", current.repliesPerHour, 1, 500),
    holdFirstThreads: formData.get("holdFirstThreads") === "on",
    holdCount: wholeFrom(formData, "holdCount", current.holdCount, 1, 10),
    autoHideReports: wholeFrom(formData, "autoHideReports", current.autoHideReports, 2, 20),
    closeAfterDays: (() => {
      const n = wholeFrom(formData, "closeAfterDays", current.closeAfterDays, 0, 730);
      return n === 0 ? 0 : Math.max(30, n);
    })(),
    bannedWords: bannedWordList(String(formData.get("bannedWords") ?? "")).join("\n"),
  });
  logAudit(user, "forum.settings", { url: "/admin/community/limits" });
  revalidatePath("/community");
  revalidatePath("/admin/community/limits");
  return { saved: true };
}
