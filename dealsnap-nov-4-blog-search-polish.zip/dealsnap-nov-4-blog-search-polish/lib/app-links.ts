// The pages a DealSnap link opens in the phone app rather than the browser,
// when the app is installed: the things people share. Kept to match
// mobile/android/app/src/main/AndroidManifest.xml (Android lists them there).
export const APP_LINK_PATHS = ["/", "/deals/*", "/stores/*", "/tags/*", "/u/*", "/blog/*", "/submit", "/alerts", "/notifications", "/saved"];
