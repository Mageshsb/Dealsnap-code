// A category's colour is a named hue stored with the category (Admin → Tags and
// brands), so renaming a category keeps its colour. The class names are written
// out in full so Tailwind sees them.
export type Theme = { badge: string; tile: string; icon: string; swatch: string };

const themes = {
  blue: {
    badge: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
    tile: "bg-blue-50 dark:bg-blue-950/40",
    icon: "text-blue-400 dark:text-blue-500/80",
    swatch: "bg-blue-400",
  },
  purple: {
    badge: "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300",
    tile: "bg-purple-50 dark:bg-purple-950/40",
    icon: "text-purple-400 dark:text-purple-500/80",
    swatch: "bg-purple-400",
  },
  pink: {
    badge: "bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-300",
    tile: "bg-pink-50 dark:bg-pink-950/40",
    icon: "text-pink-400 dark:text-pink-500/80",
    swatch: "bg-pink-400",
  },
  teal: {
    badge: "bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300",
    tile: "bg-teal-50 dark:bg-teal-950/40",
    icon: "text-teal-400 dark:text-teal-500/80",
    swatch: "bg-teal-400",
  },
  amber: {
    badge: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
    tile: "bg-amber-50 dark:bg-amber-950/40",
    icon: "text-amber-400 dark:text-amber-500/80",
    swatch: "bg-amber-400",
  },
  green: {
    badge: "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300",
    tile: "bg-green-50 dark:bg-green-950/40",
    icon: "text-green-400 dark:text-green-500/80",
    swatch: "bg-green-400",
  },
  sky: {
    badge: "bg-sky-100 text-sky-700 dark:bg-sky-900/40 dark:text-sky-300",
    tile: "bg-sky-50 dark:bg-sky-950/40",
    icon: "text-sky-400 dark:text-sky-500/80",
    swatch: "bg-sky-400",
  },
  rose: {
    badge: "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",
    tile: "bg-rose-50 dark:bg-rose-950/40",
    icon: "text-rose-400 dark:text-rose-500/80",
    swatch: "bg-rose-400",
  },
  lime: {
    badge: "bg-lime-100 text-lime-700 dark:bg-lime-900/40 dark:text-lime-300",
    tile: "bg-lime-50 dark:bg-lime-950/40",
    icon: "text-lime-500 dark:text-lime-500/80",
    swatch: "bg-lime-400",
  },
  cyan: {
    badge: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300",
    tile: "bg-cyan-50 dark:bg-cyan-950/40",
    icon: "text-cyan-400 dark:text-cyan-500/80",
    swatch: "bg-cyan-400",
  },
} satisfies Record<string, Theme>;

export type Hue = keyof typeof themes;
export const HUES = Object.keys(themes) as Hue[];

export const FALLBACK_THEME: Theme = {
  badge: "bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300",
  tile: "bg-zinc-100 dark:bg-zinc-800",
  icon: "text-zinc-400 dark:text-zinc-500",
  swatch: "bg-zinc-400",
};

export function isHue(value: unknown): value is Hue {
  return typeof value === "string" && value in themes;
}

export function hueTheme(hue: string | undefined): Theme {
  return isHue(hue) ? themes[hue] : FALLBACK_THEME;
}
