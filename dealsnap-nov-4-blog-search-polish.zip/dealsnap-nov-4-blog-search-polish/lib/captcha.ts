import crypto from "crypto";
import { sign as signWith } from "./secrets";

// Bot checks for public forms (the contact form). Two kinds:
//
//  - Cloudflare Turnstile, once two settings are in the server's environment:
//      TURNSTILE_SITE_KEY    shown in the page
//      TURNSTILE_SECRET_KEY  used here to check the answer
//    (Cloudflare dashboard → Turnstile → Add widget; free.) Most people just
//    see a tick; nothing to solve, and no tracking cookies.
//  - Until then, a simple sum ("What is 3 + 4?"). Good enough to stop the
//    automated junk that fills unprotected forms.
//
// Either way, the form also has a hidden field only bots fill in, and a
// minimum time between showing the form and sending it.

export function turnstileSiteKey(): string | undefined {
  return process.env.TURNSTILE_SITE_KEY && process.env.TURNSTILE_SECRET_KEY ? process.env.TURNSTILE_SITE_KEY : undefined;
}

export async function verifyTurnstile(token: string, ip?: string): Promise<boolean> {
  if (!token) return false;
  try {
    const body = new URLSearchParams({ secret: process.env.TURNSTILE_SECRET_KEY ?? "", response: token });
    if (ip && ip !== "unknown") body.set("remoteip", ip);
    const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", { method: "POST", body });
    const data = (await res.json()) as { success?: boolean };
    return data.success === true;
  } catch (err) {
    console.error("[captcha] couldn't reach Cloudflare Turnstile:", err);
    return false;
  }
}

// ---- the built-in fallback, and the "too fast to be human" check ----------

function sign(text: string): string {
  // Made with the site's key kept outside the database (lib/secrets.ts).
  return signWith("form-check", text).slice(0, 32);
}

const MIN_FILL_MS = 3000; // nobody reads a form and types a message in under 3 seconds
const MAX_AGE_MS = 2 * 60 * 60 * 1000; // a form left open for hours needs a fresh check

// A signed ticket handed out with the form: when it was shown and (for the
// fallback) the answer to its sum. The answer is never sent in plain text.
export type FormCheck = { ticket: string; question?: string };

export function newFormCheck(withSum: boolean): FormCheck {
  const issued = Date.now();
  if (!withSum) return { ticket: `${issued}..${sign(`${issued}:`)}` };
  const a = 2 + crypto.randomInt(8);
  const b = 1 + crypto.randomInt(9);
  return { ticket: `${issued}..${sign(`${issued}:${a + b}`)}`, question: `What is ${a} + ${b}?` };
}

export type FormCheckResult = "ok" | "too-fast" | "expired" | "wrong-answer" | "invalid";

export function checkFormTicket(ticket: string, answer?: string): FormCheckResult {
  const [issuedText, signature] = ticket.split("..");
  const issued = Number(issuedText);
  if (!issued || !signature) return "invalid";
  const expected = sign(`${issued}:${answer === undefined ? "" : answer.trim()}`);
  const same = expected.length === signature.length && crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  if (!same) return answer === undefined ? "invalid" : "wrong-answer";
  const age = Date.now() - issued;
  if (age < MIN_FILL_MS) return "too-fast";
  if (age > MAX_AGE_MS) return "expired";
  return "ok";
}
