import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { latestOtherAction, latestOtherEdit } from "./db";
import { timeAgo } from "./format";

// Two people on the same thing. Every helper-desk and admin button that
// changes a deal, comment or member carries `seen`: when its page was shown.
// Before acting, the server asks the activity log whether anyone else acted on
// that same thing since then. If so it changes nothing and says who did what
// ("mod_sophie approved this 2 minutes ago"), on a page showing how it stands
// now; pressing the button again from there is a deliberate choice. One
// indexed lookup per press, nothing on page views.

// A form's `seen` time: an ISO time from the last day (older counts as a day
// ago; anything else, as "no check", so an old open tab still works).
export function seenFrom(formData: FormData): string | undefined {
  const raw = formData.get("seen");
  if (typeof raw !== "string" || raw.length > 40) return undefined;
  const t = Date.parse(raw);
  if (!Number.isFinite(t) || t > Date.now() + 60_000) return undefined;
  return new Date(Math.max(t, Date.now() - 24 * 60 * 60 * 1000)).toISOString();
}

// For pages: the time to put in their forms' `seen` field.
export function seenNow(): string {
  return new Date().toISOString();
}

// How each action reads after a name: "mod_sophie approved it".
const DONE: Record<string, string> = {
  "deal.approve": "approved it",
  "deal.reject": "rejected it",
  "deal.takedown": "took it down",
  "deal.restore": "restored it",
  "deal.edit": "fixed it",
  "deal.ended": "marked it as ended",
  "deal.unended": "cleared its ended reports",
  "deal.labels": "checked its type and brand",
  "deal.delete": "deleted it",
  "comment.delete": "deleted it",
  "comment.dismiss": "dismissed its reports",
  "profile.clean": "cleaned up this profile",
  "profile.dismiss": "dismissed these reports",
  "escalation.resolve": "resolved it",
};

export const DEAL_ACTIONS = ["deal.approve", "deal.reject", "deal.takedown", "deal.restore", "deal.edit", "deal.ended", "deal.unended", "deal.labels", "deal.delete"];

export type Clash = { username: string; did: string; at: string };

// `label` names the thing on a list page: "“Air fryer”: mod_sophie approved
// it 2 minutes ago, so nothing was changed."
export function clashText(c: Clash, tail = "so nothing was changed. Here's how it stands now.", label?: string): string {
  return `${label ? `“${label}”: ` : ""}${c.username} ${c.did} ${timeAgo(c.at)}, ${tail}`;
}

// Did anyone else act on this deal since `seen`: staff or helpers (the
// activity log) or its poster editing it (their edits aren't logged there)?
export function dealClash(slug: string, seen: string | undefined, actorId: string): Clash | undefined {
  if (!seen) return undefined;
  const logged = latestOtherAction(slug, seen, actorId, DEAL_ACTIONS);
  const edit = latestOtherEdit(slug, seen, actorId);
  const latest = [logged && { username: logged.username, did: DONE[logged.action] ?? "changed it", at: logged.at }, edit && { username: edit.username, did: "edited it", at: edit.at }]
    .filter((c): c is Clash => !!c)
    .sort((a, b) => b.at.localeCompare(a.at))[0];
  return latest;
}

// The same for a comment's or member's moderation (keyed by the member's id).
export function targetClash(targetId: string, seen: string | undefined, actorId: string, actions: string[]): Clash | undefined {
  if (!seen) return undefined;
  const hit = latestOtherAction(targetId, seen, actorId, actions);
  return hit && { username: hit.username, did: DONE[hit.action] ?? "dealt with it", at: hit.at };
}

// Back to the page the button was on (same site, under /admin or /helper
// only), with the message shown at its top as ?clash=.
export async function bounceWithClash(message: string, fallback: string): Promise<never> {
  const referer = (await headers()).get("referer");
  let path = fallback;
  if (referer) {
    try {
      const url = new URL(referer);
      if (/^\/(admin|helper)(\/|$)/.test(url.pathname)) {
        for (const k of ["clash", "notice", "error", "done", "deal", "saved"]) url.searchParams.delete(k);
        path = `${url.pathname}${url.search}`;
      }
    } catch {
      // keep the fallback
    }
  }
  redirect(`${path}${path.includes("?") ? "&" : "?"}clash=${encodeURIComponent(message.slice(0, 300))}`);
}
