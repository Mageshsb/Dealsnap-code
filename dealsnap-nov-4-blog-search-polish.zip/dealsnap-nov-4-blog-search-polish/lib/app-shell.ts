import { headers } from "next/headers";

// The phone apps (mobile/) show this site inside a native shell, and add
// "DealSnapApp/1" to every request's browser name (mobile/capacitor.config.ts).
// Pages use it for the few things that differ in the app: room for the
// phone's status bar, and no Google sign-in (Google doesn't allow it inside
// apps, and Apple would then also want Sign in with Apple).
export const APP_USER_AGENT = "DealSnapApp/";

export async function isInApp(): Promise<boolean> {
  return ((await headers()).get("user-agent") ?? "").includes(APP_USER_AGENT);
}
