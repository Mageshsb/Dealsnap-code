import type { AffiliateProgramme } from "./db";
import type { SiteSettings } from "./site-settings";

// Turns a deal's shop link into one that earns DealSnap a commission, on the
// way out through /go/<deal>. The deal itself keeps the shop's plain link, so
// a change of network applies to every deal at once. Set up in Admin →
// Settings → Affiliate links, and used in this order:
//   - the shop's own programme, if it has one (an Awin merchant ID, or any
//     network's link), which usually pays more than a catch-all network
//   - Amazon links get our Amazon Associates tag (replacing any tag a poster
//     added, so nobody can earn from their own posts on our site)
//   - every other link goes through Skimlinks, which earns from thousands of
//     UK shops (it passes links straight through for shops it doesn't cover)
//   - or, instead of Skimlinks, any network that takes a link with {url} in it
// With nothing set up, people go straight to the shop as before.
//
// Each click carries a reference to the deal ({ref} in a network's link,
// Awin's clickref, Skimlinks' xcust), so the networks' reports show which
// deals earn.

function isAmazon(host: string): boolean {
  return /(^|\.)amazon\.(co\.uk|com|de|fr|it|es|ie)$/i.test(host);
}

// Networks cap their reference at about 50 characters. A deal's slug ends
// with its own short ID ("…-graphite-b740f1"), so a long one keeps its start
// and that ending.
export function dealRef(slug: string): string {
  return slug.length <= 50 ? slug : `${slug.slice(0, 43)}-${slug.slice(-6)}`;
}

// The shop's own programme: the one for its domain, or a domain it's part of
// ("argos.co.uk" covers "www.argos.co.uk"). One stopped in Admin doesn't
// count, so its clicks go through the catch-all network.
function programmeFor(host: string, programmes: AffiliateProgramme[]): AffiliateProgramme | undefined {
  const h = host.toLowerCase();
  return programmes.find((p) => !p.stopped && (h === p.domain || h.endsWith(`.${p.domain}`)));
}

const fill = (template: string, url: string, ref: string) =>
  template.replace("{url}", encodeURIComponent(url)).replace("{ref}", encodeURIComponent(ref));

export function affiliateUrl(raw: string, settings: SiteSettings, dealSlug: string, programmes: AffiliateProgramme[] = []): string {
  let url: URL;
  try {
    url = new URL(unwrapLink(raw));
  } catch {
    return raw;
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") return raw;
  const ref = dealRef(dealSlug);

  if (isAmazon(url.hostname)) {
    url.searchParams.delete("tag");
    url.searchParams.delete("ascsubtag");
  }
  const clean = url.toString();

  const own = programmeFor(url.hostname, programmes);
  if (own?.network === "awin" && own.merchantId && settings.awinPublisherId) {
    const params = new URLSearchParams({ awinmid: own.merchantId, awinaffid: settings.awinPublisherId, clickref: ref, ued: clean });
    return `https://www.awin1.com/cread.php?${params}`;
  }
  if (own?.network === "link" && own.template?.includes("{url}")) return fill(own.template, clean, ref);

  if (isAmazon(url.hostname) && settings.amazonTag) {
    url.searchParams.set("tag", settings.amazonTag);
    return url.toString();
  }
  // (No Amazon tag: the general network below has a go instead.)
  if (settings.skimlinksId) {
    const params = new URLSearchParams({ id: settings.skimlinksId, xs: "1", url: clean, xcust: ref });
    return `https://go.skimresources.com/?${params}`;
  }
  if (settings.affiliateLinkTemplate.includes("{url}")) return fill(settings.affiliateLinkTemplate, clean, ref);
  return clean;
}

// How a link's clicks earn, as affiliateUrl would send them: the store's own
// programme, the Amazon tag, the catch-all network, or not at all (Admin →
// Insights, for which stores to apply to next).
export type EarningRoute = "own" | "amazon" | "catch-all" | "none";

export function earningRoute(raw: string, settings: SiteSettings, programmes: AffiliateProgramme[] = []): EarningRoute {
  let host: string;
  try {
    host = new URL(unwrapLink(raw)).hostname;
  } catch {
    return "none";
  }
  const own = programmeFor(host, programmes);
  if ((own?.network === "awin" && own.merchantId && settings.awinPublisherId) || (own?.network === "link" && own.template?.includes("{url}"))) {
    return "own";
  }
  if (isAmazon(host) && settings.amazonTag) return "amazon";
  if (settings.skimlinksId || settings.affiliateLinkTemplate.includes("{url}")) return "catch-all";
  return "none";
}

// ---------------------------------------------------------------------------
// Someone else's affiliate or redirect link
// ---------------------------------------------------------------------------

// Members often paste a link that goes through someone's affiliate network,
// or a search engine's or social site's redirect, before the shop
// ("awin1.com/cread.php?…&ued=<the shop's link>"). The shop's own link is
// inside it, and is taken out, so the deal is filed under the right shop, a
// repost is spotted, and nobody else earns from clicks here. Only for these
// redirect addresses, as plenty of shops' own links have a "url=" of their own.
const CJ_HOSTS = /(^|\.)(anrdoezrs\.net|jdoqocy\.com|tkqlhce\.com|dpbolvw\.net|kqzyfj\.com)$/;
const WRAPPERS: [RegExp, string[]][] = [
  [/(^|\.)awin1\.com$/, ["ued", "p"]],
  [/(^|\.)(skimresources|redirectingat)\.com$/, ["url"]],
  [/(^|\.)linksynergy\.com$/, ["murl", "RD_PARM1"]],
  [/(^|\.)viglink\.com$/, ["u", "out"]],
  [/(^|\.)webgains\.com$/, ["wgtarget"]],
  [/(^|\.)tradedoubler\.com$/, ["url"]],
  // Impact's and CJ's shop-branded link addresses
  [/(^|\.)(sjv\.io|pxf\.io|ojrq\.net|evyy\.net|7eer\.net|r8lw\.net)$/, ["u"]],
  [CJ_HOSTS, ["url"]],
  [/^(l|lm)\.facebook\.com$/, ["u"]],
  [/^l\.instagram\.com$/, ["u"]],
  [/(^|\.)google\.[a-z.]+$/, ["url", "q"]],
];

function webLink(text: string | null | undefined): URL | undefined {
  if (!text) return undefined;
  try {
    const url = new URL(/^https?%3A/i.test(text) ? decodeURIComponent(text) : text);
    return url.protocol === "https:" || url.protocol === "http:" ? url : undefined;
  } catch {
    return undefined;
  }
}

function unwrapOnce(url: URL): URL | undefined {
  const host = url.hostname.toLowerCase();
  // Partnerize puts the shop's link in the path ("…/destination:<link>"),
  // and so can CJ ("…/type/dlg/<link>").
  const inPath =
    host === "prf.hn" || host.endsWith(".prf.hn")
      ? url.pathname.match(/\/destination:(.+)$/)?.[1]
      : CJ_HOSTS.test(host)
        ? url.href.match(/\/dlg\/(https?.+)$/i)?.[1]
        : undefined;
  const fromPath = webLink(inPath);
  if (fromPath) return fromPath;
  // (A search engine's own pages aren't redirects, only its /url.)
  if (/(^|\.)google\.[a-z.]+$/.test(host) && url.pathname !== "/url") return undefined;
  for (const name of WRAPPERS.find(([re]) => re.test(host))?.[1] ?? []) {
    const found = webLink(url.searchParams.get(name));
    if (found) return found;
  }
  return undefined;
}

// The shop's own link from inside any of the redirects above (they can be
// nested), or the link as it was.
export function unwrapLink(raw: string): string {
  let url: URL;
  try {
    url = new URL(raw.trim());
  } catch {
    return raw;
  }
  for (let depth = 0; depth < 3; depth++) {
    const inner = unwrapOnce(url);
    if (!inner) break;
    url = inner;
  }
  return url.toString();
}

// Checks for what an admin types in.
export const AMAZON_TAG_PATTERN = /^[A-Za-z0-9][A-Za-z0-9-]{1,38}-2[0-9]$/;
export const SKIMLINKS_ID_PATTERN = /^[0-9]{3,10}X[0-9]{3,10}$/i;
export const AWIN_ID_PATTERN = /^[0-9]{2,10}$/;

export function validLinkTemplate(template: string): boolean {
  return /^https:\/\/[^\s]+$/i.test(template) && template.includes("{url}");
}

// "https://www.argos.co.uk/some/page" → "argos.co.uk".
export function programmeDomain(text: string): string | undefined {
  const t = text.trim().toLowerCase();
  if (!t) return undefined;
  try {
    const host = new URL(/^https?:\/\//.test(t) ? t : `https://${t}`).hostname.replace(/^www\./, "");
    return /^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(host) ? host : undefined;
  } catch {
    return undefined;
  }
}
