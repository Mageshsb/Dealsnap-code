"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { requirePermission } from "./auth";
import { logAudit } from "./audit";
import {
  clearCampaignImage,
  deleteAdvertiser,
  deleteCampaign,
  duplicateCampaign,
  findAdvertiserByName,
  getCampaigns,
  getAdvertiser,
  getCampaign,
  saveAdSlotSettings,
  saveAdvertiser,
  saveCampaign,
  deleteMediaKit,
  getMediaKit,
  saveMediaKit,
  setMediaKitLink,
  setCampaignImage,
  setCampaignReportKey,
  setCampaignStatus,
  setSiteSetting,
} from "./db";
import { PromoImageError, cleanPromoImage } from "./promo-images";
import { overLimit } from "./rate-limit";
import { getCategoryGroups } from "./categories";
import { slugify } from "./slug";
import { getDealBySlug } from "./mock-deals";
import { KIT_DAYS_DEFAULT } from "./media-kit";
import { ukDay } from "./events";
import { ADS_PREVIEW_COOKIE, flushAdCounts, forgetAdSettings, getAdSettings, type AdSettings } from "./ad-serving";
import {
  AD_PAGE_KINDS,
  AD_SCOPES,
  AD_SLOTS,
  AD_TARGETED_SCOPES,
  AD_TEXT,
  MAX_EVERY,
  MAX_FIRST,
  MAX_PER_PAGE,
  adSlot,
  checkAdsTxt,
  isPagePath,
  minEvery,
  minFirst,
  networkSlots,
  rivalsOf,
  slotName,
  type AdSlotId,
  type CampaignKind,
  isAdSlotId,
  isAdUnitPath,
  isNetworkCode,
  type AdScope,
  type CampaignStatus,
} from "./ads";

// Admin → Ads. Everything here is money, so it needs ads.manage (admins
// only). Words are plain text (pages draw them as text, never HTML); a link
// must be a page on the site or an https address; pictures are opened and
// saved again as clean WebP; network codes and ads.txt lines are checked
// against their exact formats. Every change goes in the activity log.
const DAY = /^\d{4}-\d{2}-\d{2}$/;
const isDay = (v: string) => DAY.test(v) && !Number.isNaN(Date.parse(`${v}T12:00:00Z`));
const TARGET = /^[a-z0-9][a-z0-9-]{0,79}$/;

function isAdLink(v: string): boolean {
  if (v.startsWith("/")) return !v.startsWith("//") && !/[\s\\]/.test(v);
  try {
    const u = new URL(v);
    return u.protocol === "https:" && !!u.hostname.includes(".") && !u.username && !u.password && !/\s/.test(v);
  } catch {
    return false;
  }
}

const text = (formData: FormData, name: string, max: number) =>
  String(formData.get(name) ?? "")
    .replace(/[\u0000-\u001f\u007f]/g, " ")
    .trim()
    .slice(0, max);

const whole = (v: FormDataEntryValue | null, min: number, max: number, fallback: number) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) && String(v ?? "").trim() !== "" ? Math.min(max, Math.max(min, n)) : fallback;
};

function done() {
  revalidatePath("/", "layout");
}

// A deal's address name from a pasted link ("https://…/deals/sony-tv-12?x" →
// "sony-tv-12"), or the name itself.
function dealSlugFrom(v: string): string | undefined {
  const m = v.trim().match(/(?:\/deals\/)?([a-z0-9][a-z0-9-]{0,199})\/?(?:[?#].*)?$/i);
  return m ? m[1].toLowerCase() : undefined;
}

export async function saveCampaignAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const id = String(formData.get("id") ?? "") || undefined;
  const existing = id ? getCampaign(id) : undefined;
  if (id && !existing) redirect("/admin/ads/campaigns");
  // An ad, or a sponsored deal (fixed once made).
  const kind: CampaignKind = existing?.kind ?? (formData.get("kind") === "deal" ? "deal" : "ad");
  const back = existing ? `/admin/ads/${existing.id}` : `/admin/ads/new${kind === "deal" ? "?kind=deal" : ""}`;
  const fail = (msg: string): never => redirect(`${back}${back.includes("?") ? "&" : "?"}error=${encodeURIComponent(msg)}`);

  // Who it's for: one already on the list, or a new one by name.
  let advertiserId = String(formData.get("advertiserId") ?? "");
  const newAdvertiser = text(formData, "newAdvertiser", AD_TEXT.name);
  if (advertiserId === "new" || !advertiserId) {
    if (!newAdvertiser) fail("Pick the advertiser, or type a new one's name.");
    advertiserId = findAdvertiserByName(newAdvertiser)?.id ?? "";
  } else if (!getAdvertiser(advertiserId)) {
    fail("That advertiser isn't on the list any more.");
  }

  const name = text(formData, "name", AD_TEXT.name);
  const shownName = text(formData, "shownName", AD_TEXT.advertiser);
  // A sponsored deal: the deal's link (or just its address name).
  const dealSlug = kind === "deal" ? dealSlugFrom(text(formData, "deal", 500)) : undefined;
  const sponsored = dealSlug ? getDealBySlug(dealSlug) : undefined;
  if (kind === "deal" && (!sponsored || (sponsored.status ?? "live") !== "live")) {
    fail("Paste the link of a live deal on DealSnap, like https://dealsnap.co.uk/deals/…");
  }
  const headline = kind === "deal" ? sponsored!.title.slice(0, AD_TEXT.headline) : text(formData, "headline", AD_TEXT.headline);
  const body = kind === "deal" ? "" : text(formData, "body", AD_TEXT.body);
  const ctaLabel = kind === "deal" ? "Get deal" : text(formData, "ctaLabel", AD_TEXT.cta);
  const linkUrl = kind === "deal" ? `/deals/${dealSlug}` : text(formData, "linkUrl", 500);
  const slots = kind === "deal" ? (["sponsored"] as AdSlotId[]) : formData.getAll("slots").filter((v) => isAdSlotId(v) && v !== "sponsored");
  const rawScope = String(formData.get("scope") ?? "all");
  const scope: AdScope = AD_SCOPES.find((s) => s.value === rawScope)?.value ?? "all";
  const target = AD_TARGETED_SCOPES.includes(scope) ? text(formData, "target", 80).toLowerCase() : "";
  // A house ad (the site's own promo) is free and has no views goal; a sponsored
  // deal can't be one (it's always a store paying).
  const priority = formData.get("priority") === "sponsorship" ? "sponsorship" : formData.get("priority") === "house" && kind === "ad" ? "house" : "standard";
  const startsOn = text(formData, "startsOn", 10);
  const endsOn = text(formData, "endsOn", 10);
  const goalText = text(formData, "goal", 12).replace(/[,\s]/g, "");
  const goal = goalText && priority !== "house" ? Math.round(Number(goalText)) : undefined;
  const pricing = priority === "house" ? "none" : ((["cpm", "flat", "none"] as const).find((p) => p === formData.get("pricing")) ?? "cpm");
  const priceText = text(formData, "price", 12).replace(/[£,\s]/g, "");
  const price = priceText ? Number(priceText) : 0;

  if (formData.get("rulesOk") !== "on") fail("Tick the box to say you've checked the ad is allowed.");
  if (!name) fail("Give the campaign a name (only staff see it), like “Currys TVs, November”.");
  if (!shownName) fail("Say who the ad is from, as visitors will see it, like “Currys”.");
  if (!headline) fail("Write the headline.");
  if (!ctaLabel) fail("Say what the button should read, like “Shop now”.");
  if (!isAdLink(linkUrl)) fail("The link should be a web address starting with https:// (or a page on the site, starting with /).");
  if (!slots.length) fail("Tick at least one place for it to show.");
  if (target && !TARGET.test(target)) fail("The page's address name can only use letters, numbers and dashes, like “currys”.");
  if ((startsOn && !isDay(startsOn)) || (endsOn && !isDay(endsOn))) fail("Those dates don't look right.");
  if (startsOn && endsOn && endsOn < startsOn) fail("It can't end before it starts.");
  if (goal !== undefined && (!Number.isFinite(goal) || goal < 100 || goal > 1_000_000_000)) fail("The views goal should be a number from 100 up (or left empty for no limit).");
  if (pricing !== "none" && (!Number.isFinite(price) || price <= 0 || price > 1_000_000)) fail("The price should be an amount in pounds, like 6.50.");

  // Pictures are checked and cleaned before anything is saved, so a bad one
  // leaves the campaign as it was.
  const pictures: { slot: "image" | "logo"; data: Buffer }[] = [];
  for (const slot of kind === "ad" ? (["image", "logo"] as const) : []) {
    const file = formData.get(slot);
    if (!(file instanceof File) || file.size === 0) continue;
    if (await overLimit("promo-picture", 20)) fail("That's a lot of pictures in a minute. Wait a moment and try again.");
    try {
      pictures.push({ slot, data: await cleanPromoImage(Buffer.from(await file.arrayBuffer()), slot) });
    } catch (e) {
      fail(e instanceof PromoImageError ? e.message : "We couldn't use that picture. Please try another.");
    }
  }

  if (!advertiserId) advertiserId = saveAdvertiser({ name: newAdvertiser, contact: "", notes: "" });
  const savedId = saveCampaign({
    id,
    kind,
    dealSlug,
    reportCosts: formData.get("reportCosts") === "on",
    advertiserId,
    name,
    status: existing?.status ?? "draft",
    slots,
    scope,
    target,
    startsOn: startsOn || undefined,
    endsOn: endsOn || undefined,
    goal,
    pacing: formData.get("pacing") === "fast" ? "fast" : "even",
    priority,
    weight: whole(formData.get("weight"), 1, 10, 5),
    pricing,
    pricePence: pricing === "none" ? 0 : Math.round(price * 100),
    shownName,
    headline,
    body: body || undefined,
    ctaLabel,
    linkUrl,
  });
  for (const p of pictures) setCampaignImage(savedId, p.slot, p.data, "image/webp");
  for (const slot of ["image", "logo"] as const) {
    if (existing && !pictures.some((p) => p.slot === slot) && formData.get(`remove-${slot}`) === "on") clearCampaignImage(savedId, slot);
  }
  logAudit(admin, "ad.change", { label: name.slice(0, 60), targetId: savedId, detail: existing ? "Edited" : "Created" });
  done();
  const saved = getCampaign(savedId);
  const headsUp = saved ? overlapNotice(saved) : "";
  redirect(
    `/admin/ads/${savedId}?notice=${encodeURIComponent(`${existing ? "Saved." : "Saved as a draft. It isn't showing yet: put it live when you're ready."}${headsUp}`)}`,
  );
}

// A sentence for the team when a campaign shares spaces, dates and pages with
// others booked in already: a sponsorship pushes the others out, and one
// pushed out by a sponsorship won't show. Drafts aren't counted (nothing is
// booked yet), and neither is a house ad.
function overlapNotice(c: NonNullable<ReturnType<typeof getCampaign>>): string {
  const rivals = rivalsOf(c, getCampaigns(), ukDay()).filter((r) => r.campaign.status !== "draft" && r.effect !== "backfill" && r.effect !== "shares");
  const names = (list: typeof rivals) => {
    const shown = list.slice(0, 3).map((r) => `“${r.campaign.name.slice(0, 40)}”`).join(", ");
    return list.length > 3 ? `${shown} and ${list.length - 3} more` : shown;
  };
  const pushed = rivals.filter((r) => r.effect === "outranked");
  const pushing = rivals.filter((r) => r.effect === "outranks");
  const where = (list: typeof rivals) => [...new Set(list.flatMap((r) => r.slots))].map(slotName).slice(0, 3).join(", ");
  let out = "";
  if (pushed.length && c.priority === "sponsorship") out += ` Heads up: as a sponsorship it takes ${where(pushed)} from ${names(pushed)} while their dates overlap.`;
  if (pushing.length) out += ` Heads up: ${names(pushing)} has ${where(pushing)} to itself over these dates, so this one won't show there.`;
  return out;
}

export async function duplicateCampaignAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const campaign = getCampaign(String(formData.get("id") ?? ""));
  if (!campaign) redirect("/admin/ads/campaigns");
  const copy = duplicateCampaign(campaign.id);
  if (!copy) redirect("/admin/ads/campaigns");
  logAudit(admin, "ad.change", { label: campaign.name.slice(0, 60), targetId: copy, detail: "Copied as a draft" });
  done();
  redirect(`/admin/ads/${copy}?notice=${encodeURIComponent("Copied as a draft, with its pictures. Set its dates, check it, then put it live.")}`);
}

const STATUS_WORDS: Record<CampaignStatus, { log: string; notice: string }> = {
  live: { log: "Put live", notice: "It's live." },
  paused: { log: "Paused", notice: "Paused. It stops showing straight away." },
  archived: { log: "Archived", notice: "Archived. Its report is kept." },
  draft: { log: "Back to draft", notice: "Back to draft." },
};

export async function setCampaignStatusAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const campaign = getCampaign(String(formData.get("id") ?? ""));
  if (!campaign) redirect("/admin/ads/campaigns");
  const status = (["live", "paused", "archived", "draft"] as const).find((s) => s === formData.get("status"));
  if (!status) redirect(`/admin/ads/${campaign.id}`);
  setCampaignStatus(campaign.id, status);
  logAudit(admin, "ad.change", { label: campaign.name.slice(0, 60), targetId: campaign.id, detail: STATUS_WORDS[status].log });
  done();
  const back = formData.get("back") === "list" ? "/admin/ads/campaigns" : `/admin/ads/${campaign.id}`;
  redirect(`${back}?notice=${encodeURIComponent(STATUS_WORDS[status].notice)}`);
}

export async function deleteCampaignAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const campaign = getCampaign(String(formData.get("id") ?? ""));
  if (!campaign) redirect("/admin/ads/campaigns");
  flushAdCounts();
  deleteCampaign(campaign.id);
  logAudit(admin, "ad.delete", { label: campaign.name.slice(0, 60), targetId: campaign.id });
  done();
  redirect(`/admin/ads/campaigns?notice=${encodeURIComponent("Deleted the campaign and its report.")}`);
}

export async function saveAdvertiserAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const id = String(formData.get("id") ?? "") || undefined;
  if (id && !getAdvertiser(id)) redirect("/admin/ads/advertisers");
  const name = text(formData, "name", AD_TEXT.name);
  const fail = (msg: string): never => redirect(`/admin/ads/advertisers?error=${encodeURIComponent(msg)}`);
  if (!name) fail("Give the advertiser a name.");
  const clash = findAdvertiserByName(name);
  if (clash && clash.id !== id) fail(`“${clash.name}” is already on the list.`);
  const saved = saveAdvertiser({ id, name, contact: text(formData, "contact", 200), notes: text(formData, "notes", 1000) });
  logAudit(admin, "advertiser.change", { label: name.slice(0, 60), targetId: saved, detail: id ? "Edited" : "Added" });
  redirect(`/admin/ads/advertisers?notice=${encodeURIComponent(id ? "Saved." : `Added ${name}.`)}`);
}

export async function deleteAdvertiserAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const advertiser = getAdvertiser(String(formData.get("id") ?? ""));
  if (!advertiser) redirect("/admin/ads/advertisers");
  if (!deleteAdvertiser(advertiser.id)) {
    redirect(`/admin/ads/advertisers?error=${encodeURIComponent("They still have campaigns. Delete those first (or keep them, for their reports).")}`);
  }
  logAudit(admin, "advertiser.change", { label: advertiser.name.slice(0, 60), targetId: advertiser.id, detail: "Deleted" });
  redirect(`/admin/ads/advertisers?notice=${encodeURIComponent(`Deleted ${advertiser.name}.`)}`);
}

// A space's saved settings as they stand, to change one part of.
function slotRows(change: (id: AdSlotId, now: AdSettings["slots"][AdSlotId]) => Partial<AdSettings["slots"][AdSlotId]> & { enabled?: boolean }) {
  const current = getAdSettings();
  return AD_SLOTS.map((def) => {
    const now = current.slots[def.id];
    const next = { ...now, ...change(def.id, now) };
    return {
      id: def.id,
      enabled: next.enabled,
      first: def.repeats ? next.first : undefined,
      every: def.repeats ? next.every : undefined,
      max: def.repeats ? next.max : undefined,
      screens: def.screenChoice ? next.screens : undefined,
      cond: def.condition ? next.cond : undefined,
      size: def.size ? next.size : undefined,
      unit: next.unit,
    };
  });
}

// The master switch on its own (the Overview's button).
export async function setAdsOnAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const on = formData.get("on") === "1";
  setSiteSetting("ads_on", on ? "1" : "0");
  forgetAdSettings();
  logAudit(admin, "ad.settings", { label: "Ad spaces", detail: on ? "Ads on" : "Ads off" });
  done();
  redirect(`/admin/ads?notice=${encodeURIComponent(on ? "Ads are on." : "Ads are off. Nothing shows, and no ad code loads.")}`);
}

// The master switch, who sees ads, which kinds of page and which pages have
// none, and each space's on/off, screens, spacing and conditions.
export async function saveAdPlacesAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const fail = (msg: string): never => redirect(`/admin/ads/places?error=${encodeURIComponent(msg)}`);
  const known = new Set(getCategoryGroups().map((c) => slugify(c.name)));
  const blocked = formData.getAll("blocked").map(String).filter((c) => known.has(c));
  const kinds = AD_PAGE_KINDS.map((k) => k.value as string);
  const offPages = kinds.filter((k) => formData.get(`page-${k}`) !== "on");
  // Pages with no ads: one address a line, as it shows in the address bar.
  const lines = String(formData.get("blockedPaths") ?? "")
    .slice(0, 20_000)
    .split(/\r?\n/)
    .map((l) => {
      const t = l.trim().toLowerCase();
      try {
        return t.startsWith("http") ? new URL(t).pathname.replace(/\/+$/, "") : t.replace(/[?#].*$/, "").replace(/\/+$/, "");
      } catch {
        return t;
      }
    })
    .filter(Boolean);
  const bad = lines.find((l) => !isPagePath(l));
  if (bad) fail(`“${bad.slice(0, 60)}” isn't a page address. Use the part after the site's name, like /stores/currys.`);
  if (lines.length > 200) fail("Keep the list of pages with no ads to 200 or fewer.");

  setSiteSetting("ads_on", formData.get("adsOn") === "on" ? "1" : "0");
  setSiteSetting("ads_members_free", formData.get("membersFree") === "on" ? "1" : "0");
  setSiteSetting("ads_blocked_categories", JSON.stringify(blocked));
  setSiteSetting("ads_off_pages", JSON.stringify(offPages));
  setSiteSetting("ads_blocked_paths", JSON.stringify([...new Set(lines)]));
  saveAdSlotSettings(
    slotRows((id, now) => {
      const def = adSlot(id);
      const screens = formData.get(`screens-${id}`);
      return {
        enabled: formData.get(`enabled-${id}`) === "on",
        first: def.repeats ? whole(formData.get(`first-${id}`), minFirst(def), MAX_FIRST, now.first) : now.first,
        every: def.repeats ? whole(formData.get(`every-${id}`), minEvery(def), MAX_EVERY, now.every) : now.every,
        max: def.repeats ? whole(formData.get(`max-${id}`), 0, MAX_PER_PAGE, now.max) : now.max,
        screens: screens === "phones" || screens === "laptops" ? screens : "all",
        cond: def.condition ? whole(formData.get(`cond-${id}`), 0, def.condition.max, now.cond) : now.cond,
        size: formData.get(`size-${id}`) === "compact" ? "compact" : formData.get(`size-${id}`) === "standard" ? "standard" : now.size,
      };
    }),
  );
  forgetAdSettings();
  logAudit(admin, "ad.settings", { label: "Ad spaces", detail: formData.get("adsOn") === "on" ? "Ads on" : "Ads off" });
  done();
  redirect(`/admin/ads/places?notice=${encodeURIComponent("Saved.")}`);
}

export async function saveAdNetworkAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const fail = (msg: string): never => redirect(`/admin/ads/network?error=${encodeURIComponent(msg)}`);
  const network = formData.get("network") === "gam" ? "gam" : "off";
  const code = text(formData, "networkCode", 12);
  if (network === "gam" && !isNetworkCode(code)) fail("The network code is the number in your Ad Manager address, like 21234567.");
  const units: Record<string, string> = {};
  for (const s of networkSlots()) {
    const unit = text(formData, `unit-${s.id}`, 300);
    if (unit && !isAdUnitPath(unit)) fail(`The ad unit code for “${s.name}” should look like /21234567/dealsnap_${s.id.replace("-", "_")}.`);
    if (unit && code && !unit.startsWith(`/${code}/`)) fail(`The ad unit code for “${s.name}” should start with your network code, /${code}/.`);
    units[s.id] = unit;
  }
  const adsTxt = checkAdsTxt(String(formData.get("adsTxt") ?? "").slice(0, 64_000));
  if (adsTxt.errors.length) fail(`ads.txt: ${adsTxt.errors[0]}`);

  setSiteSetting("ads_network", network);
  setSiteSetting("ads_network_code", code);
  setSiteSetting("ads_personalised", formData.get("personalised") === "on" ? "1" : "0");
  setSiteSetting("ads_txt", adsTxt.clean);
  saveAdSlotSettings(slotRows((id) => ({ unit: units[id] ?? "" })));
  forgetAdSettings();
  logAudit(admin, "ad.settings", { label: "Ad network", detail: network === "gam" ? "Google Ad Manager on" : "Off" });
  done();
  redirect(`/admin/ads/network?notice=${encodeURIComponent("Saved.")}`);
}

// Staff only: show every ad space on the site, outlined and named, even with
// ads off, so placements can be checked before anything goes live. Lasts two
// hours (the site checks it's staff before drawing any outline).
export async function setAdsPreviewAction(formData: FormData) {
  await requirePermission("ads.manage");
  const jar = await cookies();
  if (formData.get("on") === "1") {
    jar.set(ADS_PREVIEW_COOKIE, "1", { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 2 * 60 * 60 });
  } else {
    jar.delete(ADS_PREVIEW_COOKIE);
  }
  done();
  redirect(formData.get("on") === "1" ? "/" : "/admin/ads/places");
}

// The advertiser's report link: "on" makes a link (a new one, if there was
// one: the old stops working), "off" stops it.
export async function setCampaignReportAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const campaign = getCampaign(String(formData.get("id") ?? ""));
  if (!campaign) redirect("/admin/ads/campaigns");
  const on = formData.get("on") === "1";
  setCampaignReportKey(campaign.id, on);
  logAudit(admin, "ad.change", {
    label: campaign.name.slice(0, 60),
    targetId: campaign.id,
    detail: on ? (campaign.reportKey ? "Made a new report link" : "Made a report link") : "Turned the report link off",
  });
  redirect(
    `/admin/ads/${campaign.id}?notice=${encodeURIComponent(on ? "The report link is ready to copy below." : "The report link is off. Anyone who had it can't open it now.")}#report-link`,
  );
}

// The public "Advertise with us" page (/advertise): on or off, its own words,
// rates, and whether it shows the site's numbers.
export async function saveAdvertisePageAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  // Off (no page), a short holding page, or the full page.
  const mode = String(formData.get("pageMode") ?? "off");
  const on = mode === "full";
  const holding = mode === "holding";
  setSiteSetting("ads_page_on", on ? "1" : "0");
  setSiteSetting("ads_page_holding", holding ? "1" : "0");
  setSiteSetting("ads_page_stats", formData.get("pageStats") === "on" ? "1" : "0");
  setSiteSetting("ads_page_intro", text(formData, "pageIntro", 600));
  setSiteSetting("ads_page_rates", String(formData.get("pageRates") ?? "").replace(/\r\n?/g, "\n").replace(/[\u0000-\u0009\u000b-\u001f\u007f]/g, " ").trim().slice(0, 1500));
  forgetAdSettings();
  logAudit(admin, "ad.settings", { label: "Advertise page", detail: on ? "Full page" : holding ? "Holding page" : "Off" });
  done();
  redirect(
    `/admin/ads/selling?notice=${encodeURIComponent(on ? "Saved. The full page is live at /advertise." : holding ? "Saved. /advertise shows the holding page." : "Saved. The page is off.")}`
  );
}

// ---------------------------------------------------------------------------
// Media kits (Admin → Ads → Selling): the kit's own words, and one private
// link per business (lib/media-kit.ts).
// ---------------------------------------------------------------------------
const EMAIL = /^[^\s@<>"]{1,64}@[^\s@<>"]{1,190}\.[a-z]{2,}$/i;
const multiline = (formData: FormData, name: string, max: number) =>
  String(formData.get(name) ?? "")
    .replace(/\r\n?/g, "\n")
    .replace(/[\u0000-\u0009\u000b-\u001f\u007f]/g, " ")
    .trim()
    .slice(0, max);

export async function saveKitSettingsAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const email = text(formData, "contactEmail", 254);
  if (email && !EMAIL.test(email)) redirect(`/admin/ads/selling?error=${encodeURIComponent("That email address doesn't look right.")}#kit-settings`);
  setSiteSetting("kit_contact_name", text(formData, "contactName", 80));
  setSiteSetting("kit_contact_email", email);
  setSiteSetting("kit_rates", multiline(formData, "rates", 2000));
  setSiteSetting("kit_terms", multiline(formData, "terms", 3000));
  setSiteSetting("kit_lead_days", String(whole(formData.get("leadDays"), 0, 30, 2)));
  logAudit(admin, "kit.change", { label: "Media kit", detail: "Changed its words" });
  redirect(`/admin/ads/selling?notice=${encodeURIComponent("Saved. Every kit link shows the change straight away.")}#kit-settings`);
}

// The fields a kit link has, checked. `fail` for a mistake.
function kitFields(formData: FormData, fail: (msg: string) => never) {
  const recipient = text(formData, "recipient", 120);
  if (!recipient) fail("Say who the kit is for, like “Currys (Jane Smith)”.");
  const noEnd = formData.get("noEnd") === "on";
  const expiresOn = text(formData, "expiresOn", 10);
  if (!noEnd && expiresOn && !isDay(expiresOn)) fail("That end date doesn't look right.");
  return {
    recipient,
    contact: text(formData, "contact", 200),
    note: multiline(formData, "note", 1000),
    rates: multiline(formData, "rates", 2000),
    showRates: formData.get("showRates") === "on",
    showStats: formData.get("showStats") === "on",
    expiresOn: noEnd ? undefined : expiresOn || ukDay(new Date(Date.now() + KIT_DAYS_DEFAULT * 86_400_000)),
  };
}

export async function createMediaKitAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const fail = (msg: string): never => redirect(`/admin/ads/selling?error=${encodeURIComponent(msg)}#new-kit`);
  const fields = kitFields(formData, fail);
  const id = saveMediaKit({ ...fields, createdBy: admin.username });
  logAudit(admin, "kit.change", { label: fields.recipient.slice(0, 60), targetId: id, detail: "Made a media kit link" });
  redirect(`/admin/ads/selling?notice=${encodeURIComponent(`The kit for ${fields.recipient} is ready: copy its link below.`)}#kit-${id}`);
}

export async function updateMediaKitAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const kit = getMediaKit(String(formData.get("id") ?? ""));
  if (!kit) redirect("/admin/ads/selling");
  const fields = kitFields(formData, (msg): never => redirect(`/admin/ads/selling?error=${encodeURIComponent(msg)}#kit-${kit.id}`));
  saveMediaKit({ ...fields, id: kit.id, createdBy: kit.createdBy });
  logAudit(admin, "kit.change", { label: fields.recipient.slice(0, 60), targetId: kit.id, detail: "Edited" });
  redirect(`/admin/ads/selling?notice=${encodeURIComponent("Saved. The same link shows the change.")}#kit-${kit.id}`);
}

export async function setMediaKitLinkAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const kit = getMediaKit(String(formData.get("id") ?? ""));
  if (!kit) redirect("/admin/ads/selling");
  const on = formData.get("on") === "1";
  setMediaKitLink(kit.id, on);
  logAudit(admin, "kit.change", { label: kit.recipient.slice(0, 60), targetId: kit.id, detail: on ? "Made a new link" : "Turned the link off" });
  redirect(
    `/admin/ads/selling?notice=${encodeURIComponent(on ? "New link ready. The old one no longer works." : "The link is off. Anyone who has it can't open it now.")}#kit-${kit.id}`,
  );
}

export async function deleteMediaKitAction(formData: FormData) {
  const admin = await requirePermission("ads.manage");
  const kit = getMediaKit(String(formData.get("id") ?? ""));
  if (!kit) redirect("/admin/ads/selling");
  deleteMediaKit(kit.id);
  logAudit(admin, "kit.change", { label: kit.recipient.slice(0, 60), targetId: kit.id, detail: "Deleted" });
  redirect(`/admin/ads/selling?notice=${encodeURIComponent("Deleted. Its link no longer works.")}#kits`);
}
