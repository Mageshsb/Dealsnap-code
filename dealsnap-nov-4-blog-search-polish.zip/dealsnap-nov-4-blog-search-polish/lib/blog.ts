import type { IconName } from "@/components/Icon";
import { slugify } from "./slug";

// What kind of post it is. Shown as a label on each post, as the topic tabs at
// the top of the blog, and as each topic's own page (/blog/topic/<slug>), which
// is what search engines index for "money saving tips" and the like. `blurb` is
// the description search engines show; `intro` is the short line under the
// page's title, kept to two lines on a phone so the page never shifts.
export const BLOG_KINDS = [
  {
    key: "guide",
    slug: "guides",
    label: "Buying guides",
    single: "Buying guide",
    icon: "compass" as IconName,
    blurb: "Plain-English guides to the things people actually shop for: what to look for, which models are worth the money, and when the price is usually lowest.",
    intro: "Plain-English guides to what to look for and when prices are lowest.",
  },
  {
    key: "tips",
    slug: "tips",
    label: "Money-saving tips",
    single: "Money-saving tip",
    icon: "lightbulb" as IconName,
    blurb: "Practical ways to pay less for everyday things, from checking whether a deal is real to cutting the weekly shop.",
    intro: "Practical ways to pay less, from spotting a real deal to cutting the weekly shop.",
  },
  {
    key: "sales",
    slug: "sales",
    label: "Sales & events",
    single: "Sales & events",
    icon: "calendar" as IconName,
    blurb: "When the big UK sales fall, what is worth waiting for and what to skip, so you buy at the right moment.",
    intro: "When the big UK sales fall, and which are worth waiting for.",
  },
  {
    key: "news",
    slug: "news",
    label: "News",
    single: "News",
    icon: "newspaper" as IconName,
    blurb: "Price changes, store news and anything else that affects what you pay.",
    intro: "Price changes, store news and anything else that affects what you pay.",
  },
] as const;

export type BlogKind = (typeof BLOG_KINDS)[number]["key"];

export function blogKind(key: string | undefined) {
  return BLOG_KINDS.find((k) => k.key === key) ?? BLOG_KINDS[1];
}

export function isBlogKind(key: string | undefined): key is BlogKind {
  return BLOG_KINDS.some((k) => k.key === key);
}

export function blogKindBySlug(slug: string | undefined) {
  return BLOG_KINDS.find((k) => k.slug === slug);
}

export const blogKindHref = (key: string | undefined) => `/blog/topic/${blogKind(key).slug}`;

// ---- the post's text -------------------------------------------------------
// Posts are written as plain text with a few simple marks (the editor lists
// them): a blank line between paragraphs, "## " for a heading, "- " for a
// bullet point, "> " for a highlighted note, a few "|" rows for a table,
// **bold**, [words](https://link), ![what it shows](picture) for a picture the
// editor uploaded, and "::deal <slug>" for a live deal card. Nothing else is
// treated as formatting, and the text is never inserted as HTML.

export type BlogBlock =
  | { type: "heading"; text: string; id: string }
  | { type: "subheading"; text: string }
  | { type: "list"; items: string[] }
  | { type: "paragraph"; text: string }
  | { type: "quote"; text: string }
  | { type: "table"; head: string[]; rows: string[][] }
  | { type: "image"; src: string; alt: string; w: number; h: number }
  | { type: "deal"; slug: string };

export const TABLE_MAX_COLS = 6;
export const TABLE_MAX_ROWS = 40;

// A picture the editor uploaded: /blog-image/<id>/<width>x<height>. Only these
// addresses are drawn, so a post can't pull in a picture from anywhere else.
const IMAGE_LINE = /^!\[([^\]]*)\]\(\/blog-image\/([0-9a-f-]{36})\/(\d{2,5})x(\d{2,5})\)$/;
const DEAL_LINE = /^::deal\s+([a-z0-9][a-z0-9-]{0,120})$/i;
const isTableLine = (l: string) => l.startsWith("|") && l.lastIndexOf("|") > 0;
const isDivider = (l: string) => /^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?$/.test(l);

export const blogImagePath = (id: string, w: number, h: number) => `/blog-image/${id}/${w}x${h}`;

function cells(line: string): string[] {
  const parts = line.split("|").map((c) => c.trim());
  if (parts[0] === "") parts.shift();
  if (parts.length && parts[parts.length - 1] === "") parts.pop();
  return parts.slice(0, TABLE_MAX_COLS);
}

export function parseBlogContent(content: string[]): BlogBlock[] {
  const blocks: BlogBlock[] = [];
  const usedIds = new Set<string>();
  for (const chunk of content) {
    const lines = chunk.split("\n").map((l) => l.trim()).filter(Boolean);
    let para: string[] = [];
    let list: string[] = [];
    let quote: string[] = [];
    let table: string[][] = [];
    const flush = () => {
      if (para.length) blocks.push({ type: "paragraph", text: para.join(" ") });
      if (list.length) blocks.push({ type: "list", items: list });
      if (quote.length) blocks.push({ type: "quote", text: quote.join(" ") });
      if (table.length >= 2) {
        const [head, ...rest] = table;
        blocks.push({ type: "table", head, rows: rest.slice(0, TABLE_MAX_ROWS).map((r) => head.map((_, i) => r[i] ?? "")) });
      } else if (table.length === 1) {
        blocks.push({ type: "paragraph", text: table[0].join(" ") });
      }
      para = [];
      list = [];
      quote = [];
      table = [];
    };
    for (const line of lines) {
      const image = IMAGE_LINE.exec(line);
      const deal = DEAL_LINE.exec(line);
      if (image) {
        flush();
        blocks.push({ type: "image", src: `/blog-image/${image[2]}/${image[3]}x${image[4]}`, alt: image[1].trim(), w: Number(image[3]), h: Number(image[4]) });
      } else if (deal) {
        flush();
        blocks.push({ type: "deal", slug: deal[1].toLowerCase() });
      } else if (line.startsWith("### ")) {
        flush();
        blocks.push({ type: "subheading", text: line.slice(4).trim() });
      } else if (line.startsWith("## ")) {
        flush();
        const text = line.slice(3).trim();
        let id = slugify(text) || "section";
        for (let n = 2; usedIds.has(id); n++) id = `${slugify(text)}-${n}`;
        usedIds.add(id);
        blocks.push({ type: "heading", text, id });
      } else if (isTableLine(line)) {
        if (para.length || list.length || quote.length) flush();
        if (!isDivider(line)) table.push(cells(line));
      } else if (line.startsWith("> ") || line === ">") {
        if (para.length || list.length || table.length) flush();
        quote.push(line.slice(1).trim());
      } else if (/^[-•*] /.test(line)) {
        if (para.length || quote.length || table.length) {
          const keep = list;
          list = [];
          flush();
          list = keep;
        }
        list.push(line.slice(2).trim());
      } else {
        if (list.length || quote.length || table.length) flush();
        para.push(line);
      }
    }
    flush();
  }
  return blocks;
}

// The words of the post with the formatting marks taken out (for reading time
// and search snippets).
export function plainBlogText(content: string): string {
  return content
    .replace(/^::deal .*$/gim, "")
    .replace(/^!\[[^\]]*\]\(\/blog-image\/[^)]*\)$/gm, "")
    .replace(/^\|?\s*:?-{2,}[-:| ]*$/gm, "")
    .replace(/^#{2,3} /gm, "")
    .replace(/^[-•*] /gm, "")
    .replace(/^> ?/gm, "")
    .replace(/\|/g, " ")
    .replace(/\*\*(.+?)\*\*/g, "$1")
    .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, "$1");
}

const DAY_MS = 24 * 60 * 60 * 1000;
// Whole days since a date, and the date (YYYY-MM-DD) n days ago.
export const daysSince = (iso: string) => Math.floor((Date.now() - new Date(iso).getTime()) / DAY_MS);
export const dayDaysAgo = (n: number) => new Date(Date.now() - n * DAY_MS).toISOString().slice(0, 10);

export const wordCount = (text: string) => text.split(/\s+/).filter(Boolean).length;

// Minutes to read at 200 words a minute, counting the box at the top and the
// picks as well as the text. Worked out when a post is saved.
export function readMinutes(content: string, takeaways: string[] = [], picks: { name: string; blurb: string }[] = []): number {
  const words = wordCount([plainBlogText(content), ...takeaways, ...picks.map((p) => `${p.name} ${p.blurb}`)].join(" "));
  return Math.max(1, Math.round(words / 200));
}

export type InlinePart = { text: string; bold?: boolean; href?: string };

// **bold** and [words](link). Links must be a web address or a page on this
// site ("/deals/…"), so nothing like "javascript:" can sneak in.
export function parseInline(text: string): InlinePart[] {
  const parts: InlinePart[] = [];
  const re = /\*\*(.+?)\*\*|\[([^\]]+)\]\(([^)\s]+)\)/g;
  let last = 0;
  for (const m of text.matchAll(re)) {
    if (m.index! > last) parts.push({ text: text.slice(last, m.index) });
    if (m[1] !== undefined) parts.push({ text: m[1], bold: true });
    else if (safeHref(m[3])) parts.push({ text: m[2], href: m[3] });
    else parts.push({ text: m[2] });
    last = m.index! + m[0].length;
  }
  if (last < text.length) parts.push({ text: text.slice(last) });
  return parts;
}

export function safeHref(href: string | undefined): boolean {
  if (!href) return false;
  return /^https?:\/\/[^\s]+$/i.test(href) || (href.startsWith("/") && !href.startsWith("//"));
}

const inlineText = (text: string) => parseInline(text).map((p) => p.text).join("");

// ---- what search engines read out of a post --------------------------------

// A "Common questions" section (a heading with "question" or "FAQ" in it, then
// a "### Question" and its answer for each) becomes FAQ data for Google, so
// the questions can show in results. Written the way posts already are; the
// editor needn't do anything.
export function faqFromBlocks(blocks: BlogBlock[]): { q: string; a: string }[] {
  const out: { q: string; a: string }[] = [];
  let inFaq = false;
  let q: string | undefined;
  let a: string[] = [];
  const close = () => {
    if (q && a.length) out.push({ q, a: a.join(" ").slice(0, 900) });
    q = undefined;
    a = [];
  };
  for (const b of blocks) {
    if (b.type === "heading") {
      close();
      inFaq = /\b(faqs?|questions?)\b/i.test(b.text);
    } else if (!inFaq) {
      continue;
    } else if (b.type === "subheading") {
      close();
      q = inlineText(b.text);
    } else if (q && b.type === "paragraph") {
      a.push(inlineText(b.text));
    } else if (q && b.type === "list") {
      a.push(b.items.map(inlineText).join(" "));
    }
  }
  close();
  return out.slice(0, 10);
}

// The deal cards a post asks for.
export const dealSlugsIn = (blocks: BlogBlock[]): string[] => [...new Set(blocks.flatMap((b) => (b.type === "deal" ? [b.slug] : [])))];

// ---- related posts ----------------------------------------------------------

const TITLE_STOP = new Set(["the", "and", "for", "how", "what", "best", "uk", "to", "a", "an", "of", "in", "on", "your", "you", "is", "it", "at", "with", "from", "every"]);
const titleWords = (t: string) => new Set(t.toLowerCase().split(/[^a-z0-9£]+/).filter((w) => w.length > 2 && !TITLE_STOP.has(w)));

type Related = { slug: string; title: string; kind: string; category: string; publishedAt: string };

// More reading: posts on the same subject first (same category, then shared
// words in the title, then the same kind), newest breaking ties, so a phone
// guide points at the earbuds guide before it points at a food-shop article.
export function relatedPosts<T extends Related>(post: Related, others: T[], n: number): T[] {
  const mine = titleWords(post.title);
  const score = (p: T) => {
    let s = 0;
    if (post.category && p.category === post.category) s += 3;
    for (const w of titleWords(p.title)) if (mine.has(w)) s += 1.5;
    if (p.kind === post.kind) s += 1;
    return s;
  };
  return others
    .filter((p) => p.slug !== post.slug)
    .map((p) => ({ p, s: score(p) }))
    .sort((a, b) => b.s - a.s || b.p.publishedAt.localeCompare(a.p.publishedAt))
    .slice(0, n)
    .map((x) => x.p);
}

// ---- the editor's checklist ---------------------------------------------------

export type BlogCheck = { ok: boolean; label: string; hint: string };

// What makes a post easy to find and worth reading. Never stops a save; it
// only says what's missing, so a half-written post is never lost.
export function blogChecks(post: { title: string; excerpt: string; content: string; takeaways: string; hasCover: boolean }): BlogCheck[] {
  const title = post.title.trim();
  const excerpt = post.excerpt.trim();
  const blocks = parseBlogContent(post.content.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean));
  const words = wordCount(plainBlogText(post.content));
  const headings = blocks.filter((b) => b.type === "heading").length;
  const inText = post.content.match(/\]\((\/[^)\s]*|https?:\/\/[^)\s]+)\)/g) ?? [];
  const onSite = inText.filter((l) => l.startsWith("](/")).length;
  const questions = faqFromBlocks(blocks).length;
  return [
    { ok: title.length >= 25 && title.length <= 65, label: "Title 25–65 characters", hint: `It is ${title.length}. Google cuts titles off at about 60.` },
    { ok: excerpt.length >= 90 && excerpt.length <= 170, label: "Summary 90–170 characters", hint: `It is ${excerpt.length}. This is the text Google shows under the title.` },
    { ok: words >= 600, label: "At least 600 words", hint: `${words} so far. Thorough posts rank better than thin ones.` },
    { ok: headings >= 3, label: "Three or more section headings", hint: "Headings make a post easy to skim and give Google its structure. Phrase some as questions." },
    { ok: onSite >= 2, label: "Links to other pages on the site", hint: "Link to a related post, a store or an alert page, at least twice." },
    { ok: questions >= 2, label: "A common questions section", hint: 'Add a "## Common questions" heading with "### Question?" lines, so the questions can show in Google.' },
    { ok: post.takeaways.trim().length > 0, label: "Key takeaways", hint: "A short box at the top for people who only skim." },
    { ok: post.hasCover, label: "A cover picture", hint: "It is also the picture in link previews." },
  ];
}
