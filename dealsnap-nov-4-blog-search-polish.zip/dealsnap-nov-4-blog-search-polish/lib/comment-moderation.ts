import { revalidatePath } from "next/cache";
import { deleteComment, getCommentForModeration, type UserRecord } from "./db";
import { logAudit } from "./audit";
import { can, mayManageComment } from "./permissions";
import { missingTwoStep } from "./staff-two-step";

// Whether someone may remove comments from the deal page: the admin area's
// own rule (moderators and admins who aren't suspended, with two-step login
// when an admin has made it a must for staff).
export function canModerateComments(user: UserRecord | null): user is UserRecord {
  if (!user || user.suspended || !can(user.role, "comments.moderate")) return false;
  return !missingTwoStep(user);
}

// The team removing a comment, from the admin area or the deal page. Only a
// comment by someone of lower rank (or their own); its replies stay, under
// "Removed by our team". Logged either way. Returns whether it went.
export function removeCommentAsTeam(actor: UserRecord, commentId: string): boolean {
  const comment = getCommentForModeration(commentId);
  if (!comment || comment.deleted || !mayManageComment(actor, comment)) return false;
  deleteComment(commentId, actor.id);
  logAudit(actor, "comment.delete", {
    targetId: comment.userId,
    label: comment.username,
    url: `/deals/${comment.dealSlug}`,
    detail: `"${comment.text.slice(0, 160)}"${comment.reportCount ? ` · had ${comment.reportCount} report${comment.reportCount === 1 ? "" : "s"}` : ""}`,
  });
  revalidatePath("/admin/comments");
  revalidatePath(`/deals/${comment.dealSlug}`);
  return true;
}
