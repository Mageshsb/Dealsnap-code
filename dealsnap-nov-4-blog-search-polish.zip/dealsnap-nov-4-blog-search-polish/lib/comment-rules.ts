// Shared by the comment box (its counter) and the server (the real check).
export const MAX_COMMENT_LENGTH = 2000;

// A comment needs this many likes before it's picked out as "Most helpful".
export const HELPFUL_LIKES = 3;

// A comment can be changed for this long after it's posted (a typo, a wrong
// price), then it's fixed, so replies and likes keep meaning what they did.
// Deleting your own comment is allowed at any time.
export const EDIT_WINDOW_MINUTES = 15;

export function editableUntil(createdAt: string): number {
  return new Date(createdAt).getTime() + EDIT_WINDOW_MINUTES * 60 * 1000;
}
