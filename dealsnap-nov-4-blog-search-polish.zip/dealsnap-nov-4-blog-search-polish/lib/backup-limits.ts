// The biggest backup file that can be uploaded for a restore, and how it's worded.
// A plain file so the upload button (in the browser) and the server share one number.
export const MAX_UPLOAD_BYTES = 1024 * 1024 * 1024;

export function sizeLabel(bytes: number): string {
  const mb = Math.round(bytes / 1048576);
  return mb >= 1024 ? `${Math.round((mb / 1024) * 10) / 10}GB` : `${mb}MB`;
}
