import type { CodeVerdict } from "./db";

// "Did this code work?": how members' answers about a deal's discount code are
// read. Shared by the deal page, the store's code list and the helper desk.

// Recent answers lean "no" (at least two in the last two days, and more than
// said yes): warn people, and put it on the helper desk to check. A helper or
// the team checking the deal after the last "no" settles it (`checkedAt`).
export function codeLooksBroken(v: CodeVerdict | undefined, checkedAt?: string): boolean {
  if (!v || v.recentFailed < 2 || v.recentFailed <= v.recentWorked) return false;
  return !(checkedAt && v.lastFailedAt && checkedAt > v.lastFailedAt);
}
