import type { AwinProductRow } from "./product-lists";

// Reading what Awin's API sends back (lib/awin.ts), kept apart from the
// fetching so it can be tested on its own (scripts/awin-test.mjs).

// ---- the stores that have accepted us ----

export type AwinProgramme = { merchantId: string; name: string; domains: string[] };

// One programme from GET /publishers/{id}/programmes: its ID, name, and the
// websites it pays for ("validDomains", plus the one it shows), as Awin
// writes them (lib/awin.ts tidies them to "argos.co.uk").
export function readProgramme(raw: unknown): AwinProgramme | undefined {
  if (!raw || typeof raw !== "object") return undefined;
  const p = raw as { id?: unknown; name?: unknown; displayUrl?: unknown; validDomains?: unknown };
  const merchantId = typeof p.id === "number" || typeof p.id === "string" ? String(p.id) : "";
  if (!/^[0-9]{1,10}$/.test(merchantId)) return undefined;
  const name = typeof p.name === "string" ? p.name.trim().slice(0, 120) : "";
  const listed = Array.isArray(p.validDomains)
    ? p.validDomains.map((d) => (d && typeof d === "object" ? (d as { domain?: unknown }).domain : undefined))
    : [];
  const domains = [...listed, p.displayUrl].filter((d): d is string => typeof d === "string" && !!d.trim()).map((d) => d.slice(0, 300));
  return { merchantId, name: name || `Awin store ${merchantId}`, domains };
}

// ---- a store's product list ----

// Awin's product lists (the "Enhanced Feed", Google's format) are JSON, one
// product a line. A field may sit at the top of the line or one level down
// (the first line also carries the store's details), so both are looked at.
function field(obj: Record<string, unknown>, name: string): unknown {
  if (obj[name] !== undefined) return obj[name];
  for (const value of Object.values(obj)) {
    if (value && typeof value === "object" && !Array.isArray(value) && (value as Record<string, unknown>)[name] !== undefined) {
      return (value as Record<string, unknown>)[name];
    }
  }
  return undefined;
}

// Stores' product names often arrive with web-page codes still in them
// ("26&#34;", "Boucl&eacute;"): turned back into the characters.
const NAMED: Record<string, string> = {
  amp: "&", quot: '"', apos: "'", lt: "<", gt: ">", nbsp: " ", pound: "£", euro: "€", trade: "™", reg: "®", copy: "©",
  ndash: "–", mdash: "—", hellip: "…", lsquo: "‘", rsquo: "’", ldquo: "“", rdquo: "”", deg: "°", times: "×", frac12: "½",
  eacute: "é", egrave: "è", ecirc: "ê", euml: "ë", aacute: "á", agrave: "à", acirc: "â", auml: "ä", aring: "å", ccedil: "ç",
  iacute: "í", icirc: "î", iuml: "ï", ntilde: "ñ", oacute: "ó", ocirc: "ô", ouml: "ö", oslash: "ø", uacute: "ú", ucirc: "û",
  uuml: "ü", szlig: "ß", Eacute: "É", Ouml: "Ö", Uuml: "Ü", Auml: "Ä",
};
// Some arrive coded twice ("&amp;amp;") or title-cased ("&Amp;"), so it
// goes round until nothing changes (at most three times).
export function decodeEntities(text: string): string {
  for (let pass = 0; pass < 3; pass++) {
    const next = text.replace(/&(#x[0-9a-f]{1,6}|#[0-9]{1,7}|[a-z][a-z0-9]{1,8});/gi, (whole, code: string) => {
      if (code[0] !== "#") return NAMED[code] ?? NAMED[code.toLowerCase()] ?? whole;
      const n = code[1] === "x" || code[1] === "X" ? parseInt(code.slice(2), 16) : parseInt(code.slice(1), 10);
      return n > 0 && n <= 0x10ffff && (n < 0xd800 || n > 0xdfff) ? String.fromCodePoint(n) : whole;
    });
    if (next === text) break;
    text = next;
  }
  return text;
}

const text = (v: unknown, max: number) => (typeof v === "string" && v.trim() ? v.trim().slice(0, max) : undefined);

// "15.00 GBP", "1,299.00 GBP" (or a plain number) in pounds; nothing in
// another currency.
export function readPounds(v: unknown): number | undefined {
  if (typeof v === "number") return Number.isFinite(v) && v >= 0 && v < 1_000_000 ? Math.round(v * 100) / 100 : undefined;
  if (typeof v !== "string") return undefined;
  const m = v.trim().replace(/,/g, "").match(/^£?\s*([0-9]+(?:\.[0-9]{1,2})?)\s*(GBP)?$/i);
  return m ? readPounds(Number(m[1])) : undefined;
}

// What a line that isn't a product says: the download stopped part way
// ({"error": 500, "message": …} as the last line).
export function feedError(obj: unknown): string | undefined {
  if (!obj || typeof obj !== "object") return undefined;
  const e = obj as { error?: unknown; message?: unknown };
  return typeof e.error === "number" ? `Awin stopped the download part way (${e.error}${typeof e.message === "string" ? `: ${e.message.slice(0, 100)}` : ""}).` : undefined;
}

// One line of a product list as what the post form needs, found later by
// keyOf(the product's link): the store's product number, or the tidied link.
// Nothing for a line without a link and a name.
export function readFeedProduct(obj: unknown, keyOf: (link: string) => string | undefined): AwinProductRow | undefined {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return undefined;
  const o = obj as Record<string, unknown>;
  const link = text(field(o, "link"), 2000) ?? text(field(o, "mobile_link"), 2000);
  const named = text(field(o, "title"), 1000);
  const title = named && decodeEntities(named).slice(0, 300);
  if (!link || !title) return undefined;
  const key = keyOf(link);
  if (!key) return undefined;
  const full = readPounds(field(o, "price"));
  const sale = readPounds(field(o, "sale_price"));
  const onSale = sale !== undefined && full !== undefined && sale < full;
  const image = text(field(o, "image_link"), 1000);
  return {
    key,
    title,
    price: onSale ? sale : (full ?? sale),
    was: onSale ? full : undefined,
    image: image && /^https:\/\//i.test(image) ? image : undefined,
    brand: text(field(o, "brand"), 100),
    inStock: field(o, "availability") !== "out_of_stock",
  };
}

// ---- Create-a-Feed: Awin's standard product lists ----

// The download link Awin's Create-a-Feed makes (Toolbox → Create-a-Feed),
// pasted into Admin. It holds our product-list key, the columns, format and
// compression chosen there, and one store's feed ID ("/fid/1234/"), which is
// swapped for each store's own. Only ever Awin's own product-data addresses.
const FEED_HOSTS = new Set(["productdata.awin.com", "datafeed.api.productserve.com"]);

export type FeedLink = { href: string; key: string; delimiter: string; gzip: boolean };

export function readFeedLink(text: string): FeedLink | undefined {
  let url: URL;
  try {
    url = new URL(text.trim());
  } catch {
    return undefined;
  }
  if (url.protocol !== "https:" || !FEED_HOSTS.has(url.hostname) || url.search || url.hash) return undefined;
  const key = url.pathname.match(/\/apikey\/([A-Za-z0-9]{8,100})(\/|$)/)?.[1];
  if (!key || !/\/fid\/[0-9%C,]+(\/|$)/i.test(url.pathname)) return undefined;
  const compression = url.pathname.match(/\/compression\/([a-z]+)(\/|$)/i)?.[1]?.toLowerCase();
  // (Zip holds a folder of files, which isn't worth unpacking here: gzip or none.)
  if (compression && compression !== "gzip" && compression !== "none") return undefined;
  const format = url.pathname.match(/\/format\/([a-z]+)(\/|$)/i)?.[1]?.toLowerCase();
  if (format && format !== "csv") return undefined;
  const delimiter = decodeURIComponent(url.pathname.match(/\/delimiter\/([^/]+)/)?.[1] ?? "%2C");
  if (delimiter.length !== 1) return undefined;
  return { href: url.href, key, delimiter, gzip: compression === "gzip" };
}

// The same link for these feeds instead.
export function feedLinkFor(link: FeedLink, feedIds: string[]): string {
  return link.href.replace(/\/fid\/[0-9%C,]+/i, `/fid/${feedIds.join("%2C")}`);
}

// The list of feeds the key can see.
export function feedListLink(link: FeedLink): string {
  return `https://productdata.awin.com/datafeed/list/apikey/${link.key}`;
}

// CSV, read a piece at a time as it downloads: quoted fields can hold the
// delimiter, line breaks and doubled quotes, and may be split across pieces.
export class CsvReader {
  private field = "";
  private row: string[] = [];
  private inQuotes = false;
  private quoteSeen = false;
  private delimiter: string;
  private maxField: number;
  constructor(delimiter = ",", maxField = 20_000) {
    this.delimiter = delimiter;
    this.maxField = maxField;
  }

  push(text: string): string[][] {
    const rows: string[][] = [];
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (this.quoteSeen) {
        this.quoteSeen = false;
        if (c === '"') {
          this.add(c);
          continue;
        }
        this.inQuotes = false;
      }
      if (this.inQuotes) {
        if (c === '"') this.quoteSeen = true;
        else this.add(c);
      } else if (c === '"' && this.field === "") this.inQuotes = true;
      else if (c === this.delimiter) {
        this.row.push(this.field);
        this.field = "";
      } else if (c === "\n") {
        this.row.push(this.field);
        rows.push(this.row);
        this.row = [];
        this.field = "";
      } else if (c !== "\r") this.add(c);
    }
    return rows;
  }

  end(): string[][] {
    this.quoteSeen = false;
    this.inQuotes = false;
    if (!this.field && !this.row.length) return [];
    this.row.push(this.field);
    const last = this.row;
    this.row = [];
    this.field = "";
    return [last];
  }

  private add(c: string) {
    if (this.field.length < this.maxField) this.field += c;
  }
}

// One line of the feed list: a store's feed, and whether we're on its programme.
export type ListedFeed = { merchantId: string; feedId: string; joined: boolean; lastImported?: string };

export function readFeedList(csv: string): ListedFeed[] {
  const reader = new CsvReader(",");
  const [header, ...rows] = [...reader.push(csv), ...reader.end()];
  if (!header) return [];
  const col = (name: string) => header.findIndex((h) => h.replace(/^﻿/, "").trim().toLowerCase() === name);
  const [advertiser, feed, status, imported] = [col("advertiser id"), col("feed id"), col("membership status"), col("last imported")];
  if (advertiser < 0 || feed < 0) return [];
  return rows
    .map((r) => ({
      merchantId: (r[advertiser] ?? "").trim(),
      feedId: (r[feed] ?? "").trim(),
      joined: status < 0 || /^(active|joined)$/i.test((r[status] ?? "").trim()),
      lastImported: imported >= 0 ? r[imported]?.trim() || undefined : undefined,
    }))
    .filter((f) => /^[0-9]{1,10}$/.test(f.merchantId) && /^[0-9]{1,10}$/.test(f.feedId));
}

// One product from a Create-a-Feed CSV, by its column names (header row).
// Awin's standard names, with the advertiser-side spellings as a fallback.
// The store's own link, not Awin's tracking one (which doesn't carry it).
export function readCsvProduct(row: Record<string, string>, keyOf: (link: string) => string | undefined): AwinProductRow | undefined {
  const get = (...names: string[]) => names.map((n) => row[n]?.trim()).find((v) => !!v);
  const link = get("merchant_deep_link", "deep_link");
  const named = get("product_name");
  const title = named && decodeEntities(named.slice(0, 1000)).trim().slice(0, 300);
  if (!link || !title) return undefined;
  const currency = get("currency");
  if (currency && currency.toUpperCase() !== "GBP") return undefined;
  const key = keyOf(link);
  if (!key) return undefined;
  const price = readPounds(get("search_price", "price", "store_price"));
  const old = readPounds(get("product_price_old"));
  const image = get("merchant_image_url", "large_image", "aw_image_url", "image_url");
  const stock = get("in_stock");
  const brand = get("brand_name");
  return {
    key,
    title,
    price,
    was: old !== undefined && price !== undefined && old > price ? old : undefined,
    image: image && /^https:\/\//i.test(image) ? image.slice(0, 1000) : undefined,
    brand: brand && decodeEntities(brand).slice(0, 100),
    // (No stock column: assume it's on sale.)
    inStock: stock === undefined ? true : stock === "1" || /^(true|yes|in stock)$/i.test(stock),
  };
}
