import type { UserRecord } from "./db";
import { mustConfirmEmail } from "./email";
import { can, outranks, type Permission } from "./permissions";
import { missingTwoStep } from "./staff-two-step";
import { countLiveThreadsByUser, getActiveMute, getCommunitySettings, type ThreadRow } from "./community-db";

// Who may do what in the Community. Shared by the actions (which enforce it)
// and the pages (which only show the tools that will work), so the two can't
// disagree.

// Whether someone may write in the Community right now; the problem in words
// if not.
export function writerProblem(user: UserRecord | null): string | null {
  if (!getCommunitySettings().on) return "The Community is closed for the moment.";
  if (!user) return "Log in to join in.";
  if (user.suspended) return "Your account is suspended.";
  if (mustConfirmEmail(user)) return "Confirm your email address before posting.";
  const mute = getActiveMute(user.id);
  if (mute) {
    const until = new Date(mute.until).toLocaleDateString("en-GB", { day: "numeric", month: "long" });
    return `You can read the Community but not post until ${until}.${mute.reason ? ` ${mute.reason}` : ""}`;
  }
  return null;
}

// Team tools: the permission, not suspended, and two-step login where the
// admins have made it a must.
export function teamMember(user: UserRecord | null, permission: Permission): user is UserRecord {
  return !!user && !user.suspended && can(user.role, permission) && !missingTwoStep(user);
}

// Staff look after the work of people below them, and their own.
export function mayAct(actor: Pick<UserRecord, "id" | "role">, target: { userId: string; role: UserRecord["role"] }): boolean {
  return actor.id === target.userId || outranks(actor.role, target.role);
}

// Whether a thread can be seen by this reader at all: a live one by anyone, a
// first thread waiting for a check by its writer and the moderators, a removed
// or deleted one by the moderators only.
export function threadVisibleTo(thread: Pick<ThreadRow, "status" | "userId">, viewer: UserRecord | null): boolean {
  if (thread.status === "live") return true;
  if (!viewer) return false;
  if (thread.status === "held") return viewer.id === thread.userId || teamMember(viewer, "forum.moderate");
  return teamMember(viewer, "forum.moderate");
}

// New members' first thread gets a bot check.
export function needsBotCheck(user: UserRecord): boolean {
  return user.role === "user" && countLiveThreadsByUser(user.id) === 0;
}
