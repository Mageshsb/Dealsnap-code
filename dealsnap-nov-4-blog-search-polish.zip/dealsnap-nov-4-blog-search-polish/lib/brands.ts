// Brands: who makes a deal's product (Apple, Samsung, Dyson…). A separate
// label from its type (lib/categories.ts) and its shop: one brand per deal, or
// none for shop-wide sales and mixed bundles. Each brand has a page at
// /brands/[slug] and can be followed like a shop.
//
// The list lives in the database (Admin → Tags and brands), seeded from
// lib/brand-defaults.ts, and is read once per change rather than per request.

import { clearBrandLogo, deleteBrandRow, getBrandRows, saveBrandRow, setBrandLogo, type BrandRow } from "./db";
import { getTagByName, tagMaker } from "./categories";

export type Brand = BrandRow;

let cached: { brands: Brand[]; bySlug: Map<string, Brand>; byName: Map<string, Brand>; matchers: Matcher[] } | undefined;
// Goes up each time the list is re-read, so anything worked out from it
// (the demo deals' brands) knows to work it out again.
let version = 0;

type Matcher = { brand: Brand; re: RegExp };

function normalise(text: string): string {
  return ` ${text
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[’‘`´']/g, "")
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()} `;
}

function load() {
  if (cached) return cached;
  const brands = getBrandRows();
  const matchers: Matcher[] = [];
  for (const brand of brands) {
    const words = [...new Set([brand.name, ...brand.words].map((w) => normalise(w).trim()).filter(Boolean))];
    if (!words.length) continue;
    const alts = words.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|");
    matchers.push({ brand, re: new RegExp(`(?<![a-z0-9])(?:${alts})(?![a-z0-9])`) });
  }
  version++;
  cached = {
    brands,
    bySlug: new Map(brands.map((b) => [b.slug, b])),
    byName: new Map(brands.map((b) => [b.name.toLowerCase(), b])),
    matchers,
  };
  return cached;
}

export function getBrandListVersion(): number {
  load();
  return version;
}

// Every brand, hidden ones included (admin), A–Z.
export function getBrandList(): Brand[] {
  return load().brands;
}

// Brands people can pick and browse (hidden ones are only for admin).
export function getVisibleBrands(): Brand[] {
  return load().brands.filter((b) => !b.hidden);
}

export function getBrandBySlug(slug: string): Brand | undefined {
  const brand = load().bySlug.get(slug);
  return brand && !brand.hidden ? brand : undefined;
}

export function getBrandByName(name: string | undefined): Brand | undefined {
  if (!name) return undefined;
  const brand = load().byName.get(name.toLowerCase());
  return brand && !brand.hidden ? brand : undefined;
}

// Saves a brand from Admin → Tags and brands, then re-reads the list.
export function saveBrand(row: Brand) {
  saveBrandRow(row);
  cached = undefined;
}

// Takes a brand off the site (see deleteBrandRow), then re-reads the list.
export function removeBrand(brand: Brand) {
  deleteBrandRow(brand.slug, brand.name);
  cached = undefined;
}

// The list changed under us (a category was renamed, so brands limited to it
// changed too): read it again.
export function forgetBrands() {
  cached = undefined;
}

// Saves a brand's logo (or removes it with null), then re-reads the list: the
// logo's address changes each time, so pages pick up the new one.
export function updateBrandLogo(slug: string, logo: { bytes: Buffer; type: string } | null) {
  if (logo) setBrandLogo(slug, logo.bytes, logo.type);
  else clearBrandLogo(slug);
  cached = undefined;
}

export type BrandMatch = { brand: string; from: "tag" | "product" | "title" | "trail" | "link" };

// Works out who makes a deal's product:
//  1. A tag with a maker decides it outright (MacBook → Apple, PS5 → Sony).
//  2. Then the shop's own "brand" field, if it's a brand we know.
//  3. Then the earliest brand named in the title, the shop's category trail,
//     and the link, in that order.
// A brand only counts in the categories it's allowed in, so "apple cider
// vinegar" in Food never becomes Apple.
export function detectBrand(input: {
  category: string;
  tag: string;
  title?: string;
  trail?: string;
  link?: string;
  productBrand?: string;
}): BrandMatch | undefined {
  const maker = getBrandByName(tagMaker(input.tag));
  if (maker) return { brand: maker.name, from: "tag" };

  const category = getTagByName(input.tag)?.category.name ?? input.category;
  const allowed = (b: Brand) => !b.hidden && (!b.categories.length || b.categories.includes(category));
  const { matchers } = load();

  const earliest = (text: string | undefined): Brand | undefined => {
    if (!text?.trim()) return undefined;
    const norm = normalise(text);
    let best: { brand: Brand; at: number } | undefined;
    for (const m of matchers) {
      if (!allowed(m.brand)) continue;
      const hit = m.re.exec(norm);
      if (hit && (!best || hit.index < best.at)) best = { brand: m.brand, at: hit.index };
    }
    return best?.brand;
  };

  const product = earliest(input.productBrand);
  if (product) return { brand: product.name, from: "product" };
  for (const from of ["title", "trail", "link"] as const) {
    const found = earliest(input[from]);
    if (found) return { brand: found.name, from };
  }
  return undefined;
}

// A brand a poster or helper picked: must be one on the list, and a tag with
// a maker always keeps its maker. "" (or anything unknown) means no brand.
export function resolvePickedBrand(tag: string, picked: string): string | undefined {
  const maker = getBrandByName(tagMaker(tag));
  if (maker) return maker.name;
  return getBrandByName(picked)?.name;
}
