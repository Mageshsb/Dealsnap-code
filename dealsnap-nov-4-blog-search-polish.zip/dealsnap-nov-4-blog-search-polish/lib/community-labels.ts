import { getStores } from "./mock-deals";
import { getCategoryGroups, getTagBySlug } from "./categories";
import { slugify } from "./slug";
import type { LabelKind } from "./community-db";

// What a thread can be about: a store, a category or a tag the site already
// has (so its page can show "Latest discussions"). Checked against the real
// lists, never taken on trust from the address or the form.
export function checkedLabel(kind: string, value: string): { kind: LabelKind; value: string; name: string; href: string } | undefined {
  if (!value) return undefined;
  if (kind === "store") {
    const store = getStores().find((s) => s.slug === value);
    if (store) return { kind, value, name: store.name, href: `/stores/${store.slug}` };
  }
  if (kind === "category") {
    const group = getCategoryGroups().find((g) => slugify(g.name) === value);
    if (group) return { kind, value, name: group.name, href: `/categories/${value}` };
  }
  if (kind === "tag") {
    const found = getTagBySlug(value);
    if (found) return { kind, value, name: found.tag.name, href: `/tags/${value}` };
  }
  return undefined;
}
