# Brand colour options (parked 20 Oct 2026)

These are screenshots of the colour previews, taken on an iPhone-sized screen (390px). Each option has a deal list and a Featured deal page. The live previews have been shut down and the site is still orange. Nothing here is used by the site.

| # | Option | Main colour | Accent ("% off" tag, Featured) |
|---|---|---|---|
| 1 | Orange (current) | `#f97316` / text `#ea580c` | green text `#16a34a` |
| 2 | Deep teal | `#0f766e` (hover `#115e59`) | black tag `#18181b` |
| 3 | Deep violet | `#6d28d9` (hover `#5b21b6`) | black tag `#18181b` |
| 4 | Violet + lime (recommended) | `#6d28d9` | lime `#a3e635`, text `#1a2e05` |
| 5 | Violet + gold | `#6d28d9` | gold `#fbbf24`, text `#451a03` |

**How the previews were made:** they overrode Tailwind's `--color-orange-*` variables, so every orange class changed colour.

| Variable | Teal | Violet |
|---|---|---|
| `-50` | `#f0fdfa` | `#f5f3ff` |
| `-100` | `#ccfbf1` | `#ede9fe` |
| `-200` | `#99f6e4` | `#ddd6fe` |
| `-300` | `#5eead4` | `#c4b5fd` |
| `-400` | `#2dd4bf` | `#a78bfa` |
| `-500` | `#0f766e` | `#6d28d9` |
| `-600` | `#115e59` | `#5b21b6` |
| `-700` / `-800` | `#134e4a` | `#4c1d95` |
| `-900` / `-950` | `#042f2e` | `#2e1065` |

**What a real switch would also cover:**
- the logo tag colour
- `app/icon.svg` and `app/manifest.ts`
- the share images
- the emails
- the heart "pop" colour
- giving Featured its own colour
