# Community (forum) plan — Nov 3 2026

Status: BUILT on Nov 3 2026 (owner approved: name "Community", no live chat, no pre-approval of first posts). Not yet built: images in posts, merge/split, site search of threads, email digest, new-replies pill, event threads, paging of deal comments.

## What the research says to copy

- **Discourse**: trust levels. New accounts are sandboxed (limited links, no messages, short edit time) and earn
  abilities by behaviour. Trusted members' flags hide obvious spam straight away, so moderators only see the
  grey cases. One review step for the few, not for everyone.
- **MoneySavingExpert forum**: the closest match to our audience. Calm boards grouped by topic, volunteer
  helpers who are not moderators, follow a board/thread, bookmark, email digest of trending threads, report button
  on every post, a rule that the forum is free of sellers.
- **hotukdeals / Slickdeals**: every deal belongs to a topic group; separate "ask for a deal" and store-specific
  talk. Nothing hard to find. Discussion lives next to the deal.
- **Reddit**: voting on posts, flair, per-space rules pinned at the top, mod tools in the page itself.
- **Stack Overflow**: "accepted answer" on questions. Best-answer marking is the single most useful feature for a
  "Is this deal any good / where can I find X" space.
- **Google**: forum pages can earn rich results with DiscussionForumPosting markup (author, date, full text,
  replies nested as `comment`). Must be crawlable (no login wall) and show full text on the page.
- **Retention research** (vendor blogs, unverified numbers): members whose first post gets a reply within a day
  mostly come back; ignored first posts mostly do not. So: welcome nudge + "no replies yet" list for helpers.

## Recommended shape

- **Name / place**: "Community" at /community, one item in the main nav and footer.
- **Spaces, not 40 boards**: about 8 curated spaces, run from Admin (name, icon, blurb, order, rules, who can start
  a thread). Starter set: Welcome & introductions, Deal talk, Ask the community (best answer), Money-saving tips,
  Stores & brands, Tech & gadgets, Home & garden, Off topic. A thread can also be tagged to a store, category or
  tag already in the taxonomy, so store pages can show "Latest discussions".
- **Threads**: title + body (plain text, paragraphs, auto-linked links with rel nofollow/ugc, @mentions, quote
  a reply, paste a DealSnap deal link and it becomes a deal card). Images later (existing sharp WebP pipeline).
- **Replies**: one flat list per thread, 25 per page, "replying to X" tag with quote preview on tap (same
  idea as the ↳ tag on deal comments). Jump to first unread / latest. No downvotes, no emoji reactions: Like only.
- **Ask space**: asker or a helper can mark a best answer; it is pinned under the question and the thread shows
  "Answered".
- **Sorts**: Latest activity (default), New, Top this week, Unanswered.
- **Following**: you follow a thread when you post in it; follow a space; bell notifications through the existing
  system (new kinds: thread replies, mentions, best answer). Optional weekly email digest later.
- **No live chat in v1**: costs a lot (sockets, moderation, scale) and feels empty on a young site. Instead:
  a small "new replies — tap to show" pill that checks every ~30s only while the tab is open. Event chat
  (Black Friday) can be a pinned thread per shopping event later.

## Staff and helpers (editing on the page itself, like deals)

- New named permissions: `forum.tidy` (helpers), `forum.moderate` (moderators+), `forum.manage` (admins).
- Helper: fix a title, move a thread to the right space, mark best answer, merge a duplicate request, hide a post
  (goes to the moderators' queue, not deleted). Cannot delete or lock.
- Moderator: hide/remove posts and threads (shows "Removed by our team"), pin, lock, split/merge, edit a post
  (shows "edited by our team"), mute a member from the Community for N days without full suspension.
- Admin: spaces, rules, limits, word filter, ad spaces, settings.
- All from a "Manage" bar and "⋯" menus on the thread/post. Everything audit-logged.
- Rank rule reused: staff act only on people they outrank (mayManageComment pattern).

## Admin → Community

Overview (new threads/replies this week, reports waiting, threads with no reply yet), Moderation queue (reports,
helper-hidden posts, held posts), Spaces (add/rename/reorder/archive/rules), Limits (new-member limits, edit
window, hold-first-posts switch, banned words), Ads for the Community.

## Where it joins the rest of the site

- **Profile**: the Comments tab becomes "Posts" and includes deal comments and Community posts, labelled. Keeps
  four tabs (no side scroll).
- **Badges** (data rows in lib/badges.ts): Conversation Starter (threads started), Problem Solver (best answers),
  Welcomer (first replies to new members' first posts). Likes on Community posts count towards Helpful.
- **Notifications**: existing bell, preferences, emails.
- **Search**: Community threads in site search (FTS5 is available in node:sqlite), live results first.
- **Deal page**: the comments stay; they get the same upgrades (page of 25 + load more, @mentions, quote,
  follow this discussion, jump to newest) so both feel the same. Today deal comments load all at once, which
  does not scale.
- **Store / category pages**: "Latest discussions" under the deals when there are any.
- **Account deletion**: posts stay, shown as the anonymised "Former member" (existing anonymiseAccount).

## Ads

New Ad spaces in Admin → Ads, all individually switchable, no ad code when off, never on the first screen,
never in the Ask-space best answer, never next to removed/held posts:
1. Between threads in a space list (after the 4th, then every 8th).
2. Inside long threads (after the 6th reply, then every 12th).
3. Desktop side rail (existing AdRails).
4. Under the last reply.

## Security and speed rules

- Plain text only. Never render user HTML; our own auto-linker makes links (https/http only, nofollow ugc).
- Server checks every action: signed in, email confirmed, not suspended, not Community-muted, named permission.
- Rate limits per member and per IP; new-member limits (links blocked for the first day, fewer posts per hour,
  Turnstile on first thread); duplicate-post detection; @mention cap per post; blocked members respected.
- Report = one tap; N reports from trusted members auto-hide pending review.
- Counters denormalised (reply count, last activity), keyset paging, proper indexes, no per-row subqueries;
  server-rendered lists; client JS only for composer, like, menus.
- Tests like the existing suites: permissions, rate limits, hostile input, paging, ranks, restore.

## Build order

1. Engine: tables, rules, permissions, tests.
2. Community home, space page, thread page (read), SEO markup, ads spaces.
3. Composer, reply, like, report, edit/delete, follow, notifications.
4. Staff front-end tools + Admin → Community.
5. Profile tab, badges, store pages strip, search.
6. Bring deal comments onto the same components (paging, mentions, quote, follow).
7. Later: images, digest email, new-replies pill, event threads.

## Open decisions for the owner

1. Name and nav place ("Community").
2. No live chat in v1.
3. First posts: no pre-approval by default (switch exists).
4. Whether to start with the engine + read pages and show a first look before building the rest.
