// Mock-up only: shoots the live /stores page and injects a proposed
// "Smaller shops, great deals" row above the list. Site code is untouched.
import { spawn } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";
const OUT = process.argv[2]; const SITE = process.env.SITE ?? "http://localhost:3000";
mkdirSync(OUT, { recursive: true });
const DEVICES = { desktop: { w: 1280, h: 900, dpr: 1, mobile: false }, honor: { w: 360, h: 900, dpr: 2, mobile: true } };
const chrome = spawn("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  ["--headless=new", "--remote-debugging-port=9334", "--user-data-dir=/private/tmp/claude-501/mock-chrome2", "--no-first-run", "--hide-scrollbars", "about:blank"], { stdio: "ignore" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let targets; for (let i = 0; i < 40; i++) { try { targets = await (await fetch("http://127.0.0.1:9334/json")).json(); if (targets.length) break; } catch {} await sleep(250); }
const ws = new WebSocket(targets.find((t) => t.type === "page").webSocketDebuggerUrl);
await new Promise((r) => (ws.onopen = r));
let id = 0; const waiting = new Map();
ws.onmessage = (m) => { const d = JSON.parse(m.data); if (d.id && waiting.has(d.id)) waiting.get(d.id)(d); };
const send = (method, params = {}) => new Promise((res, rej) => { const n = ++id; waiting.set(n, (d) => (d.error ? rej(new Error(JSON.stringify(d.error))) : res(d.result))); ws.send(JSON.stringify({ id: n, method, params })); });
const evaluate = async (e) => { const r = await send("Runtime.evaluate", { expression: e, awaitPromise: true, returnByValue: true }); if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails)); return r.result.value; };

const INJECT = `(() => {
  const DEALS = [
    ["AO.com", "Samsung 55\\" QLED 4K TV", "£449", "£699", 203, "1 live deal"],
    ["TAP Air Portugal", "Return flights to Lisbon (Oct dates)", "£58", "£110", 145, "1 live deal"],
    ["Dunelm", "Corner sofa bed", "£399", "£650", 91, "1 live deal"],
    ["ASOS", "Levi's 501 jeans", "£44.99", "£90", 27, "1 live deal"],
  ];
  const cards = [...document.querySelectorAll('a[href^="/store/"]')].filter(a => a.className.includes("rounded-xl"));
  const logoFor = (name) => { const c = cards.find(a => a.innerText.split("\\n")[0].trim() === name); const l = c && c.querySelector("span.h-10"); return l ? l.outerHTML.replace("h-10 w-10", "h-8 w-8") : '<span style="display:flex;width:32px;height:32px;flex:none;align-items:center;justify-content:center;border-radius:8px;background:#0e7490;color:#fff;font-weight:700;font-size:14px">' + name[0] + '</span>'; };
  const grid = cards[0].parentElement.parentElement;
  const heart = '<svg viewBox="0 0 24 24" width="14" height="14" fill="#f97316" stroke="#f97316" stroke-width="2" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>';
  const sparkle = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#f97316" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.94 14.34a2 2 0 0 0-1.28-1.28l-5.1-1.31a.5.5 0 0 1 0-.97l5.1-1.31a2 2 0 0 0 1.28-1.28l1.31-5.1a.5.5 0 0 1 .97 0l1.31 5.1a2 2 0 0 0 1.28 1.28l5.1 1.31a.5.5 0 0 1 0 .97l-5.1 1.31a2 2 0 0 0-1.28 1.28l-1.31 5.1a.5.5 0 0 1-.97 0Z"/></svg>';
  const tile = ([store, title, price, was, hearts, n]) => '<a href="#" class="smallshop-tile" style="display:flex;flex-direction:column;gap:8px;min-width:0;padding:12px;border:1px solid #e4e4e7;border-radius:12px;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.05);color:inherit;text-decoration:none">'
    + '<span style="display:flex;align-items:center;gap:8px;min-width:0">' + logoFor(store) + '<span style="font-size:13px;font-weight:600;color:#52525b;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + store + '</span></span>'
    + '<span style="font-weight:600;font-size:15px;line-height:1.3;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;min-height:2.6em">' + title + '</span>'
    + '<span style="display:flex;align-items:baseline;gap:6px"><span style="font-weight:700;font-size:17px">' + price + '</span><span style="font-size:12px;color:#a1a1aa;text-decoration:line-through">' + was + '</span></span>'
    + '<span style="display:flex;align-items:center;justify-content:space-between;font-size:12px;color:#71717a;border-top:1px solid #f4f4f5;padding-top:8px"><span style="display:flex;align-items:center;gap:4px;font-weight:600;color:#3f3f46">' + heart + hearts + '</span><span>' + n + '</span></span></a>';
  const sec = document.createElement("section");
  const wide = window.innerWidth >= 768;
  sec.style.cssText = "display:flex;flex-direction:column;gap:10px;margin:4px 0 8px";
  sec.innerHTML = '<div><h2 style="display:flex;align-items:center;gap:6px;font-size:17px;font-weight:700;margin:0">' + sparkle + 'Smaller shops, great deals</h2>'
    + '<p style="font-size:13px;color:#71717a;margin:2px 0 0">Shops with only a few deals, where the community loved what was found.</p></div>'
    + '<div style="' + (wide ? "display:grid;grid-template-columns:repeat(4,1fr);gap:12px" : "display:flex;gap:10px;overflow-x:auto;scroll-snap-type:x mandatory;scroll-padding-left:16px;margin:0 -16px;padding:0 16px 4px") + '">'
    + DEALS.map(d => wide ? tile(d) : '<div style="flex:0 0 72%;scroll-snap-align:start;display:flex">' + tile(d).replace("<a ", '<a data-m ').replace("display:flex;flex-direction:column", "display:flex;flex:1;flex-direction:column") + '</div>').join("")
    + '</div>';
  grid.parentElement.insertBefore(sec, grid);
  return document.documentElement.scrollWidth + " of " + innerWidth;
})()`;

for (const [name, d] of Object.entries(DEVICES)) {
  await send("Page.enable");
  await send("Emulation.setDeviceMetricsOverride", { width: d.w, height: d.h, deviceScaleFactor: d.dpr, mobile: d.mobile });
  await send("Page.navigate", { url: SITE + "/stores" }); await sleep(4000);
  await evaluate(`document.querySelector('[aria-label*="lose"]')?.click(); window.scrollTo(0,0)`);
  const w = await evaluate(INJECT); await sleep(600);
  const ys = await evaluate(`Math.round(document.querySelector("section h2").getBoundingClientRect().top + scrollY)`);
  const r = await send("Page.captureScreenshot", { format: "png", clip: { x: 0, y: Math.max(0, ys - 230), width: d.w, height: 760, scale: 1 }, captureBeyondViewport: true });
  writeFileSync(`${OUT}/smaller-shops-${name}.png`, Buffer.from(r.data, "base64")); console.log(name, w);
}
ws.close(); chrome.kill();
