# DealSnap front end walkthrough

**From:** DealSnap front-end owner
**To:** Barath (backend, LootDrop deal engine)
**Written:** 1 November 2026, from the code as it stands today (latest commit on the private GitHub repository)

This follows your brief's headings in the same order. It contains no code, no file paths and no secrets: only page URLs, API route names, data field names and environment variable *names*.

One thing to know before reading: **DealSnap is more than a front end.** It's one app that includes its own server, database, sign-in, moderation, admin area and background jobs. So most items below are "Working" on DealSnap's own database. The two big exceptions are:

- **The demo catalogue.** About 216 example deals are built into the app so the site looks busy. These are the source of the "800+ hearts" bot deals and the comment-count mismatch you saw.
- **The deal engine connections.** These are not built yet; section 5 covers them.

---

## 1. Overall setup

### Stack
| Part | What it is |
|---|---|
| Language | TypeScript, about 54,000 lines |
| Framework | Next.js 16.4 (App Router) with React 19 |
| How pages are rendered | On the server, fresh for every visit. Nothing is pre-built except icons and the web app manifest. Pages are server components. The interactive parts (voting, the comment box, menus, infinite scroll, Cards view) are client components. |
| UI library | Tailwind CSS 4 and Lucide icons. All other components are our own, with no component kit. |
| How data is fetched | Pages read the database directly on the server. The browser calls the site's own API only for: loading more deals as you scroll (`/api/deals`), search suggestions (`/api/search`), and the notification count (`/api/notifications/count`). Everything a member does (vote, comment, post, settings) goes through Next.js "server actions": form posts handled on the server, with no separate REST API. |
| Database | SQLite, built into Node.js 24. There is no ORM: the queries are hand-written. There are two files: the main database (members, deals, comments, votes, settings, photos: about 5MB today) and a separate product-lists file for Awin product lists (rebuildable, kept out of backups). |
| Login library | None. Sign-in is built in-house (see the Login feature). Google sign-in uses Google's standard sign-in flow (OAuth), called directly with no library. |
| Other packages | Only 8 outside packages run on the live site, including sharp (image processing), web-push (browser notifications) and qrcode (two-step login setup). |
| Phone apps | Capacitor 8 shells for iPhone and Android that load the live website, plus native notifications. They're not compiled yet: Xcode and Android Studio still need installing. |
| Browser extension | A Chrome extension that calls the site's `/api/extension/*` routes. It isn't published yet. |

### Hosting
- **Today:** a Mac. For demos, a production build runs on the Mac and is shared through a temporary Cloudflare quick tunnel (the trycloudflare.com address changes on every restart). That copy uses a snapshot of the database.
- **Planned:** one server with a permanent disk, behind Cloudflare (CDN, bot protection, rate limits). The recommendation is a managed host with a disk, such as Render or Railway, or a rented server such as DigitalOcean London.
- **What won't work as it stands:** "serverless" hosting (Vercel and similar). The app needs a disk that survives restarts and needs to run all the time for its timed jobs.
- **CDN:** none yet. Uploaded images already send year-long cache headers, with addresses that change whenever the image changes.

### Data: what's demo and what's real
| Data | Status |
|---|---|
| **Demo catalogue:** about 47 hand-written deals plus 169 generated ones | **Mock.** Built into the app, not stored in the database. Their posted times are re-spread over the last 3 weeks every time the server starts, so the demo looks alive. Most are credited to a demo account called "DealBot", and 5 to demo members. Their heart counts are fixed starting numbers, up to 847 (that's where the "800+ hearts" come from), and their comment counts are fixed numbers too. Their store links are mostly store home pages, which is why `/go` took you to Microsoft's home page. Staff can take these down or feature them through an override list in the database. |
| Deals posted through the site | **Real.** Stored in the database. There are 69 test posts today. |
| Hearts | **Real** votes are stored per member. For demo deals, real votes are added on top of the fixed starting number. |
| Comments, members, follows, saves, alerts, notifications, reports | **Real**, in the database |
| Stores | **Real but derived.** There is no master stores table: a store exists because deals name it. Store page content (description, delivery, perks, questions) is in the database: 57 stores have it, written from research on 25 October. |
| Categories and tags | **Fixed list in the code**, plus extra matching words that admins can add in Admin |
| Brands | **Real**, in the database: about 85 starter brands, editable in Admin |
| Awin store programmes | **Real**, synced from our Awin account (see Stores and categories) |
| Blog | Real posts in the database, starting with 6 researched articles |

### Background jobs
These run inside the app on timers, starting when the server starts:
- **Every minute:**
  - send notification emails that are due (instantly, or as a daily summary at 8am UK time);
  - tell people who saved an upcoming deal that it has started.
- **Every hour:**
  - make the daily database backup (once a day, keeping 7, on the same server);
  - Awin upkeep: re-sync the stores that have approved us about once a day, and refresh each switched-on product list about once a day;
  - email admins about urgent things waiting (at most every 6 hours, and only if something changed; off by default).
- **Once when the server starts:** label older deals with sub-tags and brands (a one-off job).

### Environment variable names
| Name | What it's for |
|---|---|
| `DEALSNAP_DATA_DIR` | Folder holding the database files, backups and the email outbox. Must be on a permanent disk in production. |
| `DEALSNAP_SECRET_KEY` | Encrypts secrets saved through Admin: the Awin token, the Awin feed link, and the Apple and Google push keys. Without it, a key file is made beside the database. |
| `SITE_URL` | The site's real address, used for links in emails, the sitemap and share images |
| `ADMIN_EMAIL` | The owner's email. Only that account can claim the first admin role on a fresh site. |
| `RESEND_API_KEY`, `EMAIL_FROM` | Email sending through Resend. Until these are set, emails are written to an outbox folder instead of being sent. |
| `TURNSTILE_SITE_KEY`, `TURNSTILE_SECRET_KEY` | Cloudflare Turnstile bot check on sign-up, posting and the contact form. Until set, the site uses a simple sum question plus hidden checks. |
| `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | "Continue with Google". The button is hidden until these are set. |
| `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY` | Optional fixed keys for browser notifications. Without them, keys are generated once and stored in the database. |
| `NODE_ENV` | Standard: production switches on stricter security headers (forcing HTTPS) |

Other settings and keys are entered in **Admin → Settings**, not environment variables:
- the Google Analytics or Tag Manager ID;
- the Amazon tag, Skimlinks ID and Awin publisher ID;
- the Awin API token and feed link (stored encrypted);
- the Apple and Google push keys (stored encrypted);
- the deal engine key, of which only a fingerprint is stored.

---

## 2. Page by page

"Login" means the visitor must be signed in. For "Data", "own DB" means DealSnap's database, and "catalogue" means demo deals plus posted deals, merged when the page is built.

### Public pages
| URL | Purpose and what it shows | Data | Login | Status |
|---|---|---|---|---|
| `/` | Home: all deals as a List or as swipeable Cards. Sort by Most loved (this week, with Today, This month and All time options) or New. Filters for hearts, deal type, "Live only" and hiding expired deals. Sidebar boxes and popular topics on wider screens. | Catalogue | No | Working |
| `/?q=…` | Search results: Best match, Most loved and New sorts, plus a typo correction ("Showing results for…"). Expired matches are counted with a "Show" link. | Catalogue plus the built-in search | No | Working |
| `/deals` | Redirects to `/` | — | No | Working |
| `/deals/[slug]` | Deal page (see Feature 2) | Catalogue plus own DB | No | Working |
| `/deals/[slug]/edit` | Edit a deal: the poster, helpers, moderators and admins, with rank rules | Own DB | Yes | Working (posted deals only; demo deals can't be edited) |
| `/go/[slug]` | "Get deal": logs the click, then redirects to the store, with an affiliate tag when we have one | Own DB | No | Working |
| `/categories` | Every category as a card, with its tags as tiles, live deal counts and a search box | Catalogue | No | Working |
| `/categories/[slug]` | One category's deals, with Store, Brand and Type filters | Catalogue | No | Working |
| `/tags` | Redirects to `/categories` | — | No | Working |
| `/tags/[slug]` | One tag's or sub-tag's deals (Laptop, MacBook…). The bar shows the path and related tags. | Catalogue | No | Working |
| `/stores` | Every store as a tile: logo, deal count, code count and free-delivery note. Search, a category filter, perk filters (free delivery, click and collect, free returns, student discount, price match), sorting (Most deals, A–Z, Most codes) and a "Your stores" row. | Catalogue plus store profiles | No | Working |
| `/stores/[slug]` | One store: its deals, voucher codes, a details panel and questions | Catalogue plus store profiles | No | Working |
| `/brands`, `/brands/[slug]` | Every brand, and one brand's deals. Quiet brands are kept out of search engines. | Own DB plus catalogue | No | Working |
| `/black-friday`, `/christmas` (any event address) | Shopping event pages, only while an admin has launched them | Own DB | No | Working (not launched yet) |
| `/blog`, `/blog/[slug]` | Blog: post types, pinned post, key takeaways, related deals | Own DB | No | Working |
| `/u/[username]` | Public profile: deals, loved deals, comments, badges, stats, follow button. "Live only" switch. | Own DB plus catalogue | No | Working |
| `/u/[username]/followers`, `/following` | Follower lists | Own DB | No | Working |
| `/member/[id]` | Permanent link to a member that survives username changes. Redirects to their profile. | Own DB | No | Working |
| `/submit` | Post a deal, in 3 steps. Guests can fill it in and are asked to sign up when they press post; the draft is kept on their device. | Own DB plus link reader | To post | Working |
| `/about`, `/contact`, `/guidelines`, `/terms`, `/privacy` | Footer pages. Contact has a topic menu and a bot check, and messages go to Admin → Messages. | Static text, plus own DB for contact | No | Working. The company details in the legal text are placeholders. |
| `/iphone` | How to add "Post to DealSnap" to the iPhone Share menu with a Shortcut | Static | No | Working |
| `/email/unsubscribe` (plus `/api/email/unsubscribe` for one-click) | Unsubscribe from emails using the link in an email | Own DB | No | Working |

### Account pages
| URL | Purpose | Login | Status |
|---|---|---|---|
| `/login`, `/signup` | Email and password; Google once switched on. `?next=` returns the visitor to where they were. | — | Working |
| `/login/verify` | Two-step code after the password, for members who have turned it on | — | Working |
| `/login/forgot`, `/login/reset` | Password reset by emailed link | — | Working; emails go to the outbox until Resend is live |
| `/confirm-email` | Confirm the email address from the emailed link | — | Working |
| `/welcome` | Straight after sign-up: tick the kinds of deals you like, and each becomes a category alert | Yes | Working |
| `/auth/google`, `/auth/google/callback` | Google sign-in | — | Built; switched off until the keys are set |
| `/account` | Phone home screen for the account: profile card, counts, links | Yes | Working |
| `/profile` | Your own profile | Yes | Working |
| `/profile/export` | Download all your data as a JSON file (UK GDPR) | Yes | Working |
| `/settings` | Settings: name, photo and bio; sign-in and security (email, password, two-step); notifications; blocked members; your data and account deletion | Yes | Working |
| `/alerts` (shown as "Watching") | Followed stores, categories, tags and brands, plus keyword alerts with an optional "up to £" price | Yes | Working |
| `/saved` | Saved deals | Yes | Working |
| `/feed` | Deals from the people you follow | Yes | Working |
| `/notifications` (and `/notifications/open/[id]`) | Notification list with filters. Opening one marks it read and goes to the item. | Yes | Working |
| `/helper` | Helper desk: a to-do list of deals to check or fix | Helpers and staff | Working |

### Admin pages (staff only; each page checks a named permission)
| URL | Purpose | Status |
|---|---|---|
| `/admin` | Dashboard: "Needs attention", this week's numbers, deals that went up without a check, moderator activity | Working |
| `/admin/deals` | Review queue and all deals: approve, reject, take down, restore, feature, set the Hero deal, delete, bulk actions | Working |
| `/admin/comments` | Reported comments: delete or dismiss | Working |
| `/admin/users`, `/admin/users/[id]` (and `/make-admin`, `/make-moderator`) | Members: search, suspend, notes, roles, sign-in details, a member's staff work | Working |
| `/admin/stores`, `/admin/stores/[slug]` | Stores: rename, merge spellings, logos, store details, perks, blocking-reader stats, earning route | Working |
| `/admin/labels` | Tags and brands: matching words, brands and brand logos | Working |
| `/admin/events` (and `/new`, `/[id]`) | Shopping events: launch, take down, edit, repeat rules | Working |
| `/admin/banners` (and `/new`, `/[id]`) | One-line site banner: text, link, dates, colours | Working |
| `/admin/blog` (and `/new`, `/[id]`) | Blog editor | Working |
| `/admin/messages` | Contact form messages | Working |
| `/admin/insights` | Growth and click numbers (see Feature 13) | Working |
| `/admin/activity`, `/admin/team` | Staff activity log, and per-person staff impact | Working |
| `/admin/settings` | Tabs: General, Earnings, Tracking & code, Security, Moderators, Data & backups | Working |
| `/admin/engine` | Deal engine controls (see Feature 11) | Controls work; the engine isn't connected |
| `/admin/guidelines` | Rules for moderators | Working |
| `/admin/backup`, `/admin/export/[kind]` | Download a full database backup; spreadsheets of deals, users, comments and activity | Working |
| `/admin-claim` | One-time: makes the owner (`ADMIN_EMAIL`) the first admin on a fresh site | Working |

### System pages and files
| URL | What it is |
|---|---|
| 404 page and error page | Our own "not found" and "something went wrong" pages, each with a way back |
| Maintenance page | Shown to everyone except sign-in and admin while maintenance mode is on in Admin |
| `/sitemap.xml`, `/robots.txt` | Generated on each request (see Feature 12) |
| `/manifest.webmanifest` | Lets the site install as an app; on Android, adds DealSnap to the Share menu |
| `/.well-known/apple-app-site-association`, `/.well-known/assetlinks.json` | App links for the iPhone and Android apps |
| `/deals/[slug]/opengraph-image`, `/blog/[slug]/opengraph-image` | Share images |
| `/deal-image/[slug]/[file]`, `/avatar/[id]/[file]`, `/store-logo/[key]`, `/brand-logo/[slug]`, `/blog-cover/[id]/[v]` | Images served from the database |
| `/api/deals`, `/api/search`, `/api/notifications/count`, `/api/go/[slug]` | Own API (see the features) |
| `/api/extension/love`, `/me`, `/notifications`, `/read`, `/save`, `/shop`, `/shops`, `/state` | Browser extension API |

`/affiliate-disclosure` doesn't exist, and that's on purpose. The disclosure is a note in the footer (and phone menu) linking to the "How we make money" section of `/terms`.

---

## 3. Feature by feature

### 3.1 Deal cards
| Part | Walkthrough |
|---|---|
| Name and where it appears | Deal card in List view (home, search, category, tag, store, brand, event, profile, saved, following). There's also a full-screen swipe card in Cards view, and a small tile in "Related deals" and sidebars. |
| What the user sees and does | **Shown:** photo (or an icon tile when there's none); a heart count with love and "Not for me" buttons; the poster's name and rank colour; time posted; title; the price block (big price, struck-through was-price and % off, or the offer text for non-price deals, plus /month, "from" or cashback extras); store; small print for conditions (new customers, members price, app only, students, selected lines); delivery; and a Get deal button. **Labels and pills:** Expired, Featured, Hero, upcoming ("Starts Fri 8am"), "In-store only". **Taps:** the card opens the deal page; the heart votes; Get deal goes through `/go`. |
| How it works, step by step | The list is built **on the server**: the demo catalogue and the database's posted deals are merged once per page view, then real vote totals, store-name tidying, "ended" reports and the Hero flag are applied. The list is sorted and filtered, and the first batch is drawn on the server. More load from `/api/deals` as you scroll (20 at a time). Whether expired deals are hidden is a choice kept in the visitor's browser, so the browser hides or greys them. |
| Data pulled | `title, slug, image, imageSize, price, originalPrice, kind, offer, priceUnit, priceFrom, cashback, conditions, store, category, tag, brand, url, postedAt, startsAt, expiresAt, hearts, commentCount, postedByUsername, postedByAvatarUrl, postedByRole, voucherCode, delivery, whereToBuy, featured, hero, endedByMembers, status`. **% off is worked out** from price and was-price, not stored. **Freshness:** live on every page load; there's no caching between visits. |
| Data saved or changed | A vote saves one row per member per deal, with its direction (love or not for me) and its weight. |
| How it's handled | **Expired:** greyed out and labelled; hidden unless "Show expired" is on. **No photo:** an icon tile. **Logged-out vote:** sends the visitor to sign in and back. **Taken-down and pending deals:** never listed (a pending deal is visible only to its poster and staff). |
| Status | **Working.** On the demo deals, the **comment count is a fixed made-up number**, while the deal page counts real comments. That's your 86-versus-3 mismatch. Posted deals use real counts. The 800+ hearts are the demo deals' fixed starting numbers. |
| What it needs from the backend | Real deals instead of the demo catalogue. Real prices, photos, end dates and conditions from the engine for bot deals. Later, a reference-price label, "price checked" time and "lowest in 90 days" (none are shown today). There's no "Ad" flag today, because nothing on the site is paid placement. |

### 3.2 Deal detail page
| Part | Walkthrough |
|---|---|
| Name and where it appears | `/deals/[slug]` |
| What the user sees and does | **Top:** back link, then the category › tag trail. **Main:** photo, the same price block as the card, Get deal (plus a sticky bar with the price and Get deal once you scroll past the button), Save (or "Remind me" for upcoming deals), Share (copy link, or the phone's share menu), Report and "Deal ended?" links. **About this deal:** description, conditions, voucher code (tap to copy, plus "Did this code work? Yes/No" with results), delivery, where to buy (online, or in-store with a note), the poster card (joined date, deals posted, hearts received), and "Checked by DealSnap helpers {time ago}". **Price check:** compares the price with earlier posts of the same product on DealSnap. **Comments:** one level of replies, likes, "Most helpful", sorting, and edit, delete and report through a ⋯ menu. **Related deals:** a sideways-scrolling row. Also an "In Black Friday" style event chip, and the affiliate "*" note. |
| How it works, step by step | The server loads the deal from the merged catalogue and checks the visitor may see it. It then loads the poster's stats, the helper-check time, code results, events, comments and related deals (same tag first, then category). It also builds the page title and description, a share image and structured data. |
| Data pulled | All the card fields, plus `description, voucherCode, delivery, whereToBuy, whereNote, conditions, editedAt, endedReports`. Also: comments (from `comments` and `comment_likes`), helper checks (`deal_checks`), code results (`code_reports`), price history (other posts of the same product), and events. **Live** on every visit. |
| Data saved or changed | Votes, saves, comments, comment likes, reports (deal or comment), "Deal ended?" reports, code yes/no answers, and a click record when Get deal is pressed. |
| How it's handled | **Ended:** when enough members say a deal has ended (3 to start, rising gently with popularity up to 8, both settable in Admin), or one member of staff or the poster does, the deal is marked expired from that moment. It stays up, labelled "Expired", still listed when "Show expired" is on, with its structured data saying it's out of stock. A fair share of "ended" reports shows a "members say this may have ended" warning first. **Removed by staff:** a 404 for everyone except the poster, who sees why. **Pending:** visible only to the poster and staff, and kept out of search engines. **Upcoming:** says "Starts Fri 8am" and switches over by itself at the start time. |
| Status | **Working** (on demo and posted deals) |
| What it needs from the backend | Price history for "lowest in 90 days" (connection 3); a price-checked time; updates or expiry pushed from the engine for bot deals. |

**Share image:** every deal has its own picture for WhatsApp, Facebook and X previews, drawn on request. It shows the photo, price and % off (or the offer).

**Structured data:**
- deal pages: Product with an Offer (price, was-price, availability, seller = store, brand), plus a breadcrumb trail;
- blog posts: Article;
- the home page: WebSite.

### 3.3 Listing, search, filter and sort
| Part | Walkthrough |
|---|---|
| Name and where it appears | Every deal list; the header search box with its suggestions; the results page at `/?q=` |
| What the user sees and does | **Sorts:**<br>• **Most loved** (the default): deals from the chosen window (Today, This week, This month or All time; this week by default) by hearts, then older deals by hearts, with a "Posted before this week" divider. The Hero deal is pinned on top.<br>• **New:** newest first.<br>• **Best match:** only on searches.<br>**Filters:**<br>• minimum hearts (25, 100 or 250);<br>• deal type (price drops, sales, multi-buys, vouchers, cashback, freebies);<br>• Store, Category or Brand menus, depending on the page;<br>• "Show expired" and "Live only".<br>**Typeahead:** as you type, suggestions show categories, tags, stores, brands, a "Laptop made by Apple" style shortcut, and up to 6 deals. Pasting a store link instead shows whether that product is already on DealSnap. |
| How it works, step by step | **Search is our own, built in. There's no search service.** It:<br>• ignores case, accents and apostrophes;<br>• matches whole words, plurals and joined or split words;<br>• fixes typos only for words that appear nowhere on the site;<br>• uses a synonym list;<br>• needs every word to match (falling back to "most words" when nothing has every word);<br>• ranks by where the words are found (title first, then tag, brand and store, then description, then category), with a bonus for the exact phrase and ties going to the most loved deal.<br>Choices are kept in the address (`?view=new&hearts=100&store=currys&type=voucher&when=today`), so a reload or a shared link shows the same list. Pages load 20 deals, then `/api/deals` serves more using `offset` and `limit`. |
| Data pulled | The same merged catalogue. Search words are capped in length and count. **Live**: worked out per request, with small in-memory caches. |
| Data saved or changed | Nothing. (Searches aren't logged. The "What members want" section in Insights comes from members' alerts and follows.) |
| How it's handled | **Empty results:** a friendly empty state, never a blank page. **Expired matches:** "N expired also match · Show". **Pagination:** infinite scroll, with Back returning to the exact same deal and scroll position (List and Cards). **Permissions:** public. |
| Status | **Working** |
| What it needs from the backend | Nothing to run. At engine scale, a proper search index may be needed later (Postgres full-text search or a search service). |

### 3.4 Stores and categories
| Part | Walkthrough |
|---|---|
| Name and where it appears | `/stores`, `/stores/[slug]`, `/categories`, `/categories/[slug]`, `/tags/[slug]`, `/brands/[slug]`, plus the store, category and brand filters |
| What the user sees and does | **Store page:**<br>• the store's deals;<br>• a "Codes" list with code results ("Worked 2h ago" or "May not work");<br>• an ⓘ panel with delivery, returns, price match, student and Blue Light discounts, click and collect, and questions;<br>• an alert bell.<br>**Category and tag pages:** the path bar (Electronics › Laptop › MacBook), related tags, an alert bell, and the filters. |
| How it works, step by step | **Stores:**<br>• There is no master store list. A store is any name used on a deal, matched loosely ("Amazon UK", "amazon.co.uk" and "Amazon" are one store).<br>• Admins can rename stores and merge spellings.<br>• The store's address name comes from its display name.<br>• Store details are kept per store in the database (written from research on 25 October for 56 stores, and editable in Admin). Logos are fetched from the store's website or uploaded, and kept in the database.<br>**Categories:**<br>• A fixed list in the code: categories, then tags, then sub-tags (up to 3 levels, one parent each).<br>• Each deal has **one** type (its most specific tag) and **one optional brand**.<br>• When a link is pasted, the post form suggests the category and tag from the product's title and the store's own category trail. If it isn't sure, it asks the poster, and a helper checks it later.<br>• Admins can add matching words to any tag.<br>**The "33 stores synced":** these are **not** stores on the site. They are **Awin affiliate programmes**.<br>• Pressing "Sync my stores" in Admin (also run automatically about every 23 hours) asks Awin's API which advertisers have approved our publisher account.<br>• It saves a row per **store website domain**, holding Awin's **merchant ID**, the store's name on Awin and the source "awin".<br>• "Get deal" clicks to those domains are then tagged.<br>• Rows added by hand are never touched. A store that drops us is removed.<br>• It's 33 stores and 37 rows, because some stores have more than one website. |
| Data pulled | Deals (catalogue); store details (`store_profiles`); store name changes and merges (`store_names`, `store_aliases`); Awin programmes (`affiliate_programmes`: `domain, network, merchant_id, name, source, stopped, has_list`); brands (`brands`); tag words (`tag_words`). **Live.** |
| Data saved or changed | Admin edits; alert bells (`store_alerts`, `category_alerts`, `tag_alerts`, `brand_alerts`); sync results |
| How it's handled | Store tiles show "Most deals" first. A store with no live deals is still listed (an eye toggle hides empty ones). Quiet brand pages are kept out of search engines. Perks show a "Perks can change" note. |
| Status | **Working.** Store facts are researched, not live: they drift and need re-checking. |
| What it needs from the backend | A **master store list** with a shared ID (the domain is the natural key), mapping engine retailers to DealSnap stores. Engine categories need mapping onto DealSnap's types (see section 6). |

### 3.5 Outbound `/go` links and affiliate tracking
| Part | Walkthrough |
|---|---|
| Name and where it appears | Every "Get deal" button (and "View store" on upcoming deals). In the phone apps it goes through `/api/go/[slug]`. |
| What the user sees and does | A tap opens the store. When the affiliate note is on, the button carries a "*", explained in the footer. |
| How it works, step by step | 1. Look up the deal. If it's missing, removed or pending (and not yours), go to the home page.<br>2. **Log the click** (deal slug, member ID if signed in, time).<br>3. Build the outgoing link from the deal's **plain store link**, in this order:<br>• the store's own programme (Awin merchant ID, or another network's link format);<br>• the Amazon Associates tag (replacing any tag a poster added);<br>• Skimlinks for everything else;<br>• or a general network link format;<br>• or no tag at all.<br>4. Every tagged link carries a **deal reference** (Awin `clickref`, Skimlinks `xcust`), so network reports show which deal earned.<br>5. Redirect. The response is never cached.<br>When a deal is posted, any affiliate or redirect wrapping someone pasted is stripped, so the deal stores the store's own link. |
| Data pulled | The deal's `url`; the affiliate settings (Amazon tag, Skimlinks ID, Awin publisher ID, link format); Awin programmes |
| Data saved or changed | One `deal_clicks` row per click (`deal_slug, user_id, at`) |
| How it's handled | **Link attributes:** Get deal links open in a new tab with `rel="nofollow noopener noreferrer"`, and search engines are told not to crawl `/go/`. Adding `sponsored` would be a small improvement. **In the apps:** Amazon and eBay links are handed to the phone so they open in the store's own app (Amazon's rules require this); other stores open in an in-app browser. |
| Status | **Working.** On the demo, `/go` went to Microsoft's home page with no tag for two reasons: demo deals' links are store home pages, and Microsoft isn't one of our Awin stores. Amazon and Skimlinks IDs aren't set either. A real Awin store's link is tagged. |
| What it needs from the backend | Engine deals should send the **plain store link**. DealSnap adds the tag when someone clicks, so the tag lives in one place. Click logs stay on DealSnap and can be shared with the engine (see section 6). |

### 3.6 Images
| Part | Walkthrough |
|---|---|
| Name and where it appears | Deal photos, avatars, store logos, brand logos, blog covers, share images |
| What the user sees and does | Photos on cards and deal pages. Posters can upload one, or let the form take it from the link. |
| How it works, step by step | **Deal photos:**<br>1. They arrive from the poster's upload, the photo on the store's page (read when a link is pasted), the browser extension, or an Awin product list.<br>2. The server downloads the photo itself (public addresses only; a size limit; "decompression bomb" files refused).<br>3. It checks the file is really an image by its contents.<br>4. It **re-saves it as two new WebP files** (one large, one small for lists), dropping anything hidden in the file and the camera's location data.<br>5. Both are stored **in the database** and served from `/deal-image/…` with year-long caching.<br>**Images from other sites are never shown directly.** Demo deals use bundled photos (free Unsplash images) or drawn illustrations. |
| Data pulled | The image file and its size from the database (`deal_images`, `user_avatars`, logos) |
| Data saved or changed | The two sizes per deal, when it's posted or edited |
| How it's handled | **No or broken photo:** an icon tile for the deal's type. **Allowed sources:** any public address, with private and internal addresses refused. **Limits:** uploads up to a few MB; tiny images (tracking pixels) refused. |
| Status | **Working** |
| What it needs from the backend | Engine deals send `image_url`; DealSnap downloads and re-saves it the same way. Later, at scale, photos should move out of the database into object storage (Cloudflare R2). |

### 3.7 Vouchers and unique offers
| Part | Walkthrough |
|---|---|
| Name and where it appears | The post form (step 1: "What kind of deal?"), cards, the deal page, and store pages' "Codes" list |
| What the user sees and does | **Six deal types:**<br>• **price drop:** price, was-price, % off;<br>• **sale:** "Up to 70% off" or "20% off";<br>• **multi-buy:** BOGOF, half price, 3 for 2, "2 for £x", "3 for £x", or other;<br>• **voucher:** £ off, % off or free delivery;<br>• **cashback;**<br>• **freebie.**<br>**Extras:**<br>• a voucher code (tap to copy, plus "Did this code work?");<br>• delivery: free, paid with an amount, or not said;<br>• **online** (the default) or **in-store only**, with a note on which stores;<br>• conditions: new customers, members or loyalty card price, app only, students, selected lines;<br>• charged per month, year, person or night;<br>• a "from" price;<br>• cashback after paying;<br>• an end date, and "Starts later?" for upcoming deals. |
| How it works, step by step | Each type stores its own few answers and shows one headline in the price spot. Codes are checked against members' yes/no answers. A code looks broken with at least 2 "no" answers in 48 hours and more no than yes; a helper's check after the last "no" settles it. |
| Data pulled | `kind, offer, price, originalPrice, priceUnit, priceFrom, cashback, voucherCode, delivery, whereToBuy, whereNote, conditions, startsAt, expiresAt`; code answers (`code_reports`) |
| Data saved or changed | Saved with the deal when posted or edited. One code answer per member, tied to the current code. |
| How it's handled | Cards show conditions as one line of small print. The poster can't answer about their own code. The code question is hidden until an upcoming deal starts. |
| Status | **Working.** **Bank or card offers ("10% off with HSBC") are NOT BUILT** as a type or condition. |
| What it needs from the backend | `offers[]` from the engine mapped onto these types and conditions. Agree a shared list, and add "bank or card offer" if the engine finds them. |

### 3.8 Login, users and sessions
| Part | Walkthrough |
|---|---|
| Name and where it appears | `/login`, `/signup`, `/login/verify`, `/login/forgot`, `/login/reset`, `/confirm-email`, Settings → Sign-in & security |
| What the user sees and does | Sign up with a username, email and password. Log in with email and password, or "Continue with Google" once switched on (website only; hidden in the apps). Optional **two-step login** with an authenticator app (QR code setup). Forgot password, change email, change password, delete account, download my data. |
| How it works, step by step | **Passwords:** hashed. **Sessions:** a random token in a secure, HTTP-only cookie lasting **30 days**. Only a hash of the token is stored, so a stolen database can't sign anyone in.<br>**Login protection:** after a set number of failed attempts the account is locked for a while (settable in Admin). Sign-up and password reset are rate limited by email and by network address.<br>**Password reset:** a one-time emailed link. Afterwards every device is signed out.<br>**Email confirmation:** needed before commenting, but only once email sending is live.<br>**`login?next=`:** after signing in, the member returns to that page. Only addresses on our own site are accepted, so it can't send people elsewhere. Sign-up passes it through `/welcome`.<br>**Roles:** Member, Helper, Moderator, Admin. Every admin page and action checks a **named permission**, not just "is admin", and staff can only act on people below their rank. "Trusted" isn't a role: it's earned automatically (5 live deals, an account at least 14 days old, and no removals in 30 days) and lets deals go live without review. Admins can require two-step login for staff (the switch exists but is off). |
| Data pulled | `users`, `sessions`, `login_attempts`, `login_challenges`, `password_resets`, `email_confirmations` |
| Data saved or changed | Accounts, sessions, attempts, and resets with expiry times |
| How it's handled | Suspended members can't sign in, and are pointed to an appeal on the contact form. Errors are friendly and never reveal whether an email has an account. |
| Status | **Working.** Google sign-in is built but off until its keys are set. Reset and confirmation emails go to the outbox until Resend is set up. |
| What it needs from the backend | Nothing. Members stay on DealSnap. The engine authenticates with its own key, not a member account. |

### 3.9 Votes, comments and user submissions
| Part | Walkthrough |
|---|---|
| Name and where it appears | Hearts on every card and deal page; comments on deal pages; `/submit` |
| What the user sees and does | **Votes:** "Love this deal" adds hearts; "Not for me" takes them away. Tap again to take the vote back.<br>**Comments:** one level of replies (a reply to a reply stays in the thread with "↳ name"), likes, a "Most helpful" comment (one comment with at least 3 likes, once there are at least 3 comments), a "Poster" tag, a 15-minute window to edit your own comment, delete any time, and report.<br>**Posting**, in 3 steps:<br>1. Paste a link and pick the kind of deal.<br>2. Fill in the must-haves.<br>3. Add optional extras, then see a preview. |
| How it works, step by step | **Hearts:** one vote per member per deal. Each vote is worth **4 to 7 hearts** depending on the member's standing (rewarding taking part), and keeps the weight it was cast with. The count shown is the deal's starting number (0 for posted deals) plus the current weight of every vote.<br>**Comment counts** are worked out from the comments table, not counted as they happen (demo deals excepted, see 3.1).<br>**Pasting a link pre-fills the form.** It tries, in order:<br>1. reading the store's page (only trustworthy structured data, never guessing a price from page text);<br>2. the Awin product list for stores that block us;<br>3. an earlier post of the same product;<br>4. the browser extension, which reads the page in the poster's own browser.<br>It also suggests the category, tag and brand, finds possible duplicates from the last 60 days, and spots start dates.<br>**Posting rules:**<br>• Staff and trusted members go live straight away, unless it's a store nobody has posted before; everyone else waits for review.<br>• New accounts have daily posting and hourly comment limits, and can't put links in comments.<br>• A poster's edit to the link, store or photo on a live deal sends it back for review. |
| Data pulled | `deal_votes`, `comments`, `comment_likes`; for the form: the page reader, product lists, earlier posts |
| Data saved or changed | **Votes:** one row per member per deal, with direction and weight. **Comments:** rows with reply links. **New deals:** a `deals` row (status `live` or `pending`), photos, and event ticks. Edits are recorded in `deal_edits`. |
| How it's handled | Guests are asked to sign in (votes) or sign up (posting, with the draft kept). Hearts update straight away on screen and then match the server's total. Rate limits on link reading per visitor. |
| Status | **Working** |
| What it needs from the backend | Engine "What's this link?" for pre-filling (connection 1). Bot posts come in through connection 2. |

### 3.10 Moderation
| Part | Walkthrough |
|---|---|
| Name and where it appears | Report links on deals, comments and profiles; "Deal ended?"; `/admin/deals`, `/admin/comments`, `/admin/users`; the helper desk at `/helper`; ⋯ menus for staff on deal pages |
| What the user sees and does | **Members:** report a deal, comment or profile (with Undo); say a deal has ended; block a member.<br>**Helpers** (hand-picked members): a desk listing deals that were reported, may have ended, end soon, have a thin description, have no photo, have a code not working, or have unsure labels. They can fix details, mark a deal ended, or press "All good". They can't change a deal's link or store, and can't remove anything.<br>**Moderators:** approve or reject pending deals; take down and restore; edit; remove comments; suspend members; pass decisions up to an admin.<br>**Admins:** everything, plus permanent delete, roles and settings. |
| How it works, step by step | Every decision has a reason the affected person can read, and is written to the **activity log**. Rank rules apply: a helper only fixes members' deals, a moderator only acts on members and helpers. If two staff act on the same item at once, the second is told what changed instead of overwriting it. **Expiring:** an end date, enough members' "ended" reports, or one from staff or the poster. **Taking down:** status set to removed (hidden, with a reason shown to the poster). **Deleting:** admins only, and permanent. The poster can withdraw their own pending deal; a live one is marked ended instead. |
| Data pulled | `deal_reports`, `comment_reports`, `profile_reports`, `ended_report_strikes`, `escalations`, `deal_checks`, `deal_fixing`, `desk_snoozes`, `audit_log`, `user_notes` |
| Data saved or changed | Statuses, reasons, the activity log, edits, and member suspensions |
| How it's handled | Each staff page checks its own permission. Helpers never get into `/admin`. Moderator limits per hour raise a flag for admins. |
| Status | **Working** |
| What it needs from the backend | Bot deals go into the same queue when "check before it goes live" is on. The engine should receive taken-down and expired results for its deals, so it stops re-posting them. |

### 3.11 Admin (including the deal engine settings)
| Part | Walkthrough |
|---|---|
| Name and where it appears | `/admin/*` (listed in section 2); **Admin → Deal engine** at `/admin/engine` (admins only) |
| What the user sees and does | **Deal engine page:**<br>• an **on/off switch, off by default** (nothing is posted until an admin turns it on);<br>• **"Most deals it can post in a day": 20 by default**, maximum 200;<br>• **"Check before it goes live": on by default**, so engine deals wait in Admin → Deals for approval;<br>• **the engine's key:** made in Admin, shown once, and only its fingerprint stored; making a new one stops the old one; it can be revoked;<br>• **the bot account:** a "Set up" button creates **DealSnapBot**, which can't be signed into;<br>• **the engine's lookup address**, for connection 1 (an https address only).<br>**Other admin tools you asked about:**<br>• **Product lists:** Admin → Settings → Earnings, per Awin store, with "Use product list" and "Refresh", the product count and the last refresh time.<br>• **Editing deals:** one edit form for everyone.<br>• **"Launch now" and "take down now"** exist for **events and banners** (Admin → Events and Banners), and "Take down" for deals.<br>• **Featured and Hero deals:** the Hero is one deal pinned on top of Most loved.<br>• **Maintenance mode**, and **sign everyone out**.<br>• **Backups and spreadsheet exports.** |
| How it works, step by step | Settings are saved in `site_settings`. Every change is in the activity log. |
| Data pulled and saved | `site_settings`, `site_secrets` (encrypted), `audit_log` |
| How it's handled | The engine page shows a readiness checklist (key made, bot account set up, address saved). |
| Status | **The engine controls work, but nothing uses them yet.** The route the engine would post to and the post-form lookup are **NOT BUILT YET**, waiting for agreement on section 5. |
| What it needs from the backend | The engine itself, and agreement on the two connections |

### 3.12 Notifications and alerts
| Part | Walkthrough |
|---|---|
| Name and where it appears | The bell in the header (count from `/api/notifications/count`), `/notifications`, "Watching" (`/alerts`), Settings → Notifications, browser and app push, email |
| What the user sees and does | **Kinds of notification:**<br>• **alerts:** new deals matching a followed store, category, tag, brand or keyword, optionally only once a deal reaches 25, 100 or 250 hearts, or under a price;<br>• **saved deals:** a saved deal getting popular, or an upcoming deal you saved starting (there are no "ending soon" or "price changed" notices yet: **NOT BUILT**);<br>• **replies and mentions;**<br>• **comments on your deals;**<br>• **your deal approved or removed;**<br>• **heart milestones;**<br>• **new followers.**<br>For each kind, members choose: bell only, push, or email (instantly or as a daily summary at 8am). |
| How it works, step by step | Every notice is written to `notifications` first, and the bell reads that. Push goes to every device the member turned on: web push for browsers, or Apple and Google push for the apps. The email job runs every minute and sends what each member asked for. **Keyword matching:** every word must start a word in the title, store, category or tag, with spelling variants folded together (PS 5 = PS5). |
| Data pulled and saved | `notifications`, `notification_prefs`, `push_subscriptions`, and the alert tables |
| How it's handled | Following someone you've blocked is prevented. Unsubscribe links are in every email, including one-click. |
| Status | **Bell and web push: working.** Email: **built, but not sent** until Resend is set up (goes to the outbox). App push: built, but needs the apps compiled and the Apple and Google keys. |
| What it needs from the backend | Engine deals must go through DealSnap's normal "new deal" step so alerts fire. Engine **updates** (price drop, expiry) could notify savers. |

### 3.13 SEO
| Part | Walkthrough |
|---|---|
| Name and where it appears | Every public page |
| What the user sees and does | — |
| How it works, step by step | **Titles:** every page has its own title and description.<br>• Deal pages: "Title – £price (x% off) at Store", with "[expired]" added when it's over.<br>• Category, store, tag and brand pages use their names.<br>**Canonicals:** every deal and browse page sets one. Filtered versions (`?sort`, `?cat`, `?live`) point back to the plain address.<br>**Sitemap:** `/sitemap.xml`, built on every request. It includes the hubs, events, categories, tags, busy brands, stores and every visible deal.<br>**Structured data:** WebSite; Product plus Offer on deals; BreadcrumbList on category, tag, store, brand and deal pages; Article on blog posts.<br>**Not indexed:** pending deals, quiet brand pages, and private or account pages (blocked in `robots.txt`: `/admin`, `/api/`, `/go/`, login, account pages). AI training crawlers are blocked in `robots.txt`. An Admin switch, "hide from search engines", blocks everything (useful for test copies).<br>**Share images:** for each deal and each blog post. A Google Search Console verification token can be entered in Admin. |
| Data pulled | Catalogue and settings, live |
| Data saved or changed | Nothing |
| How it's handled | **Clearing caches after changes:** there's nothing to clear today, because every page and the sitemap are built fresh on each request. Actions refresh the pages in the visitor's own browser. **Once Cloudflare caching is added**, logged-out pages will need short cache times or a purge when the engine updates a deal. |
| Status | **Working** |
| What it needs from the backend | `updated_at` on engine deals, for the sitemap's "last modified" |

### 3.14 Compliance labels
| Part | Walkthrough |
|---|---|
| Name and where it appears | The footer, the phone menu, Get deal buttons, the cookie banner, `/privacy`, `/terms`, `/guidelines` |
| What the user sees and does | **Affiliate disclosure:** while switched on in Admin, every Get deal button has a "*". The note ("*We may earn a commission…") is in the footer and phone menu, and links to "How we make money" in the Terms (the wording is editable in Admin).<br>**"Ad" labels:** **NOT BUILT.** Nothing is paid placement: Featured and Hero are staff picks with no payment, and ranking is by hearts.<br>**Reference-price labels** ("RRP", "Was price on 1 Oct"): **NOT BUILT.** The struck-through was-price has no label. The "Price check" on deal pages compares only with earlier DealSnap posts and says "on DealSnap".<br>**Cookie banner:** built to UK PECR and ICO guidance. It shows only when Google Analytics, Tag Manager or custom code is set up. There are two optional kinds, analytics and marketing, each its own choice, and nothing optional runs before a yes. "Reject all" and "Accept all" are equal buttons. It asks again after 6 months. "Cookies" in the footer reopens it.<br>**Privacy and Terms** cover: UK GDPR rights, data download and deletion, a full cookie table, the Online Safety Act reporting and complaints route, fake reviews, and the phone apps and extension. The company details are **placeholders** and need a lawyer's review. |
| Data pulled and saved | Settings in the database; consent choices in the visitor's browser |
| Status | Disclosure, cookie banner and legal pages: **working**. Ad labels and reference-price labels: **NOT BUILT YET**. |
| What it needs from the backend | `was_price_type` (RRP, previous price, average) and its date to show a proper reference-price label. Price history to prove "was" prices (CMA and DMCC Act rules). An `is_affiliate` flag isn't needed for the label: the "*" shows on every Get deal. |

### 3.15 Analytics
| Part | Walkthrough |
|---|---|
| Name and where it appears | Site-wide, plus Admin → Insights |
| What the user sees and does | — |
| How it works, step by step | **Google Analytics 4 or Google Tag Manager:** optional. Switched on by entering an ID in Admin → Settings → Tracking & code, and loaded **only after analytics consent**, with Google consent mode signals sent first. **No custom events are sent: page views only.** **Custom code:** for other tools (such as Meta or TikTok), only after marketing consent, naming who it's from.<br>**Admin → Insights** (own database, no outside tool):<br>• new members, deals posted, comments;<br>• Get deal clicks, most-clicked deals, stores by clicks;<br>• "Stores to apply for next" (clicks with no earning route);<br>• "What members want" (alert words, stores, categories, products and brands members follow);<br>• "Autofill by store" (how often link reading worked per store).<br>Time ranges are 24 hours, 7, 30 or 90 days, or all time. |
| Data pulled | `deal_clicks`, users, deals, comments, the alert tables, `autofill_reports` |
| Data saved or changed | Clicks (see 3.5) |
| Status | Insights: **working**. GA: **built, but no ID set**. |
| What it needs from the backend | Network sales and commission reports (from Awin's API), matched to DealSnap's click reference, for "earned per deal" (**NOT BUILT**) |

---

## 4. New, planned or changed since the demo (18 October)

**Built since 18 October:**
- **Search:** Best match, Most loved and New sorts on search results; a search rebuild (typos, synonyms, every word must match).
- **Categories, tags and brands:**
  - A categories page.
  - Plural addresses everywhere: `/stores/…`, `/tags/…`, `/brands/…`, `/categories/…`.
  - Each deal now has one type (category › tag › sub-tag) plus an optional brand; about 85 brands, with pages, logos and alerts.
- **Deal types:** price drops, sales, multi-buys, vouchers, cashback and freebies, with per month or per person, "from" prices, conditions, and a Type filter.
- **Post a deal:**
  - A 3-step form with a preview.
  - Photos from the link or an upload.
  - A link reader, a duplicate checker and the Turnstile hook.
  - Sharing to DealSnap from Android's Share menu, and an iPhone Shortcut.
  - "Post this deal" from the browser extension.
- **Earning:** affiliate tagging at click time; the Awin connection (encrypted token, store sync, Create-a-Feed product lists for stores that block us); an Earnings tab in Admin.
- **Security and speed:** a security audit (hashed sessions, real visitor addresses, safe link reading); performance fixes for large catalogues.
- **Team tools:**
  - Ranks, badges, named permissions, and Helpers with a helper desk.
  - "Checked by DealSnap helpers" and "Did this code work?".
  - Protection when two staff act on the same thing at once; staff impact pages.
- **Content and events:** shopping events (Black Friday, Christmas) and site banners, run from Admin.
- **Stores page:** perk filters and a "Your stores" row.
- **Comments rebuilt:** one-level threads, "Most helpful", a 15-minute edit window.
- **Account:** My account and Settings redesigned for phones.
- **Upcoming deals:** "Starts Fri 8am", "Remind me" and a start notification.
- **Admin → Deal engine controls:** off, 20 a day, check first, key, DealSnapBot, lookup address.
- **UK cookie banner.**
- **Phone apps:** iPhone and Android shells with native notifications (not compiled yet).
- **Footer pages:** Terms, Privacy, Guidelines and Contact redone, including the Online Safety Act complaints route.
- **Product lists** moved into their own file, out of backups.

**Planned (next):**
- The engine connections (section 5), once agreed.
- **Launch basics:**
  - email (Resend), Turnstile keys, two-step login required for staff;
  - off-server backups (continuous copies to Cloudflare R2), uptime and error alerts;
  - hosting behind Cloudflare.
- Moving off the old Awin account.
- **Before launch:**
  - remove the demo catalogue and its fixed counts;
  - fill in the company details in the legal pages;
  - a load test with lots of data.
- **Later:**
  - "Lowest in 90 days" and reference-price labels, from engine price history;
  - a hearts-only leaderboard after launch.

---

## 5. Engine connections (proposed): comments

**Overall:** the shape suits how DealSnap is built. The guard rails are ready in Admin, and these will be built on DealSnap's side once the details below are agreed. Server to server, HTTPS, a shared key plus a signed body: agreed. The proposal:
- **Key:** the engine sends the key made in Admin → Deal engine (DealSnap stores only its fingerprint) in the `Authorization: Bearer` header.
- **Signature:** an HMAC-SHA256 signature of the body and a timestamp, in a `X-Signature` header. DealSnap refuses anything older than 5 minutes, so a captured request can't be replayed.

### Connection 1: "What's this link?" (DealSnap → engine, `POST /v1/links/resolve`)
- **Fits:** the post form already has a slot for this, in the same place the Awin product lists fill today, and Admin already stores the engine's address. **NOT BUILT YET** on DealSnap's side.
- **Timeout:** DealSnap will wait about **2 seconds**, then carry on without it.
- **Please add to the reply:**
  - `kind` (price, sale, multibuy, voucher, cashback or freebie) and `offer` text for non-price deals;
  - `voucher_code`;
  - `delivery` (a number, 0 = free; leave it out if unknown);
  - `in_stock`;
  - `brand`;
  - a category hint (the store's own category trail is ideal; DealSnap maps it to its own types);
  - `conditions` where known.
- **`affiliate_url` and `is_affiliate`:** DealSnap won't use these for the link. It stores the plain store link and tags it when someone clicks. Please send the plain link as `url`. `is_affiliate` is useful for Insights.
- **`price_checked_at`:** yes please. DealSnap will show "price checked x ago" once it's built.

### Connection 2: "Here's a good deal" (engine → DealSnap)
- **Route:** `POST /api/engine/deals` is fine. It's **NOT BUILT YET**. One route for all four events, with an `event` field, is simplest.
- **How bot posts are created:**
  - They're created exactly like a member's post, under **DealSnapBot**, so they go through the same checks, photo processing, duplicate check, alerts and listing. They get **no ranking boost**: hearts decide.
  - If "check before it goes live" is on, they arrive as `pending` in Admin → Deals.
  - If the engine is switched off, or the daily limit is reached, the deal is refused with a clear reason (`paused` or `cap_reached`), so the engine can try again later.
- **Reply:** `{ status: live | pending | refused, reason?, slug, url }`.
- **Re-sending the same `deal_id`:** this updates the deal. DealSnap needs a new lookup from `deal_id` to its own slug (a small table). **Updates won't overwrite staff edits** to the title or description; they will update price, photo and end date. Agreed?
- **Events:**
  - `deal.updated` changes the deal and records the edit;
  - `deal.expired` sets the end date to now, so it shows as Expired;
  - `deal.taken_down` sets it to removed.
- **Field mapping:**

| Engine field | DealSnap field | Note |
|---|---|---|
| `title` | `title` | Tidied up the same way as members' titles |
| `store` | `store` | Please also send the store's **domain**: DealSnap matches stores by name, and the domain is the safer key |
| `category` | `category` + `tag` | DealSnap maps it to its own types. Send the store's category trail and DealSnap's suggester picks the type. |
| `price`, `was_price` | `price`, `originalPrice` | |
| `was_price_type` | **new field** | Needed for a reference-price label (NOT BUILT) |
| `discount_pct` | (worked out) | Not needed: DealSnap works it out from the two prices |
| `score` | **new field** | Stored for Admin; not used for ranking |
| `image_url` | photo | DealSnap downloads it and re-saves it as WebP |
| `go_url` | `url` | Please send the **plain store link**. DealSnap adds its own tag at click time and strips other people's tags. |
| `offers[]` | `kind`, `offer`, `voucherCode`, `conditions` | Agree the list of offer types against section 3.7 |
| `delivery` | `delivery` | A number (0 = free), or leave it out if unknown |
| `is_affiliate` | **new field** | Optional, for Insights |
| `price_checked_at` | **new field** | For "price checked x ago" |
| `expires_at` | `expiresAt` | |
| (add) `starts_at` | `startsAt` | For upcoming deals |
| (add) `description` | `description` | A short plain-text description; Markdown and HTML are not interpreted |
| (add) `where_to_buy` | `whereToBuy` | `online` or `instore` |

- **Does a push refresh cached pages?** Today there's nothing to refresh: every page is built fresh on each visit, so a pushed deal shows straight away everywhere, including the sitemap. When Cloudflare caching is added, DealSnap will purge the affected pages itself after a push.

### Connection 3: "What has this cost before?" (later, `GET /v1/products/{id}/price-history?days=90`)
- Fine as proposed. DealSnap would call it from the deal page with a short cache (about an hour), and show "Lowest price in 90 days" next to the price.
- DealSnap would need the engine's `product_id` stored on each deal: for bot deals from the push, and for member deals from connection 1.
- Not available for Amazon: understood. DealSnap will show nothing rather than a guess.
- Today's "Price check" (comparing with earlier DealSnap posts) stays as a fallback.

---

## 6. Open decisions (my view)

1. **What "20 a day" means:** a cap on **engine deals going live (or into the queue) per UK calendar day**. Members' posts are never counted. The engine should send its best picks first. Anything over the cap is refused with `cap_reached`, so nothing silently piles up.
2. **Moving off the Offercry Awin account:** do it **now**, before launch, because approvals take weeks. Ask Awin whether DealSnap can be added as a new website on the existing account, or needs its own. If a company is being set up for DealSnap, a **new publisher account in the company's name** is cleanest, so payments go to the company. Then re-apply to stores and re-run "Sync my stores".
3. **Who owns which tables:** agreed in principle. **The engine owns** products, prices, price history, retailers, feeds, scores and raw offers. **DealSnap owns** users, deals as published posts, votes, comments, reports, notifications, alerts, saves, moderation, clicks, and store page content (descriptions, perks, logos, display names). The link between them: the engine's `deal_id` and `product_id`, stored on DealSnap's deal.
4. **Where clicks are logged:** **DealSnap.** It already logs every Get deal click (deal, member if signed in, time), adds the affiliate tag when someone clicks, and passes the deal reference to the network. The engine can get a daily click summary from an endpoint if it needs one for scoring. Sales and commission reports from Awin are best pulled by the engine, matched on the deal reference.
5. **Where the admin screens live:** **both, split by who uses them.** DealSnap Admin keeps what founders and moderators use day to day: the engine on/off switch, the daily cap, the review queue for bot deals, and taking down. The engine's own admin handles the technical side: feed health, scoring rules, and retailer and category mapping.
6. **Who owns the master store list:** **the engine**, for retailer facts (domains, network IDs, feeds), keyed by domain. **DealSnap** keeps the display name and store page content, linked by the same domain. DealSnap has no store table today, so the engine's list would become the reference it matches against.
7. **One shared Postgres, or separate databases:** **separate.** DealSnap runs on its own small database next to the app (fast and simple), and the engine's data will be far bigger, with different needs. Sharing a database would tie the two together, so a slow engine job could slow the website. They should talk only through the connections in section 5.
8. **Who schedules the drip release:** **the engine decides what and when** (it knows freshness and score). **DealSnap enforces the guard rails:** the on/off switch, the daily cap, and review first. For launch, a one-off bulk load could use a temporary higher cap with review first on. After that, one deal every 10–15 minutes from the engine fits comfortably within a cap of 20 to 100 a day.

---

## Appendix: data map

"Own DB" means DealSnap's database. "Catalogue" means demo deals plus posted deals, merged when a page is built. Demo values are marked **mock**.

| Field | Where shown | Source today | Should come from |
|---|---|---|---|
| Deal title `title` | Card, page, search, share image, page title | Mock (demo) / own DB (posted) | Engine (bot) / DealSnap (members) |
| Deal URL slug `slug` | Everywhere | Mock / own DB (made from the title plus a short ID) | DealSnap |
| Description `description` | Deal page, search ranking, share text | Mock / own DB | Engine / DealSnap |
| Product image | Card, page, share image | Bundled demo photos / own DB (two WebP sizes) | Engine `image_url`, re-saved by DealSnap |
| Store name `store` | Card, page, store pages, filters | Mock / own DB, tidied to one spelling per store | Engine (by domain) ↔ DealSnap display name |
| Store logo | Store tiles and pages, alerts | Own DB (fetched from the store's website or uploaded) | DealSnap |
| Store details, perks and FAQ | Store page ⓘ panel and questions, perk filters | Own DB (researched 25 October, editable in Admin) | DealSnap (engine could supply delivery thresholds) |
| Awin programme (`domain, merchant_id, name, source, stopped, has_list`) | Admin only; used by `/go` | Synced from Awin about daily (own DB) | Engine (retailer master) or DealSnap; agree which |
| Category `category` | Card trail, filters, category pages | Fixed list in code; set by the poster with suggestions | Engine hint → DealSnap mapping |
| Type (tag or sub-tag) `tag` | Trail, tag pages, filters | Fixed list in code; poster plus suggester, checked by helpers | Engine hint → DealSnap mapping |
| Brand `brand` | Deal page, brand pages, filter, alerts | Own DB brand list; detected from the title or set by the poster | Engine / DealSnap |
| Labels unsure `labelsUnsure` | Helper desk | Own DB | DealSnap |
| Deal type `kind` | Price block, Type filter | Mock / own DB | Engine `offers[]` / DealSnap |
| Offer text `offer` | Price block for sales, multi-buys, vouchers, cashback, freebies | Own DB | Engine / DealSnap |
| Price `price` | Card, page, page title, share image | Mock / own DB | Engine |
| Was-price `originalPrice` | Card, page (struck through, **no label**) | Mock / own DB | Engine |
| Reference-price type and date | **Not shown** | — | Engine `was_price_type` (NOT BUILT on DealSnap) |
| % off | Card, page, page title, share image | Worked out from price and was-price | Worked out by DealSnap |
| Per month, year, person or night `priceUnit`; "from" `priceFrom`; cashback `cashback` | Price block | Own DB | Engine / DealSnap |
| Conditions `conditions` (new customers, members, app, students, selected lines) | Card small print, page | Own DB | Engine / DealSnap |
| Voucher code `voucherCode` | Page, store "Codes" list | Mock / own DB | Engine / DealSnap |
| Code worked or failed counts, last worked | Page, store codes | Own DB (`code_reports`) | DealSnap |
| Delivery `delivery` | Card, page | Mock / own DB | Engine / DealSnap |
| Online or in-store `whereToBuy`, `whereNote` | Card badge, page | Own DB | Engine / DealSnap |
| Deal score | Not shown | — | Engine (stored for Admin only) |
| Price checked at | Not shown | — | Engine |
| Lowest in 90 days | Not shown | — | Engine (connection 3) |
| Price check (versus earlier DealSnap posts) | Deal page | Worked out from the catalogue | DealSnap (fallback) |
| Starts at `startsAt` | "Starts Fri 8am" pill, "Remind me" | Own DB | Engine / DealSnap |
| Expiry `expiresAt`, expired flag | Card, page, page title | Mock (demo: hours from server start) / own DB / members' "ended" reports | Engine (bot) / DealSnap (members and reports) |
| Ended by members, staff or poster | Expired label wording | Own DB (ended reports) | DealSnap |
| Status `status` (live, pending, removed) | Admin; hides deals | Own DB (demo deals: override list) | DealSnap |
| Featured `featured`, Hero `hero` | Card and page badges, Hero pinned top | Own DB (staff picks) | DealSnap |
| Ad or affiliate label | "*" on Get deal plus a footer note | Settings | DealSnap (no per-deal flag needed) |
| Outbound link `url` | Get deal via `/go` | Mock (store home pages) / own DB (store link) | Engine plain store link; DealSnap adds the tag |
| Click count | Admin Insights | Own DB (`deal_clicks`) | DealSnap |
| Hearts `hearts` and my vote | Card, page, sorting, profile stats | Demo: fixed starting number plus real votes / own DB votes (4–7 hearts each) | DealSnap |
| Comment count `commentCount` | Card, page | **Demo: fixed mock number (the mismatch)** / own DB counted | DealSnap |
| Comments, likes, "Most helpful" | Deal page, profile | Own DB | DealSnap |
| Poster name, avatar, rank `postedByUsername`, `postedByAvatarUrl`, `postedByRole` | Card, page | Demo: "DealBot" plus 5 demo members / own DB | DealSnap (bot deals: DealSnapBot) |
| Poster stats (joined, deals, hearts received) | Deal page About panel | Own DB | DealSnap |
| Checked by helpers at | Deal page | Own DB (`deal_checks`) | DealSnap |
| Posted time `postedAt` | Card, page, New sort | Mock (re-spread at each start) / own DB | DealSnap (time it went live) |
| Edited at `editedAt` | Deal page "edited" | Own DB | DealSnap |
| Events (Black Friday…) | Deal page chip, event pages | Own DB (ticks plus keywords) | DealSnap |
| Related deals | Deal page row | Worked out (same tag, then category) | DealSnap |
| Search suggestions | Header typeahead | `/api/search`, built-in search over the catalogue | DealSnap (a search index later) |
| Notifications | Bell, `/notifications`, push, email | Own DB | DealSnap |
| Alerts (stores, categories, tags, brands, keywords with price) | `/alerts`, bells | Own DB | DealSnap |
| Saved deals | `/saved`, Save button | Own DB | DealSnap |
| Profile and stats, badges and tiers, followers | `/u/[username]`, `/profile` | Own DB plus catalogue | DealSnap |
| Blog posts | `/blog` | Own DB | DealSnap |
| Engine settings (on/off, 20 a day, check first, key, bot account, lookup address) | `/admin/engine` | Own DB (`site_settings`; key fingerprint only) | DealSnap |
| Product lists (Awin) | Post form autofill; Admin → Earnings | Separate product-lists file, refreshed about daily | Engine (replaces it) |

---

### Still to send
- **Screenshots per page:** sent with this file as `DealSnap_Screenshots_2026-11-01.zip`. It holds 66 full-page shots at computer size (1280px wide) and 37 at phone size (390px wide), named by page in the order of section 2, plus a deal's share image. They were taken on 1 November from a copy of the site signed in as a test admin; real email addresses were swapped for test ones. On the phone shots of deal pages, the price-and-Get-deal bar halfway down is the sticky bar that follows you as you scroll, caught by the full-page capture.
- **Answers on the open decisions:** in section 6 above.
