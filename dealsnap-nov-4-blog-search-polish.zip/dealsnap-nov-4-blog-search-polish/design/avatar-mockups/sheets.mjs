// Lays the screenshots out side by side, one sheet per device. Run: node sheets.mjs <shotsDir> <outDir>
import { writeFileSync, mkdirSync } from "node:fs";
import { execFileSync } from "node:child_process";
const [IN, OUT] = process.argv.slice(2);
mkdirSync(OUT, { recursive: true });
const CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const NAME = { honor: "Android phone (Honor, 360px wide)", iphone: "iPhone (390px wide)", tablet: "Tablet (768px wide)", desktop: "Laptop / desktop (1280px wide)" };
const panels = [["list", "now", "List view: now"], ["list", "new", "List view: proposed"], ["swipe", "now", "Cards view: now"], ["swipe", "new", "Cards view: proposed"]];
for (const [dev, w, h, cols, shown] of [["honor", 360, 780, 4, 360], ["iphone", 390, 844, 4, 390], ["tablet", 768, 1024, 2, 560], ["desktop", 1280, 800, 2, 840]]) {
  const ph = Math.round((h * shown) / w);
  const html = `<!doctype html><meta charset=utf-8><style>
  body{margin:0;padding:28px;background:#f4f4f5;font-family:system-ui,sans-serif;color:#18181b}
  h1{font-size:22px;margin:0 0 4px} p{margin:0 0 20px;color:#52525b;font-size:14px}
  .g{display:grid;grid-template-columns:repeat(${cols},${shown}px);gap:24px}
  figure{margin:0} figcaption{font-weight:700;font-size:15px;margin-bottom:8px}
  figcaption.new{color:#c2410c}
  img{width:${shown}px;height:${ph}px;object-fit:cover;object-position:top;border-radius:14px;border:1px solid #d4d4d8;display:block;background:#fff}
  </style><h1>${NAME[dev]}</h1><p>Proposed: poster's round avatar sits on the photo's bottom-left corner, ringed in their rank colour with a small rank icon. The name stays in the row, in the rank colour. Sample names and ranks are for illustration.</p>
  <div class=g>${panels.map(([v, m, l]) => `<figure><figcaption class=${m}>${l}</figcaption><img src="file://${IN}/${dev}-${v}-${m}.png"></figure>`).join("")}</div>`;
  const f = `${OUT}/${dev}.html`;
  writeFileSync(f, html);
  const rows = cols === 4 ? 1 : 2;
  const W = cols * shown + (cols - 1) * 24 + 56;
  const H = rows * (ph + 40) + (rows - 1) * 24 + 150;
  execFileSync(CHROME, ["--headless=new", "--hide-scrollbars", "--force-device-scale-factor=2", `--window-size=${W},${H}`, `--screenshot=${OUT}/${dev}-sheet.png`, "--allow-file-access-from-files", "--user-data-dir=/private/tmp/claude-501/mock-chrome2", `file://${f}`], { stdio: "ignore" });
  console.log(`${OUT}/${dev}-sheet.png`, W, H);
}
