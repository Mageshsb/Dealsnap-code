// Makes the poster-avatar mock-ups: takes real screenshots of the running site
// (default http://localhost:3001) and, for the "new" version, adds the
// proposed avatar + rank mark on the photo in the page before shooting.
// Nothing in the site's code changes. Run: node shoot.mjs <outDir>
import { spawn } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";

const OUT = process.argv[2];
const SITE = process.env.SITE ?? "http://localhost:3001";
mkdirSync(OUT, { recursive: true });

const DEVICES = {
  honor: { w: 360, h: 780, dpr: 2, mobile: true },
  iphone: { w: 390, h: 844, dpr: 2, mobile: true },
  tablet: { w: 768, h: 1024, dpr: 1.5, mobile: false },
  desktop: { w: 1280, h: 800, dpr: 1, mobile: false },
};

const chrome = spawn(
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  ["--headless=new", "--remote-debugging-port=9333", "--user-data-dir=/private/tmp/claude-501/mock-chrome", "--no-first-run", "--hide-scrollbars", "about:blank"],
  { stdio: "ignore" },
);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let targets;
for (let i = 0; i < 40; i++) {
  try {
    targets = await (await fetch("http://127.0.0.1:9333/json")).json();
    if (targets.length) break;
  } catch {}
  await sleep(250);
}
const page = targets.find((t) => t.type === "page");
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r) => (ws.onopen = r));
let id = 0;
const waiting = new Map();
ws.onmessage = (m) => {
  const d = JSON.parse(m.data);
  if (d.id && waiting.has(d.id)) waiting.get(d.id)(d);
};
const send = (method, params = {}) =>
  new Promise((res, rej) => {
    const n = ++id;
    waiting.set(n, (d) => (d.error ? rej(new Error(JSON.stringify(d.error))) : res(d.result)));
    ws.send(JSON.stringify({ id: n, method, params }));
  });
const evaluate = async (expression) => {
  const r = await send("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true });
  if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails));
  return r.result.value;
};

// What the page runs before a shot. mode: "now" (the live site, plus some
// sample ranks so each colour shows) or "new" (that, plus the proposed
// avatar + rank mark on the photo corner).
const INJECT = (mode, view) => `(() => {
  const POSTERS = [
    ["Jat", "admin"], ["Priya_Sharma", "trusted"], ["BargainBen", "helper"],
    ["SaverSam", "moderator"], ["dealhunter42", null], ["Alexandra_Smith", "trusted"],
  ];
  const RANK = {
    admin: { c: "#18181b", icon: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>' },
    moderator: { c: "#4338ca", icon: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>' },
    helper: { c: "#047857", icon: '<path d="M11 12h2a2 2 0 1 0 0-4h-3c-.6 0-1.1.2-1.4.6L3 14"/><path d="m7 18 1.6-1.4c.3-.4.8-.6 1.4-.6h4c1.1 0 2.1-.4 2.8-1.2l4.6-4.4a2 2 0 0 0-2.75-2.91l-4.2 3.9"/><path d="m2 13 6 6"/>' },
    trusted: { c: "#0369a1", icon: '<path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><path d="m9 12 2 2 4-4"/>' },
  };
  const HUES = ["#3b82f6", "#a855f7", "#ec4899", "#14b8a6", "#f59e0b", "#22c55e"];
  const isSwipe = ${view === "swipe"};
  const gos = [...document.querySelectorAll('a[href^="/go/"]')];
  const wide = window.innerWidth >= 640;
  gos.forEach((go, i) => {
    const [name, rank] = POSTERS[i % POSTERS.length];
    const left = go.parentElement.firstElementChild;
    const nameEl = left.querySelector("span.truncate");
    if (!nameEl) return;
    nameEl.textContent = name;
    nameEl.style.fontWeight = rank ? "500" : "";
    nameEl.style.color = rank ? RANK[rank].c : "";
    const rowAvatar = left.querySelector('span[aria-hidden="true"].rounded-full, img.rounded-full');
    const hue = HUES[i % HUES.length];
    if (rowAvatar) {
      if (${mode === "new"}) rowAvatar.style.display = "none";
      else { rowAvatar.textContent = name[0]; rowAvatar.style.background = hue; }
    }
    if (${mode === "new"}) {
      let card = go;
      const sel = isSwipe ? '[class*="max-h-[62.5cqw]"]' : 'a.relative.shrink-0.self-stretch';
      while (card && !card.querySelector(sel)) card = card.parentElement;
      const photo = card && card.querySelector(sel);
      if (!photo) return;
      const big = isSwipe;
      const av = big ? 34 : 26;
      const dot = big ? 17 : 14;
      const wrap = document.createElement("div");
      wrap.style.cssText = "position:absolute;z-index:5;left:" + (big ? 12 : 6) + "px;bottom:" + (big ? 12 : 6) + "px;width:" + av + "px;height:" + av + "px;pointer-events:none";
      const a = document.createElement("div");
      const ring = rank ? RANK[rank].c : "#fff";
      a.style.cssText = "width:100%;height:100%;border-radius:50%;background:" + hue + ";color:#fff;font:600 " + (big ? 14 : 11) + "px system-ui;display:flex;align-items:center;justify-content:center;text-transform:uppercase;box-shadow:0 0 0 2px #fff,0 0 0 " + (rank ? 4 : 2) + "px " + ring + ",0 1px 4px rgba(0,0,0,.35)";
      a.textContent = name[0];
      wrap.appendChild(a);
      if (rank) {
        const d = document.createElement("div");
        d.style.cssText = "position:absolute;right:-" + (dot / 2 - 1) + "px;bottom:-" + (dot / 2 - 1) + "px;width:" + dot + "px;height:" + dot + "px;border-radius:50%;background:" + RANK[rank].c + ";border:1.5px solid #fff;display:flex;align-items:center;justify-content:center";
        d.innerHTML = '<svg viewBox="0 0 24 24" width="' + (dot - 5) + '" height="' + (dot - 5) + '" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">' + RANK[rank].icon + "</svg>";
        wrap.appendChild(d);
      }
      photo.appendChild(wrap);
    }
  });
})()`;

async function shot(device, view, mode) {
  const d = DEVICES[device];
  await send("Emulation.setDeviceMetricsOverride", { width: d.w, height: d.h, deviceScaleFactor: d.dpr, mobile: d.mobile });
  await send("Page.navigate", { url: SITE + "/" });
  await sleep(2500);
  await evaluate(`localStorage.setItem("dealsnap:viewMode", "${view}"); localStorage.setItem("ds_banner_closed", "x")`);
  await send("Page.navigate", { url: SITE + "/" });
  await sleep(3500);
  await evaluate(`document.querySelector('[aria-label*="lose"]')?.click(); window.scrollTo(0,0)`);
  await sleep(500);
  await evaluate(INJECT(mode, view));
  await sleep(800);
  const sw = await evaluate("document.documentElement.scrollWidth");
  const r = await send("Page.captureScreenshot", { format: "png" });
  const file = `${OUT}/${device}-${view}-${mode}.png`;
  writeFileSync(file, Buffer.from(r.data, "base64"));
  console.log(file, "scrollWidth", sw, "of", d.w);
}

await send("Page.enable");
for (const device of Object.keys(DEVICES))
  for (const view of ["list", "swipe"])
    for (const mode of ["now", "new"]) await shot(device, view, mode);

ws.close();
chrome.kill();
