import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    // The test copy's and the screen tests' own builds, and the browser's reports.
    ".next-staging/**",
    ".next-e2e/**",
    "playwright-report/**",
    "test-results/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
    // The phone apps (their own project, with native code).
    "mobile/**",
    // Built copies of the browser extension, and Claude's working copies.
    "dist/**",
    ".claude/**",
  ]),
  // The extension's scripts share names with each other through the page
  // (one file defines what the next one uses), which the checker can't see.
  { files: ["extension/**/*.js"], rules: { "@typescript-eslint/no-unused-vars": "off" } },
  // Plain Node scripts for seeding demo data.
  { files: ["scripts/**/*.js"], rules: { "@typescript-eslint/no-require-imports": "off" } },
]);

export default eslintConfig;
