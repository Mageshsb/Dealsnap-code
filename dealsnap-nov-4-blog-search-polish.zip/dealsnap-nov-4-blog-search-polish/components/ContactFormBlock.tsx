import ContactForm from "./ContactForm";
import { getCurrentUser } from "@/lib/auth";
import { newFormCheck, turnstileSiteKey } from "@/lib/captcha";
import { contactTopic } from "@/lib/contact";

// The contact form, filled in for signed-in members and with a fresh bot check
// per visit. On the Contact page, and wherever a page's HTML has [[contact-form]].
export default async function ContactFormBlock({ topic }: { topic?: string }) {
  const user = await getCurrentUser();
  const siteKey = turnstileSiteKey();
  return (
    <ContactForm
      initialCheck={newFormCheck(!siteKey)}
      turnstileSiteKey={siteKey}
      defaultName={user?.username ?? ""}
      defaultEmail={user?.email ?? ""}
      defaultTopic={contactTopic(topic ?? "")?.value ?? "help"}
    />
  );
}
