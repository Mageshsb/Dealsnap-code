"use client";

import { ReactNode, useRef } from "react";
import Icon from "./Icon";

// A single side-scrolling line. Swipes on touch screens; with a mouse,
// arrow buttons nudge it a card or two at a time.
export default function ScrollRow({ children, label }: { children: ReactNode; label: string }) {
  const ref = useRef<HTMLDivElement>(null);

  function nudge(dir: 1 | -1) {
    const el = ref.current;
    if (el) el.scrollBy({ left: dir * el.clientWidth * 0.8, behavior: "smooth" });
  }

  const arrow =
    "absolute top-1/2 z-10 hidden h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full border border-zinc-200 bg-white text-lg shadow-md hover:bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-900 [@media(hover:hover)]:flex";

  return (
    <div className="relative">
      <div
        ref={ref}
        role="list"
        aria-label={label}
        className="no-scrollbar flex snap-x snap-proximity gap-3 overflow-x-auto scroll-smooth pb-2 pt-1"
      >
        {children}
      </div>
      <button type="button" aria-label="Scroll left" onClick={() => nudge(-1)} className={`${arrow} left-1`}>
        <Icon name="chevron-left" className="size-5" />
      </button>
      <button type="button" aria-label="Scroll right" onClick={() => nudge(1)} className={`${arrow} right-1`}>
        <Icon name="chevron-right" className="size-5" />
      </button>
    </div>
  );
}
