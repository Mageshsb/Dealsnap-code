import Link from "next/link";
import Icon from "./Icon";

// "Show 11 expired" above a profile's Deals and Loved lists: the same tile as on
// Saved deals (grey when off, orange with a tick when on). It belongs to this
// profile page only (a ?show=all in the address, like Saved deals): it never
// touches the "show expired deals" choice in Filters, so playing with it here
// can't change what someone sees on the deal lists.
export default function ShowExpiredTile({
  basePath,
  tab,
  sort,
  defaultSort,
  count,
  showExpired,
}: {
  basePath: string;
  tab: string;
  sort: string;
  defaultSort: string;
  count: number;
  showExpired: boolean;
}) {
  const query = new URLSearchParams([
    ["tab", tab],
    ...(sort !== defaultSort ? [["sort", sort]] : []),
    ...(showExpired ? [] : [["show", "all"]]),
  ]).toString();
  return (
    <Link
      href={`${basePath}?${query}`}
      aria-pressed={showExpired}
      scroll={false}
      className={`flex min-h-9 items-center gap-1.5 rounded-xl px-3 text-sm font-medium transition-colors ${
        showExpired
          ? "bg-orange-500 text-white hover:bg-orange-600"
          : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
      }`}
    >
      {showExpired && <Icon name="check" className="size-4" />}
      {showExpired ? "Showing expired" : `Show ${count} expired`}
    </Link>
  );
}
