"use client";

import { ClearSearch, searchBox } from "@/components/SearchBox";
import {
  useEffect,
  useMemo,
  useOptimistic,
  useRef,
  useState,
  useTransition,
} from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import Icon from "./Icon";
import {
  parseSlug,
  withNarrow,
  type Facet,
  type FacetOption,
  type NarrowParam,
} from "@/lib/deal-filters";
import { NAME_SEARCH_MAX } from "@/lib/search-limits";

// How many options show before the visitor asks for more, and how many it takes
// before a search box earns its place.
const TOP_COUNT = 6;
const SEARCH_FROM = 8;

const WORDS: Record<NarrowParam, { title: string; noun: string; nouns: string }> = {
  store: { title: "Store", noun: "store", nouns: "stores" },
  cat: { title: "Category", noun: "category", nouns: "categories" },
  brand: { title: "Brand", noun: "brand", nouns: "brands" },
  type: { title: "Deal type", noun: "type", nouns: "types" },
};

// The Store dropdown (category/tag/brand pages), Category dropdown (store and
// brand pages) or Brand dropdown (category/tag pages) in the Filters box (Deal
// type has tiles of its own, components/TypeFilter.tsx). One choice at a time; picking one narrows
// this page's list rather than going anywhere. The list re-renders on the
// server; the button shows the new choice straight away while it does.
//
// With few options it's a plain list. With many it shows the top few (most
// deals first), a search box for the rest, and a "Show all" A–Z list. The panel
// opens in the page flow instead of floating, so it can't be clipped by the
// filter sheet or push the page sideways on a phone.
export default function FacetFilter({ facet }: { facet: Facet }) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [, startTransition] = useTransition();
  const [chosen, setChosen] = useOptimistic(parseSlug(params.get(facet.param)));
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [showAll, setShowAll] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);

  const { title, noun, nouns } = WORDS[facet.param];
  const { options } = facet;
  const searchable = options.length >= SEARCH_FROM;
  const current = options.find((o) => o.slug === chosen);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node))
        setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  const q = query.trim().toLowerCase();
  const matches = useMemo(() => {
    if (!q) return [];
    const starts = options.filter((o) => o.name.toLowerCase().startsWith(q));
    const contains = options.filter(
      (o) =>
        !o.name.toLowerCase().startsWith(q) && o.name.toLowerCase().includes(q),
    );
    return [...starts, ...contains];
  }, [options, q]);

  // A single option isn't a choice — unless it's chosen and needs clearing.
  if (options.length < 2 && !chosen) return null;

  function choose(value: string) {
    setOpen(false);
    setQuery("");
    setShowAll(false);
    startTransition(() => {
      setChosen(value);
      router.push(
        withNarrow(
          pathname,
          new URLSearchParams(params.toString()),
          facet.param,
          value,
        ),
        { scroll: false },
      );
    });
  }

  // Most deals first, but never hide the one that's chosen.
  const top = options.slice(0, searchable ? TOP_COUNT : options.length);
  if (chosen && current && !top.includes(current)) top.unshift(current);
  const az = [...options].sort((a, b) => a.name.localeCompare(b.name));
  const hiddenCount = options.length - top.length;

  const row = (o: FacetOption) => {
    const on = o.slug === chosen;
    return (
      <button
        key={o.slug}
        type="button"
        onClick={() => choose(o.slug)}
        aria-pressed={on}
        className={`flex min-h-10 w-full min-w-0 items-center gap-2 px-3 py-2 text-left text-base lg:text-sm ${
          on
            ? "bg-orange-50 font-semibold text-orange-800 dark:bg-orange-950/30 dark:text-orange-200"
            : "text-zinc-800 hover:bg-zinc-50 dark:text-zinc-100 dark:hover:bg-zinc-800"
        }`}
      >
        {o.icon && <Icon name={o.icon} className="size-4 text-zinc-500 dark:text-zinc-400" />}
        <span className="min-w-0 flex-1 truncate">{o.name}</span>
        <span className="shrink-0 text-xs text-zinc-500">{o.count}</span>
        <Icon name="check" className={`size-4 text-orange-700 dark:text-orange-400 ${on ? "" : "invisible"}`} />
      </button>
    );
  };

  const heading = (text: string) => (
    <p className="px-3 pb-1 pt-2.5 text-[11px] font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">
      {text}
    </p>
  );

  const label = current ? current.name : `All ${nouns}`;

  return (
    <section className="flex flex-col gap-2">
      <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">
        {title}
      </h3>
      <div
        ref={boxRef}
        className="flex min-w-0 flex-col gap-2"
        onKeyDown={(e) => {
          if (e.key === "Escape" && open) {
            e.stopPropagation();
            setOpen(false);
          }
        }}
      >
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          aria-label={`${title}: ${label}`}
          className={`relative flex h-10 w-full min-w-0 items-center rounded-xl border pl-3 pr-9 text-left text-base outline-none transition-colors focus:border-orange-400 lg:text-sm ${
            chosen
              ? "border-orange-400 bg-orange-50 font-semibold text-orange-800 dark:border-orange-700 dark:bg-orange-950/30 dark:text-orange-200"
              : "border-zinc-200 bg-white text-zinc-800 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
          }`}
        >
          {current?.icon && <Icon name={current.icon} className="mr-2 size-4" />}
          <span className="min-w-0 flex-1 truncate">{label}</span>
          <Icon
            name="chevron-down"
            className={`pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-zinc-500 transition-transform ${open ? "rotate-180" : ""}`}
          />
        </button>

        {open && (
          <div className="overflow-hidden rounded-xl border border-zinc-200 bg-white dark:border-zinc-700 dark:bg-zinc-900">
            {searchable && (
              <div className="border-b border-zinc-100 p-2 dark:border-zinc-800">
                <div className="relative">
                  <input
                    type="search"
                    value={query}
                    maxLength={NAME_SEARCH_MAX}
                    onChange={(e) => setQuery(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        if (matches[0]) choose(matches[0].slug);
                      }
                    }}
                    placeholder={`Find a ${noun}`}
                    aria-label={`Find a ${noun}`}
                    className={searchBox}
                  />
                  {query && <ClearSearch onClick={() => setQuery("")} />}
                </div>
              </div>
            )}

            <div className="max-h-64 overflow-y-auto overscroll-contain pb-1">
              {q ? (
                matches.length > 0 ? (
                  <>
                    {heading(
                      `${matches.length} match${matches.length === 1 ? "" : "es"}`,
                    )}
                    {matches.map(row)}
                  </>
                ) : (
                  <p className="px-3 py-4 text-sm text-zinc-500">
                    No {noun} matches &ldquo;{query.trim()}&rdquo;.
                  </p>
                )
              ) : showAll ? (
                <>
                  <button
                    type="button"
                    onClick={() => choose("")}
                    className="flex min-h-10 w-full items-center px-3 py-2 text-left text-base text-orange-700 hover:bg-zinc-50 dark:text-orange-400 dark:hover:bg-zinc-800 lg:text-sm"
                  >
                    All {nouns}
                  </button>
                  {heading(`All ${nouns}, A–Z`)}
                  {az.map(row)}
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => choose("")}
                    aria-pressed={!chosen}
                    className={`flex min-h-10 w-full items-center px-3 py-2 text-left text-base lg:text-sm ${
                      chosen
                        ? "text-orange-700 hover:bg-zinc-50 dark:text-orange-400 dark:hover:bg-zinc-800"
                        : "bg-orange-50 font-semibold text-orange-800 dark:bg-orange-950/30 dark:text-orange-200"
                    }`}
                  >
                    All {nouns}
                  </button>
                  {searchable && heading(`Top ${nouns}`)}
                  {top.map(row)}
                  {hiddenCount > 0 && (
                    <button
                      type="button"
                      onClick={() => setShowAll(true)}
                      className="flex min-h-10 w-full items-center px-3 py-2 text-left text-sm font-medium text-orange-700 hover:bg-zinc-50 dark:text-orange-400 dark:hover:bg-zinc-800"
                    >
                      Show all {options.length} {nouns}
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
