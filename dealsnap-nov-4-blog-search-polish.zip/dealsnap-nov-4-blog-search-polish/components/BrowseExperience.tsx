"use client";

import { ReactNode, useRef } from "react";
import { Deal } from "@/lib/types";
import type { LovedDivider } from "@/lib/deal-views";
import { useViewMode } from "./ViewModeProvider";
import DealsList from "./DealsList";
import SwipeDeck, { EmptyDeck } from "./SwipeDeck";
import FilterEmpty from "./FilterEmpty";
import ScrollUpReveal from "./ScrollUpReveal";
import type { ListPromos } from "@/lib/promos";
import type { PageAds } from "@/lib/ads";
import { AdsProvider } from "./AdUnit";
import AdRails from "./AdRails";

export default function BrowseExperience({
  resetKey,
  initialDeals,
  initialHasMore,
  isEmpty,
  query,
  expiredCount,
  category,
  tag,
  store,
  brand,
  view,
  minHearts,
  filterQuery,
  when,
  divider,
  hero,
  heading,
  listFilterBar,
  controls,
  promos,
  fixedType,
  ads,
  swipeLabel,
  sidebar,
  emptyState,
}: {
  resetKey: string;
  initialDeals: Deal[];
  initialHasMore: boolean;
  isEmpty: boolean;
  query?: string;
  expiredCount?: number; // search only: how many matches have expired (listed last)
  category?: string;
  tag?: string;
  store?: string;
  brand?: string; // brand page slug
  view?: string;
  minHearts?: number;
  filterQuery?: string; // ticked stores/categories ("stores=currys,argos")
  when?: string; // Most loved's time window, when not the default
  divider?: LovedDivider; // where Most loved's older deals start
  hero?: ReactNode;
  heading?: ReactNode;
  listFilterBar: ReactNode;
  controls?: ReactNode; // the heading's own <SortAndFilters inList>, repeated in the strip
  promos?: ListPromos; // Admin → Promos: a promo card and a sign-up tile (for people not signed in) that sit in the list
  // A page that only ever lists one type of deal (the Vouchers page): more
  // deals load as that type too. Not a filter the visitor chose, so an empty
  // list says the page's own "nothing here" rather than "clear your filters".
  fixedType?: string;
  ads?: PageAds; // Admin → Ads: what this page's ad spaces show (lib/ad-serving.ts)
  swipeLabel?: ReactNode;
  sidebar?: ReactNode;
  emptyState: ReactNode;
}) {
  const { mode } = useViewMode();
  const headingRef = useRef<HTMLDivElement>(null);
  // When a filter is what emptied the list, say so (with a way back) instead
  // of the page's own "nothing here yet" message.
  const empty = minHearts || filterQuery ? <FilterEmpty minHearts={minHearts} narrowed={!!filterQuery} /> : emptyState;
  // What the list asks for when it loads more: the chosen filters, plus the
  // page's own type.
  const listQuery = [filterQuery, fixedType && `type=${fixedType}`].filter(Boolean).join("&") || undefined;

  if (mode === "swipe") {
    return (
      <AdsProvider ads={ads}>
        <div className="flex flex-1 flex-col">
          <div className="border-b border-zinc-200 bg-white py-2.5 dark:border-zinc-800 dark:bg-black">
            {/* The same width and side padding as the page's own content (and the header), so the strip lines up with it on a wide screen. */}
            <div className="mx-auto max-w-5xl px-4">{listFilterBar}</div>
          </div>

          <div className="flex flex-1 flex-col items-center justify-center gap-2 px-4 py-3">
            {swipeLabel}
            {isEmpty ? (
              <EmptyDeck>{empty}</EmptyDeck>
            ) : (
              <SwipeDeck
                key={resetKey}
                initialDeals={initialDeals}
                initialHasMore={initialHasMore}
                query={query}
                expiredCount={expiredCount}
                category={category}
                tag={tag}
                store={store}
                brand={brand}
                view={view}
                minHearts={minHearts}
                filterQuery={listQuery}
                when={when}
                divider={divider}
                promos={promos}
              />
            )}
          </div>
        </div>
      </AdsProvider>
    );
  }

  return (
    <AdsProvider ads={ads}>
      <div className="flex flex-1 flex-col">
        {/* Comes back under the header as soon as you scroll up. Once the page's
            own Most loved/New and Filters (the end of the heading) are out of
            sight, they come back with it in a row underneath. On laptops that's
            just Most loved/New, as the Filters box stays beside the list. */}
        <ScrollUpReveal
          className="border-b border-zinc-200 bg-white py-2.5 dark:border-zinc-800 dark:bg-black"
          moreAfter={headingRef}
          more={
            controls && (
              <div className="border-b border-zinc-200 bg-white py-2 dark:border-zinc-800 dark:bg-black">
                <div className="mx-auto max-w-5xl px-4">{controls}</div>
              </div>
            )
          }
        >
          <div className="mx-auto max-w-5xl px-4">{listFilterBar}</div>
        </ScrollUpReveal>

        <main className="relative mx-auto flex w-full max-w-5xl flex-1 flex-col gap-6 px-4 py-6">
          {/* Wide screens: an ad column either side, outside the page's own. */}
          <AdRails />
          {hero}
          {heading && <div ref={headingRef}>{heading}</div>}

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_280px]">
            <div className="flex flex-col gap-4">
              {isEmpty ? (
                empty
              ) : (
                <DealsList
                  key={resetKey}
                  promos={promos}
                  initialDeals={initialDeals}
                  initialHasMore={initialHasMore}
                  query={query}
                  expiredCount={expiredCount}
                  category={category}
                  tag={tag}
                  store={store}
                  brand={brand}
                  view={view}
                  minHearts={minHearts}
                  filterQuery={listQuery}
                  when={when}
                  divider={divider}
                />
              )}
            </div>

            {/* Laptops only: phones have the Filters pill in the heading instead. */}
            <div className="hidden lg:block">{sidebar}</div>
          </div>
        </main>
      </div>
    </AdsProvider>
  );
}
