import Link from "next/link";
import Icon from "./Icon";

export default function Pagination({
  basePath,
  tab,
  sort,
  page,
  totalPages,
  keep = {},
}: {
  basePath: string;
  tab: string;
  sort: string;
  page: number;
  totalPages: number;
  keep?: Record<string, string | undefined>; // any other choice on the page (a filter), so paging doesn't undo it
}) {
  if (totalPages <= 1) return null;

  function href(p: number) {
    return `${basePath}${basePath.includes("?") ? "&" : "?"}${new URLSearchParams({ tab, sort, ...Object.fromEntries(Object.entries(keep).filter((e): e is [string, string] => !!e[1])), page: String(p) }).toString()}`;
  }

  return (
    <div className="flex items-center justify-center gap-3 pt-2">
      <Link
        href={href(Math.max(1, page - 1))}
        aria-disabled={page === 1}
        tabIndex={page === 1 ? -1 : undefined}
        className={`inline-flex items-center gap-0.5 rounded-full border border-zinc-300 py-1 text-sm pl-2 pr-3 dark:border-zinc-700 ${
          page === 1
            ? "pointer-events-none opacity-40"
            : "hover:bg-zinc-50 dark:hover:bg-zinc-800"
        }`}
      >
        <Icon name="chevron-left" className="size-4" />
        Prev
      </Link>
      <span className="text-sm text-zinc-500">
        Page {page} of {totalPages}
      </span>
      <Link
        href={href(Math.min(totalPages, page + 1))}
        aria-disabled={page === totalPages}
        tabIndex={page === totalPages ? -1 : undefined}
        className={`inline-flex items-center gap-0.5 rounded-full border border-zinc-300 py-1 text-sm pl-3 pr-2 dark:border-zinc-700 ${
          page === totalPages
            ? "pointer-events-none opacity-40"
            : "hover:bg-zinc-50 dark:hover:bg-zinc-800"
        }`}
      >
        Next
        <Icon name="chevron-right" className="size-4" />
      </Link>
    </div>
  );
}
