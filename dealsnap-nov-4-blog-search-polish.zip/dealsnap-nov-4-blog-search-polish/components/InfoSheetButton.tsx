"use client";

import { ReactNode, useCallback, useState } from "react";
import BottomSheet from "./BottomSheet";
import { InfoIcon } from "./icons";

// The Scroll view's ⓘ: the same panel as the List view's InfoToggle, but in a
// bottom sheet, since opening it under the title would push the card down.
// Styled like the Alert button beside it ("ⓘ Info", or just the icon in a
// 34px circle on phones).
export default function InfoSheetButton({ label, panel, className = "" }: { label: string; panel: ReactNode; className?: string }) {
  const [open, setOpen] = useState(false);
  const close = useCallback(() => setOpen(false), []);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-haspopup="dialog"
        aria-label={label}
        title={label}
        className={`flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-3 py-1.5 text-sm font-semibold leading-5 transition-colors max-sm:h-[34px] max-sm:w-[34px] max-sm:justify-center max-sm:gap-0 max-sm:p-0 ${
          open
            ? "border-orange-500 bg-orange-50 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400"
            : "border-zinc-300 text-zinc-700 hover:border-orange-400 hover:text-orange-600 dark:border-zinc-700 dark:text-zinc-200"
        } ${className}`}
      >
        <InfoIcon className="h-4 w-4" />
        <span className="max-sm:hidden">Info</span>
      </button>
      <BottomSheet open={open} onClose={close} label={label} title={label}>
        {/* The sheet's own title says "About …", so the panel's is hidden. */}
        <div className="text-left [&>div>h2:first-child]:hidden">{panel}</div>
      </BottomSheet>
    </>
  );
}
