import Link from "next/link";
import { Fragment } from "react";
import { ownPath, richBlocks, type Bit } from "@/lib/rich-text";
import type { Picture } from "@/lib/pictures";
import DealCardMini from "./community/DealCardMini";
import InlinePicture from "./InlinePicture";
import { LinkStar } from "./AffiliateNote";

// What a member wrote (a deal's description, a Community post, a comment),
// drawn safely from lib/rich-text.ts with our own elements, never as HTML:
// formatting, bullet points and numbered steps, links, @names, pictures where
// they were put, and deal cards.
//
// Links to other websites go out through /out/<kind>/<id>, which only sends
// people on to an address that is really in that post, after taking out
// anyone else's referral tag and adding the store's earning one where there
// is one (hence the "*", as on "Get deal"). They open in a new tab and tell
// search engines not to count them. Links to this site stay on it.

export type LinkOwner = { kind: "d" | "c" | "p"; id: string };

const LINK = "font-medium text-orange-700 hover:underline dark:text-orange-400";

function Words({ line, hosts, out }: { line: Bit[]; hosts: string[]; out?: LinkOwner }) {
  return (
    <>
      {line.map((bit, i) => {
        let node: React.ReactNode;
        if (bit.type === "text") node = bit.text;
        else if (bit.type === "mention") {
          node = (
            <Link href={`/u/${bit.username}`} className={LINK}>
              @{bit.username}
            </Link>
          );
        } else {
          const own = ownPath(bit.href, hosts);
          node = own ? (
            <Link href={own} className={LINK}>
              {bit.label}
            </Link>
          ) : out ? (
            <a href={`/out/${out.kind}/${encodeURIComponent(out.id)}?to=${encodeURIComponent(bit.href)}`} target="_blank" rel="nofollow ugc noopener" className={LINK}>
              {bit.label}
              <LinkStar />
            </a>
          ) : (
            bit.label
          );
        }
        if (bit.italic) node = <em>{node}</em>;
        if (bit.bold) node = <strong className="font-semibold text-zinc-800 dark:text-zinc-100">{node}</strong>;
        if (bit.strike) node = <s>{node}</s>;
        return <Fragment key={i}>{node}</Fragment>;
      })}
    </>
  );
}

export default function RichContent({
  text,
  format,
  hosts,
  cards = 0,
  pictures = [],
  out,
  className = "flex flex-col gap-3 text-sm leading-relaxed text-zinc-600 dark:text-zinc-400",
  pictureAlt = "from the poster",
}: {
  text: string;
  format: boolean;
  hosts: string[];
  cards?: number;
  pictures?: Picture[];
  out?: LinkOwner;
  className?: string;
  pictureAlt?: string;
}) {
  const byId = new Map(pictures.map((p) => [p.id, p]));
  const blocks = richBlocks(text, { format, hosts, cards });
  const shown = blocks.flatMap((b) => (b.type === "picture" && byId.has(b.id) ? [b.id] : []));
  return (
    <div className={`min-w-0 [overflow-wrap:anywhere] ${className}`}>
      {blocks.map((block, i) => {
        if (block.type === "p") {
          return (
            <p key={i}>
              {block.lines.map((line, l) => (
                <Fragment key={l}>
                  {l > 0 && <br />}
                  <Words line={line} hosts={hosts} out={out} />
                </Fragment>
              ))}
            </p>
          );
        }
        if (block.type === "ul" || block.type === "ol") {
          const items = block.items.map((item, n) => (
            <li key={n}>
              <Words line={item} hosts={hosts} out={out} />
            </li>
          ));
          return block.type === "ul" ? (
            <ul key={i} className="flex list-disc flex-col gap-1 pl-5 marker:text-zinc-400">
              {items}
            </ul>
          ) : (
            <ol key={i} start={block.start} className="flex list-decimal flex-col gap-1 pl-5 marker:font-semibold marker:text-zinc-500">
              {items}
            </ol>
          );
        }
        if (block.type === "deal") return <DealCardMini key={i} slug={block.slug} />;
        const picture = byId.get(block.id);
        if (!picture) return null;
        return <InlinePicture key={i} {...picture} alt={`Picture ${shown.indexOf(picture.id) + 1} ${pictureAlt}`} />;
      })}
    </div>
  );
}
