import Image from "next/image";
import { Deal } from "@/lib/types";
import { hueTheme } from "@/lib/category-theme";
import Icon from "./Icon";
import { IMAGE_SIZES, isPostedPhoto, smallPhoto } from "@/lib/deal-photos";

// Light in both colour schemes: the blend only works against a light tile. The
// inner box carries it too, so the photo blends inside its own stacking context.
const CUTOUT_TILE = "bg-[#ececee]";

export default function DealThumbnail({
  deal,
  iconSize = "size-9",
  sizes = "160px",
  backdrop = false,
  eager = false,
}: {
  deal: Deal;
  iconSize?: string; // the category icon shown when the deal has no photo
  sizes?: string; // how wide the image displays, so next/image picks a sharp enough size
  // Fill the whole tile: a soft, blurred copy of the photo behind the full
  // photo, so every tile looks the same whatever the photo's shape.
  // "compact" is for the narrow list-card tiles: a lighter blur, so it looks
  // as soft as the big tiles' blur does at their size, and a tighter inset.
  backdrop?: boolean | "compact";
  // The first photos on screen (the top deals, a deal's own page): loaded
  // straight away instead of when scrolled to, as they're the biggest thing
  // people see first.
  eager?: boolean;
}) {
  const loading = eager ? ("eager" as const) : undefined;
  const fetchPriority = eager ? ("high" as const) : undefined;
  const theme = hueTheme(deal.labelHue);
  // A voucher with no photo shows its store's logo (the code is for the
  // store, not one product), or a violet ticket when the store has none. A
  // whole-store sale shows the logo too, or a store (lib/deal-kinds.ts).
  const voucherTile = deal.kind === "voucher" && !deal.image;
  const size = deal.imageSize ?? (deal.image ? IMAGE_SIZES[deal.image] : undefined);
  const compact = backdrop === "compact";
  // A product photo on plain white (decided at upload, lib/deal-images.ts): on a
  // soft grey tile with the photo blended in ("multiply"), so the white melts
  // away and the product looks cut out. No blurred copy, rounding or shadow
  // (a shadow would draw a box round it). The tile stays light in dark mode,
  // as the blend needs a light colour to blend with.
  const cutout = !!backdrop && !!deal.imageCutout && !!deal.image;
  // A posted photo is already sized and compressed (see lib/deal-images.ts),
  // so it's shown as it is, not re-processed on every view: the small copy
  // where it shows at 240px or less, the full one elsewhere.
  const posted = !!deal.image && isPostedPhoto(deal.image);
  const shownAtMost = Math.max(...(sizes.match(/\d+(?=px)/g) ?? ["9999"]).map(Number));
  const src = deal.image && shownAtMost <= 240 && !/vw/.test(sizes) ? smallPhoto(deal.image) : deal.image;

  return (
    <div
      className={`relative flex h-full w-full shrink-0 items-center justify-center overflow-hidden ${
        backdrop ? "" : "rounded-lg"
      } ${cutout ? CUTOUT_TILE : voucherTile ? "bg-violet-50 dark:bg-violet-950/40" : theme.tile}`}
    >
      {backdrop && deal.image && !cutout && (
        <Image
          src={smallPhoto(deal.image)}
          alt=""
          aria-hidden
          fill
          unoptimized={posted}
          className={`scale-150 object-cover opacity-60 saturate-150 ${compact ? "blur-xl" : "blur-3xl"}`}
          sizes="64px"
        />
      )}
      {deal.image && size ? (
        // The tile is a size container, so the picture can be sized to the
        // largest box of its own shape that fits (cqw/cqh = the tile's inner
        // width/height). Its rounded corners then sit on the picture itself.
        <div
          className={`relative flex h-full w-full items-center justify-center ${backdrop && !compact ? "p-3" : "p-2"} ${cutout ? CUTOUT_TILE : ""}`}
          style={{ containerType: "size" }}
        >
          <Image
            src={src!}
            alt={deal.title}
            unoptimized={posted}
            width={size[0]}
            height={size[1]}
            className={cutout ? "object-cover mix-blend-multiply" : `rounded-xl object-cover ${backdrop ? "shadow-lg" : ""}`}
            style={{ width: `min(100cqw, calc(100cqh * ${size[0] / size[1]}))`, height: "auto" }}
            sizes={sizes}
            loading={loading}
            fetchPriority={fetchPriority}
          />
        </div>
      ) : deal.image ? (
        <Image src={src!} alt={deal.title} unoptimized={posted} fill className="rounded-xl object-contain" sizes={sizes} loading={loading} fetchPriority={fetchPriority} />
      ) : voucherTile && deal.storeLogo ? (
        // A logo is drawn on white (most are made for it), in a box that
        // keeps to the tile's shape whatever the logo's.
        <span className="flex aspect-square w-[62%] max-w-40 items-center justify-center rounded-2xl bg-white p-[9%] shadow-sm ring-1 ring-violet-200 dark:ring-violet-900">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={deal.storeLogo} alt={`${deal.store} logo`} loading={loading ?? "lazy"} className="max-h-full max-w-full object-contain" />
        </span>
      ) : !deal.image && deal.storeLogo ? (
        // A whole-store sale: its store's logo the same way, on its own tile.
        <span className="flex aspect-square w-[62%] max-w-40 items-center justify-center rounded-2xl bg-white p-[9%] shadow-sm ring-1 ring-zinc-200 dark:ring-zinc-700">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={deal.storeLogo} alt={`${deal.store} logo`} loading={loading ?? "lazy"} className="max-h-full max-w-full object-contain" />
        </span>
      ) : voucherTile ? (
        <Icon name="ticket" strokeWidth={1.5} className={`${iconSize} text-violet-500 dark:text-violet-400`} />
      ) : (
        <Icon name={deal.labelIcon ?? "tag"} strokeWidth={1.5} className={`${iconSize} ${theme.icon}`} />
      )}
    </div>
  );
}
