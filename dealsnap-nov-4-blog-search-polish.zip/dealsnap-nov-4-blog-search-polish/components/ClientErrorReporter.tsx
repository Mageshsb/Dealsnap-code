"use client";

import { useEffect } from "react";

// Tells the site when a script breaks in a visitor's browser (a button that
// does nothing, a menu that won't open), which the server can't see. Only the
// site's own scripts count: errors from browser extensions or other sites'
// code are ignored, and at most five are sent from one page view.
export function reportClientError(message: string, stack?: string) {
  try {
    const body = JSON.stringify({ message: message.slice(0, 300), stack: stack?.slice(0, 1500), path: location.pathname });
    if (!navigator.sendBeacon?.("/api/client-error", new Blob([body], { type: "application/json" }))) {
      void fetch("/api/client-error", { method: "POST", body, keepalive: true, headers: { "content-type": "application/json" } });
    }
  } catch {
    // Nothing more to do.
  }
}

export default function ClientErrorReporter() {
  useEffect(() => {
    let sent = 0;
    const own = (file?: string) => !!file && (file.startsWith(location.origin) || file.includes("/_next/"));
    const onError = (e: ErrorEvent) => {
      if (sent >= 5 || !own(e.filename) || /ResizeObserver loop/.test(e.message)) return;
      sent++;
      reportClientError(e.message, e.error instanceof Error ? e.error.stack : undefined);
    };
    const onRejection = (e: PromiseRejectionEvent) => {
      const reason = e.reason;
      const stack = reason instanceof Error ? reason.stack : undefined;
      if (sent >= 5 || !stack || !/_next\//.test(stack)) return;
      sent++;
      reportClientError(`Unhandled: ${reason.message}`, stack);
    };
    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onRejection);
    return () => {
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onRejection);
    };
  }, []);
  return null;
}
