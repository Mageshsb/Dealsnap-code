"use client";

import { useState, type ReactNode } from "react";
import { useAffiliateNote } from "./AffiliateNote";
import Icon from "./Icon";
import StableLabel from "./StableLabel";
import { copyText } from "./VoucherCode";
import { UPCOMING_BUTTON } from "./UpcomingBits";

// The deal's main button, everywhere it shows (list card, Cards view, deal
// page, the bar along the bottom): opens the store through /go (counted, with
// our earning tag). When the deal has a code it copies the code too, so it's
// ready to paste at checkout, and says so for a moment.
//
// A voucher (the code is the deal) says "Get code" in violet, the colour codes
// have everywhere. Any other deal with a code keeps its orange "Get deal",
// which copies the code just the same. An upcoming deal is "View store" and
// copies nothing yet.
//
// The words swap in the same space (StableLabel), so nothing beside it moves:
// "Copied" with a tick is no wider than "Get code*", so the button keeps the
// size of every other Get deal button, with the words centred.
// `className` sets the size and shape; this sets the colours.
export const VOUCHER_BUTTON = "bg-violet-600 text-white hover:bg-violet-700 dark:bg-violet-600 dark:hover:bg-violet-500";
const DEAL_BUTTON = "bg-orange-500 text-white hover:bg-orange-600";

export default function GetDealButton({
  slug,
  store,
  code,
  voucher = false,
  upcoming = false,
  long = false,
  id,
  tabIndex,
  className = "",
}: {
  slug: string;
  store: string;
  code?: string;
  voucher?: boolean;
  upcoming?: boolean;
  // The deal page's roomier wording for an upcoming deal ("Upcoming · View store").
  long?: boolean;
  id?: string;
  tabIndex?: number;
  className?: string;
}) {
  const star = useAffiliateNote() ? "*" : "";
  const [copied, setCopied] = useState(false);
  const copies = !!code && !upcoming;
  const isVoucher = voucher && !upcoming;

  function onClick() {
    if (!copies) return;
    // Started in the tap itself, before the store opens: browsers only let a
    // page copy while it has the user's attention.
    void copyText(code!).then((ok) => {
      if (!ok) return;
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  }

  const main: ReactNode = upcoming ? (
    <>{long ? "Upcoming · View store" : "View store"}{star}</>
  ) : isVoucher ? (
    <>Get code{star}</>
  ) : (
    <>Get deal{star}</>
  );

  return (
    <a
      id={id}
      href={`/go/${slug}`}
      target="_blank"
      rel="nofollow noopener noreferrer"
      tabIndex={tabIndex}
      onClick={onClick}
      aria-label={copies ? `${isVoucher ? "Get code" : "Get deal"}: copies ${code} and opens ${store}` : undefined}
      className={`${className} ${upcoming ? UPCOMING_BUTTON : isVoucher ? VOUCHER_BUTTON : DEAL_BUTTON}`}
    >
      {copies ? (
        <StableLabel
          center
          show={copied ? "copied" : "main"}
          options={[
            { key: "main", label: main },
            {
              key: "copied",
              label: (
                <>
                  <Icon name="check" className="size-4 shrink-0" />
                  Copied
                </>
              ),
            },
          ]}
        />
      ) : (
        main
      )}
      {/* Said out loud too, for screen readers. */}
      {copies && (
        <span role="status" className="sr-only">
          {copied ? `Code ${code} copied` : ""}
        </span>
      )}
    </a>
  );
}
