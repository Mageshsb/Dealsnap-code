"use client";

import GetDealButton from "./GetDealButton";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Deal } from "@/lib/types";
import { formatShortDate, isEndingSoon, isExpired, timeAgo, timeAgoShort, timeRemaining } from "@/lib/format";
import { dealPriceTag } from "@/lib/deal-kinds";
import { PriceMain, SmallPrint, WasPrice } from "./DealPrice";
import { hueTheme } from "@/lib/category-theme";
import DealThumbnail from "./DealThumbnail";
import VoteButton from "./VoteButton";
import UsernameLink from "./UsernameLink";
import ShareButton from "./ShareButton";
import SaveDealButton from "./SaveDealButton";
import { CommentIcon } from "./icons";
import FeaturedBadge from "./FeaturedBadge";
import HeroRibbon from "./HeroRibbon";
import { slugify } from "@/lib/slug";
import WhereBadge from "./WhereBadge";
import { deliveryLabel } from "@/lib/deal-extras";
import VoucherCode from "./VoucherCode";
import Icon from "@/components/Icon";
import { STARTS_PILL, StartsText } from "./UpcomingBits";
import { isUpcoming } from "@/lib/upcoming";

export default function SwipeCard({ deal }: { deal: Deal }) {
  const router = useRouter();

  // Covers the vote bar as well as the comment/share/get-deal strip — any
  // tap inside either should act like a normal button, not trigger the
  // card's own navigate-to-detail click.
  function isInInteractiveRegion(target: EventTarget | null) {
    return (
      target instanceof HTMLElement &&
      target.closest("[data-vote-region], [data-interactive-region]") !== null
    );
  }

  function handleClick(e: React.MouseEvent) {
    if (isInInteractiveRegion(e.target)) return;
    router.push(`/deals/${deal.slug}`);
  }

  const theme = hueTheme(deal.labelHue);
  const tag = dealPriceTag(deal);
  const endingSoon = isEndingSoon(deal.expiresAt);
  const expired = isExpired(deal.expiresAt);
  const upcoming = !expired && isUpcoming(deal);
  const hero = !!deal.hero && !expired;
  const featured = !!deal.featured && !expired && !hero;
  const delivery = deliveryLabel(deal.delivery);
  // A voucher (the code is the deal) has a dashed violet edge, like a cut-out
  // coupon, in the same footprint as any card. A Featured or Deal of the Day
  // voucher keeps that look's colours, dashed the same way.
  const voucher = deal.kind === "voucher";

  return (
    <div
      onClick={handleClick}
      className={`@container flex h-full w-full select-none flex-col overflow-hidden rounded-3xl bg-white shadow-2xl cursor-pointer dark:bg-zinc-900 ${
        hero
          ? `hero-card ${voucher ? "hero-dashed" : ""}`
          : featured
            ? `featured-glow border-[3px] border-orange-500 ${voucher ? "border-dashed" : ""}`
            : voucher
              ? "border-2 border-dashed border-violet-400 dark:border-violet-700"
              : "border border-zinc-200 dark:border-zinc-800"
      } ${expired ? "opacity-60 grayscale" : ""}`}
    >
      {/* Every card has the same shape: the photo frame is a fixed 16:10 (it
          only shrinks, for every card alike, on short screens), the photo
          fills it over a blurred copy of itself, and the text below always
          takes the same space — two title lines, one price line, one store
          line. A deal's small print rides on the photo as a pill, so it never
          takes room from the text. On short screens the spacing and price
          tighten a little (the max-height variants) so the photo keeps most
          of its size; the title stays full size. */}
      <div className={`relative min-h-0 w-full flex-[1000_1_0%] max-h-[62.5cqw] ${theme.tile}`}>
        <DealThumbnail deal={deal} iconSize="size-24" sizes="(min-width: 640px) 440px, 380px" backdrop />
        {featured && <FeaturedBadge className="left-4 top-4 px-3 py-1.5 text-xs" />}
        {hero && <HeroRibbon className="py-1.5" />}
        {(deal.cashback || deal.conditions?.length) && (
          <div
            className={`absolute left-3 max-w-[calc(100%-1.5rem)] rounded-full bg-white/90 px-2.5 py-1 shadow-sm dark:bg-zinc-900/90 [&_p]:text-zinc-800 dark:[&_p]:text-zinc-100 ${hero ? "bottom-12" : "bottom-3"}`}
          >
            <SmallPrint conditions={deal.conditions} cashback={deal.cashback} className="text-xs" />
          </div>
        )}

        {endingSoon && (
          <div className="absolute right-4 top-4 flex items-center gap-1 rounded-xl bg-red-500 px-2.5 py-1 text-xs font-semibold text-white">
            <Icon name="hourglass" className="size-3.5" />
            {timeRemaining(deal.expiresAt!)}
          </div>
        )}
      </div>

      {/* The photo frame (grow 1000) claims spare height first; once it's full
          size, the rest comes here, above the Get deal and hearts rows, which
          stay together at the bottom of the card. */}
      <div className="flex shrink-0 grow flex-col gap-2 p-4 sm:p-6 [@media(max-height:719px)]:gap-1.5 [@media(max-height:719px)]:p-3">
        {/* Title with the price straight after it. The title always reserves
            two lines (2lh follows the font size, so a phone set to larger text
            still holds), so a one-line title doesn't change the card's shape. */}
        <div className="flex flex-col gap-2 [@media(max-height:719px)]:gap-1">
          <div className="flex items-start justify-between gap-2">
            <h3 className="line-clamp-2 min-h-[2lh] min-w-0 flex-1 text-lg font-bold leading-snug sm:text-xl">
              {deal.title}
            </h3>
            {/* The discount code tucks under the age pill, in the space the
                title leaves free, so it never changes the card's shape. */}
            <div className="flex shrink-0 flex-col items-end gap-1">
              {expired ? (
                <span className="whitespace-nowrap rounded-full bg-zinc-200 px-2.5 py-1 text-[11px] font-medium text-zinc-600 dark:bg-zinc-700 dark:text-zinc-300">
                  Expired
                </span>
              ) : upcoming && deal.startsAt ? (
                <span className={`whitespace-nowrap rounded-full px-2.5 py-1 text-[11px] font-medium ${STARTS_PILL}`}>
                  <span className="sm:hidden">
                    <StartsText startsAt={deal.startsAt} short />
                  </span>
                  <span className="hidden sm:inline">
                    <StartsText startsAt={deal.startsAt} />
                  </span>
                </span>
              ) : (
                <span className="whitespace-nowrap rounded-full bg-zinc-100 px-2.5 py-1 text-[11px] font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">
                  <span className="sm:hidden">{timeAgoShort(deal.postedAt)}</span>
                  <span className="hidden sm:inline">Posted {timeAgo(deal.postedAt)}</span>
                </span>
              )}
              {deal.voucherCode && (
                <div data-interactive-region className="flex max-w-[7.5rem]" onClick={(e) => e.stopPropagation()}>
                  <VoucherCode code={deal.voucherCode} variant="badge" doubtful={deal.codeMayNotWork} />
                </div>
              )}
            </div>
          </div>

          <div className="flex min-h-8 items-baseline gap-2 overflow-hidden whitespace-nowrap sm:min-h-9 [@media(max-height:719px)]:min-h-7">
            {/* An offer ("Buy 1 get 1 half price") is a size down so it
                always fits this one line, even on a 360px phone; the line's
                min-h keeps it the same height as a plain price. */}
            <span className={`font-bold text-orange-700 dark:text-orange-400 ${tag.isOffer ? "text-xl sm:text-2xl [@media(max-height:719px)]:text-lg" : "text-2xl sm:text-3xl [@media(max-height:719px)]:text-xl"}`}>
              <PriceMain tag={tag} />
            </span>
            <WasPrice tag={tag} className="min-w-0 truncate text-base text-zinc-500 dark:text-zinc-400" />
            {tag.off && (
              <span className="text-lg font-bold text-green-700 dark:text-green-400">{tag.off}% off</span>
            )}
          </div>

          {/* Where to buy it, under the price as in List view, so the row
              below has room for the poster's name. */}
          <div
            data-interactive-region
            onClick={(e) => e.stopPropagation()}
            className="flex min-w-0 items-center gap-1.5 whitespace-nowrap text-sm text-zinc-500 dark:text-zinc-400"
          >
            <span className="min-w-0 truncate">
              at{" "}
              <Link href={`/stores/${slugify(deal.store)}`} className="font-semibold text-zinc-700 hover:text-orange-500 hover:underline dark:text-zinc-200">
                {deal.store}
              </Link>
              {delivery && <> · {delivery}</>}
              {deal.expiresAt && !expired && !endingSoon && <> · Ends {formatShortDate(deal.expiresAt)}</>}
            </span>
            <WhereBadge where={deal.whereToBuy} note={deal.whereNote} />
          </div>
        </div>

        {/* Who posted it and comments; Get deal on the right. */}
        <div
          data-interactive-region
          onClick={(e) => e.stopPropagation()}
          className="mt-auto flex min-w-0 items-center gap-3"
        >
          <div className="flex min-w-0 flex-1 items-center gap-1.5 overflow-hidden whitespace-nowrap text-sm text-zinc-500 dark:text-zinc-400">
            {deal.postedByUsername && (
              <UsernameLink
                username={deal.postedByUsername}
                userId={deal.postedByUserId}
                avatarUrl={deal.postedByAvatarUrl}
                role={deal.postedByRole}
                badge="colour"
                size="h-5 w-5"
                className="flex min-w-0 items-center gap-1.5"
              />
            )}
            <Link
              href={`/deals/${deal.slug}`}
              aria-label={`${deal.commentCount} comment${deal.commentCount === 1 ? "" : "s"}`}
              className="ml-1 flex shrink-0 items-center gap-1 text-xs text-zinc-500 dark:text-zinc-400"
            >
              <CommentIcon className="h-[18px] w-[18px]" />
              {deal.commentCount}
            </Link>
          </div>
          <GetDealButton
            slug={deal.slug}
            store={deal.store}
            code={deal.voucherCode}
            voucher={voucher}
            upcoming={upcoming}
            className="flex h-10 shrink-0 items-center rounded-full px-5 text-sm font-semibold [@media(max-height:719px)]:h-9"
          />
        </div>

        {/* The big hearts in the middle, with share and save either side. */}
        <div
          data-vote-region
          onClick={(e) => e.stopPropagation()}
          className="flex items-center justify-between -mb-0.5 border-t border-zinc-100 pt-3.5 dark:border-zinc-800 sm:-mb-1.5 sm:pt-[18px] [@media(max-height:719px)]:-mb-0.5 [@media(max-height:719px)]:pt-2.5"
        >
          <ShareButton url={`/deals/${deal.slug}`} title={deal.title} round />
          <VoteButton initialHearts={deal.hearts} dealSlug={deal.slug} size="lg" />
          <SaveDealButton dealSlug={deal.slug} variant="round" />
        </div>
      </div>
    </div>
  );
}
