import ContactFormBlock from "./ContactFormBlock";
import { pageTokens, type SitePage } from "@/lib/site-pages";

// A page written as HTML and CSS (Admin → Pages → Custom HTML). What is drawn is
// the cleaned copy built by lib/page-html.ts (scripts, event handlers and the
// like removed; the CSS limited to this page), never the text as pasted. That
// is the only place the site puts page code on screen as HTML, so it is the one
// place to check. A page that uses [[contact-form]] arrives in two parts with
// the form between them.
export default async function HtmlPage({ page, topic, children }: { page: SitePage; topic?: string; children?: React.ReactNode }) {
  const { builtHtmlPage, fillHtmlTokens, PAGE_CLASS } = await import("@/lib/page-html");
  const built = builtHtmlPage(page);
  const tokens = pageTokens();
  const [first, second] = built.parts.map((p) => fillHtmlTokens(p, tokens));
  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-6 px-4 py-6">
      {built.css && <style dangerouslySetInnerHTML={{ __html: built.css }} />}
      <div className={PAGE_CLASS} dangerouslySetInnerHTML={{ __html: first }} />
      {second !== undefined && (
        <>
          <ContactFormBlock topic={topic} />
          <div className={PAGE_CLASS} dangerouslySetInnerHTML={{ __html: second }} />
        </>
      )}
      {children}
    </main>
  );
}
