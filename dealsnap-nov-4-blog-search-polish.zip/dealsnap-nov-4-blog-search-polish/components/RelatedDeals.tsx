import { Deal } from "@/lib/types";
import { getRelatedDeals } from "@/lib/mock-deals";
import DealTile from "./DealTile";
import ScrollRow from "./ScrollRow";

// "Related deals" on a deal's page: one line of compact tiles that scrolls
// sideways. Hidden when there's nothing related.
export default function RelatedDeals({ deal }: { deal: Deal }) {
  const related = getRelatedDeals(deal);
  if (related.length === 0) return null;

  return (
    <section className="flex flex-col gap-3" aria-labelledby="related-deals">
      <h2 id="related-deals" className="text-lg font-bold">
        Related deals
      </h2>
      <ScrollRow label="Related deals">
        {related.map((d) => (
          <DealTile key={d.slug} deal={d} />
        ))}
      </ScrollRow>
    </section>
  );
}
