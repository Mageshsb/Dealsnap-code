import Link from "next/link";

// A profile's four tabs. Each is a small two-line tile (name over count) so all
// four fit side by side on the narrowest phones, with nothing hidden off-screen.
export default function ProfileTabs({
  basePath,
  active,
  tabs,
}: {
  basePath: string;
  active: string;
  tabs: { key: string; label: string; count: string }[];
}) {
  const join = basePath.includes("?") ? "&" : "?";
  return (
    <nav aria-label="Profile sections" className="grid grid-cols-4 gap-1.5 sm:flex sm:gap-2">
      {tabs.map((t) => (
        <Link
          key={t.key}
          href={`${basePath}${join}tab=${t.key}`}
          aria-current={active === t.key ? "page" : undefined}
          className={`flex min-h-11 flex-col items-center justify-center rounded-xl px-1 py-1 text-center leading-tight transition-colors sm:flex-row sm:gap-1.5 sm:px-3 sm:py-1.5 ${
            active === t.key
              ? "bg-orange-500 text-white"
              : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300"
          }`}
        >
          <span className="text-[13px] font-medium sm:text-sm">{t.label}</span>
          <span className={`text-xs tabular-nums ${active === t.key ? "text-white/90" : "text-zinc-600 dark:text-zinc-400"}`}>{t.count}</span>
        </Link>
      ))}
    </nav>
  );
}
