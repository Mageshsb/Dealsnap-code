"use client";

import { createContext, lazy, useContext, useSyncExternalStore, type ReactNode } from "react";
import type { AdScreens, AdSlotId, PageAds } from "@/lib/ads";

// The ad itself (components/AdSpace.tsx) is fetched only when a page has an
// ad to show. With ads off, or on a page without any, the browser downloads
// none of the ad code: just this file, which renders nothing.
const AdSpace = lazy(() => import("./AdSpace"));

// The page's ads (lib/ad-serving.ts picks them on the server), handed to every
// ad space inside: the deal list, Cards view, the sidebar, the side columns.
const AdsContext = createContext<PageAds | undefined>(undefined);

export function AdsProvider({ ads, children }: { ads?: PageAds; children: ReactNode }) {
  return <AdsContext value={ads}>{children}</AdsContext>;
}

export const useAds = () => useContext(AdsContext);

// A space set to phones (and tablets) or laptops only is hidden by CSS on the
// others, so it's in the page from the start and nothing moves; a hidden ad
// is never counted, and the ad network skips it.
// (Cards view hides its own card wrapper, which is a flex box.)
export function screenClass(screens: AdScreens, display: "block" | "flex" = "block"): string {
  if (screens === "phones") return "lg:hidden";
  if (screens === "laptops") return display === "flex" ? "hidden lg:flex" : "hidden lg:block";
  return "";
}

// Spaces only some screens show: drawn once the screen is known to be one of
// them, so a hidden space never asks the ad network for an ad no one sees.
const SCREENS: Partial<Record<AdSlotId, string>> = { sidebar: "(min-width: 1024px)" };
const noScreen = () => () => {};
function useScreen(query: string | undefined): boolean {
  return useSyncExternalStore(
    query
      ? (onChange) => {
          const q = window.matchMedia(query);
          q.addEventListener("change", onChange);
          return () => q.removeEventListener("change", onChange);
        }
      : noScreen,
    () => !query || window.matchMedia(query).matches,
    () => !query,
  );
}

// One ad space. `n` says which turn it is in a list (the 1st, 2nd… ad down
// the page), so a list goes round its campaigns. Renders nothing if the page
// has nothing for this space.
export default function AdUnit({ slot, n = 0, cards = false, className = "" }: { slot: AdSlotId; n?: number; cards?: boolean; className?: string }) {
  const ads = useAds();
  const fill = ads?.slots[slot];
  const fits = useScreen(SCREENS[slot]);
  if (!fill || !fits) return null;
  return (
    <AdSpace
      slot={slot}
      fill={fill}
      n={n}
      cards={cards}
      personalised={ads.personalised}
      className={`${cards ? "" : screenClass(fill.screens)} ${className}`}
    />
  );
}
