// The "Ad · who it's from" label every ad carries (UK advertising rules, CAP
// Code 2.1). Its own small file so a deal card can wear it without pulling in
// the ad layouts, which only pages with an ad load.

export function AdTag({ advertiser, className = "" }: { advertiser: string; className?: string }) {
  return (
    <span className={`flex min-w-0 items-center gap-1.5 text-xs text-zinc-500 dark:text-zinc-400 ${className}`}>
      <span className="shrink-0 rounded bg-zinc-800 px-1.5 py-px text-[11px] font-semibold leading-4 text-white dark:bg-zinc-200 dark:text-zinc-900">
        Ad
      </span>
      <span className="truncate font-medium">{advertiser}</span>
    </span>
  );
}
