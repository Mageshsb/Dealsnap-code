import { getPictures } from "@/lib/pictures";
import { getSiteHosts } from "@/lib/site-url";
import RichContent from "./RichContent";

// "About this deal": the poster's words, with their formatting (bold, bullet
// points, numbered steps), links (out through /out, like hotukdeals'), and
// their pictures (a screenshot of where the code goes, how to redeem it)
// where they put them. Drawn by RichContent, as Community posts and comments
// are; the pictures' sizes are one quick look-up, only for a description
// that has any.
export default async function DealDescription({ slug, dealId, description }: { slug: string; dealId: string; description: string }) {
  const pictures = description.includes("[[shot:") ? getPictures("deal", dealId) : [];
  return <RichContent text={description} format hosts={await getSiteHosts()} pictures={pictures} out={{ kind: "d", id: slug }} />;
}
