"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { postCommentAction } from "@/lib/actions";
import { MAX_COMMENT_LENGTH } from "@/lib/comment-rules";
import Icon from "./Icon";
import { shrinkPhoto } from "./DealPhotoField";

// Brings a comment into view and flashes it once it's showing: a new one
// arrives with the refreshed page a moment after posting, and a reply further
// down a thread shows only once the thread has opened.
export function revealComment(id: string, tries = 40) {
  const el = document.getElementById(`comment-${id}`);
  if (!el || !el.getClientRects().length) {
    if (tries > 0) requestAnimationFrame(() => revealComment(id, tries - 1));
    return;
  }
  history.replaceState(null, "", `#comment-${id}`);
  el.scrollIntoView({ behavior: "smooth", block: "center" });
  el.classList.remove("comment-flash");
  void el.offsetWidth; // restarts the flash if it's already run
  el.classList.add("comment-flash");
}

// The box for a new comment (under the heading) or a reply (at the end of a
// thread). A new comment's box sits as one line until it's tapped; a reply's
// opens ready to type, saying who it answers. Posting doesn't reload the page:
// the comment appears and is brought into view.
//
// A comment stays a plain box (no formatting toolbar: they're quick replies,
// and this is on every deal page), with a Picture button for a couple of
// pictures shown under the words: proof it worked at the till, the shelf in
// store, the code being turned down.
export default function CommentComposer({
  dealSlug,
  targetId = null,
  replyingTo,
  onCancel,
  onPosted,
  maxPictures = 0,
}: {
  dealSlug: string;
  maxPictures?: number;
  targetId?: string | null;
  replyingTo?: string;
  onCancel?: () => void;
  onPosted?: () => void;
}) {
  const [text, setText] = useState("");
  // New pictures, shrunk in the browser, as data: addresses.
  const [pictures, setPictures] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [opened, setOpened] = useState(false);
  const [error, setError] = useState("");
  const [pending, startTransition] = useTransition();
  const box = useRef<HTMLTextAreaElement>(null);
  const isReply = !!replyingTo;
  const open = isReply || opened || text.length > 0 || pictures.length > 0;
  const nearLimit = text.length > MAX_COMMENT_LENGTH - 200;

  // A reply box takes the focus when it opens, or when Reply is tapped on
  // another comment in the thread. It's brought to the middle of the screen
  // first, as phones otherwise scroll it behind the header or the keyboard.
  useEffect(() => {
    if (!isReply) return;
    const el = box.current;
    if (!el) return;
    el.focus({ preventScroll: true });
    requestAnimationFrame(() => el.scrollIntoView({ behavior: "smooth", block: "center" }));
  }, [isReply, replyingTo]);

  function post() {
    if (!text.trim() || pending) return;
    setError("");
    startTransition(async () => {
      const sent = new FormData();
      for (const [i, src] of pictures.entries()) {
        const blob = await (await fetch(src)).blob();
        sent.append("pictures", new File([blob], `picture-${i + 1}.jpg`, { type: blob.type }));
      }
      const result = await postCommentAction(dealSlug, targetId, text, sent);
      if ("error" in result) return setError(result.error);
      setText("");
      setPictures([]);
      setOpened(false);
      box.current?.blur();
      onPosted?.();
      revealComment(result.id);
    });
  }

  async function addPictures(files: File[]) {
    const room = maxPictures - pictures.length;
    const images = files.filter((f) => f.type.startsWith("image/")).slice(0, Math.max(0, room));
    if (!images.length) return;
    setBusy(true);
    setError("");
    try {
      const added: string[] = [];
      for (const file of images) added.push(await shrinkPhoto(file));
      setPictures((now) => [...now, ...added].slice(0, maxPictures));
    } catch (e) {
      setError(e instanceof Error ? e.message : "We couldn't open that picture.");
    } finally {
      setBusy(false);
    }
  }

  function cancel() {
    setText("");
    setPictures([]);
    setOpened(false);
    setError("");
    onCancel?.();
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        post();
      }}
      className="flex flex-col gap-2"
    >
      {isReply && (
        <div className="flex items-center justify-between gap-2 text-xs text-zinc-500">
          <span className="min-w-0 truncate">
            Replying to <span className="font-medium text-zinc-700 dark:text-zinc-300">{replyingTo}</span>
          </span>
          <button type="button" onClick={cancel} aria-label="Cancel reply" className="-m-1 shrink-0 rounded-full p-1 hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-zinc-800 dark:hover:text-zinc-200">
            <Icon name="x" className="size-4" />
          </button>
        </div>
      )}
      <textarea
        ref={box}
        value={text}
        onChange={(e) => setText(e.target.value)}
        onFocus={() => setOpened(true)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) post();
        }}
        onPaste={(e) => {
          const files = Array.from(e.clipboardData.files);
          if (maxPictures > 0 && files.some((f) => f.type.startsWith("image/"))) {
            e.preventDefault();
            void addPictures(files);
          }
        }}
        rows={open ? 3 : 1}
        maxLength={MAX_COMMENT_LENGTH}
        placeholder={isReply ? `Reply to ${replyingTo}…` : "Add a comment…"}
        aria-label={isReply ? `Reply to ${replyingTo}` : "Add a comment"}
        className="w-full resize-none rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950"
      />
      {pictures.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {pictures.map((src, i) => (
            <div key={i} className="relative">
              {/* eslint-disable-next-line @next/next/no-img-element -- a picture still on this device */}
              <img src={src} alt={`Picture ${i + 1}`} className="block h-20 w-auto max-w-40 rounded-lg border border-zinc-200 bg-white object-contain dark:border-zinc-700" />
              <button
                type="button"
                onClick={() => setPictures((now) => now.filter((_, at) => at !== i))}
                aria-label={`Remove picture ${i + 1}`}
                className="absolute right-1 top-1 flex size-6 items-center justify-center rounded-full bg-zinc-900/80 text-white hover:bg-zinc-900"
              >
                <Icon name="x" className="size-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
      {error && (
        <p role="alert" className="text-xs text-amber-700 dark:text-amber-400">
          {error}
        </p>
      )}
      {open && (
        <div className="flex items-center justify-end gap-2">
          {maxPictures > 0 && pictures.length < maxPictures && (
            <label
              title="Add a picture"
              className="mr-auto flex cursor-pointer items-center gap-1.5 rounded-full px-2.5 py-1.5 text-sm font-medium text-zinc-600 hover:bg-zinc-100 has-focus-visible:ring-2 has-focus-visible:ring-orange-500 dark:text-zinc-300 dark:hover:bg-zinc-800"
            >
              <input
                type="file"
                multiple
                accept="image/jpeg,image/png,image/webp,image/gif,image/avif,image/heic"
                className="sr-only"
                onChange={(e) => {
                  void addPictures(Array.from(e.target.files ?? []));
                  e.target.value = "";
                }}
              />
              <Icon name={busy ? "loader" : "image"} className={`size-4 ${busy ? "animate-spin" : ""}`} />
              {busy ? "Adding…" : "Picture"}
            </label>
          )}
          {nearLimit && (
            <span className={`${maxPictures > 0 && pictures.length < maxPictures ? "" : "mr-auto "}text-xs tabular-nums text-zinc-500 dark:text-zinc-400`}>
              {text.length}/{MAX_COMMENT_LENGTH}
            </span>
          )}
          {!isReply && (
            <button
              type="button"
              onClick={cancel}
              className="rounded-full px-3 py-1.5 text-sm font-medium text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
            >
              Cancel
            </button>
          )}
          <button
            type="submit"
            disabled={pending || !text.trim()}
            className="rounded-full bg-orange-500 px-4 py-1.5 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60"
          >
            {pending ? "Posting…" : isReply ? "Reply" : "Post"}
          </button>
        </div>
      )}
    </form>
  );
}
