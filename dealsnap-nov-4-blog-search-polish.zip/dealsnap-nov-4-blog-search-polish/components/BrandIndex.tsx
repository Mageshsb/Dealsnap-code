"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { ClearSearch, searchBox } from "@/components/SearchBox";
import Icon, { type IconName } from "./Icon";
import BrandLogo from "./BrandLogo";
import BrowseCard, { LETTER_HEADING } from "./BrowseCard";
import BottomSheet from "./BottomSheet";
import ScrollUpBand from "./ScrollUpBand";
import { CategoryMenu, CategoryPanel, CLEAR_BUTTON, EmptyToggle, FilterBar, FilterHalf, SortMenu } from "./BrowseFilters";
import { NAME_SEARCH_MAX } from "@/lib/search-limits";
import { LIST_PAGE, visibleCount } from "@/lib/list-paging";
import ShowMoreButton from "./ShowMoreButton";

export type IndexBrand = { name: string; slug: string; logoUrl?: string; count: number; categories: Record<string, number> };
type Category = { slug: string; name: string; icon: IconName };

const SORT_OPTIONS = [
  { value: "popular", label: "Most deals" },
  { value: "az", label: "A–Z" },
];

const squash = (text: string) =>
  text
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");

// The brands list: every brand with its logo and live deals. The same search,
// category filter, sort and hide-empty button as the stores list (without
// perks); the choices live in the address (?q, ?cat, ?sort, ?live) so Back
// keeps them. Busiest first by default; sorted A–Z it has letter headings;
// with a category picked the counts are that category's.
export default function BrandIndex({ brands, categories }: { brands: IndexBrand[]; categories: Category[] }) {
  const params = useSearchParams();
  const [query, setQuery] = useState((params.get("q") ?? "").slice(0, NAME_SEARCH_MAX));
  const cat = categories.some((c) => c.slug === params.get("cat")) ? params.get("cat")! : "";
  const sort = params.get("sort") === "az" ? "az" : "popular";
  const liveOnly = params.get("live") === "1";
  const [catPanel, setCatPanel] = useState(false);
  const controlsRef = useRef<HTMLDivElement>(null);
  const closeCatPanel = useCallback(() => setCatPanel(false), []);

  // Swap the address without a page load (Next keeps useSearchParams in step).
  function setParam(key: string, value: string) {
    const next = new URLSearchParams(window.location.search);
    if (value) next.set(key, value);
    else next.delete(key);
    const qs = next.toString();
    window.history.replaceState(null, "", qs ? `?${qs}` : window.location.pathname);
  }

  // The search box updates the address a moment after typing stops.
  useEffect(() => {
    const t = setTimeout(() => setParam("q", query.trim()), 300);
    return () => clearTimeout(t);
  }, [query]);

  const categoryOptions = [{ value: "", label: "All categories", icon: "grid" as IconName }, ...categories.map((c) => ({ value: c.slug, label: c.name, icon: c.icon }))];
  const q = squash(query);
  // With a category picked, counts are that category's deals.
  const deals = (b: IndexBrand) => (cat ? b.categories[cat] ?? 0 : b.count);
  const shown = useMemo(
    () =>
      brands
        .filter((b) => (!q || squash(b.name).includes(q)) && (!cat || b.categories[cat]) && (!liveOnly || deals(b) > 0))
        .sort((a, b) => {
          // While searching, names that start with what's typed come first.
          if (q) {
            const starts = (x: IndexBrand) => (squash(x.name).startsWith(q) ? 0 : 1);
            if (starts(a) !== starts(b)) return starts(a) - starts(b);
          }
          if (sort === "popular") return deals(b) - deals(a) || a.name.localeCompare(b.name);
          return a.name.localeCompare(b.name);
        }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [brands, q, cat, sort, liveOnly]
  );
  const filtered = !!(q || cat || liveOnly);

  // A first lot of brands, then "Show more"; a new search or filter starts over.
  const [more, setMore] = useState({ key: "", n: LIST_PAGE });
  const listKey = `${q}|${cat}|${sort}|${liveOnly}`;
  const limit = more.key === listKey ? more.n : LIST_PAGE;
  const visible = shown.slice(0, visibleCount(shown.length, limit));

  function clearAll() {
    setQuery("");
    window.history.replaceState(null, "", sort === "popular" ? window.location.pathname : `?sort=${sort}`);
  }

  // A–Z gets letter headings, so a long list is easy to scan down.
  const letter = (name: string) => {
    const c = name.trim()[0]?.toUpperCase() ?? "#";
    return c >= "A" && c <= "Z" ? c : "#";
  };

  // The search row and the filter bar are drawn twice: in the page, and again
  // in the band that slides down when you scroll back up (ScrollUpBand). Both
  // copies share all their state, so they always agree.
  const searchRow = (
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        {/* The search, with the hide-empty button right after it (beside it on phones too). */}
        <div className="flex w-full min-w-0 items-center gap-2 sm:max-w-md sm:flex-1">
        {/* Same box and clear (x) button as the store search. */}
        <div className="relative min-w-0 flex-1">
          <input
            type="search"
            enterKeyHint="search"
            value={query}
            maxLength={NAME_SEARCH_MAX}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()}
            placeholder="Search brands, e.g. Dyson"
            aria-label="Search brands"
            className={searchBox}
          />
          {query && <ClearSearch onClick={() => {
                setQuery("");
                setParam("q", "");
              }} />}
        </div>
        <EmptyToggle on={liveOnly} onToggle={() => setParam("live", liveOnly ? "" : "1")} />
        </div>
        <div className="hidden min-w-0 lg:flex">
          <CategoryMenu value={cat} onChange={(v) => setParam("cat", v)} options={categoryOptions} />
        </div>
      </div>

  );

  // Phones and tablets: the same pill as on Stores, in the same spot (the left
  // half). It opens the categories as a sheet; picking one closes it.
  const filterBar = (
      <FilterBar
        halves={
          <FilterHalf
            icon="grid"
            label={(cat && categoryOptions.find((o) => o.value === cat)?.label) || "Categories"}
            active={!!cat}
            onOpen={() => setCatPanel(true)}
          />
        }
      />
  );

  return (
    <div className="flex flex-col gap-4">
      <div ref={controlsRef} className="flex flex-col gap-4">
        {searchRow}
        {filterBar}
      </div>
      <ScrollUpBand after={controlsRef}>
        <div className="flex flex-col gap-2">
          {searchRow}
          {filterBar}
        </div>
      </ScrollUpBand>
      <BottomSheet open={catPanel} onClose={closeCatPanel} label="Categories" title="Categories">
        <CategoryPanel
          value={cat}
          options={categoryOptions}
          onPick={(v) => {
            setParam("cat", v);
            setCatPanel(false);
          }}
        />
      </BottomSheet>

      <div className="flex items-center justify-between gap-3 text-sm text-zinc-500">
        {/* Only a count of what a search or filter found, not of every brand. */}
        {filtered && (
          <span className="flex min-w-0 items-center gap-2">
            <span className="truncate">
              {shown.length.toLocaleString("en-GB")} {shown.length === 1 ? "brand" : "brands"}
            </span>
            <button type="button" onClick={clearAll} className={CLEAR_BUTTON}>
              <Icon name="x" className="size-3.5" />
              Clear all
            </button>
          </span>
        )}
        <SortMenu value={sort} onChange={(v) => setParam("sort", v === "popular" ? "" : v)} options={SORT_OPTIONS} />
      </div>

      {shown.length === 0 ? (
        <div className="flex flex-col items-center gap-2 py-10 text-center text-zinc-500">
          <p>{q ? <>No brands match &ldquo;{query.trim()}&rdquo;.</> : "No brands match these filters."}</p>
          {q && (
            <Link href={`/?q=${encodeURIComponent(query.trim())}`} className="text-sm font-medium text-orange-700 hover:underline dark:text-orange-400">
              Search all deals for &ldquo;{query.trim()}&rdquo; ›
            </Link>
          )}
        </div>
      ) : (
        // Same grid and letter headings (with their line) as the A–Z stores.
        <div className="grid grid-cols-2 gap-2.5 sm:gap-3 md:grid-cols-3 lg:grid-cols-4">
          {visible.map((b, i) => {
            const n = deals(b);
            const heading = sort === "az" && (i === 0 || letter(visible[i - 1].name) !== letter(b.name));
            return (
              <div key={b.slug} className="contents">
                {heading && <h2 className={`${LETTER_HEADING} ${i ? "mt-2" : ""}`}>{letter(b.name)}</h2>}
                <BrowseCard
                  href={`/brands/${b.slug}`}
                  leading={<BrandLogo name={b.name} logoUrl={b.logoUrl} className="h-10 w-10" />}
                  name={b.name}
                  sub={n ? `${n} live deal${n === 1 ? "" : "s"}` : "None right now"}
                  muted={!n}
                  phoneArrow={false}
                />
              </div>
            );
          })}
        </div>
      )}

      {shown.length > visible.length && (
        <ShowMoreButton noun="brands" left={shown.length - visible.length} onClick={() => setMore({ key: listKey, n: limit + LIST_PAGE })} />
      )}
    </div>
  );
}
