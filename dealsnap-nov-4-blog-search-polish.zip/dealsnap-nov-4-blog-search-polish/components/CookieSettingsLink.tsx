"use client";

import { openCookieSettings } from "./cookie-consent";

// Lets a visitor change their mind: reopens the cookie banner on the choices
// they made before. In the footer, the About page and the privacy policy.
export default function CookieSettingsLink({ className, children = "Cookies" }: { className?: string; children?: React.ReactNode }) {
  return (
    <button type="button" onClick={openCookieSettings} className={className}>
      {children}
    </button>
  );
}
