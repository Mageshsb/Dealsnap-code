import Link from "next/link";
import { DEAL_VIEWS, DEFAULT_LOVED_WINDOW, DEFAULT_VIEW, LOVED_WINDOWS, type LovedWindow, type SearchSort } from "@/lib/deal-views";
import MostLovedTab from "./MostLovedTab";
import Icon, { HeartIcon, type IconName } from "./Icon";

// Sort chips for a deal list: "Most loved | 7 days ⌄" (with a heart) (its time window
// lives on its own chip, since it only applies there; see MostLovedTab) and "New". Plain links
// (?view=..., ?when=...), so the choice is shareable. `basePath` is the page the
// chips belong to (home, a category, a tag, a store). `fitShort` steps the chips
// down a size on short screens (Scroll view); both it and `fitNarrow` (the List
// view's row) trim their padding below 400px, to leave room for the Filters
// pill on a 360px phone. On search results
// (`searchQuery`) the chips are Best match | Most loved | New instead, all plain
// (no time window), linking to /?q=...&view=...
export default function DealViewTabs({
  active,
  when = DEFAULT_LOVED_WINDOW,
  basePath = "/",
  fitShort,
  fitNarrow,
  minHearts = 0,
  filterQuery,
  searchQuery,
}: {
  active: SearchSort; // "best" only on search results
  when?: LovedWindow;
  basePath?: string;
  fitShort?: boolean;
  fitNarrow?: boolean;
  minHearts?: number; // keep the hearts filter when switching view
  filterQuery?: string; // ...and the ticked stores/categories ("stores=currys")
  searchQuery?: string;
}) {
  const extra = [minHearts > 0 ? `hearts=${minHearts}` : "", filterQuery ?? ""].filter(Boolean).join("&");
  const keep = (href: string) => (extra ? `${href}${href.includes("?") ? "&" : "?"}${extra}` : href);
  // The chosen period rides along on New too (it ignores it), so coming back to
  // Most loved keeps it rather than resetting to the last 7 days.
  const whenParam = when === DEFAULT_LOVED_WINDOW ? "" : `when=${when}`;
  const viewHref = (v: SearchSort) => {
    if (searchQuery !== undefined) {
      return keep(`/?q=${encodeURIComponent(searchQuery)}${v === "best" ? "" : `&view=${v}`}`);
    }
    const q = [v === DEFAULT_VIEW ? "" : `view=${v}`, whenParam].filter(Boolean).join("&");
    return keep(q ? `${basePath}?${q}` : basePath);
  };
  // Written out in full so Tailwind can see each class.
  const sizeClass = fitShort
    ? "py-1.5 text-sm [@media(max-height:640px)]:py-1 [@media(max-height:640px)]:text-xs"
    : "py-1.5 text-sm";
  const pad = fitShort ? "px-2 min-[400px]:px-3 [@media(max-height:640px)]:px-2.5" : fitNarrow ? "px-2 min-[400px]:px-3" : "px-3";
  const padStart = fitShort ? "ps-2 min-[400px]:ps-3 [@media(max-height:640px)]:ps-2.5" : fitNarrow ? "ps-2 min-[400px]:ps-3" : "ps-3";
  const padEnd = fitShort ? "pe-2 min-[400px]:pe-3 [@media(max-height:640px)]:pe-2.5" : fitNarrow ? "pe-2 min-[400px]:pe-3" : "pe-3";
  const windowHrefs = Object.fromEntries(
    LOVED_WINDOWS.map((w) => [w.value, keep(w.value === DEFAULT_LOVED_WINDOW ? basePath : `${basePath}?when=${w.value}`)])
  ) as Record<LovedWindow, string>;

  // Search's three chips plus the Filters pill fill a 360px phone exactly in
  // Scroll view (and the List view's row), so there they drop their icons below
  // 400px to leave some slack.
  const iconClass = searchQuery !== undefined && (fitShort || fitNarrow) ? "size-[1em] max-[399px]:hidden" : "size-[1em]";
  const chip = (v: { value: SearchSort; label: string; icon: IconName }) => (
    <Link
      key={v.value}
      href={viewHref(v.value)}
      scroll={false}
      aria-current={active === v.value ? "true" : undefined}
      className={`flex shrink-0 items-center gap-1 whitespace-nowrap rounded-full font-medium transition-colors ${sizeClass} ${pad} ${
        active === v.value
          ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900"
          : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
      }`}
    >
      {/* The same red heart as the Most loved chip on other pages. */}
      {v.value === "hottest" ? <HeartIcon className={iconClass} /> : <Icon name={v.icon} className={iconClass} />}
      {v.label}
    </Link>
  );

  if (searchQuery !== undefined) {
    return (
      <div className="flex items-center gap-1.5">
        {[{ value: "best" as const, label: "Best match", icon: "search" as const }, ...DEAL_VIEWS].map(chip)}
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1.5">
      {DEAL_VIEWS.map((v) =>
        v.value === "hottest" ? (
          <MostLovedTab
            key={v.value}
            href={viewHref(v.value)}
            active={active === "hottest"}
            current={when}
            hrefs={windowHrefs}
            sizeClass={sizeClass}
            pad={pad}
            padStart={padStart}
            padEnd={padEnd}
          />
        ) : (
          chip(v)
        )
      )}
    </div>
  );
}
