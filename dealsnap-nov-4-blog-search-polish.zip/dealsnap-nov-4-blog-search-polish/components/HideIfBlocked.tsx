"use client";

import { useUserVotes } from "./UserVotesProvider";

// Drops a deal from any list when the viewer has blocked whoever posted it.
export default function HideIfBlocked({ userId, children }: { userId?: string; children: React.ReactNode }) {
  const { blockedUserIds } = useUserVotes();
  if (userId && blockedUserIds.includes(userId)) return null;
  return <>{children}</>;
}
