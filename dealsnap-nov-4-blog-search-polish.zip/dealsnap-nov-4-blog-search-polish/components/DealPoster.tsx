import Link from "next/link";
import { countOf } from "@/lib/badges";
import UserAvatar from "./UserAvatar";
import RoleBadge, { type Tier } from "./RoleBadge";

export type PosterInfo = {
  username: string;
  avatarUrl: string | null;
  joinedAt: string;
  dealCount: number;
  heartsReceived: number;
};

// "Posted by" at the top of the About panel: who shared the deal and how much
// they have done here, so people can judge it at a glance: their team rank (if
// any), when they joined, deals and hearts. Two short lines, and the whole
// thing opens their profile, the only thing to tap.
export default function DealPoster({ info, tier }: { info: PosterInfo; tier?: Tier }) {
  const joined = new Date(info.joinedAt).toLocaleDateString("en-GB", { month: "short", year: "numeric" });

  return (
    <Link
      href={`/u/${info.username}`}
      className="group flex min-w-0 items-center gap-2.5"
    >
      <UserAvatar username={info.username} avatarUrl={info.avatarUrl} size="size-9" textSize="text-sm" />
      <span className="flex min-w-0 flex-col">
        <span className="flex min-w-0 items-center gap-1.5 text-sm">
          <span className="shrink-0 text-zinc-500 dark:text-zinc-400">Posted by</span>
          <span className="truncate font-semibold group-hover:underline">{info.username}</span>
          {tier && <RoleBadge tier={tier} variant="label" />}
        </span>
        <span className="truncate text-xs text-zinc-500 dark:text-zinc-400">
          Joined {joined} · {countOf(info.dealCount, "deals")} · {countOf(info.heartsReceived, "hearts")}
        </span>
      </span>
    </Link>
  );
}
