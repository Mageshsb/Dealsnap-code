import Link from "next/link";
import GetDealButton from "./GetDealButton";
import { Deal } from "@/lib/types";
import { formatShortDate, isEndingSoon, isExpired, timeAgo, timeAgoShort, timeAgoTiny, timeRemaining } from "@/lib/format";
import { dealPriceTag } from "@/lib/deal-kinds";
import VoteButton from "./VoteButton";
import AgeLabel from "./AgeLabel";
import DealThumbnail from "./DealThumbnail";
import ShareButton from "./ShareButton";
import SaveDealButton from "./SaveDealButton";
import HideIfBlocked from "./HideIfBlocked";
import UsernameLink from "./UsernameLink";
import { CommentIcon } from "./icons";
import FeaturedBadge from "./FeaturedBadge";
import HeroRibbon from "./HeroRibbon";
import { slugify } from "@/lib/slug";
import WhereBadge from "./WhereBadge";
import VoucherCode from "./VoucherCode";
import { deliveryLabel } from "@/lib/deal-extras";
import Icon from "@/components/Icon";
import { PriceMain, SmallPrint, WasPrice } from "./DealPrice";
import { STARTS_PILL, StartsText } from "./UpcomingBits";
import { isUpcoming } from "@/lib/upcoming";
import { AdTag } from "./AdTag";

// `eager`: one of the first cards on the page, whose photo loads straight away.
// `sponsoredBy`: an advertiser's deal (Admin → Ads). "Ad · Sponsored by …" sits
// in a slim strip along the top, inside the card's own border, so it reads as
// part of the deal; the tile underneath is the same size as any other.
export default function DealCard({ deal, eager = false, sponsoredBy }: { deal: Deal; eager?: boolean; sponsoredBy?: string }) {
  const tag = dealPriceTag(deal);
  const endingSoon = isEndingSoon(deal.expiresAt);
  const expired = isExpired(deal.expiresAt);
  const upcoming = !expired && isUpcoming(deal);
  const hero = !!deal.hero && !expired;
  // Hero outranks featured: a Hero deal never wears both looks.
  const featured = !!deal.featured && !expired && !hero;
  const delivery = deliveryLabel(deal.delivery);
  // A voucher (the code is the deal) has a dashed violet edge, like a cut-out
  // coupon, in the same footprint as any card. A Featured or Deal of the Day
  // voucher keeps that look's colours, dashed the same way.
  const voucher = deal.kind === "voucher";

  return (
    <HideIfBlocked userId={deal.postedByUserId}>
    <div
      className={`relative flex flex-col overflow-hidden rounded-xl bg-white shadow-sm transition-shadow hover:shadow-md dark:bg-zinc-900 ${
        hero
          ? `hero-card -my-0.5 ${voucher ? "hero-dashed" : ""}` // thicker border, same footprint as a plain tile
          : featured
            ? `featured-glow -my-px border-2 border-orange-500 ${voucher ? "border-dashed" : ""} bg-gradient-to-br from-orange-50 to-white dark:from-orange-950/30 dark:to-zinc-900`
            : voucher
              ? "-my-px border-2 border-dashed border-violet-400 dark:border-violet-700"
              : "border border-zinc-200 dark:border-zinc-800"
      } ${expired ? "opacity-60 grayscale" : ""}`}
    >
      {/* Stretched link: makes the whole tile open the deal page. Buttons and
          links that do their own thing sit above it with relative z-10. */}
      <Link
        href={`/deals/${deal.slug}`}
        aria-hidden
        tabIndex={-1}
        className="absolute inset-0"
      />
      {sponsoredBy && (
        <div className="border-b border-zinc-200 bg-zinc-50 px-3 py-[3px] dark:border-zinc-800 dark:bg-zinc-800/50">
          <AdTag advertiser={`Sponsored by ${sponsoredBy}`} />
        </div>
      )}
      <div className="flex min-w-0 flex-1">
        {/* The photo is a second way in for a tap; screen readers and the
            keyboard use the title link, so it isn't read out twice. */}
        <Link
          href={`/deals/${deal.slug}`}
          aria-hidden
          tabIndex={-1}
          className="relative w-28 shrink-0 self-stretch sm:w-32 md:w-40"
        >
          <DealThumbnail deal={deal} iconSize="size-9 sm:size-11" backdrop="compact" eager={eager} />
          {featured && <FeaturedBadge className="left-1.5 top-1.5" />}
          {hero && <HeroRibbon />}
          {endingSoon && (
            <div className="absolute right-0 top-0 flex items-center gap-1 rounded-bl-lg bg-red-500 px-2 py-1 text-[11px] font-semibold text-white">
              <Icon name="hourglass" className="size-3" />
              {timeRemaining(deal.expiresAt!)}
            </div>
          )}
        </Link>

        <div className="flex min-w-0 flex-1 flex-col gap-1.5 px-1.5 py-3 sm:p-4">
          {/* One line always: the hearts, save and the age pill never wrap onto
              each other. The pill is "Posted 27 days ago" from 640px and
              "27d ago" on phones, shortened to "27d" on a card where that
              doesn't fit (see AgeLabel); under 340px it's dropped. */}
          <div className="flex flex-nowrap items-center justify-between gap-1 sm:gap-2">
            <div className="relative z-10 flex shrink-0 items-center gap-1.5 sm:gap-2">
              <VoteButton initialHearts={deal.hearts} dealSlug={deal.slug} />
              <SaveDealButton dealSlug={deal.slug} />
            </div>
            {expired ? (
              <span className="min-w-0 truncate whitespace-nowrap rounded-full bg-zinc-200 px-1.5 py-1 text-[11px] font-medium text-zinc-600 dark:bg-zinc-700 dark:text-zinc-300 sm:px-2.5">
                Expired
              </span>
            ) : upcoming && deal.startsAt ? (
              <span
                data-age-pill
                className={`relative min-w-0 truncate whitespace-nowrap rounded-full px-1.5 py-1 text-[11px] font-medium max-[339px]:hidden sm:px-2.5 ${STARTS_PILL}`}
              >
                <span className="sm:hidden">
                  <StartsText startsAt={deal.startsAt} short />
                </span>
                <span className="hidden sm:inline">
                  <StartsText startsAt={deal.startsAt} />
                </span>
              </span>
            ) : (
              <span
                data-age-pill
                className="relative min-w-0 truncate whitespace-nowrap rounded-full bg-zinc-100 px-1.5 py-1 text-[11px] font-medium text-zinc-600 max-[339px]:hidden dark:bg-zinc-800 dark:text-zinc-400 sm:px-2.5"
              >
                <span className="sm:hidden">
                  <AgeLabel full={timeAgoShort(deal.postedAt)} tiny={timeAgoTiny(deal.postedAt)} />
                </span>
                <span className="hidden sm:inline">Posted {timeAgo(deal.postedAt)}</span>
              </span>
            )}
          </div>

          {/* A div, not a link: the store name inside is its own link, and
              anchors can't nest. The title link and the tile's stretched link
              still open the deal. The title takes one to three lines on phones, one or two from 640px (cut short
              with …), then on phones one line for the price or
              offer and one for where to get it, cut short rather than
              wrapping; from 640px those two share one line. A deal with
              cashback or catches (new customers, app only…) adds one line of
              small print.
              Nothing keeps blank lines: a short title doesn't leave a gap. */}
          <div className="flex min-w-0 flex-1 flex-col gap-1.5">
            <h2 className="line-clamp-3 font-bold leading-snug sm:line-clamp-2 text-zinc-900 dark:text-zinc-50">
              <Link href={`/deals/${deal.slug}`}>{deal.title}</Link>
            </h2>

            <div className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:gap-2">
              <div className="flex h-7 min-w-0 items-baseline gap-2 overflow-hidden whitespace-nowrap sm:contents">
                {/* The price, or the offer ("Up to 70% off") on a sale, multi-buy
                    or voucher, a size down on phones (two for a long one, like
                    "25% off when you buy 6") so it fits one line at 360px. */}
                <span
                  className={`font-bold text-orange-700 dark:text-orange-400 ${
                    tag.isOffer && tag.main.length > 18 ? "text-base sm:text-xl" : "text-lg sm:text-xl"
                  }`}
                >
                  <PriceMain tag={tag} />
                </span>
                <WasPrice tag={tag} className="min-w-0 truncate text-xs text-zinc-500 sm:text-sm dark:text-zinc-400" />
                {tag.off && (
                  <span className="shrink-0 text-sm font-bold text-green-700 sm:text-base dark:text-green-400">
                    {tag.off}% off
                  </span>
                )}
              </div>
              <div className="flex h-5 min-w-0 items-center gap-1.5 whitespace-nowrap text-sm text-zinc-500 sm:contents dark:text-zinc-400">
                <span className="min-w-0 truncate">
                  at{" "}
                  <Link
                    href={`/stores/${slugify(deal.store)}`}
                    className="relative z-10 font-semibold text-zinc-700 hover:text-orange-500 hover:underline dark:text-zinc-200"
                  >
                    {deal.store}
                  </Link>
                  {delivery && <> · {delivery}</>}
                  {deal.expiresAt && !expired && !endingSoon && <> · Ends {formatShortDate(deal.expiresAt)}</>}
                </span>
                <WhereBadge where={deal.whereToBuy} note={deal.whereNote} />
                {deal.voucherCode && <VoucherCode code={deal.voucherCode} variant="badge" doubtful={deal.codeMayNotWork} />}
              </div>
            </div>
            <SmallPrint conditions={deal.conditions} cashback={deal.cashback} className="h-4 text-xs" />
          </div>

          {/* On phones the poster is just their name (no picture), shrinking
              with … if long, so it fits beside comments, share and "Get deal"
              (~76px for the name at 360px wide, ~56px at 340px). */}
          <div className="mt-auto flex items-center justify-between gap-1.5 pt-1 sm:gap-2">
            <div className="flex min-w-0 flex-1 items-center gap-1 min-[380px]:gap-2 sm:gap-3">
              {deal.postedByUsername && (
                <div className="relative z-10 flex min-w-0 shrink">
                  <UsernameLink
                    username={deal.postedByUsername}
                    userId={deal.postedByUserId}
                    avatarUrl={deal.postedByAvatarUrl}
                    role={deal.postedByRole}
                    badge="colour"
                    size="h-6 w-6 max-sm:hidden"
                    className="flex min-w-0 shrink items-center gap-1 text-xs text-zinc-500 dark:text-zinc-400 sm:text-sm"
                  />
                </div>
              )}
              <Link
                href={`/deals/${deal.slug}`}
                aria-label={`${deal.commentCount} comment${deal.commentCount === 1 ? "" : "s"}`}
                className="flex shrink-0 items-center gap-0.5 text-xs text-zinc-500 dark:text-zinc-400"
              >
                <CommentIcon className="h-4 w-4 sm:h-[18px] sm:w-[18px]" />
                {deal.commentCount}
              </Link>
              <div className="relative z-10 flex shrink-0">
                <ShareButton url={`/deals/${deal.slug}`} title={deal.title} />
              </div>
            </div>
            <GetDealButton
              slug={deal.slug}
              store={deal.store}
              code={deal.voucherCode}
              voucher={voucher}
              upcoming={upcoming}
              className="relative z-10 shrink-0 rounded-full px-2.5 py-2 text-sm font-semibold min-[380px]:px-4 sm:px-5"
            />
          </div>
        </div>
      </div>
    </div>
    </HideIfBlocked>
  );
}
