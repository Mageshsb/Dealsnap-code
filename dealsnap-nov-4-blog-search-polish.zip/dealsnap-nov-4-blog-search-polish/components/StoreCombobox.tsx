"use client";

import { useEffect, useId, useMemo, useRef, useState } from "react";
import { storeKey } from "@/lib/stores";
import { STORE_NAME_MAX } from "@/lib/deal-text";

type Suggestion = { name: string; kind: "same" | "similar" };

// Suggests existing stores as someone types, including variants of what they
// typed: "amazon uk", "Amazon.co.uk" and "amazon" all point at Amazon, so a
// store can't end up listed twice under different spellings.
export default function StoreCombobox({
  id,
  name,
  value,
  onChange,
  options,
  variants = {},
}: {
  id?: string;
  name: string;
  value: string;
  onChange: (value: string) => void;
  options: string[];
  // Other spellings an admin has merged into a store: storeKey → store name.
  variants?: Record<string, string>;
}) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const listboxId = useId();

  const needleKey = storeKey(value);

  const suggestions = useMemo<Suggestion[]>(() => {
    if (!needleKey) return options.slice(0, 8).map((name) => ({ name, kind: "similar" }));
    const rank = (key: string) => {
      if (key === needleKey) return 0; // same store, different spelling
      if (key.startsWith(needleKey)) return 1;
      if (key.includes(needleKey)) return 2;
      // They typed more than the store's name ("amazon prime video").
      if (key.length >= 3 && needleKey.includes(key)) return 3;
      return -1;
    };
    const merged = variants[needleKey]; // typed an old/merged name of an existing store
    return options
      .map((name) => ({ name, r: name === merged ? 0 : rank(storeKey(name)) }))
      .filter((o) => o.r >= 0)
      .sort((a, b) => a.r - b.r || a.name.localeCompare(b.name))
      .slice(0, 8)
      .map((o): Suggestion => ({ name: o.name, kind: o.r === 0 ? "same" : "similar" }));
  }, [options, needleKey, variants]);

  // The existing store the typed text is a variant of, if any.
  const same = suggestions.find((s) => s.kind === "same");
  const isNewStore = value.trim().length > 0 && !same;

  // Leaving the field with a variant typed ("Amazon UK") snaps it to the
  // store's real name. The server does the same on submit as a backstop.
  function settle() {
    setOpen(false);
    if (same && same.name !== value) onChange(same.name);
  }

  useEffect(() => {
    if (!open) return;
    function onPointerDown(e: MouseEvent) {
      if (!containerRef.current?.contains(e.target as Node)) settle();
    }
    document.addEventListener("mousedown", onPointerDown);
    return () => document.removeEventListener("mousedown", onPointerDown);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, same?.name, value]);

  return (
    <div
      ref={containerRef}
      className="relative"
      onBlur={(e) => {
        // Focus left the field and its suggestion list entirely.
        if (!e.currentTarget.contains(e.relatedTarget as Node | null)) settle();
      }}
    >
      <input
        id={id}
        name={name}
        required
        maxLength={STORE_NAME_MAX}
        role="combobox"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-autocomplete="list"
        autoComplete="off"
        value={value}
        onChange={(e) => {
          onChange(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onKeyDown={(e) => {
          if (e.key === "Escape") setOpen(false);
        }}
        placeholder="e.g. Amazon"
        className="h-11 w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base sm:h-10 outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950"
      />

      {open && (suggestions.length > 0 || isNewStore) && (
        // mousedown is cancelled so picking a suggestion doesn't blur the input first.
        <div
          onMouseDown={(e) => e.preventDefault()}
          className="absolute z-20 mt-1 w-full overflow-hidden rounded-lg border border-zinc-200 bg-white shadow-lg dark:border-zinc-800 dark:bg-zinc-900"
        >
          {same && same.name !== value.trim() && (
            <div className="border-b border-zinc-100 bg-green-50 px-3 py-1.5 text-xs text-green-800 dark:border-zinc-800 dark:bg-green-950/30 dark:text-green-300">
              Same store as <span className="font-semibold">{same.name}</span>. It will be listed under that name.
            </div>
          )}
          <ul id={listboxId} role="listbox" className="max-h-48 overflow-y-auto py-1">
            {suggestions.map((s) => (
              <li key={s.name}>
                <button
                  type="button"
                  onClick={() => {
                    onChange(s.name);
                    setOpen(false);
                  }}
                  className="flex w-full items-center justify-between gap-2 px-3 py-1.5 text-left text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800"
                >
                  {s.name}
                  {s.kind === "same" && (
                    <span className="shrink-0 rounded-full bg-green-100 px-2 py-0.5 text-[10px] font-semibold text-green-700 dark:bg-green-950/40 dark:text-green-400">
                      existing store
                    </span>
                  )}
                </button>
              </li>
            ))}
          </ul>
          {isNewStore && (
            <div className="border-t border-zinc-100 px-3 py-1.5 text-xs text-zinc-500 dark:border-zinc-800">
              {suggestions.length > 0 ? "None of these? " : ""}+ Add{" "}
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">&quot;{value.trim()}&quot;</span> as a
              new store
            </div>
          )}
        </div>
      )}
    </div>
  );
}
