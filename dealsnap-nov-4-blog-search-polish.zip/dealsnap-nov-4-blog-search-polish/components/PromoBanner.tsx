"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import Icon from "./Icon";
import { PROMO_CLOSED_COOKIE, bannerShowsOn, type PromoBannerData } from "@/lib/promos";

type Look = Pick<PromoBannerData, "kicker" | "headline" | "body" | "ctaLabel" | "linkUrl" | "logoUrl" | "showTag" | "bg" | "fg">;

// The promo banner under the header (Admin → Promos): a full-width band in
// the colours staff choose, with a button in the same two colours swapped so
// it always stands out. It scrolls away with the page, and the header stays.
// It is the same height whatever it holds (56px on phones, 64px from 640px up):
// the headline is cut off at one line under a small line, or two without one,
// so every page below it sits at the same place and Back isn't thrown off.
// `preview` is the admin's look at it, with nothing to click.
export function PromoBannerView({ promo, onClose, preview = false }: { promo: Look; onClose?: () => void; preview?: boolean }) {
  const { kicker, headline, body, ctaLabel, linkUrl, logoUrl, showTag, bg, fg } = promo;
  const top = !!(kicker || showTag);
  const button = "shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold hover:opacity-90 sm:text-sm";
  const buttonStyle = { backgroundColor: fg, color: bg };
  return (
    <div role="region" aria-label="Promotion" style={{ backgroundColor: bg, color: fg }}>
      <div className="mx-auto flex h-14 max-w-5xl items-center gap-3 px-4 sm:h-16">
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="" width={36} height={36} decoding="async" className="size-9 shrink-0 rounded-lg object-contain" />
        )}
        <div className="flex min-w-0 flex-1 flex-col justify-center gap-0.5">
          {top && (
            <div className="flex items-center gap-2 text-xs font-semibold">
              {kicker && <span className="truncate">{kicker}</span>}
              {showTag && (
                <span className="flex shrink-0 items-center gap-1 rounded-full border border-current px-1.5 py-px text-[11px] font-medium">
                  <Icon name="megaphone" className="size-3" />
                  Promoted
                </span>
              )}
            </div>
          )}
          <p className={`${top ? "line-clamp-1" : "line-clamp-2"} text-sm font-semibold leading-snug sm:text-base`}>
            {headline}
            {body && <span className="hidden font-normal sm:inline"> · {body}</span>}
          </p>
        </div>
        {preview ? (
          <span className={button} style={buttonStyle}>
            {ctaLabel}
          </span>
        ) : linkUrl.startsWith("/") ? (
          <Link href={linkUrl} className={button} style={buttonStyle}>
            {ctaLabel}
          </Link>
        ) : (
          <a href={linkUrl} target="_blank" rel="sponsored noopener nofollow" className={button} style={buttonStyle}>
            {ctaLabel}
          </a>
        )}
        {onClose && (
          <button
            type="button"
            aria-label="Close promotion"
            onClick={onClose}
            className="-mr-2 flex size-9 shrink-0 items-center justify-center rounded-full hover:opacity-70"
          >
            <Icon name="x" className="size-4" />
          </button>
        )}
      </div>
    </div>
  );
}

// The banner as the site shows it: only on the pages it's meant for, and
// closable for the rest of the day (the cookie is read by the layout, so a
// closed banner is never drawn on the next page or the next visit that day).
export default function PromoBanner(props: PromoBannerData) {
  const pathname = usePathname();
  const [closed, setClosed] = useState(false);
  if (closed || !bannerShowsOn(props.scope, pathname)) return null;
  const close = () => {
    document.cookie = `${PROMO_CLOSED_COOKIE}=${encodeURIComponent(props.stamp)}; path=/; max-age=86400; samesite=lax${
      location.protocol === "https:" ? "; secure" : ""
    }`;
    setClosed(true);
  };
  return <PromoBannerView promo={props} onClose={props.closable ? close : undefined} />;
}
