"use client";

import { useEffect, useState } from "react";
import Icon from "./Icon";

// The "In this post" / "On this page" list on long pages: blog posts, Terms,
// Privacy, Guidelines and the team's own pages. One look everywhere:
// - laptops (ContentsSide): on the right of the text, staying in view as you
//   read (the page's column is sticky), a thin grey line with an orange mark
//   on the section being read;
// - phones and tablets (ContentsFolded): one folded line above the text
//   ("In this post · 6 sections"), so the first words come first; picking a
//   section folds it again.

export type ContentsItem = { id: string; text: string };

// The section being read: the last whose heading has passed a line a quarter
// of the way down the screen, or the last one once the page is at its end.
function useActiveSection(items: ContentsItem[]) {
  const [active, setActive] = useState(items[0]?.id);

  useEffect(() => {
    const sections = items.map((i) => document.getElementById(i.id)).filter((el): el is HTMLElement => !!el);
    if (!sections.length) return;
    let frame = 0;
    const update = () => {
      frame = 0;
      const line = window.innerHeight * 0.25;
      let current = sections[0].id;
      for (const s of sections) if (s.getBoundingClientRect().top <= line) current = s.id;
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4) current = sections[sections.length - 1].id;
      setActive(current);
    };
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };
    frame = requestAnimationFrame(update);
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(frame);
    };
  }, [items]);

  return active;
}

export function ContentsSide({ title, items, numbered = false }: { title: string; items: ContentsItem[]; numbered?: boolean }) {
  const active = useActiveSection(items);
  return (
    <nav aria-label={title} className="hidden lg:block print:hidden">
      <h2 className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">{title}</h2>
      {/* A long list scrolls on its own rather than running off the screen. */}
      <div className="max-h-[calc(100vh-10rem)] overflow-y-auto pl-px">
        <ol className="flex flex-col border-l border-zinc-200 text-sm dark:border-zinc-800">
          {items.map((h, i) => (
            <li key={h.id}>
              <a
                href={`#${h.id}`}
                aria-current={active === h.id ? "location" : undefined}
                className={`-ml-px flex gap-2 border-l-2 py-1.5 pl-3 leading-snug transition-colors ${
                  active === h.id
                    ? "border-orange-500 font-semibold text-zinc-900 dark:text-zinc-100"
                    : "border-transparent text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-100"
                }`}
              >
                {numbered && <span className="w-5 shrink-0 tabular-nums text-zinc-500 dark:text-zinc-400">{i + 1}.</span>}
                <span className="min-w-0">{h.text}</span>
              </a>
            </li>
          ))}
        </ol>
      </div>
    </nav>
  );
}

export function ContentsFolded({ title, items }: { title: string; items: ContentsItem[] }) {
  return (
    <details className="group rounded-xl border border-zinc-200 lg:hidden print:hidden dark:border-zinc-800">
      <summary className="flex min-h-11 cursor-pointer list-none items-center justify-between gap-2 px-4 text-sm font-semibold [&::-webkit-details-marker]:hidden">
        <span>
          {title} · {items.length} sections
        </span>
        <Icon name="chevron-down" className="size-4 shrink-0 text-zinc-500 dark:text-zinc-400 transition-transform group-open:rotate-180" />
      </summary>
      <ol className="flex flex-col gap-2 border-t border-zinc-100 px-4 py-3 text-sm dark:border-zinc-800">
        {items.map((h, i) => (
          <li key={h.id} className="flex gap-2">
            <span className="w-5 shrink-0 tabular-nums text-zinc-500 dark:text-zinc-400">{i + 1}.</span>
            <a
              href={`#${h.id}`}
              onClick={(e) => e.currentTarget.closest("details")?.removeAttribute("open")}
              className="font-medium hover:text-orange-600 hover:underline dark:hover:text-orange-400"
            >
              {h.text}
            </a>
          </li>
        ))}
      </ol>
    </details>
  );
}
