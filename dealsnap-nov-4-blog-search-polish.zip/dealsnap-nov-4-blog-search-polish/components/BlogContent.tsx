import Image from "next/image";
import Link from "next/link";
import { Fragment } from "react";
import { parseInline, type BlogBlock } from "@/lib/blog";
import type { Deal } from "@/lib/types";
import AdUnit from "./AdUnit";
import DealEmbed from "./blog/DealEmbed";
import Icon from "./Icon";

// A post's text: paragraphs, headings (with an id for the contents box),
// bullet lists, notes, tables, pictures, deal cards, bold and links. Links to
// other sites open in a new tab.
// `adsAfter`: the blocks an ad follows (Admin → Ads, lib/ad-positions.ts).
// `deals`: the deals a post's cards show, by address. The editor's preview
// passes none, and a card then says what it will show.
export default function BlogContent({ blocks, adsAfter = [], deals, preview = false }: { blocks: BlogBlock[]; adsAfter?: number[]; deals?: Map<string, Deal>; preview?: boolean }) {
  return (
    <div className="flex flex-col gap-4 text-[17px] leading-[1.7] text-zinc-700 dark:text-zinc-300">
      {blocks.map((b, i) => (
        <Fragment key={i}>
          <Block b={b} deals={deals} preview={preview} first={i === 0} />
          {adsAfter.includes(i) && <AdUnit slot="blog" n={adsAfter.indexOf(i)} className="my-2 text-base" />}
        </Fragment>
      ))}
    </div>
  );
}

function Block({ b, deals, preview, first }: { b: BlogBlock; deals?: Map<string, Deal>; preview: boolean; first: boolean }) {
  if (b.type === "heading") {
    return (
      <h2 id={b.id} className={`${first ? "" : "mt-6"} scroll-mt-24 text-balance text-xl font-bold leading-snug text-zinc-900 sm:text-2xl dark:text-zinc-50`}>
        {b.text}
      </h2>
    );
  }
  if (b.type === "subheading") {
    return <h3 className="mt-3 text-balance text-lg font-semibold leading-snug text-zinc-900 dark:text-zinc-50">{b.text}</h3>;
  }
  if (b.type === "list") {
    return (
      <ul className="flex list-disc flex-col gap-2 pl-5 marker:text-orange-500">
        {b.items.map((item, j) => (
          <li key={j}>
            <Inline text={item} />
          </li>
        ))}
      </ul>
    );
  }
  if (b.type === "quote") {
    return (
      <aside className="flex gap-3 rounded-xl border border-orange-200 bg-orange-50 p-4 text-[16px] leading-relaxed text-zinc-800 dark:border-orange-900/60 dark:bg-orange-950/30 dark:text-zinc-200">
        <Icon name="lightbulb" className="mt-[0.2em] size-5 shrink-0 text-orange-700 dark:text-orange-400" />
        <p className="min-w-0">
          <Inline text={b.text} />
        </p>
      </aside>
    );
  }
  if (b.type === "table") {
    return (
      <div className="overflow-x-auto rounded-xl border border-zinc-200 dark:border-zinc-800">
        <table className="w-full border-collapse text-left text-[15px] leading-snug">
          <thead className="bg-zinc-50 text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100">
            <tr>
              {b.head.map((h, j) => (
                <th key={j} scope="col" className="px-3 py-2.5 align-bottom font-semibold [overflow-wrap:anywhere]">
                  <Inline text={h} />
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {b.rows.map((row, r) => (
              <tr key={r} className="border-t border-zinc-200 dark:border-zinc-800">
                {row.map((cell, j) => (
                  <td key={j} className="px-3 py-2.5 align-top [overflow-wrap:anywhere]">
                    <Inline text={cell} />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
  if (b.type === "image") {
    // The shape is in the address, so the space is held before the picture loads.
    return (
      <figure className="flex flex-col gap-2">
        <Image src={b.src} alt={b.alt} width={b.w} height={b.h} unoptimized sizes="(min-width: 768px) 704px, 100vw" className="h-auto w-full rounded-xl" />
        {b.alt && <figcaption className="text-center text-sm text-zinc-500">{b.alt}</figcaption>}
      </figure>
    );
  }
  if (b.type === "deal") {
    const deal = deals?.get(b.slug);
    if (preview && !deal) {
      return (
        <p className="rounded-xl border border-dashed border-zinc-300 px-4 py-3 text-sm text-zinc-500 dark:border-zinc-700">
          <Icon name="shopping-bag" className="mr-1.5" />
          A live card for the deal <code className="rounded bg-zinc-100 px-1 dark:bg-zinc-800">{b.slug}</code> shows here once the post is live.
        </p>
      );
    }
    return <DealEmbed deal={deal} slug={b.slug} />;
  }
  return (
    <p>
      <Inline text={b.text} />
    </p>
  );
}

function Inline({ text }: { text: string }) {
  return (
    <>
      {parseInline(text).map((part, i) => {
        if (part.bold) {
          return (
            <strong key={i} className="font-semibold text-zinc-900 dark:text-zinc-50">
              {part.text}
            </strong>
          );
        }
        if (part.href) {
          const external = !part.href.startsWith("/");
          const className = "font-medium text-orange-700 underline decoration-orange-300 underline-offset-2 hover:decoration-orange-600 dark:text-orange-400";
          return external ? (
            <a key={i} href={part.href} target="_blank" rel="nofollow noopener noreferrer" className={className}>
              {part.text}
            </a>
          ) : (
            <Link key={i} href={part.href} className={className}>
              {part.text}
            </Link>
          );
        }
        return <span key={i}>{part.text}</span>;
      })}
    </>
  );
}
