"use client";

import { useState } from "react";
import Icon from "./Icon";

// Copies text even where navigator.clipboard is missing (plain-http pages,
// like the site opened over Wi-Fi on a phone).
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const el = document.createElement("textarea");
    el.value = text;
    el.setAttribute("readonly", "");
    el.style.position = "fixed";
    el.style.opacity = "0";
    document.body.appendChild(el);
    el.select();
    const ok = document.execCommand("copy");
    el.remove();
    return ok;
  }
}

// A deal's discount code; tapping it copies the code. "full" is the deal
// page's dashed coupon; "badge" is the small chip on list cards. `doubtful`:
// recent answers to "did this code work?" say it doesn't (lib/code-trust.ts),
// so the chip turns amber and says "May not work": still copyable (it may
// work for some), but no one is caught out. The deal page says more.
// `label`: the words before the full coupon ("Use code", or on a price drop
// "Price with code", as the price shown needs it).
export default function VoucherCode({
  code,
  variant = "full",
  doubtful = false,
  label = "Use code",
}: {
  code: string;
  variant?: "full" | "badge";
  doubtful?: boolean;
  label?: string;
}) {
  const [copied, setCopied] = useState(false);

  async function copy(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (await copyText(code)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    }
  }

  if (variant === "badge") {
    return (
      <button
        type="button"
        onClick={copy}
        aria-label={`Copy discount code ${code}${doubtful ? ". Members say it may not work" : ""}`}
        title={doubtful ? "Members say this code may not work. Tap to copy it" : "Tap to copy the code"}
        className={`relative z-10 flex h-5 min-w-0 max-w-[10rem] shrink items-center gap-1 overflow-hidden rounded-full border border-dashed px-2 text-[11px] leading-none font-semibold ${
          doubtful
            ? "border-amber-500 bg-amber-50 text-amber-800 dark:border-amber-700 dark:bg-amber-950/40 dark:text-amber-300"
            : "border-violet-400 bg-violet-50 text-violet-700 dark:border-violet-700 dark:bg-violet-950/40 dark:text-violet-300"
        }`}
      >
        <Icon name={copied ? "check" : doubtful ? "warning" : "ticket"} className="size-3" />
        {/* A doubtful code says so in words, not just in colour. */}
        <span className={`truncate ${doubtful && !copied ? "" : "font-mono"}`}>{copied ? "Copied" : doubtful ? "May not work" : code}</span>
      </button>
    );
  }

  return (
    <div className="flex min-w-0 items-center gap-2 text-sm">
      <span className="shrink-0 text-zinc-500">{label}</span>
      <button
        type="button"
        onClick={copy}
        aria-label={`Copy discount code ${code}`}
        className="flex min-w-0 items-center overflow-hidden rounded-lg border-2 border-dashed border-violet-400 bg-violet-50 text-violet-800 transition-colors hover:bg-violet-100 dark:border-violet-700 dark:bg-violet-950/40 dark:text-violet-200 dark:hover:bg-violet-950/70"
      >
        <span className="min-w-0 truncate px-3 py-1.5 font-mono font-bold tracking-wide">{code}</span>
        <span className="shrink-0 border-l-2 border-dashed border-violet-400 px-3 py-1.5 text-xs font-semibold dark:border-violet-700">
          {copied ? (
            <span className="flex items-center gap-1">
              <Icon name="check" className="size-3.5" />
              Copied
            </span>
          ) : (
            "Copy"
          )}
        </span>
      </button>
    </div>
  );
}
