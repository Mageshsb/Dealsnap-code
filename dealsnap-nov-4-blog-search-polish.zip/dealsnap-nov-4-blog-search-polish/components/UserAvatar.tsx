import Icon from "./Icon";

const COLORS = [
  "bg-blue-500",
  "bg-purple-500",
  "bg-pink-500",
  "bg-teal-500",
  "bg-amber-500",
  "bg-green-500",
  "bg-sky-500",
  "bg-indigo-500",
  "bg-rose-500",
  "bg-orange-500",
];

// Deterministic so the same username always gets the same colour, without
// needing a stored avatar image.
function colorFor(username: string): string {
  let hash = 0;
  for (let i = 0; i < username.length; i++) {
    hash = (hash * 31 + username.charCodeAt(i)) >>> 0;
  }
  return COLORS[hash % COLORS.length];
}

const BOT_USERNAME = "DealBot";

export default function UserAvatar({
  username,
  avatarUrl,
  size = "h-5 w-5",
  textSize = "text-[10px]",
}: {
  username: string;
  avatarUrl?: string | null;
  size?: string;
  // Bigger avatars (profile header, settings) need a bigger initial.
  textSize?: string;
}) {
  const isBot = username === BOT_USERNAME;

  if (avatarUrl) {
    return (
      // eslint-disable-next-line @next/next/no-img-element -- locally uploaded, arbitrary aspect ratio
      <img
        src={avatarUrl}
        alt=""
        className={`inline-flex ${size} shrink-0 rounded-full object-cover`}
      />
    );
  }

  return (
    <span
      aria-hidden="true"
      title={isBot ? "DealBot — our AI assistant, surfacing deals it finds for you" : undefined}
      className={`inline-flex ${size} shrink-0 items-center justify-center rounded-full ${textSize} font-semibold uppercase text-white ${
        isBot ? "bg-gradient-to-br from-violet-500 to-fuchsia-500" : colorFor(username)
      }`}
    >
      {isBot ? <Icon name="bot" className="size-[60%]" /> : username.charAt(0)}
    </span>
  );
}
