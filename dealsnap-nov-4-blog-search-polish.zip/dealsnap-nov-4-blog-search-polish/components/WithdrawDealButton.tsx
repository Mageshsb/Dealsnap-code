"use client";

import { useState } from "react";
import { withdrawOwnDealAction } from "@/lib/actions";
import Icon from "./Icon";

// Taking back a deal that's still waiting for the team, with one more tap to
// be sure.
export default function WithdrawDealButton({ slug }: { slug: string }) {
  const [asking, setAsking] = useState(false);
  return (
    <form action={withdrawOwnDealAction} className="flex items-center justify-center gap-3 text-sm">
      <input type="hidden" name="slug" value={slug} />
      {asking ? (
        <>
          <span className="text-zinc-500 dark:text-zinc-400">Withdraw it for good?</span>
          <button type="submit" className="font-medium text-red-600 hover:underline dark:text-red-400">
            Yes, withdraw
          </button>
          <button type="button" onClick={() => setAsking(false)} className="text-zinc-500 hover:underline dark:text-zinc-400">
            Cancel
          </button>
        </>
      ) : (
        <button
          type="button"
          onClick={() => setAsking(true)}
          className="flex items-center gap-1.5 text-zinc-500 hover:text-red-600 dark:text-zinc-400 dark:hover:text-red-400"
        >
          <Icon name="trash" className="size-4" />
          Withdraw this deal
        </button>
      )}
    </form>
  );
}
