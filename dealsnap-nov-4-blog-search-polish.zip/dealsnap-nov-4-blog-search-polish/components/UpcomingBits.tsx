import { startsLabel } from "@/lib/upcoming";
import Icon from "./Icon";

// The look of an upcoming deal (lib/upcoming.ts), shared by every card and the
// deal page so they match: a blue "Starts Fri 8am" pill in the "Posted…"
// pill's place, and an outlined button in Get deal's place. Same sizes as
// what they replace, so no card changes shape.

export const STARTS_PILL = "bg-sky-100 text-sky-800 dark:bg-sky-950/60 dark:text-sky-300";

// Outlined orange instead of filled: the store can be looked at, but the deal
// isn't on yet.
export const UPCOMING_BUTTON = "border border-orange-500 bg-white text-orange-700 hover:bg-orange-50 dark:bg-transparent dark:text-orange-400 dark:hover:bg-orange-950/40";

// The pill's words: "Starts Fri 8am", or `short` ("Fri 8am") for a phone's
// narrow pill. The minutes can tick over between the page being made and
// shown, which isn't worth a warning.
export function StartsText({ startsAt, short = false }: { startsAt: string; short?: boolean }) {
  const label = startsLabel(startsAt) ?? "Starting now";
  // The short phone pill has no icon: its blue already says "upcoming", and
  // it has to fit where "4d ago" does.
  if (short) return <span suppressHydrationWarning>{label.replace(/^Starts /, "")}</span>;
  return (
    <span suppressHydrationWarning className="inline-flex items-center gap-1">
      <Icon name="calendar" className="size-3 shrink-0" />
      {label}
    </span>
  );
}
