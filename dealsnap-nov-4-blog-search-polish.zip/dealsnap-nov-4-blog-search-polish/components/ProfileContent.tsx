import {
  getFollowEdge,
  getFollowerCount,
  getFollowingCount,
  getUserStats,
  hasBlocked,
  hasOpenProfileReport,
  type UserRecord,
} from "@/lib/db";
import { getBadges, getBadgeProgress } from "@/lib/badges";
import { isFollowing, getPostedDealsPage, getLikedDealsPage, getCommentsPage } from "@/lib/social";
import { getCommunityStats } from "@/lib/community-db";
import ProfileView from "./ProfileView";
import { withdrawProfileReportAction } from "@/lib/member-actions";

export type ProfileParams = { tab?: string; sort?: string; page?: string; show?: string; reported?: string; error?: string };

// A member's profile: exactly the same for everyone, except that the owner
// also gets the settings cog and sees their own deals waiting for review.
export default function ProfileContent({
  profileUser,
  viewer,
  params,
}: {
  profileUser: UserRecord;
  viewer: UserRecord | null;
  params: ProfileParams;
}) {
  const { tab, sort, page, reported, error } = params;
  const isSelf = viewer?.id === profileUser.id;
  const activeTab = tab === "liked" || tab === "comments" || tab === "badges" ? tab : "posted";
  const pageNum = Number(page) || 1;
  // Expired deals are hidden unless this page was opened with ?show=all (the tile above
  // the list). It is this profile page's own choice, separate from the site-wide Filters.
  const showExpired = params.show === "all";

  const viewerFollows = isFollowing(viewer?.id ?? null, profileUser.id);
  const followEdge = viewer ? getFollowEdge(viewer.id, profileUser.id) : null;

  const base = getUserStats(profileUser.id);
  // The Community counts too: its posts are posts, and its likes, threads and
  // best answers earn badges.
  const community = getCommunityStats(profileUser.id);
  const badgeStats = {
    ...base,
    commentLikesReceived: base.commentLikesReceived + community.likesReceived,
    threadCount: community.threadsStarted,
    bestAnswerCount: community.bestAnswers,
    welcomeCount: community.welcomes,
  };
  const stats = { ...base, commentCount: base.commentCount + community.threadsStarted + community.replies };

  return (
    <>
      {reported && viewer && hasOpenProfileReport(profileUser.id, viewer.id) && (
        <form
          action={withdrawProfileReportAction.bind(null, profileUser.id)}
          role="status"
          className="flex flex-wrap items-center gap-x-2 rounded-lg bg-green-50 px-4 py-2 text-sm text-green-700 dark:bg-green-950/40 dark:text-green-400"
        >
          Thanks for the report. Our team will take a look.
          {/* Undo, as after reporting a deal or comment. */}
          <button type="submit" className="font-medium text-orange-700 hover:underline dark:text-orange-400">
            Undo
          </button>
        </form>
      )}
      {error && (
        <p role="alert" className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </p>
      )}
      <ProfileView
        profileUser={profileUser}
        basePath={`/u/${profileUser.username}`}
        activeTab={activeTab}
        isOwner={isSelf}
        isFollowing={viewerFollows}
        followMuted={followEdge?.muted ?? false}
        viewerLoggedIn={!!viewer}
        followerCount={getFollowerCount(profileUser.id)}
        followingCount={getFollowingCount(profileUser.id)}
        badges={getBadges(badgeStats)}
        badgeProgress={getBadgeProgress(badgeStats)}
        postedPage={getPostedDealsPage(profileUser.id, { isOwner: isSelf, sort, page: pageNum, showExpired })}
        likedPage={getLikedDealsPage(profileUser.id, { sort, page: pageNum, showExpired, viewer })}
        commentsPage={getCommentsPage(profileUser.id, { sort, page: pageNum, viewer })}
        stats={stats}
        viewerRelation={
          viewer && !isSelf
            ? {
                blocked: hasBlocked(viewer.id, profileUser.id),
                blockedBy: hasBlocked(profileUser.id, viewer.id),
                reported: hasOpenProfileReport(profileUser.id, viewer.id),
              }
            : undefined
        }
      />
    </>
  );
}
