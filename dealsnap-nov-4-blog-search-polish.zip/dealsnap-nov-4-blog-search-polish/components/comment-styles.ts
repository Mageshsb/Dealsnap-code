// Shared by the comment rows (server) and a member's own comment (client), so
// the two read the same.

// The comment itself: keeps the writer's line breaks, and breaks a long link
// rather than pushing the page wider.
export const COMMENT_TEXT = "whitespace-pre-line text-sm leading-relaxed text-zinc-700 [overflow-wrap:anywhere] dark:text-zinc-300";

// The line under it: Like and Reply on the left, the "⋯" menu on the right.
export const COMMENT_ACTIONS = "mt-1 flex min-h-6 items-center gap-4 text-xs text-zinc-500";
