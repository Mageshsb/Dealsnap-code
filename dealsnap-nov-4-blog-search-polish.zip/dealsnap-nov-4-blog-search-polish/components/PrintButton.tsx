"use client";

import Icon from "./Icon";

// "Save as PDF": the browser's own print, where every browser (phones too)
// offers Save as PDF. The page's print styles turn it into a clean A4 document.
export default function PrintButton({ label = "Save as PDF" }: { label?: string }) {
  return (
    <button
      type="button"
      onClick={() => window.print()}
      className="inline-flex items-center gap-1.5 rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600"
    >
      <Icon name="download" className="size-4" />
      {label}
    </button>
  );
}
