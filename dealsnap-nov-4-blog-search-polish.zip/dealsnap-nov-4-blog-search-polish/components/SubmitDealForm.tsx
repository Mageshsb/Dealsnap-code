"use client";

import Link from "next/link";
import { useEffect, useRef, useState, useSyncExternalStore, useTransition } from "react";
import {
  postDealAction,
  editOwnDealAction,
  fetchDealMetadataAction,
  getExtensionReadAction,
  codeAlreadyPostedAction,
  guessTagAction,
  type DealMetadataResult,
} from "@/lib/actions";
import { discountPercent, formatPrice } from "@/lib/format";
import { useTaxonomy } from "./TaxonomyProvider";
import TypePicker from "./TypePicker";
import BrandPicker from "./BrandPicker";
import StoreCombobox from "./StoreCombobox";
import WhereToBuyField from "./WhereToBuyField";
import {
  VoucherCodeField,
  DeliveryField,
  ConditionsField,
  EventsField,
  PriceExtrasFields,
  CHOICE_TILE,
  HINT,
  INPUT,
  type PriceExtrasValue,
} from "./DealExtrasFields";
import SelectField from "./SelectField";
import AmountInput from "./AmountInput";
import DealPhotoField, { type DealPhoto } from "./DealPhotoField";
import BotCheck from "./BotCheck";
import { useRouter } from "next/navigation";
import { saveDealDraft, type DealDraft } from "@/lib/deal-draft";
import { shorterTitle } from "@/lib/title-tidy";
import { linkIn } from "@/lib/pasted-link";
import type { EditFrom } from "@/lib/deal-edit-from";
import type { WhereToBuy } from "@/lib/where-to-buy";
import {
  DEAL_CONDITIONS,
  MULTIBUY_CHOICES,
  OFFER_FIELD_NAMES,
  OFFER_MAX,
  PRICE_UNITS,
  VOUCHER_UNITS,
  SALE_UNITS,
  buildOffer,
  canBeWholeStore,
  dealPriceTag,
  offerFieldsFromHints,
  parsePriceUnit,
  type DealCondition,
  type DealKind,
  type OfferFields,
  type PriceTag,
} from "@/lib/deal-kinds";
import Icon, { type IconName } from "./Icon";
import { londonInputToIso, startsInFull } from "@/lib/upcoming";
import { Field, KIND_COPY, Note, ProblemContext, ProblemText, STEPS, UpToTile, problemFor, type FillState, type Problem } from "./post/bits";
import KindTiles from "./post/KindTiles";
import { CompactPreview, PhonePreview } from "./post/DealPreviews";
import DuplicateNotes, { needsALook } from "./post/DuplicateNotes";
import ExtraRow from "./post/ExtraRow";
import RichEditor from "./RichEditor";
import { DEAL_TITLE_MAX, MAX_PICTURES } from "@/lib/deal-text";

// "offer" is the offer boxes of a sale, multi-buy, voucher or cashback.
type FilledField = "title" | "price" | "originalPrice" | "store" | "category" | "offer";

const noSubscribe = () => () => {};

// The offer boxes before anything's chosen: "Up to" ticked for a sale, and
// a voucher's money off in pounds.
const OFFER_DEFAULTS: OfferFields = { saleUnit: "%", saleUpTo: "1", voucherUnit: "£" };

// Phones and tablets, where pasting into a box is fiddly, get a Paste button
// (only where the browser lets a page ask for what's copied).
const canPasteButton = () =>
  window.matchMedia("(pointer: coarse)").matches && window.isSecureContext && !!navigator.clipboard?.readText;

// "Sun 9 Nov", for the answers on the "Anything else?" lines.
const shortDate = (date: Date) => date.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });

// When editing, every step shows at once, each under its own heading.
function SectionHeading({ index }: { index: number }) {
  return (
    <h2 className={`text-base font-bold ${index > 0 ? "border-t border-zinc-100 pt-5 dark:border-zinc-800" : ""}`}>
      {STEPS[index].title}
    </h2>
  );
}

// The price people pay for a product, when it's less than its page price: a
// members price ("£17.50 Clubcard Price"), a voucher to tick on the page
// ("Apply £5 voucher"), or a code its page gives with what it takes off
// ("25% off code AUTUMN") when the product alone is enough to use it. With
// a few words for under the price box and for the description.
function priceCut(res: DealMetadataResult | null): { price: number; hint: string; fact: string } | undefined {
  const offer = res?.offer;
  const price = res?.price;
  if (!offer || price === undefined || res?.range) return undefined;
  if (offer.memberPrice !== undefined && offer.memberPrice < price) {
    return { price: offer.memberPrice, hint: "The price with the store's loyalty card.", fact: "That's with the store's loyalty card." };
  }
  const code =
    offer.voucherCode &&
    (offer.voucherUnit === "£" || offer.voucherUnit === "%") &&
    offer.voucherAmount &&
    (offer.voucherMinSpend ?? 0) <= price &&
    !offer.voucherWithOther
      ? { unit: offer.voucherUnit, amount: offer.voucherAmount }
      : undefined;
  const off = offer.pageVoucher ?? code;
  if (!off) return undefined;
  const after = Math.round((off.unit === "£" ? price - off.amount : price * (1 - off.amount / 100)) * 100) / 100;
  if (!(after > 0)) return undefined;
  if (!offer.pageVoucher) return { price: after, hint: `With code ${offer.voucherCode}.`, fact: `Use code ${offer.voucherCode} to get this price.` };
  const amount = off.unit === "£" ? `£${Number.isInteger(off.amount) ? off.amount : off.amount.toFixed(2)}` : `${off.amount}%`;
  return { price: after, hint: `With the ${amount} voucher on the page.`, fact: `Tick the ${amount} voucher on the page to get this price.` };
}

// Asks the DealSnap browser extension, when it's on this browser, to read a
// link from a shop that won't let us read its pages: it opens it in a tab
// behind, as its right-click "Post this link" does (see extension/content.js).
// Gives the ticket for what it read, or nothing.
function readWithExtension(link: string): Promise<string | undefined> {
  if (!document.documentElement.dataset.dealsnapExtension) return Promise.resolve(undefined);
  const id = crypto.randomUUID();
  return new Promise((done) => {
    const finish = (ticket?: string) => {
      clearTimeout(timer);
      window.removeEventListener("message", listen);
      done(ticket);
    };
    const listen = (event: MessageEvent) => {
      if (event.source !== window || event.data?.dealsnap !== "read-link-reply" || event.data.id !== id) return;
      finish(typeof event.data.ticket === "string" ? event.data.ticket : undefined);
    };
    const timer = setTimeout(finish, 45000);
    window.addEventListener("message", listen);
    window.postMessage({ dealsnap: "read-link", id, url: link }, window.location.origin);
  });
}

// "What does it cover?" on a voucher or sale (lib/deal-kinds.ts WHOLE_STORE_KINDS).
const SCOPE_CHOICES: { value: "store" | "products"; label: string; icon: IconName }[] = [
  { value: "store", label: "Whole store", icon: "store" },
  { value: "products", label: "Some products", icon: "tag" },
];

// A link to a store's front page or its sale page ("next.co.uk/",
// "argos.co.uk/sale"), rather than to some products.
function storeWideLink(raw: string): boolean {
  try {
    // Its front page, or a sale page one or two steps in, named for the sale
    // ("/sale", "/events/jan-sales"); not a part of one ("/sale/womens").
    const parts = new URL(raw.trim()).pathname.toLowerCase().split("/").filter(Boolean);
    // ("tv-sale" is some products, so only a season or event before it.)
    const saleWord =
      /^((jan(uary)?|summer|winter|spring|autumn|mid-season|end-of-season|big|mega|flash)[-_])?(sales?|clearance|offers|deals|outlet)$|^(black-friday|cyber-monday|boxing-day)$/;
    return parts.length === 0 || (parts.length <= 2 && saleWord.test(parts[parts.length - 1]));
  } catch {
    return false;
  }
}

export default function SubmitDealForm({
  knownStores,
  storeVariants,
  storesWithSite = [],
  goesLiveImmediately,
  guest = false,
  initial,
  editing,
  eventChoices = [],
  botCheckKey,
  extensionTicket,
  sharedUrl,
  extension,
  iphone,
  brands = [],
}: {
  knownStores: string[];
  storeVariants?: Record<string, string>;
  // Stores whose website we know, so an in-store deal posted without a link
  // only asks for the website when it's at a store we don't.
  storesWithSite?: string[];
  // Who posts without waiting for a check: staff, or a member who has earned it.
  goesLiveImmediately?: "staff" | "trusted";
  // Not logged in: the form works as normal, but "Submit" keeps the deal on
  // this device and asks them to join first (they come straight back to it).
  guest?: boolean;
  initial?: DealDraft | null;
  // The poster changing a deal they've posted: every part shows at once, as
  // there's nothing to work through, with one Save button.
  // helping: someone fixing another member's deal. locked: they can't change
  // where it points, so its link and shop are left out of the form.
  editing?: {
    slug: string;
    live: boolean;
    helping?: boolean;
    locked?: boolean;
    from?: EditFrom;
    hq?: string;
    backHref?: string;
    // When the form was opened, so a save can't quietly undo someone else's
    // change made in the meantime (lib/collisions.ts).
    seen?: string;
  };
  // The shopping events on now, for the "Part of an event?" tiles.
  eventChoices?: { slug: string; name: string; icon: IconName }[];
  // Cloudflare's robot check before posting, once it's set up (members only:
  // guests get it when they join).
  botCheckKey?: string;
  // A page the browser extension read (its ticket), or a link shared to
  // DealSnap from a phone.
  extensionTicket?: string;
  sharedUrl?: string;
  // Where to get the browser extension on this browser, once it's published:
  // suggested when a shop won't let us read its pages.
  extension?: { url: string; browser: string };
  // On an iPhone: pointed to the Shortcut that posts from any app's Share
  // button (/iphone).
  iphone?: boolean;
  // The brands a deal can be "Made by" (lib/brands.ts), A–Z.
  brands?: string[];
}) {
  const router = useRouter();
  const today = new Date().toISOString().slice(0, 10);
  const [kind, setKind] = useState<DealKind>(initial?.kind ?? "price");
  const copy = KIND_COPY[kind];
  // The answers that make up a sale, multi-buy or voucher's offer.
  const [offerFields, setOfferFields] = useState<OfferFields>(initial?.offerFields ?? OFFER_DEFAULTS);
  const setOfferField = (name: keyof OfferFields, value: string) => setOfferFields((f) => ({ ...f, [name]: value }));
  // The poster's own answers, which a link never changes.
  const typedOffer = useRef(new Set<keyof OfferFields>());
  function editOffer(name: keyof OfferFields, value: string) {
    typedOffer.current.add(name);
    touch("offer");
    setOfferField(name, value);
  }
  // What it is starts empty — a hidden default is how deals end up filed as
  // the wrong thing. Autofill fills it only when it has a match. The category
  // comes with the tag.
  const [tag, setTag] = useState(initial?.tag ?? "");
  // Who makes it: autofill's guess until the poster picks; a type with a
  // maker (MacBook → Apple) decides it.
  const [brand, setBrand] = useState(initial?.brand ?? "");
  const [linkBrand, setLinkBrand] = useState<string>();
  const taxonomy = useTaxonomy();
  // A voucher or sale can be for the whole store (lib/deal-kinds.ts): then
  // it has no type or brand, as it isn't any one kind of thing. Vouchers
  // usually are ("£10 off £50"), so they start as Whole store; a sale is
  // more often a range, so it starts as Some products.
  // A sale linked to the store's front page or its sale page
  // (next.co.uk/sale) is almost always the whole store, so it starts so too.
  const [url, setUrl] = useState(initial?.url ?? sharedUrl ?? "");
  const [scopePick, setScopePick] = useState<"store" | "products" | undefined>(initial?.scope);
  const scopeFor = (k: DealKind) => scopePick ?? (k === "voucher" || storeWideLink(url) ? "store" : "products");
  const wholeStore = canBeWholeStore(kind) && scopeFor(kind) === "store";
  // Switching between Voucher and Sale ("No code? Make it a Sale") keeps
  // what it's for, rather than falling back to the other type's default.
  const [scopeKind, setScopeKind] = useState(kind);
  if (kind !== scopeKind) {
    setScopeKind(kind);
    if (!scopePick && canBeWholeStore(scopeKind) && canBeWholeStore(kind)) setScopePick(scopeFor(scopeKind));
  }
  const maker = tag && !wholeStore ? taxonomy.tagMaker(tag) : undefined;
  const typeLabel = canBeWholeStore(kind) ? "Which products?" : "What is it?";

  // An in-store deal with no link to post: it points at the store's website.
  const [noLink, setNoLink] = useState(!!initial?.noLink && !editing);
  const [storeSite, setStoreSite] = useState(initial?.storeSite ?? "");
  const [where, setWhere] = useState<WhereToBuy>(initial?.whereToBuy ?? "online");
  const [title, setTitle] = useState(initial?.title ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  // New pictures in the description (screenshots of how to get the deal),
  // by their key, waiting to be sent (see RichEditor).
  const [pictures, setPictures] = useState<Record<string, string>>(initial?.pictures ?? {});
  const [price, setPrice] = useState(initial?.price ?? "");
  const [originalPrice, setOriginalPrice] = useState(initial?.originalPrice ?? "");
  // The "was" price is the store's RRP: shown as "RRP £x", not crossed out.
  const [wasRrp, setWasRrp] = useState(!!initial?.wasRrp);
  const wasRrpTouched = useRef(!!editing || !!initial);
  const [store, setStore] = useState(initial?.store ?? "");
  const [priceExtras, setPriceExtras] = useState<PriceExtrasValue>({
    priceUnit: initial?.priceUnit ?? "",
    priceFrom: !!initial?.priceFrom,
    cashback: initial?.cashback ?? "",
  });
  const [conditions, setConditions] = useState<DealCondition[]>(initial?.conditions ?? []);
  const [photo, setPhoto] = useState<DealPhoto | null>(initial?.photo ? { src: initial.photo, fromLink: false } : null);
  // Extras the shop's page told us (an end date, free delivery, a "from"
  // price). Their boxes keep their own state, so a new value remounts them
  // (the key), unless the poster has already set them.
  const [endDate, setEndDate] = useState(initial?.expiresAt ?? "");
  const [endFromLink, setEndFromLink] = useState(false);
  // An upcoming deal: when it starts (UK time), from the page or typed.
  const [startAt, setStartAt] = useState(initial?.startsAt ?? "");
  const [startFromLink, setStartFromLink] = useState(false);
  const [linkDelivery, setLinkDelivery] = useState<number>();
  const [deliveryKey, setDeliveryKey] = useState(0);
  // Delivery as the poster set it (its boxes keep their own state).
  const [deliveryTyped, setDeliveryTyped] = useState<{ choice: string; cost: string } | null>(null);
  const [extrasKey, setExtrasKey] = useState(0);
  const [extrasFromLink, setExtrasFromLink] = useState(false);
  // A code and catches the page gave.
  const [linkCode, setLinkCode] = useState<string>();
  const [codeKey, setCodeKey] = useState(0);
  // Mirrors touchedExtras.code for the parts that draw from it (a ref isn't read while drawing).
  const [codeTouched, setCodeTouched] = useState(false);
  const [codeText, setCodeText] = useState("");
  const [conditionsKey, setConditionsKey] = useState(0);
  const [conditionsFromLink, setConditionsFromLink] = useState(false);
  const [eventsTicked, setEventsTicked] = useState<string[]>(initial?.events ?? []);
  const touchedExtras = useRef({
    end: false,
    start: false,
    delivery: false,
    priceFrom: false,
    code: false,
    conditions: false,
    kind: !!editing || !!initial,
  });
  const [botWait, setBotWait] = useState(false);
  // The link picked the kind of deal (a page of many products is a sale, one
  // on a 3 for 2 a multi-buy…), and the poster hasn't changed it.
  const [kindGuessed, setKindGuessed] = useState(false);
  const autoKind = useRef<DealKind | null>(null);

  // One step at a time: the must-haves first, then the optional extras. A
  // deal brought back opens on the step it was left on (after joining, or
  // with something to fix, that's the last one, ready to post).
  const [step, setStep] = useState(initial ? Math.min(initial.step ?? STEPS.length - 1, STEPS.length - 1) : 0);
  const last = step === STEPS.length - 1;
  const shows = (i: number) => !!editing || step === i;
  // Fixing someone else's deal without the right to repoint it: the link and
  // shop are out of sight (still in the form, but the server ignores them).
  const hideLocked = editing?.locked ? "hidden" : "";

  // The "Anything else?" lines that are open. An in-store deal without a link
  // opens "Where to get it", to say which stores.
  const [openRows, setOpenRows] = useState<Set<string>>(() => new Set(initial?.noLink ? ["where"] : []));
  const toggleRow = (name: string) =>
    setOpenRows((rows) => {
      const next = new Set(rows);
      if (!next.delete(name)) next.add(name);
      return next;
    });

  // The box that needs fixing, shown in red with the reason under it.
  const [problem, setProblem] = useState<Problem>(null);
  const problemEl = useRef<HTMLElement | null>(null);
  function clearProblem() {
    problemEl.current?.removeAttribute("aria-invalid");
    problemEl.current?.removeAttribute("aria-describedby");
    problemEl.current = null;
    setProblem(null);
  }
  function clearIfFixing(target: EventTarget) {
    const el = target as HTMLInputElement;
    if (problem && (el.id === problem.id || el.name === problem.id)) clearProblem();
  }
  function showProblem(el: HTMLInputElement | HTMLTextAreaElement) {
    const found = problemFor(el);
    if (!found) return;
    problemEl.current?.removeAttribute("aria-invalid");
    problemEl.current = el;
    el.setAttribute("aria-invalid", "true");
    el.setAttribute("aria-describedby", `${found.id}-problem`);
    // A box inside a closed "Anything else?" line opens it first.
    const row = el.closest("[data-row]")?.getAttribute("data-row");
    if (row) setOpenRows((rows) => new Set(rows).add(row));
    setProblem(found);
    requestAnimationFrame(() => {
      el.focus({ preventScroll: true });
      (document.getElementById(`${found.id}-problem`) ?? el).scrollIntoView({ block: "center" });
    });
  }

  const [isFetching, startFetching] = useTransition();
  const [result, setResult] = useState<DealMetadataResult | null>(null);
  // The browser extension reading a link a shop turned us away from.
  const [extensionStatus, setExtensionStatus] = useState<"reading" | "tried" | null>(null);
  const [fill, setFill] = useState<Partial<Record<FilledField, FillState>>>({});
  // What the last read put in each box, for the autofill report sent with
  // the deal (kept, or changed by the poster).
  const [linkValues, setLinkValues] = useState<Partial<Record<Exclude<FilledField, "offer">, string>>>({});
  const urlInput = useRef<HTMLInputElement>(null);
  // A deal being edited has already been read, so it's only read again if
  // the link changes.
  const lastFetchedUrl = useRef<string | null>(editing ? (initial?.url ?? null) : null);
  const requestId = useRef(0);
  // Next was pressed while the link was still being read: move on once it's
  // read, unless there's something on step 1 they need to see first.
  const advanceWhenRead = useRef(false);
  const [waitingToAdvance, setWaitingToAdvance] = useState(false);

  // What autofill last put in each field, so a new link can replace its own
  // earlier values but never something the poster typed themselves.
  // ("category" is the "What is it?" box, holding the tag.)
  const latest = useRef({ kind, title, price, originalPrice, store, category: tag, photo, brand, linkBrand });
  useEffect(() => {
    latest.current = { kind, title, price, originalPrice, store, category: tag, photo, brand, linkBrand };
  });
  const autoValues = useRef<Partial<Record<FilledField, string>>>({});

  function touch(field: FilledField) {
    setFill((f) => (f[field] ? { ...f, [field]: undefined } : f));
    delete autoValues.current[field];
  }

  // With no link to read (an in-store deal, or nothing pasted yet), the title
  // is the best clue to "What is it?": a moment after they stop typing it,
  // pre-fill the pick, unless the poster has chosen one themselves (anything
  // autofill put there is still replaceable). A weaker guess is marked "check".
  useEffect(() => {
    const words = title.trim();
    if (words.length < 4 || wholeStore) return;
    const own = () => !!latest.current.category && latest.current.category !== autoValues.current.category;
    if (own()) return;
    let current = true;
    const timer = setTimeout(async () => {
      const guess = await guessTagAction(words).catch(() => null);
      if (!current || !guess || own() || !taxonomy.getTagByName(guess.tag)) return;
      setTag(guess.tag);
      autoValues.current.category = guess.tag;
      setFill((f) => ({ ...f, category: guess.confidence === "high" ? "auto" : "check" }));
    }, 700);
    return () => {
      current = false;
      clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [title, wholeStore]);

  // Reads the link and fills in what it can. Returns whether it started.
  function autofillFromLink(value?: string): boolean {
    const trimmed = (value ?? url).trim();
    if (!/^https?:\/\//i.test(trimmed) || trimmed === lastFetchedUrl.current) return false;
    lastFetchedUrl.current = trimmed;
    readLink(trimmed, (res) => applyRead(res, trimmed));
    return true;
  }

  // Editing: what the deal still lacks (its photo; its "was" price, when the
  // page's price is the deal's), from its link read again. Nothing already
  // there changes. On a store that turns our reader away, someone with the
  // DealSnap extension (a helper, from the helper desk) gets these from it.
  const [gapsNote, setGapsNote] = useState<string | null>(null);
  function fillGapsFromLink() {
    const trimmed = url.trim();
    if (!/^https?:\/\//i.test(trimmed)) return;
    setGapsNote(null);
    readLink(trimmed, (res) => {
      const added: string[] = [];
      if (!latest.current.photo && res.photo) {
        setPhoto({ src: res.photo, fromLink: true });
        added.push("the photo");
      }
      const samePrice = res.price !== undefined && Number(latest.current.price) === res.price;
      if (latest.current.kind === "price" && !latest.current.originalPrice && samePrice && res.originalPrice !== undefined) {
        setOriginalPrice(res.originalPrice.toFixed(2));
        setWasRrp(!!res.wasRrp);
        setFill((f) => ({ ...f, originalPrice: "check" }));
        added.push("the was price");
      }
      setGapsNote(
        added.length
          ? `Added ${added.join(" and ")} from the store's page. Give ${added.length > 1 ? "them" : "it"} a check.`
          : res.error ?? "There was nothing new on the store's page to add."
      );
    });
  }

  // Reads a link: by us, or, for a shop that turns us away, by the browser
  // extension if it's here.
  function readLink(trimmed: string, use: (res: DealMetadataResult) => void) {
    const id = ++requestId.current;
    setResult(null);
    setExtensionStatus(null);
    startFetching(async () => {
      // A page the extension read is used again, not re-read from a shop
      // that may turn us away.
      const pinned = extensionRead.current;
      let res = pinned?.url === trimmed ? pinned : await fetchDealMetadataAction(trimmed, editing?.slug);
      if (id !== requestId.current) return; // a newer link was pasted meanwhile
      // A shop that turned us away: the browser extension reads it instead,
      // if it's here.
      if (res.blocked && document.documentElement.dataset.dealsnapExtension) {
        setExtensionStatus("reading");
        const ticket = await readWithExtension(trimmed);
        const read = ticket ? await getExtensionReadAction(ticket) : null;
        if (id !== requestId.current) return;
        setExtensionStatus("tried");
        if (read && !read.error) {
          extensionRead.current = read;
          res = read;
        }
      }
      use(res);
    });
  }

  // Fills in the form from a read link (ours, or the extension's).
  function applyRead(res: DealMetadataResult, trimmed: string) {
    setResult(res);

    // The kind of deal the page is about (a sale, a multi-buy, a code,
    // cashback), unless they've chosen the kind themselves. A kind an earlier
    // link chose goes back to a price drop for a link that's just a product.
    const hints = res.offer ?? {};
    const suggested = hints.kind ?? (res.range ? "sale" : undefined);
    const toKind = suggested && suggested !== "price" ? suggested : null;
    const kindIsOurs = latest.current.kind === "price" || latest.current.kind === autoKind.current;
    if (!touchedExtras.current.kind && kindIsOurs) {
      const next = toKind ?? "price";
      setKind(next);
      latest.current.kind = next;
      autoKind.current = toKind;
      setKindGuessed(!res.error);
    }

    // The offer's details, for every kind, so they're there whichever the
    // poster picks. Their own answers stay.
    const fromPage = offerFieldsFromHints(hints);
    setOfferFields((current) => {
      const next = { ...current };
      for (const name of OFFER_FIELD_NAMES) {
        if (typedOffer.current.has(name)) continue;
        next[name] = fromPage[name] ?? OFFER_DEFAULTS[name];
      }
      return next;
    });
    if (!touchedExtras.current.code) {
      setLinkCode(hints.voucherCode);
      setCodeKey((k) => k + 1);
    }
    if (!touchedExtras.current.conditions) {
      setConditions(hints.conditions ?? []);
      setConditionsFromLink(!!hints.conditions?.length);
      setConditionsKey((k) => k + 1);
    }
    if (res.endsOn && !touchedExtras.current.end) {
      setEndDate(res.endsOn);
      setEndFromLink(true);
    }
    // The page says it starts later (midnight, unless they set a time).
    if (res.startsOn && !touchedExtras.current.start) {
      setStartAt(`${res.startsOn}T00:00`);
      setStartFromLink(true);
    }
    if (res.delivery === 0 && !touchedExtras.current.delivery) {
      setLinkDelivery(0);
      setDeliveryKey((k) => k + 1);
    }
    // How the price is charged: "from", a month, after cashback. (A page of
    // plans "from £24.99 a month" gives its price that way too.)
    const fromPrice = res.price === undefined ? hints.fromPrice : undefined;
    if (!touchedExtras.current.priceFrom) {
      const extras = {
        priceFrom: !!(res.priceFrom || fromPrice),
        priceUnit: hints.priceUnit ?? "",
        cashback:
          hints.cashback !== undefined && !res.range
            ? Number.isInteger(hints.cashback)
              ? String(hints.cashback)
              : hints.cashback.toFixed(2)
            : "",
      };
      setPriceExtras(extras);
      setExtrasFromLink(extras.priceFrom || !!extras.priceUnit || !!extras.cashback);
      setExtrasKey((k) => k + 1);
    }

    const nextFill: Partial<Record<FilledField, FillState>> = {};
    const put: Partial<Record<Exclude<FilledField, "offer">, string>> = {};
    const apply = (field: Exclude<FilledField, "offer">, next: string | undefined, set: (v: string) => void, state: FillState = "auto") => {
      const current = latest.current[field];
      const canReplace = !current || current === autoValues.current[field];
      if (!canReplace) return false;
      if (next) {
        set(next);
        autoValues.current[field] = next;
        put[field] = next;
        nextFill[field] = state;
      } else if (current) {
        set("");
        delete autoValues.current[field];
      }
      return true;
    };
    // A page of many products is named for what's on it ("Argos Sale"), a
    // best guess to check.
    apply("title", res.title, setTitle, res.range ? "check" : "auto");
    if (latest.current.kind === "price") {
      // A voucher to tick on the page ("Apply £5 voucher") comes off: it's
      // the price people pay
      // (and so does a code the product's own page gives), with the price
      // before it as the "was".
      const cut = priceCut(res);
      const pagePrice = cut?.price ?? res.price ?? fromPrice;
      apply("price", pagePrice != null ? pagePrice.toFixed(2) : undefined, setPrice);
      // A "was" price read off the page without its "Save £…" to check it
      // against is a best guess (yellow). One the page calls an RRP is ticked
      // as one.
      const was = res.originalPrice ?? (cut ? res.price : undefined);
      const replaced = apply(
        "originalPrice",
        was != null ? was.toFixed(2) : undefined,
        setOriginalPrice,
        res.wasUnsure ? "check" : "auto"
      );
      if (replaced && !wasRrpTouched.current) setWasRrp(!!(res.originalPrice !== undefined && res.wasRrp));
    }
    apply("store", res.store, setStore);

    const knownTag = res.tag ? taxonomy.getTagByName(res.tag)?.tag.name : undefined;
    if (knownTag) {
      const current = latest.current.category;
      if (!current || current === autoValues.current.category) {
        setTag(knownTag);
        autoValues.current.category = knownTag;
        put.category = knownTag;
        nextFill.category = res.confidence === "high" ? "auto" : "check";
      }
    } else if (latest.current.category && latest.current.category === autoValues.current.category) {
      setTag("");
      delete autoValues.current.category;
    }
    // The brand, unless the poster has picked one themselves.
    if (latest.current.brand === "" || latest.current.brand === latest.current.linkBrand) setBrand(res.brand ?? "");
    setLinkBrand(res.brand ?? "");
    if (Object.keys(fromPage).length && !typedOffer.current.size) nextFill.offer = "auto";
    setFill((f) => ({ ...f, offer: undefined, ...nextFill }));
    setLinkValues(put);
    // The product photo, unless they've added their own.
    if (!latest.current.photo || latest.current.photo.fromLink) setPhoto(res.photo ? { src: res.photo, fromLink: true } : null);

    // Swap in the tidied link (tracking tags removed, short links expanded).
    if (res.url && res.url !== trimmed) {
      lastFetchedUrl.current = res.url;
      setUrl(res.url);
    }

    if (advanceWhenRead.current) {
      advanceWhenRead.current = false;
      setWaitingToAdvance(false);
      if (!res.error && !needsALook(res.duplicates) && !res.warnings?.length) setStep(1);
    }
  }

  // Arriving from the browser extension's "Post this deal" (?read=…), or
  // from sharing a link to DealSnap on a phone (?url=…): read it straight away.
  const extensionRead = useRef<DealMetadataResult | null>(null);
  const arrived = useRef(false);
  useEffect(() => {
    if (arrived.current) return;
    arrived.current = true;
    if (sharedUrl) {
      autofillFromLink(sharedUrl);
      return;
    }
    if (!extensionTicket) return;
    const id = ++requestId.current;
    startFetching(async () => {
      const res = await getExtensionReadAction(extensionTicket);
      if (id !== requestId.current) return;
      if (!res) {
        setResult({ error: "That page has timed out. Press Post this deal on it again, or paste its link here." });
        return;
      }
      extensionRead.current = res;
      if (res.url) {
        lastFetchedUrl.current = res.url;
        setUrl(res.url);
      }
      applyRead(res, res.url ?? "");
    });
    // Once, on arrival.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // A different kind of deal wants different things from the page: a price
  // drop takes its price, the rest their offer (already filled in from the
  // same read). So a new choice fills in again from it, and drops a price it
  // filled in for a price drop that this kind doesn't use.
  function changeKind(next: DealKind) {
    touchedExtras.current.kind = true;
    setKindGuessed(false);
    setKind(next);
    latest.current.kind = next;
    if (problem) clearProblem();
    if (next !== "price") {
      for (const [field, set] of [["price", setPrice], ["originalPrice", setOriginalPrice]] as const) {
        if (autoValues.current[field] && latest.current[field] === autoValues.current[field]) {
          set("");
          delete autoValues.current[field];
          setFill((f) => ({ ...f, [field]: undefined }));
        }
      }
    }
    if (result && !result.error && lastFetchedUrl.current) applyRead(result, lastFetchedUrl.current);
    else {
      lastFetchedUrl.current = null;
      autofillFromLink();
    }
  }

  // A "voucher" with no code to enter is a sale (the money comes off by
  // itself), and a code that works across a whole store is a voucher: one
  // tap moves the answers across, so nothing typed is lost.
  function switchOffer(to: "sale" | "voucher") {
    const moved: (keyof OfferFields)[] =
      to === "sale" ? ["saleUnit", "saleUpTo", "saleAmount", "salePercent", "saleMinSpend"] : ["voucherUnit", "voucherAmount", "voucherMinSpend"];
    moved.forEach((name) => typedOffer.current.add(name));
    setOfferFields((f) => {
      if (to === "sale") {
        const unit = f.voucherUnit ?? "£";
        return {
          ...f,
          saleUnit: unit,
          saleUpTo: "",
          saleAmount: unit === "£" ? f.voucherAmount : f.saleAmount,
          salePercent: unit === "%" ? f.voucherAmount : f.salePercent,
          saleMinSpend: f.voucherMinSpend,
        };
      }
      if (kind !== "sale") return f;
      const unit = f.saleUnit ?? "%";
      return {
        ...f,
        voucherUnit: unit,
        voucherAmount: unit === "£" ? f.saleAmount : unit === "%" ? f.salePercent : f.voucherAmount,
        voucherMinSpend: f.saleMinSpend,
      };
    });
    changeKind(to);
    // The voucher's amount and code are asked for with its offer.
    if (to === "voucher" && !editing) setStep(1);
  }

  // An in-store deal with nothing to link to: no link box, and it's marked
  // as in-store only, with "Where to get it" open to say which stores.
  function chooseNoLink(on: boolean) {
    setNoLink(on);
    if (problem) clearProblem();
    if (on) {
      setUrl("");
      setResult(null);
      lastFetchedUrl.current = null;
      setWhere("instore");
      setOpenRows((rows) => new Set(rows).add("where"));
    } else {
      setWhere("online");
      setTimeout(() => urlInput.current?.focus(), 0);
    }
  }

  const anyFilled = Object.values(fill).some(Boolean);
  // A title too long for the two lines phones show: a tidier one to offer.
  const shorter = shorterTitle(title);
  // What the page couldn't give. (From a shop that won't let us read its
  // pages, only the link was read: what's left to add from its page.)
  const askPrice = kind === "price" && !result?.range;
  const priceNotice =
    !result || result.error || !result.notice
      ? undefined
      : result.source === "link"
        ? `${result.notice} ${
            result.title
              ? `Please check the title${askPrice ? ", and add the price from its page" : ""}.`
              : `Please add the title${askPrice ? " and price" : ""} from its page.`
          }`
        : kind === "price"
          ? result.notice
          : undefined;

  const sections = useRef<(HTMLDivElement | null)[]>([]);
  // The first box in a step that isn't filled in right, if any.
  const invalidIn = (i: number) =>
    Array.from(sections.current[i]?.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>("input, textarea") ?? []).find(
      (el) => el.willValidate && !el.checkValidity()
    );

  const heading = useRef<HTMLHeadingElement>(null);
  const firstRender = useRef(true);
  // Set when posting found a box to fix on an earlier step: that box is
  // pointed out once its step shows, rather than the step's heading.
  const fixOnShow = useRef(false);
  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    if (fixOnShow.current) {
      fixOnShow.current = false;
      // Once the step has drawn, so its boxes can be pointed at.
      requestAnimationFrame(() => {
        const bad = invalidIn(step);
        if (bad) showProblem(bad);
      });
      return;
    }
    // Start each step at its top, and tell screen readers where they are.
    const el = heading.current;
    if (!el) return;
    el.focus({ preventScroll: true });
    if (el.getBoundingClientRect().top < 80) el.scrollIntoView({ block: "center" });
  }, [step]);

  // Kept on the device as it's filled in (lib/deal-draft), a moment after
  // each change, so leaving halfway through loses nothing. Not once it's
  // been sent, or it would come back after posting.
  const formRef = useRef<HTMLFormElement>(null);
  const sent = useRef(false);
  useEffect(() => {
    if (editing) return;
    const timer = setTimeout(() => {
      if (formRef.current && !sent.current) saveDealDraft(formRef.current, photo?.src, { step, sent: false, pictures });
    }, 600);
    return () => clearTimeout(timer);
  });

  // The phone Paste button: puts a link that's been copied in the box.
  const showPaste = useSyncExternalStore(noSubscribe, canPasteButton, () => false) && !editing && !url;
  const [pasteNote, setPasteNote] = useState<string | null>(null);
  async function pasteLink() {
    let copied: string;
    try {
      copied = await navigator.clipboard.readText();
    } catch {
      setPasteNote("Your phone didn't let us paste. Press and hold in the box, then choose Paste.");
      urlInput.current?.focus();
      return;
    }
    const link = linkIn(copied);
    if (!link) {
      setPasteNote(
        copied.trim()
          ? "What you've copied isn't a link. Copy the deal's link from the store first."
          : "Nothing's copied yet. Copy the deal's link from the store first."
      );
      return;
    }
    setPasteNote(null);
    if (problem) clearProblem();
    setUrl(link);
    autofillFromLink(link);
  }

  function goNext() {
    const bad = invalidIn(step);
    if (bad) {
      showProblem(bad);
      return;
    }
    // Wait for the link to be read, so step 2 opens filled in.
    if (step === 0 && (autofillFromLink() || isFetching)) {
      advanceWhenRead.current = true;
      setWaitingToAdvance(true);
      return;
    }
    setStep(step + 1);
  }

  // What the card's big price spot will show, for the preview.
  const priceNumber = parseFloat(price);
  const wasNumber = parseFloat(originalPrice);
  const cashbackNumber = parseFloat(priceExtras.cashback);
  const previewExtras = {
    priceUnit: parsePriceUnit(priceExtras.priceUnit),
    priceFrom: priceExtras.priceFrom,
    cashback: Number.isFinite(cashbackNumber) && cashbackNumber > 0 && cashbackNumber < priceNumber ? cashbackNumber : undefined,
  };
  const previewTag: PriceTag =
    kind === "price"
      ? Number.isFinite(priceNumber) && priceNumber > 0
        ? dealPriceTag({ price: priceNumber, originalPrice: Number.isFinite(wasNumber) ? wasNumber : priceNumber, wasRrp, ...previewExtras })
        : { ...dealPriceTag({ price: 0, originalPrice: 0, ...previewExtras }), main: "£0.00" }
      : dealPriceTag({ kind, offer: buildOffer(kind, offerFields).offer ?? "Your offer", price: 0, originalPrice: 0 });
  const preview = {
    title: title.trim(),
    tag: previewTag,
    store: store.trim(),
    conditions,
    cashback: kind === "price" ? previewExtras.cashback : undefined,
    photo: photo?.src,
    tagName: wholeStore ? undefined : tag,
    wholeStore,
    voucher: kind === "voucher",
  };

  // Good news only: the price beats (or matches) every time this product has
  // been posted on DealSnap. Nothing is said when it's been cheaper before,
  // as a deal can be worth posting without being the lowest ever.
  const earlier = result?.earlier;
  const singlePrice = kind === "price" && !priceExtras.priceFrom && !priceExtras.priceUnit && priceNumber > 0;
  const lowest = earlier && singlePrice ? (priceNumber < earlier.lowest - 0.005 ? "lowest" : priceNumber <= earlier.lowest + 0.005 ? "matches" : null) : null;

  // "Add the shop's description": what it added, and what was there before,
  // so unticking puts it back (unless they've edited it since).
  const [shopText, setShopText] = useState<{ before: string; after: string } | null>(null);
  const atStore = store.trim() ? ` at ${store.trim()}` : "";
  const offerLine = kind !== "price" && kind !== "freebie" ? buildOffer(kind, offerFields).offer : undefined;
  // A voucher's title writes itself ("Argos discount code", the words people
  // search for) until the poster changes it: a store's front page has no
  // title worth keeping, and the offer already shows just under the title.
  const autoTitle =
    kind === "voucher" && store.trim()
      ? `${store.trim()} ${offerFields.voucherUnit === "delivery" ? "free delivery code" : "discount code"}`
      : "";
  const [lastAutoTitle, setLastAutoTitle] = useState(autoTitle);
  if (autoTitle !== lastAutoTitle) {
    setLastAutoTitle(autoTitle);
    if (autoTitle && (!title.trim() || title === lastAutoTitle || fill.title)) {
      setTitle(autoTitle);
      setFill((f) => ({ ...f, title: "check" }));
    } else if (!autoTitle && lastAutoTitle && title === lastAutoTitle) {
      // No longer a voucher: a title it wrote, untouched, goes with it.
      setTitle("");
      setFill((f) => ({ ...f, title: undefined }));
    }
  }
  // The voucher or code we took off the price, while it's still our price.
  const cut = kind === "price" && fill.price ? priceCut(result) : undefined;
  const priceFacts = [
    kind === "price" && Number.isFinite(priceNumber) && Number.isFinite(wasNumber) && wasNumber > priceNumber
      ? `${wasRrp ? "RRP" : "Was"} ${formatPrice(wasNumber)}, now ${formatPrice(priceNumber)}${atStore} (${discountPercent(priceNumber, wasNumber)}% off).`
      : "",
    lowest === "lowest" ? "The lowest it's been on DealSnap." : "",
    cut?.fact ?? "",
    offerLine ? `${offerLine}${linkCode && !codeTouched ? ` with code ${linkCode}` : ""}${atStore}.` : "",
    startAt && startFromLink && londonInputToIso(startAt) ? `Starts ${startsInFull(londonInputToIso(startAt)!)}.` : "",
    endDate && endFromLink ? `Ends ${new Date(`${endDate}T12:00:00`).toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" })}.` : "",
  ]
    .filter(Boolean)
    .join(" ");
  function toggleShopText(on: boolean) {
    if (on) {
      const added = [priceFacts, result?.description].filter(Boolean).join("\n\n");
      const after = description.trim() ? `${description.trim()}\n\n${added}` : added;
      setShopText({ before: description, after });
      setDescription(after);
    } else {
      if (shopText && description === shopText.after) setDescription(shopText.before);
      setShopText(null);
    }
  }

  const codeNow = codeTouched ? codeText : (linkCode ?? initial?.voucherCode ?? "");
  // A code with a link to the store's front page reads like a store-wide
  // voucher, whatever type was picked.
  const frontPage = (() => {
    try {
      return new URL(url.trim()).pathname.replace(/\/+$/, "") === "";
    } catch {
      return false;
    }
  })();
  const looksLikeVoucher = kind !== "voucher" && kind !== "freebie" && !!codeNow && frontPage;

  // The same code at the same store, already live: said under the code box,
  // a moment after typing stops, so a second copy isn't posted.
  const [samePosted, setSamePosted] = useState<{ key: string; slug: string; title: string } | null>(null);
  const codeKeyNow = codeNow.length >= 3 && store.trim() ? `${store.trim().toLowerCase()}|${codeNow.toUpperCase()}` : "";
  useEffect(() => {
    if (!codeKeyNow) return;
    let stale = false;
    const timer = setTimeout(async () => {
      const found = await codeAlreadyPostedAction(store, codeNow, editing?.slug).catch(() => null);
      if (!stale) setSamePosted(found ? { key: codeKeyNow, ...found } : null);
    }, 500);
    return () => {
      stale = true;
      clearTimeout(timer);
    };
    // The key holds the store and code.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [codeKeyNow]);
  const alreadyPosted = samePosted && samePosted.key === codeKeyNow ? samePosted : null;

  const codeBelow = (
    <>
      {alreadyPosted && (
        <p className="flex items-start gap-1.5 rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-900 dark:bg-amber-950/40 dark:text-amber-200">
          <Icon name="info" className="mt-0.5 size-4 shrink-0" />
          <span className="min-w-0">
            Already posted:{" "}
            <a href={`/deals/${alreadyPosted.slug}`} target="_blank" rel="noopener" className="font-semibold underline">
              {alreadyPosted.title}
            </a>
          </span>
        </p>
      )}
      {kind === "voucher" && !codeNow && (
        <button
          type="button"
          onClick={() => switchOffer("sale")}
          className="flex min-h-9 items-center gap-1 self-start text-sm font-semibold text-orange-700 hover:underline dark:text-orange-400"
        >
          No code to enter? Make it a Sale
          <Icon name="chevron-right" className="size-4" />
        </button>
      )}
      {looksLikeVoucher && (
        <p className="flex flex-wrap items-center gap-x-2 gap-y-1 rounded-lg bg-violet-50 px-3 py-2 text-sm text-violet-900 dark:bg-violet-950/40 dark:text-violet-200">
          <span className="flex items-center gap-1.5">
            <Icon name="ticket" className="size-4 shrink-0" />
            A code for the whole store?
          </span>
          <button type="button" onClick={() => switchOffer("voucher")} className="font-semibold text-violet-800 underline dark:text-violet-200">
            Make it a voucher
          </button>
        </p>
      )}
    </>
  );

  // The discount code: the page's, unless they've typed their own. (A
  // voucher asks for it with its offer, other kinds with the extras.)
  const codeField = (
    <div
      className="min-w-0"
      onChange={(e) => {
        touchedExtras.current.code = true;
        setCodeTouched(true);
        setCodeText((e.target as HTMLInputElement).value.trim());
      }}
    >
      <VoucherCodeField
        key={`code-${codeKey}`}
        defaultValue={(codeTouched ? undefined : linkCode) ?? initial?.voucherCode}
        fromLink={!!linkCode && !codeTouched}
        voucher={kind === "voucher"}
        below={codeBelow}
      />
    </div>
  );

  // The multi-buy amount or own wording sits beside the choice; otherwise the
  // choice has the row to itself.
  const multibuyExtra = offerFields.multibuy?.endsWith("£") || offerFields.multibuy === "other";

  // An in-store deal without a link, at a store we don't know the website of.
  const storeKnown = storesWithSite.some((s) => s.toLowerCase() === store.trim().toLowerCase());
  const askStoreSite = noLink && !!store.trim() && !storeKnown;

  // The answers on the "Anything else?" lines.
  const deliveryNow = (() => {
    if (deliveryTyped) return deliveryTyped.choice === "free" ? "Free" : deliveryTyped.choice === "paid" ? (Number(deliveryTyped.cost) > 0 ? formatPrice(Number(deliveryTyped.cost)) : "Costs extra") : "";
    const given = linkDelivery ?? initial?.delivery;
    return given === undefined ? "" : given === 0 ? "Free" : formatPrice(given);
  })();
  const endNow = endDate ? shortDate(new Date(`${endDate}T12:00:00`)) : "";
  const startNow = (() => {
    const at = startAt ? londonInputToIso(startAt) : undefined;
    if (!at) return "";
    const date = new Date(at);
    const time = startAt.endsWith("T00:00") ? "" : `, ${date.toLocaleTimeString("en-GB", { hour: "numeric", minute: "2-digit", timeZone: "Europe/London" })}`;
    return `${shortDate(date)}${time}`;
  })();
  const priceIsNow = [
    priceExtras.priceFrom ? "From price" : "",
    PRICE_UNITS.find((u) => u.value === priceExtras.priceUnit)?.label ?? "",
    Number(priceExtras.cashback) > 0 ? `${formatPrice(Number(priceExtras.cashback))} cashback` : "",
  ]
    .filter(Boolean)
    .join(" · ");
  const catchesNow = DEAL_CONDITIONS.filter((c) => conditions.includes(c.value))
    .map((c) => c.short)
    .join(" · ");
  const eventsNow = eventChoices
    .filter((e) => eventsTicked.includes(e.slug))
    .map((e) => e.name)
    .join(" · ");

  // Sent with the deal for Admin → Insights (lib/autofill-report.ts): how the
  // link was read and, for each box autofill fills, whether the poster kept
  // what it put there, changed it, added it themselves or left it empty.
  const boxes = { title, price, originalPrice, store, category: tag };
  const autofillReport =
    result && !result.error && result.source && !editing
      ? JSON.stringify({
          via: result.via ?? result.source,
          fields: Object.fromEntries(
            (Object.keys(boxes) as (keyof typeof boxes)[]).map((name) => {
              const filled = linkValues[name];
              return [name, filled !== undefined ? (boxes[name] === filled ? "kept" : "changed") : boxes[name] ? "added" : "empty"];
            })
          ),
        })
      : "";

  return (
    <ProblemContext.Provider value={problem}>
      {/* On a computer the deal's card sits beside the form and changes as
          it's filled in; phones get a small one at the top of "The details"
          and the full card before posting. */}
      <div className="flex flex-col gap-6 lg:grid lg:grid-cols-[minmax(0,1fr)_20rem] lg:items-start lg:gap-8">
        <form
          ref={formRef}
          action={editing ? editOwnDealAction : postDealAction}
          // The browser's own checks can't reach a box on a hidden step, so each
          // step is checked when moving on, and everything again before posting.
          noValidate
          // Typing in (or changing) the box that needs fixing clears its red.
          onInput={(e) => clearIfFixing(e.target)}
          onChange={(e) => clearIfFixing(e.target)}
          onSubmit={(e) => {
            const badStep = STEPS.findIndex((_, i) => invalidIn(i));
            if (badStep !== -1) {
              e.preventDefault();
              if (editing || badStep === step) showProblem(invalidIn(badStep)!);
              else {
                fixOnShow.current = true;
                setStep(badStep);
              }
              return;
            }
            // The pictures must fit in one post (the server takes up to 4MB).
            const form = e.currentTarget;
            const bytes = [...new FormData(form).values()].reduce((n, v) => n + (v instanceof File ? v.size : 0), 0);
            if (bytes > 3.8 * 1024 * 1024) {
              e.preventDefault();
              setStep(1);
              setProblem({ id: "description", message: "Your pictures are too big to send together. Take one or two out." });
              requestAnimationFrame(() => document.getElementById("description-problem")?.scrollIntoView({ block: "center" }));
              return;
            }
            if (editing) return;
            // Cloudflare's check hands over its pass a moment after it shows.
            if (botCheckKey && !guest && !new FormData(form).get("cf-turnstile-response")) {
              e.preventDefault();
              setBotWait(true);
              return;
            }
            // Kept on the device as it's sent, so if it comes back with something
            // to fix, it comes back filled in. (A guest's isn't sent yet: they
            // join first, then it comes back to post.)
            sent.current = !guest;
            saveDealDraft(form, photo?.src, { step, sent: !guest, pictures });
            if (!guest) return;
            e.preventDefault();
            router.push(`/signup?next=${encodeURIComponent("/submit?draft=1")}`);
          }}
          onKeyDown={(e) => {
            // Enter in a box moves on a step, rather than posting half a deal.
            const target = e.target as HTMLElement;
            if (e.key === "Enter" && !last && !editing && !e.defaultPrevented && target.tagName === "INPUT") {
              e.preventDefault();
              goNext();
            }
          }}
          className="flex min-w-0 flex-col gap-6 rounded-xl border border-zinc-200 bg-white p-4 sm:p-6 dark:border-zinc-800 dark:bg-zinc-900"
        >
          {autofillReport && <input type="hidden" name="autofillReport" value={autofillReport} />}
          {editing ? (
            <>
              <input type="hidden" name="slug" value={editing.slug} />
              {editing.from && <input type="hidden" name="from" value={editing.from} />}
              {editing.hq && <input type="hidden" name="hq" value={editing.hq} />}
              {editing.seen && <input type="hidden" name="seen" value={editing.seen} />}
            </>
          ) : (
            <div className="flex flex-col gap-1">
              <div className="mb-2 flex gap-1.5" aria-hidden>
                {STEPS.map((s, i) => (
                  <span key={s.title} className={`h-1 flex-1 rounded-full ${i <= step ? "bg-orange-500" : "bg-zinc-200 dark:bg-zinc-800"}`} />
                ))}
              </div>
              <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
                Step {step + 1} of {STEPS.length}
              </p>
              <h2 ref={heading} tabIndex={-1} className="text-lg font-bold outline-none">
                {STEPS[step].title}
              </h2>
              <p className="text-sm text-zinc-500 dark:text-zinc-400">{STEPS[step].hint}</p>
            </div>
          )}

          {/* Step 1: the link (it fills in most of step 2) and what kind of deal. */}
          <div ref={(el) => void (sections.current[0] = el)} hidden={!shows(0)} className="flex flex-col gap-5">
            {editing && !editing.locked && <SectionHeading index={0} />}
            <div className={`flex flex-col gap-2 ${hideLocked}`}>
              {noLink ? (
                <div className="flex flex-col gap-1.5">
                  <p className="text-sm font-medium">Link to the deal</p>
                  <input type="hidden" name="noLink" value="1" />
                  <div className="flex min-h-11 items-center justify-between gap-3 rounded-lg bg-zinc-100 px-3 py-2 text-sm sm:min-h-10 dark:bg-zinc-800">
                    <span className="flex min-w-0 items-center gap-2">
                      <Icon name="store" className="size-4 shrink-0 text-zinc-500 dark:text-zinc-400" />
                      <span className="truncate">In-store deal, no link</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => chooseNoLink(false)}
                      className="shrink-0 font-medium text-orange-700 hover:underline dark:text-orange-400"
                    >
                      Add a link
                    </button>
                  </div>
                  <p className={HINT}>We&apos;ll point people to the store&apos;s website. You can say which stores have it at the end.</p>
                </div>
              ) : (
                <>
                  <Field label="Link to the deal" htmlFor="url">
                    <div className="relative">
                      <input
                        ref={urlInput}
                        id="url"
                        name="url"
                        required
                        type="url"
                        autoComplete="off"
                        value={url}
                        onChange={(e) => {
                          setUrl(e.target.value);
                          setPasteNote(null);
                        }}
                        // Read it the moment it's pasted, or on leaving the box.
                        onBlur={() => autofillFromLink()}
                        onPaste={() => setTimeout(() => autofillFromLink(urlInput.current?.value), 0)}
                        placeholder="https://..."
                        className={`w-full min-w-0 ${INPUT} ${showPaste ? "pr-24" : ""}`}
                      />
                      {showPaste && (
                        <button
                          type="button"
                          onClick={pasteLink}
                          className="absolute right-1.5 top-1/2 flex -translate-y-1/2 items-center gap-1.5 rounded-lg bg-orange-500 px-3 py-1.5 text-sm font-semibold text-white hover:bg-orange-600"
                        >
                          <Icon name="clipboard-paste" className="size-4" />
                          Paste
                        </button>
                      )}
                    </div>
                  </Field>
                  {!editing && !url && !isFetching && (
                    <button
                      type="button"
                      onClick={() => chooseNoLink(true)}
                      className="self-start text-sm font-medium text-orange-700 hover:underline dark:text-orange-400"
                    >
                      No link? It&apos;s an in-store deal
                    </button>
                  )}
                </>
              )}
              {pasteNote && (
                <Note tone="warn" icon="warning">
                  {pasteNote}
                </Note>
              )}
              {iphone && !url && !editing && !noLink && (
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  Quicker: post from any app&apos;s Share button with{" "}
                  <Link href="/iphone" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
                    our iPhone Shortcut
                  </Link>
                  .
                </p>
              )}
              {isFetching ? (
                <p className="flex items-center gap-1.5 text-xs text-zinc-500 dark:text-zinc-400">
                  <Icon name="loader" className="size-3.5 animate-spin" />
                  {extensionStatus === "reading" ? "Reading it with your DealSnap extension…" : "Reading the page…"}
                </p>
              ) : (
                result &&
                !result.error &&
                anyFilled &&
                (result.source === "link" ? (
                  // Only the link's own words were read: no tick, as it didn't work.
                  <p className="flex items-start gap-1.5 text-xs text-zinc-500 dark:text-zinc-400">
                    <Icon name="info" className="mt-px size-3.5 shrink-0" />
                    {result.notice ?? "We couldn't read that page, so we've used what the link tells us."}
                  </p>
                ) : (
                  <p className="flex items-center gap-1.5 text-xs text-green-700 dark:text-green-400">
                    <Icon name="check" className="size-3.5" />
                    Got it. We&apos;ve filled in what we could.
                  </p>
                ))
              )}
              {kind === "price" && result?.offer?.multibuy && (
                <Note tone="good" icon="basket">
                  It&apos;s also on a multi-buy ({buildOffer("multibuy", offerFields).offer ?? "see the page"}). Choose Multi-buy below if
                  that&apos;s the better deal.
                </Note>
              )}
              {result?.error && (
                <Note tone="warn" icon="warning">
                  {result.error}
                </Note>
              )}
              {result?.blocked && extension && !extensionStatus && (
                <Note tone="good" icon="sparkles">
                  Our browser extension can read {result.store ?? "the store"}&apos;s page for you and fill it all in.{" "}
                  <a href={extension.url} target="_blank" rel="noopener noreferrer" className="font-semibold underline">
                    Add it to {extension.browser}
                  </a>
                </Note>
              )}
              {result?.warnings?.map((w) => (
                <Note key={w} tone="warn" icon="warning">
                  {w}
                </Note>
              ))}
              {result?.duplicates && <DuplicateNotes check={result.duplicates} />}
            </div>

            <KindTiles value={kind} onChange={changeKind} guessed={kindGuessed} />
          </div>

          {/* Step 2: everything a deal can't go up without. */}
          <div ref={(el) => void (sections.current[1] = el)} hidden={!shows(1)} className="flex flex-col gap-5">
            {editing && <SectionHeading index={1} />}
            {!editing && (
              <div className="lg:hidden">
                <CompactPreview {...preview} />
              </div>
            )}
            {(anyFilled || priceNotice) && (
              <div className="flex flex-col gap-2">
                {anyFilled && result?.source !== "link" && (
                  <Note tone="good" icon="check">
                    Boxes in green came from the link, so give them a quick check.
                    {Object.values(fill).includes("check") && " Ones in yellow are our best guess, so check them closely."}
                  </Note>
                )}
                {priceNotice && (
                  <Note tone="warn" icon="warning">
                    {priceNotice}
                    {result?.source === "page" && " Not one product? Go back and choose another kind of deal."}
                    {result?.source === "link" && anyFilled && " Anything in green came from the link, so check it."}
                  </Note>
                )}
              </div>
            )}

            <Field
              label={copy.titleLabel}
              htmlFor="title"
              fill={fill.title}
              hint={
                kind === "price"
                  ? "Phones show only the first two or three lines, so the key details are best near the start."
                  : "The offer shows just under the title, so you can leave it out here if you like."
              }
            >
              <input
                id="title"
                name="title"
                required
                maxLength={DEAL_TITLE_MAX}
                value={title}
                onChange={(e) => {
                  touch("title");
                  setTitle(e.target.value);
                }}
                placeholder={copy.title}
                className={INPUT}
              />
              {shorter && (
                <p className="flex items-start gap-2 rounded-lg bg-zinc-100 px-3 py-2 text-sm text-zinc-700 dark:bg-zinc-800 dark:text-zinc-200">
                  <span className="min-w-0 flex-1">
                    Shorter, so it all shows: <span className="font-medium">&ldquo;{shorter}&rdquo;</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      touch("title");
                      setTitle(shorter);
                    }}
                    className="shrink-0 font-semibold text-orange-700 dark:text-orange-400 hover:underline"
                  >
                    Use this
                  </button>
                </p>
              )}
            </Field>

            {kind === "price" && (
              <div className="flex flex-col gap-2">
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Deal price" htmlFor="price" fill={fill.price} hint={cut?.hint}>
                    <AmountInput
                      unit="£"
                      id="price"
                      name="price"
                      required
                      step="0.01"
                      min="0.01"
                      value={price}
                      onChange={(e) => {
                        touch("price");
                        setPrice(e.target.value);
                      }}
                      placeholder="219.00"
                      className={INPUT}
                    />
                  </Field>
                  <Field label="Was" htmlFor="originalPrice" fill={fill.originalPrice}>
                    <AmountInput
                      unit="£"
                      id="originalPrice"
                      name="originalPrice"
                      step="0.01"
                      min="0.01"
                      value={originalPrice}
                      onChange={(e) => {
                        touch("originalPrice");
                        setOriginalPrice(e.target.value);
                      }}
                      placeholder="Optional"
                      className={INPUT}
                    />
                  </Field>
                </div>
                {/* A store's recommended price often isn't one anybody charged,
                    so it's shown as "RRP £x" rather than crossed out. */}
                {wasNumber > 0 && (
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                    <label className={`${CHOICE_TILE} gap-1.5 whitespace-nowrap`}>
                      <input
                        type="checkbox"
                        name="wasRrp"
                        value="1"
                        checked={wasRrp}
                        onChange={(e) => {
                          wasRrpTouched.current = true;
                          setWasRrp(e.target.checked);
                        }}
                        className="sr-only"
                      />
                      <Icon name={wasRrp ? "check" : "plus"} className="size-4" />
                      It&apos;s the RRP
                    </label>
                    <span className={HINT}>{wasRrp ? `Shows as “RRP ${formatPrice(wasNumber)}”, not crossed out.` : "Tick if the store calls it the RRP."}</span>
                  </div>
                )}
                {lowest && (
                  <p className="flex items-center gap-1.5 text-sm font-medium text-green-700 dark:text-green-400">
                    <Icon name="trending-down" className="size-4 shrink-0" />
                    {lowest === "lowest"
                      ? `Lowest it's been on DealSnap (posted ${earlier!.times === 1 ? "once" : `${earlier!.times} times`} before)`
                      : "Matches the lowest it's been on DealSnap"}
                  </p>
                )}
              </div>
            )}

            {kind === "sale" && (
              <>
                {/* A % off (most sales), money off or free delivery, which
                    comes off by itself: an offer with a code is a voucher. */}
                <fieldset className="flex flex-col gap-1.5">
                  <legend className="mb-1.5 text-sm font-medium">What does it give?</legend>
                  <div className="grid grid-cols-[1fr_1fr_1.7fr] gap-1.5 sm:flex sm:gap-2">
                    {SALE_UNITS.map((u) => (
                      <label key={u.value} className={`${CHOICE_TILE} whitespace-nowrap`}>
                        <input
                          type="radio"
                          name="saleUnit"
                          value={u.value}
                          checked={(offerFields.saleUnit ?? "%") === u.value}
                          onChange={() => {
                            editOffer("saleUnit", u.value);
                            // "Up to" suits a % sale; money off rarely says it.
                            if (u.value !== "%") setOfferField("saleUpTo", "");
                          }}
                          className="sr-only"
                        />
                        {u.label}
                      </label>
                    ))}
                  </div>
                </fieldset>
                <div className="grid grid-cols-2 gap-3">
                  {offerFields.saleUnit !== "delivery" && (
                    <div className={offerFields.saleUnit === "£" ? "" : "col-span-2"}>
                      <Field label="How much off?" htmlFor={offerFields.saleUnit === "£" ? "saleAmount" : "salePercent"} fill={fill.offer}>
                        <div className="grid grid-cols-[auto_1fr] gap-2">
                          <UpToTile name="saleUpTo" checked={!!offerFields.saleUpTo} onChange={(on) => editOffer("saleUpTo", on ? "1" : "")} />
                          {offerFields.saleUnit === "£" ? (
                            <AmountInput
                              unit="£"
                              id="saleAmount"
                              name="saleAmount"
                              required
                              step="0.01"
                              min="0.01"
                              value={offerFields.saleAmount ?? ""}
                              onChange={(e) => editOffer("saleAmount", e.target.value)}
                              placeholder="5"
                              className={INPUT}
                            />
                          ) : (
                            <AmountInput
                              unit="%"
                              unitAfter
                              id="salePercent"
                              name="salePercent"
                              required
                              inputMode="numeric"
                              step="1"
                              min="1"
                              max="99"
                              value={offerFields.salePercent ?? ""}
                              onChange={(e) => editOffer("salePercent", e.target.value)}
                              placeholder="70"
                              className={INPUT}
                            />
                          )}
                        </div>
                      </Field>
                    </div>
                  )}
                  {offerFields.saleUnit && offerFields.saleUnit !== "%" && (
                    <Field label="Minimum spend" htmlFor="saleMinSpend" fill={offerFields.saleMinSpend ? fill.offer : undefined}>
                      <AmountInput
                        unit="£"
                        id="saleMinSpend"
                        name="saleMinSpend"
                        step="0.01"
                        min="0.01"
                        value={offerFields.saleMinSpend ?? ""}
                        onChange={(e) => editOffer("saleMinSpend", e.target.value)}
                        placeholder="Optional"
                        className={INPUT}
                      />
                    </Field>
                  )}
                </div>
              </>
            )}

            {kind === "multibuy" && (
              <div className="grid grid-cols-2 gap-3">
                <div className={`min-w-0 ${multibuyExtra ? "" : "col-span-2"}`}>
                  <Field label="The offer" htmlFor="multibuy" fill={fill.offer}>
                    <SelectField
                      id="multibuy"
                      name="multibuy"
                      label="The offer"
                      required
                      placeholder="Choose…"
                      value={offerFields.multibuy ?? ""}
                      onChange={(v) => {
                        editOffer("multibuy", v);
                        if (problem?.id === "multibuy") clearProblem();
                      }}
                      options={MULTIBUY_CHOICES.map((c) => ({ value: c, label: c === "other" ? "Something else…" : c.endsWith("£") ? `${c}…` : c }))}
                    />
                  </Field>
                </div>
                {offerFields.multibuy?.endsWith("£") && (
                  <Field label="For" htmlFor="multibuyPrice" fill={offerFields.multibuyPrice ? fill.offer : undefined}>
                    <AmountInput
                      unit="£"
                      id="multibuyPrice"
                      name="multibuyPrice"
                      required
                      step="0.01"
                      min="0.01"
                      value={offerFields.multibuyPrice ?? ""}
                      onChange={(e) => editOffer("multibuyPrice", e.target.value)}
                      placeholder="5.00"
                      className={INPUT}
                    />
                  </Field>
                )}
                {offerFields.multibuy === "other" && (
                  <Field label="Type it" htmlFor="multibuyOther" fill={offerFields.multibuyOther ? fill.offer : undefined}>
                    <input
                      id="multibuyOther"
                      name="multibuyOther"
                      required
                      maxLength={OFFER_MAX}
                      value={offerFields.multibuyOther ?? ""}
                      onChange={(e) => editOffer("multibuyOther", e.target.value)}
                      placeholder="Buy 2 get 1 free"
                      className={`min-w-0 ${INPUT}`}
                    />
                  </Field>
                )}
              </div>
            )}

            {kind === "voucher" && (
              <>
                {/* A voucher's code is the deal itself, so it comes first,
                    rather than with the extras. */}
                {codeField}
                <fieldset className="flex flex-col gap-1.5">
                  <legend className="mb-1.5 text-sm font-medium">What does it give?</legend>
                  {/* "Free delivery" gets the most room so it fits a 360px phone. */}
                  <div className="grid grid-cols-[1fr_1fr_1.7fr] gap-1.5 sm:flex sm:gap-2">
                    {VOUCHER_UNITS.map((u) => (
                      <label key={u.value} className={`${CHOICE_TILE} whitespace-nowrap`}>
                        <input
                          type="radio"
                          name="voucherUnit"
                          value={u.value}
                          checked={(offerFields.voucherUnit ?? "£") === u.value}
                          onChange={() => editOffer("voucherUnit", u.value)}
                          className="sr-only"
                        />
                        {u.label}
                      </label>
                    ))}
                  </div>
                </fieldset>
                <div className="grid grid-cols-2 gap-3">
                  {offerFields.voucherUnit !== "delivery" && (
                    <Field label="How much off?" htmlFor="voucherAmount" fill={fill.offer}>
                      <AmountInput
                        unit={offerFields.voucherUnit === "%" ? "%" : "£"}
                        unitAfter={offerFields.voucherUnit === "%"}
                        id="voucherAmount"
                        name="voucherAmount"
                        required
                        step="0.01"
                        min="0.01"
                        value={offerFields.voucherAmount ?? ""}
                        onChange={(e) => editOffer("voucherAmount", e.target.value)}
                        placeholder={offerFields.voucherUnit === "%" ? "20" : "5"}
                        className={INPUT}
                      />
                    </Field>
                  )}
                  <Field label="Minimum spend" htmlFor="voucherMinSpend" fill={offerFields.voucherMinSpend ? fill.offer : undefined}>
                    <AmountInput
                      unit="£"
                      id="voucherMinSpend"
                      name="voucherMinSpend"
                      step="0.01"
                      min="0.01"
                      value={offerFields.voucherMinSpend ?? ""}
                      onChange={(e) => editOffer("voucherMinSpend", e.target.value)}
                      placeholder="Optional"
                      className={INPUT}
                    />
                  </Field>
                </div>
              </>
            )}

            {kind === "cashback" && (
              <Field label="How much back?" htmlFor="cashbackAmount" fill={fill.offer}>
                <div className="grid grid-cols-[auto_1fr] gap-2">
                  <UpToTile
                    name="cashbackUpTo"
                    checked={!!offerFields.cashbackUpTo}
                    onChange={(on) => editOffer("cashbackUpTo", on ? "1" : "")}
                  />
                  <AmountInput
                    unit="£"
                    id="cashbackAmount"
                    name="cashbackAmount"
                    required
                    step="0.01"
                    min="0.01"
                    value={offerFields.cashbackAmount ?? ""}
                    onChange={(e) => editOffer("cashbackAmount", e.target.value)}
                    placeholder="50"
                    className={INPUT}
                  />
                </div>
              </Field>
            )}

            <div className={`flex flex-col gap-5 ${hideLocked}`}>
              <Field label="Store" htmlFor="store" fill={fill.store}>
                <StoreCombobox
                  id="store"
                  name="store"
                  value={store}
                  onChange={(v) => {
                    touch("store");
                    setStore(v);
                    if (problem?.id === "store") clearProblem();
                  }}
                  options={knownStores}
                  variants={storeVariants}
                />
              </Field>
              {askStoreSite && (
                <Field label="The store's website" htmlFor="storeSite" hint="So people can find the store. Just the address is fine.">
                  <input
                    id="storeSite"
                    name="storeSite"
                    required
                    value={storeSite}
                    onChange={(e) => setStoreSite(e.target.value)}
                    autoComplete="off"
                    autoCapitalize="none"
                    spellCheck={false}
                    placeholder="e.g. bmstores.co.uk"
                    className={INPUT}
                  />
                </Field>
              )}
            </div>

            {canBeWholeStore(kind) && (
              <fieldset className="flex flex-col gap-1.5">
                <legend className="mb-1.5 text-sm font-medium">What does it cover?</legend>
                <div className="grid grid-cols-2 gap-1.5 sm:flex sm:gap-2">
                  {SCOPE_CHOICES.map((o) => (
                    <label key={o.value} className={`${CHOICE_TILE} gap-1.5 whitespace-nowrap`}>
                      <input
                        type="radio"
                        name="scope"
                        value={o.value}
                        checked={(o.value === "store") === wholeStore}
                        onChange={() => {
                          setScopePick(o.value);
                          if (problem?.id === "tag") clearProblem();
                        }}
                        className="sr-only"
                      />
                      <Icon name={o.icon} className="size-4" />
                      {o.label}
                    </label>
                  ))}
                </div>
                <p className={HINT}>
                  {wholeStore
                    ? "Money off almost anything there. It's listed under the store, not a category."
                    : "Only on some things, like TVs or one brand. Pick what below."}
                </p>
              </fieldset>
            )}

            {!wholeStore && (
              <Field
                label={typeLabel}
                htmlFor="tag"
                fill={fill.category}
                hint={
                  canBeWholeStore(kind)
                    ? "The most specific that covers all of it: Laptop, or All of Electronics if it's several kinds of thing."
                    : "The most specific fits best: MacBook rather than Laptop."
                }
              >
                <TypePicker
                  id="tag"
                  name="tag"
                  label={typeLabel}
                  allowCategory={canBeWholeStore(kind)}
                  required
                  value={tag}
                  onChange={(v) => {
                    touch("category");
                    setTag(v);
                    if (problem?.id === "tag") clearProblem();
                  }}
                />
              </Field>
            )}

            <Field
              label="Why is it a good deal?"
              htmlFor="description"
              hint={`A line or two is plenty. Add pictures to show how to get it${kind === "voucher" ? ", like where the code goes" : ""}.`}
              fill={shopText && description === shopText.after ? "auto" : undefined}
            >
              <RichEditor
                value={description}
                onChange={setDescription}
                pictures={pictures}
                onPictures={setPictures}
                placeholder={copy.description}
                maxPictures={MAX_PICTURES.deal}
                fieldName="description"
                filesName="shots"
                requiredId="description"
              />
            </Field>
            {/* A head start from the shop's page: the price facts and a short
                description of the product. Their own words are better, so it's a
                choice, and it goes after anything they've already written. */}
            {(result?.description || priceFacts) && (
              // Green, like the boxes filled from the link, as this is from it too.
              <label className="-mt-2 flex min-h-11 cursor-pointer items-center gap-1.5 self-start rounded-xl border border-green-300 bg-green-50 px-3 text-sm font-medium text-green-800 transition-colors hover:bg-green-100 has-focus-visible:ring-2 has-focus-visible:ring-green-500 has-focus-visible:ring-offset-2 sm:min-h-10 dark:border-green-700 dark:bg-green-950/50 dark:text-green-300 dark:hover:bg-green-950 dark:ring-offset-zinc-900">
                <input type="checkbox" checked={!!shopText} onChange={(e) => toggleShopText(e.target.checked)} className="sr-only" />
                {shopText ? <Icon name="check" className="size-4" /> : <Icon name="plus" className="size-4" />}
                Add the store&apos;s description
              </label>
            )}
          </div>

          {/* Step 3: all optional, one line each with its answer so far (green
              when it came from the link). Tapping a line opens it. */}
          <div ref={(el) => void (sections.current[2] = el)} hidden={!shows(2)} className="flex flex-col gap-6">
            {editing && <SectionHeading index={2} />}
            <div className="-mt-2 flex flex-col">
              <ExtraRow
                name="photo"
                label="Photo"
                icon="image"
                value={photo ? (photo.fromLink ? "From the store" : "Added") : ""}
                filled={!!photo?.fromLink}
                open={openRows.has("photo")}
                onToggle={toggleRow}
              >
                <div className="flex flex-col gap-3">
                  <DealPhotoField value={photo} onChange={setPhoto} />
                  {editing && url && (!photo || (kind === "price" && !originalPrice)) && (
                    <div className="flex flex-col gap-2">
                      <button
                        type="button"
                        onClick={fillGapsFromLink}
                        disabled={isFetching}
                        className="flex items-center gap-1.5 self-start rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold text-zinc-700 hover:border-orange-300 hover:bg-orange-50 hover:text-orange-700 disabled:opacity-60 dark:border-zinc-700 dark:text-zinc-200 dark:hover:border-orange-800 dark:hover:bg-orange-950/40 dark:hover:text-orange-400"
                      >
                        <Icon name={isFetching ? "loader" : "sparkles"} className={`size-4 ${isFetching ? "animate-spin" : ""}`} />
                        {isFetching
                          ? extensionStatus === "reading"
                            ? "Reading it with your DealSnap extension…"
                            : "Reading the store's page…"
                          : "Fill in the gaps from the link"}
                      </button>
                      {gapsNote && <p className="text-xs text-zinc-500 dark:text-zinc-400">{gapsNote}</p>}
                    </div>
                  )}
                </div>
              </ExtraRow>

              <ExtraRow name="ends" label="Ends" icon="calendar" value={endNow} filled={endFromLink} open={openRows.has("ends")} onToggle={toggleRow}>
                <Field
                  label="End date"
                  htmlFor="expiresAt"
                  fill={endFromLink ? "auto" : undefined}
                  hint={endFromLink ? "From the store's page." : "Leave blank if you don't know."}
                >
                  <input
                    id="expiresAt"
                    name="expiresAt"
                    type="date"
                    value={endDate}
                    onChange={(e) => {
                      touchedExtras.current.end = true;
                      setEndFromLink(false);
                      setEndDate(e.target.value);
                    }}
                    // A deal being edited can keep an end date that's passed.
                    min={editing && initial?.expiresAt && initial.expiresAt < today ? undefined : today}
                    // iPhones centre a date and shrink an empty one; keep it a normal box.
                    className={`w-full min-w-0 appearance-none text-left [&::-webkit-date-and-time-value]:text-left ${INPUT}`}
                  />
                </Field>
              </ExtraRow>

              {kind !== "voucher" && (
                <ExtraRow
                  name="code"
                  label="Discount code"
                  icon="ticket"
                  value={codeNow}
                  filled={!!linkCode && !codeTouched}
                  open={openRows.has("code")}
                  onToggle={toggleRow}
                >
                  {codeField}
                </ExtraRow>
              )}

              <ExtraRow
                name="catches"
                label="Catches"
                icon="list"
                value={catchesNow}
                filled={conditionsFromLink}
                open={openRows.has("catches")}
                onToggle={toggleRow}
              >
                <ConditionsField
                  key={`conditions-${conditionsKey}`}
                  defaultValue={conditions}
                  onChange={(v) => {
                    touchedExtras.current.conditions = true;
                    setConditionsFromLink(false);
                    setConditions(v);
                  }}
                />
              </ExtraRow>

              <ExtraRow
                name="delivery"
                label="Delivery"
                icon="truck"
                value={deliveryNow}
                filled={!deliveryTyped && linkDelivery !== undefined}
                open={openRows.has("delivery")}
                onToggle={toggleRow}
              >
                <div
                  className="flex flex-col gap-2"
                  onChange={(e) => {
                    touchedExtras.current.delivery = true;
                    const box = e.currentTarget;
                    setDeliveryTyped({
                      choice: box.querySelector<HTMLInputElement>('input[name="delivery"]:checked')?.value ?? "",
                      cost: box.querySelector<HTMLInputElement>('input[name="deliveryCost"]')?.value ?? "",
                    });
                  }}
                >
                  <DeliveryField key={`delivery-${deliveryKey}`} defaultDelivery={linkDelivery ?? initial?.delivery} />
                  <ProblemText id="deliveryCost" />
                </div>
              </ExtraRow>

              <ExtraRow
                name="where"
                label="Where to get it"
                icon="map-pin"
                value={where === "instore" ? "In-store only" : "Online"}
                open={openRows.has("where")}
                onToggle={toggleRow}
              >
                <WhereToBuyField where={where} onWhereChange={setWhere} defaultNote={initial?.whereNote} />
              </ExtraRow>

              {/* A whole-store deal isn't any one brand's. */}
              {!wholeStore && (
                <ExtraRow
                  name="brand"
                  label="Made by"
                  icon="badge-check"
                  value={maker ?? brand}
                  filled={!maker && !!brand && brand === linkBrand}
                  open={openRows.has("brand")}
                  onToggle={toggleRow}
                >
                  <Field
                    label="Made by"
                    htmlFor="brand"
                    fill={!maker && brand && brand === linkBrand ? "auto" : undefined}
                    hint={maker ? undefined : "Leave it as No single brand for a mixed bundle or a sale across brands."}
                  >
                    <BrandPicker id="brand" name="brand" value={brand} onChange={setBrand} brands={brands} maker={maker} />
                  </Field>
                </ExtraRow>
              )}


              {kind === "price" && (
                <ExtraRow
                  name="priceIs"
                  label="Price is"
                  icon="pound"
                  value={priceIsNow}
                  filled={extrasFromLink}
                  open={openRows.has("priceIs")}
                  onToggle={toggleRow}
                >
                  <PriceExtrasFields
                    key={`extras-${extrasKey}`}
                    defaultValue={priceExtras}
                    onChange={(v) => {
                      touchedExtras.current.priceFrom = true;
                      setExtrasFromLink(false);
                      setPriceExtras(v);
                    }}
                  />
                </ExtraRow>
              )}

              {/* An upcoming deal: shown in the lists now, as "Starts Fri 8am"
                  with View store, turning into a normal deal at this time. */}
              <ExtraRow
                name="starts"
                label="Starts later"
                icon="clock"
                value={startNow}
                filled={startFromLink}
                open={openRows.has("starts")}
                onToggle={toggleRow}
              >
                <Field
                  label="Starts"
                  htmlFor="startsAt"
                  fill={startFromLink ? "auto" : undefined}
                  hint={startFromLink ? "From the store's page. Add the time if you know it." : "Leave blank if it's on now. UK time."}
                >
                  <input
                    id="startsAt"
                    name="startsAt"
                    type="datetime-local"
                    value={startAt}
                    onChange={(e) => {
                      touchedExtras.current.start = true;
                      setStartFromLink(false);
                      setStartAt(e.target.value);
                    }}
                    min={editing && initial?.startsAt ? undefined : `${today}T00:00`}
                    className={`w-full min-w-0 appearance-none text-left [&::-webkit-date-and-time-value]:text-left ${INPUT}`}
                  />
                </Field>
              </ExtraRow>
              {/* Last: rarely needed, as deals join an event by its words anyway. */}
              {eventChoices.length > 0 && (
                <ExtraRow name="events" label="Part of an event" icon="sparkles" value={eventsNow} open={openRows.has("events")} onToggle={toggleRow}>
                  <div
                    onChange={(e) =>
                      setEventsTicked(
                        Array.from(e.currentTarget.querySelectorAll<HTMLInputElement>('input[name="events"]:checked')).map((i) => i.value)
                      )
                    }
                  >
                    <EventsField choices={eventChoices} defaultValue={initial?.events} />
                  </div>
                </ExtraRow>
              )}
            </div>

            {(last || editing) && (
              <div className="lg:hidden">
                <PhonePreview {...preview} />
              </div>
            )}
          </div>

          <div className="flex flex-col gap-2 border-t border-zinc-100 pt-4 dark:border-zinc-800">
            {editing ? (
              <>
                <div className="flex items-center justify-between gap-3">
                  <Link
                    href={editing.backHref ?? `/deals/${editing.slug}`}
                    className="rounded-full px-3 py-2 text-sm font-medium text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
                  >
                    Cancel
                  </Link>
                  <button type="submit" className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600">
                    Save changes
                  </button>
                </div>
                <p className="text-center text-xs text-zinc-500 dark:text-zinc-400">
                  {editing.helping
                    ? "Changes show straight away, and are logged for the team."
                    : editing.live
                      ? "Changes show straight away. A new link, store or photo goes back to our team to check first."
                      : "Our team will take a look before it goes live."}
                </p>
              </>
            ) : (
              <>
                <div className="flex items-center justify-between gap-3">
                  {step > 0 ? (
                    <button
                      type="button"
                      onClick={() => {
                        if (problem) clearProblem();
                        setStep(step - 1);
                      }}
                      className="flex items-center gap-0.5 rounded-full py-2 pl-2 pr-3 text-sm font-medium text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
                    >
                      <Icon name="chevron-left" className="size-4" />
                      Back
                    </button>
                  ) : (
                    <span />
                  )}
                  {/* Separate keys: reusing one button would turn Next into Post
                      mid-tap, and the tap would post the deal. */}
                  {last ? (
                    <button
                      key="post"
                      type="submit"
                      className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600"
                    >
                      {guest ? "Join free to post" : "Post deal"}
                    </button>
                  ) : (
                    <button
                      key="next"
                      type="button"
                      // Pressing it mustn't take focus from the link box first:
                      // leaving that box starts reading the link, which shows a
                      // line above and moves this button from under the
                      // pointer, so the click was lost. goNext reads it instead.
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={goNext}
                      className="flex items-center gap-1 rounded-full bg-orange-500 py-2.5 pl-5 pr-3.5 text-sm font-semibold text-white hover:bg-orange-600"
                    >
                      {waitingToAdvance && isFetching ? (
                        <>
                          <Icon name="loader" className="size-4 animate-spin" />
                          Reading the link…
                        </>
                      ) : (
                        <>
                          Next
                          <Icon name="chevron-right" className="size-4" />
                        </>
                      )}
                    </button>
                  )}
                </div>
                {last && !guest && botCheckKey && <BotCheck idPrefix="post" siteKey={botCheckKey} />}
                {botWait && (
                  <p role="status" className="text-center text-xs text-amber-700 dark:text-amber-400">
                    One moment: we&apos;re just checking you&apos;re not a robot. Then press Post deal again.
                  </p>
                )}
                {last && (
                  <p className="text-center text-xs text-zinc-500 dark:text-zinc-400">
                    {guest
                      ? "We'll keep everything you've filled in while you join. It takes a few seconds."
                      : goesLiveImmediately === "staff"
                        ? "As staff, your deal goes live on the site straight away."
                        : goesLiveImmediately === "trusted"
                          ? "You've posted plenty of good deals, so yours go live straight away. A store we haven't seen before still gets a quick check."
                          : "Our team takes a quick look before it goes live."}
                  </p>
                )}
              </>
            )}
          </div>
        </form>

        <aside aria-hidden className="hidden lg:sticky lg:top-24 lg:block">
          <PhonePreview {...preview} label="Preview" />
        </aside>
      </div>
    </ProblemContext.Provider>
  );
}
