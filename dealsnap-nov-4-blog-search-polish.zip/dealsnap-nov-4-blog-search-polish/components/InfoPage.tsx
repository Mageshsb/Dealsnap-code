import Link from "next/link";

import Icon from "./Icon";
import { ContentsFolded, ContentsSide } from "./ContentsNav";
import ReadingProgress from "./ReadingProgress";
import { getSiteLinks } from "@/lib/site-pages";

// The shared layout for the footer pages (Terms, Privacy, Guidelines, and any the
// team adds in Admin → Pages: see components/SitePageView.tsx): the title
// across the site's full width, then the text at a comfortable reading width
// with the "On this page" list beside it on the right on computers (the same
// list, place and look as a blog post's "In this post": components/ContentsNav).
// On phones the list is a folded row above the text. The sections sit on one sheet with
// thin rules between them, like a document. Text inside sections is styled
// here (paragraphs, lists, tables, links), so the pages only write words.

export type InfoSection = { id: string; title: string; body: React.ReactNode }; // an empty title = no heading

const prose =
  "flex flex-col gap-3 text-[15px] leading-relaxed text-zinc-600 dark:text-zinc-400 " +
  "[&_strong]:font-semibold [&_strong]:text-zinc-800 dark:[&_strong]:text-zinc-200 " +
  "[&_ul]:flex [&_ul]:list-disc [&_ul]:flex-col [&_ul]:gap-1.5 [&_ul]:pl-5 [&_ol]:flex [&_ol]:list-decimal [&_ol]:flex-col [&_ol]:gap-1.5 [&_ol]:pl-5 " +
  "[&_li]:marker:text-zinc-300 dark:[&_li]:marker:text-zinc-600 " +
  "[&_a]:font-medium [&_a]:text-orange-700 [&_a]:underline-offset-2 hover:[&_a]:underline dark:[&_a]:text-orange-400 " +
  "[&_h3]:pt-2 [&_h3]:font-semibold [&_h3]:text-zinc-900 dark:[&_h3]:text-zinc-100";

export default function InfoPage({
  path,
  title,
  intro,
  updated,
  summary,
  sections,
  numbered = false,
  contents = true,
  children,
}: {
  path?: string; // this page's address, so "Related" leaves it out
  title: string;
  intro?: React.ReactNode;
  updated?: string;
  summary?: React.ReactNode; // "The short version" box at the top
  sections: InfoSection[];
  numbered?: boolean; // "1. Who we are": for the legal pages, so a section can be named
  contents?: boolean; // the "On this page" list and related links; off for a plain how-to page
  children?: React.ReactNode; // anything after the sections
}) {
  const items = sections.filter((s) => s.title).map((s) => ({ id: s.id, text: s.title }));
  const showContents = contents && items.length >= 3;
  const related = getSiteLinks().filter((l) => l.href !== path && l.href !== "/about" && l.href !== "/contact");
  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-6 px-4 py-6">
      <header className="flex max-w-2xl flex-col gap-1">
        <h1 className="text-xl font-bold text-balance sm:text-2xl">{title}</h1>
        {intro && <p className="text-sm text-zinc-500">{intro}</p>}
        {updated && (
          <p className="flex items-center gap-1.5 text-xs text-zinc-500 dark:text-zinc-400">
            <Icon name="calendar" className="size-3.5" />
            Last updated {updated}
          </p>
        )}
      </header>

      <div className={contents ? "flex flex-col gap-6 lg:grid lg:grid-cols-[minmax(0,44rem)_minmax(0,1fr)] lg:items-start lg:gap-12" : "flex flex-col"}>
        <div className="flex min-w-0 max-w-[44rem] flex-col gap-6">
          {summary && (
            <div className="flex flex-col gap-2 rounded-xl border border-orange-200 bg-orange-50 p-5 dark:border-orange-900/60 dark:bg-orange-950/20">
              <h2 className="text-sm font-bold text-zinc-900 dark:text-zinc-100">The short version</h2>
              <div className={prose}>{summary}</div>
            </div>
          )}

          {showContents && <ContentsFolded title="On this page" items={items} />}

          {showContents && <ReadingProgress targetId="page-body" />}
          <article id="page-body" className="rounded-xl border border-zinc-200 bg-white px-5 sm:px-8 dark:border-zinc-800 dark:bg-zinc-900">
            {sections.map((s, i) => (
              <section
                key={s.id || i}
                id={s.id || undefined}
                aria-labelledby={s.title ? `${s.id}-title` : undefined}
                className="flex scroll-mt-24 flex-col gap-3 border-t border-zinc-100 py-6 first:border-t-0 sm:py-7 dark:border-zinc-800"
              >
                {s.title && (
                  <h2 id={`${s.id}-title`} className="flex gap-2 text-base font-bold text-zinc-900 sm:text-lg dark:text-zinc-100">
                    {numbered && <span className="tabular-nums text-orange-700 dark:text-orange-400">{sections.slice(0, i + 1).filter((x) => x.title).length}.</span>}
                    <span className="min-w-0 text-balance">{s.title}</span>
                  </h2>
                )}
                <div className={prose}>{s.body}</div>
              </section>
            ))}
          </article>

          {children}

          {contents && (
            <nav aria-label="Related pages" className="flex flex-col gap-3 border-t border-zinc-200 pt-5 text-sm sm:flex-row sm:items-center sm:justify-between dark:border-zinc-800 print:hidden">
              <p className="text-zinc-500">
                Questions about this page?{" "}
                <Link href="/contact" className="font-medium text-orange-700 underline-offset-2 hover:underline dark:text-orange-400">
                  Contact us
                </Link>
              </p>
              <ul className="flex flex-wrap gap-x-4 gap-y-1">
                {related.map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className="text-zinc-600 hover:text-orange-600 hover:underline dark:text-zinc-400 dark:hover:text-orange-400">
                      {l.full}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          )}
        </div>

        {showContents && (
          <aside className="hidden lg:sticky lg:top-24 lg:block">
            <ContentsSide title="On this page" items={items} numbered={numbered} />
          </aside>
        )}
      </div>
    </main>
  );
}

// A two-column table that turns into stacked rows on phones, so nothing
// scrolls sideways at 360px.
export function InfoTable({ head, rows }: { head: [string, string] | [string, string, string]; rows: React.ReactNode[][] }) {
  const cols = head.length === 3 ? "sm:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)_minmax(0,0.8fr)]" : "sm:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)]";
  return (
    <div className="overflow-hidden rounded-lg border border-zinc-200 dark:border-zinc-800">
      <div className={`hidden bg-zinc-50 px-3 py-2 text-xs font-semibold text-zinc-500 sm:grid sm:gap-4 dark:bg-zinc-800/60 ${cols}`}>
        {head.map((h) => (
          <span key={h}>{h}</span>
        ))}
      </div>
      <ul className="!list-none divide-y divide-zinc-100 !gap-0 !pl-0 dark:divide-zinc-800">
        {rows.map((r, i) => (
          <li key={i} className={`grid gap-1 px-3 py-2.5 sm:gap-4 ${cols}`}>
            {r.map((cell, j) => (
              <div key={j} className={j === 0 ? "font-medium text-zinc-800 dark:text-zinc-200" : ""}>
                <span className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 sm:hidden">{j > 0 ? `${head[j]}: ` : ""}</span>
                {cell}
              </div>
            ))}
          </li>
        ))}
      </ul>
    </div>
  );
}
