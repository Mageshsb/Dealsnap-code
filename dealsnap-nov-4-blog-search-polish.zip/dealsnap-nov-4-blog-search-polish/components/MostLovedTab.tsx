"use client";

import { useState } from "react";
import { createPortal } from "react-dom";
import Link from "next/link";
import { LOVED_WINDOWS, type LovedWindow } from "@/lib/deal-views";
import { HeartIcon } from "./Icon";
import { useAnchoredMenu } from "./useAnchoredMenu";

// The Most loved chip: "Most loved | 7 days ⌄" (with a heart). The ⌄ always opens the
// period menu (Last 24 hours / 7 days / 30 days / 12 months), so it never looks
// like a dropdown that doesn't open. While New is picked the chip is split:
// "Most loved" switches back (keeping the period last chosen, which rides
// along in ?when= while on New) and "7 days ⌄" opens the menu, where picking
// a period switches to Most loved too. Once on Most loved the whole chip opens
// the menu. It always shows the period and is as wide as its longest option,
// so New never moves. The menu is the chip's own width and colours, so it
// reads as the chip opening out, and says "Deals posted…": the period is when
// a deal was posted, not when its hearts came in.
export default function MostLovedTab({
  href,
  active,
  current,
  hrefs,
  sizeClass,
  pad,
  padStart,
  padEnd,
}: {
  href: string; // Most loved with the current period
  active: boolean;
  current: LovedWindow;
  hrefs: Record<LovedWindow, string>;
  sizeClass: string; // the chips' height and text size
  pad: string; // side padding, matching the other chips
  padStart: string; // ...and each side on its own, for the split chip
  padEnd: string;
}) {
  const { open, toggle: toggleMenu, close, anchorRef, host, menuProps } = useAnchoredMenu<HTMLDivElement>("left");
  const [width, setWidth] = useState<number>();
  const label = LOVED_WINDOWS.find((w) => w.value === current)?.label ?? "Last 7 days";

  const shape = `flex shrink-0 items-center whitespace-nowrap rounded-full font-medium transition-colors ${sizeClass}`;
  const divider = <span aria-hidden className="h-3.5 w-px shrink-0 bg-current opacity-25" />;
  const period = (
    <span className={`flex items-center gap-1 ${active ? "opacity-80" : ""}`}>
      {/* Every option stacked in one cell, only the current one visible, so
          the chip is always as wide as the longest. Short wording here ("7 days",
          not "Last 7 days"): a 360px phone's row has no spare room, and the menu
          spells each period out. */}
      <span className="grid justify-items-center">
        {LOVED_WINDOWS.map((w) => (
          <span
            key={w.value}
            aria-hidden={w.value !== current}
            className={`col-start-1 row-start-1 ${w.value === current ? "" : "invisible"}`}
          >
            {w.short}
          </span>
        ))}
      </span>
      <svg
        aria-hidden
        viewBox="0 0 12 12"
        className={`h-3 w-3 opacity-75 transition-transform ${open ? "rotate-180" : ""}`}
        fill="none"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M3 4.5 6 7.5 9 4.5" />
      </svg>
    </span>
  );
  const toggle = {
    type: "button" as const,
    onClick: () => {
      setWidth(anchorRef.current?.offsetWidth);
      toggleMenu();
    },
    "aria-haspopup": true,
    "aria-expanded": open,
  };

  return (
    <div ref={anchorRef} className="relative shrink-0">
      {active ? (
        <button
          {...toggle}
          aria-current="true"
          aria-label={`Most loved, deals posted: ${label}`}
          className={`${shape} ${pad} gap-2 bg-zinc-900 text-white hover:bg-zinc-700 dark:bg-zinc-100 dark:text-zinc-900 dark:hover:bg-zinc-300 ${
            open ? "bg-zinc-700 dark:bg-zinc-300" : ""
          }`}
        >
          <span className="flex items-center gap-1">
            <HeartIcon className="size-[1em]" />
            Most loved
          </span>
          {divider}
          {period}
        </button>
      ) : (
        // Each half lights up on its own, so it's clear they do different things.
        <div className="flex shrink-0 items-center rounded-full bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">
          <Link
            href={href}
            scroll={false}
            className={`${shape} ${padStart} gap-1 pe-2 hover:bg-zinc-200 dark:hover:bg-zinc-700`}
          >
            <HeartIcon className="size-[1em]" />
            Most loved
          </Link>
          {divider}
          <button
            {...toggle}
            aria-label={`Most loved, deals posted: ${label}. Change`}
            className={`${shape} ${padEnd} ps-2 hover:bg-zinc-200 dark:hover:bg-zinc-700 ${open ? "bg-zinc-200 dark:bg-zinc-700" : ""}`}
          >
            {period}
          </button>
        </div>
      )}

      {open &&
        host &&
        createPortal(
          <div
            {...menuProps}
            style={{ ...menuProps.style, width }}
            className={`${menuProps.className} rounded-2xl bg-zinc-900 p-1 text-white shadow-lg dark:bg-zinc-100 dark:text-zinc-900`}
          >
            <p className="px-3 pb-1 pt-1.5 text-xs font-medium opacity-60">Deals posted…</p>
            {LOVED_WINDOWS.map((w) => {
              const selected = w.value === current;
              return (
                <Link
                  key={w.value}
                  href={hrefs[w.value]}
                  scroll={false}
                  onClick={close}
                  aria-current={selected ? "true" : undefined}
                  className={`flex min-h-10 items-center justify-between gap-2 rounded-xl px-3 text-sm ${
                    selected
                      ? "bg-white/15 font-semibold dark:bg-black/10"
                      : "opacity-80 hover:bg-white/10 hover:opacity-100 dark:hover:bg-black/5"
                  }`}
                >
                  {w.label}
                  {selected && (
                    <svg
                      aria-hidden
                      viewBox="0 0 16 16"
                      className="h-4 w-4 text-orange-400 dark:text-orange-600"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="m3.5 8.5 3 3 6-7" />
                    </svg>
                  )}
                </Link>
              );
            })}
          </div>,
          host,
        )}
    </div>
  );
}
