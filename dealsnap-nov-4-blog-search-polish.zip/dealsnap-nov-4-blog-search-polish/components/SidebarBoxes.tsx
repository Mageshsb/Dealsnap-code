"use client";

import { useSearchParams } from "next/navigation";
import { countNarrow, parseMinHearts, type Facet } from "@/lib/deal-filters";
import { FilterIcon } from "./icons";
import FilterBox from "./FilterBox";
import AdUnit from "./AdUnit";

// The sidebar beside the deal lists on laptops (lg+): the Filters box, which
// narrows the list on this page, always open and sticking under the header as
// the list scrolls. Phones and tablets don't show it: their Filters is the
// pill beside Most loved/New (a sheet, see SwipeFilters). When there's an ad
// for this space (Admin → Ads), it sits just under Filters and sticks with it.
// (An Explore box of popular topics, stores and brands used to sit under
// Filters; it was removed on 2 November 2026 to keep the page simple, as the
// category strip, the menu and the Stores, Categories and Brands pages cover it.)
export default function SidebarBoxes({ facets }: { facets?: Facet[] }) {
  const params = useSearchParams();
  // How many filters are on: hearts cut, deal type, store/category dropdowns. (Show
  // expired and Hide in-store are settings kept on this device, so not counted.)
  const activeCount = (parseMinHearts(params.get("hearts")) > 0 ? 1 : 0) + countNarrow(params);

  return (
    <aside className="flex h-fit flex-col gap-4 lg:sticky lg:top-[calc(var(--list-sticky-top,4rem)+1rem)] lg:transition-[top] lg:duration-200">
      <div className="flex flex-col gap-4 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
        <h2 className="flex items-center gap-2 font-semibold">
          <FilterIcon className="h-4 w-4" />
          Filters
          {activeCount > 0 && <CountBadge count={activeCount} />}
        </h2>
        <FilterBox facets={facets} />
      </div>
      <AdUnit slot="sidebar" />
    </aside>
  );
}

// The orange "N filters on" count, same look as the Scroll view's Filters button.
export function CountBadge({ count }: { count: number }) {
  return (
    <span
      aria-label={`${count} filter${count === 1 ? "" : "s"} on`}
      className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-orange-500 px-1 text-xs font-semibold leading-none text-white"
    >
      {count}
    </span>
  );
}
