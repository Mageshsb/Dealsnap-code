import Link from "next/link";
import Icon from "./Icon";
import type { PromoCardData } from "@/lib/promos";

export type PromoLook = Pick<
  PromoCardData,
  "variant" | "kicker" | "headline" | "body" | "benefits" | "ctaLabel" | "linkUrl" | "icon" | "imageUrl" | "showTag"
>;

// The tile in a promo card's picture slot: the cover picture, or (with none) a
// tinted block with an icon, the way a deal with no photo gets its tile. Its
// size is set by whatever holds it, so a late-loading picture moves nothing.
export function PromoPicture({ promo, iconSize }: { promo: Pick<PromoLook, "icon" | "imageUrl" | "variant">; iconSize: string }) {
  if (promo.imageUrl) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={promo.imageUrl} alt="" loading="lazy" decoding="async" className="absolute inset-0 size-full object-cover" />;
  }
  return (
    <span className="absolute inset-0 flex items-center justify-center text-orange-700 dark:text-orange-400">
      <Icon name={promo.icon ?? (promo.variant === "signup" ? "party" : "tag")} className={iconSize} />
    </span>
  );
}

// The "Promoted" tag with its megaphone: the staff's choice, on for anything
// paid or from a partner.
export function PromotedTag() {
  return (
    <span className="flex items-center gap-1 text-xs font-medium text-zinc-500 dark:text-zinc-400">
      <Icon name="megaphone" className="size-3.5" />
      Promoted
    </span>
  );
}

// The button, drawn as a plain look inside a card that is itself the link, or
// as a real link (for a sign-up tile, whose card holds two links).
export const CTA_LOOK =
  "shrink-0 rounded-full bg-orange-500 px-3.5 py-1.5 text-sm font-semibold text-white hover:bg-orange-600";

// A promo card or sign-up tile inside a deal list (Admin → Promos). It has the
// footprint of a deal card, whatever is filled in: the picture slot is always
// there (an icon tile when there's no picture), the height is fixed, and every
// line of text is cut off at a set length. So it never shifts what's around it,
// before or after a picture loads, and Back lands where it should. A promo is
// one tap target, the whole card. A sign-up tile has its own button and a Log
// in link. `preview` is the admin's look at it, with nothing to click.
export default function PromoCard({ promo, preview = false }: { promo: PromoLook; preview?: boolean }) {
  const { variant, kicker, headline, body, benefits, ctaLabel, linkUrl, showTag } = promo;
  const signup = variant === "signup";
  const className =
    "group flex h-[12rem] overflow-hidden rounded-xl border border-orange-300 bg-orange-50 shadow-sm dark:border-orange-900/60 dark:bg-orange-950/20";
  const inner = (
    <>
      <div className="relative w-28 shrink-0 self-stretch bg-orange-100 sm:w-32 md:w-40 dark:bg-orange-950/50">
        <PromoPicture promo={promo} iconSize="size-10" />
      </div>
      <div className="flex min-w-0 flex-1 flex-col gap-1 p-3">
        {showTag && <PromotedTag />}
        {kicker && <span className="truncate text-xs font-medium text-zinc-500 dark:text-zinc-400">{kicker}</span>}
        <span className="line-clamp-2 font-semibold leading-snug">{headline}</span>
        {signup ? (
          <ul className="flex flex-col gap-0.5">
            {benefits.slice(0, 3).map((b, i) => (
              <li key={i} className="flex items-start gap-1.5 text-sm leading-snug text-zinc-700 dark:text-zinc-300">
                <Icon name="check" className="mt-0.5 size-3.5 shrink-0 text-orange-700 dark:text-orange-400" />
                <span className="line-clamp-1">{b}</span>
              </li>
            ))}
          </ul>
        ) : (
          body && <span className="line-clamp-2 text-sm leading-snug text-zinc-600 dark:text-zinc-400">{body}</span>
        )}
        <span className="mt-auto flex items-center justify-end gap-3 pt-1">
          {signup && !preview && (
            <Link href="/login" className="text-sm font-medium text-zinc-600 hover:underline dark:text-zinc-400">
              Log in
            </Link>
          )}
          {signup && preview && <span className="text-sm font-medium text-zinc-600 dark:text-zinc-400">Log in</span>}
          {signup && !preview ? (
            <Link href={linkUrl} className={CTA_LOOK}>
              {ctaLabel}
            </Link>
          ) : (
            <span className={CTA_LOOK}>{ctaLabel}</span>
          )}
        </span>
      </div>
    </>
  );

  if (preview || signup) return <div className={className}>{inner}</div>;
  if (linkUrl.startsWith("/")) {
    return (
      <Link href={linkUrl} className={className}>
        {inner}
      </Link>
    );
  }
  // Somebody else's page: say so to search engines, and keep our tab open.
  return (
    <a href={linkUrl} target="_blank" rel="sponsored noopener nofollow" className={className}>
      {inner}
    </a>
  );
}
