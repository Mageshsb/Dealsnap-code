"use client";

import Icon, { type IconName } from "./Icon";
import MenuSelect from "./MenuSelect";
import { CountBadge } from "./SidebarBoxes";

// The filter and sort controls the Stores and Brands lists share, so the two
// look and work the same. Every screen size shows the same white outlined
// pills (icon, name, chevron). Wide screens open them as dropdowns beside
// the search box. Phones and tablets show them two to a row, each opening its
// options as a sheet over the page (BottomSheet). Nothing ever opens between
// the pills and the tiles, so they don't jump and Back lands where you were.

export type CategoryOption = { value: string; label: string; icon: IconName };

// The soft orange "Clear all filters" look from the deal filters.
export const CLEAR_BUTTON =
  "flex h-8 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border border-orange-200 bg-orange-50 px-3 text-sm font-semibold text-orange-700 transition-colors hover:bg-orange-100 dark:border-orange-900/60 dark:bg-orange-950/40 dark:text-orange-400 dark:hover:bg-orange-950/70";

// The button right after the search box on all three browse pages: hides the
// tiles with nothing live on them (kept in the address as ?live=1). It stays
// beside the search on phones too, as just its icon, since the filters move
// into their own bar there.
export function EmptyToggle({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-pressed={on}
      aria-label="Hide empty"
      title="Hide the ones with nothing live right now"
      className={`flex h-[38px] shrink-0 items-center justify-center gap-1.5 rounded-full border text-sm font-medium outline-none transition-colors focus-visible:border-orange-500 max-sm:w-[38px] sm:px-3.5 ${
        on
          ? "border-orange-500 bg-orange-50 text-orange-700 dark:bg-orange-950/30 dark:text-orange-300"
          : "border-zinc-300 bg-white text-zinc-700 hover:border-orange-300 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200"
      }`}
    >
      <Icon name="eye-off" className="size-4 shrink-0" />
      <span className="max-sm:hidden">Hide empty</span>
    </button>
  );
}

// Wide screens: the category menu as a pill beside the search box.
export function CategoryMenu({ value, onChange, options }: { value: string; onChange: (value: string) => void; options: CategoryOption[] }) {
  return (
    <MenuSelect
      value={value}
      onChange={onChange}
      label="Category"
      options={options}
      className="w-56 min-w-0 shrink-0"
      leading={<Icon name="grid" className="size-4 shrink-0" />}
      buttonClassName={`flex h-[38px] w-full min-w-0 items-center gap-2 rounded-full border pl-4 pr-3.5 text-sm font-medium outline-none focus-visible:border-orange-500 ${
        value
          ? "border-orange-500 bg-orange-50 text-orange-700 dark:bg-orange-950/30 dark:text-orange-300"
          : "border-zinc-300 bg-white text-zinc-700 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200"
      }`}
    />
  );
}

// Phones and tablets: the filter pills, two to a row on phones (a page with
// one, Brands, keeps it in the left half, where it sits on Stores) and the
// wide screens' pill width from tablets up.
export function FilterBar({ halves }: { halves: React.ReactNode }) {
  return <div className="grid grid-cols-2 gap-2 sm:flex lg:hidden">{halves}</div>;
}

// One filter pill on a phone, opening its sheet: the same pill as the wide
// screens' dropdowns, orange while its filter is on.
export function FilterHalf({
  icon,
  label,
  count = 0,
  active = false,
  onOpen,
}: {
  icon: IconName;
  label: string;
  count?: number;
  active?: boolean;
  onOpen: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onOpen}
      aria-haspopup="dialog"
      className={`flex h-[38px] min-w-0 items-center gap-2 rounded-full border pl-4 pr-3.5 text-sm font-medium outline-none transition-colors focus-visible:border-orange-500 sm:w-56 ${
        active || count > 0
          ? "border-orange-500 bg-orange-50 text-orange-700 dark:bg-orange-950/30 dark:text-orange-300"
          : "border-zinc-300 bg-white text-zinc-700 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200"
      }`}
    >
      <Icon name={icon} className="size-4 shrink-0" />
      <span className="min-w-0 flex-1 truncate text-left">{label}</span>
      {count > 0 && <CountBadge count={count} />}
      <Icon name="chevron-down" className="size-4 shrink-0 text-zinc-500" />
    </button>
  );
}

// The category list in the phone bar's sheet, its rows running edge to edge.
export function CategoryPanel({ value, options, onPick }: { value: string; options: CategoryOption[]; onPick: (value: string) => void }) {
  return (
    <div className="-mx-4 flex flex-col sm:-mx-6">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onPick(o.value)}
          aria-pressed={o.value === value}
          className={`flex w-full items-center gap-3 px-4 py-3 text-left text-sm sm:px-6 ${
            o.value === value ? "bg-orange-50 font-semibold text-orange-700 dark:bg-orange-950/30 dark:text-orange-300" : "text-zinc-800 hover:bg-zinc-50 dark:text-zinc-100 dark:hover:bg-zinc-800/60"
          }`}
        >
          <Icon name={o.icon} className="size-4 shrink-0 text-zinc-500 dark:text-zinc-400" />
          <span className="min-w-0 flex-1 truncate">{o.label}</span>
          {o.value === value && <Icon name="check" className="size-4 shrink-0" />}
        </button>
      ))}
    </div>
  );
}

// The sort: the site's grey tile (see SortSelect), set apart from the white
// outlined filters.
export function SortMenu({ value, onChange, options }: { value: string; onChange: (value: string) => void; options: { value: string; label: string }[] }) {
  return (
    <MenuSelect
      value={value}
      onChange={onChange}
      label="Sort by"
      align="right"
      options={options}
      className="ml-auto shrink-0"
      leading={<Icon name="arrow-up-down" className="size-3.5 shrink-0 text-zinc-500 dark:text-zinc-400" />}
      chevronClassName="size-3.5 text-zinc-500 dark:text-zinc-400"
      buttonClassName="flex min-h-9 items-center gap-1.5 rounded-xl bg-zinc-100 px-3 text-sm font-medium text-zinc-600 outline-none transition-colors hover:bg-zinc-200 focus-visible:ring-2 focus-visible:ring-orange-500 aria-expanded:bg-zinc-200 aria-expanded:text-zinc-900 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700 dark:aria-expanded:bg-zinc-700 dark:aria-expanded:text-zinc-100"
    />
  );
}
