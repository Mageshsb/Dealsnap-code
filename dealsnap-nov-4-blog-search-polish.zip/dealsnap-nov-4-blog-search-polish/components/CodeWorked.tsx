"use client";

import Link from "next/link";
import { useState, useTransition } from "react";
import { setCodeWorkedAction } from "@/lib/member-actions";
import { codeLooksBroken } from "@/lib/code-trust";
import type { CodeVerdict } from "@/lib/db";
import Icon from "./Icon";
import { timeAgo } from "@/lib/format";

// Under a deal's discount code: what members say about it ("Worked for 4
// people · last 2 hours ago", or a warning when recent answers say no) and
// "Did it work? Yes / No". One answer each, changeable, and tapping your
// answer again takes it back (like a heart). Guests are asked to
// log in; the poster only sees what others said.
export default function CodeWorked({
  slug,
  initial,
  lastWorked,
  mine: initialMine,
  canAnswer,
  signedIn,
  checkedAt,
  code,
}: {
  slug: string;
  initial: CodeVerdict;
  // "2 hours ago", worked out on the server so the page and browser agree.
  lastWorked?: string;
  mine?: boolean;
  canAnswer: boolean;
  signedIn: boolean;
  // When a helper or the team last checked the deal: settles earlier "no"s.
  checkedAt?: string;
  // The code itself, so the line says which code it's about.
  code: string;
}) {
  const [verdict, setVerdict] = useState(initial);
  const [mine, setMine] = useState(initialMine);
  const [last, setLast] = useState(lastWorked);
  const [pending, start] = useTransition();

  function answer(worked: boolean) {
    // The same answer again takes it back.
    const next = mine === worked ? undefined : worked;
    const before = { verdict, mine, last };
    setMine(next);
    if (next) setLast("just now");
    start(async () => {
      const res = await setCodeWorkedAction(slug, next ?? null);
      if (res.ok) {
        setVerdict(res.verdict);
        setLast(res.verdict.lastWorkedAt ? timeAgo(res.verdict.lastWorkedAt) : undefined);
      } else {
        setMine(before.mine);
        setLast(before.last);
      }
    });
  }

  const broken = codeLooksBroken(verdict, checkedAt);
  const choice = (worked: boolean) =>
    `inline-flex min-h-8 items-center gap-1 rounded-full border px-3 text-xs font-semibold transition-colors disabled:opacity-60 ${
      mine === worked
        ? worked
          ? "border-green-500 bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-300"
          : "border-red-400 bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-300"
        : "border-zinc-300 text-zinc-600 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
    }`;

  return (
    <div className="flex flex-col gap-1.5 text-xs sm:items-end sm:text-sm">
      {broken && (
        <p className="flex items-start gap-1.5 text-amber-700 dark:text-amber-400">
          <Icon name="warning" className="mt-0.5 size-4 shrink-0" />
          Recent reports say the code {code} may not work.
        </p>
      )}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 sm:justify-end">
        <span className="text-zinc-500">
          {verdict.worked > 0 ? (
            <>
              <Icon name="circle-check" className="mr-1 text-green-700 dark:text-green-400" />
              <span className="font-mono">{code}</span> worked for {verdict.worked} {verdict.worked === 1 ? "person" : "people"}
              {last && ` · ${last}`}
            </>
          ) : (
            canAnswer ? <>Did the code {code} work?</> : <>Nobody has said yet whether the code {code} works.</>
          )}
        </span>
        {canAnswer ? (
          <span className="flex items-center gap-1.5">
            {verdict.worked > 0 && <span className="text-zinc-500">Did it work?</span>}
            <button type="button" onClick={() => answer(true)} disabled={pending} aria-pressed={mine === true} title={mine === true ? "Tap again to take it back" : undefined} className={choice(true)}>
              <Icon name="thumbs-up" className="size-3.5" />
              Yes
            </button>
            <button type="button" onClick={() => answer(false)} disabled={pending} aria-pressed={mine === false} title={mine === false ? "Tap again to take it back" : undefined} className={choice(false)}>
              <Icon name="x" className="size-3.5" />
              No
            </button>
          </span>
        ) : (
          !signedIn && (
            <Link href={`/login?next=${encodeURIComponent(`/deals/${slug}`)}`} className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
              Log in to say if it worked
            </Link>
          )
        )}
      </div>
    </div>
  );
}
