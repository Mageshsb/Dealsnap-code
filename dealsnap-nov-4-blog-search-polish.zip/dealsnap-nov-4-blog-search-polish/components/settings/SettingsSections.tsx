import Link from "next/link";
import { emailDeliveryReady, mustConfirmEmail } from "@/lib/email";
import ResendConfirmButton from "@/components/ResendConfirmButton";
import {
  USERNAME_CHANGE_COOLDOWN_DAYS,
  nextUsernameChangeAt,
  getBlockedUsers,
  getEmailFrequency,
  type UserRecord,
} from "@/lib/db";
import { changeEmailAction, changePasswordAction } from "@/lib/actions";
import { saveNotificationPrefsAction, unblockUserAction } from "@/lib/member-actions";
import { getNotificationPrefs } from "@/lib/notifications";
import PushToggle from "@/components/PushToggle";
import { pushPublicKey } from "@/lib/push";
import { NOTIFICATION_KINDS, NOTIFICATION_KIND_KEYS } from "@/lib/notification-kinds";
import UserAvatar from "@/components/UserAvatar";
import TwoStepPanel from "@/components/TwoStepPanel";
import { USERNAME_MAX, USERNAME_MIN, USERNAME_PATTERN, USERNAME_RULE } from "@/lib/username";
import SelectField from "@/components/SelectField";
import Icon, { type IconName } from "@/components/Icon";
import { RowIcon } from "@/components/AccountSection";
import ProfileForm from "./ProfileForm";
import { formatDate } from "@/lib/format";
import EmptyState from "@/components/EmptyState";

const field =
  "rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950";
const primary =
  "self-start rounded-full bg-orange-500 px-4 py-1.5 text-sm font-semibold text-white hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-50";
const hint = "text-xs text-zinc-500";
const outline =
  "shrink-0 items-center rounded-full border border-zinc-300 px-3.5 py-1.5 text-sm font-semibold text-zinc-700 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800";

export function ProfileSection({ user }: { user: UserRecord }) {
  const cooldownUntil = nextUsernameChangeAt(user.usernameChangedAt);
  return (
    <ProfileForm
      username={user.username}
      bio={user.bio}
      avatarUrl={user.avatarUrl}
      usernameLocked={!!cooldownUntil}
      usernameHint={
        cooldownUntil
          ? `You can change it again on ${formatDate(cooldownUntil)} (once every ${USERNAME_CHANGE_COOLDOWN_DAYS} days).`
          : `Up to ${USERNAME_MAX} characters: letters, numbers, _ and -. You can change it once every ${USERNAME_CHANGE_COOLDOWN_DAYS} days.`
      }
      pattern={USERNAME_PATTERN}
      minLength={USERNAME_MIN}
      maxLength={USERNAME_MAX}
      rule={USERNAME_RULE}
    />
  );
}

// One line of Sign-in & security: what it is, what it's set to now, and a
// Change button that opens its form underneath (no form showing until then).
export function SettingRow({
  icon,
  label,
  value,
  action = "Change",
  open = false,
  children,
}: {
  icon: IconName;
  label: string;
  value: React.ReactNode;
  action?: string;
  open?: boolean;
  children: React.ReactNode;
}) {
  return (
    <details open={open} className="group py-4 first:pt-0 last:pb-0">
      <summary className="flex cursor-pointer list-none items-center gap-3 [&::-webkit-details-marker]:hidden">
        <RowIcon icon={icon} />
        <span className="flex min-w-0 flex-1 flex-col">
          <span className="text-sm font-semibold">{label}</span>
          <span className="truncate text-sm text-zinc-500">{value}</span>
        </span>
        <span className={`${outline} inline-flex group-open:hidden`}>{action}</span>
        <span className={`${outline} hidden group-open:inline-flex`}>Cancel</span>
      </summary>
      <div className="pt-4 sm:pl-[52px]">{children}</div>
    </details>
  );
}

// Email, password and two-step login: everything about getting into your account.
export function SecuritySection({ user, openRow, error }: { user: UserRecord; openRow?: string; error?: string }) {
  // What went wrong with the email or password form, shown inside that form.
  const problem = (row: string) =>
    error && openRow === row ? (
      <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
        {error}
      </p>
    ) : null;
  return (
    <div className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
      <SettingRow
        icon="mail"
        label="Email"
        open={openRow === "email"}
        value={
          <>
            {user.email}
            {mustConfirmEmail(user) && <span className="text-amber-700 dark:text-amber-400"> · not confirmed yet</span>}
          </>
        }
      >
        <div className="flex flex-col gap-3">
          {mustConfirmEmail(user) && (
            <p className={hint}>
              Not confirmed yet. <ResendConfirmButton />
            </p>
          )}
          <form action={changeEmailAction} className="flex flex-col gap-2 sm:max-w-xs">
            {problem("email")}
            <input name="email" type="email" placeholder="New email address" autoComplete="email" required className={field} />
            <input name="currentPassword" type="password" placeholder="Your password" autoComplete="current-password" required className={field} />
            <button type="submit" className={primary}>
              Change email
            </button>
          </form>
        </div>
      </SettingRow>

      <SettingRow icon="key" label="Password" value="••••••••" open={openRow === "password"}>
        <form action={changePasswordAction} className="flex flex-col gap-2 sm:max-w-xs">
          {problem("password")}
          <input name="currentPassword" type="password" placeholder="Current password" autoComplete="current-password" required className={field} />
          <input name="newPassword" type="password" placeholder="New password (8+ characters)" autoComplete="new-password" required minLength={8} className={field} />
          <input name="confirmPassword" type="password" placeholder="Confirm new password" autoComplete="new-password" required minLength={8} className={field} />
          <button type="submit" className={primary}>
            Change password
          </button>
        </form>
      </SettingRow>

      <TwoStepPanel user={user} open={openRow === "two-step"} />
    </div>
  );
}

// An on/off switch that is a real checkbox underneath, so it posts with the
// form and works with a keyboard and screen readers.
function Switch({ name, defaultChecked, label }: { name: string; defaultChecked: boolean; label: string }) {
  return (
    <label className="relative inline-flex cursor-pointer items-center p-1">
      <input type="checkbox" name={name} defaultChecked={defaultChecked} aria-label={label} className="peer sr-only" />
      <span className="h-6 w-10 rounded-full bg-zinc-300 transition-colors peer-checked:bg-orange-500 peer-focus-visible:ring-2 peer-focus-visible:ring-orange-500 peer-focus-visible:ring-offset-2 dark:bg-zinc-700 dark:peer-focus-visible:ring-offset-zinc-900" />
      <span className="pointer-events-none absolute left-1.5 size-5 rounded-full bg-white shadow transition-transform peer-checked:translate-x-4" />
    </label>
  );
}

export function NotificationsSection({ user }: { user: UserRecord }) {
  const prefs = getNotificationPrefs(user.id);
  const frequency = getEmailFrequency(user.id);
  return (
    <div className="flex flex-col gap-4">
    <PushToggle publicKey={pushPublicKey()} />
    <form action={saveNotificationPrefsAction} className="flex flex-col gap-4">
      <p className={hint}>
        Choose what appears in your notifications (and on your phone, if that&apos;s on).{" "}
        {emailDeliveryReady()
          ? "You can also have each one emailed to you."
          : "Email is coming soon: your email choices are saved now and will start working when it arrives."}
      </p>
      <div className="overflow-hidden rounded-xl border border-zinc-200 dark:border-zinc-800">
        <div className="flex items-center gap-2 border-b border-zinc-200 bg-zinc-50 px-3 py-2 text-xs font-semibold uppercase tracking-wide text-zinc-500 sm:gap-3 dark:border-zinc-800 dark:bg-zinc-800/50">
          <span className="flex-1">Tell me about</span>
          <span className="w-12 text-center">Site</span>
          <span className="w-12 text-center">Email</span>
        </div>
        {NOTIFICATION_KIND_KEYS.map((kind) => {
          const k = NOTIFICATION_KINDS[kind];
          return (
            <div key={kind} className="flex items-center gap-2 border-b border-zinc-100 px-3 py-3 last:border-b-0 sm:gap-3 dark:border-zinc-800">
              <span className="flex min-w-0 flex-1 flex-col">
                <span className="flex items-center gap-2 text-sm font-medium">
                  <Icon name={k.icon} className="hidden size-4 shrink-0 text-zinc-500 dark:text-zinc-400 sm:block" />
                  {k.label}
                </span>
                <span className="text-xs text-zinc-500">{k.hint}</span>
              </span>
              <span className="flex w-12 justify-center">
                <Switch name={`site:${kind}`} defaultChecked={prefs[kind].onSite} label={`${k.label} on the site`} />
              </span>
              <span className="flex w-12 justify-center">
                <Switch name={`email:${kind}`} defaultChecked={prefs[kind].byEmail} label={`${k.label} by email`} />
              </span>
            </div>
          );
        })}
      </div>
      <div className="flex flex-wrap items-center gap-2 text-sm">
        <span>Send emails</span>
        <SelectField
          look="tile"
          name="emailFrequency"
          label="Send emails"
          defaultValue={frequency}
          options={[
            { value: "instant", label: "as things happen" },
            { value: "daily", label: "as one summary each morning" },
          ]}
        />
      </div>
      <button type="submit" className={primary}>
        Save notification settings
      </button>
    </form>
    </div>
  );
}

export function BlockedSection({ user }: { user: UserRecord }) {
  const blocked = getBlockedUsers(user.id);
  return (
    <div className="flex flex-col gap-3">
      <p className={hint}>
        You won&apos;t see their deals or comments, they can&apos;t follow you, and you won&apos;t be notified about anything they do.
        To block someone, use the ••• menu on their profile.
      </p>
      {blocked.length === 0 ? (
        <EmptyState icon="ban">
          <p>You haven&apos;t blocked anyone.</p>
        </EmptyState>
      ) : (
        <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
          {blocked.map((b) => (
            <li key={b.id} className="flex items-center justify-between gap-3 py-3">
              <Link href={`/u/${b.username}`} className="flex min-w-0 items-center gap-3 font-medium hover:text-orange-600">
                <UserAvatar username={b.username} avatarUrl={b.avatarUrl} size="h-10 w-10" />
                <span className="truncate">{b.username}</span>
              </Link>
              <form action={unblockUserAction.bind(null, b.id)}>
                <input type="hidden" name="back" value="/settings?s=blocked" />
                <button
                  type="submit"
                  className="rounded-full border border-zinc-300 px-3 py-1 text-xs font-semibold text-zinc-600 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
                >
                  Unblock
                </button>
              </form>
            </li>
          ))}
        </ul>
        )}
    </div>
  );
}
