"use client";

import { useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { removeAvatarAction, updateProfileAction } from "@/lib/actions";
import UserAvatar from "@/components/UserAvatar";
import Icon from "@/components/Icon";

const field =
  "w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950";
const label = "text-sm font-medium text-zinc-700 dark:text-zinc-300";
const MAX_BYTES = 2 * 1024 * 1024;
const BIO_MAX = 280;

function SaveButton({ changed }: { changed: boolean }) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={!changed || pending}
      className="self-start rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600 disabled:cursor-not-allowed disabled:bg-zinc-200 disabled:text-zinc-500 dark:disabled:bg-zinc-800 dark:disabled:text-zinc-500"
    >
      {pending ? "Saving…" : "Save changes"}
    </button>
  );
}

// Settings → Name, photo & bio. Tap the photo to pick a new one (it shows
// straight away), and one Save for everything, lit only once something has
// changed. The server checks it all again (updateProfileAction).
export default function ProfileForm({
  username,
  bio,
  avatarUrl,
  usernameHint,
  usernameLocked,
  pattern,
  minLength,
  maxLength,
  rule,
}: {
  username: string;
  bio: string;
  avatarUrl: string | null;
  usernameHint: string;
  usernameLocked: boolean;
  pattern: string;
  minLength: number;
  maxLength: number;
  rule: string;
}) {
  const [preview, setPreview] = useState<string | null>(null);
  const [photoError, setPhotoError] = useState("");
  const [name, setName] = useState(username);
  const [about, setAbout] = useState(bio);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => () => {
    if (preview) URL.revokeObjectURL(preview);
  }, [preview]);

  function pickPhoto(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    setPhotoError("");
    if (!file) return setPreview(null);
    if (file.size > MAX_BYTES) {
      e.target.value = "";
      setPreview(null);
      setPhotoError("That photo is over 2MB. Please pick a smaller one.");
      return;
    }
    setPreview(URL.createObjectURL(file));
  }

  const changed = !!preview || name.trim() !== username || about.trim() !== bio.trim();

  return (
    <form action={updateProfileAction} className="flex flex-col gap-5">
      <div className="flex items-center gap-4">
        <label className="group relative shrink-0 cursor-pointer rounded-full focus-within:ring-2 focus-within:ring-orange-500 focus-within:ring-offset-2 dark:focus-within:ring-offset-zinc-900">
          <span className="sr-only">Change your photo</span>
          {preview ? (
            // eslint-disable-next-line @next/next/no-img-element -- a local preview, not a served image
            <img src={preview} alt="" className="h-20 w-20 rounded-full object-cover" />
          ) : (
            <UserAvatar username={username} avatarUrl={avatarUrl} size="h-20 w-20" textSize="text-3xl" />
          )}
          <span className="absolute -bottom-0.5 -right-0.5 flex size-8 items-center justify-center rounded-full border-2 border-white bg-orange-500 text-white group-hover:bg-orange-600 dark:border-zinc-900">
            <Icon name="camera" className="size-4" />
          </span>
          <input
            ref={fileRef}
            name="avatar"
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif"
            onChange={pickPhoto}
            className="sr-only"
          />
        </label>
        <div className="flex min-w-0 flex-col items-start gap-1">
          <button type="button" onClick={() => fileRef.current?.click()} className="text-sm font-semibold text-orange-700 hover:underline dark:text-orange-400">
            {avatarUrl || preview ? "Change photo" : "Add a photo"}
          </button>
          {preview ? (
            <button
              type="button"
              onClick={() => {
                if (fileRef.current) fileRef.current.value = "";
                setPreview(null);
              }}
              className="text-xs text-zinc-500 hover:underline"
            >
              Keep my old photo
            </button>
          ) : (
            avatarUrl && (
              <button type="submit" formAction={removeAvatarAction} formNoValidate className="text-xs text-zinc-500 hover:text-red-600 hover:underline">
                Remove photo
              </button>
            )
          )}
          <span className="text-xs text-zinc-500 dark:text-zinc-400">JPG, PNG, WEBP or GIF, up to 2MB.</span>
        </div>
      </div>
      {photoError && (
        <p role="alert" className="-mt-2 text-sm text-red-600 dark:text-red-400">
          {photoError}
        </p>
      )}

      {/* The hint sits outside the label, so the field's name is just "Username"
          and the hint is read after it (aria-describedby). */}
      <div className="flex flex-col gap-1.5">
        <label htmlFor="profile-username" className={label}>
          Username
        </label>
        <input
          id="profile-username"
          name="username"
          value={name}
          onChange={(e) => setName(e.target.value)}
          readOnly={usernameLocked}
          required
          minLength={minLength}
          maxLength={maxLength}
          pattern={pattern}
          title={rule}
          autoComplete="username"
          aria-describedby="profile-username-hint"
          className={`${field} sm:max-w-xs ${usernameLocked ? "cursor-not-allowed text-zinc-500" : ""}`}
        />
        <span id="profile-username-hint" className="text-xs text-zinc-500">
          {usernameHint}
        </span>
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="profile-bio" className={label}>
          Bio
        </label>
        <textarea
          id="profile-bio"
          name="bio"
          rows={3}
          maxLength={BIO_MAX}
          value={about}
          onChange={(e) => setAbout(e.target.value)}
          placeholder="Tell people a bit about yourself…"
          aria-describedby="profile-bio-hint"
          className={field}
        />
        <span id="profile-bio-hint" className="flex justify-between gap-3 text-xs text-zinc-500">
          <span>Shown on your profile.</span>
          <span className="tabular-nums">
            {about.length}/{BIO_MAX}
          </span>
        </span>
      </div>

      <SaveButton changed={changed} />
    </form>
  );
}
