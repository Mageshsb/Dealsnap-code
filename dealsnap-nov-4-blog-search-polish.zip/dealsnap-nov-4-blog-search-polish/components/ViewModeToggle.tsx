"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useViewMode, type ViewMode } from "./ViewModeProvider";
import Icon from "./Icon";

export default function ViewModeToggle() {
  const { mode, setMode } = useViewMode();
  const pathname = usePathname();
  // Every page that lists deals and switches between list and scroll in place
  // (each page built on BrowseExperience; a new one belongs here too).
  const onBrowsePage =
    pathname === "/" ||
    pathname === "/vouchers" ||
    pathname.startsWith("/categories/") ||
    pathname.startsWith("/tags/") ||
    pathname.startsWith("/stores/") ||
    pathname.startsWith("/brands/");

  // Only shown where there's a list to switch. Everywhere else (a deal, the
  // blog, your account…) a quiet "Deals" link takes its exact place, so the
  // header never shifts and there's always one tap back to the deals.
  const placeholder = !onBrowsePage;

  function selectMode(next: ViewMode) {
    if (next !== mode) window.scrollTo({ top: 0, behavior: "instant" });
    setMode(next);
  }

  const toggle = (
    // p-0.5 and 38px buttons make it exactly as tall as the header's other
    // buttons (44px on phones, 34px within 36px on laptops), so the header is
    // the same height with or without it.
    <div
      aria-hidden={placeholder || undefined}
      inert={placeholder}
      className={`inline-flex shrink-0 rounded-xl border border-zinc-200 bg-white p-0.5 dark:border-zinc-800 dark:bg-zinc-900 ${
        placeholder ? "[&>button]:invisible" : ""
      }`}
    >
      <button
        onClick={() => selectMode("list")}
        aria-pressed={mode === "list"}
        className={`flex min-h-[38px] min-w-11 flex-col items-center justify-center gap-0.5 rounded-lg px-2 py-0.5 lg:py-1 text-sm font-medium transition-colors lg:min-h-0 lg:min-w-0 lg:flex-row lg:gap-1 lg:px-2.5 ${
          mode === "list"
            ? "bg-orange-500 text-white"
            : "text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100"
        }`}
      >
        <Icon name="list" className="size-4" />
        <span className="text-[9px] font-semibold leading-none lg:text-sm lg:font-medium lg:leading-normal">
          List
        </span>
      </button>
      <button
        onClick={() => selectMode("swipe")}
        aria-pressed={mode === "swipe"}
        className={`flex min-h-[38px] min-w-11 flex-col items-center justify-center gap-0.5 rounded-lg px-2 py-0.5 lg:py-1 text-sm font-medium transition-colors lg:min-h-0 lg:min-w-0 lg:flex-row lg:gap-1 lg:px-2.5 ${
          mode === "swipe"
            ? "bg-orange-500 text-white"
            : "text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100"
        }`}
      >
        <Icon name="cards" className="size-4" />
        <span className="text-[9px] font-semibold leading-none lg:text-sm lg:font-medium lg:leading-normal">
          Cards
        </span>
      </button>
    </div>
  );

  if (!placeholder) return toggle;

  // The switch's frame stays (its buttons hidden) and the link fills exactly
  // the area its buttons cover, as its own inner box, so it reads as the same
  // control: a box within the box. Icon over a small label on phones, one line
  // on laptops; dark bold text with only the icon in orange, so it stands out
  // without a tinted block next to the solid orange Post button.
  return (
    <div className="relative shrink-0">
      {toggle}
      <Link
        href="/"
        className="absolute inset-[3px] flex flex-col items-center justify-center gap-0.5 rounded-lg text-sm font-semibold text-zinc-900 transition-colors hover:bg-zinc-100 dark:text-zinc-100 dark:hover:bg-zinc-800 lg:flex-row lg:gap-1"
      >
        <Icon name="shopping-bag" className="size-4 text-orange-700 dark:text-orange-400" />
        <span className="text-[9px] leading-none lg:text-sm lg:leading-normal">Deals</span>
      </Link>
    </div>
  );
}
