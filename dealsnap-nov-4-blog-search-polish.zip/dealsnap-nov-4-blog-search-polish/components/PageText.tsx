import Link from "next/link";
import { Fragment } from "react";
import { InfoTable } from "./InfoPage";
import { inlineParts, type PageBlock, type TokenValues } from "@/lib/page-text";

// Draws a page's text (lib/page-text.ts) as plain elements, which InfoPage's
// wrapper styles: paragraphs, lists, tables, links. Nothing here uses
// dangerouslySetInnerHTML: the text is read into pieces and each piece is a
// React node, so typed-in markup can only ever appear as words.

function Inline({ raw, tokens }: { raw: string; tokens: TokenValues }) {
  const parts = inlineParts(raw, tokens);
  if (!parts) return null;
  return (
    <>
      {parts.map((p, i) => {
        let node: React.ReactNode = p.text;
        if (p.href) {
          node = p.href.startsWith("/") ? (
            <Link href={p.href}>{p.text}</Link>
          ) : p.href.startsWith("#") || p.href.startsWith("mailto:") ? (
            <a href={p.href}>{p.text}</a>
          ) : (
            <a href={p.href} target="_blank" rel="nofollow noopener noreferrer">
              {p.text}
            </a>
          );
        }
        return <Fragment key={i}>{p.bold ? <strong>{node}</strong> : node}</Fragment>;
      })}
    </>
  );
}

// Whether a line would be drawn (not left out for quoting a detail that isn't set).
const shown = (raw: string, tokens: TokenValues) => inlineParts(raw, tokens) !== null;

export default function PageBlocks({ blocks, tokens }: { blocks: PageBlock[]; tokens: TokenValues }) {
  return (
    <>
      {blocks.map((b, i) => {
        if (b.type === "p") return shown(b.text, tokens) ? <p key={i}><Inline raw={b.text} tokens={tokens} /></p> : null;
        if (b.type === "h3") return shown(b.text, tokens) ? <h3 key={i}><Inline raw={b.text} tokens={tokens} /></h3> : null;
        if (b.type === "ul") {
          const items = b.items.filter((t) => shown(t, tokens));
          return items.length ? (
            <ul key={i}>
              {items.map((t, j) => (
                <li key={j}><Inline raw={t} tokens={tokens} /></li>
              ))}
            </ul>
          ) : null;
        }
        if (b.type === "ol") {
          const items = b.items.filter((t) => shown(t, tokens));
          return items.length ? (
            <ol key={i} start={b.start}>
              {items.map((t, j) => (
                <li key={j}><Inline raw={t} tokens={tokens} /></li>
              ))}
            </ol>
          ) : null;
        }
        if (b.type === "rules") {
          // Numbered cards, numbered on across the whole page so "rule 7" means one thing.
          return (
            <ol key={i} className="!list-none !gap-3 !pl-0">
              {b.items.map((r) => (
                <li key={r.n} className="flex gap-3">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-100 text-xs font-semibold text-orange-700 dark:bg-orange-950/40 dark:text-orange-400">
                    {r.n}
                  </span>
                  <div className="flex flex-col gap-0.5">
                    <h3 className="!pt-0"><Inline raw={r.title} tokens={tokens} /></h3>
                    {r.body && <p><Inline raw={r.body} tokens={tokens} /></p>}
                  </div>
                </li>
              ))}
            </ol>
          );
        }
        // A table: 2 or 3 columns (anything else was flagged when it was saved).
        if (b.head.length < 2 || b.head.length > 3) return null;
        return (
          <InfoTable
            key={i}
            head={b.head.length === 3 ? [b.head[0], b.head[1], b.head[2]] : [b.head[0], b.head[1]]}
            rows={b.rows.map((r) => r.map((c, j) => <Inline key={j} raw={c} tokens={tokens} />))}
          />
        );
      })}
    </>
  );
}
