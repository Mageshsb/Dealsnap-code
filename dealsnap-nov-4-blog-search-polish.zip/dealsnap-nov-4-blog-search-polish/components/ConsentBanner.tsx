"use client";

import { useEffect, useState, useSyncExternalStore } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import Icon from "./Icon";
import { onOpenCookieSettings, saveConsent, savedChoice, useConsent, type CookieCategory } from "./cookie-consent";

// The cookie banner (UK PECR + the ICO's guidance):
//   - shown only when the site has something optional to ask about;
//   - "Reject all" sits beside "Accept all", the same size and colour, so
//     saying no is exactly as easy as saying yes;
//   - every optional kind starts off, and nothing optional runs before a yes;
//   - it doesn't block the page: browsing without answering is a no;
//   - "Cookies" in the footer reopens it, on the visitor's current choices.
//
// ?cookie-preview on any page shows it with both kinds, for checking how it
// looks before tracking is switched on; choices made in a preview aren't saved.

// `partners`: who the marketing code is from, as named in Admin (the ICO
// wants every company that gets the data named).
function about(c: CookieCategory, partners: string): { title: string; text: string; short: string } {
  return c === "analytics"
    ? {
        title: "Analytics",
        text: "Google Analytics counts visits and which pages get used, so we can make DealSnap better. Google sees your IP address and browser details.",
        short: "analytics cookies from Google to see how the site is used",
      }
    : {
        title: "Marketing",
        text: `Lets ${partners} see whether our adverts bring people to DealSnap. They may use it to show you adverts elsewhere.`,
        short: `marketing cookies from ${partners} to see how our adverts are doing`,
      };
}

const BUTTON =
  "flex min-h-11 items-center justify-center rounded-xl bg-orange-500 px-4 text-sm font-semibold text-white transition hover:bg-orange-600 active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-orange-500";

function noSubscribe() {
  return () => {};
}

export default function ConsentBanner({ categories: siteCategories, partners: sitePartners }: { categories: CookieCategory[]; partners: string }) {
  const pathname = usePathname();
  const preview = useSyncExternalStore(noSubscribe, () => new URLSearchParams(window.location.search).has("cookie-preview"), () => false);
  const categories: CookieCategory[] = preview && siteCategories.length === 0 ? ["analytics", "marketing"] : siteCategories;
  const consent = useConsent(categories);
  const partners = sitePartners || "our ad partners (such as Meta)";

  // "closed" once answered; "main" (two buttons) or "choose" (one switch per
  // kind) while asking; "saved" for the short note after answering.
  const [view, setView] = useState<"closed" | "main" | "choose" | "saved">("closed");
  const [picked, setPicked] = useState<Partial<Record<CookieCategory, boolean>>>({});
  const [previewDone, setPreviewDone] = useState(false);

  // Reopened from the footer: start from what they chose last time.
  useEffect(
    () =>
      onOpenCookieSettings(() => {
        const last = savedChoice();
        setPicked(last ? { analytics: last.analytics, marketing: last.marketing } : {});
        setView(categories.length > 1 ? "choose" : "main");
      }),
    [categories.length]
  );

  // The "saved" note goes by itself after a few seconds.
  useEffect(() => {
    if (view !== "saved") return;
    const t = setTimeout(() => setView("closed"), 5000);
    return () => clearTimeout(t);
  }, [view]);

  if (categories.length === 0 || pathname.startsWith("/admin") || consent === "loading") return null;
  const asking = view === "main" || view === "choose" || (view === "closed" && (preview ? !previewDone : consent === "unset"));
  if (!asking && view !== "saved") return null;
  const mode = view === "closed" ? "main" : view;

  function answer(yes: Partial<Record<CookieCategory, boolean>>) {
    if (preview) setPreviewDone(true);
    else saveConsent(categories, yes);
    setView("saved");
  }
  const all = (value: boolean) => Object.fromEntries(categories.map((c) => [c, value]));

  const frame =
    "fixed inset-x-3 z-50 mx-auto max-w-lg rounded-2xl border border-zinc-200 bg-white shadow-xl motion-safe:animate-[consent-in_200ms_ease-out] dark:border-zinc-700 dark:bg-zinc-900";
  const place = { bottom: "calc(env(safe-area-inset-bottom, 0px) + 12px)" };

  if (mode === "saved") {
    return (
      <div role="status" className={`${frame} flex items-center gap-3 p-3 pl-4`} style={place}>
        <Icon name="circle-check" className="size-5 shrink-0 text-green-700 dark:text-green-400" />
        <p className="flex-1 text-sm text-zinc-700 dark:text-zinc-200">
          <span className="font-semibold">Cookie choices saved.</span> Change them any time from Cookies at the bottom of the page.
        </p>
        <button
          type="button"
          onClick={() => setView("closed")}
          aria-label="Close"
          className="flex size-11 shrink-0 items-center justify-center rounded-full text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800"
        >
          <Icon name="x" className="size-5" />
        </button>
      </div>
    );
  }

  // Reopened with one kind to ask about: say where it stands now.
  const current = typeof consent === "object" && view !== "closed" && categories.length === 1;

  return (
    <section aria-labelledby="cookie-banner-title" className={`${frame} flex max-h-[80dvh] flex-col gap-3 overflow-y-auto p-4`} style={place}>
      <div className="flex items-center gap-2.5">
        <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-orange-50 text-orange-700 dark:bg-orange-950/50 dark:text-orange-400">
          <Icon name="cookie" className="size-5" />
        </span>
        <h2 id="cookie-banner-title" className="text-base font-semibold">
          {mode === "choose" ? "Choose your cookies" : "Cookies on DealSnap"}
        </h2>
      </div>

      {mode === "main" ? (
        <p className="text-sm leading-relaxed text-zinc-600 dark:text-zinc-300">
          We use essential cookies to make DealSnap work. With your OK, we&apos;d also like to use{" "}
          {categories.map((c) => about(c, partners).short).join(", and ")}. Nothing optional runs unless you say yes.{" "}
          {current && (
            <span className="font-medium text-zinc-800 dark:text-zinc-100">
              Right now they&apos;re {consent[categories[0]] ? "on" : "off"}.{" "}
            </span>
          )}
          <Link href="/privacy#cookies" className="font-medium text-orange-700 underline-offset-2 hover:underline dark:text-orange-400">
            Cookie details
          </Link>
        </p>
      ) : (
        <ul className="flex flex-col divide-y divide-zinc-100 rounded-xl border border-zinc-200 dark:divide-zinc-800 dark:border-zinc-700">
          <li className="flex items-start gap-3 p-3">
            <div className="flex-1">
              <p className="text-sm font-semibold">Essential</p>
              <p className="text-xs leading-relaxed text-zinc-500 dark:text-zinc-400">
                Keep you signed in, keep the site secure and remember choices you make here, like List or Cards.
              </p>
            </div>
            <span className="shrink-0 pt-0.5 text-xs font-medium text-zinc-500">Always on</span>
          </li>
          {categories.map((c) => {
            const on = !!picked[c];
            return (
              <li key={c}>
                {/* The whole row is the switch, so it's an easy tap on a phone. */}
                <button
                  type="button"
                  role="switch"
                  aria-checked={on}
                  onClick={() => setPicked((p) => ({ ...p, [c]: !on }))}
                  className="flex w-full items-start gap-3 p-3 text-left hover:bg-zinc-50 focus-visible:outline-2 focus-visible:outline-orange-500 dark:hover:bg-zinc-800/60"
                >
                  <span className="flex-1">
                    <span className="block text-sm font-semibold">{about(c, partners).title}</span>
                    <span className="block text-xs leading-relaxed text-zinc-500 dark:text-zinc-400">{about(c, partners).text}</span>
                  </span>
                  <span
                    aria-hidden
                    className={`relative mt-0.5 h-6 w-11 shrink-0 rounded-full transition-colors ${on ? "bg-orange-500" : "bg-zinc-300 dark:bg-zinc-600"}`}
                  >
                    <span className={`absolute top-0.5 left-0.5 size-5 rounded-full bg-white shadow transition-transform ${on ? "translate-x-5" : ""}`} />
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}

      {/* Same size, same colour: saying no is as easy as saying yes. */}
      <div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={() => answer(all(false))} className={BUTTON}>
          Reject all
        </button>
        {mode === "main" ? (
          <button type="button" onClick={() => answer(all(true))} className={BUTTON}>
            Accept all
          </button>
        ) : (
          <button type="button" onClick={() => answer(picked)} className={BUTTON}>
            Save choices
          </button>
        )}
      </div>

      {categories.length > 1 && (
        <button
          type="button"
          onClick={() => setView(mode === "main" ? "choose" : "main")}
          className="-mt-1 flex min-h-11 items-center justify-center gap-1 text-sm font-medium text-zinc-600 hover:text-zinc-900 dark:text-zinc-300 dark:hover:text-zinc-100"
        >
          {mode === "main" ? (
            <>
              Choose which <Icon name="chevron-right" className="size-4" />
            </>
          ) : (
            <>
              <Icon name="chevron-left" className="size-4" /> Back
            </>
          )}
        </button>
      )}
    </section>
  );
}
