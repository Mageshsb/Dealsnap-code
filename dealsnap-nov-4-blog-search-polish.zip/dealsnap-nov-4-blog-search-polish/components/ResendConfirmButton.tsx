"use client";

import { useState, useTransition } from "react";
import { resendEmailConfirmationAction } from "@/lib/actions";

// "Send it again", for the email that confirms a member's address.
export default function ResendConfirmButton({ className = "" }: { className?: string }) {
  const [message, setMessage] = useState("");
  const [pending, startTransition] = useTransition();
  if (message) return <span className={className}>{message}</span>;
  return (
    <button
      type="button"
      disabled={pending}
      onClick={() => startTransition(async () => setMessage(await resendEmailConfirmationAction()))}
      className={`font-medium text-orange-700 hover:underline disabled:opacity-50 dark:text-orange-400 ${className}`}
    >
      {pending ? "Sending…" : "Send it again"}
    </button>
  );
}
