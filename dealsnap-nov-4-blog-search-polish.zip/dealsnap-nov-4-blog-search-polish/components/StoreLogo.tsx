import Icon from "./Icon";

// A store's logo in a rounded box, or a shop icon in a light grey box when it
// has none (light in dark mode too, like the logos' white boxes). The box is
// the same size either way, so a page doesn't shift when a logo is added.
export default function StoreLogo({
  name,
  logoUrl,
  className = "h-7 w-7",
}: {
  name: string;
  logoUrl?: string;
  className?: string;
}) {
  if (!logoUrl) {
    return (
      <span aria-hidden className={`inline-flex shrink-0 items-center justify-center rounded-md bg-zinc-100 text-zinc-600 dark:text-zinc-400 ${className}`}>
        <Icon name="store" className="size-[60%]" />
      </span>
    );
  }
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={logoUrl}
      alt={`${name} logo`}
      className={`shrink-0 rounded-md bg-white object-contain ${className}`}
    />
  );
}
