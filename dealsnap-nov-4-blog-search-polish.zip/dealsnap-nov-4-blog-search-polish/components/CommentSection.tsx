import Link from "next/link";
import {
  getBlockedIds,
  getCommentsForDeal,
  getReportedCommentIdsByUser,
  getLikedCommentIdsByUser,
  type CommentRecord,
  type CommentSort,
  type UserRecord,
} from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { CommentReportMenu } from "@/components/ReportControls";
import CommentRemoveMenu from "@/components/CommentRemoveMenu";
import { formatDate, timeAgo } from "@/lib/format";
import UserAvatar from "@/components/UserAvatar";
import UsernameLink from "@/components/UsernameLink";
import { tierOf } from "@/components/RoleBadge";
import CommentLikeButton from "@/components/CommentLikeButton";
import SortSelect from "@/components/SortSelect";
import OwnComment from "@/components/OwnComment";
import CommentComposer from "@/components/CommentComposer";
import CommentThread, { ReplyButton } from "@/components/CommentThread";
import RichContent from "@/components/RichContent";
import InlinePicture from "@/components/InlinePicture";
import { getPicturesFor, type Picture } from "@/lib/pictures";
import { getSiteHosts } from "@/lib/site-url";
import { mayAddPictures } from "@/lib/post-pictures";
import { MAX_PICTURES } from "@/lib/deal-text";
import ResendConfirmButton from "@/components/ResendConfirmButton";
import Icon from "@/components/Icon";
import { COMMENT_ACTIONS, COMMENT_TEXT } from "@/components/comment-styles";
import { mustConfirmEmail } from "@/lib/email";
import { HELPFUL_LIKES } from "@/lib/comment-rules";
import { canModerateComments } from "@/lib/comment-moderation";
import { mayManageComment } from "@/lib/permissions";

const COMMENT_SORT_OPTIONS: { value: CommentSort; label: string }[] = [
  { value: "old", label: "Oldest first" },
  { value: "new", label: "Newest first" },
  { value: "liked", label: "Most liked" },
];

// What every row needs to know about the reader and the deal.
type Reader = {
  user: UserRecord | null;
  canPost: boolean;
  // A moderator or admin, who can remove comments by people below them.
  canModerate: boolean;
  posterId?: string;
  reportedByMe: Set<string>;
  likedByMe: Set<string>;
  blocked: Set<string>;
  hosts: string[];
  pictures: Map<string, Picture[]>;
};

// A comment's words (plain, with links, @names and up to two deal cards from
// pasted deal addresses: "this one's cheaper") and its pictures underneath.
function CommentBody({ comment, reader }: { comment: CommentRecord; reader: Reader }) {
  const pictures = reader.pictures.get(comment.id) ?? [];
  return (
    <div className="flex min-w-0 flex-col gap-2">
      <RichContent text={comment.text} format={false} hosts={reader.hosts} cards={2} out={{ kind: "c", id: comment.id }} className={`flex flex-col gap-2 ${COMMENT_TEXT}`} />
      {pictures.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {pictures.map((p, i) => (
            <InlinePicture key={p.id} {...p} size="small" alt={`Picture ${i + 1} from ${comment.username}`} />
          ))}
        </div>
      )}
    </div>
  );
}

// One comment: picture on the left; name, tags and time; the text; then Like
// and Reply, with the "⋯" menu at the far right: Edit and Delete on their own,
// Remove on one the team member looks after, otherwise Report.
function CommentRow({ comment, reader, isReply = false }: { comment: CommentRecord; reader: Reader; isReply?: boolean }) {
  const anchor = `comment-${comment.id}`;
  if (reader.blocked.has(comment.userId) || comment.deleted) {
    return (
      <p id={anchor} className="scroll-mt-24 text-sm italic text-zinc-500 dark:text-zinc-400">
        {!comment.deleted ? "Comment from a member you've blocked." : comment.removed ? "Removed by our team" : "Comment deleted"}
      </p>
    );
  }

  const own = !!reader.user && reader.user.id === comment.userId;
  const canRemove = reader.canModerate && !own && mayManageComment(reader.user!, { userId: comment.userId, userRole: comment.role });
  const meta = (
    <div className="flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-xs text-zinc-500">
      <UsernameLink
        username={comment.username}
        userId={comment.userId}
        avatar={false}
        tier={tierOf(comment.role)}
        badge="colour"
        className="flex min-w-0 max-w-full items-center font-medium text-zinc-700 dark:text-zinc-300"
      />
      {/* The person who posted the deal: their answers to questions stand out. */}
      {reader.posterId === comment.userId && (
        <span className="rounded bg-orange-100 px-1.5 text-[11px] font-semibold text-orange-700 dark:bg-orange-950/50 dark:text-orange-300">
          Poster
        </span>
      )}
      {comment.replyToUsername && (
        <span className="flex min-w-0 items-center gap-0.5 text-zinc-500 dark:text-zinc-400">
          <Icon name="corner-down-right" className="size-3 shrink-0" />
          <span className="sr-only">replying to</span>
          <span className="truncate">{comment.replyToUsername}</span>
        </span>
      )}
      <span aria-hidden>·</span>
      <time dateTime={comment.createdAt} title={formatDate(comment.createdAt)} className="whitespace-nowrap">
        {timeAgo(comment.createdAt)}
      </time>
      {comment.edited && <span>· edited</span>}
    </div>
  );
  const actions = (
    <>
      <CommentLikeButton
        commentId={comment.id}
        initialLikeCount={comment.likeCount}
        initiallyLiked={reader.likedByMe.has(comment.id)}
        loggedIn={!!reader.user}
      />
      {reader.canPost && <ReplyButton id={comment.id} username={comment.username} />}
    </>
  );

  return (
    <article id={anchor} className="flex scroll-mt-24 gap-2 rounded-lg">
      <UserAvatar username={comment.username} avatarUrl={comment.avatarUrl} size={isReply ? "h-5 w-5" : "h-6 w-6"} />
      <div className="flex min-w-0 flex-1 flex-col gap-0.5">
        {own ? (
          <OwnComment commentId={comment.id} createdAt={comment.createdAt} meta={meta} text={comment.text} body={<CommentBody comment={comment} reader={reader} />} actions={actions} />
        ) : (
          <>
            {meta}
            <CommentBody comment={comment} reader={reader} />
            {/* Guests get the line only when there are likes to count. */}
            {(reader.user || comment.likeCount > 0) && (
              <div className={COMMENT_ACTIONS}>
                {actions}
                {reader.user && (
                  <span className="ml-auto flex">
                    {canRemove ? (
                      <CommentRemoveMenu commentId={comment.id} />
                    ) : (
                      <CommentReportMenu commentId={comment.id} initiallyReported={reader.reportedByMe.has(comment.id)} />
                    )}
                  </span>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </article>
  );
}

export default async function CommentSection({
  dealSlug,
  posterId,
  pending = false,
  sort = "old",
}: {
  dealSlug: string;
  posterId?: string;
  // A deal still being checked: comments open once it's live.
  pending?: boolean;
  sort?: CommentSort;
}) {
  const user = await getCurrentUser();
  // Comments from members you've blocked are left out, except a top comment
  // that others have replied to, which shows as a placeholder so the thread
  // still makes sense.
  const blocked = new Set(user ? getBlockedIds(user.id) : []);
  const all = getCommentsForDeal(dealSlug, sort);
  const comments = blocked.size
    ? all.filter((c) => !blocked.has(c.userId) || (!c.parentId && all.some((r) => r.parentId === c.id && !blocked.has(r.userId))))
    : all;
  // A deleted comment only stays as a placeholder for its replies.
  const commentCount = comments.filter((c) => !c.deleted).length;
  const reader: Reader = {
    user,
    canPost: !!user && !mustConfirmEmail(user) && !pending,
    canModerate: canModerateComments(user),
    posterId,
    reportedByMe: user ? getReportedCommentIdsByUser(user.id) : new Set<string>(),
    likedByMe: user ? getLikedCommentIdsByUser(user.id) : new Set<string>(),
    blocked,
    hosts: await getSiteHosts(),
    pictures: getPicturesFor("comment", comments.filter((c) => !c.deleted).map((c) => c.id)),
  };
  const maxPictures = mayAddPictures(user) ? MAX_PICTURES.comment : 0;

  const topLevel = comments.filter((c) => c.parentId === null);

  // Replies are grouped under their thread and always read oldest first,
  // whatever order the threads are sorted in.
  const repliesByParent = new Map<string, CommentRecord[]>();
  for (const c of comments) {
    if (!c.parentId) continue;
    const list = repliesByParent.get(c.parentId) ?? [];
    list.push(c);
    repliesByParent.set(c.parentId, list);
  }
  for (const list of repliesByParent.values()) {
    list.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  }

  // The one comment (a reply counts too: it's often the poster's answer) that
  // members found most useful, picked out above the list once a conversation
  // has got going. Ties go to the earliest.
  const helpful =
    commentCount >= 3
      ? comments
          .filter((c) => c.likeCount >= HELPFUL_LIKES && !c.deleted && !blocked.has(c.userId))
          .sort((a, b) => b.likeCount - a.likeCount || a.createdAt.localeCompare(b.createdAt))[0]
      : undefined;

  return (
    <section
      id="comments"
      className="flex scroll-mt-20 flex-col gap-4 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900 sm:p-6"
    >
      <div className="flex min-h-9 items-center justify-between gap-3">
        <h2 className="text-lg font-bold">Comments ({commentCount})</h2>
        {topLevel.length > 1 && <SortSelect param="commentSort" label="Sort comments" current={sort} options={COMMENT_SORT_OPTIONS} />}
      </div>

      {pending ? (
        <p className="text-sm text-zinc-500">Comments open once the deal is live.</p>
      ) : user && mustConfirmEmail(user) ? (
        <p className="rounded-lg border border-dashed border-zinc-300 p-3 text-sm text-zinc-500 dark:border-zinc-700">
          Confirm your email to join in. We sent a link to {user.email}. <ResendConfirmButton />
        </p>
      ) : user ? (
        <CommentComposer dealSlug={dealSlug} maxPictures={maxPictures} />
      ) : (
        <p className="rounded-lg border border-dashed border-zinc-300 p-3 text-sm text-zinc-500 dark:border-zinc-700">
          <Link href="/login" className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
            Log in
          </Link>{" "}
          to comment or reply.
        </p>
      )}

      {helpful && (
        <a
          href={`#comment-${helpful.id}`}
          className="group flex flex-col gap-1 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5 dark:border-amber-900/50 dark:bg-amber-950/20"
        >
          <span className="flex items-center gap-1.5 text-xs font-semibold text-amber-700 dark:text-amber-500">
            <Icon name="thumbs-up" className="size-3.5" />
            Most helpful
          </span>
          <span className="line-clamp-3 text-sm text-zinc-700 dark:text-zinc-300">{helpful.text}</span>
          <span className="flex min-w-0 items-center gap-1.5 text-xs text-zinc-500">
            <span className="min-w-0 truncate font-medium">{helpful.username}</span>
            <span aria-hidden>·</span>
            <span className="shrink-0">{helpful.likeCount} likes</span>
            <span aria-hidden>·</span>
            <span className="shrink-0 font-medium text-orange-700 group-hover:underline dark:text-orange-400">See in thread</span>
          </span>
        </a>
      )}

      {topLevel.length === 0 ? (
        <p className="text-sm text-zinc-500">No comments yet. Ask a question or share a tip.</p>
      ) : (
        <div className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
          {topLevel.map((c) => {
            const replies = repliesByParent.get(c.id) ?? [];
            return (
              <div key={c.id} className="py-4 first:pt-0 last:pb-0">
                <CommentThread
                  dealSlug={dealSlug}
                  maxPictures={maxPictures}
                  root={<CommentRow comment={c} reader={reader} />}
                  replies={replies.map((r) => (
                    <CommentRow key={r.id} comment={r} reader={reader} isReply />
                  ))}
                  replyIds={replies.map((r) => r.id)}
                />
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
