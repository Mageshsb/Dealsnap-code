"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import StoreLogo from "./StoreLogo";
import BrowseCard, { LETTER_HEADING } from "./BrowseCard";
import { ClearSearch, searchBox } from "@/components/SearchBox";
import Icon, { type IconName } from "./Icon";
import { CategoryMenu, CategoryPanel, CLEAR_BUTTON, EmptyToggle, FilterBar, FilterHalf, SortMenu } from "./BrowseFilters";
import { CountBadge } from "./SidebarBoxes";
import BottomSheet from "./BottomSheet";
import ScrollUpBand from "./ScrollUpBand";
import { useAnchoredMenu } from "./useAnchoredMenu";
import { NAME_SEARCH_MAX } from "@/lib/search-limits";
import { LIST_PAGE, visibleCount } from "@/lib/list-paging";
import ShowMoreButton from "./ShowMoreButton";
import { deliveryLabel, matchesDelivery, type DeliveryKind, type StorePerks } from "@/lib/store-perks";

export type DirectoryStore = {
  name: string;
  slug: string;
  logoUrl?: string;
  dealCount: number;
  codeCount: number;
  categories: Record<string, number>;
  // Other names it's known by ("M&S Food"), so searching those finds it too.
  aliases: string[];
  // Free delivery, free returns… for the perk filters. Left out when unknown.
  perks?: StorePerks;
};
type Category = { slug: string; name: string; icon: IconName };
type Sort = "popular" | "codes" | "az";

const SORT_OPTIONS = [
  { value: "popular", label: "Most deals" },
  { value: "az", label: "A–Z" },
  { value: "codes", label: "Most codes" },
];

// The pills. Delivery has two that never overlap (see lib/store-perks.ts); with
// both on, a shop passes if it has either, i.e. any free delivery.
type Pill = { param: string; label: string; icon: IconName; has: (p?: StorePerks) => boolean; kind?: DeliveryKind };
const DELIVERY_PILLS: Pill[] = [
  { param: "free", kind: "free", label: "Free delivery, no minimum", icon: "truck", has: (p) => p?.delivery === "free" },
  { param: "over", kind: "over", label: "Free over a minimum spend", icon: "truck", has: (p) => p?.delivery === "over" },
];
const PERK_PILLS: Pill[] = [
  { param: "collect", label: "Click & collect", icon: "store", has: (p) => !!p?.collect },
  { param: "returns", label: "Free returns", icon: "undo", has: (p) => !!p?.freeReturns },
  { param: "student", label: "Student discount", icon: "graduation-cap", has: (p) => !!p?.student },
  { param: "match", label: "Price match", icon: "handshake", has: (p) => !!p?.priceMatch },
];

const pillClass = (on: boolean, dotted = false) =>
  `flex h-9 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-3 text-sm font-medium transition-colors ${
    on
      ? "border-orange-500 bg-orange-500 text-white"
      : dotted
        ? "border-dashed border-violet-300 bg-violet-50 text-violet-800 hover:bg-violet-100 dark:border-violet-800 dark:bg-violet-950/40 dark:text-violet-200"
        : "border-zinc-300 bg-white text-zinc-700 hover:border-orange-300 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200"
  }`;

// Names compared without case, spaces or punctuation, with & read as "and",
// so "marks and spencer", "m&s" and "sainsburys" all find their store.
const squash = (text: string) => text.toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]/g, "");

// The list on /stores. Each card shows the store's live deals and any working
// codes. Built to stay usable with thousands of shops: a search,
// a category menu, a "with codes" switch and a sort, with only the first few
// dozen drawn until asked for more. Choices live in the address (?q, ?cat,
// ?codes, ?live, ?sort), so coming Back from a store finds the list as it was left.
export default function StoreDirectory({ stores, categories }: { stores: DirectoryStore[]; categories: Category[] }) {
  const params = useSearchParams();
  const [query, setQuery] = useState((params.get("q") ?? "").slice(0, NAME_SEARCH_MAX));
  const cat = categories.some((c) => c.slug === params.get("cat")) ? params.get("cat")! : "";
  const codesOnly = params.get("codes") === "1";
  const deliveryOn = DELIVERY_PILLS.filter((p) => params.get(p.param) === "1");
  const perksOn = PERK_PILLS.filter((p) => params.get(p.param) === "1");
  const perkKey = [...deliveryOn, ...perksOn].map((p) => p.param).join(",");
  // Phones and tablets: the bar's open sheet, "cats" or "perks". Wide screens: Perks is a
  // dropdown beside the category menu.
  const [panel, setPanel] = useState<"cats" | "perks" | null>(null);
  const closePanel = useCallback(() => setPanel(null), [setPanel]);
  const { open: perksMenuOpen, toggle: togglePerksMenu, close: closePerksMenu, anchorRef: perksAnchor, host: perksHost, menuProps: perksMenuProps } = useAnchoredMenu<HTMLButtonElement>("left");
  const controlsRef = useRef<HTMLDivElement>(null);
  const sortParam = params.get("sort");
  const sort: Sort = sortParam === "az" || sortParam === "codes" ? sortParam : "popular";
  const liveOnly = params.get("live") === "1";
  const [more, setMore] = useState({ key: "", n: LIST_PAGE });

  // Swap the address without a page load (Next keeps useSearchParams in step).
  function setParam(key: string, value: string) {
    const next = new URLSearchParams(window.location.search);
    if (value) next.set(key, value);
    else next.delete(key);
    const qs = next.toString();
    window.history.replaceState(null, "", qs ? `?${qs}` : window.location.pathname);
  }

  // The search box updates the address a moment after typing stops.
  useEffect(() => {
    const t = setTimeout(() => setParam("q", query.trim()), 300);
    return () => clearTimeout(t);
  }, [query]);

  const categoryOptions = [{ value: "", label: "All categories", icon: "grid" as IconName }, ...categories.map((c) => ({ value: c.slug, label: c.name, icon: c.icon }))];
  const q = squash(query);
  const names = (s: DirectoryStore) => [s.name, ...s.aliases].map(squash);
  // With a category picked, counts are that category's deals.
  const deals = (s: DirectoryStore) => (cat ? s.categories[cat] ?? 0 : s.dealCount);
  const shown = useMemo(
    () =>
      stores
        .filter((s) => (!q || names(s).some((n) => n.includes(q))) && (!cat || s.categories[cat]) && (!liveOnly || deals(s) > 0) && (!codesOnly || s.codeCount > 0) && matchesDelivery(s.perks, deliveryOn.map((p) => p.kind!)) && perksOn.every((p) => p.has(s.perks)))
        .sort((a, b) => {
          // While searching, names that start with what's typed come first.
          if (q) {
            const starts = (s: DirectoryStore) => (names(s).some((n) => n.startsWith(q)) ? 0 : 1);
            if (starts(a) !== starts(b)) return starts(a) - starts(b);
          }
          if (sort === "az") return a.name.localeCompare(b.name);
          if (sort === "codes") return b.codeCount - a.codeCount || deals(b) - deals(a) || a.name.localeCompare(b.name);
          return deals(b) - deals(a) || a.name.localeCompare(b.name);
        }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [stores, q, cat, codesOnly, sort, perkKey, liveOnly]
  );

  // A new search or filter starts back at the first lot of stores.
  const listKey = `${q}|${cat}|${codesOnly}|${sort}|${perkKey}|${liveOnly}`;
  const limit = more.key === listKey ? more.n : LIST_PAGE;
  const visible = shown.slice(0, visibleCount(shown.length, limit));
  const filtered = !!(q || cat || codesOnly || liveOnly || deliveryOn.length || perksOn.length);

  function clearAll() {
    setQuery("");
    window.history.replaceState(null, "", sort === "popular" ? window.location.pathname : `?sort=${sort}`);
  }

  const perkCount = (codesOnly ? 1 : 0) + deliveryOn.length + perksOn.length;
  const pill = (p: Pill) => {
    const on = params.get(p.param) === "1";
    return (
      <button key={p.param} type="button" onClick={() => setParam(p.param, on ? "" : "1")} aria-pressed={on} className={pillClass(on)}>
        <Icon name={p.icon} className="size-4" />
        {p.label}
      </button>
    );
  };
  // The codes pill is dashed violet like codes everywhere (orange once on,
  // like every chosen filter), at the size of the others.
  const codesPill = (
    <button key="codes" type="button" onClick={() => setParam("codes", codesOnly ? "" : "1")} aria-pressed={codesOnly} className={pillClass(codesOnly, true)}>
      <Icon name="ticket" className="size-4" />
      With codes
    </button>
  );

  // What Perks holds, on the phone panel and the wide-screen dropdown alike.
  const perksBody = (
    <>
      <section className="flex flex-col gap-2">
        <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Delivery</h3>
        <div className="flex flex-wrap gap-2">{DELIVERY_PILLS.map(pill)}</div>
      </section>
      <section className="flex flex-col gap-2">
        <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Also</h3>
        <div className="flex flex-wrap gap-2">
          {codesPill}
          {PERK_PILLS.map(pill)}
        </div>
      </section>
      <p className="text-center text-xs leading-snug text-zinc-500">Perks can change. Check the store&apos;s own site before you buy.</p>
    </>
  );

  // A–Z gets letter headings, so a long list is easy to scan down.
  const letter = (name: string) => {
    const c = name.trim()[0]?.toUpperCase() ?? "#";
    return c >= "A" && c <= "Z" ? c : "#";
  };

  // The search row and the filter bar are drawn twice: in the page, and again
  // in the band that slides down when you scroll back up (ScrollUpBand). Both
  // copies share all their state, so they always agree. `floating` marks the
  // band's copy, whose Perks button (wide screens) has to tell the menu it is
  // the one to line up with.
  const searchRow = (floating: boolean) => (
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        {/* The search, with the hide-empty button right after it (beside it on phones too). */}
        <div className="flex w-full min-w-0 items-center gap-2 sm:max-w-md sm:flex-1">
        {/* Same box and clear (x) button as the search at the top of the site. */}
        <div className="relative min-w-0 flex-1">
          <input
            type="search"
            enterKeyHint="search"
            value={query}
            maxLength={NAME_SEARCH_MAX}
            onChange={(e) => setQuery(e.target.value)}
            // Results are already showing, so Enter just puts the keyboard away.
            onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()}
            placeholder="Search stores, e.g. Currys"
            aria-label="Search stores"
            className={searchBox}
          />
          {query && <ClearSearch onClick={() => {
                setQuery("");
                setParam("q", "");
              }} />}
        </div>
        <EmptyToggle on={liveOnly} onToggle={() => setParam("live", liveOnly ? "" : "1")} />
        </div>
        <div className="hidden min-w-0 gap-2 lg:flex">
          <CategoryMenu value={cat} onChange={(v) => setParam("cat", v)} options={categoryOptions} />
          {/* Perks: a dropdown with the same contents as the phone panel. */}
          <button
            ref={floating ? undefined : perksAnchor}
            type="button"
            onClick={(e) => {
              if (floating) perksAnchor.current = e.currentTarget;
              togglePerksMenu();
            }}
            aria-expanded={perksMenuOpen}
            aria-haspopup="dialog"
            className={`flex h-[38px] w-56 shrink-0 items-center gap-2 rounded-full border pl-4 pr-3.5 text-sm font-medium outline-none focus-visible:border-orange-500 ${
              perkCount || perksMenuOpen
                ? "border-orange-500 bg-orange-50 text-orange-700 dark:bg-orange-950/30 dark:text-orange-300"
                : "border-zinc-300 bg-white text-zinc-700 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200"
            }`}
          >
            <Icon name="gift" className="size-4 shrink-0" />
            <span className="min-w-0 flex-1 truncate text-left">Perks</span>
            {perkCount > 0 && <CountBadge count={perkCount} />}
            <Icon name="chevron-down" className={`size-4 shrink-0 text-zinc-500 transition-transform ${perksMenuOpen ? "rotate-180" : ""}`} />
          </button>
        </div>
      </div>
  );

  // Phones and tablets: the same pills as wide screens, two to a row, with an
  // orange count badge. Each opens a sheet: picking a category closes it,
  // Perks stays open for ticking several (Done closes it).
  const filterBar = (
      <FilterBar
        halves={
          <>
            <FilterHalf
              icon="grid"
              label={(cat && categoryOptions.find((o) => o.value === cat)?.label) || "Categories"}
              active={!!cat}
              onOpen={() => setPanel("cats")}
            />
            <FilterHalf icon="gift" label="Perks" count={perkCount} onOpen={() => setPanel("perks")} />
          </>
        }
      />
  );

  return (
    <div className="flex flex-col gap-4">
      <div ref={controlsRef} className="flex flex-col gap-4">
        {searchRow(false)}
        {filterBar}
      </div>
      <ScrollUpBand after={controlsRef} onHide={closePerksMenu}>
        <div className="flex flex-col gap-2">
          {searchRow(true)}
          {filterBar}
        </div>
      </ScrollUpBand>
      {perksMenuOpen &&
        perksHost &&
        createPortal(
          <div
            {...perksMenuProps}
            role="dialog"
            aria-label="Perks"
            className={`${perksMenuProps.className} flex w-[26rem] flex-col gap-4 rounded-xl border border-zinc-200 bg-white p-4 shadow-lg dark:border-zinc-800 dark:bg-zinc-900`}
          >
            {perksBody}
          </div>,
          perksHost
        )}

      <BottomSheet open={panel !== null} onClose={closePanel} label={panel === "perks" ? "Perks" : "Categories"} title={panel === "perks" ? "Perks" : "Categories"}>
        {panel === "perks" ? (
          perksBody
        ) : (
          <CategoryPanel
            value={cat}
            options={categoryOptions}
            onPick={(v) => {
              setParam("cat", v);
              setPanel(null);
            }}
          />
        )}
      </BottomSheet>

      <div className="flex items-center justify-between gap-3 text-sm text-zinc-500">
        {/* Only a count of what a search or filter found, not of every store. */}
        {filtered && (
          <span className="flex min-w-0 items-center gap-2">
            <span className="truncate">
              {shown.length.toLocaleString("en-GB")} {shown.length === 1 ? "store" : "stores"}
            </span>
            {/* The soft orange "Clear all filters" look from the deal filters. */}
            <button type="button" onClick={clearAll} className={CLEAR_BUTTON}>
              <Icon name="x" className="size-3.5" />
              Clear all
            </button>
          </span>
        )}
        <SortMenu value={sort} onChange={(v) => setParam("sort", v === "popular" ? "" : v)} options={SORT_OPTIONS} />
      </div>

      {shown.length === 0 ? (
        <div className="flex flex-col items-center gap-2 py-10 text-center text-zinc-500">
          <p>{q ? <>No stores match &ldquo;{query.trim()}&rdquo;.</> : "No stores match these filters."}</p>
          {/* "Clear all" is just above. The shop may be new to DealSnap,
              or it was a product name, so offer the deal search too. */}
          {q && (
            <Link href={`/?q=${encodeURIComponent(query.trim())}`} className="text-sm font-medium text-orange-700 hover:underline dark:text-orange-400">
              Search all deals for &ldquo;{query.trim()}&rdquo; ›
            </Link>
          )}
        </div>
      ) : (
        // The same grid as the brands: two across on phones. A store's card is a
        // brand's plus a strip along the bottom for its codes and perks.
        <div className="grid grid-cols-2 gap-2.5 sm:gap-3 md:grid-cols-3 lg:grid-cols-4">
          {visible.map((s, i) => {
            const n = deals(s);
            const delivery = deliveryLabel(s.perks);
            const heading = sort === "az" && (i === 0 || letter(visible[i - 1].name) !== letter(s.name));
            return (
              <div key={s.slug} className="contents">
                {heading && <h2 className={`${LETTER_HEADING} ${i ? "mt-2" : ""}`}>{letter(s.name)}</h2>}
                <BrowseCard
                  href={`/stores/${s.slug}`}
                  leading={
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-zinc-100 bg-white p-1 dark:border-zinc-800">
                      <StoreLogo name={s.name} logoUrl={s.logoUrl} className="h-full w-full" />
                    </span>
                  }
                  name={s.name}
                  sub={n > 0 ? `${n} live deal${n === 1 ? "" : "s"}` : "No live deals"}
                  muted={n === 0}
                  phoneArrow={false}
                  footer={
                    <>
                      {delivery && (
                        <span className="flex min-w-0 items-center gap-1 whitespace-nowrap rounded-full border border-green-200 bg-green-50 px-2 py-px font-semibold text-green-700 dark:border-green-900/60 dark:bg-green-950/40 dark:text-green-300">
                          <Icon name="truck" className="size-3 shrink-0" />
                          {/* With a code beside it a phone tile has no room for the full wording. */}
                          <span className={`truncate ${s.codeCount > 0 ? "max-sm:hidden" : ""}`}>{delivery}</span>
                          {s.codeCount > 0 && <span className="sm:hidden">{s.perks?.delivery === "over" ? `Over £${s.perks.deliveryMin}` : "Free"}</span>}
                        </span>
                      )}
                      {s.codeCount > 0 && (
                        <span
                          aria-label={`${s.codeCount} ${s.codeCount === 1 ? "code" : "codes"}`}
                          className="flex shrink-0 items-center gap-1 whitespace-nowrap rounded-full border border-dashed border-violet-300 bg-violet-50 px-2 py-px font-semibold text-violet-800 dark:border-violet-800 dark:bg-violet-950/40 dark:text-violet-200"
                        >
                          <Icon name="ticket" className="size-3" />
                          {s.codeCount}
                          <span className="max-sm:hidden">{s.codeCount === 1 ? "code" : "codes"}</span>
                        </span>
                      )}
                    </>
                  }
                />
              </div>
            );
          })}
        </div>
      )}

      {shown.length > visible.length && (
        <ShowMoreButton noun="stores" left={shown.length - visible.length} onClick={() => setMore({ key: listKey, n: limit + LIST_PAGE })} />
      )}
    </div>
  );
}
