import { deleteAccountAction } from "@/lib/actions";
import { RowIcon } from "./AccountSection";
import Icon from "./Icon";

const field =
  "rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950";

// Download-my-data and delete-my-account (UK GDPR rights): Settings → Your data.
// Deleting opens in place, with the password and "DELETE" to confirm.
export default function YourDataPanel() {
  return (
    <div id="your-data" className="flex scroll-mt-24 flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-3 pb-5">
        <RowIcon icon="download" />
        <div className="min-w-0 flex-1 basis-48">
          <p className="font-semibold">Download your data</p>
          <p className="text-sm text-zinc-500">A file with your account details, deals, comments, hearts, saved deals, alerts, notifications and reports.</p>
        </div>
        {/* A file download, so a plain link on purpose (not a page for next/link to open). */}
        {/* eslint-disable-next-line @next/next/no-html-link-for-pages */}
        <a
          href="/profile/export"
          className="shrink-0 rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
        >
          Download
        </a>
      </div>

      <details className="group pt-5">
        <summary className="flex cursor-pointer list-none flex-wrap items-center gap-x-3 gap-y-3 [&::-webkit-details-marker]:hidden">
          <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-400">
            <Icon name="trash" className="size-5" />
          </span>
          <span className="min-w-0 flex-1 basis-48">
            <span className="block font-semibold">Delete my account</span>
            <span className="block text-sm text-zinc-500">Close your account for good.</span>
          </span>
          <span className="shrink-0 rounded-full border border-red-300 px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50 group-open:hidden dark:border-red-900 dark:hover:bg-red-950/30">
            Delete…
          </span>
        </summary>
        <div className="mt-4 flex flex-col gap-3 rounded-xl border border-red-200 bg-red-50/60 p-4 dark:border-red-900/60 dark:bg-red-950/20 sm:max-w-md">
          <p className="text-sm text-red-900 dark:text-red-200">
            This removes your name, email, profile and hearts, takes down your deals and replaces your comments with &ldquo;[comment deleted]&rdquo;. It
            can&apos;t be undone.
          </p>
          <form action={deleteAccountAction} className="flex flex-col gap-2">
            <input name="password" type="password" required placeholder="Your password" aria-label="Your password" className={field} />
            <input name="confirm" required placeholder="Type DELETE to confirm" aria-label="Type DELETE to confirm" autoComplete="off" className={field} />
            <button type="submit" className="self-start rounded-full bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700">
              Permanently delete my account
            </button>
          </form>
        </div>
      </details>
    </div>
  );
}
