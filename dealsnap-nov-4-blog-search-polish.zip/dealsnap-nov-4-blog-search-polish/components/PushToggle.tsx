"use client";

import { useEffect, useState, useTransition } from "react";
import {
  removePushSubscriptionAction,
  saveAppPushTokenAction,
  savePushSubscriptionAction,
  sendTestPushAction,
} from "@/lib/member-actions";
import { nativeApp, registerAppPush, rememberAppPushToken, savedAppPushToken } from "@/lib/app-native";
import { RowIcon } from "./AccountSection";
import Icon from "./Icon";

type State = "checking" | "unsupported" | "insecure" | "ios-install" | "blocked" | "off" | "on";

function base64UrlToBytes(value: string): Uint8Array<ArrayBuffer> {
  const padded = (value + "=".repeat((4 - (value.length % 4)) % 4)).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(padded);
  const bytes = new Uint8Array(new ArrayBuffer(raw.length));
  for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
  return bytes;
}

function bytesToBase64Url(buf: ArrayBuffer | null): string {
  if (!buf) return "";
  return btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function registration() {
  return navigator.serviceWorker.register("/sw.js", { scope: "/" }).then(() => navigator.serviceWorker.ready);
}

// "Phone notifications" on/off for this device. Turning it on asks the
// browser's permission (only when tapped, never on page load).
// In Settings → Notifications it's a soft grey row with every state
// explained. As a `nudge` (the Alerts page, once you have an alert) it's one
// line offering to turn it on, and nothing at all unless it's simply off.
// In the phone apps it asks the phone instead of the browser, and the
// notifications come through Apple or Google (lib/app-push.ts).
export default function PushToggle({ publicKey, nudge = false }: { publicKey: string; nudge?: boolean }) {
  const [state, setState] = useState<State>("checking");
  const [message, setMessage] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const push = nativeApp()?.plugins.PushNotifications;
      if (push) {
        const { receive } = await push.checkPermissions();
        const next: State = receive === "denied" ? "blocked" : receive === "granted" && savedAppPushToken() ? "on" : "off";
        if (!cancelled) setState(next);
        return;
      }
      const ios = /iPhone|iPad|iPod/.test(navigator.userAgent);
      const installed = window.matchMedia("(display-mode: standalone)").matches;
      let next: State;
      if (!window.isSecureContext) next = "insecure";
      else if (!("serviceWorker" in navigator) || !("PushManager" in window) || !("Notification" in window)) {
        next = ios && !installed ? "ios-install" : "unsupported";
      } else if (Notification.permission === "denied") next = "blocked";
      else {
        const reg = await navigator.serviceWorker.getRegistration("/");
        const sub = await reg?.pushManager.getSubscription();
        next = sub ? "on" : "off";
      }
      if (!cancelled) setState(next);
    })().catch(() => !cancelled && setState("unsupported"));
    return () => {
      cancelled = true;
    };
  }, []);

  function turnOn() {
    setMessage(null);
    const app = nativeApp();
    if (app?.plugins.PushNotifications) {
      const push = app.plugins.PushNotifications;
      startTransition(async () => {
        try {
          const { receive } = await push.requestPermissions();
          if (receive !== "granted") {
            setState(receive === "denied" ? "blocked" : "off");
            return;
          }
          const token = await registerAppPush();
          if (!token || !(await saveAppPushTokenAction(app.platform, token)).ok) throw new Error("save failed");
          rememberAppPushToken(token);
          setState("on");
          await sendTestPushAction();
          setMessage("Done. We've sent a test notification to this phone.");
        } catch {
          setMessage("That didn't work. Please try again.");
        }
      });
      return;
    }
    startTransition(async () => {
      try {
        const permission = await Notification.requestPermission();
        if (permission !== "granted") {
          setState(permission === "denied" ? "blocked" : "off");
          return;
        }
        const reg = await registration();
        const sub =
          (await reg.pushManager.getSubscription()) ??
          (await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: base64UrlToBytes(publicKey) }));
        const res = await savePushSubscriptionAction({
          endpoint: sub.endpoint,
          p256dh: bytesToBase64Url(sub.getKey("p256dh")),
          auth: bytesToBase64Url(sub.getKey("auth")),
        });
        if (!res.ok) throw new Error("save failed");
        setState("on");
        await sendTestPushAction();
        setMessage("Done. We've sent a test notification to this device.");
      } catch {
        setMessage("That didn't work. Please try again.");
      }
    });
  }

  function turnOff() {
    setMessage(null);
    const app = nativeApp();
    if (app?.plugins.PushNotifications) {
      const push = app.plugins.PushNotifications;
      startTransition(async () => {
        const token = savedAppPushToken();
        if (token) await removePushSubscriptionAction(`app:${app.platform}:${token}`);
        rememberAppPushToken(undefined);
        await push.unregister().catch(() => {});
        setState("off");
      });
      return;
    }
    startTransition(async () => {
      const reg = await navigator.serviceWorker.getRegistration("/");
      const sub = await reg?.pushManager.getSubscription();
      if (sub) {
        await removePushSubscriptionAction(sub.endpoint);
        await sub.unsubscribe().catch(() => {});
      }
      setState("off");
    });
  }

  const note: Partial<Record<State, string>> = {
    insecure: "Phone notifications need the site's secure (https://) address.",
    unsupported: "This browser can't show notifications from websites.",
    "ios-install": "On iPhone, add DealSnap to your Home Screen first: tap Share, then Add to Home Screen, then open DealSnap from there and come back here.",
    blocked: nativeApp()
      ? "Notifications are off for DealSnap in your phone's Settings. Turn them on there, then come back here."
      : "Notifications are blocked for DealSnap. Allow them in your browser's site settings, then come back here.",
  };

  if (nudge) {
    if (state !== "off" && !message) return null;
    return (
      <div className="flex items-center gap-3 rounded-xl border border-orange-200 bg-orange-50 px-4 py-3 dark:border-orange-900/60 dark:bg-orange-950/30">
        <Icon name="bell-ring" className="size-5 shrink-0 text-orange-700 dark:text-orange-400" />
        <p className="min-w-0 flex-1 text-sm">{message ?? "Get your alerts on this phone too, even when DealSnap is closed."}</p>
        {state === "off" && (
          <button
            type="button"
            onClick={turnOn}
            disabled={pending}
            className="shrink-0 rounded-full bg-orange-500 px-4 py-1.5 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60"
          >
            {pending ? "…" : "Turn on"}
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-2 rounded-xl bg-zinc-50 p-3 dark:bg-zinc-800/50">
      <div className="flex items-center gap-3">
        <RowIcon icon="bell-ring" />
        <span className="flex min-w-0 flex-1 flex-col">
          <span className="font-semibold">Phone notifications</span>
          <span className="text-sm text-zinc-500">
            {state === "on" ? "On for this device." : "Pop up on this device, even when DealSnap is closed."}
          </span>
        </span>
        {(state === "off" || state === "on") && (
          <button
            type="button"
            onClick={state === "on" ? turnOff : turnOn}
            disabled={pending}
            className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition-colors disabled:opacity-60 ${
              state === "on"
                ? "border border-zinc-300 text-zinc-700 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
                : "bg-orange-500 text-white hover:bg-orange-600"
            }`}
          >
            {pending ? "…" : state === "on" ? "Turn off" : "Turn on"}
          </button>
        )}
      </div>
      {note[state] && <p className="text-sm text-zinc-500 sm:pl-[52px]">{note[state]}</p>}
      {message && <p className="text-sm text-green-700 sm:pl-[52px] dark:text-green-400">{message}</p>}
    </div>
  );
}
