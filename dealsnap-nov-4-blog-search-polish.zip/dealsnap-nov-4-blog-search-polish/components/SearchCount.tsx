"use client";

import { useExpiredFilter } from "./ExpiredFilterProvider";

// The "N results" line beside a search's title, counting only the deals the
// list will actually show: expired matches are left out while "Show expired"
// is off. `query` is the search as understood, typos fixed ("iphne" → "iphone").
export default function SearchCount({ total, expired, query }: { total: number; expired: number; query: string }) {
  const { showExpired } = useExpiredFilter();
  const hiding = !showExpired && expired > 0;
  const n = hiding ? total - expired : total;
  return (
    <p className="ml-3 inline text-sm text-zinc-500 [overflow-wrap:anywhere]">
      {n} {hiding ? "live " : ""}result{n === 1 ? "" : "s"} for &ldquo;{query}&rdquo;
    </p>
  );
}
