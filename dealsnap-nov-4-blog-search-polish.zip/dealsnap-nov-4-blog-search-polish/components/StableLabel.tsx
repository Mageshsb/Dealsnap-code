import type { ReactNode } from "react";

// A button label that changes ("Follow" → "Following", "Copy" → "Copied")
// without changing the button's size: every wording sits in the same spot,
// the widest one sets the width, and only the current one is visible. Use it
// wherever tapping a button swaps its words, so nothing beside it moves.
// `center`: the shorter wordings sit in the middle of the space (a button's
// label), rather than at its start.
export default function StableLabel({ options, show, center = false }: { options: { key: string; label: ReactNode }[]; show: string; center?: boolean }) {
  return (
    <span className="inline-grid">
      {options.map((o) => (
        <span key={o.key} className={`col-start-1 row-start-1 inline-flex items-center gap-1.5 ${center ? "justify-center" : ""} ${o.key === show ? "" : "invisible"}`}>
          {o.label}
        </span>
      ))}
    </span>
  );
}

// The common case: plain words.
export function words(...labels: string[]) {
  return labels.map((l) => ({ key: l, label: l }));
}
