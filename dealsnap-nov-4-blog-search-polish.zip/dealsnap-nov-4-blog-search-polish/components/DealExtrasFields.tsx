"use client";

import { useContext, useState, type ReactNode } from "react";
import { ProblemContext, ProblemText } from "./post/bits";
import { VOUCHER_CODE_MAX } from "@/lib/deal-extras";
import { DEAL_CONDITIONS, PRICE_UNITS, type DealCondition } from "@/lib/deal-kinds";
import SelectField from "./SelectField";
import AmountInput from "./AmountInput";
import Icon, { type IconName } from "./Icon";

// The post form's boxes. Every one-line box, menu and tile is the same
// height (44px on phones, 40px from 640px), so boxes side by side line up.
export const FIELD =
  "rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950";
export const INPUT = `h-11 sm:h-10 ${FIELD}`;
const field = INPUT;

// Hints under a box.
export const HINT = "text-xs text-zinc-500 dark:text-zinc-400";

// The optional extras when posting or editing a deal (see lib/deal-extras.ts).

export function VoucherCodeField({
  defaultValue = "",
  fromLink = false,
  voucher = false,
  below,
}: {
  defaultValue?: string;
  fromLink?: boolean;
  // A voucher: the code is the deal, so it's required, asked for first, and
  // said plainly what kind of code belongs here.
  voucher?: boolean;
  // Anything to say under it (the "Then it's a Sale" switch, an earlier post).
  below?: ReactNode;
}) {
  const wrong = useContext(ProblemContext)?.id === "voucherCode";
  return (
    <div className="flex min-w-0 flex-col gap-1.5" data-problem={wrong || undefined}>
      <label htmlFor="voucherCode" className="text-sm font-medium">
        {voucher ? "The code" : "Discount code"}
      </label>
      <input
        id="voucherCode"
        name="voucherCode"
        defaultValue={defaultValue}
        maxLength={VOUCHER_CODE_MAX}
        required={voucher}
        autoCapitalize="characters"
        autoComplete="off"
        spellCheck={false}
        placeholder="e.g. SAVE20"
        className={`min-w-0 font-mono placeholder:font-sans ${field}`}
      />
      <ProblemText id="voucherCode" />
      <p className={HINT}>
        {fromLink
          ? "From the store's page."
          : voucher
            ? "Only codes anyone can use: no referral or one-off codes."
            : "Only if one's needed at checkout."}
      </p>
      {below}
    </div>
  );
}

// The grey tiles that turn orange when picked: Delivery's choices, the
// catches below, where to buy, and on the post form what a voucher gives and
// "Up to".
export const CHOICE_TILE =
  "flex min-h-11 cursor-pointer items-center justify-center rounded-xl bg-zinc-100 px-3 text-sm font-medium text-zinc-600 transition-colors hover:bg-zinc-200 has-checked:bg-orange-500 has-checked:text-white has-focus-visible:ring-2 has-focus-visible:ring-orange-500 has-focus-visible:ring-offset-2 sm:min-h-10 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700 dark:has-checked:bg-orange-500 dark:has-checked:text-white dark:ring-offset-zinc-900";

const DELIVERY_OPTIONS = [
  { value: "", label: "Not sure" },
  { value: "free", label: "Free" },
  { value: "paid", label: "Costs extra" },
] as const;

type DeliveryChoice = (typeof DELIVERY_OPTIONS)[number]["value"];

export function DeliveryField({ defaultDelivery }: { defaultDelivery?: number }) {
  const [choice, setChoice] = useState<DeliveryChoice>(
    defaultDelivery === undefined ? "" : defaultDelivery === 0 ? "free" : "paid",
  );

  return (
    <fieldset className="flex flex-col gap-1.5">
      <legend className="mb-1.5 text-sm font-medium">Delivery</legend>
      {/* "Costs extra" gets a little more room so it fits a 360px phone. */}
      <div className="grid grid-cols-[1fr_1fr_1.3fr] gap-1.5 sm:flex sm:gap-2">
        {DELIVERY_OPTIONS.map((o) => (
          <label key={o.value} className={`${CHOICE_TILE} whitespace-nowrap`}>
            <input
              type="radio"
              name="delivery"
              value={o.value}
              checked={choice === o.value}
              onChange={() => setChoice(o.value)}
              className="sr-only"
            />
            {o.label}
          </label>
        ))}
      </div>
      {choice === "paid" && (
        <div className="mt-1 flex items-center gap-3">
          <label htmlFor="deliveryCost" className="text-sm text-zinc-600 dark:text-zinc-300">
            Delivery costs
          </label>
          <div className="w-32">
            <AmountInput
              unit="£"
              id="deliveryCost"
              name="deliveryCost"
              step="0.01"
              min="0.01"
              required
              defaultValue={defaultDelivery || ""}
              placeholder="3.99"
              className={field}
            />
          </div>
        </div>
      )}
    </fieldset>
  );
}

// The shopping events on now (Black Friday, Christmas…), as tiles to tick:
// the deal then shows on that event's page. Not shown when none is on.
export function EventsField({
  choices,
  defaultValue = [],
}: {
  choices: { slug: string; name: string; icon: IconName }[];
  defaultValue?: string[];
}) {
  if (!choices.length) return null;
  return (
    <fieldset className="flex flex-col gap-1.5">
      <legend className="mb-1.5 text-sm font-medium">Part of an event?</legend>
      <div className="grid grid-cols-2 gap-1.5 sm:gap-2">
        {choices.map((c) => (
          <label key={c.slug} className={`${CHOICE_TILE} justify-start gap-2 last:odd:col-span-2`}>
            <input
              type="checkbox"
              name="events"
              value={c.slug}
              defaultChecked={defaultValue.includes(c.slug)}
              className="sr-only"
            />
            <Icon name={c.icon} className="size-4 shrink-0" />
            <span className="min-w-0 truncate">{c.name}</span>
          </label>
        ))}
      </div>
      <p className={HINT}>Tick it to show the deal on that event&apos;s page.</p>
    </fieldset>
  );
}

// Who or what the deal is limited to (lib/deal-kinds.ts), as tiles to tick.
// They show as small print on the deal, so people know before they click.
export function ConditionsField({
  defaultValue = [],
  onChange,
}: {
  defaultValue?: DealCondition[];
  onChange?: (conditions: DealCondition[]) => void;
}) {
  const [ticked, setTicked] = useState<DealCondition[]>(defaultValue);
  function toggle(value: DealCondition, on: boolean) {
    const next = DEAL_CONDITIONS.map((c) => c.value).filter((v) => (v === value ? on : ticked.includes(v)));
    setTicked(next);
    onChange?.(next);
  }

  return (
    <fieldset className="flex flex-col gap-1.5">
      <legend className="mb-1.5 text-sm font-medium">Any catches?</legend>
      {/* Two to a row (three cuts the words short), the odd one out taking
          the whole last row rather than leaving a gap. */}
      <div className="grid grid-cols-2 gap-1.5 sm:gap-2">
        {DEAL_CONDITIONS.map((c) => (
          <label key={c.value} title={c.hint} className={`${CHOICE_TILE} justify-start gap-2 last:odd:col-span-2`}>
            <input
              type="checkbox"
              name="conditions"
              value={c.value}
              checked={ticked.includes(c.value)}
              onChange={(e) => toggle(c.value, e.target.checked)}
              className="sr-only"
            />
            {/* No icon on narrow phones, so the words fit two to a row. */}
            <Icon name={c.icon} className="size-4 shrink-0 max-[399px]:hidden" />
            <span className="min-w-0 truncate">{c.short}</span>
          </label>
        ))}
      </div>
      <p className={HINT}>
        Tick any that apply. Members price means a loyalty card or membership, like Clubcard or Prime.
      </p>
    </fieldset>
  );
}

export type PriceExtrasValue = { priceUnit: string; priceFrom: boolean; cashback: string };

// A price drop's extras: charged per month/person…, a "from" price, and
// cashback to claim after paying (the card then shows the price after it,
// with "After £x cashback" in its small print).
export function PriceExtrasFields({
  defaultValue,
  onChange,
  look = "field",
}: {
  defaultValue?: Partial<PriceExtrasValue>;
  onChange?: (value: PriceExtrasValue) => void;
  look?: "field" | "admin";
}) {
  const [value, setValue] = useState<PriceExtrasValue>({
    priceUnit: defaultValue?.priceUnit ?? "",
    priceFrom: !!defaultValue?.priceFrom,
    cashback: defaultValue?.cashback ?? "",
  });
  function set(change: Partial<PriceExtrasValue>) {
    const next = { ...value, ...change };
    setValue(next);
    onChange?.(next);
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-2 gap-3">
        <div className="flex min-w-0 flex-col gap-1.5">
          <label htmlFor="priceUnit" className="text-sm font-medium">
            Price is
          </label>
          <SelectField
            id="priceUnit"
            name="priceUnit"
            label="Price is"
            look={look}
            value={value.priceUnit}
            onChange={(v) => set({ priceUnit: v })}
            options={[{ value: "", label: "One-off" }, ...PRICE_UNITS.map((u) => ({ value: u.value, label: u.label }))]}
          />
        </div>
        <div className="flex min-w-0 flex-col gap-1.5">
          <label htmlFor="cashback" className="text-sm font-medium">
            Cashback
          </label>
          <AmountInput
            unit="£"
            id="cashback"
            name="cashback"
            step="0.01"
            min="0.01"
            value={value.cashback}
            onChange={(e) => set({ cashback: e.target.value })}
            placeholder="Optional"
            className={look === "admin" ? field.replace("dark:bg-zinc-950", "dark:bg-zinc-900") : field}
          />
        </div>
      </div>
      <label className={`${CHOICE_TILE} justify-start gap-2 py-2 text-left`}>
        <input
          type="checkbox"
          name="priceFrom"
          value="1"
          checked={value.priceFrom}
          onChange={(e) => set({ priceFrom: e.target.checked })}
          className="sr-only"
        />
        <Icon name={value.priceFrom ? "check" : "plus"} className="size-4 shrink-0" />
        <span>It&apos;s a &ldquo;from&rdquo; price (it varies by size, date or room)</span>
      </label>
    </div>
  );
}
