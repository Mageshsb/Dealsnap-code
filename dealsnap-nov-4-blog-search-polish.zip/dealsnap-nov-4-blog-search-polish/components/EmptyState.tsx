import type { ReactNode } from "react";
import Icon, { EMPTY_ICON, type IconName } from "./Icon";

// The one look for "nothing here": a faint icon and a short message in a
// dashed box, on deal lists, Saved, Notifications, the blog and profiles.
// `boxed={false}` drops the box where it already sits in one (the dashed
// end-of-deck card in Cards view).
export default function EmptyState({ icon, children, boxed = true }: { icon: IconName; children: ReactNode; boxed?: boolean }) {
  return (
    <div
      className={`flex flex-col items-center gap-2 text-center text-sm text-zinc-500 ${
        boxed ? "rounded-xl border border-dashed border-zinc-300 p-8 dark:border-zinc-700" : ""
      }`}
    >
      <Icon name={icon} className={EMPTY_ICON} />
      {children}
    </div>
  );
}
