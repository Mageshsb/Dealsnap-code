import type { ReactNode } from "react";
import Icon from "./Icon";
import { AdTag } from "./AdTag";
import type { AdCreative } from "@/lib/ads";

// How a campaign's ad looks in each ad space. One set of words and pictures,
// drawn in the site's own style for wherever it lands. Every space has a fixed
// size whatever is filled in (lines are cut off at a set length, and the picture
// spot is always there), so nothing on the page moves before or after an ad or
// its picture loads. Every ad starts with "Ad" and who it's from, which UK
// advertising rules (CAP Code 2.1) ask for. Plain look, no orange: deals and
// DealSnap's own promos are the orange ones.

export type AdLayout = "row" | "strip" | "card" | "box" | "tower";

// The fixed heights (Tailwind classes), shared with the ad network's spaces and
// the outlines staff can switch on.
export const AD_HEIGHT: Record<AdLayout, string> = {
  // As tall as the shortest deal tile (one-line title, no small print), which
  // is 190px on phones and 174px from 640px, never taller than the tiles round it.
  row: "h-[11.875rem] sm:h-[10.875rem]",
  strip: "h-24", // compact, on deal pages and in articles
  card: "h-full", // the Cards view decides
  box: "h-[18rem]",
  tower: "h-[38.75rem]", // 600px, plus the label line
};

const CTA = "shrink-0 rounded-full bg-zinc-900 px-3.5 py-1.5 text-sm font-semibold text-white group-hover:bg-zinc-700 dark:bg-white dark:text-zinc-900 dark:group-hover:bg-zinc-200";
const FRAME = "group flex overflow-hidden border border-zinc-200 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900";
const PICTURE_BG = "relative shrink-0 overflow-hidden bg-zinc-100 dark:bg-zinc-800";

// The picture, or (with none) the advertiser's logo on a plain tile, or an icon.
function Picture({ ad, iconSize }: { ad: AdCreative; iconSize: string }) {
  const src = ad.imageUrl ?? ad.logoUrl;
  if (src) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={src} alt="" loading="lazy" decoding="async" className={`absolute inset-0 size-full ${ad.imageUrl ? "object-cover" : "object-contain p-6"}`} />;
  }
  return (
    <span className="absolute inset-0 flex items-center justify-center text-zinc-500 dark:text-zinc-400">
      <Icon name="shopping-bag" className={iconSize} />
    </span>
  );
}

function Shell({ ad, href, className, children }: { ad: AdCreative; href?: string; className: string; children: ReactNode }) {
  if (!href) return <div className={className}>{children}</div>;
  return (
    <a
      href={href}
      // Somebody else's page: a new tab, and search engines are told it's paid.
      target={ad.internal ? undefined : "_blank"}
      rel={ad.internal ? "sponsored" : "sponsored noopener"}
      aria-label={`Ad from ${ad.advertiser}: ${ad.headline}`}
      className={className}
    >
      {children}
    </a>
  );
}

// Lists and deal pages: a deal card's shape, picture at the left.
export function AdRow({ ad, href }: { ad: AdCreative; href?: string }) {
  return (
    <Shell ad={ad} href={href} className={`${FRAME} ${AD_HEIGHT.row} rounded-xl`}>
      <div className={`${PICTURE_BG} w-28 self-stretch sm:w-32 md:w-40`}>
        <Picture ad={ad} iconSize="size-10" />
      </div>
      <div className="flex min-w-0 flex-1 flex-col gap-1 p-3">
        <AdTag advertiser={ad.advertiser} />
        <span className="line-clamp-2 font-semibold leading-snug">{ad.headline}</span>
        {ad.body && <span className="line-clamp-2 text-sm leading-snug text-zinc-600 dark:text-zinc-400 sm:line-clamp-1">{ad.body}</span>}
        <span className="mt-auto flex justify-end pt-1">
          <span className={CTA}>{ad.ctaLabel}</span>
        </span>
      </div>
    </Shell>
  );
}

// Compact (deal pages and articles): one line, small square picture at the
// left, the button at the right. About half a row's height.
export function AdStrip({ ad, href }: { ad: AdCreative; href?: string }) {
  return (
    <Shell ad={ad} href={href} className={`${FRAME} ${AD_HEIGHT.strip} items-center rounded-xl`}>
      <div className={`${PICTURE_BG} w-20 self-stretch sm:w-24`}>
        <Picture ad={ad} iconSize="size-7" />
      </div>
      <div className="flex min-w-0 flex-1 flex-col gap-0.5 px-3">
        <AdTag advertiser={ad.advertiser} />
        <span className="line-clamp-2 text-sm font-semibold leading-snug sm:line-clamp-1 sm:text-base">{ad.headline}</span>
        {ad.body && <span className="hidden text-sm leading-snug text-zinc-600 sm:line-clamp-1 dark:text-zinc-400">{ad.body}</span>}
      </div>
      <span className={`${CTA} mr-3 px-3 text-xs sm:px-3.5 sm:text-sm`}>{ad.ctaLabel}</span>
    </Shell>
  );
}

// Cards view: a deal card's shape there (SwipeCard), picture on top.
export function AdTallCard({ ad, href }: { ad: AdCreative; href?: string }) {
  return (
    <Shell ad={ad} href={href} className={`${FRAME} @container h-full w-full select-none flex-col rounded-3xl shadow-2xl`}>
      <div className={`${PICTURE_BG} min-h-0 w-full flex-[1000_1_0%] max-h-[62.5cqw]`}>
        <Picture ad={ad} iconSize="size-24" />
      </div>
      <div className="flex min-h-0 flex-1 flex-col gap-1.5 p-4">
        <AdTag advertiser={ad.advertiser} />
        <span className="line-clamp-2 text-lg font-bold leading-snug">{ad.headline}</span>
        {ad.body && <span className="line-clamp-2 text-sm leading-snug text-zinc-600 dark:text-zinc-400">{ad.body}</span>}
        <span className="mt-auto flex justify-end pt-1">
          <span className={CTA}>{ad.ctaLabel}</span>
        </span>
      </div>
    </Shell>
  );
}

// Under Filters on laptops: the sidebar's width, picture on top.
export function AdBox({ ad, href }: { ad: AdCreative; href?: string }) {
  return (
    <Shell ad={ad} href={href} className={`${FRAME} ${AD_HEIGHT.box} w-full flex-col rounded-xl`}>
      <div className={`${PICTURE_BG} h-28 w-full`}>
        <Picture ad={ad} iconSize="size-10" />
      </div>
      <div className="flex min-h-0 flex-1 flex-col gap-1 p-3">
        <AdTag advertiser={ad.advertiser} />
        <span className="line-clamp-2 shrink-0 font-semibold leading-snug">{ad.headline}</span>
        {ad.body && <span className="line-clamp-1 shrink-0 text-sm leading-snug text-zinc-600 dark:text-zinc-400">{ad.body}</span>}
        <span className="mt-auto flex justify-end">
          <span className={CTA}>{ad.ctaLabel}</span>
        </span>
      </div>
    </Shell>
  );
}

// The side columns on wide screens: 160px across, 620px tall.
export function AdTower({ ad, href }: { ad: AdCreative; href?: string }) {
  return (
    <Shell ad={ad} href={href} className={`${FRAME} ${AD_HEIGHT.tower} w-40 flex-col rounded-xl`}>
      <div className={`${PICTURE_BG} h-40 w-full`}>
        <Picture ad={ad} iconSize="size-10" />
      </div>
      <div className="flex min-h-0 flex-1 flex-col gap-2 p-3">
        <AdTag advertiser={ad.advertiser} />
        <span className="line-clamp-4 text-lg font-bold leading-snug">{ad.headline}</span>
        {ad.body && <span className="line-clamp-[8] text-sm leading-snug text-zinc-600 dark:text-zinc-400">{ad.body}</span>}
        <span className="mt-auto flex justify-center">
          <span className={CTA}>{ad.ctaLabel}</span>
        </span>
      </div>
    </Shell>
  );
}

export const AD_VIEWS: Record<AdLayout, typeof AdRow> = { row: AdRow, strip: AdStrip, card: AdTallCard, box: AdBox, tower: AdTower };
