"use client";

import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { withoutListFilters } from "@/lib/deal-filters";
import EmptyState from "@/components/EmptyState";

// Shown instead of the page's own empty message when a filter (hearts, or the
// ticked stores/categories) is what emptied the list, with a way back.
export default function FilterEmpty({ minHearts, narrowed }: { minHearts?: number; narrowed?: boolean }) {
  const pathname = usePathname();
  const params = useSearchParams();
  return (
    <EmptyState icon="search">
      <p>{narrowed ? "No deals here match your filters." : `No deals here have ${minHearts}+ hearts.`}</p>
      <Link
        href={withoutListFilters(pathname, new URLSearchParams(params.toString()))}
        scroll={false}
        className="font-semibold text-orange-700 hover:underline dark:text-orange-400"
      >
        {narrowed ? "Clear filters" : "Clear the hearts filter"}
      </Link>
    </EmptyState>
  );
}
