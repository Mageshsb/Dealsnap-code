"use client";

import { useEffect, useId, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import {
  descriptionParts,
  keepAsWords,
  newToken,
  parseMarks,
  plainDescription,
  textBlocks,
  writeMarks,
  type Mark,
} from "@/lib/deal-text";
import Icon, { type IconName } from "./Icon";
import { shrinkPhoto } from "./DealPhotoField";
import { MENTION, rank } from "./community/MentionPicker";

// One box of words and pictures, like hotukdeals' editor, for a deal's "Why is
// it a good deal?" and Community posts:
// a small toolbar for bold, italic, crossed-out words, bullet points and
// numbered steps, and pictures (a screenshot of where the code goes, how to
// redeem it) that sit between the lines where the poster puts them. "Picture"
// or pasting one puts it below the line being typed on; × takes it out. In a
// Community thread, typing "@" offers the people in it (as the plain reply box
// did, components/community/MentionPicker.tsx).
//
// What's kept is plain text with a few marks and a line per picture
// (lib/deal-text.ts), never HTML: the box is drawn from that text with our own
// elements, and read back into it after every change. Pasting only ever adds
// plain words, so formatting comes from the toolbar (or ⌘B / Ctrl+B) alone.
// New pictures are shrunk here (like the deal photo), wait in `pictures` (and
// a saved draft) as data: addresses, and go with the form as files named by
// their key (`filesName`), or are handed over by picturesToFiles for a box
// sent without a form.

// A picture over this (as sent) is made again at a lower quality, so four of
// them and the photo always fit in one post (the server takes 4MB).
const BIG_PICTURE_CHARS = 1_100_000;

const newKey = () =>
  Array.from(crypto.getRandomValues(new Uint8Array(6)), (b) => (b % 36).toString(36)).join("") + Date.now().toString(36).slice(-4);

const LINE = "min-h-[1.5em]";
const LIST_UL = "my-1 list-disc pl-5";
const LIST_OL = "my-1 list-decimal pl-5";
const FIGURE = "relative my-2 w-fit max-w-full select-none";
const IMAGE = "block max-h-56 max-w-full rounded-lg border border-zinc-200 bg-white object-contain dark:border-zinc-700";
const REMOVE = "absolute right-1.5 top-1.5 flex size-7 items-center justify-center rounded-full bg-zinc-900/80 text-white hover:bg-zinc-900";
const CROSS =
  '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>';

// ---- drawing the box from the text -----------------------------------------

// A line's words with their formatting, as elements (text is only ever set as
// text, never as HTML).
function appendMarks(el: HTMLElement, line: string) {
  for (const mark of parseMarks(line)) {
    let node: Node = document.createTextNode(mark.text);
    if (mark.italic) node = wrap("i", node);
    if (mark.bold) node = wrap("b", node);
    if (mark.strike) node = wrap("s", node);
    el.appendChild(node);
  }
}

function wrap(tag: string, child: Node): HTMLElement {
  const el = document.createElement(tag);
  el.appendChild(child);
  return el;
}

function lineEl(line: string): HTMLDivElement {
  const div = document.createElement("div");
  div.className = LINE;
  if (line) appendMarks(div, line);
  else div.appendChild(document.createElement("br"));
  return div;
}

function figureEl(token: string, src: string, n: number): HTMLElement {
  const figure = document.createElement("figure");
  figure.contentEditable = "false";
  figure.dataset.token = token;
  figure.className = FIGURE;
  const img = document.createElement("img");
  img.src = src;
  img.alt = `Picture ${n}`;
  img.className = IMAGE;
  img.draggable = false;
  const remove = document.createElement("button");
  remove.type = "button";
  remove.dataset.remove = "";
  remove.className = REMOVE;
  remove.setAttribute("aria-label", `Remove picture ${n}`);
  remove.innerHTML = CROSS;
  figure.append(img, remove);
  return figure;
}

function draw(root: HTMLElement, value: string, pictures: Record<string, string>) {
  root.replaceChildren();
  let n = 0;
  for (const part of descriptionParts(value)) {
    if (part.type !== "text") {
      n++;
      const src = part.type === "shot" ? `/picture/${part.id}/sm.webp` : pictures[part.key];
      root.append(src ? figureEl(part.type === "shot" ? `[[shot:${part.id}]]` : newToken(part.key), src, n) : lineEl(""));
      continue;
    }
    textBlocks(part.text).forEach((block, i) => {
      // A blank line between paragraphs, as typed.
      if (i > 0 && block.type === "p") root.append(lineEl(""));
      if (block.type === "p") for (const line of block.lines) root.append(lineEl(line));
      else {
        const list = document.createElement(block.type);
        list.className = block.type === "ul" ? LIST_UL : LIST_OL;
        for (const item of block.items) {
          const li = document.createElement("li");
          if (item) appendMarks(li, item);
          else li.appendChild(document.createElement("br"));
          list.appendChild(li);
        }
        root.append(list);
      }
    });
  }
  if (!root.lastChild || isFigure(root.lastChild)) root.append(lineEl(""));
}

// ---- reading the box back into text ------------------------------------------

const isFigure = (n: Node | null): n is HTMLElement => n instanceof HTMLElement && n.tagName === "FIGURE" && !!n.dataset.token;
const isList = (n: Node): n is HTMLElement => n instanceof HTMLElement && (n.tagName === "UL" || n.tagName === "OL");
const isBlock = (n: Node) => n instanceof HTMLElement && /^(DIV|P|LI|H[1-6]|BLOCKQUOTE|SECTION)$/.test(n.tagName);

type Style = Omit<Mark, "text">;

// The formatting an element adds: our own <b>/<i>/<s>, the browser's own
// shortcuts' <strong>/<em>, or a style it chose to write instead.
function styleOf(el: HTMLElement, style: Style): Style {
  const tag = el.tagName;
  const css = el.style;
  return {
    bold: style.bold || tag === "B" || tag === "STRONG" || Number(css.fontWeight) >= 600 || css.fontWeight === "bold",
    italic: style.italic || tag === "I" || tag === "EM" || css.fontStyle === "italic",
    strike: style.strike || tag === "S" || tag === "STRIKE" || tag === "DEL" || css.textDecoration.includes("line-through"),
  };
}

// A block's lines, each written with its marks. List items come back with
// their "- " or "1. ".
function blockLines(el: Node, style: Style = {}): string[] {
  const out: string[] = [];
  let runs: Mark[] = [];
  const endLine = () => {
    out.push(keepAsWords(writeMarks(runs)));
    runs = [];
  };
  const walk = (node: Node, s: Style) => {
    const kids = Array.from(node.childNodes);
    kids.forEach((n, i) => {
      if (n.nodeType === Node.TEXT_NODE) runs.push({ text: n.textContent ?? "", ...s });
      else if (n.nodeName === "BR") {
        // A block's last <br> only keeps an empty line open; any other is a break.
        if (i < kids.length - 1 || node !== el) endLine();
      } else if (isFigure(n)) {
        if (runs.length) endLine();
        out.push(n.dataset.token!);
      } else if (isList(n)) {
        if (runs.length) endLine();
        Array.from(n.children).forEach((li, at) => {
          const words = blockLines(li, s).filter((l) => l !== "");
          out.push(`${n.tagName === "UL" ? "-" : `${at + 1}.`} ${words.join(" ")}`);
        });
      } else if (isBlock(n)) {
        if (runs.length) endLine();
        out.push(...blockLines(n, s));
      } else if (n instanceof HTMLElement) walk(n, styleOf(n, s));
    });
  };
  walk(el, style);
  if (runs.length || !out.length) endLine();
  return out;
}

function serialize(root: HTMLElement): string {
  const lines: string[] = [];
  for (const n of Array.from(root.childNodes)) {
    if (isFigure(n)) lines.push(n.dataset.token!);
    else if (isList(n) || isBlock(n)) lines.push(...(isList(n) ? blockLines(wrapIn(n)) : blockLines(n)));
    else if (n.nodeName !== "BR") lines.push(keepAsWords(writeMarks([{ text: n.textContent ?? "" }])));
  }
  return lines
    .map((l) => l.replace(/ /g, " ").replace(/\s+$/, ""))
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

// A list at the top of the box is read as the only thing in a block.
function wrapIn(list: HTMLElement): HTMLElement {
  const holder = document.createElement("div");
  holder.appendChild(list.cloneNode(true));
  return holder;
}

// ---- the toolbar ---------------------------------------------------------------

const TOOLS: { command: string; label: string; icon: IconName; keys?: string }[] = [
  { command: "bold", label: "Bold", icon: "bold", keys: "B" },
  { command: "italic", label: "Italic", icon: "italic", keys: "I" },
  { command: "strikeThrough", label: "Crossed out", icon: "strikethrough" },
  { command: "insertUnorderedList", label: "Bullet points", icon: "list" },
  { command: "insertOrderedList", label: "Numbered steps", icon: "list-ordered" },
];

function ToolButton({ label, pressed, onUse, children }: { label: string; pressed?: boolean; onUse: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      aria-pressed={pressed}
      // Keep the cursor (and the phone's keyboard) in the box.
      onPointerDown={(e) => e.preventDefault()}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onUse}
      className={`flex size-10 shrink-0 items-center justify-center rounded-lg transition-colors sm:size-9 ${
        pressed
          ? "bg-orange-100 text-orange-800 dark:bg-orange-950/60 dark:text-orange-300"
          : "text-zinc-600 hover:bg-zinc-200/70 dark:text-zinc-300 dark:hover:bg-zinc-800"
      }`}
    >
      {children}
    </button>
  );
}

// The new pictures a box's text shows, as files named by their key, for a
// box sent without a form (a reply, an edit): append them as `field`.
export async function picturesToFiles(text: string, pictures: Record<string, string>): Promise<File[]> {
  const files: File[] = [];
  for (const part of descriptionParts(text)) {
    if (part.type !== "new" || !pictures[part.key]) continue;
    const blob = await (await fetch(pictures[part.key])).blob();
    files.push(new File([blob], `${part.key}.jpg`, { type: blob.type }));
  }
  return files;
}

export default function RichEditor({
  value,
  onChange,
  pictures,
  onPictures,
  placeholder,
  label = "Why is it a good deal?",
  maxPictures,
  fieldName,
  filesName,
  requiredId,
  mentionNames = [],
  onCtrlEnter,
  autoFocus = false,
  minHeight = "min-h-[7.5rem]",
}: {
  value: string;
  onChange: (value: string) => void;
  pictures: Record<string, string>;
  onPictures: (pictures: Record<string, string>) => void;
  placeholder: string;
  label?: string;
  // 0: no pictures (a new account, lib/post-pictures.ts mayAddPictures).
  maxPictures: number;
  // For a box inside a form: the text's name, the new pictures' name, and
  // the id of an invisible required box that stops an empty form being sent.
  fieldName?: string;
  filesName?: string;
  requiredId?: string;
  // People who can be @mentioned (a Community thread's posters).
  mentionNames?: string[];
  onCtrlEnter?: () => void;
  autoFocus?: boolean;
  minHeight?: string;
}) {
  const box = useRef<HTMLDivElement>(null);
  const sent = useRef<HTMLInputElement>(null);
  // The text the box last reported, so a change made outside it (the store's
  // description added) redraws it, and its own changes don't.
  const shown = useRef<string | null>(null);
  // Where the cursor was, so "Picture" (which opens the phone's picker) still
  // knows which line it's on.
  const caret = useRef<Range | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  // Which tools apply where the cursor is, to show them pressed.
  const [active, setActive] = useState<Record<string, boolean>>({});
  const parts = descriptionParts(value);
  const count = parts.filter((p) => p.type !== "text").length;
  const empty = !plainDescription(value) && count === 0;
  const newKeys = parts.flatMap((p) => (p.type === "new" ? [p.key] : [])).join();
  // "@" being typed: what follows it, and where it is.
  const [mention, setMention] = useState<{ node: Text; at: number; end: number; typed: string } | null>(null);
  const [mentionIndex, setMentionIndex] = useState(0);
  const [mentionClosed, setMentionClosed] = useState<Text | null>(null);
  const listId = useId();
  const matches = mention && mention.node !== mentionClosed ? rank(mentionNames, mention.typed) : [];
  const activeMatch = Math.min(mentionIndex, Math.max(0, matches.length - 1));

  // Draw the box from the text: on arrival, and when the text is changed
  // from outside it.
  useEffect(() => {
    const root = box.current;
    if (!root || value === shown.current) return;
    shown.current = value;
    draw(root, value, pictures);
  }, [value, pictures]);

  useEffect(() => {
    if (autoFocus) box.current?.focus();
  }, [autoFocus]);

  const mentionNamesRef = useRef(mentionNames);
  useEffect(() => {
    mentionNamesRef.current = mentionNames;
  }, [mentionNames]);

  // Keep track of where the cursor is inside the box, and what's on there.
  useEffect(() => {
    const look = () => {
      const sel = document.getSelection();
      if (!sel?.rangeCount || !box.current?.contains(sel.anchorNode)) return;
      caret.current = sel.getRangeAt(0).cloneRange();
      setActive(Object.fromEntries(TOOLS.map((t) => [t.command, safeState(t.command)])));
      // An "@name" being typed just before the cursor.
      const node = sel.anchorNode;
      if (mentionNamesRef.current.length && sel.isCollapsed && node?.nodeType === Node.TEXT_NODE) {
        const before = (node.textContent ?? "").slice(0, sel.anchorOffset);
        const m = MENTION.exec(before);
        if (m) {
          setMention({ node: node as Text, at: sel.anchorOffset - m[2].length - 1, end: sel.anchorOffset, typed: m[2] });
          return;
        }
      }
      setMention(null);
    };
    document.addEventListener("selectionchange", look);
    return () => document.removeEventListener("selectionchange", look);
  }, []);

  // Puts the picked name in place of the "@…" typed, through the browser's
  // own typing so Undo still works.
  function pickMention(name: string) {
    if (!mention) return;
    const sel = document.getSelection();
    const range = document.createRange();
    range.setStart(mention.node, mention.at);
    range.setEnd(mention.node, Math.min(mention.end, mention.node.length));
    sel?.removeAllRanges();
    sel?.addRange(range);
    document.execCommand("insertText", false, `@${name} `);
    setMention(null);
    setMentionIndex(0);
    report();
  }

  // Arrow keys, Enter or Tab and Escape for the list of names.
  function mentionKey(e: KeyboardEvent<HTMLDivElement>): boolean {
    if (!matches.length) return false;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      setMentionIndex((activeMatch + (e.key === "ArrowDown" ? 1 : matches.length - 1)) % matches.length);
      return true;
    }
    if ((e.key === "Enter" && !e.metaKey && !e.ctrlKey) || e.key === "Tab") {
      e.preventDefault();
      pickMention(matches[activeMatch]);
      return true;
    }
    if (e.key === "Escape") {
      e.preventDefault();
      setMentionClosed(mention!.node);
      return true;
    }
    return false;
  }

  // The new pictures go with the form as files, named by their key.
  useEffect(() => {
    const input = sent.current;
    if (!input) return;
    const keys = newKeys.split(",").filter((key) => pictures[key]);
    let stale = false;
    void (async () => {
      const transfer = new DataTransfer();
      for (const key of keys) {
        const blob = await (await fetch(pictures[key])).blob();
        transfer.items.add(new File([blob], `${key}.jpg`, { type: blob.type }));
      }
      if (!stale) input.files = transfer.files;
    })();
    return () => {
      stale = true;
    };
  }, [newKeys, pictures]);

  function report() {
    const root = box.current;
    if (!root) return;
    // Words typed straight into an emptied box are put on a line of their own.
    for (const n of Array.from(root.childNodes)) {
      if (n.nodeType === Node.TEXT_NODE && n.textContent) {
        const div = document.createElement("div");
        div.className = LINE;
        root.insertBefore(div, n);
        div.appendChild(n);
      }
    }
    const next = serialize(root);
    shown.current = next;
    onChange(next);
  }

  function use(command: string) {
    box.current?.focus({ preventScroll: true });
    // Back to where the cursor was, if the focus wandered.
    const sel = document.getSelection();
    if (caret.current && sel && !box.current?.contains(sel.anchorNode)) {
      sel.removeAllRanges();
      sel.addRange(caret.current);
    }
    document.execCommand(command);
    setActive(Object.fromEntries(TOOLS.map((t) => [t.command, safeState(t.command)])));
    report();
  }

  // Puts pictures below the line the cursor is on (or at the end), each
  // followed by an empty line to carry on typing.
  async function addPictures(files: File[]) {
    const room = maxPictures - count;
    const images = files.filter((f) => f.type.startsWith("image/"));
    if (!images.length || maxPictures <= 0) return;
    setError(images.length > room ? `Up to ${maxPictures} pictures, so we've added ${room > 0 ? `the first ${room}` : "none"}.` : "");
    if (room <= 0) return;
    setBusy(true);
    try {
      const added: Record<string, string> = {};
      for (const file of images.slice(0, room)) {
        let src = await shrinkPhoto(file);
        if (src.length > BIG_PICTURE_CHARS) src = await shrinkPhoto(file, 0.7);
        added[newKey()] = src;
      }
      const root = box.current!;
      // The top-level line the cursor was on (a list counts as one).
      let at: Node | null = caret.current && root.contains(caret.current.startContainer) ? caret.current.startContainer : null;
      while (at && at.parentNode !== root) at = at.parentNode;
      let n = count;
      let after: Node | null = at;
      for (const [key, src] of Object.entries(added)) {
        const figure = figureEl(newToken(key), src, ++n);
        if (after && after.nextSibling) root.insertBefore(figure, after.nextSibling);
        else root.appendChild(figure);
        after = figure;
      }
      // An empty line after them to type on, with the cursor in it.
      let next = (after as Node).nextSibling;
      if (!next || isFigure(next) || isList(next) || next.textContent) {
        next = lineEl("");
        root.insertBefore(next, (after as Node).nextSibling);
      }
      // A line left empty where the cursor was isn't needed above a picture.
      if (at && !isFigure(at) && !isList(at) && !at.textContent && root.childNodes.length > 2) at.parentNode?.removeChild(at);
      const range = document.createRange();
      range.setStart(next, 0);
      range.collapse(true);
      caret.current = range;
      onPictures({ ...pictures, ...added });
      report();
      root.focus({ preventScroll: true });
      document.getSelection()?.removeAllRanges();
      document.getSelection()?.addRange(range);
      (next as HTMLElement).scrollIntoView?.({ block: "nearest" });
    } catch (e) {
      setError(e instanceof Error ? e.message : "We couldn't open that picture.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-w-0 flex-col gap-1.5">
      {/* What's sent: the text (with its marks and picture lines), and the new pictures. */}
      {fieldName && <input type="hidden" name={fieldName} value={value} />}
      {filesName && <input ref={sent} type="file" name={filesName} multiple hidden tabIndex={-1} aria-hidden />}
      {/* For the form's own check that some words were written: an invisible
          box that hands the focus to the real one. */}
      {requiredId && (
        <textarea
          id={requiredId}
          required
          tabIndex={-1}
          aria-hidden
          value={plainDescription(value)}
          onChange={() => {}}
          onFocus={() => box.current?.focus()}
          className="pointer-events-none absolute h-px w-px opacity-0"
        />
      )}

      {/* One frame round the toolbar and the box, tinted and outlined like
          the form's other boxes (data-editor in globals.css). */}
      <div
        data-editor
        className="overflow-hidden rounded-lg border border-zinc-300 bg-zinc-50 focus-within:border-orange-500 dark:border-zinc-700 dark:bg-zinc-950"
      >
        <div role="toolbar" aria-label="Formatting" className="flex items-center gap-0.5 border-b border-zinc-200 px-1 py-1 dark:border-zinc-800">
          {TOOLS.map((tool, i) => (
            <span key={tool.command} className="contents">
              {i === 3 && <span aria-hidden className="mx-1 h-5 w-px bg-zinc-200 dark:bg-zinc-700" />}
              <ToolButton label={tool.keys ? `${tool.label} (Ctrl+${tool.keys})` : tool.label} pressed={!!active[tool.command]} onUse={() => use(tool.command)}>
                <Icon name={tool.icon} className="size-[18px]" />
              </ToolButton>
            </span>
          ))}
          <span aria-hidden className="mx-1 h-5 w-px bg-zinc-200 dark:bg-zinc-700" />
          {maxPictures <= 0 ? null : count < maxPictures ? (
            <label
              title="Add a picture"
              onPointerDown={(e) => e.preventDefault()}
              className="flex h-10 cursor-pointer items-center gap-1.5 rounded-lg px-2 text-sm font-medium text-zinc-600 transition-colors hover:bg-zinc-200/70 has-focus-visible:ring-2 has-focus-visible:ring-orange-500 sm:h-9 dark:text-zinc-300 dark:hover:bg-zinc-800"
            >
              <input
                type="file"
                multiple
                accept="image/jpeg,image/png,image/webp,image/gif,image/avif,image/heic"
                className="sr-only"
                onChange={(e) => {
                  void addPictures(Array.from(e.target.files ?? []));
                  e.target.value = "";
                }}
              />
              <Icon name={busy ? "loader" : "image"} className={`size-[18px] ${busy ? "animate-spin" : ""}`} />
              <span className="max-[359px]:sr-only">{busy ? "Adding…" : "Picture"}</span>
            </label>
          ) : (
            <span className="px-2 text-xs text-zinc-500 dark:text-zinc-400">{maxPictures} pictures added</span>
          )}
          {count > 0 && count < maxPictures && <span className="ml-auto pr-2 text-xs tabular-nums text-zinc-500 dark:text-zinc-400">{count}/{maxPictures}</span>}
        </div>

        <div className="relative">
          {matches.length > 0 && (
            <div className="absolute bottom-full left-0 z-20 mb-1 w-64 max-w-full overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-lg dark:border-zinc-700 dark:bg-zinc-900">
              <p className="border-b border-zinc-100 px-3 py-1.5 text-xs text-zinc-500 dark:border-zinc-800">People in this thread</p>
              <ul id={listId} role="listbox" aria-label="People in this thread">
                {matches.map((name, i) => (
                  <li
                    key={name}
                    id={`${listId}-${i}`}
                    role="option"
                    aria-selected={i === activeMatch}
                    // Keeps the cursor in the box while the name is tapped.
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => pickMention(name)}
                    className={`flex min-h-10 cursor-pointer items-center px-3 text-sm ${i === activeMatch ? "bg-orange-50 font-medium text-orange-700 dark:bg-orange-950/30 dark:text-orange-300" : "hover:bg-zinc-50 dark:hover:bg-zinc-800"}`}
                  >
                    <span className="truncate">@{name}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div
            ref={box}
            contentEditable
            suppressContentEditableWarning
            role="textbox"
            aria-multiline="true"
            aria-label={label}
            {...(matches.length
              ? { "aria-autocomplete": "list" as const, "aria-controls": listId, "aria-expanded": true, "aria-activedescendant": `${listId}-${activeMatch}` }
              : {})}
            spellCheck
            onInput={report}
            onFocus={() => document.execCommand("defaultParagraphSeparator", false, "div")}
            onKeyDown={(e) => {
              if (mentionKey(e)) return;
              // The browser's own ⌘U would underline, which isn't kept.
              if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "u") e.preventDefault();
              if (onCtrlEnter && e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                e.preventDefault();
                onCtrlEnter();
              }
            }}
            onClick={(e) => {
              const figure = (e.target as HTMLElement).closest("[data-remove]")?.closest("figure");
              if (!figure) return;
              const next = figure.nextSibling;
              figure.remove();
              // Two empty lines meeting where the picture was become one.
              if (next && !isFigure(next) && !next.textContent && next.previousSibling && !next.previousSibling.textContent && !isFigure(next.previousSibling)) {
                next.parentNode?.removeChild(next);
              }
              report();
            }}
            onPaste={(e) => {
              e.preventDefault();
              const files = Array.from(e.clipboardData.files);
              if (files.some((f) => f.type.startsWith("image/"))) {
                void addPictures(files);
                return;
              }
              // Words only, as plain text, whatever they were copied from.
              document.execCommand("insertText", false, e.clipboardData.getData("text/plain"));
            }}
            onDrop={(e) => {
              e.preventDefault();
              void addPictures(Array.from(e.dataTransfer.files));
            }}
            onDragOver={(e) => e.preventDefault()}
            className={`block ${minHeight} w-full whitespace-pre-wrap break-words px-3 py-2 text-base outline-none lg:text-sm [&_ol]:my-1 [&_ol]:list-decimal [&_ol]:pl-5 [&_ul]:my-1 [&_ul]:list-disc [&_ul]:pl-5`}
          />
          {empty && (
            <p aria-hidden className="pointer-events-none absolute left-3 right-3 top-2 text-base text-zinc-400 lg:text-sm dark:text-zinc-500">
              {placeholder}
            </p>
          )}
        </div>
      </div>
      {error && <p className="text-xs text-amber-700 dark:text-amber-400">{error}</p>}
    </div>
  );
}

// Whether a tool applies where the cursor is (some browsers throw for some).
function safeState(command: string): boolean {
  try {
    return document.queryCommandState(command);
  } catch {
    return false;
  }
}
