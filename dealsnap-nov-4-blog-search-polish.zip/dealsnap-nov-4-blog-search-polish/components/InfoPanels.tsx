import Link from "next/link";
import { filledFacts, possessive, type StoreDetails } from "@/lib/store-details";
import Icon from "./Icon";

// What the ⓘ button beside a page's title opens (see InfoToggle).

// What the ⓘ panel of a store, category or tag shows about the Community.
export type PanelDiscussions = { items: { title: string; href: string; replies: number }[]; startHref: string; name: string };

const sectionTitle = "text-xs font-semibold uppercase tracking-wide text-zinc-500";
const linkChip =
  "rounded-full border border-zinc-200 px-3 py-1.5 text-sm font-medium text-zinc-700 hover:border-orange-400 hover:text-orange-600 dark:border-zinc-700 dark:text-zinc-200";

// A store: the about text, then each fact as the question shoppers ask ("Does
// Argos price match?") with its answer. The same questions go to search
// engines as FAQ data, so everything they read is visible here too. A store
// nobody has written up yet gets a short automatic intro instead.
export function StorePanel({
  storeName,
  details,
  categories,
  guides,
  discussions,
}: {
  storeName: string;
  details?: StoreDetails;
  categories: string[];
  guides: { title: string; href: string }[];
  discussions?: PanelDiscussions;
}) {
  const facts = filledFacts(details);
  return (
    <div className="flex flex-col gap-4">
      <h2 className={sectionTitle}>About {storeName}</h2>
      {details?.about ? (
        <p className="text-sm leading-relaxed text-zinc-700 dark:text-zinc-300">{details.about}</p>
      ) : (
        !facts.length && (
          <p className="text-sm leading-relaxed text-zinc-700 dark:text-zinc-300">
            {storeName} deals found and rated by the DealSnap community{categories.length > 0 && <>, mostly in {listOf(categories)}</>}.
            The ones people love most rise to the top. Tap the bell to hear about new ones.
          </p>
        )
      )}
      {facts.length > 0 && (
        <div className="grid grid-cols-1 gap-x-6 gap-y-3 sm:grid-cols-2">
          {facts.map((f) => (
            <div key={f.key} className="flex gap-2.5">
              <Icon name={f.icon} className="mt-0.5 size-4 text-orange-700 dark:text-orange-400" />
              <div className="flex min-w-0 flex-col gap-0.5">
                <h3 className="text-sm font-semibold">{f.question(storeName)}</h3>
                <p className="text-sm leading-relaxed text-zinc-600 dark:text-zinc-400">{f.detail}</p>
              </div>
            </div>
          ))}
        </div>
      )}
      <Guides guides={guides} />
      {discussions && <Discussions {...discussions} />}
      {facts.length > 0 && (
        <p className="text-xs leading-relaxed text-zinc-500 dark:text-zinc-400">
          {details?.updatedAt && <>Details checked {new Date(details.updatedAt).toLocaleDateString("en-GB", { month: "long", year: "numeric" })}. </>}
          Stores change their terms from time to time, so check on {possessive(storeName)} own site before you buy.
        </p>
      )}
    </div>
  );
}

// Conversations in the Community about this store, category or tag, and a way
// to start one. Always shown (a quiet way in), with the latest three when
// there are any.
function Discussions({ items, startHref, name }: PanelDiscussions) {
  return (
    <section className="flex flex-col gap-2">
      <h3 className="text-sm font-semibold">Discussions about {name}</h3>
      {items.length > 0 && (
        <ul className="flex flex-col gap-1.5">
          {items.map((d) => (
            <li key={d.href} className="flex min-w-0 items-baseline justify-between gap-3">
              <Link href={d.href} className="min-w-0 truncate text-sm font-medium text-orange-700 hover:underline dark:text-orange-400">
                <Icon name="comment" className="mr-1.5" />
                {d.title}
              </Link>
              <span className="shrink-0 text-xs text-zinc-500 dark:text-zinc-400">
                {d.replies} {d.replies === 1 ? "reply" : "replies"}
              </span>
            </li>
          ))}
        </ul>
      )}
      <Link href={startHref} className="w-fit text-sm font-medium text-zinc-600 hover:text-orange-600 hover:underline dark:text-zinc-300">
        Start a discussion about {name}
      </Link>
    </section>
  );
}

function Guides({ guides }: { guides: { title: string; href: string }[] }) {
  if (!guides.length) return null;
  return (
    <section className="flex flex-col gap-2">
      <h3 className="text-sm font-semibold">Buying guides</h3>
      <ul className="flex flex-col gap-1.5">
        {guides.map((g) => (
          <li key={g.href}>
            <Link href={g.href} className="text-sm font-medium text-orange-700 hover:underline dark:text-orange-400">
              <Icon name="book-open" className="mr-1.5" />
              {g.title}
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}

// "a, b and c"
function listOf(items: string[]): string {
  return items.length > 1 ? `${items.slice(0, -1).join(", ")} and ${items[items.length - 1]}` : items[0] ?? "";
}

// A category or tag: where its deals come from, and our guides on it.
export function TopicPanel({
  name,
  stores,
  guides,
  discussions,
}: {
  name: string;
  stores: { name: string; href: string }[];
  guides: { title: string; href: string }[];
  discussions?: PanelDiscussions;
}) {
  const shopList = stores.length > 1 ? listOf(stores.slice(0, 3).map((s) => s.name)) : "";
  return (
    <div className="flex flex-col gap-4">
      <h2 className={sectionTitle}>About {name} deals</h2>
      <p className="text-sm leading-relaxed text-zinc-700 dark:text-zinc-300">
        {name} deals found and rated by the DealSnap community{shopList && `, from stores like ${shopList}`}. The ones people love
        most rise to the top. Tap the bell to hear about new ones.
      </p>
      {stores.length >= 2 && (
        <section className="flex flex-col gap-2">
          <h3 className="text-sm font-semibold">Top stores</h3>
          <div className="flex flex-wrap gap-2">
            {stores.map((s) => (
              <Link key={s.href} href={s.href} className={linkChip}>
                {s.name}
              </Link>
            ))}
          </div>
        </section>
      )}
      <Guides guides={guides} />
      {discussions && <Discussions {...discussions} />}
    </div>
  );
}

// A brand: what it covers, where its deals come from, and the brand's own shop
// page when there is one (the Apple brand page lists Apple products from every
// shop; the Apple store page only Apple's own site).
export function BrandPanel({
  name,
  categories,
  lines,
  stores,
  ownStore,
}: {
  name: string;
  categories: string[];
  lines: string[];
  stores: { name: string; href: string }[];
  ownStore?: { name: string; href: string };
}) {
  return (
    <div className="flex flex-col gap-4">
      <h2 className={sectionTitle}>About {name}</h2>
      <p className="text-sm leading-relaxed text-zinc-700 dark:text-zinc-300">
        {name} products from every store, found and rated by the DealSnap community
        {lines.length > 0 ? <>, including {listOf(lines)}</> : categories.length > 0 && <>, mostly in {listOf(categories)}</>}. The ones people
        love most rise to the top. Tap the bell to hear about new ones.
      </p>
      {ownStore && (
        <p className="text-sm text-zinc-700 dark:text-zinc-300">
          Buying from {possessive(name)} own store?{" "}
          <Link href={ownStore.href} className="font-medium text-orange-700 hover:underline dark:text-orange-400">
            See the {ownStore.name} store page
          </Link>
        </p>
      )}
      {stores.length >= 2 && (
        <section className="flex flex-col gap-2">
          <h3 className="text-sm font-semibold">Top stores</h3>
          <div className="flex flex-wrap gap-2">
            {stores.map((s) => (
              <Link key={s.href} href={s.href} className={linkChip}>
                {s.name}
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
