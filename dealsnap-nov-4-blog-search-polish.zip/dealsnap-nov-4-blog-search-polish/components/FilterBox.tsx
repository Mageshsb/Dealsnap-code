"use client";

import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useExpiredFilter } from "./ExpiredFilterProvider";
import FacetFilter from "./FacetFilter";
import TypeFilter from "./TypeFilter";
import Icon, { HeartIcon } from "./Icon";
import { HEART_TIERS, countNarrow, parseMinHearts, withMinHearts, withoutListFilters, type Facet } from "@/lib/deal-filters";

const chip = "flex items-center justify-center gap-1 whitespace-nowrap rounded-full border py-1.5 text-center text-sm font-medium leading-5 transition-colors";
const keyWord = "font-bold text-zinc-900 dark:text-zinc-100";

// The filter panel's contents: the Deal type tiles first (what kind of deal
// is the bigger choice; vouchers are one tap away), then a minimum-hearts cut,
// the page's dropdowns (Store, Category or Brand) and two on-this-device switches. Hearts options
// are plain links that set ?hearts=N, so the server re-renders the list.
export default function FilterBox({ facets = [] }: { facets?: Facet[] }) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const { showExpired, setShowExpired, hideLocal, setHideLocal } = useExpiredFilter();
  const active = parseMinHearts(params.get("hearts"));
  const hrefFor = (n: number) => withMinHearts(pathname, new URLSearchParams(params.toString()), n);
  const narrowed = countNarrow(params) > 0;
  // The two switches below are settings kept on this device, not filters on
  // this list, so they aren't counted and "Clear all filters" leaves them be.
  const activeCount = (active > 0 ? 1 : 0) + countNarrow(params);
  const anyActive = activeCount > 0;

  // Hearts, the deal type and the dropdowns live in the address.
  function clearAll() {
    if (active > 0 || narrowed) router.push(withoutListFilters(pathname, new URLSearchParams(params.toString())), { scroll: false });
  }

  const type = facets.find((f) => f.param === "type");

  return (
    <>
    {type && <TypeFilter facet={type} />}

    <section className="flex flex-col gap-2">
      {/* The chips share the line in columns ("Any" a little narrower, as
          it has no heart), so all four sit on one line even on narrow phones,
          with spare room around each label. */}
      <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Minimum hearts</h3>
      <div className="grid gap-1.5" style={{ gridTemplateColumns: `minmax(0, 3fr) repeat(${HEART_TIERS.length}, minmax(0, 4fr))` }}>
        {[0, ...HEART_TIERS].map((n) => (
          <Link
            key={n}
            href={hrefFor(n)}
            scroll={false}
            aria-current={active === n ? "true" : undefined}
            className={`${chip} ${
              active === n
                ? "border-zinc-900 bg-zinc-900 text-white dark:border-zinc-100 dark:bg-zinc-100 dark:text-zinc-900"
                : "border-zinc-200 text-zinc-700 hover:border-orange-400 hover:text-orange-600 dark:border-zinc-700 dark:text-zinc-200"
            }`}
          >
            {n === 0 ? "Any" : <><HeartIcon className="size-3.5" />{n}+</>}
          </Link>
        ))}
      </div>
    </section>

    {facets
      .filter((f) => f.param !== "type")
      .map((f) => (
        <FacetFilter key={f.param} facet={f} />
      ))}

    {/* These two are remembered on this device (not in the address) and apply
        to every deals page, so they have their own heading, and Clear all
        filters leaves them be. The word that matters in each is in bold. */}
    <section className="flex flex-col gap-3">
      <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">On every deals page</h3>
      <label className="flex cursor-pointer items-center justify-between gap-3 text-sm text-zinc-700 dark:text-zinc-300">
        <span>
          Show <strong className={keyWord}>expired</strong> deals
        </span>
        <input
          type="checkbox"
          checked={showExpired}
          onChange={(e) => setShowExpired(e.target.checked)}
          className="h-4 w-4 accent-orange-500"
        />
      </label>
      <label className="flex cursor-pointer items-center justify-between gap-3 text-sm text-zinc-700 dark:text-zinc-300">
        <span>
          Hide <strong className={keyWord}>in-store only</strong> deals
        </span>
        <input
          type="checkbox"
          checked={hideLocal}
          onChange={(e) => setHideLocal(e.target.checked)}
          className="h-4 w-4 accent-orange-500"
        />
      </label>
    </section>

    {/* Its own footer under a divider, as a full-width button: soft orange with
        the number of filters on, greyed out when there's nothing to clear. */}
    <div className="border-t border-zinc-100 pt-3 dark:border-zinc-800">
      <button
        type="button"
        onClick={clearAll}
        disabled={!anyActive}
        className="flex min-h-10 w-full items-center justify-center gap-2 rounded-xl border border-orange-200 bg-orange-50 px-3 text-sm font-semibold text-orange-700 transition-colors hover:bg-orange-100 disabled:cursor-default disabled:border-zinc-200 disabled:bg-transparent disabled:font-medium disabled:text-zinc-400 dark:border-orange-900/60 dark:bg-orange-950/40 dark:text-orange-400 dark:hover:bg-orange-950/70 dark:disabled:border-zinc-800 dark:disabled:bg-transparent dark:disabled:text-zinc-600"
      >
        <Icon name="x" className="size-4" />
        Clear all filters
        {anyActive && (
          <span className="rounded-full bg-orange-500 px-1.5 py-px text-xs font-bold tabular-nums text-white">{activeCount}</span>
        )}
      </button>
    </div>
    </>
  );
}
