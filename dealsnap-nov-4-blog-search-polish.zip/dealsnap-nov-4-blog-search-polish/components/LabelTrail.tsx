import Link from "next/link";
import { getTagByName } from "@/lib/categories";
import { slugify } from "@/lib/slug";
import Icon from "./Icon";

// The small "Electronics › Laptop › MacBook" trail, on the top line of a deal
// page beside "Back to deals" (so it adds no height). Plain links, one main
// path, always on one line: a name too long for the room is cut short rather
// than wrapping or pushing a phone screen sideways. A three-level path never
// fits a phone, so there it starts from the second level (Laptop › MacBook);
// the broad category is still one tap away on the full-width trail.
//
// A whole-store voucher or sale has no category (lib/deal-kinds.ts), so its
// trail is its store's instead: Stores › Argos.
export function labelTrail(category: string, tag?: string, store?: string): { name: string; href: string }[] {
  if (!category && store) return [{ name: "Stores", href: "/stores" }, { name: store, href: `/stores/${slugify(store)}` }];
  if (!category) return [];
  const info = tag ? getTagByName(tag) : undefined;
  const items = [{ name: info?.category.name ?? category, href: `/categories/${slugify(info?.category.name ?? category)}` }];
  if (info?.parent) items.push({ name: info.parent.name, href: `/tags/${slugify(info.parent.name)}` });
  if (info) items.push({ name: info.tag.name, href: `/tags/${slugify(info.tag.name)}` });
  return items;
}

export default function LabelTrail({ items }: { items: { name: string; href: string }[] }) {
  if (!items.length) return null;
  const deep = items.length > 2;
  return (
    <nav aria-label="Breadcrumb" className="flex min-w-0 items-center gap-1 text-xs text-zinc-500 sm:text-sm">
      {items.map((item, i) => (
        <span key={item.href} className={`min-w-0 items-center gap-1 ${deep && i === 0 ? "max-sm:hidden sm:flex" : "flex"}`}>
          {i > 0 && <Icon name="chevron-right" className={`size-3 shrink-0 text-zinc-500 dark:text-zinc-400 ${deep && i === 1 ? "max-sm:hidden" : ""}`} />}
          <Link href={item.href} className="truncate hover:text-zinc-900 hover:underline dark:hover:text-zinc-100">
            {item.name}
          </Link>
        </span>
      ))}
    </nav>
  );
}
