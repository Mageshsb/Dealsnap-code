"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import Link from "next/link";
import { useTaxonomy } from "./TaxonomyProvider";
import { slugify } from "@/lib/slug";
import Icon, { type IconName } from "./Icon";

const MENU_WIDTH = 256;

const footerTile =
  "flex min-h-10 items-center justify-center gap-1.5 rounded-lg border border-zinc-200 px-2 text-sm font-semibold text-zinc-700 transition-colors hover:border-orange-300 hover:bg-orange-50 hover:text-orange-700 dark:border-zinc-700 dark:text-zinc-200 dark:hover:border-orange-800 dark:hover:bg-orange-950/40 dark:hover:text-orange-400";

// The orange category button at the start of the category row. Always the same
// width: wide enough for every category name in full, with room to spare for
// Android's wider text (anything longer is cut short with "…"). The arrow is
// divided off so it reads as a dropdown. It scrolls away with the row, so its
// menu is drawn on top of the page rather than inside the row, where it would
// be cut off.
export default function CategorySwitcher({ activeSlug }: { activeSlug: string }) {
  const { groups } = useTaxonomy();
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const open = pos !== null;

  const options = [
    { slug: "all", href: "/", icon: "grid" as IconName, name: "All categories" },
    ...groups.map((g) => ({ slug: slugify(g.name), href: `/categories/${slugify(g.name)}`, icon: g.icon, name: g.name })),
  ];
  const current = options.find((o) => o.slug === activeSlug) ?? options[0];

  function toggle() {
    if (open || !buttonRef.current) {
      setPos(null);
      return;
    }
    const r = buttonRef.current.getBoundingClientRect();
    // Line up with the button, but never past either edge of the screen.
    const left = Math.max(8, Math.min(r.left, window.innerWidth - MENU_WIDTH - 8));
    setPos({ top: r.bottom + 6, left });
  }

  useEffect(() => {
    if (!open) return;
    const close = () => setPos(null);
    const inside = (t: EventTarget | null) =>
      t instanceof Node && (menuRef.current?.contains(t) || buttonRef.current?.contains(t));
    function onDown(e: MouseEvent) {
      if (!inside(e.target)) close();
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") close();
    }
    // Swiping the row or scrolling the page moves the button, so close rather
    // than leave the menu floating somewhere else. Scrolling the menu is fine.
    function onScroll(e: Event) {
      if (!(e.target instanceof Node && menuRef.current?.contains(e.target))) close();
    }
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    window.addEventListener("scroll", onScroll, true);
    window.addEventListener("resize", close);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
      window.removeEventListener("scroll", onScroll, true);
      window.removeEventListener("resize", close);
    };
  }, [open]);

  return (
    <>
      <button
        ref={buttonRef}
        type="button"
        onClick={toggle}
        aria-haspopup="true"
        aria-expanded={open}
        aria-label={`Category: ${current.name}. Choose a category`}
        className="flex h-8 w-64 items-center overflow-hidden rounded-xl bg-orange-500 text-sm font-medium text-white transition-colors hover:bg-orange-600"
      >
        <span className="flex min-w-0 flex-1 items-center gap-1.5 pl-3 pr-2 text-left">
          <Icon name={current.icon} className="size-4" />
          <span className="truncate">{current.name}</span>
        </span>
        <span aria-hidden className="flex h-full w-8 shrink-0 items-center justify-center border-l border-white/35">
          <svg viewBox="0 0 12 12" className={`h-3.5 w-3.5 transition-transform ${open ? "rotate-180" : ""}`} fill="none" stroke="currentColor" strokeWidth="2.25" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 4.5 6 7.5 9 4.5" />
          </svg>
        </span>
      </button>

      {pos &&
        createPortal(
          <div
            ref={menuRef}
            style={{ top: pos.top, left: pos.left, width: MENU_WIDTH }}
            className="fixed z-50 flex max-h-[min(70vh,30rem)] flex-col overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-lg dark:border-zinc-800 dark:bg-zinc-900"
          >
            {/* The categories scroll when there are too many to fit; the links
                below them stay in view. */}
            <div className="flex min-h-0 flex-1 flex-col overflow-y-auto p-1">
              {options.map((o) => {
                const selected = o.slug === activeSlug;
                return (
                  <Link
                    key={o.slug}
                    href={o.href}
                    onClick={() => setPos(null)}
                    aria-current={selected ? "page" : undefined}
                    className={`flex min-h-10 shrink-0 items-center gap-2.5 rounded-lg px-3 text-sm ${
                      selected
                        ? "bg-orange-50 font-medium text-orange-700 dark:bg-orange-950/40 dark:text-orange-400"
                        : "text-zinc-700 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
                    }`}
                  >
                    <Icon name={o.icon} className={`size-[18px] ${selected ? "" : "text-zinc-500 dark:text-zinc-400"}`} />
                    <span className="min-w-0 flex-1">{o.name}</span>
                    {selected && (
                      <svg aria-hidden viewBox="0 0 16 16" className="h-4 w-4 shrink-0" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m3.5 8.5 3 3 6-7" />
                      </svg>
                    )}
                  </Link>
                );
              })}
            </div>
            {/* Browsing by tag, shop or brand is another way round the site, so
                it lives here rather than as one more button on the page. These
                leave the page, so they're outlined tiles, not rows. Voucher
                codes come first, in the codes' own violet, dashed like a code
                (as the Vouchers chip in the category row). */}
            <div className="flex shrink-0 flex-col gap-1 border-t border-zinc-100 p-1 dark:border-zinc-800">
              <Link
                href="/vouchers"
                onClick={() => setPos(null)}
                aria-current={activeSlug === "vouchers" ? "page" : undefined}
                className={`flex min-h-10 items-center justify-center gap-1.5 rounded-lg border border-dashed px-2 text-sm font-semibold transition-colors ${
                  activeSlug === "vouchers"
                    ? "border-violet-600 bg-violet-600 text-white dark:border-violet-500"
                    : "border-violet-300 bg-violet-50 text-violet-800 hover:bg-violet-100 dark:border-violet-800 dark:bg-violet-950/40 dark:text-violet-200 dark:hover:bg-violet-950/70"
                }`}
              >
                <Icon name="ticket" className="size-4" />
                Voucher codes
              </Link>
              <Link href="/categories" onClick={() => setPos(null)} className={footerTile}>
                <Icon name="grid" className="size-4" />
                All categories &amp; tags
              </Link>
              <div className="grid grid-cols-2 gap-1">
                <Link href="/stores" onClick={() => setPos(null)} className={footerTile}>
                  <Icon name="store" className="size-4" />
                  Stores
                </Link>
                <Link href="/brands" onClick={() => setPos(null)} className={footerTile}>
                  <Icon name="badge-check" className="size-4" />
                  Brands
                </Link>
              </div>
            </div>
          </div>,
          document.body
        )}
    </>
  );
}
