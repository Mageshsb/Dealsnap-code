"use client";

import { ReactNode, useId, useState } from "react";
import { InfoIcon } from "./icons";

// A page title row (name + alert bell) with an ⓘ button at the end that opens
// a panel of details underneath: a store's delivery, returns and so on, or a
// category's top stores and guides. Closed by default, so the page looks the
// same as any other until someone asks. The panel is in the page from the
// start (search engines read it), just hidden.
export default function InfoToggle({ label, panel, children }: { label: string; panel?: ReactNode; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const panelId = useId();

  return (
    <>
      {/* Fixed to the title's height so the buttons (a touch taller) don't
          push the page down. */}
      <div className="flex h-8 items-center gap-3">
        {children}
        {panel && (
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-controls={panelId}
            aria-label={label}
            title={label}
            // Matches the Alert button beside it: "ⓘ Info" on wider screens,
            // just the icon in a 34px circle on phones.
            className={`flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-3 py-1.5 text-sm font-semibold leading-5 transition-colors max-sm:-ml-1 max-sm:h-[34px] max-sm:w-[34px] max-sm:justify-center max-sm:gap-0 max-sm:p-0 ${
              open
                ? "border-orange-500 bg-orange-50 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400"
                : "border-zinc-300 text-zinc-700 hover:border-orange-400 hover:text-orange-600 dark:border-zinc-700 dark:text-zinc-200"
            }`}
          >
            <InfoIcon className="h-4 w-4" />
            <span className="max-sm:hidden">Info</span>
          </button>
        )}
      </div>
      {panel && (
        <div id={panelId} hidden={!open} className="mt-3 rounded-xl border border-zinc-200 bg-white p-4 sm:p-5 dark:border-zinc-800 dark:bg-zinc-900">
          {panel}
        </div>
      )}
    </>
  );
}
