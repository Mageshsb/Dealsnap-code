import Icon from "./Icon";

// A brand's logo in a rounded white box with a small brand badge in its
// bottom-right corner, so "Nike the brand" never looks like "Nike the shop"
// (a shop's logo stands bare). A brand with no logo yet is the badge on an
// orange tile, the same size, so a page doesn't shift when a logo is added.
export default function BrandLogo({
  name,
  logoUrl,
  className = "h-9 w-9",
}: {
  name: string;
  logoUrl?: string;
  className?: string;
}) {
  if (!logoUrl) {
    return (
      <span aria-hidden className={`inline-flex shrink-0 items-center justify-center rounded-lg bg-orange-50 dark:bg-orange-950/40 ${className}`}>
        <Icon name="badge-check" className="size-[55%] text-orange-700 dark:text-orange-400" />
      </span>
    );
  }
  return (
    <span className={`relative inline-flex shrink-0 ${className}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={logoUrl} alt={`${name} logo`} className="h-full w-full rounded-lg border border-zinc-100 bg-white object-contain p-[8%] dark:border-zinc-800" />
      <span
        aria-hidden
        className="absolute -bottom-[12%] -right-[12%] flex size-[46%] items-center justify-center rounded-full bg-orange-500 text-white ring-2 ring-white dark:ring-zinc-900"
      >
        <Icon name="badge-check" className="size-[72%]" />
      </span>
    </span>
  );
}
