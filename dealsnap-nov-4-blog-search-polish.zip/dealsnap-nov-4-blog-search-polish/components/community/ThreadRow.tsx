import Link from "next/link";
import type { ThreadRow as Thread } from "@/lib/community-db";
import { timeAgoShort } from "@/lib/format";
import { pageOfSeq } from "@/lib/community-rules";
import UserAvatar from "../UserAvatar";
import Icon from "../Icon";

// One conversation in a list: the starter's picture, the title (two lines at
// most), where it is, who spoke last and when, and the reply count at the end.
// Pinned, locked and answered show as small marks; a dot says there's
// something new since you looked (only for threads you follow), and the
// title then takes you straight to the first new reply.
export default function ThreadRow({ thread, seenTo, showSpace = true }: { thread: Thread; seenTo?: number; showSpace?: boolean }) {
  // A thread with replies you haven't read opens at the first of them.
  const unread = seenTo !== undefined;
  const first = unread ? seenTo + 1 : 0;
  const href = unread ? `/community/t/${thread.slug}${pageOfSeq(first) > 1 ? `?page=${pageOfSeq(first)}` : ""}#post-${first}` : `/community/t/${thread.slug}`;
  return (
    <article className="relative flex items-start gap-3 py-3.5 first:pt-0 last:pb-0">
      <UserAvatar username={thread.username} avatarUrl={thread.avatarUrl} size="h-8 w-8" textSize="text-xs" />
      <div className="flex min-w-0 flex-1 flex-col gap-1">
        <h3 className="text-[15px] font-semibold leading-snug text-zinc-900 dark:text-zinc-100">
          {/* The whole row is the link, so a thumb anywhere on it opens the thread. */}
          <Link href={href} className="line-clamp-2 [overflow-wrap:anywhere] after:absolute after:inset-0 hover:text-orange-600 dark:hover:text-orange-400">
            {unread && (
              <>
                <span aria-hidden className="mr-1.5 inline-block size-2 rounded-full bg-orange-500 align-middle" />
                <span className="sr-only">New replies: </span>
              </>
            )}
            {thread.title}
          </Link>
        </h3>
        <p className="flex min-w-0 items-center gap-1.5 text-xs text-zinc-500">
          {thread.pinned && (
            <span className="shrink-0" title="Pinned">
              <Icon name="pin" className="size-3.5 text-orange-700 dark:text-orange-400" />
              <span className="sr-only">Pinned</span>
            </span>
          )}
          {thread.locked && (
            <span className="shrink-0" title="Locked">
              <Icon name="lock" className="size-3.5 text-zinc-500 dark:text-zinc-400" />
              <span className="sr-only">Locked</span>
            </span>
          )}
          {thread.solved && (
            <span className="flex shrink-0 items-center gap-0.5 font-medium text-green-700 dark:text-green-400">
              <Icon name="circle-check" className="size-3.5" />
              Answered
            </span>
          )}
          {showSpace && (
            <span className="max-w-[75%] shrink truncate rounded bg-zinc-100 px-1.5 py-px text-[11px] font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">{thread.spaceName}</span>
          )}
          <span className="min-w-0 shrink-[2] truncate">
            {thread.replyCount > 0 ? (
              <>
                {thread.lastUsername}
                <span className="hidden min-[420px]:inline"> replied</span>
              </>
            ) : (
              thread.username
            )}{" "}
            {timeAgoShort(thread.lastPostAt)}
          </span>
        </p>
      </div>
      <span className="flex shrink-0 items-center gap-2.5 pt-0.5 text-xs tabular-nums text-zinc-500">
        {thread.likeTotal > 0 && (
          <span className="flex items-center gap-1" title={`${thread.likeTotal} ${thread.likeTotal === 1 ? "like" : "likes"}`}>
            <Icon name="thumbs-up" className="size-3.5 text-zinc-500 dark:text-zinc-400" />
            {thread.likeTotal}
            <span className="sr-only">{thread.likeTotal === 1 ? "like" : "likes"}</span>
          </span>
        )}
        <span className="flex min-w-7 items-center justify-end gap-1" title={`${thread.replyCount} ${thread.replyCount === 1 ? "reply" : "replies"}`}>
          <Icon name="comment" className="size-3.5 text-zinc-500 dark:text-zinc-400" />
          {thread.replyCount}
          <span className="sr-only">{thread.replyCount === 1 ? "reply" : "replies"}</span>
        </span>
      </span>
    </article>
  );
}
