import { MAX_DEAL_CARDS } from "@/lib/community-rules";
import type { Picture } from "@/lib/pictures";
import RichContent from "../RichContent";

// A post's words, safely (components/RichContent.tsx): its formatting, links
// (to other websites out through /out), @names as profile links, its pictures
// where they were put, and a line that is just a deal's address on this site
// as a deal card. Never markup.
export default function PostBody({
  postId,
  username,
  text,
  hosts,
  pictures,
  large = false,
}: {
  postId: string;
  username: string;
  text: string;
  hosts: string[];
  pictures: Picture[];
  large?: boolean;
}) {
  return (
    <RichContent
      text={text}
      format
      hosts={hosts}
      cards={MAX_DEAL_CARDS}
      pictures={pictures}
      out={{ kind: "p", id: postId }}
      pictureAlt={`from ${username}`}
      className={`flex flex-col gap-2 text-sm leading-relaxed text-zinc-700 dark:text-zinc-300 ${large ? "sm:text-base" : ""}`}
    />
  );
}
