"use client";

import { useState, useTransition, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import {
  dismissPostReportsAction,
  deletePostAction,
  editPostAction,
  hidePostAction,
  likePostAction,
  markBestAnswerAction,
  removePostAction,
  setPostReportAction,
} from "@/lib/community-actions";
import { COMMUNITY_EDIT_MINUTES, REPLY_MAX, THREAD_BODY_MAX, communityEditableUntil } from "@/lib/community-rules";
import { COMMENT_ACTIONS } from "../comment-styles";
import RichEditor, { picturesToFiles } from "../RichEditor";
import CommentLikeButton from "../CommentLikeButton";
import MoreMenu, { moreMenuItem } from "../MoreMenu";
import Icon from "../Icon";
import { ReplyButton } from "./Replies";

export type PostFlags = {
  postId: string;
  threadId: string;
  seq: number;
  username: string;
  createdAt: string;
  // The words, for the writer or the team to edit (null for everyone else).
  rawText: string | null;
  loggedIn: boolean;
  canReply: boolean;
  own: boolean;
  teamEdit: boolean;
  canHide: boolean;
  canRemove: boolean;
  canDismiss: boolean;
  opening: boolean;
  best: "mark" | "unmark" | null;
  liked: boolean;
  likeCount: number;
  reported: boolean;
  // How many pictures the post can have once edited (0: no new ones).
  maxPictures: number;
};

const softButton = "rounded-full px-3 py-1 font-medium text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800";

// The line under a post (Like, Reply, best answer, and the "⋯" menu) and the
// post's words themselves, which swap for a box while they're being edited.
// What the menu holds depends on who is looking: Edit and Delete on your own
// post, Report on others', and the team's tools (hide, remove, edit, dismiss
// reports) for those who have them. Nothing here is trusted by the server:
// every action checks again.
export default function PostActions({ f, children }: { f: PostFlags; children: ReactNode }) {
  const router = useRouter();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(f.rawText ?? "");
  const [pictures, setPictures] = useState<Record<string, string>>({});
  const [error, setError] = useState("");
  const [canEdit, setCanEdit] = useState(false);
  const [asking, setAsking] = useState<"delete" | "remove" | null>(null);
  const [reported, setReported] = useState(f.reported);
  const [pending, startTransition] = useTransition();
  const max = f.opening ? THREAD_BODY_MAX : REPLY_MAX;
  const noun = f.opening ? "thread" : "post";

  function run(work: () => Promise<boolean>, done?: () => void) {
    setError("");
    startTransition(async () => {
      if (!(await work())) return setError("That didn't work. It may already have changed.");
      done?.();
      router.refresh();
    });
  }

  function save() {
    setError("");
    startTransition(async () => {
      const sent = new FormData();
      for (const file of await picturesToFiles(draft, pictures)) sent.append("pictures", file);
      const problem = await editPostAction(f.postId, draft, sent);
      if (problem) return setError(problem);
      setEditing(false);
      router.refresh();
    });
  }

  function setReport(next: boolean) {
    setReported(next);
    startTransition(async () => {
      const saved = await setPostReportAction(f.postId, next);
      if (saved === null) setReported(!next);
    });
  }

  if (editing) {
    return (
      <div className="mt-1 flex flex-col gap-2">
        <RichEditor
          value={draft}
          onChange={setDraft}
          pictures={pictures}
          onPictures={setPictures}
          placeholder=""
          label="Your post"
          maxPictures={Math.max(f.maxPictures, (draft.match(/\[\[shot:/g) ?? []).length)}
          onCtrlEnter={save}
          autoFocus
          minHeight={f.opening ? "min-h-[10rem]" : "min-h-[5rem]"}
        />
        {draft.length > max - 300 && (
          <span className="self-end text-xs tabular-nums text-zinc-500 dark:text-zinc-400">
            {draft.length}/{max}
          </span>
        )}
        {!f.own && <p className="text-xs text-zinc-500">You are editing this as the team. It will say so, and the change is logged.</p>}
        {error && <p className="text-xs text-amber-700 dark:text-amber-400">{error}</p>}
        <div className="flex items-center justify-end gap-2 text-xs">
          <button
            type="button"
            onClick={() => {
              setEditing(false);
              setError("");
            }}
            className={softButton}
          >
            Cancel
          </button>
          <button type="button" onClick={save} disabled={pending || !draft.trim()} className="rounded-full bg-orange-500 px-3 py-1 font-semibold text-white hover:bg-orange-600 disabled:opacity-60">
            {pending ? "Saving…" : "Save"}
          </button>
        </div>
      </div>
    );
  }

  const hasMenu = f.loggedIn && (f.own || f.teamEdit || f.canHide || f.canRemove || f.canDismiss || !f.own);
  const showReported = reported && !f.own && !f.canRemove;

  return (
    <>
      {children}
      <div className={`${COMMENT_ACTIONS} empty:hidden`}>
        {asking === "delete" ? (
          <span className="tell-us-in flex flex-wrap items-center gap-x-3 gap-y-1">
            {f.opening ? "Delete this whole thread?" : "Delete this post?"}
            <button
              type="button"
              disabled={pending}
              onClick={() =>
                startTransition(async () => {
                  const result = await deletePostAction(f.postId);
                  if (!result) return setError("We couldn't delete that. Please try again.");
                  if (result.thread) router.push("/community");
                  else router.refresh();
                })
              }
              className="font-medium text-red-600 hover:underline disabled:opacity-60 dark:text-red-400"
            >
              {pending ? "Deleting…" : "Yes, delete"}
            </button>
            <button type="button" onClick={() => setAsking(null)} className="hover:underline">
              Cancel
            </button>
          </span>
        ) : (
          <>
            <CommentLikeButton commentId={f.postId} initialLikeCount={f.likeCount} initiallyLiked={f.liked} loggedIn={f.loggedIn && !f.own} action={likePostAction} />
            {f.canReply && !f.opening && <ReplyButton id={f.postId} username={f.username} />}
            {f.best && (
              <button
                type="button"
                disabled={pending}
                onClick={() => run(() => markBestAnswerAction(f.threadId, f.best === "mark" ? f.postId : null))}
                className="flex items-center gap-1 transition-colors hover:text-green-700 disabled:opacity-60 dark:hover:text-green-400"
              >
                <Icon name="circle-check" className="size-3.5" />
                {f.best === "mark" ? "Best answer" : "Best answer · Undo"}
              </button>
            )}
            {hasMenu && (
              <span className="ml-auto flex">
                {showReported ? (
                  <span className="tell-us-in inline-flex items-center gap-1.5 whitespace-nowrap text-xs text-zinc-500 dark:text-zinc-500">
                    <Icon name="flag" className="size-3.5" />
                    Reported
                    <button type="button" onClick={() => setReport(false)} disabled={pending} className="font-medium text-orange-700 hover:underline disabled:opacity-50 dark:text-orange-400">
                      Undo
                    </button>
                  </span>
                ) : (
                  <MoreMenu
                    label="Post options"
                    onOpen={() => {
                      setCanEdit(Date.now() < communityEditableUntil(f.createdAt));
                      setAsking(null);
                    }}
                  >
                    {(close) =>
                      asking === "remove" ? (
                        <div className="flex flex-col gap-2 px-4 py-2.5">
                          <p className="text-sm font-semibold">{f.opening ? "Remove this whole thread?" : "Remove this post?"}</p>
                          <p className="text-xs text-zinc-500 dark:text-zinc-400">
                            {f.opening ? "Everyone's replies go with it. You can bring it back later." : "It shows as “Removed by our team”. It's logged under your name."}
                          </p>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              disabled={pending}
                              onClick={() => run(() => removePostAction(f.postId), close)}
                              className="rounded-full bg-red-600 px-3 py-1 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-60"
                            >
                              {pending ? "Removing…" : "Remove"}
                            </button>
                            <button type="button" onClick={() => setAsking(null)} className="rounded-full px-3 py-1 text-sm text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800">
                              Cancel
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          {(f.own ? canEdit : f.teamEdit) && (
                            <button
                              type="button"
                              role="menuitem"
                              onClick={() => {
                                close();
                                setDraft(f.rawText ?? "");
                                setError("");
                                setEditing(true);
                              }}
                              className={moreMenuItem}
                            >
                              <Icon name="pencil" className="size-4 text-zinc-500 dark:text-zinc-400" />
                              {f.own ? "Edit" : "Edit as team"}
                            </button>
                          )}
                          {f.own && (
                            <button
                              type="button"
                              role="menuitem"
                              onClick={() => {
                                close();
                                setAsking("delete");
                              }}
                              className={`${moreMenuItem} hover:text-red-600 dark:hover:text-red-400`}
                            >
                              <Icon name="trash" className="size-4 text-zinc-500 dark:text-zinc-400" />
                              Delete
                            </button>
                          )}
                          {f.own && !canEdit && (
                            <p className="border-t border-zinc-100 px-4 pb-1.5 pt-2 text-xs text-zinc-500 dark:text-zinc-400 dark:border-zinc-800">
                              Posts can be edited for {COMMUNITY_EDIT_MINUTES} minutes after posting.
                            </p>
                          )}
                          {f.canHide && !f.canRemove && (
                            <button type="button" role="menuitem" disabled={pending} onClick={() => run(() => hidePostAction(f.postId), close)} className={moreMenuItem}>
                              <Icon name="eye-off" className="size-4 text-zinc-500 dark:text-zinc-400" />
                              Hide for a moderator to check
                            </button>
                          )}
                          {f.canDismiss && (
                            <button type="button" role="menuitem" disabled={pending} onClick={() => run(() => dismissPostReportsAction(f.postId), close)} className={moreMenuItem}>
                              <Icon name="flag-off" className="size-4 text-zinc-500 dark:text-zinc-400" />
                              Dismiss reports
                            </button>
                          )}
                          {f.canRemove && (
                            <button type="button" role="menuitem" onClick={() => setAsking("remove")} className={`${moreMenuItem} !text-red-600 dark:!text-red-400`}>
                              <Icon name="trash" className="size-4" />
                              {f.opening ? "Remove thread" : "Remove post"}
                            </button>
                          )}
                          {!f.own && !f.canRemove && (
                            <button
                              type="button"
                              role="menuitem"
                              onClick={() => {
                                close();
                                setReport(true);
                              }}
                              className={moreMenuItem}
                            >
                              <Icon name="flag" className="size-4 text-zinc-500 dark:text-zinc-400" />
                              Report {noun}
                            </button>
                          )}
                        </>
                      )
                    }
                  </MoreMenu>
                )}
              </span>
            )}
          </>
        )}
      </div>
      {error && <p role="alert" className="text-xs text-amber-700 dark:text-amber-400">{error}</p>}
    </>
  );
}
