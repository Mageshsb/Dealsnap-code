import { SEARCH_MAX } from "@/lib/community-rules";
import { ClearSearch, searchBox } from "../SearchBox";

// "Search conversations": one box that looks through the titles of the threads on
// this page's list (every space on the Community home, one space inside it). A
// plain form that works before any script loads; the sort the reader chose is kept.
export default function CommunitySearch({ action, q, sort, view, placeholder }: { action: string; q: string; sort?: string; view?: string; placeholder: string }) {
  return (
    <form action={action} role="search" className="relative">
      <label htmlFor={`search-${action}`} className="sr-only">
        Search conversations
      </label>
      <input
        id={`search-${action}`}
        type="search"
        name="q"
        defaultValue={q}
        maxLength={SEARCH_MAX}
        enterKeyHint="search"
        autoComplete="off"
        placeholder={placeholder}
        className={searchBox}
      />
      {sort && sort !== "active" && <input type="hidden" name="sort" value={sort} />}
      {view && <input type="hidden" name="view" value={view} />}
      {q && <ClearSearch href={view ? `${action}?view=${view}` : action} />}
    </form>
  );
}
