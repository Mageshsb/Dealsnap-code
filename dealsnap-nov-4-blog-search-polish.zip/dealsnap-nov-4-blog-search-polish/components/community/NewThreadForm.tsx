"use client";

import { useActionState, useRef, useState } from "react";
import Link from "next/link";
import { createThreadAction, similarThreadsAction, type NewThreadState } from "@/lib/community-actions";
import type { SimilarThread } from "@/lib/community-db";
import { THREAD_BODY_MAX, TITLE_MAX } from "@/lib/community-rules";
import type { FormCheck } from "@/lib/captcha";
import BotCheck from "../BotCheck";
import SelectField from "../SelectField";
import Icon from "../Icon";
import RichEditor from "../RichEditor";

const input =
  "w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950";
const errorRing = "border-red-400 dark:border-red-500";

// The form for a new thread: where it goes, a title and the opening post.
// What was typed stays if something is wrong. A member's very first thread
// also carries the site's bot check. `label` is the store, category or tag
// page the thread was started from, which it is then tied to.
export default function NewThreadForm({
  spaces,
  defaultSpace,
  label,
  initialCheck,
  turnstileSiteKey,
  maxPictures,
}: {
  spaces: { value: string; label: string; hint?: string; askHint?: boolean }[];
  defaultSpace: string;
  label?: { kind: string; value: string; name: string };
  initialCheck?: FormCheck;
  turnstileSiteKey?: string;
  // Pictures the opening post can have (0 for a brand-new account).
  maxPictures: number;
}) {
  const [state, action, pending] = useActionState<NewThreadState, FormData>(createThreadAction, {});
  const check = state.check ?? initialCheck;
  const values = state.values ?? { space: defaultSpace, title: "", text: "" };
  const [space, setSpace] = useState(values.space || defaultSpace);
  const [text, setText] = useState(values.text);
  const [pictures, setPictures] = useState<Record<string, string>>({});
  const [syncedTo, setSyncedTo] = useState(state);
  if (syncedTo !== state) {
    setSyncedTo(state);
    setSpace(values.space || defaultSpace);
    setText(values.text);
  }
  const bad = (field: NonNullable<NewThreadState["field"]>) => (state.field === field ? errorRing : "");

  // Threads that already cover what the title says, looked up once typing pauses.
  const [similar, setSimilar] = useState<SimilarThread[]>([]);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const latest = useRef(0);
  function titleChanged(value: string) {
    clearTimeout(timer.current);
    const turn = ++latest.current;
    if (value.trim().length < 10) return setSimilar([]);
    timer.current = setTimeout(async () => {
      const found = await similarThreadsAction(value).catch(() => []);
      if (turn === latest.current) setSimilar(found);
    }, 600);
  }
  const chosen = spaces.find((s) => s.value === space);

  return (
    <form action={action} className="flex flex-col gap-4 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900 sm:p-6">
      {state.error && (
        <p role="alert" className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200">
          {state.error}
        </p>
      )}
      {label && (
        <>
          <input type="hidden" name="labelKind" value={label.kind} />
          <input type="hidden" name="labelValue" value={label.value} />
          <p className="text-sm text-zinc-500">
            About <span className="font-medium text-zinc-800 dark:text-zinc-200">{label.name}</span>. It will show on that page too.
          </p>
        </>
      )}

      <div className="flex flex-col gap-1">
        <label htmlFor="thread-space" className="text-sm font-medium">
          Where does it belong?
        </label>
        <SelectField id="thread-space" name="space" label="Where does it belong?" required value={space} onChange={setSpace} options={spaces.map((s) => ({ value: s.value, label: s.label }))} />
        {chosen?.hint && <p className="text-xs text-zinc-500 dark:text-zinc-400">{chosen.hint}</p>}
      </div>

      <div className="flex flex-col gap-1">
        <label htmlFor="thread-title" className="text-sm font-medium">
          Title
        </label>
        <input
          id="thread-title"
          name="title"
          required
          maxLength={TITLE_MAX}
          defaultValue={values.title}
          onChange={(e) => titleChanged(e.target.value)}
          placeholder={chosen?.askHint ? "Ask it as a question, e.g. Best cheap air fryer under £60?" : "What's it about?"}
          className={`${input} ${bad("title")}`}
        />
        {similar.length > 0 && (
          <div className="mt-1 flex flex-col gap-1.5 rounded-lg border border-zinc-200 bg-zinc-50 p-3 text-sm dark:border-zinc-800 dark:bg-zinc-950">
            <p className="flex items-center gap-1.5 font-medium">
              <Icon name="lightbulb" className="size-4 text-orange-700 dark:text-orange-400" />
              Already being talked about
            </p>
            <ul className="flex flex-col gap-1">
              {similar.map((t) => (
                <li key={t.slug} className="min-w-0">
                  {/* A new tab, so what you've typed here stays put. */}
                  <Link href={`/community/t/${t.slug}`} target="_blank" className="line-clamp-2 [overflow-wrap:anywhere] font-medium text-orange-700 hover:underline dark:text-orange-400">
                    {t.title}
                  </Link>
                  <span className="text-xs text-zinc-500">
                    {t.spaceName} · {t.replyCount} {t.replyCount === 1 ? "reply" : "replies"}
                    {t.solved ? " · answered" : ""}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="flex flex-col gap-1">
        <label htmlFor="thread-text" className="text-sm font-medium">
          {chosen?.askHint ? "Details" : "What do you want to say?"}
        </label>
        <div className={state.field === "text" ? "rounded-lg ring-1 ring-red-400 dark:ring-red-500" : ""}>
          <RichEditor
            value={text}
            onChange={setText}
            pictures={pictures}
            onPictures={setPictures}
            placeholder={chosen?.askHint ? "Your budget, what you've tried, what matters most." : "Share it with the community."}
            label={chosen?.askHint ? "Details" : "What do you want to say?"}
            maxPictures={maxPictures}
            fieldName="text"
            filesName="pictures"
            requiredId="thread-text"
            minHeight="min-h-[11rem]"
          />
        </div>
        <div className="flex justify-between gap-3 text-xs text-zinc-500 dark:text-zinc-400">
          <span>Paste a DealSnap deal on a line of its own to show it as a card.</span>
          <span className="shrink-0 tabular-nums">
            {text.length}/{THREAD_BODY_MAX}
          </span>
        </div>
      </div>

      {check && <BotCheck idPrefix="thread" check={check} siteKey={turnstileSiteKey} resetKey={state.error ? state : undefined} answerClassName={`${input} w-24 ${bad("check")}`} />}

      <div className="flex justify-end">
        <button type="submit" disabled={pending} className="rounded-full bg-orange-500 px-6 py-2 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60">
          {pending ? "Posting…" : "Post thread"}
        </button>
      </div>
    </form>
  );
}
