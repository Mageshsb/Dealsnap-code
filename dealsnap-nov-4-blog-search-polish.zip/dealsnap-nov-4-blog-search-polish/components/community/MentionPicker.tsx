"use client";

import { useId, useState, type ChangeEvent, type KeyboardEvent, type ReactNode, type RefObject, type SyntheticEvent } from "react";

// Typing "@" in a reply offers the people who have posted in the thread (the only
// people a mention can notify), narrowing as you type. Arrow keys and Enter or Tab
// pick one, Escape closes the list, and a tap or click works too. The names are
// handed in by the page, so nothing is looked up as you type.
export const MENTION = /(^|[^A-Za-z0-9_])@([A-Za-z0-9_]{0,20})$/;
export const SHOWN = 6;

// Names starting with what's typed first, then names containing it; with nothing
// typed yet, the most recent speakers.
export function rank(names: string[], typed: string): string[] {
  if (!typed) return [...names].reverse().slice(0, SHOWN);
  const low = typed.toLowerCase();
  const starts = names.filter((n) => n.toLowerCase().startsWith(low));
  const inside = names.filter((n) => !n.toLowerCase().startsWith(low) && n.toLowerCase().includes(low));
  const found = [...starts, ...inside].slice(0, SHOWN);
  // Once the whole name is typed there is nothing left to suggest.
  return found.length === 1 && found[0].toLowerCase() === low ? [] : found;
}

export function useMentionPicker({
  names,
  text,
  setText,
  box,
  max,
}: {
  names: string[];
  text: string;
  setText: (value: string) => void;
  box: RefObject<HTMLTextAreaElement | null>;
  max: number;
}) {
  const listId = useId();
  const [caret, setCaret] = useState(0);
  const [index, setIndex] = useState(0);
  const [closedAt, setClosedAt] = useState(-1);

  const match = names.length ? MENTION.exec(text.slice(0, caret)) : null;
  const at = match ? caret - match[2].length - 1 : -1; // where the "@" is
  const matches = match && closedAt !== at ? rank(names, match[2]) : [];
  const open = matches.length > 0;
  const active = Math.min(index, Math.max(0, matches.length - 1));

  function pick(name: string) {
    const next = `${text.slice(0, at)}@${name} ${text.slice(caret)}`;
    if (next.length > max) return;
    setText(next);
    const to = at + name.length + 2;
    setCaret(to);
    setIndex(0);
    requestAnimationFrame(() => {
      box.current?.focus();
      box.current?.setSelectionRange(to, to);
    });
  }

  const track = (e: SyntheticEvent<HTMLTextAreaElement>) => setCaret(e.currentTarget.selectionStart);

  return {
    open,
    // Spread onto the textarea.
    props: {
      onChange: (e: ChangeEvent<HTMLTextAreaElement>) => {
        setText(e.target.value);
        setCaret(e.target.selectionStart);
        setIndex(0);
      },
      onKeyUp: track,
      onClick: track,
      onSelect: track,
      ...(open
        ? { "aria-autocomplete": "list" as const, "aria-controls": listId, "aria-expanded": true, "aria-activedescendant": `${listId}-${active}` }
        : {}),
    },
    // Called first by the textarea's key handler: true when the key was for the list.
    onKeyDown: (e: KeyboardEvent<HTMLTextAreaElement>): boolean => {
      if (!open) return false;
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        setIndex((active + (e.key === "ArrowDown" ? 1 : matches.length - 1)) % matches.length);
        return true;
      }
      if ((e.key === "Enter" && !e.metaKey && !e.ctrlKey) || e.key === "Tab") {
        e.preventDefault();
        pick(matches[active]);
        return true;
      }
      if (e.key === "Escape") {
        e.preventDefault();
        setClosedAt(at);
        return true;
      }
      return false;
    },
    // Shown above the box, so the keyboard on a phone never covers it.
    list: (open ? (
      <div className="absolute bottom-full left-0 z-20 mb-1 w-64 max-w-full overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-lg dark:border-zinc-700 dark:bg-zinc-900">
        <p className="border-b border-zinc-100 px-3 py-1.5 text-xs text-zinc-500 dark:border-zinc-800">People in this thread</p>
        <ul id={listId} role="listbox" aria-label="People in this thread">
          {matches.map((name, i) => (
            <li
              key={name}
              id={`${listId}-${i}`}
              role="option"
              aria-selected={i === active}
              // Keeps the cursor in the box while the name is tapped.
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => pick(name)}
              className={`flex min-h-10 cursor-pointer items-center px-3 text-sm ${i === active ? "bg-orange-50 font-medium text-orange-700 dark:bg-orange-950/30 dark:text-orange-300" : "hover:bg-zinc-50 dark:hover:bg-zinc-800"}`}
            >
              <span className="truncate">@{name}</span>
            </li>
          ))}
        </ul>
      </div>
    ) : null) as ReactNode,
  };
}
