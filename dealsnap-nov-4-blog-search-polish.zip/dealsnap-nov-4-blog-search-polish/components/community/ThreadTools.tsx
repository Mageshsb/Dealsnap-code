"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { changeThreadAction, deleteThreadForeverAction, followThreadAction, restorePostAction, tidyThreadAction } from "@/lib/community-actions";
import { TITLE_MAX } from "@/lib/community-rules";
import MoreMenu, { moreMenuItem } from "../MoreMenu";
import SelectField from "../SelectField";
import Icon from "../Icon";
import StableLabel, { words } from "../StableLabel";

// Follow, and (for the team) the Manage menu, at the top of a thread. A
// follower hears about new replies in the bell and sees a dot on the thread in
// lists. Manage holds what a helper or moderator may do from the thread itself:
// rename it, move it to a better space, pin it, lock it. Every change is logged.
export default function ThreadTools({
  threadId,
  title,
  spaceId,
  spaces,
  following,
  canTidy,
  canModerate,
  pinned,
  locked,
}: {
  threadId: string;
  title: string;
  spaceId: string;
  spaces: { value: string; label: string }[];
  following: boolean | null; // null: a guest
  canTidy: boolean;
  canModerate: boolean;
  pinned: boolean;
  locked: boolean;
}) {
  const router = useRouter();
  const [follow, setFollow] = useState(!!following);
  const [panel, setPanel] = useState(false);
  const [name, setName] = useState(title);
  const [space, setSpace] = useState(spaceId);
  const [error, setError] = useState("");
  const [pending, startTransition] = useTransition();

  function toggleFollow() {
    const next = !follow;
    setFollow(next);
    startTransition(async () => {
      const saved = await followThreadAction(threadId, next);
      if (saved === null) setFollow(!next);
    });
  }

  function save() {
    setError("");
    startTransition(async () => {
      const problem = await tidyThreadAction(threadId, { title: name, spaceId: space });
      if (problem) return setError(problem);
      setPanel(false);
      router.refresh();
    });
  }

  function change(what: "pin" | "unpin" | "lock" | "unlock", close: () => void) {
    startTransition(async () => {
      if (await changeThreadAction(threadId, what)) {
        close();
        router.refresh();
      }
    });
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2">
        {following !== null && (
          <button
            type="button"
            onClick={toggleFollow}
            aria-pressed={follow}
            className={`flex min-h-9 items-center gap-1.5 rounded-xl px-3 text-sm font-medium transition-colors ${
              follow ? "bg-orange-500 text-white" : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
            }`}
          >
            <Icon name={follow ? "bell-ring" : "bell"} className="size-4" />
            <StableLabel options={words("Follow", "Following")} show={follow ? "Following" : "Follow"} />
          </button>
        )}
        {(canTidy || canModerate) && (
          <MoreMenu label="Manage this thread">
            {(close) => (
              <>
                {canTidy && (
                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      close();
                      setPanel(true);
                    }}
                    className={moreMenuItem}
                  >
                    <Icon name="pen-line" className="size-4 text-zinc-500 dark:text-zinc-400" />
                    Rename or move
                  </button>
                )}
                {canModerate && (
                  <>
                    <button type="button" role="menuitem" disabled={pending} onClick={() => change(pinned ? "unpin" : "pin", close)} className={moreMenuItem}>
                      <Icon name="pin" className="size-4 text-zinc-500 dark:text-zinc-400" />
                      {pinned ? "Unpin" : "Pin to the top of its space"}
                    </button>
                    <button type="button" role="menuitem" disabled={pending} onClick={() => change(locked ? "unlock" : "lock", close)} className={moreMenuItem}>
                      <Icon name="lock" className="size-4 text-zinc-500 dark:text-zinc-400" />
                      {locked ? "Unlock replies" : "Lock replies"}
                    </button>
                  </>
                )}
              </>
            )}
          </MoreMenu>
        )}
      </div>

      {panel && (
        <div className="tell-us-in flex flex-col gap-3 rounded-lg border border-zinc-200 bg-zinc-50 p-3 dark:border-zinc-800 dark:bg-zinc-950">
          <label className="flex flex-col gap-1 text-sm font-medium">
            Title
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={TITLE_MAX}
              className="min-h-11 w-full rounded-lg border border-zinc-300 bg-white px-3 py-2 text-base font-normal outline-none focus:border-orange-500 sm:min-h-10 lg:text-sm dark:border-zinc-700 dark:bg-zinc-900"
            />
          </label>
          <div className="flex flex-col gap-1 text-sm font-medium">
            Space
            <SelectField label="Space" options={spaces} value={space} onChange={setSpace} />
          </div>
          {error && <p className="text-xs text-amber-700 dark:text-amber-400">{error}</p>}
          <div className="flex justify-end gap-2 text-sm">
            <button
              type="button"
              onClick={() => {
                setPanel(false);
                setName(title);
                setSpace(spaceId);
                setError("");
              }}
              className="rounded-full px-3 py-1.5 font-medium text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
            >
              Cancel
            </button>
            <button type="button" onClick={save} disabled={pending} className="rounded-full bg-orange-500 px-4 py-1.5 font-semibold text-white hover:bg-orange-600 disabled:opacity-60">
              {pending ? "Saving…" : "Save"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// "Restore" on a post (or a whole thread) the team took down or hid, for a
// moderator who decides it was fine.
export function RestorePost({ postId }: { postId: string }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  return (
    <button
      type="button"
      disabled={pending}
      onClick={() =>
        startTransition(async () => {
          if (await restorePostAction(postId)) router.refresh();
        })
      }
      className="ml-2 font-medium text-orange-700 not-italic hover:underline disabled:opacity-60 dark:text-orange-400"
    >
      {pending ? "Restoring…" : "Restore"}
    </button>
  );
}

// The strip over a thread that is waiting for a check (approve it) or has
// been taken down (bring it back, or, for owners, delete it for good), for
// moderators.
export function ThreadStateBanner({ threadId, state, canDelete = false, posts = 1 }: { threadId: string; state: "held" | "removed"; canDelete?: boolean; posts?: number }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [asking, setAsking] = useState(false);
  const [failed, setFailed] = useState(false);
  return (
    <div className="flex flex-col gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5 text-sm text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/20 dark:text-amber-200">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="flex min-w-0 items-center gap-2">
          <Icon name={state === "held" ? "eye" : "trash"} className="size-4 shrink-0" />
          {state === "held" ? "A first thread, waiting for a quick check. Only you and its writer can see it." : "Taken down. Only moderators can see it."}
        </span>
        <span className="flex flex-wrap gap-2">
          <button
            type="button"
            disabled={pending}
            onClick={() =>
              startTransition(async () => {
                if (await changeThreadAction(threadId, state === "held" ? "approve" : "restore")) router.refresh();
              })
            }
            className="rounded-full bg-amber-600 px-3 py-1 font-semibold text-white hover:bg-amber-700 disabled:opacity-60"
          >
            {pending && !asking ? "Working…" : state === "held" ? "Approve" : "Restore thread"}
          </button>
          {state === "removed" && canDelete && !asking && (
            <button type="button" onClick={() => setAsking(true)} className="rounded-full border border-red-400 px-3 py-1 font-semibold text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-300 dark:hover:bg-red-950/40">
              Delete permanently
            </button>
          )}
        </span>
      </div>
      {asking && (
        <div className="tell-us-in flex flex-wrap items-center gap-x-3 gap-y-2 border-t border-amber-200 pt-2 dark:border-amber-900/50">
          <span>
            Delete this thread and its {posts === 1 ? "post" : `${posts} posts`} for good? This can&apos;t be undone.
          </span>
          <button
            type="button"
            disabled={pending}
            onClick={() =>
              startTransition(async () => {
                if (await deleteThreadForeverAction(threadId)) router.push("/admin/community");
                else setFailed(true);
              })
            }
            className="rounded-full bg-red-600 px-3 py-1 font-semibold text-white hover:bg-red-700 disabled:opacity-60"
          >
            {pending ? "Deleting…" : "Yes, delete it"}
          </button>
          <button type="button" onClick={() => setAsking(false)} className="hover:underline">
            Cancel
          </button>
          {failed && <span className="text-red-700 dark:text-red-300">That didn&apos;t work. It may already have gone.</span>}
        </div>
      )}
    </div>
  );
}
