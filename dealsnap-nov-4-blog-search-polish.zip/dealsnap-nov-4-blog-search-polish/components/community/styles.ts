// Shared by the Community's pages.

// The orange "Start a discussion" button.
export const startButton =
  "inline-flex min-h-10 shrink-0 items-center gap-1.5 rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600";

// The white card every block of the Community sits in.
export const card = "rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900 sm:p-6";
