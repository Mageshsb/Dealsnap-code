import Link from "next/link";
import type { PostRow, ThreadRow } from "@/lib/community-db";
import type { Picture } from "@/lib/pictures";
import { MAX_PICTURES } from "@/lib/deal-text";
import { PLACEHOLDER, pageOfSeq } from "@/lib/community-rules";
import { formatDate, timeAgo } from "@/lib/format";
import UserAvatar from "../UserAvatar";
import UsernameLink from "../UsernameLink";
import { tierOf } from "../RoleBadge";
import Icon from "../Icon";
import PostActions from "./PostActions";
import PostBody from "./PostBody";
import { RestorePost } from "./ThreadTools";

// What a post needs to know about the reader and the thread around it.
export type PostReader = {
  loggedIn: boolean;
  userId?: string;
  canReply: boolean;
  isAsker: boolean;
  canTidy: boolean; // a helper or above
  canModerate: boolean;
  mayAct: (post: PostRow) => boolean;
  liked: Set<string>;
  reported: Set<string>;
  reportCounts: Map<string, number>;
  blocked: Set<string>;
  hosts: string[];
  pictures: Map<string, Picture[]>;
  // Whether this reader can add pictures (not a brand-new account).
  picturesAllowed: boolean;
};

// One post: picture on the left; name, tags and time; the quote of what it
// answers; the words; then Like, Reply and the "⋯" menu. A post that has been
// hidden, removed or deleted keeps its place as a short line, so the numbers
// and the replies after it still make sense.
export default function PostItem({ post, thread, reader }: { post: PostRow; thread: ThreadRow; reader: PostReader }) {
  const anchor = `post-${post.seq}`;
  const opening = post.seq === 1;
  const own = reader.userId === post.userId;

  if (reader.blocked.has(post.userId) && !own) {
    return (
      <article id={anchor} className="scroll-mt-24 text-sm italic text-zinc-500 dark:text-zinc-400">
        Post from a member you&apos;ve blocked.
      </article>
    );
  }
  if (post.status !== "live") {
    const canRestore = reader.canModerate && (post.status === "hidden" || post.status === "removed") && reader.mayAct(post);
    return (
      <article id={anchor} className="scroll-mt-24 text-sm italic text-zinc-500 dark:text-zinc-400">
        {PLACEHOLDER[post.status]}
        {canRestore && <RestorePost postId={post.id} />}
      </article>
    );
  }

  const isBest = thread.solvedPostId === post.id;
  const acts = !own && reader.mayAct(post);
  const quoteHref = post.replyToSeq
    ? `/community/t/${thread.slug}${pageOfSeq(post.replyToSeq) > 1 ? `?page=${pageOfSeq(post.replyToSeq)}` : ""}#post-${post.replyToSeq}`
    : undefined;
  const hasReports = (reader.reportCounts.get(post.id) ?? 0) > 0;

  return (
    <article
      id={anchor}
      className={`flex scroll-mt-24 gap-3 rounded-xl ${opening ? "border border-orange-200 bg-orange-50/70 p-3 dark:border-orange-900/50 dark:bg-orange-950/20" : ""}`}
    >
      <UserAvatar username={post.username} avatarUrl={post.avatarUrl} size={opening ? "h-9 w-9" : "h-8 w-8"} textSize="text-xs" />
      <div className="flex min-w-0 flex-1 flex-col gap-1">
        <div className="flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-xs text-zinc-500">
          <UsernameLink
            username={post.username}
            userId={post.userId}
            avatar={false}
            tier={tierOf(post.role)}
            badge="colour"
            className="flex min-w-0 max-w-full items-center font-medium text-zinc-700 dark:text-zinc-300"
          />
          {opening && (
            <span className="flex items-center gap-1 rounded bg-orange-500 px-1.5 text-[11px] font-semibold text-white">
              <Icon name="pen-line" className="size-3" />
              Original post
            </span>
          )}
          {thread.userId === post.userId && !opening && (
            <span className="rounded bg-orange-100 px-1.5 text-[11px] font-semibold text-orange-700 dark:bg-orange-950/50 dark:text-orange-300">Starter</span>
          )}
          {isBest && (
            <span className="flex items-center gap-0.5 rounded bg-green-100 px-1.5 text-[11px] font-semibold text-green-800 dark:bg-green-950/50 dark:text-green-300">
              <Icon name="circle-check" className="size-3" />
              Best answer
            </span>
          )}
          <span aria-hidden>·</span>
          <a href={`#${anchor}`} className="whitespace-nowrap hover:underline" title={formatDate(post.createdAt)}>
            <time dateTime={post.createdAt}>{timeAgo(post.createdAt)}</time>
          </a>
          {post.edited && <span>· {post.editedByTeam ? "edited by our team" : "edited"}</span>}
          <span className="ml-auto text-zinc-500 dark:text-zinc-400">#{post.seq}</span>
        </div>

        {post.replyToSeq && post.replyToUsername && (
          <a href={quoteHref} className="flex min-w-0 flex-col gap-0.5 rounded-lg border-l-2 border-zinc-200 bg-zinc-50 px-3 py-1.5 text-xs text-zinc-500 hover:bg-zinc-100 dark:border-zinc-700 dark:bg-zinc-950 dark:hover:bg-zinc-800">
            <span className="flex items-center gap-1 font-medium">
              <Icon name="corner-down-right" className="size-3 shrink-0" />
              <span className="truncate">{post.replyToUsername}</span>
            </span>
            {post.replyToSnippet && <span className="line-clamp-2 [overflow-wrap:anywhere]">{post.replyToSnippet}</span>}
          </a>
        )}

        <PostActions
          f={{
            postId: post.id,
            threadId: thread.id,
            seq: post.seq,
            username: post.username,
            createdAt: post.createdAt,
            rawText: own || (reader.canModerate && acts) ? post.text : null,
            loggedIn: reader.loggedIn,
            canReply: reader.canReply,
            own,
            teamEdit: reader.canModerate && acts,
            canHide: reader.canTidy && acts && !opening && !reader.canModerate,
            canRemove: reader.canModerate && acts,
            canDismiss: reader.canModerate && acts && (hasReports || false),
            opening,
            best:
              thread.spaceKind === "ask" && !opening && (reader.isAsker || reader.canTidy)
                ? isBest
                  ? "unmark"
                  : "mark"
                : null,
            liked: reader.liked.has(post.id),
            likeCount: post.likeCount,
            reported: reader.reported.has(post.id),
            // New pictures in an edit: the writer's own allowance (the team keeps what's there).
            maxPictures: own && !reader.picturesAllowed ? 0 : opening ? MAX_PICTURES.thread : MAX_PICTURES.reply,
          }}
        >
          <PostBody postId={post.id} username={post.username} text={post.text} hosts={reader.hosts} pictures={reader.pictures.get(post.id) ?? []} large={opening} />
        </PostActions>
      </div>
    </article>
  );
}

// "Started by alice" strip shown on later pages, where the opening post isn't.
export function StartedBy({ thread }: { thread: ThreadRow }) {
  return (
    <p className="text-sm text-zinc-500">
      Started by <span className="font-medium text-zinc-700 dark:text-zinc-300">{thread.username}</span>.{" "}
      <Link href={`/community/t/${thread.slug}`} className="font-medium text-orange-700 hover:underline dark:text-orange-400">
        Back to the first post
      </Link>
    </p>
  );
}
