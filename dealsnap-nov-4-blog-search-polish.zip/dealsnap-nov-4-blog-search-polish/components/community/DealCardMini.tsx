import Link from "next/link";
import { getDealBySlug } from "@/lib/mock-deals";
import { dealPriceTag, priceTagText } from "@/lib/deal-kinds";
import { isExpired } from "@/lib/format";
import DealThumbnail from "../DealThumbnail";

// A deal pasted into a post (its address on a line of its own) opens as this
// small card: picture, title, price and store. A deal that has gone or isn't
// public is simply left out, so nothing private can leak through a pasted address.
export default function DealCardMini({ slug }: { slug: string }) {
  const deal = getDealBySlug(slug);
  if (!deal || deal.status === "pending" || deal.status === "removed") return null;
  const over = isExpired(deal.expiresAt) || !!deal.endedByMembers;
  // A voucher's dashed violet edge, as on its card everywhere else.
  const voucher = deal.kind === "voucher";
  return (
    <Link
      href={`/deals/${deal.slug}`}
      className={`flex min-w-0 items-center gap-3 rounded-xl border bg-zinc-50 p-2 transition-colors dark:bg-zinc-950 ${
        voucher
          ? "border-dashed border-violet-400 hover:border-violet-600 dark:border-violet-700 dark:hover:border-violet-500"
          : "border-zinc-200 hover:border-orange-300 dark:border-zinc-800 dark:hover:border-orange-700"
      }`}
    >
      <div className="size-14 shrink-0 overflow-hidden rounded-lg">
        <DealThumbnail deal={deal} iconSize="size-6" sizes="56px" backdrop="compact" />
      </div>
      <div className="flex min-w-0 flex-1 flex-col gap-0.5">
        <span className="line-clamp-2 text-sm font-semibold leading-snug text-zinc-900 dark:text-zinc-100">{deal.title}</span>
        <span className="flex min-w-0 items-center gap-1.5 text-xs text-zinc-500">
          <span className="shrink-0 font-semibold text-orange-700 dark:text-orange-400">{priceTagText(dealPriceTag(deal))}</span>
          <span aria-hidden>·</span>
          <span className="min-w-0 truncate">{deal.store}</span>
          {over && <span className="shrink-0 rounded bg-zinc-200 px-1.5 text-[11px] font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">Ended</span>}
        </span>
      </div>
    </Link>
  );
}
