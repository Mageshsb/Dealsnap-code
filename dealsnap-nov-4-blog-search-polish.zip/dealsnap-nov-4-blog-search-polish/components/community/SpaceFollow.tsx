"use client";

import { useState, useTransition } from "react";
import { followSpaceAction } from "@/lib/community-actions";
import Icon from "../Icon";
import StableLabel, { words } from "../StableLabel";

// "Follow" on a space: new threads in it reach the bell.
export default function SpaceFollow({ spaceId, following }: { spaceId: string; following: boolean }) {
  const [on, setOn] = useState(following);
  const [, startTransition] = useTransition();
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={() => {
        const next = !on;
        setOn(next);
        startTransition(async () => {
          if ((await followSpaceAction(spaceId, next)) === null) setOn(!next);
        });
      }}
      className={`flex min-h-9 items-center gap-1.5 rounded-xl px-3 text-sm font-medium transition-colors ${
        on ? "bg-orange-500 text-white" : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
      }`}
    >
      <Icon name={on ? "bell-ring" : "bell"} className="size-4" />
      <StableLabel options={words("Follow", "Following")} show={on ? "Following" : "Follow"} />
    </button>
  );
}
