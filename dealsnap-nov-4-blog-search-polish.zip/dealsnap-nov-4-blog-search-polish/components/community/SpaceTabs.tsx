import Link from "next/link";
import type { SpaceRow } from "@/lib/community-db";
import Icon from "../Icon";

// The spaces as tabs, with "All" first (the Community home), so a visitor in one
// space can see the others and step across without going back. Laptops and
// tablets only: on a phone the page's back link is the way to the spaces, which
// keeps the top of the page short.
export default function SpaceTabs({ spaces, current }: { spaces: Pick<SpaceRow, "id" | "slug" | "name" | "icon">[]; current: string }) {
  const tab = "flex min-h-9 items-center gap-1.5 rounded-xl px-3 text-sm font-medium transition-colors";
  return (
    <nav aria-label="Spaces" className="hidden flex-wrap gap-2 sm:flex">
      <Link href="/community" className={`${tab} bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700`}>
        <Icon name="replies" className="size-4" />
        All spaces
      </Link>
      {spaces.map((s) => (
        <Link
          key={s.id}
          href={`/community/${s.slug}`}
          aria-current={s.slug === current ? "page" : undefined}
          className={`${tab} ${s.slug === current ? "bg-orange-500 text-white" : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"}`}
        >
          <Icon name={s.icon} className="size-4" />
          {s.name}
        </Link>
      ))}
    </nav>
  );
}
