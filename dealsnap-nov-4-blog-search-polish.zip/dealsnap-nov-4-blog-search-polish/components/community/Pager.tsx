import Link from "next/link";
import Icon from "../Icon";

// First / Prev / "Page 2 of 7" / Next / Last under a list or a thread (First and
// Last only once there are more than two pages, and as small icon buttons so the
// row still fits a phone). `keep` is any other
// choice in the address (the sort) so turning the page doesn't undo it.
export default function Pager({
  basePath,
  page,
  totalPages,
  keep = {},
  anchor,
}: {
  basePath: string;
  page: number;
  totalPages: number;
  keep?: Record<string, string | undefined>;
  anchor?: string;
}) {
  if (totalPages <= 1) return null;
  const href = (p: number) => {
    const q = new URLSearchParams(Object.entries(keep).filter((e): e is [string, string] => !!e[1]));
    if (p > 1) q.set("page", String(p));
    const query = q.toString();
    return `${basePath}${query ? `?${query}` : ""}${anchor ? `#${anchor}` : ""}`;
  };
  const edge = "inline-flex min-h-9 items-center gap-0.5 rounded-full border border-zinc-300 py-1 text-sm dark:border-zinc-700";
  const end = "inline-flex size-9 items-center justify-center rounded-full border border-zinc-300 dark:border-zinc-700";
  return (
    <nav aria-label="Pages" className="flex items-center justify-center gap-2 pt-1 sm:gap-3">
      {totalPages > 2 && (
        <Link href={href(1)} aria-label="First page" aria-disabled={page === 1} tabIndex={page === 1 ? -1 : undefined} className={`${end} ${page === 1 ? "pointer-events-none opacity-40" : "hover:bg-zinc-50 dark:hover:bg-zinc-800"}`}>
          <Icon name="chevrons-left" className="size-4" />
        </Link>
      )}
      <Link
        href={href(Math.max(1, page - 1))}
        aria-disabled={page === 1}
        tabIndex={page === 1 ? -1 : undefined}
        className={`${edge} pl-2 pr-3 ${page === 1 ? "pointer-events-none opacity-40" : "hover:bg-zinc-50 dark:hover:bg-zinc-800"}`}
      >
        <Icon name="chevron-left" className="size-4" />
        <span className="max-[359px]:sr-only">Prev</span>
      </Link>
      <span className="text-sm text-zinc-500">
        Page {page} of {totalPages}
      </span>
      <Link
        href={href(Math.min(totalPages, page + 1))}
        aria-disabled={page === totalPages}
        tabIndex={page === totalPages ? -1 : undefined}
        className={`${edge} pl-3 pr-2 ${page === totalPages ? "pointer-events-none opacity-40" : "hover:bg-zinc-50 dark:hover:bg-zinc-800"}`}
      >
        <span className="max-[359px]:sr-only">Next</span>
        <Icon name="chevron-right" className="size-4" />
      </Link>
      {totalPages > 2 && (
        <Link
          href={href(totalPages)}
          aria-label="Last page"
          aria-disabled={page === totalPages}
          tabIndex={page === totalPages ? -1 : undefined}
          className={`${end} ${page === totalPages ? "pointer-events-none opacity-40" : "hover:bg-zinc-50 dark:hover:bg-zinc-800"}`}
        >
          <Icon name="chevrons-right" className="size-4" />
        </Link>
      )}
    </nav>
  );
}
