"use client";

import { createContext, useContext, useEffect, useRef, useState, useTransition, type ReactNode } from "react";
import { usePathname, useRouter } from "next/navigation";
import { replyAction } from "@/lib/community-actions";
import { REPLY_MAX } from "@/lib/community-rules";
import Icon from "../Icon";
import RichEditor, { picturesToFiles } from "../RichEditor";

// Brings a post into view and flashes it once it's showing. A new reply
// arrives with the refreshed page a moment after posting, so this waits for it.
export function revealPost(seq: number, tries = 40) {
  const el = document.getElementById(`post-${seq}`);
  if (!el || !el.getClientRects().length) {
    if (tries > 0) requestAnimationFrame(() => revealPost(seq, tries - 1));
    return;
  }
  history.replaceState(null, "", `${location.pathname}${location.search}#post-${seq}`);
  el.scrollIntoView({ behavior: "smooth", block: "center" });
  el.classList.remove("comment-flash");
  void el.offsetWidth; // restarts the flash if it's already run
  el.classList.add("comment-flash");
}

type Target = { id: string; username: string };
const OpenReply = createContext<((target: Target) => void) | null>(null);

// "Reply" under any post in the thread: opens (or retargets) the box at the end.
export function ReplyButton({ id, username }: Target) {
  const openReply = useContext(OpenReply);
  if (!openReply) return null;
  return (
    <button type="button" onClick={() => openReply({ id, username })} className="flex items-center gap-1 transition-colors hover:text-orange-500">
      <Icon name="reply" className="size-3.5" />
      Reply
    </button>
  );
}

// The thread's posts, and the reply box after them. The box sits as one line
// until it's tapped; "Reply" on a post points it at that post ("Replying to
// bob"), and the reply keeps a small quote of it. Posting doesn't reload the
// page: the new post appears and is brought into view (on its own page if the
// thread has grown past this one).
export default function Replies({
  threadSlug,
  page,
  canReply,
  mentionNames = [],
  notice,
  maxPictures = 0,
  children,
}: {
  threadSlug: string;
  page: number;
  canReply: boolean;
  // Who has posted in the thread, offered when "@" is typed.
  mentionNames?: string[];
  // Why there is no box (locked, not signed in, muted…), shown in its place.
  notice?: ReactNode;
  // Pictures a reply can have (0 for a brand-new account).
  maxPictures?: number;
  children: ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [target, setTarget] = useState<Target | null>(null);
  const [text, setText] = useState("");
  const [pictures, setPictures] = useState<Record<string, string>>({});
  const [opened, setOpened] = useState(false);
  const [error, setError] = useState("");
  const [pending, startTransition] = useTransition();
  const form = useRef<HTMLFormElement>(null);
  const open = !!target || opened || text.length > 0;

  // "Reply" on a post opens the box and brings it into view, ready to type.
  useEffect(() => {
    if (!target) return;
    requestAnimationFrame(() => {
      form.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      form.current?.querySelector<HTMLElement>("[contenteditable]")?.focus({ preventScroll: true });
    });
  }, [target]);

  function reset() {
    setText("");
    setPictures({});
    setOpened(false);
    setTarget(null);
    setError("");
  }

  function post() {
    if (!text.trim() || pending) return;
    setError("");
    startTransition(async () => {
      const sent = new FormData();
      for (const file of await picturesToFiles(text, pictures)) sent.append("pictures", file);
      const result = await replyAction(threadSlug, target?.id ?? null, text, sent);
      if ("error" in result) return setError(result.error);
      reset();
      if (result.page === page) {
        router.refresh();
        revealPost(result.seq);
      } else {
        router.push(`${pathname}?page=${result.page}#post-${result.seq}`);
      }
    });
  }

  return (
    <OpenReply.Provider value={setTarget}>
      {children}
      {canReply ? (
        <form
          ref={form}
          onSubmit={(e) => {
            e.preventDefault();
            post();
          }}
          className="flex flex-col gap-2 border-t border-zinc-100 pt-4 dark:border-zinc-800"
        >
          {target && (
            <div className="flex items-center justify-between gap-2 text-xs text-zinc-500">
              <span className="min-w-0 truncate">
                Replying to <span className="font-medium text-zinc-700 dark:text-zinc-300">{target.username}</span>
              </span>
              <button type="button" onClick={() => setTarget(null)} aria-label="Reply to the thread instead" className="-m-1 shrink-0 rounded-full p-1 hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-zinc-800 dark:hover:text-zinc-200">
                <Icon name="x" className="size-4" />
              </button>
            </div>
          )}
          {open ? (
            <RichEditor
              value={text}
              onChange={setText}
              pictures={pictures}
              onPictures={setPictures}
              placeholder={target ? `Reply to ${target.username}…` : mentionNames.length ? "Add a reply… type @ to mention someone" : "Add a reply…"}
              label={target ? `Reply to ${target.username}` : "Add a reply"}
              maxPictures={maxPictures}
              mentionNames={mentionNames}
              onCtrlEnter={post}
              autoFocus={opened && !target}
              minHeight="min-h-[5rem]"
            />
          ) : (
            // One line until it's tapped, so the thread ends tidily.
            <button
              type="button"
              onClick={() => setOpened(true)}
              className="w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-left text-base text-zinc-400 hover:border-zinc-400 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-500"
            >
              {mentionNames.length ? "Add a reply… type @ to mention someone" : "Add a reply…"}
            </button>
          )}
          {error && (
            <p role="alert" className="text-xs text-amber-700 dark:text-amber-400">
              {error}
            </p>
          )}
          {open && (
            <div className="flex items-center justify-end gap-2">
              {text.length > REPLY_MAX - 300 && (
                <span className="mr-auto text-xs tabular-nums text-zinc-500 dark:text-zinc-400">
                  {text.length}/{REPLY_MAX}
                </span>
              )}
              <button
                type="button"
                onClick={reset}
                className="rounded-full px-3 py-1.5 text-sm font-medium text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
              >
                Cancel
              </button>
              <button type="submit" disabled={pending || !text.trim()} className="rounded-full bg-orange-500 px-4 py-1.5 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60">
                {pending ? "Posting…" : "Reply"}
              </button>
            </div>
          )}
        </form>
      ) : (
        notice && <div className="border-t border-zinc-100 pt-4 text-sm text-zinc-500 dark:border-zinc-800">{notice}</div>
      )}
    </OpenReply.Provider>
  );
}
