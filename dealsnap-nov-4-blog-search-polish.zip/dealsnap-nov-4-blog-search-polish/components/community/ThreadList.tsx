import { Fragment } from "react";
import type { ThreadRow as Thread } from "@/lib/community-db";
import { adPositions } from "@/lib/ad-positions";
import type { SlotFill } from "@/lib/ads";
import AdUnit from "../AdUnit";
import ThreadRow from "./ThreadRow";

// A list of conversations in one white card, with the Community's ad space
// between them where Admin → Ads has switched it on (never first, never
// last, and always at the sizes that space is set to).
export default function ThreadList({
  rows,
  unread,
  showSpace = true,
  ad,
}: {
  rows: Thread[];
  // For threads with replies the reader hasn't seen: the last post they did see.
  unread: Map<string, number>;
  showSpace?: boolean;
  ad?: SlotFill;
}) {
  const after = ad ? adPositions(rows.length, ad.first, ad.every, [], true, ad.max) : [];
  return (
    <div className="flex flex-col divide-y divide-zinc-100 rounded-xl border border-zinc-200 bg-white p-4 dark:divide-zinc-800 dark:border-zinc-800 dark:bg-zinc-900 [&>*:first-child]:pt-0 [&>*:last-child]:pb-0">
      {rows.map((t, i) => (
        <Fragment key={t.id}>
          <ThreadRow thread={t} seenTo={unread.get(t.id)} showSpace={showSpace} />
          {after.includes(i) && <AdUnit slot="community-list" n={after.indexOf(i)} className="my-3.5" />}
        </Fragment>
      ))}
    </div>
  );
}
