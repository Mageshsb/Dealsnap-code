"use client";

import { createContext, useContext, useSyncExternalStore } from "react";
import { HIDE_LOCAL_COOKIE, SHOW_EXPIRED_COOKIE, type RememberedFilters } from "@/lib/remembered-filters";

const ExpiredFilterContext = createContext<{
  showExpired: boolean;
  setShowExpired: (value: boolean) => void;
  hideLocal: boolean;
  setHideLocal: (value: boolean) => void;
} | null>(null);

// Both choices are remembered on this device in cookies, which the page reads
// before drawing (app/layout passes them in as `initial`), so a list never
// appears one way and then changes. A change made here reaches every list on
// the page at once, and other tabs pick it up when you go back to them.
const CHANGED = "dealsnap:filters-changed";

function subscribe(onChange: () => void) {
  window.addEventListener(CHANGED, onChange);
  document.addEventListener("visibilitychange", onChange);
  return () => {
    window.removeEventListener(CHANGED, onChange);
    document.removeEventListener("visibilitychange", onChange);
  };
}

const cookieOn = (name: string) => document.cookie.split("; ").includes(`${name}=1`);

function useRemembered(name: string, initial: boolean): [boolean, (value: boolean) => void] {
  const value = useSyncExternalStore(subscribe, () => cookieOn(name), () => initial);
  function set(next: boolean) {
    document.cookie = `${name}=${next ? 1 : 0}; path=/; max-age=31536000; samesite=lax${location.protocol === "https:" ? "; secure" : ""}`;
    window.dispatchEvent(new Event(CHANGED));
  }
  return [value, set];
}

export function ExpiredFilterProvider({ initial, children }: { initial: RememberedFilters; children: React.ReactNode }) {
  const [showExpired, setShowExpired] = useRemembered(SHOW_EXPIRED_COOKIE, initial.showExpired);
  const [hideLocal, setHideLocal] = useRemembered(HIDE_LOCAL_COOKIE, initial.hideLocal);

  return (
    <ExpiredFilterContext.Provider value={{ showExpired, setShowExpired, hideLocal, setHideLocal }}>
      {children}
    </ExpiredFilterContext.Provider>
  );
}

export function useExpiredFilter() {
  const ctx = useContext(ExpiredFilterContext);
  if (!ctx) throw new Error("useExpiredFilter must be used within an ExpiredFilterProvider");
  return ctx;
}
