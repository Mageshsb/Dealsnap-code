// The "Show more" button under a long list (Stores, Brands).
export default function ShowMoreButton({ noun, left, onClick }: { noun: string; left: number; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="mx-auto rounded-full border border-zinc-300 px-5 py-2 text-sm font-medium text-zinc-700 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
    >
      Show more {noun} ({left.toLocaleString("en-GB")} more)
    </button>
  );
}
