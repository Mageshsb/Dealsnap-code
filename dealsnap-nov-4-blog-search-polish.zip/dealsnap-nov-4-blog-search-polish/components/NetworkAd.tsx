"use client";

import { useEffect, useId, useSyncExternalStore } from "react";
import { COMPACT_SIZES, type NetworkSize } from "@/lib/ads";

// An ad space filled by the ad network (Google Ad Manager, set up in Admin →
// Ads → Ad network), for when no campaign of DealSnap's own fills it.
//
//   - Google's code loads once, only after the page has finished loading, so
//     it never slows the deals down; each space asks for its ad only as it
//     comes near the screen (lazy loading).
//   - Without a Google-certified consent tool on the site, Google is told to
//     serve "limited ads": no cookies and nothing personal, so no consent is
//     needed. With one, Google reads the visitor's choice from it.
//   - The space keeps its size whatever comes back. If nothing comes back and
//     it's still below the screen, it folds away (nothing visible moves).
//   - Not on local test copies (Google would count them).

type Slot = { addService(s: unknown): Slot; getSlotElementId(): string; defineSizeMapping(m: unknown): Slot };
type SizeMap = { addSize(viewport: [number, number], sizes: NetworkSize[]): SizeMap; build(): unknown };
type GoogleTag = {
  cmd: (() => void)[];
  pubads(): {
    setPrivacySettings(s: { limitedAds?: boolean }): void;
    enableLazyLoad(c: { fetchMarginPercent: number; renderMarginPercent: number; mobileScaling: number }): void;
    addEventListener(event: "slotRenderEnded", handler: (e: { isEmpty: boolean; slot: Slot }) => void): void;
  };
  setConfig?(c: { lazyLoad: { fetchMarginPercent: number; renderMarginPercent: number; mobileScaling: number } }): void;
  defineSlot(unit: string, sizes: NetworkSize[], divId: string): Slot | null;
  sizeMapping(): SizeMap;
  display(divId: string): void;
  destroySlots(slots: Slot[]): void;
  enableServices(): void;
};
const win = () => window as unknown as { googletag?: GoogleTag };

// Google's two addresses for its tag: the usual one, and the one for limited ads.
const STANDARD = "https://securepubads.g.doubleclick.net/tag/js/gpt.js";
const LIMITED = "https://pagead2.googlesyndication.com/tag/js/gpt.js";
const LAZY = { fetchMarginPercent: 150, renderMarginPercent: 50, mobileScaling: 2 };

let started = false;
const onEmpty = new Map<string, () => void>();

function start(personalised: boolean) {
  if (started) return;
  started = true;
  const gt = (win().googletag ??= { cmd: [] } as unknown as GoogleTag);
  gt.cmd.push(() => {
    const pubads = gt.pubads();
    if (!personalised) pubads.setPrivacySettings({ limitedAds: true });
    if (gt.setConfig) gt.setConfig({ lazyLoad: LAZY });
    else pubads.enableLazyLoad(LAZY);
    pubads.addEventListener("slotRenderEnded", (e) => {
      if (e.isEmpty) onEmpty.get(e.slot.getSlotElementId())?.();
    });
    gt.enableServices();
  });
  const script = document.createElement("script");
  script.src = personalised ? STANDARD : LIMITED;
  script.async = true;
  script.crossOrigin = "anonymous";
  document.head.appendChild(script);
}

function afterLoad(run: () => void): () => void {
  if (document.readyState === "complete") {
    const t = setTimeout(run, 0);
    return () => clearTimeout(t);
  }
  window.addEventListener("load", run, { once: true });
  return () => window.removeEventListener("load", run);
}

const noSubscribe = () => () => {};
function isLocalCopy() {
  const host = window.location.hostname;
  return host === "localhost" || host.endsWith(".local") || /^[\d.]+$/.test(host) || host === "[::1]" || host.endsWith(".trycloudflare.com");
}

export default function NetworkAd({
  unit,
  sizes,
  compact,
  personalised,
  className,
  onNothing,
}: {
  unit: string;
  sizes: NetworkSize[];
  compact?: boolean; // a strip: a laptop's banner (728×90) or a phone's (320×100), by screen width
  personalised: boolean;
  className: string; // the space's fixed size
  onNothing?: () => void; // nothing came back and the space is off screen
}) {
  const divId = `ad-${useId().replace(/[^a-zA-Z0-9_-]/g, "")}`;
  const local = useSyncExternalStore(noSubscribe, isLocalCopy, () => true);

  useEffect(() => {
    if (local) return;
    let slot: Slot | null = null;
    onEmpty.set(divId, () => {
      const el = document.getElementById(divId);
      if (el && el.getBoundingClientRect().top > window.innerHeight) onNothing?.();
    });
    const stop = afterLoad(() => {
      // Hidden on this screen (a phones-only or laptops-only space): no ad asked for.
      if (!document.getElementById(divId)?.getClientRects().length) return;
      start(personalised);
      win().googletag!.cmd.push(() => {
        const gt = win().googletag!;
        slot = gt.defineSlot(unit, sizes, divId);
        if (!slot) return;
        if (compact) {
          slot.defineSizeMapping(gt.sizeMapping().addSize([1024, 0], COMPACT_SIZES.laptop).addSize([0, 0], COMPACT_SIZES.phone).build());
        }
        slot.addService(gt.pubads());
        gt.display(divId);
      });
    });
    return () => {
      stop();
      onEmpty.delete(divId);
      win().googletag?.cmd.push(() => {
        if (slot) win().googletag!.destroySlots([slot]);
      });
    };
  }, [local, divId, unit, sizes, compact, personalised, onNothing]);

  return (
    <div className={`flex flex-col items-center gap-1 ${className}`}>
      <span className="text-[11px] leading-4 text-zinc-500 dark:text-zinc-400">Advertisement</span>
      {local ? (
        <div className="flex w-full flex-1 items-center justify-center rounded-lg border border-dashed border-zinc-300 text-xs text-zinc-500 dark:text-zinc-400 dark:border-zinc-700">
          The ad network&apos;s ad shows here on the live site
        </div>
      ) : (
        <div id={divId} className="flex min-h-0 w-full flex-1 items-center justify-center overflow-hidden" />
      )}
    </div>
  );
}
