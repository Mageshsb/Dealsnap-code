"use client";

import { useCallback, useState } from "react";
import { useSearchParams } from "next/navigation";
import { countNarrow, parseMinHearts, type Facet } from "@/lib/deal-filters";
import FilterBox from "./FilterBox";
import BottomSheet from "./BottomSheet";
import { FilterIcon } from "./icons";

// The phone's way into the filters. A pill beside the Most loved/New chips
// opens a bottom sheet over the page (see BottomSheet), holding the same
// options as the laptop's Filters box. `inList` is the List view's own row:
// hidden on laptops (the Filters box is beside the list there), never shrunk
// for short screens.
export default function SwipeFilters({ facets, inList }: { facets?: Facet[]; inList?: boolean }) {
  const [open, setOpen] = useState(false);
  const params = useSearchParams();
  const hearts = parseMinHearts(params.get("hearts"));
  const count = (hearts > 0 ? 1 : 0) + countNarrow(params);

  const close = useCallback(() => setOpen(false), []);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-haspopup="dialog"
        aria-label="Filters"
        className={`relative inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-sm font-medium transition-colors ${
          inList ? "lg:hidden" : "[@media(max-height:640px)]:px-2.5 [@media(max-height:640px)]:py-1 [@media(max-height:640px)]:text-xs"
        } ${
          count > 0
            ? "border-orange-500 bg-orange-50 text-orange-700 dark:bg-orange-950/30 dark:text-orange-300"
            : "border-zinc-200 text-zinc-700 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
        }`}
      >
        <FilterIcon className="h-4 w-4" />
        {/* Icon only on phones: the word and the chips don't fit one row at 360px. */}
        <span className="hidden sm:inline">Filters</span>
        {count > 0 && (
          // On phones the number sits on the icon's corner, so the pill is as wide as without it
          // (the row has no spare width at 360px); beside the word from 640px.
          <span className="absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-orange-500 px-1 text-xs font-semibold leading-none text-white sm:static">
            {count}
          </span>
        )}
      </button>

      <BottomSheet open={open} onClose={close} label="Filters" title="Filters">
        <FilterBox facets={facets} />
      </BottomSheet>
    </>
  );
}
