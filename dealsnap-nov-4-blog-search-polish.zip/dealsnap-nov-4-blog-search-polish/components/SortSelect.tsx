"use client";

import { createPortal } from "react-dom";
import Link from "next/link";
import { usePathname } from "next/navigation";
import Icon from "./Icon";
import { useAnchoredMenu } from "./useAnchoredMenu";

// The sort picker above a profile's deals, loved deals and comments, Saved deals,
// the Following feed and a deal's comments; the Stores page copies its look
// (its sort menu). Styled like the profile tabs (grey tile, rounded), and
// opens our own menu rather than the browser's plain grey dropdown. `keep` is any
// other choice on the page (the tab, a filter) so sorting doesn't undo it.
// `param` is the address key the choice is saved under (comments on a deal
// page use "commentSort" so they don't clash with anything else there).
export default function SortSelect({
  keep = {},
  current,
  options,
  param = "sort",
  label = "Sort by",
}: {
  keep?: Record<string, string | undefined>;
  current: string;
  options: { value: string; label: string }[];
  param?: string;
  label?: string;
}) {
  const pathname = usePathname();
  const { open, toggle, close, anchorRef, host, menuProps } = useAnchoredMenu<HTMLButtonElement>("right");
  const currentLabel = options.find((o) => o.value === current)?.label ?? options[0]?.label;
  const kept = Object.entries(keep).filter((e): e is [string, string] => !!e[1]);

  return (
    <>
      <button
        ref={anchorRef}
        type="button"
        onClick={toggle}
        aria-haspopup="true"
        aria-expanded={open}
        aria-label={`${label}: ${currentLabel}`}
        className={`flex min-h-9 items-center gap-1.5 rounded-xl px-3 text-sm font-medium transition-colors ${
          open
            ? "bg-zinc-200 text-zinc-900 dark:bg-zinc-700 dark:text-zinc-100"
            : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
        }`}
      >
        <Icon name="arrow-up-down" className="size-3.5 text-zinc-500 dark:text-zinc-400" />
        <span className="whitespace-nowrap">{currentLabel}</span>
        <Icon
          name="chevron-down"
          className={`size-3.5 text-zinc-500 dark:text-zinc-400 transition-transform ${open ? "rotate-180" : ""}`}
        />
      </button>

      {open &&
        host &&
        createPortal(
          <div
            {...menuProps}
            className={`${menuProps.className} min-w-48 rounded-xl border border-zinc-200 bg-white p-1 shadow-lg dark:border-zinc-800 dark:bg-zinc-900`}
          >
            <p className="px-3 pb-1 pt-1.5 text-xs font-medium text-zinc-500 dark:text-zinc-400">{label}</p>
            {options.map((o) => {
              const selected = o.value === current;
              return (
                <Link
                  key={o.value}
                  href={`${pathname}?${new URLSearchParams([...kept, [param, o.value]])}`}
                  scroll={false}
                  onClick={close}
                  aria-current={selected ? "true" : undefined}
                  className={`flex min-h-10 items-center justify-between gap-3 rounded-lg px-3 text-sm ${
                    selected
                      ? "bg-orange-50 font-medium text-orange-700 dark:bg-orange-950/40 dark:text-orange-400"
                      : "text-zinc-700 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
                  }`}
                >
                  {o.label}
                  {selected && (
                    <svg
                      aria-hidden
                      viewBox="0 0 16 16"
                      className="h-4 w-4"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="m3.5 8.5 3 3 6-7" />
                    </svg>
                  )}
                </Link>
              );
            })}
          </div>,
          host,
        )}
    </>
  );
}
