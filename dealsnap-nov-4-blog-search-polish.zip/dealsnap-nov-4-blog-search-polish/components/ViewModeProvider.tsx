"use client";

import { createContext, useContext, useState } from "react";
import { VIEW_COOKIE, type ViewMode } from "@/lib/view-mode";

export type { ViewMode };

const ViewModeContext = createContext<{
  mode: ViewMode;
  setMode: (mode: ViewMode) => void;
} | null>(null);

export function ViewModeProvider({ initialMode, children }: { initialMode: ViewMode; children: React.ReactNode }) {
  const [mode, setModeState] = useState<ViewMode>(initialMode);

  function setMode(next: ViewMode) {
    setModeState(next);
    const secure = window.location.protocol === "https:" ? "; secure" : "";
    document.cookie = `${VIEW_COOKIE}=${next}; path=/; max-age=31536000; samesite=lax${secure}`;
  }

  return (
    <ViewModeContext.Provider value={{ mode, setMode }}>{children}</ViewModeContext.Provider>
  );
}

export function useViewMode() {
  const ctx = useContext(ViewModeContext);
  if (!ctx) throw new Error("useViewMode must be used within a ViewModeProvider");
  return ctx;
}
