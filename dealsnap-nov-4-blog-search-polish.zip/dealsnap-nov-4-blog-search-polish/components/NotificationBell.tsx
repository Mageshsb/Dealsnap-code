"use client";

import Link from "next/link";
import { BellIcon } from "./icons";
import { CountBadge, useNotificationCount } from "./NotificationCount";

export default function NotificationBell() {
  const count = useNotificationCount();
  return (
    <Link
      href="/notifications"
      aria-label={count ? `Notifications, ${count} unread` : "Notifications"}
      title="Notifications"
      className="relative hidden h-10 w-10 shrink-0 items-center justify-center rounded-lg text-zinc-600 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-800 sm:flex lg:-mx-2 lg:h-9 lg:w-9"
    >
      <BellIcon className="h-5 w-5" />
      <CountBadge className="absolute -right-0.5 -top-0.5" />
    </Link>
  );
}
