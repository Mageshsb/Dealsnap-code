"use client";

import { useRef, useState } from "react";
import { ShareIcon } from "./icons";

// Copy without the Clipboard API, which browsers switch off on plain http
// (a phone opening the site by its Wi-Fi address) and in some in-app views.
function copyOldWay(text: string): boolean {
  const box = document.createElement("textarea");
  box.value = text;
  box.setAttribute("readonly", "");
  box.style.cssText = "position:fixed;top:0;left:0;opacity:0;font-size:16px";
  document.body.appendChild(box);
  box.select();
  box.setSelectionRange(0, text.length);
  let ok = false;
  try {
    ok = document.execCommand("copy");
  } catch {
    // fall through
  }
  box.remove();
  return ok;
}

export default function ShareButton({
  url,
  title,
  round = false,
  label = "Share this deal",
}: {
  url: string;
  title: string;
  label?: string;
  // A round button matching the heart buttons (the scroller), not a plain icon.
  round?: boolean;
}) {
  // Bumped on each copy so the "Link copied" label replays every time.
  const [copied, setCopied] = useState(0);
  const timer = useRef<number | undefined>(undefined);

  async function handleShare(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();

    const shareUrl = new URL(url, window.location.origin).toString();

    if (navigator.share) {
      try {
        await navigator.share({ title, url: shareUrl });
        return;
      } catch (err) {
        // Closing the share sheet counts as an error in some browsers (Safari
        // calls it NotAllowedError), so only a "can't share this here" error
        // falls back to copying; anything else means they dismissed it.
        const name = err instanceof Error ? err.name : "";
        if (name !== "TypeError" && name !== "NotSupportedError") return;
      }
    }

    let ok = false;
    try {
      await navigator.clipboard.writeText(shareUrl);
      ok = true;
    } catch {
      ok = copyOldWay(shareUrl);
    }
    if (ok) {
      setCopied((n) => n + 1);
      window.clearTimeout(timer.current);
      timer.current = window.setTimeout(() => setCopied(0), 1000);
    } else {
      window.prompt("Copy this link", shareUrl);
    }
  }

  return (
    <button
      onClick={handleShare}
      aria-label={label}
      className={`relative ${
        round
          ? "flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-zinc-200 text-zinc-500 transition-colors hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-400 dark:hover:bg-zinc-800"
          : // The icon is small; an invisible margin round it makes it easy to tap on a phone without making the card any bigger.
            "flex shrink-0 items-center text-zinc-400 hover:text-zinc-600 after:absolute after:-inset-2 after:content-[''] dark:hover:text-zinc-300"
      }`}
    >
      <ShareIcon className={round ? "h-5 w-5" : "h-[18px] w-[18px]"} />
      {/* Where the phone has no share sheet the link is copied instead, and
          this little label says so, the same as "Saved" on the save button. */}
      {copied > 0 && (
        <span
          key={copied}
          role="status"
          style={round ? { transformOrigin: "0% 100%" } : undefined}
          className={`save-label pointer-events-none absolute z-10 whitespace-nowrap rounded-full bg-orange-500 px-2 py-0.5 text-[11px] font-bold text-white shadow-sm ring-2 ring-white dark:ring-zinc-900 ${
            round ? "save-label-up bottom-full left-0 mb-1.5" : "save-label-up-centred bottom-full left-1/2 mb-1.5"
          }`}
        >
          Link copied
        </span>
      )}
    </button>
  );
}
