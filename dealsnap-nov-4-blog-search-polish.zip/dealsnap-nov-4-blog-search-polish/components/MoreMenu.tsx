"use client";

import type { ReactNode } from "react";
import { createPortal } from "react-dom";
import Icon from "./Icon";
import { useAnchoredMenu } from "./useAnchoredMenu";

export const moreMenuItem =
  "flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-sm text-zinc-700 hover:bg-zinc-50 dark:text-zinc-300 dark:hover:bg-zinc-800";

// The quiet "⋯" at the end of a comment's line. What you can do with the
// comment (Edit and Delete on your own, Report on others') sits in its small
// menu, so a busy thread isn't a column of words. `onOpen` runs as it opens
// (to check what's allowed right now); `children` is given `close`.
export default function MoreMenu({
  label = "More options",
  onOpen,
  children,
}: {
  label?: string;
  onOpen?: () => void;
  children: (close: () => void) => ReactNode;
}) {
  const { open, toggle, close, anchorRef, host, menuProps } = useAnchoredMenu<HTMLButtonElement>("right");

  return (
    <>
      <button
        ref={anchorRef}
        type="button"
        onClick={() => {
          if (!open) onOpen?.();
          toggle();
        }}
        aria-label={label}
        aria-haspopup="menu"
        aria-expanded={open}
        className="-my-1 -mr-1.5 flex size-7 shrink-0 items-center justify-center rounded-full text-zinc-400 transition-colors hover:bg-zinc-100 hover:text-zinc-600 aria-expanded:bg-zinc-100 aria-expanded:text-zinc-600 dark:text-zinc-500 dark:hover:bg-zinc-800 dark:hover:text-zinc-300 dark:aria-expanded:bg-zinc-800"
      >
        <Icon name="ellipsis" className="size-4" />
      </button>
      {open &&
        host &&
        createPortal(
          <div
            {...menuProps}
            role="menu"
            className={`${menuProps.className} w-52 rounded-xl border border-zinc-200 bg-white py-1 shadow-lg dark:border-zinc-800 dark:bg-zinc-900`}
          >
            {children(close)}
          </div>,
          host
        )}
    </>
  );
}
