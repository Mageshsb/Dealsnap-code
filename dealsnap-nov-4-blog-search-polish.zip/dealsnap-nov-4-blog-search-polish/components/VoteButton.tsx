"use client";

import { forwardRef, useEffect, useId, useImperativeHandle, useRef, useState } from "react";
import { createPortal } from "react-dom";
import Link from "next/link";
import { voteOnDealAction } from "@/lib/actions";
import { useUserVotes } from "./UserVotesProvider";
import { useAnchoredMenu } from "./useAnchoredMenu";
import Icon from "./Icon";

// The outer ring is a soft fill (no outline) that follows the deal's rating (the
// number shown), the same for everyone so cards compare at a glance. One
// continuous scale, blue to grey to red: pale blue when cold, plain grey at 0
// (so a neutral deal still has its capsule), shading into red as it heats up
// (fully red by 140, deepest from 900). It grows a little stronger towards
// both ends (Nov 7: the user wanted colder and warmer to read a touch more),
// but stays pale, so the buttons and the black count keep their contrast.
const GREY = [120, 120, 120];
const BLUE = [59, 130, 246];
const RED = [239, 68, 68];
const FILL_ALPHA: [number, number][] = [
  [0, 0.08],
  [140, 0.09],
  [320, 0.115],
  [900, 0.145],
];
// Cold: blue by -40, a little deeper down to -100.
const COLD_ALPHA: [number, number] = [0.08, 0.125];
function ratingFill(hearts: number): { backgroundColor: string } {
  let target = RED;
  let mix = Math.min(1, Math.abs(hearts) / 140);
  let alpha = 0.08;
  if (hearts < 0) {
    target = BLUE;
    mix = Math.min(1, -hearts / 40);
    alpha = COLD_ALPHA[0] + (COLD_ALPHA[1] - COLD_ALPHA[0]) * Math.min(1, -hearts / 100);
  } else {
    alpha = FILL_ALPHA[FILL_ALPHA.length - 1][1];
    for (let i = 1; i < FILL_ALPHA.length; i++) {
      const [x1, a1] = FILL_ALPHA[i];
      if (hearts <= x1) {
        const [x0, a0] = FILL_ALPHA[i - 1];
        alpha = a0 + ((a1 - a0) * (hearts - x0)) / (x1 - x0);
        break;
      }
    }
  }
  const [r, g, b] = GREY.map((c, i) => Math.round(c + (target[i] - c) * mix));
  return { backgroundColor: `rgba(${r},${g},${b},${alpha.toFixed(3)})` };
}

// A solid broken heart, the partner of the solid love heart: filled in the
// current colour with the crack cut clean through it, so whatever is behind the
// button shows in the crack. Only used once "Not for me" is picked (a white
// heart on the solid blue ring); before that the outline reads better at this
// size, and the heart fills in as you vote. (Same outline and crack as the
// Lucide "heart-crack" icon; a plain fill would hide the crack.)
function BrokenHeart({ className }: { className: string }) {
  const crack = `crack-${useId().replace(/:/g, "")}`;
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" className={`shrink-0 ${className}`}>
      <defs>
        <mask id={crack} maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24">
          <rect width="24" height="24" fill="white" />
          <path
            d="M12.409 5.824c-.702.792-1.15 1.496-1.415 2.166l2.153 2.156a.5.5 0 0 1 0 .707l-2.293 2.293a.5.5 0 0 0 0 .707L12 15"
            fill="none"
            stroke="black"
            strokeWidth="2.6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </mask>
      </defs>
      <path
        d="M13.508 20.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5a5.5 5.5 0 0 1 9.591-3.677.6.6 0 0 0 .818.001A5.5 5.5 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5z"
        fill="currentColor"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="round"
        mask={`url(#${crack})`}
      />
    </svg>
  );
}

export type VoteButtonHandle = {
  vote: (direction: "love" | "unlove") => void;
};

type BurstHeart = {
  id: number;
  colour: string;
  size: string;
  x: number;
  y: number;
  rotate: number;
  delay: number;
};

type Burst = {
  id: number;
  kind: "love" | "unlove";
  // The "+5" that floats up; 0 for a signed-out tap, which shows hearts only.
  delta: number;
  hearts: BurstHeart[];
};

// The hearts that fall into the count (love) or are pulled out of it (not for me) when you vote: drawn
// icons in a few shades, so they look the same on every device.
const LOVE_COLOURS = ["text-red-500", "text-rose-400", "text-red-400"];
const UNLOVE_COLOURS = ["text-blue-400", "text-blue-500", "text-sky-400"];

const SIZES = ["size-5", "size-6", "size-9"];
const BURST_COUNT = 6;
const BURST_DURATION = 850;
// How long the "Log in to make your heart count" bubble stays for a signed-out tap.
const BUBBLE_MS = 5000;

function makeBurst(id: number, kind: "love" | "unlove", delta: number): Burst {
  const colours = kind === "love" ? LOVE_COLOURS : UNLOVE_COLOURS;
  return {
    id,
    kind,
    delta,
    hearts: Array.from({ length: BURST_COUNT }, (_, i) => ({
      id: i,
      colour: colours[Math.floor(Math.random() * colours.length)],
      size: SIZES[Math.floor(Math.random() * SIZES.length)],
      // Spreading either side of the count, and a short way up for a heart or
      // down for a broken one, so it stays on the card.
      x: (Math.random() - 0.5) * 70,
      y: kind === "love" ? -Math.random() * 6 : 4 + Math.random() * 24,
      rotate: (Math.random() - 0.5) * 60,
      delay: Math.random() * 120,
    })),
  };
}

export default forwardRef<
  VoteButtonHandle,
  { initialHearts: number; dealSlug: string; size?: "default" | "lg" }
>(function VoteButton({ initialHearts, dealSlug, size = "default" }, ref) {
  const [hearts, setHearts] = useState(initialHearts);
  const { loggedIn, votes, setVote, voteWeight, voteWeights, setVoteWeight } = useUserVotes();
  // Logged-in users: their saved vote (shared across every button for this
  // deal). A signed-out tap doesn't vote: it plays the hearts, says "Log in to
  // count" and offers the log-in bubble (see nudge), and the count stays true.
  const voted = loggedIn ? (votes[dealSlug] ?? null) : null;
  const { open: bubbleOpen, toggle: toggleBubble, close: closeBubble, anchorRef, host: bubbleHost, menuProps } = useAnchoredMenu<HTMLDivElement>("center");
  const bubbleTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  useEffect(() => () => clearTimeout(bubbleTimer.current), []);
  const [burst, setBurst] = useState<Burst | null>(null);
  const burstCounter = useRef(0);
  // Only the newest tap's answer from the server may set the count: a slow reply
  // to an earlier tap must never overwrite what a quicker second tap just showed.
  const latestTap = useRef(0);

  // Each tap moves the count by the member's vote strength (4–7, see
  // lib/votes.ts), and never by more: with a vote already in, tapping either
  // button takes it back by exactly what it added (your heart again, or the
  // broken heart after a heart, is -5, not -10). Tap again from there to vote
  // the other way.
  // Optimistic locally, then persisted server-side for logged-in users — the
  // server's authoritative total (and what the vote was really worth) is
  // reconciled in once it comes back. Guests keep a local-only vote.
  function playBurst(kind: "love" | "unlove", delta: number) {
    burstCounter.current += 1;
    const id = burstCounter.current;
    setBurst(makeBurst(id, kind, delta));
    window.setTimeout(() => {
      setBurst((current) => (current?.id === id ? null : current));
    }, BURST_DURATION);
  }

  // Signed out: the hearts still fall (the fun, with no "+5" as nothing was
  // added), and a small bubble under the pill offers Log in or Join free. Both
  // float over the page, so nothing shifts, and nothing is sent to the server.
  // Another tap just restarts the timer.
  function nudge(direction: "love" | "unlove") {
    playBurst(direction, 0);
    if (!bubbleOpen) toggleBubble();
    clearTimeout(bubbleTimer.current);
    bubbleTimer.current = setTimeout(closeBubble, BUBBLE_MS);
  }

  function vote(direction: "love" | "unlove") {
    if (!loggedIn) return nudge(direction);
    const next = voted ? null : direction;
    const amount = next ? voteWeight : (voteWeights[dealSlug] ?? voteWeight);
    // Which way the count moves: up for a new heart or a broken heart taken back.
    const up = next ? next === "love" : voted === "unlove";
    setHearts((n) => (up ? n + amount : n - amount));
    setVote(dealSlug, next, voteWeight);
    playBurst(up ? "love" : "unlove", amount);

    const tap = ++latestTap.current;
    voteOnDealAction(dealSlug, next).then((result) => {
      if (!result || tap !== latestTap.current) return;
      setHearts(result.hearts);
      if (result.weight) setVoteWeight(dealSlug, result.weight);
    });
  }

  useImperativeHandle(ref, () => ({ vote }));

  const btnSize = size === "lg" ? "h-10 w-10" : "h-8 w-8";
  const iconSize = size === "lg" ? "size-5" : "size-4";
  const ringInset = size === "lg" ? "-inset-1" : "-inset-[3px]";
  const countSize = size === "lg" ? "min-w-[3ch] text-base" : "min-w-[3ch]";

  return (
    <div ref={anchorRef} className={`relative isolate flex items-center ${size === "lg" ? "gap-2" : "gap-1.5 sm:gap-2"}`}>
      {/* The outer ring: drawn outside the buttons (negative inset), so it
          adds nothing to the control's size or to the row around it. */}
      <span
        aria-hidden="true"
        style={ratingFill(hearts)}
        className={`pointer-events-none absolute -z-10 rounded-full transition-colors duration-300 ${ringInset}`}
      />
      {burst && (
        <div className="pointer-events-none absolute inset-0 z-10">
          {burst.hearts.map((h) => (
            <span
              key={h.id}
              className={`absolute left-1/2 top-1/2 ${burst.kind === "love" ? "vote-fall-in" : "vote-burst-down"}`}
              style={
                {
                  "--tx": `${h.x}px`,
                  "--ty": `${h.y}px`,
                  "--rot": `${h.rotate}deg`,
                  animationDelay: `${h.delay}ms`,
                } as React.CSSProperties
              }
            >
              <Icon
                name={burst.kind === "love" ? "heart" : "heart-crack"}
                filled={burst.kind === "love"}
                className={`${h.size} ${h.colour}`}
              />
            </span>
          ))}
          {burst.delta > 0 && (
            <span
              className={`absolute left-1/2 top-1/2 text-3xl font-extrabold tabular-nums ${
                burst.kind === "love" ? "vote-delta-in" : "vote-delta-pop"
              } ${
                burst.kind === "love" ? "text-red-600 dark:text-red-400" : "text-blue-600 dark:text-blue-400"
              }`}
            >
              {burst.kind === "love" ? "+" : "-"}
              {burst.delta}
            </span>
          )}
        </div>
      )}

      <button
        onClick={() => vote("unlove")}
        aria-label="Not for me"
        aria-pressed={voted === "unlove"}
        className={`flex items-center justify-center rounded-full border transition-colors ${btnSize} ${
          voted === "unlove"
            ? "border-blue-500 bg-blue-500 text-white"
            : "border-blue-200 text-blue-500 hover:border-blue-500 hover:bg-blue-50 dark:border-blue-500/40 dark:text-blue-400 dark:hover:bg-blue-500/10"
        }`}
      >
        {voted === "unlove" ? <BrokenHeart className={iconSize} /> : <Icon name="heart-crack" className={iconSize} />}
      </button>
      <span
        // No kerning: with it, two 1s side by side sit a touch closer, so the pill's
        // width would depend on the digits and not only how many there are.
        className={`text-center font-semibold tabular-nums [font-kerning:none] transition-colors ${countSize} ${
          burst ? (burst.kind === "love" ? "vote-count-pop-love" : "vote-count-pop-unlove") : ""
        }`}
      >
        {hearts}
      </span>
      <button
        onClick={() => vote("love")}
        aria-label="Love this deal"
        aria-pressed={voted === "love"}
        className={`flex items-center justify-center rounded-full border transition-colors ${btnSize} ${
          voted === "love"
            ? "border-red-500 bg-red-500 text-white"
            : "border-red-200 text-red-500 hover:border-red-500 hover:bg-red-50 dark:border-red-500/40 dark:text-red-400 dark:hover:bg-red-500/10"
        }`}
      >
        <Icon name="heart" filled className={iconSize} />
      </button>

      {/* The signed-out bubble: drawn over the page (kept on screen by the same
          helper as every pop-up menu), so it adds nothing to the card's size. */}
      {bubbleOpen &&
        bubbleHost &&
        createPortal(
          <div
            {...menuProps}
            role="status"
            className={`${menuProps.className} w-56 rounded-xl border border-zinc-200 bg-white p-3 text-sm shadow-lg dark:border-zinc-700 dark:bg-zinc-900`}
          >
            <p className="font-medium text-zinc-900 dark:text-zinc-100">Log in to make your heart count</p>
            <div className="mt-2 flex gap-2">
              <Link
                href={`/login?next=${encodeURIComponent(window.location.pathname + window.location.search)}`}
                className="flex min-h-10 flex-1 items-center justify-center rounded-lg bg-orange-500 px-3 font-semibold text-white transition-colors hover:bg-orange-600"
              >
                Log in
              </Link>
              <Link
                href={`/signup?next=${encodeURIComponent(window.location.pathname + window.location.search)}`}
                className="flex min-h-10 flex-1 items-center justify-center rounded-lg border border-zinc-300 px-3 font-semibold text-zinc-700 transition-colors hover:border-orange-400 hover:text-orange-600 dark:border-zinc-600 dark:text-zinc-200"
              >
                Join free
              </Link>
            </div>
          </div>,
          bubbleHost
        )}
    </div>
  );
});
