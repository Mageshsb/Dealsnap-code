"use client";

import { ReactNode, RefObject, useEffect, useRef, useState } from "react";

// The category strip above a list of deals. It scrolls away with the page,
// but the moment you scroll back up it slides down under the header, so you
// can switch category without going all the way to the top. Scrolling down
// tucks it away again.
//
// It's `sticky` the whole time (so it never changes the page's height and
// nothing jumps); when tucked away it's simply moved up out of sight behind
// the header. --list-sticky-top tells other sticky things (the desktop
// sidebar) where the free space starts, so the strip (and the row under it,
// while it shows) never covers them.
//
// `more` is an extra row hung underneath, shown only once `moreAfter` (the
// page's own copy of those controls) has gone up out of sight. It floats over
// the list rather than taking up room, so showing it never moves anything.
const MIN_MOVE = 8; // px of scrolling before it reacts, so a jittery thumb doesn't flicker it

export default function ScrollUpReveal({
  children,
  className = "",
  more,
  moreAfter,
}: {
  children: ReactNode;
  className?: string;
  more?: ReactNode;
  moreAfter?: RefObject<HTMLElement | null>;
}) {
  const markerRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const moreRef = useRef<HTMLDivElement>(null);
  const [headerHeight, setHeaderHeight] = useState(0);
  const [hidden, setHidden] = useState(false);
  const [pastControls, setPastControls] = useState(false);

  useEffect(() => {
    const header = document.querySelector<HTMLElement>("header");
    const measure = () => setHeaderHeight(header?.offsetHeight ?? 0);
    measure();
    const observer = new ResizeObserver(measure);
    if (header) observer.observe(header);

    let lastY = window.scrollY;
    let lastHeight = document.documentElement.scrollHeight;
    // Which way the person last scrolled. The only thing remembered: whether
    // the strip is tucked away is worked out from this and where the page is.
    let down = false;
    function update() {
      const marker = markerRef.current;
      const bar = barRef.current;
      if (!marker || !bar) return;
      // Where the strip's bottom edge would be if it just scrolled with the
      // page. Until it's gone under the header, there's nothing to hide (so
      // back at the top, after a filter threw the page there, it always shows).
      const naturalBottom = marker.getBoundingClientRect().top + bar.offsetHeight;
      const headerBottom = header?.getBoundingClientRect().bottom ?? 0;
      setHidden(down && naturalBottom < headerBottom);
      // The page's own controls are gone once they're up behind the strip.
      const controls = moreAfter?.current;
      if (controls) setPastControls(controls.getBoundingClientRect().bottom < headerBottom + bar.offsetHeight);
    }
    function onScroll() {
      const y = window.scrollY;
      const height = document.documentElement.scrollHeight;
      if (height !== lastHeight) {
        // The page itself got taller or shorter (a filter hid or showed deals,
        // more loaded): the browser moves the scroll position to compensate,
        // which isn't the person scrolling up, so the direction stays as it was.
        lastHeight = height;
        lastY = y;
      } else {
        const moved = y - lastY;
        if (Math.abs(moved) < MIN_MOVE) return;
        lastY = y;
        down = moved > 0;
      }
      update();
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      observer.disconnect();
    };
  }, [moreAfter]);

  useEffect(() => {
    const root = document.documentElement.style;
    const barHeight = barRef.current?.offsetHeight ?? 0;
    const moreHeight = pastControls ? (moreRef.current?.offsetHeight ?? 0) : 0;
    root.setProperty("--list-sticky-top", `${headerHeight + (hidden ? 0 : barHeight + moreHeight)}px`);
    return () => {
      root.removeProperty("--list-sticky-top");
    };
  }, [headerHeight, hidden, pastControls]);

  return (
    <>
      {/* Marks the strip's natural place in the page (the strip itself moves). */}
      <div ref={markerRef} aria-hidden />
      <div
        ref={barRef}
        style={{
          top: headerHeight,
          // No transform at all while showing, so nothing inside is affected.
          // The extra 4rem takes the row underneath out of sight too.
          transform: hidden ? `translateY(calc(-100% - ${headerHeight}px${more ? " - 4rem" : ""}))` : undefined,
        }}
        className={`sticky z-30 transition-transform duration-200 ease-out ${className}`}
      >
        {children}
        {more && (
          <div
            ref={moreRef}
            className={`absolute inset-x-0 top-full transition-[opacity,visibility] duration-150 ${pastControls ? "" : "invisible opacity-0"}`}
          >
            {more}
          </div>
        )}
      </div>
    </>
  );
}
