"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import Link from "next/link";
import UserAvatar from "./UserAvatar";
import Icon from "./Icon";
import { CountBadge } from "./NotificationCount";
import { AffiliateNote, useAffiliateNote } from "./AffiliateNote";
import { canInstall, promptInstall } from "@/lib/install-prompt";
import { useAnchoredMenu } from "./useAnchoredMenu";

// The top group, "you": outlined boxes like the ones at the foot of the
// category dropdown. The account (or log in) box runs full width, with the
// two personal shortcuts as tiles under it, icon over label.
const box =
  "rounded-lg border border-zinc-200 transition-colors hover:border-orange-300 hover:bg-orange-50 dark:border-zinc-700 dark:hover:border-orange-800 dark:hover:bg-orange-950/40";
const tile = `${box} relative flex min-h-[3.75rem] flex-col items-center justify-center gap-1 px-1 py-2 text-[13px] font-semibold text-zinc-700 hover:text-orange-700 dark:text-zinc-200 dark:hover:text-orange-400`;

const item =
  "flex min-h-11 items-center gap-2.5 px-4 text-sm font-medium text-zinc-700 hover:bg-zinc-50 dark:text-zinc-300 dark:hover:bg-zinc-800";

// The menu button (three lines) on phones and tablets: the same links as the desktop header (Categories,
// Stores, Blog, notifications, saved deals, your account), so both work the same way. Every
// category is one tap away on the Categories page and the bar above the deals.
// In three groups: you (your name, then Notifications and Saved deals as
// tiles, only on phones, as the header has them from tablet size up), the
// pages to explore, and the site itself (install, About).
// "Install the app" appears when the phone offers it (Android Chrome).
// Last, "About DealSnap": the About page lists the footer's links (contact,
// guidelines, terms…), so they're reachable even in card view, which hides the
// footer, without crowding the menu. Under it, the "*We may earn a commission"
// note that explains the "*" on "Get deal", for the same reason.
export default function MobileMenu({ username, avatarUrl }: { username?: string; avatarUrl?: string | null }) {
  const { open, toggle, close, anchorRef, host, menuProps } = useAnchoredMenu<HTMLButtonElement>("right");
  const affiliateNote = useAffiliateNote();

  // Shown only when the browser offers to install DealSnap (Android Chrome).
  const [installable, setInstallable] = useState(false);
  useEffect(() => {
    const check = () => setInstallable(canInstall());
    const timer = setTimeout(check, 0);
    window.addEventListener("ds-install-ready", check);
    window.addEventListener("appinstalled", check);
    return () => {
      clearTimeout(timer);
      window.removeEventListener("ds-install-ready", check);
      window.removeEventListener("appinstalled", check);
    };
  }, []);

  return (
    <div className="relative shrink-0 lg:hidden">
      <button
        ref={anchorRef}
        onClick={toggle}
        aria-label="Menu"
        aria-expanded={open}
        className="relative flex h-11 w-11 items-center justify-center rounded-lg text-zinc-600 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-800"
      >
        <Icon name="menu" className="size-6" />
        <CountBadge className="absolute right-0.5 top-0.5" />
      </button>

      {open &&
        host &&
        createPortal(
          <div
            {...menuProps}
            className={`${menuProps.className} w-64 rounded-xl border border-zinc-200 bg-white py-1 shadow-lg dark:border-zinc-800 dark:bg-zinc-900`}
          >
            <div className="flex flex-col gap-1.5 px-2 pb-1 pt-1">
              {username ? (
                <Link href="/account" onClick={close} className={`${box} flex min-h-16 items-center gap-3 px-3 py-2`}>
                  <UserAvatar username={username} avatarUrl={avatarUrl} size="h-10 w-10" />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[15px] font-bold text-zinc-900 dark:text-zinc-100">
                      {username}
                    </span>
                    <span className="block text-xs font-medium text-orange-700 dark:text-orange-400">My account →</span>
                  </span>
                </Link>
              ) : (
                <Link
                  href="/login"
                  onClick={close}
                  className={`${box} flex min-h-14 items-center justify-center px-3 text-sm font-semibold text-zinc-800 hover:text-orange-700 dark:text-zinc-100 dark:hover:text-orange-400`}
                >
                  Log in or join free
                </Link>
              )}
              {username && (
                <div className="grid grid-cols-2 gap-1.5 sm:hidden">
                  <Link href="/notifications" onClick={close} className={tile}>
                    <span className="relative">
                      <Icon name="bell" className="size-5 text-zinc-500 dark:text-zinc-400" />
                      <CountBadge className="absolute -right-2.5 -top-1.5" />
                    </span>
                    Notifications
                  </Link>
                  <Link href="/saved" onClick={close} className={tile}>
                    <Icon name="bookmark" className="size-5 text-zinc-500 dark:text-zinc-400" />
                    Saved deals
                  </Link>
                </div>
              )}
            </div>

            <div className="my-1 border-t border-zinc-100 dark:border-zinc-800" />

            {/* Voucher codes first, as in the laptop's Browse menu. */}
            <Link href="/vouchers" onClick={close} className={item}>
              <Icon name="ticket" className="size-[18px] text-violet-600 dark:text-violet-400" />
              Voucher codes
            </Link>
            <Link href="/categories" onClick={close} className={item}>
              <Icon name="grid" className="size-[18px] text-zinc-500 dark:text-zinc-400" />
              Categories
            </Link>
            <Link href="/stores" onClick={close} className={item}>
              <Icon name="store" className="size-[18px] text-zinc-500 dark:text-zinc-400" />
              Stores
            </Link>
            <Link href="/brands" onClick={close} className={item}>
              <Icon name="badge-check" className="size-[18px] text-zinc-500 dark:text-zinc-400" />
              Brands
            </Link>
            <Link href="/community" onClick={close} className={item}>
              <Icon name="users" className="size-[18px] text-zinc-500 dark:text-zinc-400" />
              Community
            </Link>
            <Link href="/blog" onClick={close} className={item}>
              <Icon name="newspaper" className="size-[18px] text-zinc-500 dark:text-zinc-400" />
              Blog
            </Link>
            <div className="my-1 border-t border-zinc-100 dark:border-zinc-800" />
            {installable && (
              <button
                type="button"
                onClick={() => {
                  close();
                  promptInstall().finally(() => setInstallable(canInstall()));
                }}
                className={`${item} w-full text-left`}
              >
                <Icon name="download" className="size-[18px] text-zinc-500 dark:text-zinc-400" />
                Install the app
              </button>
            )}
            <Link href="/about" onClick={close} className={item}>
              <Icon name="info" className="size-[18px] text-zinc-500 dark:text-zinc-400" />
              About DealSnap
            </Link>
            {affiliateNote && (
              <p
                onClick={close}
                className="border-t border-zinc-100 px-4 pb-1 pt-2.5 text-[11px] text-zinc-500 dark:text-zinc-400 dark:border-zinc-800"
              >
                <AffiliateNote text={affiliateNote} />
              </p>
            )}
          </div>,
          host,
        )}
    </div>
  );
}
