"use client";

import { useEffect, useRef, useSyncExternalStore } from "react";
import { createPortal } from "react-dom";

// How far through a long read you are (blog posts, Terms, Privacy,
// Guidelines): an orange line along the bottom edge of the header that fills
// from left to right. It lives in the header's slot (#reading-progress in
// components/Header.tsx), so it's always in view and never sits under a
// phone's clock or notch. Drawn by moving one element, so scrolling never
// re-renders anything, and it takes no room in the page.
const noSubscribe = () => () => {};

export default function ReadingProgress({ targetId }: { targetId: string }) {
  const bar = useRef<HTMLDivElement>(null);
  const slot = useSyncExternalStore(
    noSubscribe,
    () => document.getElementById("reading-progress"),
    () => null,
  );

  useEffect(() => {
    const target = document.getElementById(targetId);
    if (!target || !slot) return;
    let frame = 0;
    const update = () => {
      const box = target.getBoundingClientRect();
      const total = box.height - window.innerHeight * 0.5;
      const atEnd = window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4;
      const done = atEnd ? 1 : total > 0 ? Math.min(1, Math.max(0, -box.top / total)) : 0;
      if (bar.current) {
        bar.current.style.transform = `scaleX(${done})`;
        bar.current.style.opacity = done > 0 ? "1" : "0";
      }
    };
    const onScroll = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [targetId, slot]);

  if (!slot) return null;
  return createPortal(
    <div ref={bar} className="h-full origin-left bg-orange-500 opacity-0 transition-opacity" style={{ transform: "scaleX(0)" }} />,
    slot,
  );
}
