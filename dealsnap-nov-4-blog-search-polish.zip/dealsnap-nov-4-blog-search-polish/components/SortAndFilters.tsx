import DealViewTabs from "./DealViewTabs";
import type { LovedWindow, SearchSort } from "@/lib/deal-views";
import SwipeFilters from "./SwipeFilters";
import type { Facet } from "@/lib/deal-filters";

// The Most loved/New chips (with Most loved's time window) and the Filters
// pill, which opens the filters as a sheet. One row, sized to fit a 360px
// phone. Shown above the card in the Scroll view. `inList` is the List view's
// row: under the title, and the very same row again under the category strip
// when you scroll back up from halfway down the list. Its pill is phones and
// tablets only, as laptops have the Filters box beside the list.
export default function SortAndFilters({
  active,
  when,
  basePath,
  minHearts = 0,
  filterQuery,
  facets,
  searchQuery,
  inList,
}: {
  active: SearchSort;
  when?: LovedWindow;
  basePath?: string;
  minHearts?: number;
  filterQuery?: string; // chosen store/category/type, kept when switching view
  facets?: Facet[]; // Store or Category, and Deal type, for the Filters sheet
  searchQuery?: string; // search results: Best match / Most loved / New chips
  inList?: boolean;
}) {
  if (inList) {
    return (
      <div className="flex items-center justify-between gap-1.5">
        <DealViewTabs active={active} when={when} basePath={basePath} fitNarrow minHearts={minHearts} filterQuery={filterQuery} searchQuery={searchQuery} />
        <SwipeFilters facets={facets} inList />
      </div>
    );
  }
  return (
    <>
      <DealViewTabs active={active} when={when} basePath={basePath} fitShort minHearts={minHearts} filterQuery={filterQuery} searchQuery={searchQuery} />
      <SwipeFilters facets={facets} />
    </>
  );
}
