import Link from "next/link";
import CookieSettingsLink from "./CookieSettingsLink";
import Icon from "./Icon";
import { getSiteLinks } from "@/lib/site-pages";
import { getSiteSettings, needsCookieConsent } from "@/lib/site-settings";
import SocialLinks from "./SocialLinks";

const row =
  "flex min-h-12 w-full items-center gap-3 px-4 text-left text-sm font-medium text-zinc-700 hover:bg-zinc-50 dark:text-zinc-300 dark:hover:bg-zinc-800";
const chevron = <Icon name="chevron-right" className="ml-auto size-4 text-zinc-300 dark:text-zinc-600" />;

// The footer's links as a proper list: the About page is what "About DealSnap" in
// the phone menu opens, so they're reachable from anywhere, including the card
// view, which hides the footer. Computers always have the footer, so it's left
// out there.
export default function MoreFromDealSnap() {
  return (
    <nav aria-label="More from DealSnap" className="flex flex-col gap-2 lg:hidden">
      <h2 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">More from DealSnap</h2>
      <ul className="divide-y divide-zinc-100 overflow-hidden rounded-xl border border-zinc-200 bg-white dark:divide-zinc-800 dark:border-zinc-800 dark:bg-zinc-900">
        {getSiteLinks().filter((l) => l.href !== "/about").map((l) => (
          <li key={l.href}>
            <Link href={l.href} className={row}>
              <Icon name={l.icon} className="size-[18px] text-zinc-500 dark:text-zinc-400" />
              {l.full}
              {chevron}
            </Link>
          </li>
        ))}
        {needsCookieConsent(getSiteSettings()) && (
          <li>
            <CookieSettingsLink className={row}>
              <Icon name="cookie" className="size-[18px] text-zinc-500 dark:text-zinc-400" />
              Cookie settings
              {chevron}
            </CookieSettingsLink>
          </li>
        )}
      </ul>
      {/* The footer's social and app links too, for the same reason. */}
      <SocialLinks centred className="pt-1" />
    </nav>
  );
}
