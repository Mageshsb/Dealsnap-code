"use client";

import { createContext, useContext, useState } from "react";
import type { VoteDirection } from "@/lib/db";
import { BASE_HEART_WEIGHT } from "@/lib/votes";

// The signed-in user's own state, loaded once by the root layout:
// - votes (slug -> "love" | "unlove"): every VoteButton reads its starting state
//   from here, so a deal you loved on an earlier visit shows as loved, and stays
//   in step with any other button for the same deal after you vote.
// - voteWeight: what a tap of theirs is worth right now (4–7, lib/votes.ts),
//   and voteWeights: what each vote already cast was worth, so taking one
//   back moves the count by exactly what it added.
// - saved deals, so every bookmark button for a deal agrees.
// - who they've blocked, so those members' deals drop out of every list.
const UserVotesContext = createContext<{
  loggedIn: boolean;
  votes: Record<string, VoteDirection>;
  setVote: (dealSlug: string, direction: VoteDirection | null, weight?: number) => void;
  voteWeight: number;
  voteWeights: Record<string, number>;
  setVoteWeight: (dealSlug: string, weight: number) => void;
  saved: Record<string, boolean>;
  setSaved: (dealSlug: string, saved: boolean) => void;
  blockedUserIds: string[];
}>({
  loggedIn: false,
  votes: {},
  setVote: () => {},
  voteWeight: BASE_HEART_WEIGHT,
  voteWeights: {},
  setVoteWeight: () => {},
  saved: {},
  setSaved: () => {},
  blockedUserIds: [],
});

export function UserVotesProvider({
  loggedIn,
  initialVotes,
  voteWeight = BASE_HEART_WEIGHT,
  initialVoteWeights = {},
  initialSaved = [],
  blockedUserIds = [],
  children,
}: {
  loggedIn: boolean;
  initialVotes: Record<string, VoteDirection>;
  voteWeight?: number;
  initialVoteWeights?: Record<string, number>;
  initialSaved?: string[];
  blockedUserIds?: string[];
  children: React.ReactNode;
}) {
  const [votes, setVotes] = useState(initialVotes);
  const [voteWeights, setVoteWeights] = useState(initialVoteWeights);
  const [saved, setSavedState] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(initialSaved.map((slug) => [slug, true]))
  );

  function setVote(dealSlug: string, direction: VoteDirection | null, weight?: number) {
    setVotes((prev) => {
      const next = { ...prev };
      if (direction) next[dealSlug] = direction;
      else delete next[dealSlug];
      return next;
    });
    setVoteWeights((prev) => {
      const next = { ...prev };
      if (direction && weight) next[dealSlug] = weight;
      else delete next[dealSlug];
      return next;
    });
  }

  // What a vote was really worth, once the server has saved it. Only touches
  // the weight, so a quick second tap that took the vote back isn't undone.
  function setVoteWeight(dealSlug: string, weight: number) {
    setVoteWeights((prev) => ({ ...prev, [dealSlug]: weight }));
  }

  function setSaved(dealSlug: string, on: boolean) {
    setSavedState((prev) => ({ ...prev, [dealSlug]: on }));
  }

  return (
    <UserVotesContext.Provider value={{ loggedIn, votes, setVote, voteWeight, voteWeights, setVoteWeight, saved, setSaved, blockedUserIds }}>
      {children}
    </UserVotesContext.Provider>
  );
}

export function useUserVotes() {
  return useContext(UserVotesContext);
}
