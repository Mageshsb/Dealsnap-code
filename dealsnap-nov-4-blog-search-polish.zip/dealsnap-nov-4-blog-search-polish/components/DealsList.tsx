"use client";

import { Fragment, useEffect, useLayoutEffect, useRef, useState } from "react";
import { Deal } from "@/lib/types";
import { PAGE_SIZE } from "@/lib/pagination";
import { cameBack } from "@/lib/navigation-type";
import { isExpired } from "@/lib/format";
import type { LovedDivider } from "@/lib/deal-views";
import { useExpiredFilter } from "./ExpiredFilterProvider";
import ExpiredMatches from "./ExpiredMatches";
import DealCard from "./DealCard";
import PromoCard from "./PromoCard";
import { promoSlot, type ListPromos } from "@/lib/promos";
import { adPositions } from "@/lib/ad-positions";
import AdUnit, { useAds } from "./AdUnit";
import { ClockIcon } from "./icons";
import { freshAt } from "@/lib/upcoming";

type CachedState = { deals: Deal[]; hasMore: boolean; anchorId: string; anchorOffset: number };

// Everything that makes one list different from another, so going back to a
// page restores that page's deals and never another list's (a brand page and
// the homepage would otherwise share a key).
function cacheKey(query?: string, category?: string, tag?: string, view?: string, store?: string, minHearts?: number, filterQuery?: string, when?: string, brand?: string) {
  return `deals-cache:${category ?? ""}:${tag ?? ""}:${query ?? ""}:${view ?? ""}:${store ?? ""}:${minHearts ?? 0}:${filterQuery ?? ""}:${when ?? ""}:${brand ?? ""}`;
}

export default function DealsList({
  initialDeals,
  initialHasMore,
  query,
  expiredCount,
  category,
  tag,
  store,
  brand,
  view,
  minHearts,
  filterQuery,
  when,
  divider,
  promos,
}: {
  initialDeals: Deal[];
  initialHasMore: boolean;
  query?: string;
  expiredCount?: number; // search only: expired matches, which come after every live one
  category?: string;
  tag?: string;
  store?: string;
  brand?: string; // brand page slug
  view?: string;
  minHearts?: number;
  filterQuery?: string; // ticked stores/categories, e.g. "stores=currys,argos"
  when?: string; // Most loved's time window ("today"); unset = this week
  divider?: LovedDivider; // Most loved: mark where deals from before the window start
  promos?: ListPromos; // Admin → Promos: a promo card and a sign-up tile, each after the Nth deal (not deals themselves)
}) {
  const { showExpired, hideLocal } = useExpiredFilter();
  const pageAds = useAds();
  const listAds = pageAds?.slots.list;
  const sponsored = pageAds?.slots.sponsored;
  const key = cacheKey(query, category, tag, view, store, minHearts, filterQuery, when, brand);
  const [deals, setDeals] = useState(initialDeals);
  const [hasMore, setHasMore] = useState(initialHasMore);
  const [loading, setLoading] = useState(false);
  // The last "load more" failed (a hiccup on the server or the connection): stop
  // asking by itself, and offer a button, so it never hammers a struggling server.
  const [failed, setFailed] = useState(false);
  const sentinelRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const restoredDealsRef = useRef(false);
  const restoredScrollRef = useRef(false);
  // The card to put back on screen, and how many deals the list will hold
  // once the remembered ones are back in.
  const cachedAnchorRef = useRef<{ id: string; offset: number; count: number } | null>(null);
  // On a search with expired matches hidden, stop loading once the live deals
  // run out (they all come first) and say what's left instead.
  const pastLive = !showExpired && !!expiredCount && deals.length > 0 && isExpired(deals[deals.length - 1].expiresAt);
  const moreToLoad = hasMore && !pastLive;

  // Restore the previously-loaded deals from a local cache, synchronously
  // before the browser paints — no fetch involved, so there's no async gap
  // for the browser's own scroll restoration to race against.
  useLayoutEffect(() => {
    if (restoredDealsRef.current) return;
    restoredDealsRef.current = true;
    const raw = cameBack() ? sessionStorage.getItem(key) : null;
    if (raw) {
      const cached = JSON.parse(raw) as CachedState;
      const longer = cached.deals.length > initialDeals.length;
      cachedAnchorRef.current = {
        id: cached.anchorId,
        offset: cached.anchorOffset,
        count: longer ? cached.deals.length : initialDeals.length,
      };
      if (longer) {
        // On purpose: putting the remembered deals back here, before the first
        // paint, is what lands Back on the same deal with no flicker.
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setDeals(cached.deals);
        setHasMore(cached.hasMore);
      }
      return;
    }
    startAtTop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // A list that isn't being put back starts at the top, rather than wherever
  // the page happened to be scrolled (e.g. a filter or sort picked from
  // halfway down, which would otherwise drop you past the end of the new list).
  function startAtTop() {
    if ((listRef.current?.getBoundingClientRect().top ?? 0) < 0) window.scrollTo(0, 0);
  }

  // Once the restored deals are actually in the DOM, put the remembered
  // anchor card back exactly where it was on screen.
  useLayoutEffect(() => {
    if (restoredScrollRef.current) return;
    const anchor = cachedAnchorRef.current;
    if (!anchor || deals.length !== anchor.count) return;
    restoredScrollRef.current = true;
    const target = listRef.current?.querySelector<HTMLElement>(`[data-deal-id="${anchor.id}"]`);
    if (target) window.scrollBy(0, target.getBoundingClientRect().top - anchor.offset);
    else startAtTop();
  }, [deals]);

  // The browser's own Back scroll puts the page back the same distance from
  // the top, which lands on the wrong deal whenever something above the list
  // changed height (the Filters box was open, a banner came or went). So on
  // pages with a list, the step above is the only one, and it goes by the deal
  // itself. Switched back on as the list goes, so other pages keep the
  // browser's (it's remembered per page in the history).
  useEffect(() => {
    history.scrollRestoration = "manual";
    return () => {
      history.scrollRestoration = "auto";
    };
  }, []);

  // Track whichever card sits at the top of the viewport, alongside the
  // full loaded list, so returning to this page can restore both instantly.
  useEffect(() => {
    let ticking = false;
    function save() {
      ticking = false;
      const cards = listRef.current?.querySelectorAll<HTMLElement>("[data-deal-id]");
      if (!cards) return;
      let anchor: HTMLElement | undefined;
      for (const el of cards) {
        if (el.getBoundingClientRect().bottom > 0) {
          anchor = el;
          break;
        }
      }
      if (!anchor) return;
      const state: CachedState = {
        deals,
        hasMore,
        anchorId: anchor.dataset.dealId!,
        anchorOffset: anchor.getBoundingClientRect().top,
      };
      sessionStorage.setItem(key, JSON.stringify(state));
    }
    function onScroll() {
      if (ticking) return;
      ticking = true;
      setTimeout(save, 100);
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [key, deals, hasMore]);

  async function loadMore() {
    if (loading || !hasMore) return;
    setLoading(true);
    try {
      const params = new URLSearchParams({ offset: String(deals.length), limit: String(PAGE_SIZE) });
      if (query) params.set("q", query);
      if (category) params.set("category", category);
      if (tag) params.set("tag", tag);
      if (store) params.set("store", store);
      if (brand) params.set("brand", brand);
      if (view) params.set("view", view);
      if (minHearts) params.set("hearts", String(minHearts));
      if (when) params.set("when", when);
      for (const [k, v] of new URLSearchParams(filterQuery ?? "")) params.set(k, v);

      const res = await fetch(`/api/deals?${params.toString()}`);
      if (!res.ok) throw new Error("Could not load more");
      const data = await res.json();
      setDeals((prev) => [...prev, ...data.results]);
      setHasMore(data.hasMore);
      setFailed(false);
    } catch {
      setFailed(true);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel || !moreToLoad || failed) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) loadMore();
      },
      { rootMargin: "600px" }
    );
    observer.observe(sentinel);
    return () => observer.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [moreToLoad, deals.length, failed]);

  const visibleDeals = deals.filter(
    (deal) => (showExpired || !isExpired(deal.expiresAt)) && (!hideLocal || deal.whereToBuy !== "instore")
  );
  const hidingExpired = !showExpired && !!expiredCount;

  // The first deal from before Most loved's window (the pinned Hero deal aside,
  // which can be any age). If none from the window came before it, the list says
  // so instead of just starting on old deals.
  const sinceMs = divider ? new Date(divider.since).getTime() : 0;
  const firstOlder = divider ? visibleDeals.findIndex((d) => !d.hero && freshAt(d) < sinceMs) : -1;
  const anyFresh = visibleDeals.slice(0, Math.max(0, firstOlder)).some((d) => !d.hero);

  // Where the promo card and the sign-up tile go: after the Nth deal, or after
  // the last one on a list that ends before N. A tile that lands on the same
  // deal as the card follows it.
  const cardAt = promos?.card ? promoSlot(promos.card.afterDeals, visibleDeals.length, moreToLoad) : -1;
  const signupAt = promos?.signup ? promoSlot(promos.signup.afterDeals, visibleDeals.length, moreToLoad) : -1;
  // Ads (Admin → Ads): sponsored deals, then the other ads, each after deal N
  // then every M, never right beside a promo or each other.
  const promoAt = [cardAt, signupAt];
  const sponsoredAt = sponsored ? adPositions(visibleDeals.length, sponsored.first, sponsored.every, promoAt, moreToLoad, sponsored.max) : [];
  const adAt = listAds ? adPositions(visibleDeals.length, listAds.first, listAds.every, [...promoAt, ...sponsoredAt], moreToLoad, listAds.max) : [];

  return (
    <div ref={listRef} className="flex flex-col gap-3">
      {visibleDeals.map((deal, i) => (
        <Fragment key={deal.id}>
          {i === firstOlder && divider && (
            // Noticeable enough to explain the jump in dates when scrolling
            // fast. The site's own black and orange: bold black words (white in
            // dark mode) and an orange clock between thick solid orange lines.
            // No pill or outline round the words, so it can't pass for a button.
            <div role="separator" className="flex items-center gap-2.5 py-3">
              <span aria-hidden className="h-1 min-w-4 flex-1 rounded-full bg-orange-500" />
              <span className="flex items-center gap-1.5 text-center text-xs font-bold text-zinc-900 dark:text-zinc-100">
                <ClockIcon className="h-3.5 w-3.5 shrink-0 text-orange-700 dark:text-orange-400" />
                {anyFresh ? `Posted before ${divider.phrase}` : `Nothing new in ${divider.phrase} · earlier deals`}
              </span>
              <span aria-hidden className="h-1 min-w-4 flex-1 rounded-full bg-orange-500" />
            </div>
          )}
          <div data-deal-id={deal.id} data-expired={isExpired(deal.expiresAt) || undefined}>
            {/* (The first two are on screen straight away: their photos load first.) */}
            <DealCard deal={deal} eager={i < 2} />
          </div>
          {/* Not a deal: no data-deal-id, so Back's "same deal" restore and the saved list ignore it. */}
          {i === cardAt && promos?.card && <PromoCard promo={promos.card} />}
          {i === signupAt && promos?.signup && <PromoCard promo={promos.signup} />}
          {sponsoredAt.includes(i) && <AdUnit slot="sponsored" n={sponsoredAt.indexOf(i)} />}
          {adAt.includes(i) && <AdUnit slot="list" n={adAt.indexOf(i)} />}
        </Fragment>
      ))}

      {hidingExpired && !moreToLoad && (
        <ExpiredMatches count={expiredCount} query={query} nothingLive={isExpired(deals[0]?.expiresAt)} />
      )}

      {moreToLoad && (
        <div ref={sentinelRef} className="flex justify-center py-6">
          {loading && <span className="text-sm text-zinc-500">Loading more deals…</span>}
          {failed && !loading && (
            <button type="button" onClick={loadMore} className="min-h-10 rounded-full border border-zinc-300 px-4 text-sm font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800">
              Couldn&apos;t load more deals. Try again
            </button>
          )}
        </div>
      )}

      {!hasMore && !hidingExpired && deals.length > PAGE_SIZE && (
        <p className="py-6 text-center text-sm text-zinc-500 dark:text-zinc-400">You&apos;ve reached the end</p>
      )}
    </div>
  );
}
