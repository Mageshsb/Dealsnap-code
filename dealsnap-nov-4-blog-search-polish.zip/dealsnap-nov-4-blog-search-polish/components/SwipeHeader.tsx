import { ReactNode } from "react";

// The title, Most loved/New chips (with Most loved's time window) and Filters pill above the Scroll view's card. Sized
// like the List view's heading so switching modes doesn't shrink the text, and
// lined up with the card's own width. On short screens (small phones, phones
// in landscape) it steps down a size so the card still fits above the fold —
// SwipeDeck measures whatever space is left, so the card absorbs the rest.
export default function SwipeHeader({ title, controls }: { title: ReactNode; controls: ReactNode /* <SortAndFilters> */ }) {
  return (
    <div className="flex w-full max-w-[380px] flex-col items-center gap-2 sm:max-w-[440px] lg:max-w-[500px] [@media(max-height:640px)]:gap-1">
      {/* Fixed height, so a title with a button (Get alerts, Join free) is no
          taller than one without and the card doesn't jump between pages. */}
      <h1 className="flex h-[34px] max-w-full min-w-0 items-center justify-center gap-2 text-center text-xl font-bold sm:text-2xl [@media(max-height:640px)]:text-base">
        {title}
      </h1>
      <div className="flex w-full min-w-0 items-center justify-center gap-1.5">{controls}</div>
    </div>
  );
}
