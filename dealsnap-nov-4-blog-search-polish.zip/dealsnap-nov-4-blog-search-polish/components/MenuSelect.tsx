"use client";

import { useEffect, useId, useLayoutEffect, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import { createPortal } from "react-dom";
import Icon, { type IconName } from "./Icon";

export type MenuOption = { value: string; label: string; icon?: IconName };

const GAP = 6; // between the button and the menu
const EDGE = 8; // the menu never comes closer than this to the screen's edge
const MAX_HEIGHT = 480; // 30rem

type Place = { top?: number; bottom?: number; left: number; minWidth: number; maxHeight: number };

// Every dropdown on the site: it opens our own menu (rounded, with a tick by
// the current choice) rather than the browser's plain grey list, so it looks
// the same on every phone and computer. The button's look is up to the caller
// (SelectField gives it the form-field look); `leading` goes before its label
// (an icon), `chevronClassName` sizes and colours the ⌄, and `align` picks
// which edge the menu lines up with.
//
// It works in forms like a <select>: with a `name` the choice is sent with the
// form, `required` stops the form going until something is picked, and
// `defaultValue` (no `value`/`onChange`) lets a server page use it as is. The
// menu is drawn on top of the page, below the button (or above it when there's
// more room there), so it can't be cut off by a box or sheet it sits in. Arrow
// keys, Home/End, Enter and typing a letter work as they do in a <select>.
export default function MenuSelect({
  value,
  defaultValue,
  options,
  onChange,
  label,
  buttonClassName,
  leading,
  align = "left",
  className = "",
  chevronClassName = "size-4 text-zinc-500",
  name,
  required,
  disabled,
  placeholder,
  id,
  showLabel = true,
}: {
  value?: string;
  defaultValue?: string;
  options: MenuOption[];
  onChange?: (value: string) => void;
  label: string;
  buttonClassName: string;
  leading?: ReactNode;
  align?: "left" | "right";
  className?: string;
  chevronClassName?: string;
  name?: string;
  required?: boolean;
  disabled?: boolean;
  // Shown greyed out while nothing is chosen (a value no option has, like "").
  placeholder?: string;
  id?: string;
  // The small grey heading at the top of the menu.
  showLabel?: boolean;
}) {
  const [own, setOwn] = useState(defaultValue ?? "");
  const chosen = value ?? own;
  const [open, setOpen] = useState(false);
  const [place, setPlace] = useState<Place | null>(null);
  // Where the menu is drawn: the page, or the pop-up <dialog> the button is in
  // (a menu outside one would sit behind it).
  const [host, setHost] = useState<Element | null>(null);
  // Set when the form was sent without a required choice; the button turns
  // red until something is picked.
  const [invalid, setInvalid] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const typed = useRef({ text: "", at: 0 });
  const listId = useId();
  const current = options.find((o) => o.value === chosen) ?? (placeholder === undefined ? options[0] : undefined);

  function openMenu() {
    setHost(buttonRef.current?.closest("dialog") ?? document.body);
    setOpen(true);
  }

  function close(focusButton = false) {
    setOpen(false);
    setPlace(null);
    if (focusButton) buttonRef.current?.focus();
  }

  function pick(next: string) {
    close(true);
    setInvalid(false);
    if (value === undefined) setOwn(next);
    if (next !== chosen) onChange?.(next);
  }

  // Where the menu goes: under the button, or over it when there's more room
  // above (a field near the bottom of the screen); kept on screen sideways.
  const measure = () => {
    const button = buttonRef.current;
    if (!button) return;
    const r = button.getBoundingClientRect();
    const below = window.innerHeight - r.bottom - GAP - EDGE;
    const above = r.top - GAP - EDGE;
    const up = below < 240 && above > below;
    const menuWidth = menuRef.current?.offsetWidth ?? r.width;
    const wanted = align === "right" ? r.right - menuWidth : r.left;
    setPlace({
      ...(up ? { bottom: window.innerHeight - r.top + GAP } : { top: r.bottom + GAP }),
      left: Math.max(EDGE, Math.min(wanted, window.innerWidth - menuWidth - EDGE)),
      minWidth: r.width,
      maxHeight: Math.min(MAX_HEIGHT, up ? above : below),
    });
  };
  const measureRef = useRef(measure);
  useLayoutEffect(() => {
    measureRef.current = measure;
  });

  // Once the menu is drawn (so its width is known), place it and move focus
  // to the current choice, as a <select> does.
  useLayoutEffect(() => {
    if (!open) return;
    measureRef.current();
    const menu = menuRef.current;
    const selected = menu?.querySelector<HTMLElement>('[aria-selected="true"]') ?? menu?.querySelector<HTMLElement>('[role="option"]');
    selected?.focus({ preventScroll: true });
    selected?.scrollIntoView({ block: "nearest" });
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const inside = (t: EventTarget | null) =>
      t instanceof Node && (menuRef.current?.contains(t) || buttonRef.current?.contains(t));
    const onDown = (e: PointerEvent) => {
      if (!inside(e.target)) close();
    };
    // The menu follows its button when the page (or a box around it) scrolls.
    const follow = (e: Event) => {
      if (!(e.target instanceof Node && menuRef.current?.contains(e.target))) measureRef.current();
    };
    document.addEventListener("pointerdown", onDown);
    window.addEventListener("scroll", follow, true);
    window.addEventListener("resize", follow);
    return () => {
      document.removeEventListener("pointerdown", onDown);
      window.removeEventListener("scroll", follow, true);
      window.removeEventListener("resize", follow);
    };
  }, [open]);

  function focusOption(index: number) {
    const items = menuRef.current?.querySelectorAll<HTMLElement>('[role="option"]');
    if (!items?.length) return;
    items[(index + items.length) % items.length].focus();
  }

  function onMenuKey(e: KeyboardEvent<HTMLDivElement>) {
    const items = Array.from(menuRef.current?.querySelectorAll<HTMLElement>('[role="option"]') ?? []);
    const at = items.indexOf(document.activeElement as HTMLElement);
    if (e.key === "ArrowDown") focusOption(at + 1);
    else if (e.key === "ArrowUp") focusOption(at - 1);
    else if (e.key === "Home") focusOption(0);
    else if (e.key === "End") focusOption(items.length - 1);
    else if (e.key === "Escape") close(true);
    else if (e.key === "Tab") return close();
    else if (e.key.length === 1 && !e.metaKey && !e.ctrlKey && !e.altKey) {
      // Typing jumps to the next choice starting with those letters.
      const now = Date.now();
      typed.current = { text: (now - typed.current.at < 700 ? typed.current.text : "") + e.key.toLowerCase(), at: now };
      const text = typed.current.text;
      // A first letter moves on from the focused choice; more letters refine it.
      const start = Math.max(0, text.length > 1 ? at : at + 1);
      const order = [...options.slice(start), ...options.slice(0, start)];
      const hit = order.find((o) => o.label.toLowerCase().startsWith(text));
      if (hit) focusOption(options.indexOf(hit));
    } else return;
    e.preventDefault();
  }

  function onButtonKey(e: KeyboardEvent<HTMLButtonElement>) {
    if (!open && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
      e.preventDefault();
      openMenu();
    }
  }

  return (
    <div className={`relative ${className}`}>
      <button
        ref={buttonRef}
        id={id}
        type="button"
        disabled={disabled}
        onClick={() => (open ? close() : openMenu())}
        onKeyDown={onButtonKey}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={open ? listId : undefined}
        aria-label={`${label}: ${current?.label ?? placeholder ?? ""}`}
        data-invalid={invalid || undefined}
        className={buttonClassName}
      >
        {leading}
        <span className={`min-w-0 flex-1 truncate text-left ${current ? "" : "text-zinc-500 dark:text-zinc-400"}`}>{current?.label ?? placeholder}</span>
        <Icon name="chevron-down" className={`shrink-0 transition-transform ${chevronClassName} ${open ? "rotate-180" : ""}`} />
      </button>

      {/* What the form sends. When it's required it's a real (invisible) field,
          so the browser's "please select" message appears under the button. */}
      {name &&
        (required ? (
          <input
            tabIndex={-1}
            aria-hidden
            name={name}
            value={current?.value ?? ""}
            required
            disabled={disabled}
            onChange={() => {}}
            onInvalid={() => setInvalid(true)}
            // The browser jumps to the first missing field: pass that on to the button.
            onFocus={() => buttonRef.current?.focus()}
            className="pointer-events-none absolute bottom-0 left-4 h-px w-px opacity-0"
          />
        ) : (
          <input type="hidden" name={name} value={current?.value ?? ""} disabled={disabled} />
        ))}

      {open &&
        host &&
        createPortal(
          <div
            ref={menuRef}
            id={listId}
            role="listbox"
            aria-label={label}
            onKeyDown={onMenuKey}
            style={
              place
                ? { top: place.top, bottom: place.bottom, left: place.left, minWidth: place.minWidth, maxHeight: place.maxHeight }
                : { top: 0, left: 0, visibility: "hidden" }
            }
            className="fixed z-[60] flex w-max max-w-[calc(100vw-1rem)] flex-col overflow-y-auto overscroll-contain rounded-xl border border-zinc-200 bg-white p-1 text-zinc-900 shadow-lg dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100"
          >
            {showLabel && <p className="px-3 pb-1 pt-1.5 text-xs font-medium text-zinc-500 dark:text-zinc-400">{label}</p>}
            {options.map((o) => {
              const selected = o.value === current?.value;
              return (
                <button
                  key={o.value}
                  type="button"
                  role="option"
                  aria-selected={selected}
                  onClick={() => pick(o.value)}
                  className={`flex min-h-10 shrink-0 items-center gap-2.5 rounded-lg px-3 text-left text-sm outline-none ${
                    selected
                      ? "bg-orange-50 font-medium text-orange-700 dark:bg-orange-950/40 dark:text-orange-400"
                      : "text-zinc-700 hover:bg-zinc-100 focus:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800 dark:focus:bg-zinc-800"
                  }`}
                >
                  {o.icon && <Icon name={o.icon} className={`size-[18px] ${selected ? "" : "text-zinc-500 dark:text-zinc-400"}`} />}
                  <span className="min-w-0 flex-1 whitespace-nowrap">{o.label}</span>
                  {selected ? <Icon name="check" className="size-4 shrink-0" /> : <span className="size-4 shrink-0" />}
                </button>
              );
            })}
          </div>,
          host
        )}
    </div>
  );
}
