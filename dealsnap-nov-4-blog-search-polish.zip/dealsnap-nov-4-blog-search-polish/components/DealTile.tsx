import Link from "next/link";
import { Deal } from "@/lib/types";
import { dealPriceTag } from "@/lib/deal-kinds";
import DealThumbnail from "./DealThumbnail";
import { PriceMain } from "./DealPrice";
import { HeartIcon } from "./Icon";

// A compact deal tile for sideways-scrolling rows (related deals, event pages).
export default function DealTile({ deal }: { deal: Deal }) {
  const tag = dealPriceTag(deal);
  return (
    <Link
      href={`/deals/${deal.slug}`}
      role="listitem"
      className="flex w-[42vw] min-w-[9.5rem] max-w-[13rem] shrink-0 snap-start flex-col overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-sm transition-shadow hover:shadow-md dark:border-zinc-800 dark:bg-zinc-900 sm:w-[12.5rem]"
    >
      <div className="aspect-[4/3] w-full">
        <DealThumbnail deal={deal} iconSize="size-12" sizes="208px" backdrop="compact" />
      </div>
      <div className="flex flex-1 flex-col gap-1 p-2.5 sm:p-3">
        <h3 className="line-clamp-2 min-h-[2.5rem] text-sm font-semibold leading-snug">{deal.title}</h3>
        <div className="mt-auto flex flex-wrap items-baseline gap-x-2 pt-1">
          <span className={`font-bold text-orange-700 dark:text-orange-400 ${tag.isOffer ? "text-sm" : ""}`}>
            <PriceMain tag={tag} />
          </span>
          {tag.off && <span className="text-sm font-bold text-green-700 dark:text-green-400">{tag.off}% off</span>}
        </div>
        <div className="flex items-center justify-between gap-2 text-xs text-zinc-500 dark:text-zinc-400">
          <span className="truncate font-semibold text-zinc-600 dark:text-zinc-300">{deal.store}</span>
          <span className="flex shrink-0 items-center gap-1">
            <HeartIcon className="size-3" />
            {deal.hearts}
          </span>
        </div>
      </div>
    </Link>
  );
}
