"use client";

import { useLayoutEffect, useRef, useState } from "react";

// A list card's age on phones: "5d ago" whenever it fits beside the hearts and
// save button, "5d" only on the cards where it really doesn't (a narrow phone
// plus a 4-digit heart count or "11mo ago"). Measured per card rather than by
// screen width, since phones report all sorts of widths (Display Zoom, Android
// display size). Starts as "5d ago", which fits on nearly every phone.
export default function AgeLabel({ full, tiny }: { full: string; tiny: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const probe = useRef<HTMLSpanElement>(null);
  const [fits, setFits] = useState(true);

  useLayoutEffect(() => {
    const pill = ref.current?.closest<HTMLElement>("[data-age-pill]");
    const row = pill?.parentElement;
    if (!pill || !row || !probe.current) return;
    const check = () => {
      if (!pill.offsetParent) return; // hidden (tiny phones, or desktop's long label)
      const style = getComputedStyle(row);
      const others = [...row.children].filter((c) => c !== pill).reduce((w, c) => w + (c as HTMLElement).offsetWidth, 0);
      const pad = parseFloat(getComputedStyle(pill).paddingLeft) + parseFloat(getComputedStyle(pill).paddingRight);
      const room = row.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight) - others - parseFloat(style.columnGap || "0");
      setFits(probe.current!.offsetWidth + pad + 2 <= room);
    };
    check();
    const ro = new ResizeObserver(check);
    ro.observe(row);
    for (const c of row.children) if (c !== pill) ro.observe(c); // e.g. hearts 999 → 1,000
    return () => ro.disconnect();
  }, [full]);

  return (
    <span ref={ref}>
      {fits ? full : tiny}
      {/* The full label, unseen, to measure against. */}
      <span ref={probe} aria-hidden className="invisible absolute left-0 top-0 whitespace-nowrap">
        {full}
      </span>
    </span>
  );
}
