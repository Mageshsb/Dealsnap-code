import { DealSnapIcon } from "./icons";
import { getSiteBrand } from "@/lib/site-brand";
import { iconSrc } from "@/lib/site-brand-shared";

// The site's square icon on a page (About, the media kit): the one uploaded
// in Admin → Settings → General, or the built-in one. Just a picture: the
// words beside it say whose it is.
export default function SiteMark({ className = "size-6" }: { className?: string }) {
  const icon = getSiteBrand().icon;
  if (!icon) return <DealSnapIcon className={className} />;
  // eslint-disable-next-line @next/next/no-img-element -- already the right size, and cached for a year
  return <img src={iconSrc(icon, "192")} alt="" width={192} height={192} className={`object-contain ${className}`} />;
}
