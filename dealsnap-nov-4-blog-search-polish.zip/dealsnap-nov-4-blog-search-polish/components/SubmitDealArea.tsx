"use client";

import { useMemo, useState, useSyncExternalStore, type ComponentProps } from "react";
import SubmitDealForm from "./SubmitDealForm";
import { clearDealDraft, readDealDraft } from "@/lib/deal-draft";

const noSubscribe = () => () => {};

// The post form, plus putting back a deal someone started: one they left
// halfway through ("started"), one they started before joining (they arrive
// here as /submit?draft=1 straight after signing up), or one that came back
// with a problem to fix (/submit?error=…).
export default function SubmitDealArea({
  restoreDraft,
  ...props
}: Omit<ComponentProps<typeof SubmitDealForm>, "initial"> & { restoreDraft: false | "started" | "joined" | "error" }) {
  // The draft lives on the device, so it can only be read in the browser.
  const inBrowser = useSyncExternalStore(noSubscribe, () => true, () => false);
  const [startAgain, setStartAgain] = useState(false);
  const draft = useMemo(() => {
    if (!inBrowser || !restoreDraft || startAgain) return null;
    const saved = readDealDraft();
    // One that was posted only comes back if posting needs something fixed.
    return saved && (restoreDraft !== "started" || !saved.sent) ? saved : null;
  }, [inBrowser, restoreDraft, startAgain]);

  return (
    <>
      {draft && restoreDraft === "joined" && (
        <p className="rounded-lg bg-green-50 px-4 py-2 text-sm text-green-700 dark:bg-green-950/40 dark:text-green-400">
          You&apos;re in! Here&apos;s the deal you started. Give it a quick check, then press Post deal.
        </p>
      )}
      {draft && restoreDraft === "started" && (
        <div className="flex items-center justify-between gap-3 rounded-lg bg-zinc-100 px-4 py-2 text-sm text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300">
          <span>Here&apos;s the deal you started earlier.</span>
          <button
            type="button"
            onClick={() => {
              clearDealDraft();
              setStartAgain(true);
            }}
            className="shrink-0 font-medium text-orange-700 hover:underline dark:text-orange-400"
          >
            Start again
          </button>
        </div>
      )}
      <SubmitDealForm key={draft ? "draft" : "blank"} initial={draft} {...props} />
    </>
  );
}
