import Form from "next/form";
import { SEARCH_MAX } from "@/lib/community-rules";
import { ClearSearch, searchBox } from "../SearchBox";

// Search the blog: type, press Enter. Works before any script loads, and once
// it has, the results swap in without the page reloading. Always searches
// every post, from wherever it's used. Same box as every
// other search on the site.
export default function BlogSearch({ q }: { q: string }) {
  return (
    <Form action="/blog" role="search" className="relative w-full sm:w-64">
      <label htmlFor="blog-search" className="sr-only">
        Search the blog
      </label>
      <input
        id="blog-search"
        type="search"
        name="q"
        defaultValue={q}
        maxLength={SEARCH_MAX}
        enterKeyHint="search"
        autoComplete="off"
        placeholder="Search the blog"
        className={searchBox}
      />
      {q && <ClearSearch href="/blog" />}
    </Form>
  );
}
