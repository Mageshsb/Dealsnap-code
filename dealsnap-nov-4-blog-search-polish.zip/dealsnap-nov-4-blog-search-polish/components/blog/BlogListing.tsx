import Link from "next/link";
import { notFound } from "next/navigation";
import {
  getBlogKindCounts,
  getBlogLead,
  getPopularBlogIds,
  getBlogCardsByIds,
  listBlogCards,
} from "@/lib/db";
import { blogCard, ensureBlogReady } from "@/lib/mock-blog";
import { BLOG_KINDS, blogKind, blogKindHref, dayDaysAgo } from "@/lib/blog";
import { searchWords } from "@/lib/community-rules";
import BlogCard from "@/components/BlogCard";
import EmptyState from "@/components/EmptyState";
import Icon from "@/components/Icon";
import Pager from "@/components/community/Pager";
import BlogSearch from "./BlogSearch";

export const BLOG_PAGE = 12;

// The site's "which ones to show" tabs (orange when picked, as on profiles,
// Saved and the Following feed); black pills are kept for sort order. They
// wrap rather than scroll sideways, so every topic is in view at once.
const chip = (active: boolean) =>
  `flex min-h-9 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl px-3 text-sm font-medium transition-colors ${
    active ? "bg-orange-500 text-white" : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
  }`;

export function pageNumber(raw: string | undefined): number {
  return Math.min(500, Math.max(1, parseInt(raw ?? "1", 10) || 1));
}

// The blog's front page and each topic's page: the pinned (or newest) post
// big at the top, the rest in a grid, a search box, and pages (real links, so
// search engines can follow them to every post). Reads only what the cards
// show, a page at a time, so it stays quick however many posts there are.
export default function BlogListing({ kind, q, page, basePath }: { kind?: string; q: string; page: number; basePath: string }) {
  ensureBlogReady();
  const words = searchWords(q, 5);
  const searching = q.length > 0;
  const counts = getBlogKindCounts();
  const kinds = BLOG_KINDS.filter((k) => (counts.get(k.key) ?? 0) > 0);
  const totalPosts = [...counts.values()].reduce((a, b) => a + b, 0);

  // A search with no usable word in it ("a", "?") finds nothing rather than everything.
  const noWords = searching && words.length === 0;
  // The lead sits above page 1 only, and is left out of the grid on every page
  // so the pages line up.
  const leadRow = searching ? undefined : getBlogLead(kind);
  const lead = page === 1 ? leadRow : undefined;
  const { rows, total } = noWords
    ? { rows: [], total: 0 }
    : listBlogCards({ kind, words: searching ? words : undefined, exceptId: leadRow?.id, limit: BLOG_PAGE, offset: (page - 1) * BLOG_PAGE });
  const totalPages = Math.max(1, Math.ceil(total / BLOG_PAGE));
  // A page number past the end isn't a page (so search engines drop it).
  if (page > totalPages) notFound();

  // "Popular this month": only once there are enough posts for it to say something.
  const popular =
    !searching && !kind && page === 1 && totalPosts > 8
      ? getBlogCardsByIds(getPopularBlogIds(dayDaysAgo(30), 3)).filter((p) => p.id !== lead?.id)
      : [];

  const topic = kind ? blogKind(kind) : undefined;

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-5 px-4 py-6">
      <div className="flex flex-wrap items-end justify-between gap-x-6 gap-y-3">
        <div className="min-w-0 max-w-2xl">
          <h1 className="text-xl font-bold sm:text-2xl">{topic ? topic.label : "Blog"}</h1>
          {/* A fixed two lines on a phone (one on a wide screen), so the search box,
              tabs and first post sit in the same place on every blog page. A
              search says how many it found here rather than adding a row. */}
          <p className="mt-1 min-h-[2lh] text-sm text-zinc-500 lg:min-h-[1lh]" role={searching ? "status" : undefined}>
            {searching ? (
              <>
                {total === 0 ? "No posts match" : `${total} ${total === 1 ? "post matches" : "posts match"}`} <span className="font-medium text-zinc-700 dark:text-zinc-300">&ldquo;{q}&rdquo;</span>
              </>
            ) : topic ? (
              topic.intro
            ) : (
              "Buying guides, money-saving tips and the best times to buy."
            )}
          </p>
        </div>
        <BlogSearch q={q} />
      </div>

      {kinds.length > 1 && (
        <nav aria-label="Blog topics" className="flex flex-wrap gap-2">
          <Link href="/blog" className={chip(!kind)} aria-current={!kind ? "page" : undefined}>
            All
          </Link>
          {kinds.map((k) => (
            <Link key={k.key} href={blogKindHref(k.key)} className={chip(kind === k.key)} aria-current={kind === k.key ? "page" : undefined}>
              <Icon name={k.icon} className="size-4" />
              {k.label}
            </Link>
          ))}
        </nav>
      )}


      {lead && <BlogCard post={blogCard(lead)} featured />}

      {popular.length >= 2 && (
        <section aria-labelledby="blog-popular" className="flex flex-col gap-3">
          <h2 id="blog-popular" className="flex items-center gap-2 text-lg font-bold">
            <Icon name="trending-up" className="size-5 text-orange-700 dark:text-orange-400" />
            Popular this month
          </h2>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3">
            {popular.map((p) => (
              <BlogCard key={p.id} post={blogCard(p)} />
            ))}
          </div>
        </section>
      )}

      {rows.length > 0 ? (
        <section aria-labelledby="blog-latest" className="flex flex-col gap-3">
          <h2 id="blog-latest" className="text-lg font-bold">
            {searching ? "Results" : lead ? "Latest" : "More"}
          </h2>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3">
            {rows.map((post, i) => (
              <BlogCard key={post.id} post={blogCard(post)} eager={!lead && page === 1 && i < 2} />
            ))}
          </div>
          <Pager basePath={basePath} page={page} totalPages={totalPages} keep={{ q: q || undefined }} />
        </section>
      ) : (
        !lead && (
          <EmptyState icon="newspaper">
            <p>{searching ? "Nothing matches that. Try fewer or simpler words." : "Nothing here yet."}</p>
            {(searching || kind) && (
              <Link href="/blog" className="font-semibold text-orange-700 dark:text-orange-400 hover:underline">
                See all posts
              </Link>
            )}
          </EmptyState>
        )
      )}

      {/* What to do next: the two things that bring readers back. */}
      <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Link
          href="/alerts"
          className="flex items-center gap-3 rounded-xl border border-orange-200 bg-orange-50 p-4 transition-colors hover:bg-orange-100 dark:border-orange-900/60 dark:bg-orange-950/30 dark:hover:bg-orange-950/50"
        >
          <span aria-hidden className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-orange-100 text-orange-700 dark:bg-orange-950/60 dark:text-orange-400">
            <Icon name="bell" className="size-5" />
          </span>
          <span className="flex min-w-0 flex-col">
            <span className="font-semibold">Never miss a deal</span>
            <span className="text-sm text-zinc-600 dark:text-zinc-400">Set an alert for anything you&apos;re after.</span>
          </span>
        </Link>
        <Link
          href="/community"
          className="flex items-center gap-3 rounded-xl border border-zinc-200 bg-white p-4 transition-colors hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:hover:bg-zinc-800"
        >
          <span aria-hidden className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">
            <Icon name="replies" className="size-5" />
          </span>
          <span className="flex min-w-0 flex-col">
            <span className="font-semibold">Got a question?</span>
            <span className="text-sm text-zinc-600 dark:text-zinc-400">Ask other deal hunters in the Community.</span>
          </span>
        </Link>
      </div>
    </main>
  );
}
