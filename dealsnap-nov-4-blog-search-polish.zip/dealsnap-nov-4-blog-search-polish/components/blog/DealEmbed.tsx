import Link from "next/link";
import type { Deal } from "@/lib/types";
import { dealPriceTag } from "@/lib/deal-kinds";
import { isExpired } from "@/lib/format";
import DealThumbnail from "../DealThumbnail";
import { PriceMain } from "../DealPrice";
import { HeartIcon } from "../Icon";

// A deal inside a post ("::deal <slug>"): picture, name, live price and store,
// all read from the deal itself, so a price in a post can never go stale. It
// opens the deal's page on the site (where Get deal lives), not the store.
export default function DealEmbed({ deal, slug }: { deal?: Deal; slug: string }) {
  // Not on the site any more (or not found): nothing is drawn on the live
  // page, and the editor's preview says so.
  if (!deal) return null;
  const tag = dealPriceTag(deal);
  const over = isExpired(deal.expiresAt) || !!deal.endedByMembers || !!deal.endedByStaff || !!deal.endedByPoster;
  return (
    <Link
      href={`/deals/${slug}`}
      className={`not-prose flex items-stretch gap-3 overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-sm transition-shadow hover:shadow-md dark:border-zinc-800 dark:bg-zinc-900 ${over ? "opacity-70" : ""}`}
    >
      <div className="aspect-[4/3] w-28 shrink-0 sm:w-36">
        <DealThumbnail deal={deal} iconSize="size-10" sizes="144px" backdrop="compact" />
      </div>
      <div className="flex min-w-0 flex-1 flex-col justify-center gap-1 py-2.5 pr-3">
        <span className="text-[11px] font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">{over ? "Deal ended" : "Live deal"}</span>
        <span className="line-clamp-2 text-[15px] font-semibold leading-snug text-zinc-900 dark:text-zinc-100">{deal.title}</span>
        <span className="flex flex-wrap items-baseline gap-x-2 text-sm">
          <span className={`font-bold text-orange-700 dark:text-orange-400 ${over ? "line-through" : ""}`}>
            <PriceMain tag={tag} />
          </span>
          {tag.off && !over && <span className="font-bold text-green-700 dark:text-green-400">{tag.off}% off</span>}
          <span className="truncate text-xs text-zinc-500">{deal.store}</span>
          <span className="ml-auto flex shrink-0 items-center gap-1 text-xs text-zinc-500 dark:text-zinc-400">
            <HeartIcon className="size-3" />
            {deal.hearts}
          </span>
        </span>
      </div>
    </Link>
  );
}
