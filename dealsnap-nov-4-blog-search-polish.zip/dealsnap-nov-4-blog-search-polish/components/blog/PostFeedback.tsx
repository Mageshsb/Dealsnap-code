"use client";

import { useState, useSyncExternalStore } from "react";
import Link from "next/link";
import { blogVoteAction } from "@/lib/blog-actions";
import Icon from "../Icon";

const key = (slug: string) => `blog-vote:${slug}`;

// The answer is remembered in this browser, so it isn't asked again on the
// same post. Read as an outside store: the server (and the first paint) show
// the question, and a saved answer replaces it without a flash of state.
const listeners = new Set<() => void>();
function subscribe(listener: () => void) {
  listeners.add(listener);
  window.addEventListener("storage", listener);
  return () => {
    listeners.delete(listener);
    window.removeEventListener("storage", listener);
  };
}
function saved(slug: string): "yes" | "no" | null {
  try {
    const value = localStorage.getItem(key(slug));
    return value === "yes" || value === "no" ? value : null;
  } catch {
    return null;
  }
}

// "Was this useful?" after a post. A "No" is the better signal for the
// editors, so it gets a way to ask: the Community, where others can answer.
export default function PostFeedback({ slug }: { slug: string }) {
  const stored = useSyncExternalStore(subscribe, () => saved(slug), () => null);
  // Kept for this visit too, for a browser that won't store it.
  const [now, setNow] = useState<"yes" | "no" | null>(null);
  const answer = now ?? stored;

  function vote(useful: boolean) {
    const a = useful ? "yes" : "no";
    setNow(a);
    try {
      localStorage.setItem(key(slug), a);
      listeners.forEach((l) => l());
    } catch {
      // Not saved; the answer still counts.
    }
    void blogVoteAction(slug, useful);
  }

  const btn =
    "inline-flex min-h-10 items-center gap-1.5 rounded-full border border-zinc-300 px-4 text-sm font-medium transition-colors hover:border-orange-400 hover:text-orange-600 dark:border-zinc-700 dark:hover:border-orange-700 dark:hover:text-orange-400";

  return (
    <section aria-label="Feedback" className="flex min-h-[4.5rem] flex-wrap items-center justify-between gap-3 rounded-xl border border-zinc-200 px-4 py-3 dark:border-zinc-800">
      {answer === null ? (
        <>
          <p className="font-semibold">Was this useful?</p>
          <div className="flex gap-2">
            <button type="button" onClick={() => vote(true)} className={btn}>
              <Icon name="thumbs-up" className="size-4" />
              Yes
            </button>
            <button type="button" onClick={() => vote(false)} className={btn}>
              <Icon name="thumbs-down" className="size-4" />
              No
            </button>
          </div>
        </>
      ) : (
        <p className="text-sm text-zinc-600 dark:text-zinc-400" role="status">
          <Icon name="circle-check" className="mr-1.5 text-green-700 dark:text-green-400" />
          {answer === "yes" ? "Thanks, glad it helped." : "Thanks for telling us."}{" "}
          <Link href="/community/new" className="font-medium text-orange-700 hover:underline dark:text-orange-400">
            Still have a question? Ask the Community
          </Link>
        </p>
      )}
    </section>
  );
}
