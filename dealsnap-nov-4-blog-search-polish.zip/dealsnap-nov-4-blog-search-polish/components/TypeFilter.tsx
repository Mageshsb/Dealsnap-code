"use client";

import { useOptimistic, useTransition } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import Icon from "./Icon";
import { parseSlug, withNarrow, type Facet } from "@/lib/deal-filters";
import { DEAL_KINDS } from "@/lib/deal-kinds";

// "Deal type" in the Filters box, at the top: the six types as small tiles,
// three to a row, in the same order and with the same icons as the post
// form's (components/post/KindTiles.tsx), so a voucher is one tap away. Tap
// one to see only that type; tap it again (or "Any type") for all of them.
// All six always show, in the same places, on every list (even one with a
// single type), so the Filters box looks the same everywhere and a greyed
// tile says at a glance there's nothing of that type here ("no vouchers at
// this store right now"). Like the other filters it narrows this page's list (?type=…),
// showing the choice straight away while the list re-renders on the server.
export default function TypeFilter({ facet }: { facet: Facet }) {
  if (facet.locked) return <LockedType facet={facet} />;
  return <TypeTiles facet={facet} />;
}

// A page of one type only (the Vouchers page): that type as one full-width
// tile, already chosen, in the same place and style as the tiles elsewhere,
// so the Filters box looks the same. "Any type", worded as on every other
// list, goes to All deals (where every type is).
function LockedType({ facet }: { facet: Facet }) {
  const only = facet.options[0];
  const kind = DEAL_KINDS.find((k) => k.value === only?.slug);
  if (!only || !kind) return null;
  return (
    <section className="flex flex-col gap-2">
      <div className="flex min-h-5 items-center justify-between gap-3">
        <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Deal type</h3>
        <Link href="/" className="text-xs font-semibold text-orange-700 hover:underline dark:text-orange-400">
          Any type
        </Link>
      </div>
      {/* Not a choice (it can't be unticked) but what the page is: on the
          Vouchers page it's solid violet, like the Vouchers chip in the
          category row there, rather than the orange of a picked filter. */}
      <p
        aria-label={`${kind.name} only on this page, ${only.count} deal${only.count === 1 ? "" : "s"}`}
        className={`flex min-h-[3.25rem] items-center justify-center gap-2 rounded-xl border px-3 ${
          kind.value === "voucher"
            ? "border-violet-600 bg-violet-600 text-white dark:border-violet-500"
            : "border-orange-500 bg-orange-50 text-orange-800 ring-1 ring-orange-500 dark:bg-orange-950/40 dark:text-orange-300"
        }`}
      >
        <Icon name={kind.icon} className={`size-4 ${kind.value === "voucher" ? "" : "text-orange-600 dark:text-orange-400"}`} />
        <span className="text-[13px] font-semibold">{kind.name} only</span>
      </p>
    </section>
  );
}

function TypeTiles({ facet }: { facet: Facet }) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [, startTransition] = useTransition();
  const [chosen, setChosen] = useOptimistic(parseSlug(params.get("type")));
  const counts = new Map(facet.options.map((o) => [o.slug, o.count]));

  function choose(value: string) {
    startTransition(() => {
      setChosen(value);
      router.push(withNarrow(pathname, new URLSearchParams(params.toString()), "type", value), { scroll: false });
    });
  }

  return (
    <section className="flex flex-col gap-2">
      <div className="flex min-h-5 items-center justify-between gap-3">
        <h3 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Deal type</h3>
        {chosen && (
          <button type="button" onClick={() => choose("")} className="text-xs font-semibold text-orange-700 hover:underline dark:text-orange-400">
            Any type
          </button>
        )}
      </div>
      <div className="grid grid-cols-3 gap-1.5">
        {DEAL_KINDS.map((k) => {
          const count = counts.get(k.value) ?? 0;
          const on = chosen === k.value;
          return (
            <button
              key={k.value}
              type="button"
              onClick={() => choose(on ? "" : k.value)}
              disabled={count === 0 && !on}
              aria-pressed={on}
              aria-label={`${k.name}, ${count} deal${count === 1 ? "" : "s"}`}
              className={`flex min-h-[3.25rem] min-w-0 flex-col items-center justify-center gap-1 rounded-xl border px-1 py-1.5 text-center transition-colors disabled:cursor-default disabled:opacity-40 ${
                on
                  ? "border-orange-500 bg-orange-50 text-orange-800 ring-1 ring-orange-500 dark:bg-orange-950/40 dark:text-orange-300"
                  : "border-zinc-200 bg-white text-zinc-800 enabled:hover:border-orange-300 enabled:hover:bg-orange-50 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:enabled:hover:border-orange-800 dark:enabled:hover:bg-orange-950/30"
              }`}
            >
              <Icon name={k.icon} className={`size-4 ${on ? "text-orange-600 dark:text-orange-400" : "text-zinc-500 dark:text-zinc-400"}`} />
              <span className="w-full truncate text-[13px] font-semibold leading-tight">{k.short}</span>
            </button>
          );
        })}
      </div>
    </section>
  );
}
