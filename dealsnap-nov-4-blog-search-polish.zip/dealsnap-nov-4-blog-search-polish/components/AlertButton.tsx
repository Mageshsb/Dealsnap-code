"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { setTagAlertAction, setStoreAlertAction, setCategoryAlertAction, setBrandAlertAction } from "@/lib/actions";
import { BellIcon } from "./icons";
import StableLabel, { words } from "./StableLabel";

// One-tap "alert me about this category / tag / brand / store". Sits next to the page heading. Updates
// instantly, then saves; logged-out visitors are sent to sign in and brought
// back here afterwards.
export default function AlertButton({
  kind,
  target,
  name,
  nextPath,
  initialOn,
  className = "",
}: {
  kind: "category" | "tag" | "brand" | "store";
  // Category, tag or brand: its slug. Store: its stable key.
  target: string;
  name: string;
  // Where to come back to after signing in.
  nextPath: string;
  initialOn: boolean;
  className?: string;
}) {
  const [on, setOn] = useState(initialOn);
  const [, startTransition] = useTransition();
  const router = useRouter();

  function toggle() {
    const next = !on;
    setOn(next);
    startTransition(async () => {
      const res = await (kind === "category"
        ? setCategoryAlertAction(target, next)
        : kind === "tag"
          ? setTagAlertAction(target, next)
          : kind === "brand"
            ? setBrandAlertAction(target, next)
            : setStoreAlertAction(target, next));
      if (res.needsLogin) {
        setOn(!next);
        router.push(`/login?next=${encodeURIComponent(nextPath)}`);
      } else if (!res.ok) {
        setOn(!next);
      }
    });
  }

  return (
    <button
      type="button"
      onClick={toggle}
      aria-pressed={on}
      aria-label={on ? `Stop alerts for ${name}` : `Get alerts for ${name}`}
      title={
        kind === "category"
          ? on
            ? "You'll be alerted once new deals here reach 25 hearts (change it in Alerts) — click to turn off"
            : "Get alerted when new deals here reach 25 hearts"
          : on
            ? "You'll be alerted about new deals — click to turn off"
            : "Get alerted when new deals are posted"
      }
      // On phones it's just the bell, in a 34px circle (the same height as with
      // words), so more of the page title fits beside it.
      className={`flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-3 py-1.5 text-sm font-semibold leading-5 transition-colors max-sm:h-[34px] max-sm:w-[34px] max-sm:justify-center max-sm:gap-0 max-sm:p-0 ${
        on
          ? "border-orange-500 bg-orange-500 text-white hover:bg-orange-600"
          : "border-zinc-300 text-zinc-700 hover:border-orange-400 hover:text-orange-600 dark:border-zinc-700 dark:text-zinc-200"
      } ${className}`}
    >
      <BellIcon className="h-4 w-4" filled={on} />
      <span className="max-sm:hidden">
        <StableLabel options={words("Get alerts", "Alerts on")} show={on ? "Alerts on" : "Get alerts"} />
      </span>
    </button>
  );
}
