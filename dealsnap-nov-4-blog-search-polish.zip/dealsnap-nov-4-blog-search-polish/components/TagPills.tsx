import { ReactNode } from "react";
import Link from "next/link";
import type { BarTag } from "@/lib/mock-deals";
import Icon from "./Icon";

const pill = "flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-1.5 text-sm font-medium transition-colors";
const suggestion = `${pill} bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300`;
const chevron = <Icon name="chevron-right" className="size-4 shrink-0 text-zinc-500 dark:text-zinc-400" />;

// Where you are, in orange and joined by arrows: the pages above this one, then
// this page's own (tapping it steps back up a level, like clearing a filter;
// a store or brand has no level above it that lists deals, so it goes to all deals).
// `joined`: the category menu in front is itself part of the trail (a tag's
// category), so an arrow follows it. A store's or brand's trail (Stores ›
// Currys) isn't, since its menu is a filter ("All categories"), so it starts
// straight after the menu.
export function Crumbs({
  path = [],
  current,
  deselectHref,
  joined = true,
}: {
  path?: BarTag[];
  current: BarTag;
  deselectHref: string;
  joined?: boolean;
}) {
  return (
    <nav aria-label="Breadcrumb" className="flex shrink-0 items-center gap-1.5">
      {path.map((t, i) => (
        <span key={t.name} className="flex shrink-0 items-center gap-1.5">
          {(joined || i > 0) && chevron}
          <Link
            href={t.href}
            className={`${pill} bg-orange-50 text-orange-700 hover:bg-orange-100 dark:bg-orange-950/40 dark:text-orange-300 dark:hover:bg-orange-950/70`}
          >
            {t.name}
          </Link>
        </span>
      ))}
      {(joined || path.length > 0) && chevron}
      <Link href={deselectHref} aria-current="page" aria-label={`${current.name}, tap to ${deselectHref === "/" ? "go back to all deals" : "go up a level"}`} className={`${pill} bg-orange-500 text-white`}>
        {current.name}
        <Icon name="x" className="size-3.5" />
      </Link>
    </nav>
  );
}

// The row above the list on category, tag and brand pages. It starts with
// where you are (see Crumbs: the category menu › Laptop › MacBook), then a
// divider, then grey suggestions of where to go next (getBarTags decides
// those). On a phone a sub-tag's path can run off the right edge; it starts
// from the category, and the title below names the page.
export default function TagPills({
  tags,
  path = [],
  current,
  deselectHref = "/categories",
  leading,
  joined = true,
  divided,
  end = { name: "All Categories & Tags", href: "/categories" },
}: {
  tags: BarTag[];
  // Pages between the start of the trail and this page's own (a sub-tag's tag).
  path?: BarTag[];
  // This page's own tag, store or brand.
  current?: BarTag;
  // Where tapping the current page goes: one level up.
  deselectHref?: string;
  leading?: ReactNode;
  // Whether the menu in front belongs to the trail (see Crumbs).
  joined?: boolean;
  // Divide the suggestions off from where you are (when `leading` is part of it).
  divided?: boolean;
  end?: BarTag;
}) {
  // `leading` (the category menu button) scrolls away with the pills, so a
  // long category name never eats into the room for swiping along the row.
  return (
    <div className="no-scrollbar flex items-center gap-2 overflow-x-auto scroll-smooth">
      {leading && <div className="shrink-0">{leading}</div>}
      {current && <Crumbs path={path} current={current} deselectHref={deselectHref} joined={joined} />}
      {divided && <span aria-hidden className="mx-1 h-6 w-px shrink-0 bg-zinc-300 dark:bg-zinc-700" />}
      {tags.map((tag) => (
        <Link key={tag.name} href={tag.href} className={suggestion}>
          {tag.name}
        </Link>
      ))}
      <Link
        href={end.href}
        className="shrink-0 rounded-xl bg-zinc-100 px-3 py-1.5 text-sm font-semibold text-orange-700 transition-colors hover:bg-zinc-200 dark:bg-zinc-800 dark:text-orange-400"
      >
        {end.name} →
      </Link>
    </div>
  );
}
