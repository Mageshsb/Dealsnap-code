import Link from "next/link";
import type { Deal } from "@/lib/types";
import { getAllDeals } from "@/lib/mock-deals";
import { priceCheck } from "@/lib/price-history";
import { formatPrice } from "@/lib/format";
import Icon from "./Icon";

const shortDate = (iso: string) => new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });

// Under a deal's price: how it compares with the other times the same product
// was posted here. Nothing shows for a product's first post.
export default function PriceCheck({ deal }: { deal: Deal }) {
  const check = priceCheck(deal, getAllDeals());
  if (!check) return null;
  const { verdict, cheapest, history } = check;

  const tone =
    verdict === "higher"
      ? "border-amber-200 bg-amber-50 text-amber-900 dark:border-amber-900/60 dark:bg-amber-950/30 dark:text-amber-200"
      : "border-green-200 bg-green-50 text-green-900 dark:border-green-900/60 dark:bg-green-950/30 dark:text-green-200";

  return (
    <details className={`group rounded-xl border text-sm ${tone}`}>
      <summary className="flex cursor-pointer list-none items-center gap-2 px-3 py-2 [&::-webkit-details-marker]:hidden">
        <Icon name={verdict === "higher" ? "warning" : "trending-down"} className="size-4" />
        <span className="min-w-0 flex-1 font-medium">
          {verdict === "lowest" && "Lowest price on DealSnap"}
          {verdict === "matches" && "Matches the lowest price on DealSnap"}
          {verdict === "higher" && (
            <>
              It&apos;s been cheaper here: {formatPrice(cheapest.price)} on {shortDate(cheapest.postedAt)}
            </>
          )}
        </span>
        <span className="shrink-0 text-xs opacity-70 group-open:hidden">History</span>
        <span className="hidden shrink-0 text-xs opacity-70 group-open:inline">Hide</span>
      </summary>
      <div className="flex flex-col gap-1 border-t border-current/10 px-3 pb-2.5 pt-2">
        <p className="text-xs opacity-80">Other times members posted this:</p>
        <ul className="flex flex-col gap-0.5">
          {history.slice(0, 5).map((p) => (
            <li key={p.slug} className="flex justify-between gap-3 text-xs">
              <Link href={`/deals/${p.slug}`} className="underline-offset-2 hover:underline">
                {shortDate(p.postedAt)} at {p.store}
              </Link>
              <span className="font-semibold tabular-nums">{formatPrice(p.price)}</span>
            </li>
          ))}
        </ul>
      </div>
    </details>
  );
}
