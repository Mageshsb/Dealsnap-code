"use client";

import { Suspense, useEffect, useRef, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { useTaxonomy } from "./TaxonomyProvider";
import { ClearSearch, searchBox } from "@/components/SearchBox";
import Icon, { type IconName } from "./Icon";
import { SEARCH_MAX } from "@/lib/search-limits";
import { isPostedPhoto, smallPhoto } from "@/lib/deal-photos";
import { linkIn } from "@/lib/pasted-link";

type DealResult = {
  slug: string;
  title: string;
  priceLabel: string;
  off: number;
  store: string;
  category: string;
  icon: IconName;
  image?: string;
  expired: boolean;
};

type CategoryResult = { name: string; icon: IconName; slug: string };
type TagResult = { name: string; icon: IconName; slug: string; categorySlug: string; parentName?: string };
type BrandResult = { name: string; slug: string; dealCount: number };

type StoreResult = { name: string; slug: string; dealCount: number };

type SearchResponse = {
  categories: CategoryResult[];
  stores: StoreResult[];
  tags: TagResult[];
  brands: BrandResult[];
  // A brand and a type searched together ("apple laptop").
  combo?: { name: string; href: string };
  // Codes asked for ("asos voucher"): the store's voucher codes, or all of them.
  vouchers?: { name: string; href: string; count: number };
  results: DealResult[];
  // A shop link was pasted: the deals already on DealSnap for it.
  link?: { url: string; deals: DealResult[] };
};

const EMPTY: SearchResponse = { categories: [], stores: [], tags: [], brands: [], results: [] };

// Reports every navigation (path and ?q=) to the search bar. On its own so
// only this empty component waits on the address's query string, not the bar.
function NavWatcher({ onNav }: { onNav: (pathname: string, q: string | null) => void }) {
  const pathname = usePathname();
  const q = useSearchParams().get("q");
  useEffect(() => {
    onNav(pathname, q);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname, q]);
  return null;
}

export default function SearchBar() {
  const taxonomy = useTaxonomy();
  const [query, setQuery] = useState("");
  const [data, setData] = useState<SearchResponse>(EMPTY);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  // Bumped for every lookup and on every search or page change, so an answer
  // that arrives late (the user typed on, or already pressed Enter) is dropped
  // instead of reopening the list over the results page.
  const requestRef = useRef(0);
  // The tag/category/store links in the list go to a page about the text in
  // the box, so it stays. Any other page change (nav links, a deal card, the
  // logo, browser back) means the user's moved on, so the box empties; on the
  // search results page it shows that page's search.
  const preserveOnNavRef = useRef(false);
  const router = useRouter();

  function cancelLookup() {
    clearTimeout(debounceRef.current);
    requestRef.current++;
    setLoading(false);
  }

  function handleNav(pathname: string, q: string | null) {
    cancelLookup();
    setOpen(false);
    setMobileOpen(false);
    setData(EMPTY);
    if (preserveOnNavRef.current) {
      preserveOnNavRef.current = false;
      return;
    }
    setQuery(pathname === "/" && q ? q.slice(0, SEARCH_MAX) : "");
  }

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
        setMobileOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (mobileOpen) inputRef.current?.focus();
  }, [mobileOpen]);

  function handleChange(typed: string) {
    // A pasted shop link can be long; a search can't (see lib/search-limits).
    const link = linkIn(typed);
    const value = link ? typed : typed.slice(0, SEARCH_MAX);
    setQuery(value);
    cancelLookup();

    if (!value.trim()) {
      setData(EMPTY);
      setOpen(false);
      return;
    }

    debounceRef.current = setTimeout(async () => {
      const request = ++requestRef.current;
      setLoading(true);
      try {
        const res = await fetch(link ? `/api/search?link=${encodeURIComponent(link)}` : `/api/search?q=${encodeURIComponent(value)}`);
        // A server hiccup (an error page, or "too many searches") isn't an answer:
        // keep what was shown and let the next keystroke try again.
        if (!res.ok) throw new Error("Search failed");
        const json = await res.json();
        if (request !== requestRef.current) return;
        setData(json);
        setOpen(true);
      } catch {
        // Nothing to show for this one; the box and what was typed stay as they are.
      } finally {
        if (request === requestRef.current) setLoading(false);
      }
    }, 250);
  }

  // Empties the box but leaves the bar open, ready for a new search.
  function clearSearch() {
    cancelLookup();
    // Focus first: its onFocus handler still sees the old list and would reopen it.
    inputRef.current?.focus();
    setQuery("");
    setData(EMPTY);
    setOpen(false);
  }

  // Enter or "See all results". Closes the list (and the phone's search bar
  // and keyboard) straight away, before the results page arrives.
  function goToFullResults() {
    const q = query.trim();
    if (!q) return;
    cancelLookup();
    setOpen(false);
    setMobileOpen(false);
    inputRef.current?.blur();
    // A shop link goes to the top of the list: the deal for it already on
    // DealSnap, or else posting it.
    const link = linkIn(q);
    if (link) {
      const existing = data.link?.url === link ? data.link.deals[0] : undefined;
      router.push(existing ? `/deals/${existing.slug}` : postLinkHref(link));
      return;
    }
    router.push(`/?q=${encodeURIComponent(q)}`);
  }

  const postLinkHref = (link: string) => `/submit?url=${encodeURIComponent(link)}`;

  const hasAny =
    !!data.vouchers || data.categories.length > 0 || data.stores.length > 0 || data.tags.length > 0 || data.brands.length > 0 || data.results.length > 0;

  function dealItem(deal: DealResult) {
    const theme = taxonomy.categoryTheme(deal.category);
    return (
      <li key={deal.slug}>
        <Link
          href={`/deals/${deal.slug}`}
          onClick={() => setOpen(false)}
          className="flex items-center gap-3 px-3 py-2 hover:bg-zinc-50 dark:hover:bg-zinc-800"
        >
          <div
            className={`relative h-10 w-10 shrink-0 overflow-hidden rounded-md ${theme.tile} ${deal.expired ? "opacity-50 grayscale" : ""}`}
          >
            {deal.image ? (
              <Image
                src={smallPhoto(deal.image)}
                alt=""
                unoptimized={isPostedPhoto(deal.image)}
                fill
                className="object-contain"
                sizes="40px"
              />
            ) : (
              <span className="flex h-full w-full items-center justify-center">
                <Icon name={deal.icon} strokeWidth={1.75} className={`size-5 ${theme.icon}`} />
              </span>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <p className={`truncate text-sm font-medium ${deal.expired ? "text-zinc-500 dark:text-zinc-500" : ""}`}>{deal.title}</p>
            <p className="truncate text-xs text-zinc-500">
              {deal.priceLabel}
              {deal.store && <> at {deal.store}</>}
              {deal.expired ? (
                <span className="font-medium"> · Expired</span>
              ) : deal.off > 0 && (
                <span className="text-green-700 dark:text-green-400">
                  {" "}
                  · {deal.off}% off
                </span>
              )}
            </p>
          </div>
        </Link>
      </li>
    );
  }

  return (
    <>
      <Suspense fallback={null}>
        <NavWatcher onNav={handleNav} />
      </Suspense>
      <button
        type="button"
        onClick={() => setMobileOpen(true)}
        aria-label="Search"
        className={`ml-auto flex h-11 w-11 shrink-0 items-center justify-center rounded-lg text-zinc-600 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-800 md:hidden ${
          mobileOpen ? "hidden" : "flex"
        }`}
      >
        <Icon name="search" className="size-5" />
      </button>

      <div
        ref={containerRef}
        className={`${
          mobileOpen
            ? "absolute inset-0 z-30 flex items-center gap-2 bg-white/95 px-3 backdrop-blur dark:bg-black/95"
            : "hidden"
        } md:static md:z-auto md:flex md:min-w-0 md:flex-1 md:bg-transparent md:px-0 md:backdrop-blur-none`}
      >
        <form
          onSubmit={(e) => {
            e.preventDefault();
            goToFullResults();
          }}
          className="min-w-0 flex-1"
        >
          <div className="relative">
          <input
            ref={inputRef}
            type="search"
            value={query}
            onChange={(e) => handleChange(e.target.value)}
            onFocus={() => (hasAny || data.link) && setOpen(true)}
            onKeyDown={(e) => {
              if (e.key === "Escape") {
                setOpen(false);
                setMobileOpen(false);
              }
            }}
            placeholder="Search deals, e.g. TV"
            aria-label="Search deals"
            className={searchBox}
          />
          {query && <ClearSearch onClick={clearSearch} />}
          </div>
        </form>

        <button
          type="button"
          onClick={() => setMobileOpen(false)}
          aria-label="Close search"
          className="flex h-11 shrink-0 items-center justify-center px-1 text-sm font-medium text-zinc-600 dark:text-zinc-300 md:hidden"
        >
          Close
        </button>

        {open && (
        <div className="absolute left-0 right-0 top-full z-20 mt-2 max-h-[min(28rem,calc(100dvh-6rem))] overflow-y-auto rounded-xl border border-zinc-200 bg-white shadow-lg dark:border-zinc-800 dark:bg-zinc-900">
          {loading ? (
            <p className="p-4 text-sm text-zinc-500">Searching…</p>
          ) : data.link ? (
            <>
              {data.link.deals.length > 0 && (
                <div className="border-b border-zinc-100 py-1 dark:border-zinc-800">
                  <p className="px-3 pt-1.5 pb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">
                    Already on DealSnap
                  </p>
                  <ul className="flex flex-col">{data.link.deals.map(dealItem)}</ul>
                </div>
              )}
              <Link
                href={postLinkHref(data.link.url)}
                onClick={() => setOpen(false)}
                className="flex items-center gap-3 px-3 py-2.5 hover:bg-zinc-50 dark:hover:bg-zinc-800"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-orange-100 text-orange-700 dark:bg-orange-950/50 dark:text-orange-400">
                  <Icon name="plus" className="size-5" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-semibold">Post this deal</span>
                  <span className="block truncate text-xs text-zinc-500">
                    {data.link.deals.length > 0
                      ? "Only if yours is cheaper or different"
                      : `From ${new URL(data.link.url).hostname.replace(/^www\./, "")}`}
                  </span>
                </span>
              </Link>
            </>
          ) : !hasAny ? (
            <p className="p-4 text-sm text-zinc-500">No matches found.</p>
          ) : (
            <>
              {data.vouchers && (
                <div className="border-b border-zinc-100 py-1 dark:border-zinc-800">
                  <Link
                    href={data.vouchers.href}
                    onClick={() => {
                      setOpen(false);
                      preserveOnNavRef.current = true;
                    }}
                    className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-violet-50 dark:hover:bg-violet-950/40"
                  >
                    <Icon name="ticket" className="size-4 text-violet-600 dark:text-violet-400" />
                    <span className="font-medium text-violet-700 dark:text-violet-300">{data.vouchers.name}</span>
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">
                      {data.vouchers.count} live code{data.vouchers.count === 1 ? "" : "s"}
                    </span>
                  </Link>
                </div>
              )}

              {data.combo && (
                <div className="border-b border-zinc-100 py-1 dark:border-zinc-800">
                  <Link
                    href={data.combo.href}
                    onClick={() => {
                      setOpen(false);
                      preserveOnNavRef.current = true;
                    }}
                    className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-zinc-50 dark:hover:bg-zinc-800"
                  >
                    <Icon name="search" className="size-4 text-zinc-500 dark:text-zinc-400" />
                    <span className="font-medium">{data.combo.name}</span>
                  </Link>
                </div>
              )}

              {data.categories.length > 0 && (
                <div className="border-b border-zinc-100 py-1 dark:border-zinc-800">
                  <p className="px-3 pt-1.5 pb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">
                    Categories
                  </p>
                  {data.categories.map((c) => (
                    <Link
                      key={c.slug}
                      href={`/categories/${c.slug}`}
                      onClick={() => {
                        setOpen(false);
                        setQuery(c.name);
                        preserveOnNavRef.current = true;
                      }}
                      className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-zinc-50 dark:hover:bg-zinc-800"
                    >
                      <Icon name={c.icon} className="size-4 text-zinc-500 dark:text-zinc-400" />
                      <span className="font-medium">{c.name}</span>
                    </Link>
                  ))}
                </div>
              )}

              {data.tags.length > 0 && (
                <div className="border-b border-zinc-100 py-1 dark:border-zinc-800">
                  <p className="px-3 pt-1.5 pb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">
                    Tags
                  </p>
                  {data.tags.map((t) => (
                    <Link
                      key={t.slug}
                      href={`/tags/${t.slug}`}
                      onClick={() => {
                        setOpen(false);
                        setQuery(t.name);
                        preserveOnNavRef.current = true;
                      }}
                      className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-zinc-50 dark:hover:bg-zinc-800"
                    >
                      <Icon name={t.icon} className="size-4 text-zinc-500 dark:text-zinc-400" />
                      <span className="font-medium">{t.name}</span>
                      {t.parentName && <span className="text-xs text-zinc-500 dark:text-zinc-400">in {t.parentName}</span>}
                    </Link>
                  ))}
                </div>
              )}

              {data.brands.length > 0 && (
                <div className="border-b border-zinc-100 py-1 dark:border-zinc-800">
                  <p className="px-3 pt-1.5 pb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">
                    Brands
                  </p>
                  {data.brands.map((b) => (
                    <Link
                      key={b.slug}
                      href={`/brands/${b.slug}`}
                      onClick={() => {
                        setOpen(false);
                        setQuery(b.name);
                        preserveOnNavRef.current = true;
                      }}
                      className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-zinc-50 dark:hover:bg-zinc-800"
                    >
                      <Icon name="badge-check" className="size-4 text-zinc-500 dark:text-zinc-400" />
                      <span className="font-medium">{b.name}</span>
                      <span className="text-xs text-zinc-500 dark:text-zinc-400">
                        {b.dealCount} live deal{b.dealCount === 1 ? "" : "s"}
                      </span>
                    </Link>
                  ))}
                </div>
              )}

              {data.stores.length > 0 && (
                <div className="border-b border-zinc-100 py-1 dark:border-zinc-800">
                  <p className="px-3 pt-1.5 pb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">
                    Stores
                  </p>
                  {data.stores.map((st) => (
                    <Link
                      key={st.slug}
                      href={`/stores/${st.slug}`}
                      onClick={() => {
                        setOpen(false);
                        setQuery(st.name);
                        preserveOnNavRef.current = true;
                      }}
                      className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-zinc-50 dark:hover:bg-zinc-800"
                    >
                      <Icon name="store" className="size-4 text-zinc-500 dark:text-zinc-400" />
                      <span className="font-medium">{st.name}</span>
                      <span className="text-xs text-zinc-500 dark:text-zinc-400">
                        {st.dealCount} live deal{st.dealCount === 1 ? "" : "s"}
                      </span>
                    </Link>
                  ))}
                </div>
              )}

              {data.results.length > 0 && (
                <div className="py-1">
                  <p className="px-3 pt-1.5 pb-1 text-[11px] font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">
                    Deals
                  </p>
                  <ul className="flex flex-col">{data.results.map(dealItem)}</ul>
                </div>
              )}

              <button
                onClick={goToFullResults}
                className="w-full border-t border-zinc-100 p-3 text-center text-sm font-medium text-orange-500 hover:bg-zinc-50 dark:border-zinc-800 dark:hover:bg-zinc-800"
              >
                See all results for &ldquo;{query}&rdquo;
              </button>
            </>
          )}
        </div>
        )}
      </div>
    </>
  );
}
