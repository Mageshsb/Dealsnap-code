"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useState, useTransition } from "react";
import { setCommentReportAction, setDealEndedAction, setDealReportAction } from "@/lib/actions";
import { FlagIcon, HourglassIcon, quietActionClass, tellUsRowClass } from "@/components/icons";
import Icon from "@/components/Icon";
import MoreMenu, { moreMenuItem } from "@/components/MoreMenu";

// The quiet Report links (and "Deal ended?"), and a comment's Report in its
// "⋯" menu. They change in place with no page reload: reporting turns into
// "Reported · Undo", so a stray tap is easy to take back.

function Reported({ onUndo, pending, fade }: { onUndo: () => void; pending: boolean; fade: string }) {
  return (
    <span className={`${fade} inline-flex items-center gap-1.5 whitespace-nowrap text-xs text-zinc-500 dark:text-zinc-500`}>
      <FlagIcon className="h-3.5 w-3.5" />
      Reported
      <button
        type="button"
        onClick={onUndo}
        disabled={pending}
        className="font-medium text-orange-700 hover:underline disabled:opacity-50 dark:text-orange-400"
      >
        Undo
      </button>
    </span>
  );
}

// A comment's reason is nearly always obvious, so one tap on Report in its
// "⋯" menu reports it. The menu then gives way to "Reported · Undo" in place,
// so a stray tap is easy to take back.
export function CommentReportMenu({
  commentId,
  initiallyReported,
}: {
  commentId: string;
  initiallyReported: boolean;
}) {
  const [reported, setReported] = useState(initiallyReported);
  const [touched, setTouched] = useState(false);
  const [pending, startTransition] = useTransition();
  const fade = touched ? "tell-us-in" : "";

  function set(next: boolean) {
    setTouched(true);
    setReported(next);
    startTransition(async () => {
      const saved = await setCommentReportAction(commentId, next);
      if (saved === null) setReported(!next);
    });
  }

  if (reported) return <Reported onUndo={() => set(false)} pending={pending} fade={fade} />;
  return (
    <MoreMenu label="Comment options">
      {(close) => (
        <button
          type="button"
          role="menuitem"
          onClick={() => {
            close();
            set(true);
          }}
          className={`${moreMenuItem} hover:text-red-600 dark:hover:text-red-400`}
        >
          <Icon name="flag" className="size-4 text-zinc-500 dark:text-zinc-400" />
          Report comment
        </button>
      )}
    </MoreMenu>
  );
}

// The quiet line under a deal: "Deal ended?" and "Report other issue". Both
// ask once more before counting — "Confirm: Yes, I checked / Yes, report ·
// Cancel" — so people check the deal rather than tapping it because it didn't
// work for them. Everything swaps in place, fading in, with no page refresh;
// while a question is up, or once either report is sent, the other link steps
// aside. The line wraps to a second row only when it has to (see tellUsRowClass).
type Asking = null | "ended" | "report";

export function DealTellUs({
  dealSlug,
  canSayEnded,
  initiallyEnded,
  initiallyReported,
  canFix = false,
}: {
  dealSlug: string;
  canSayEnded: boolean;
  initiallyEnded: boolean;
  initiallyReported: boolean;
  // Helpers can fix details on a deal that isn't theirs.
  canFix?: boolean;
}) {
  const [ended, setEnded] = useState(initiallyEnded);
  const [reported, setReported] = useState(initiallyReported);
  const [asking, setAskingState] = useState<Asking>(null);
  // Opened from the helper desk (?from=helper&hq=…): Fix details keeps that,
  // so saving goes straight back to the desk. The edit page checks both again.
  const params = useSearchParams();
  const from = params.get("from") === "helper" ? `?from=helper${params.get("hq") ? `&hq=${encodeURIComponent(params.get("hq")!)}` : ""}` : "";
  // Swaps fade in once the member starts using the line, not on page load.
  const [touched, setTouched] = useState(false);
  const [pending, startTransition] = useTransition();
  const fade = touched ? "tell-us-in" : "";

  function setAsking(next: Asking) {
    setTouched(true);
    setAskingState(next);
  }

  function setEndedTo(next: boolean) {
    setAsking(null);
    setEnded(next);
    // A member has one report per deal, so "it's ended" replaces any earlier
    // Report rather than sitting beside it.
    if (next) setReported(false);
    startTransition(async () => {
      const saved = await setDealEndedAction(dealSlug, next);
      if (saved === null) setEnded(!next);
    });
  }

  function setReportedTo(next: boolean) {
    setAsking(null);
    setReported(next);
    startTransition(async () => {
      const saved = await setDealReportAction(dealSlug, next);
      if (saved === null) setReported(!next);
    });
  }

  if (asking) {
    const askingEnded = asking === "ended";
    return (
      <div className={tellUsRowClass}>
        <span key={asking} className={`${fade} inline-flex items-center gap-1.5 text-xs text-zinc-500`}>
          {askingEnded ? <HourglassIcon className="h-3.5 w-3.5 shrink-0" /> : <FlagIcon className="h-3.5 w-3.5 shrink-0" />}
          Confirm:
          <button
            type="button"
            onClick={() => (askingEnded ? setEndedTo(true) : setReportedTo(true))}
            className={`font-medium hover:underline ${
              askingEnded ? "text-amber-600 dark:text-amber-400" : "text-red-600 dark:text-red-400"
            }`}
          >
            {askingEnded ? "Yes, I checked" : "Yes, report"}
          </button>
          <button
            type="button"
            onClick={() => setAsking(null)}
            className="ml-2 text-zinc-500 hover:text-zinc-600 dark:text-zinc-500 dark:hover:text-zinc-300"
          >
            Cancel
          </button>
        </span>
      </div>
    );
  }

  let endedLink: React.ReactNode = null;
  if (canSayEnded && ended) {
    endedLink = (
      <span className={`${fade} inline-flex items-center gap-1.5 text-xs text-zinc-500`}>
        <HourglassIcon className="h-3.5 w-3.5 shrink-0" />
        You said it&apos;s ended
        <button
          type="button"
          onClick={() => setEndedTo(false)}
          disabled={pending}
          className="font-medium text-orange-700 hover:underline disabled:opacity-50 dark:text-orange-400"
        >
          Undo
        </button>
      </span>
    );
  } else if (canSayEnded && !reported) {
    endedLink = (
      <button
        type="button"
        onClick={() => setAsking("ended")}
        className={`${fade} ${quietActionClass} hover:text-amber-600 dark:hover:text-amber-400`}
      >
        <HourglassIcon className="h-3.5 w-3.5" />
        Deal ended?
      </button>
    );
  }

  // One report per member per deal (a second would replace the first), so
  // once either is sent only that one stays on the line, with its Undo.
  let reportLink: React.ReactNode = null;
  if (!ended && reported) {
    reportLink = <Reported onUndo={() => setReportedTo(false)} pending={pending} fade={fade} />;
  } else if (!ended) {
    reportLink = (
      <button
        type="button"
        onClick={() => setAsking("report")}
        className={`${fade} ${quietActionClass} hover:text-red-500 dark:hover:text-red-400`}
      >
        <FlagIcon className="h-3.5 w-3.5" />
        Report other issue
      </button>
    );
  }

  return (
    <div className={tellUsRowClass}>
      {endedLink}
      {reportLink}
      {canFix && (
        <Link href={`/deals/${dealSlug}/edit${from}`} className={`${quietActionClass} hover:text-orange-600 dark:hover:text-orange-400`}>
          <Icon name="pencil" className="size-3.5" />
          Fix details
        </Link>
      )}
    </div>
  );
}

// The same line for the person who posted the deal: change it, or say it's
// ended (which ends it at once, as they know best), with an Undo.
export function DealOwnerRow({
  dealSlug,
  canSayEnded,
  initiallyEnded,
}: {
  dealSlug: string;
  canSayEnded: boolean;
  initiallyEnded: boolean;
}) {
  const [ended, setEnded] = useState(initiallyEnded);
  const [asking, setAsking] = useState(false);
  const [touched, setTouched] = useState(false);
  const [pending, startTransition] = useTransition();
  const fade = touched ? "tell-us-in" : "";

  function setEndedTo(next: boolean) {
    setTouched(true);
    setAsking(false);
    setEnded(next);
    startTransition(async () => {
      const saved = await setDealEndedAction(dealSlug, next);
      if (saved === null) setEnded(!next);
    });
  }

  if (asking) {
    return (
      <div className={tellUsRowClass}>
        <span className={`${fade} inline-flex items-center gap-1.5 text-xs text-zinc-500`}>
          <HourglassIcon className="h-3.5 w-3.5 shrink-0" />
          Confirm:
          <button type="button" onClick={() => setEndedTo(true)} className="font-medium text-amber-600 hover:underline dark:text-amber-400">
            Yes, it&apos;s ended
          </button>
          <button
            type="button"
            onClick={() => setAsking(false)}
            className="ml-2 text-zinc-500 hover:text-zinc-600 dark:text-zinc-500 dark:hover:text-zinc-300"
          >
            Cancel
          </button>
        </span>
      </div>
    );
  }

  return (
    <div className={tellUsRowClass}>
      {ended ? (
        <span className={`${fade} inline-flex items-center gap-1.5 text-xs text-zinc-500`}>
          <HourglassIcon className="h-3.5 w-3.5 shrink-0" />
          You marked it ended
          <button
            type="button"
            onClick={() => setEndedTo(false)}
            disabled={pending}
            className="font-medium text-orange-700 hover:underline disabled:opacity-50 dark:text-orange-400"
          >
            Undo
          </button>
        </span>
      ) : (
        canSayEnded && (
          <button
            type="button"
            onClick={() => {
              setTouched(true);
              setAsking(true);
            }}
            className={`${fade} ${quietActionClass} hover:text-amber-600 dark:hover:text-amber-400`}
          >
            <HourglassIcon className="h-3.5 w-3.5" />
            It&apos;s ended
          </button>
        )
      )}
      <Link href={`/deals/${dealSlug}/edit`} className={`${quietActionClass} hover:text-orange-600 dark:hover:text-orange-400`}>
        <Icon name="pencil" className="size-3.5" />
        Edit deal
      </Link>
    </div>
  );
}
