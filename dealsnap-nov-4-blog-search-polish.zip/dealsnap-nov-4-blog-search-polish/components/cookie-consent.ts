"use client";

import { useSyncExternalStore } from "react";

// The visitor's cookie choices live in their own browser (localStorage), so
// they need no server round-trip. Nothing optional runs until the visitor has
// said yes to it (UK PECR): no answer, an old answer or a broken one all count
// as "no".
//
// Two optional kinds, each its own yes/no:
//   analytics: Google Analytics / Tag Manager (visitor statistics)
//   marketing: the admin's custom code (a Meta pixel and the like)
export type CookieCategory = "analytics" | "marketing";

export type ConsentChoice = { v: number; analytics: boolean; marketing: boolean; at: string; asked: CookieCategory[] };

// "loading" is only ever seen during server render and the first client paint:
// it keeps the banner hidden until we know whether this visitor has answered,
// instead of flashing it for everyone.
export type Consent = "loading" | "unset" | ConsentChoice;

const KEY = "dealsnap:cookieConsent";
const EVENT = "dealsnap:consent-change";
const OPEN_EVENT = "dealsnap:open-cookie-settings";
// Asked again after about six months, the gap the ICO suggests.
const MAX_AGE_MS = 182 * 24 * 60 * 60 * 1000;
// The banner's wording, version by version. Add one whenever what it says
// visitors are agreeing to changes (a new purpose, a new kind of company):
// everyone is then asked again, since their old yes was to something else.
// Small fixes to spelling or layout don't need it.
//   1: 2026-11-01, first version: analytics (Google) and marketing (named in Admin)
export const BANNER_VERSION = 1;

function subscribe(onChange: () => void) {
  window.addEventListener(EVENT, onChange);
  window.addEventListener("storage", onChange);
  return () => {
    window.removeEventListener(EVENT, onChange);
    window.removeEventListener("storage", onChange);
  };
}

// The raw text, so useSyncExternalStore compares strings (a fresh object each
// read would look like a change every time).
function getRaw(): string {
  try {
    return window.localStorage.getItem(KEY) ?? "";
  } catch {
    return "";
  }
}

function parse(raw: string): ConsentChoice | "unset" {
  try {
    const c = JSON.parse(raw);
    if (c?.v !== BANNER_VERSION || typeof c.analytics !== "boolean" || typeof c.marketing !== "boolean" || !Array.isArray(c.asked)) return "unset";
    const at = new Date(c.at).getTime();
    if (!at || Date.now() - at > MAX_AGE_MS) return "unset";
    return { v: c.v, analytics: c.analytics, marketing: c.marketing, at: c.at, asked: c.asked };
  } catch {
    // Nothing saved, or the old single "granted"/"denied" answer: ask again.
    return "unset";
  }
}

// `categories`: the kinds this site actually uses right now. A choice made
// before one of them existed doesn't cover it, so the visitor is asked again.
export function useConsent(categories: CookieCategory[]): Consent {
  const raw = useSyncExternalStore(subscribe, getRaw, () => null);
  if (raw === null) return "loading";
  const choice = parse(raw);
  if (choice === "unset" || categories.some((c) => !choice.asked.includes(c))) return "unset";
  return choice;
}

// The last choice saved, if it still stands.
export function savedChoice(): ConsentChoice | undefined {
  const c = parse(getRaw());
  return c === "unset" ? undefined : c;
}

export function saveConsent(categories: CookieCategory[], yes: Partial<Record<CookieCategory, boolean>>) {
  const before = parse(getRaw());
  const next: ConsentChoice = {
    v: BANNER_VERSION,
    analytics: categories.includes("analytics") && !!yes.analytics,
    marketing: categories.includes("marketing") && !!yes.marketing,
    at: new Date().toISOString(),
    asked: categories,
  };
  try {
    window.localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    // Storage blocked (private mode etc.): the choice holds for this page only.
  }
  window.dispatchEvent(new Event(EVENT));
  // Taking a yes back: scripts already running can't be unloaded, so clear
  // the cookies they left on our domain and reload without them.
  if (before !== "unset" && ((before.analytics && !next.analytics) || (before.marketing && !next.marketing))) {
    clearTrackingCookies();
    window.location.reload();
  }
}

// Google Analytics (_ga, _gid…), Google Ads (_gcl…) and Meta (_fbp, _fbc).
// Cookies are cleared on this host and each parent domain they may sit on.
function clearTrackingCookies() {
  const names = document.cookie.split(";").map((c) => c.split("=")[0].trim());
  const parts = window.location.hostname.split(".");
  const domains = parts.map((_, i) => parts.slice(i).join(".")).filter((d) => d.includes("."));
  for (const name of names) {
    if (!/^(_ga|_gid|_gat|_gcl|_fbp|_fbc)/.test(name)) continue;
    document.cookie = `${name}=; Max-Age=0; path=/`;
    for (const d of domains) document.cookie = `${name}=; Max-Age=0; path=/; domain=.${d}`;
  }
}

// The footer's "Cookies" link (and the one on the privacy page) reopens the
// banner on its choices, already set to what the visitor picked before.
export function openCookieSettings() {
  window.dispatchEvent(new Event(OPEN_EVENT));
}

export function onOpenCookieSettings(handler: () => void) {
  window.addEventListener(OPEN_EVENT, handler);
  return () => window.removeEventListener(OPEN_EVENT, handler);
}
