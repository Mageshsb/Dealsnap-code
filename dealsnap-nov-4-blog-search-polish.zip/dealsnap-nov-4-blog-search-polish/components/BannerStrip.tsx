"use client";

import Link from "next/link";
import { useState } from "react";
import { BANNER_CLOSED_COOKIE } from "@/lib/banners";
import Icon from "./Icon";

// The banner across the top of the site (Admin → Banners). It can be closed;
// that's remembered in a cookie the page reads before drawing (app/layout), so
// a closed banner never flashes up and then vanishes. An edited banner (a new
// version) shows again. `preview` is the admin's look at it, with nothing to remember.
export default function BannerStrip({
  stamp,
  message,
  linkUrl,
  linkLabel,
  bg,
  fg,
  preview = false,
}: {
  stamp: string; // the banner's id and version
  message: string;
  linkUrl?: string;
  linkLabel?: string;
  bg: string; // colours, as #rrggbb
  fg: string;
  preview?: boolean;
}) {
  const [closed, setClosed] = useState(false);
  if (closed && !preview) return null;
  const linkClass = "whitespace-nowrap font-semibold underline underline-offset-2 hover:no-underline";

  return (
    <div
      role="region"
      aria-label="Announcement"
      style={{ backgroundColor: bg, color: fg }}
      className="flex items-center gap-2 px-4 py-1.5 text-sm"
    >
      <p className="min-w-0 flex-1 text-center leading-snug">
        {message}
        {linkUrl && (
          <>
            {" "}
            {linkUrl.startsWith("/") ? (
              <Link href={linkUrl} className={linkClass}>
                {linkLabel}
              </Link>
            ) : (
              <a href={linkUrl} target="_blank" rel="noopener nofollow" className={linkClass}>
                {linkLabel}
              </a>
            )}
          </>
        )}
      </p>
      {!preview && (
        <button
          type="button"
          aria-label="Close announcement"
          onClick={() => {
            document.cookie = `${BANNER_CLOSED_COOKIE}=${encodeURIComponent(stamp)}; path=/; max-age=31536000; samesite=lax${
              location.protocol === "https:" ? "; secure" : ""
            }`;
            setClosed(true);
          }}
          className="-mr-2 flex size-9 shrink-0 items-center justify-center rounded-full hover:opacity-70"
        >
          <Icon name="x" className="size-4" />
        </button>
      )}
    </div>
  );
}
