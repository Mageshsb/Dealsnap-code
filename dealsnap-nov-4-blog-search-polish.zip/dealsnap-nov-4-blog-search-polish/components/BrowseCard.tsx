import Link from "next/link";
import type { ReactNode } from "react";

// What the three browse pages (/categories, /stores, /brands) share so they
// read as one family: the same card (a logo or icon tile, the name over its
// count, an arrow) and the same A–Z letter heading with its line. They differ
// only in what sits in the tile and what extra goes along the bottom (a store's
// codes and perks), so the pages are still easy to tell apart.

// A–Z section heading: spans the whole grid, with a line under it.
export const LETTER_HEADING = "col-span-full border-b border-zinc-200 pb-1 text-sm font-bold text-zinc-500 dark:border-zinc-800";

export default function BrowseCard({
  href,
  leading,
  name,
  sub,
  muted,
  footer,
  nested,
  phoneArrow = true,
}: {
  href: string;
  leading: ReactNode; // the logo or icon tile (40px, or 36px when nested)
  name: string;
  sub: string; // "31 live deals", under the name
  muted?: boolean; // nothing live: the name and count go quiet
  footer?: ReactNode; // a strip along the bottom (a store's codes and perks); null keeps it blank, left out means no strip
  nested?: boolean; // inside another card (a category's tags): lighter, no shadow
  phoneArrow?: boolean; // two-up lists drop the arrow on phones, where the room goes to the name
}) {
  return (
    <Link
      href={href}
      className={`group flex h-full min-w-0 flex-col overflow-hidden border bg-white transition hover:border-orange-300 dark:bg-zinc-900 dark:hover:border-orange-900 ${
        nested ? "rounded-lg border-zinc-100 dark:border-zinc-800" : "rounded-xl border-zinc-200 shadow-sm hover:shadow-md dark:border-zinc-800"
      }`}
    >
      <span
        className={`flex min-w-0 flex-1 items-center ${
          nested ? "min-h-12 gap-2 px-2 py-1.5" : "min-h-14 gap-2.5 px-2.5 py-2"
        }`}
      >
        {leading}
        <span className="flex min-w-0 flex-1 flex-col">
          {/* Wraps between words only, never mid-word. */}
          <span
            className={`line-clamp-2 font-semibold leading-snug group-hover:text-orange-600 dark:group-hover:text-orange-400 ${
              // The narrow nested cards hyphenate a long one-word name (only
              // with larger text) rather than cut it off.
              nested ? "text-[13px] [overflow-wrap:break-word] hyphens-auto" : "text-sm [overflow-wrap:normal]"
            } ${muted ? "text-zinc-500 dark:text-zinc-500" : ""}`}
          >
            {name}
          </span>
          <span className="truncate text-xs tabular-nums text-zinc-500 dark:text-zinc-400">{sub}</span>
        </span>
        <svg
          aria-hidden
          viewBox="0 0 20 20"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className={`h-4 w-4 shrink-0 text-zinc-300 transition-colors group-hover:text-orange-500 dark:text-zinc-600 ${phoneArrow ? "" : "max-sm:hidden"}`}
        >
          <path d="M7.5 5l5 5-5 5" />
        </svg>
      </span>
      {footer !== undefined && (
        <span className="flex h-8 items-center gap-2 border-t border-zinc-100 bg-zinc-50 px-3 text-xs text-zinc-500 dark:border-zinc-800 dark:bg-zinc-950/40">
          {footer}
        </span>
      )}
    </Link>
  );
}
