import Link from "next/link";
import { Deal } from "@/lib/types";
import { slugify } from "@/lib/slug";
import { formatDate, isEndingSoon, isExpired, timeAgo, timeRemaining } from "@/lib/format";
import { dealPriceTag, priceTagText } from "@/lib/deal-kinds";
import { DealCatches, PriceMain, PriceNote, WasPrice } from "@/components/DealPrice";
import type { CommentSort } from "@/lib/db";
import DealDescription from "@/components/DealDescription";
import VoteButton from "@/components/VoteButton";
import DealThumbnail from "@/components/DealThumbnail";
import CommentSection from "@/components/CommentSection";
import GetDealButton from "@/components/GetDealButton";
import UsernameLink from "@/components/UsernameLink";
import type { Tier } from "@/components/RoleBadge";
import ShareButton from "@/components/ShareButton";
import SaveDealButton from "@/components/SaveDealButton";
import { CommentIcon } from "@/components/icons";
import FeaturedBadge from "@/components/FeaturedBadge";
import HeroRibbon from "@/components/HeroRibbon";
import RelatedDeals from "@/components/RelatedDeals";
import WhereBadge from "@/components/WhereBadge";
import VoucherCode from "@/components/VoucherCode";
import CodeWorked from "@/components/CodeWorked";
import DealTellUsRow from "@/components/DealTellUsRow";
import { deliveryLabel } from "@/lib/deal-extras";
import StickyDealBar from "@/components/StickyDealBar";
import AdUnit from "@/components/AdUnit";
import PriceCheck from "@/components/PriceCheck";
import Icon, { type IconName } from "@/components/Icon";
import DealPoster, { type PosterInfo } from "@/components/DealPoster";
import { STARTS_PILL, StartsText } from "@/components/UpcomingBits";
import { isUpcoming, startsInFull } from "@/lib/upcoming";

// Row order below deliberately mirrors DealCard/SwipeCard (thumbnail → vote
// + status → title → price line → posted-by/comments/share + CTA), so a
// deal looks the same shape whether you're looking at the tile, the swipe
// card, or the full page you land on after tapping either one.
export default function DealDetail({
  deal,
  posterTier,
  posterInfo,
  events = [],
  commentSort,
  checkedAgo,
  codeTrust,
}: {
  deal: Deal;
  posterTier?: Tier;
  // Who posted it, for the About panel (left out for demo posters and closed accounts).
  posterInfo?: PosterInfo;
  // The shopping events on now that this deal is part of.
  events?: { slug: string; name: string; icon: IconName }[];
  commentSort?: CommentSort;
  // "2 days ago": when a helper or the team last looked it over (lib/db.ts deal_checks).
  checkedAgo?: string;
  // What members say about its discount code, and whether this viewer can answer.
  codeTrust?: Omit<React.ComponentProps<typeof CodeWorked>, "code">;
}) {
  const tag = dealPriceTag(deal);
  const endingSoon = isEndingSoon(deal.expiresAt);
  const expired = isExpired(deal.expiresAt);
  const hero = !!deal.hero && !expired;
  const featured = !!deal.featured && !expired && !hero;
  const delivery = deliveryLabel(deal.delivery);
  const upcoming = !expired && isUpcoming(deal);
  // A voucher (the code is the deal) has a dashed violet edge, like a cut-out
  // coupon, in the same footprint as any card. A Featured or Deal of the Day
  // voucher keeps that look's colours, dashed the same way.
  const voucher = deal.kind === "voucher";
  // Trust beside the poster (not on ended deals: nothing left to trust).
  const showTrust = !expired && (!!checkedAgo || (!!codeTrust && !!deal.voucherCode));

  return (
    <div className="flex flex-col gap-5 sm:gap-6">
      {deal.status === "pending" && (
        <div className="rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-800 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-300">
          <Icon name="hourglass" className="mr-1.5" />
          This deal is being reviewed and will be live on the site soon.
        </div>
      )}

      <div
        className={`flex flex-col overflow-hidden rounded-xl bg-white dark:bg-zinc-900 ${
          hero
            ? `hero-card -my-0.5 ${voucher ? "hero-dashed" : ""}`
            : featured
              ? `featured-glow -my-0.5 border-[3px] border-orange-500 ${voucher ? "border-dashed" : ""} bg-gradient-to-br from-orange-50 to-white dark:from-orange-950/30 dark:to-zinc-900`
              : voucher
                ? "-my-px border-2 border-dashed border-violet-400 dark:border-violet-700"
                : "border border-zinc-200 dark:border-zinc-800"
        }`}
      >
        <div className="flex flex-1 flex-col sm:flex-row">
          <div className="relative h-56 w-full shrink-0 sm:h-auto sm:w-56">
            <DealThumbnail deal={deal} iconSize="size-20" sizes="(min-width: 768px) 480px, 100vw" backdrop eager />
            {featured && <FeaturedBadge className="left-3 top-3 px-3 py-1.5 text-xs" />}
            {hero && <HeroRibbon className="py-1.5" />}
            {endingSoon && (
              <div className="absolute right-3 top-3 flex items-center gap-1 rounded-xl bg-red-500 px-2.5 py-1 text-xs font-semibold text-white">
                <Icon name="hourglass" className="size-3.5" />
                {timeRemaining(deal.expiresAt!)}
              </div>
            )}
          </div>

          <div className="flex flex-1 flex-col gap-3 p-5 sm:p-6">
            <div className="flex items-center justify-between gap-2">
              <VoteButton initialHearts={deal.hearts} dealSlug={deal.slug} />
              {expired ? (
                <span className="shrink-0 whitespace-nowrap rounded-full bg-zinc-200 px-2.5 py-1 text-[11px] font-medium text-zinc-600 dark:bg-zinc-700 dark:text-zinc-300">
                  Expired
                </span>
              ) : upcoming && deal.startsAt ? (
                <span title={`Posted ${timeAgo(deal.postedAt)}`} className={`shrink-0 whitespace-nowrap rounded-full px-2.5 py-1 text-[11px] font-medium ${STARTS_PILL}`}>
                  <StartsText startsAt={deal.startsAt} />
                </span>
              ) : (
                <span
                  title={deal.editedAt ? `Edited ${timeAgo(deal.editedAt)}` : undefined}
                  className="shrink-0 whitespace-nowrap rounded-full bg-zinc-100 px-2.5 py-1 text-[11px] font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400"
                >
                  Posted {timeAgo(deal.postedAt)}
                  {deal.editedAt && " · edited"}
                </span>
              )}
            </div>

            <h1 className="text-lg font-bold leading-snug sm:text-xl">{deal.title}</h1>

            <div className="flex flex-wrap items-baseline gap-2">
              <span className="text-xl font-bold text-orange-700 dark:text-orange-400 sm:text-2xl">
                <PriceMain tag={tag} />
              </span>
              <PriceNote tag={tag} className="text-sm" />
              <WasPrice tag={tag} className="text-base text-zinc-500 dark:text-zinc-400" />
              {tag.off && <span className="text-lg font-bold text-green-700 dark:text-green-400">{tag.off}% off</span>}
              <span className="text-sm text-zinc-500 dark:text-zinc-400">
                at{" "}
                <Link
                  href={`/stores/${slugify(deal.store)}`}
                  className="font-semibold text-zinc-700 hover:text-orange-500 hover:underline dark:text-zinc-200"
                >
                  {deal.store}
                </Link>
              </span>
              {delivery && (
                <span className="whitespace-nowrap text-sm text-zinc-500 dark:text-zinc-400">
                  <Icon name="truck" className="mr-1 text-zinc-500 dark:text-zinc-400" />
                  {delivery}
                </span>
              )}
              <WhereBadge where={deal.whereToBuy} note={deal.whereNote} />
              {deal.expiresAt && !expired && !endingSoon && (
                <span className="text-sm text-zinc-500 dark:text-zinc-400">Ends {formatDate(deal.expiresAt)}</span>
              )}
            </div>
            {upcoming && deal.startsAt && (
              <p className="text-sm text-sky-800 dark:text-sky-300">
                <Icon name="calendar" className="mr-1.5" />
                Starts {startsInFull(deal.startsAt)}. Tap <span className="font-semibold">Remind me</span> and we&apos;ll tell you when it&apos;s on.
              </p>
            )}
            {deal.endedByMembers ? (
              <p className="text-sm text-zinc-500">
                <Icon name="hourglass" className="mr-1" />
                {deal.endedByStaff
                  ? "Our team has marked this deal as ended."
                  : deal.endedByPoster
                    ? "The person who posted this says it has ended."
                    : "Members say this deal has ended."}
              </p>
            ) : (
              !!deal.endedReports &&
              !expired && (
                <p className="text-sm text-amber-700 dark:text-amber-400">
                  <Icon name="warning" className="mr-1" />
                  {deal.endedReports} {deal.endedReports === 1 ? "member says" : "members say"} this deal may have
                  ended.
                </p>
              )
            )}
            {deal.whereToBuy === "instore" && (
              <p className="text-sm text-zinc-600 dark:text-zinc-400">
                <Icon name="map-pin" className="mr-1 text-zinc-500 dark:text-zinc-400" />
                {deal.whereNote ?? "In stores only"}
                <span className="text-zinc-500 dark:text-zinc-400"> · Store prices can vary by branch.</span>
              </p>
            )}

            <DealCatches conditions={deal.conditions} cashback={deal.cashback} price={deal.price} />

            <PriceCheck deal={deal} />

            {events.length > 0 && (
              <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-zinc-600 dark:text-zinc-400">
                {events.map((e) => (
                  <Link
                    key={e.slug}
                    href={`/${e.slug}`}
                    className="flex items-center gap-1.5 font-medium hover:underline"
                  >
                    <Icon name={e.icon} className="size-4 text-orange-700 dark:text-orange-400" />
                    Part of {e.name}
                  </Link>
                ))}
              </p>
            )}

            {/* On a price drop the code is part of the price, so it says so; on a
                voucher the code is the deal. */}
            {deal.voucherCode && <VoucherCode code={deal.voucherCode} label={(deal.kind ?? "price") === "price" ? "Price with code" : "Use code"} />}

            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div className="flex min-w-0 flex-1 items-center gap-3">
                {/* Name and picture with just the rank's icon; the rank in words is in the About panel. */}
                {deal.postedByUsername && (
                  <UsernameLink
                    username={deal.postedByUsername}
                    userId={deal.postedByUserId}
                    avatarUrl={deal.postedByAvatarUrl}
                    tier={posterTier}
                    badge="icon"
                    className="flex min-w-0 shrink items-center gap-1.5 text-sm text-zinc-500"
                  />
                )}
                <a
                  href="#comments"
                  aria-label={`${deal.commentCount} comment${deal.commentCount === 1 ? "" : "s"}`}
                  className="flex shrink-0 items-center gap-1 text-xs text-zinc-500 dark:text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300"
                >
                  <CommentIcon className="h-[18px] w-[18px]" />
                  {deal.commentCount}
                </a>
                <ShareButton url={`/deals/${deal.slug}`} title={deal.title} />
              </div>
              {/* Save beside Get deal (a wishlist-and-buy pair). On phones the
                  pair gets its own line, with Get deal taking the most room. */}
              <div className="flex items-center gap-2 max-sm:w-full">
                <SaveDealButton dealSlug={deal.slug} variant="pill" remind={upcoming} />
                <GetDealButton
                  id="deal-cta"
                  slug={deal.slug}
                  store={deal.store}
                  code={deal.voucherCode}
                  voucher={voucher}
                  upcoming={upcoming}
                  long
                  className="flex shrink-0 items-center justify-center rounded-full px-5 py-2 text-center text-sm font-semibold max-sm:flex-1"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-2 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900 sm:p-6">
        {/* Who posted it, and beside it (underneath on phones) why to trust it:
            checked by helpers, and whether its code works. Kept out of the
            deal card above so that stays the same shape as on lists. */}
        {(posterInfo || showTrust) && (
          <div className="flex flex-col gap-3 border-b border-zinc-100 pb-3 sm:flex-row sm:items-center sm:justify-between sm:gap-6 dark:border-zinc-800">
            {posterInfo && <DealPoster info={posterInfo} tier={posterTier} />}
            {showTrust && (
              <div className="flex min-w-0 flex-col gap-1.5 sm:items-end sm:text-right">
                {checkedAgo && (
                  <p className="flex items-center gap-1.5 text-xs text-green-700 sm:text-sm dark:text-green-400">
                    <Icon name="badge-check" className="size-4 shrink-0" />
                    Checked by DealSnap helpers {checkedAgo}
                  </p>
                )}
                {codeTrust && deal.voucherCode && <CodeWorked {...codeTrust} code={deal.voucherCode} />}
              </div>
            )}
          </div>
        )}
        <h2 className="mt-1 text-lg font-bold">About this deal</h2>
        <DealDescription slug={deal.slug} dealId={deal.id} description={deal.description} />
        {deal.brand && (
          <p className="text-sm text-zinc-500 dark:text-zinc-400">
            Made by{" "}
            <Link href={`/brands/${slugify(deal.brand)}`} className="font-semibold text-zinc-700 hover:text-orange-500 hover:underline dark:text-zinc-200">
              {deal.brand}
            </Link>
          </p>
        )}
        {/* The two quiet "tell us" links, side by side at the right. */}
        <DealTellUsRow deal={deal} />
      </div>

      {/* Admin → Ads (nothing unless the page has an ad for these spaces). */}
      <AdUnit slot="deal" />

      {/* Comments before related deals: they're where the community adds the
          useful bits ("cheaper at Argos", "code didn't work for me"). */}
      <CommentSection dealSlug={deal.slug} posterId={deal.postedByUserId} pending={deal.status === "pending"} sort={commentSort} />

      <AdUnit slot="deal-end" />

      <RelatedDeals deal={deal} />

      {!expired && (
        <StickyDealBar slug={deal.slug} title={deal.title} price={priceTagText(tag)} was={tag.was} wasRrp={tag.wasRrp} ctaId="deal-cta" upcoming={upcoming} store={deal.store} code={deal.voucherCode} voucher={voucher} />
      )}
    </div>
  );
}
