import { getVoteStrengthFacts } from "@/lib/db";
import { BASE_HEART_WEIGHT, MAX_HEART_WEIGHT, heartWeight, voteSteps } from "@/lib/votes";
import Icon, { HeartIcon } from "./Icon";

// On your own profile, under the stats: what one tap of the heart is worth, and the
// steps that make it worth more, so the 4–7 scale feels fair rather than
// hidden. A quiet one-line strip that opens to show the steps, and says
// plainly that nobody else sees it (the rest of the card is public).
export default function VoteStrengthCard({ userId }: { userId: string }) {
  const facts = getVoteStrengthFacts(userId);
  const weight = heartWeight(facts);
  const steps = voteSteps(facts);
  const next = steps.find((s) => !s.done);

  return (
    <details className="group rounded-xl border border-zinc-200 bg-zinc-50 text-sm dark:border-zinc-800 dark:bg-zinc-800/40">
      <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-3 py-2 [&::-webkit-details-marker]:hidden">
        <span className="flex min-w-0 flex-col">
          <span className="font-medium">
            <HeartIcon className="mr-1.5" />
            Your heart is worth{" "}
            <span className="font-semibold text-orange-700 dark:text-orange-400">{weight}</span>
          </span>
          <span className="text-xs text-zinc-500">
            <Icon name="lock" className="mr-1" />
            Only you can see this
          </span>
        </span>
        {/* Styled like the sort picker's button. Both words share one spot
            (sized to the longer), so the arrow never moves, only flips. */}
        <span className="flex shrink-0 items-center gap-1.5 rounded-xl bg-zinc-100 px-2.5 py-1.5 text-xs font-medium text-zinc-600 transition-colors group-open:bg-zinc-200 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:group-open:bg-zinc-700 dark:hover:bg-zinc-700">
          <span className="grid justify-items-end whitespace-nowrap">
            <span className="col-start-1 row-start-1 group-open:invisible">How it works</span>
            <span className="invisible col-start-1 row-start-1 group-open:visible">Hide</span>
          </span>
          <svg aria-hidden viewBox="0 0 12 12" className="h-3 w-3 text-zinc-500 dark:text-zinc-400 transition-transform group-open:rotate-180" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 4.5 6 7.5 9 4.5" />
          </svg>
        </span>
      </summary>
      <div className="flex flex-col gap-2 border-t border-zinc-200 px-3 pb-3 pt-2 dark:border-zinc-800">
        <ul className="flex flex-col gap-1">
          {steps.map((s) => (
            <li key={s.label} className="flex items-center justify-between gap-3">
              <span className={`flex items-center gap-1.5 ${s.done ? "text-zinc-800 dark:text-zinc-200" : "text-zinc-500"}`}>
                <Icon
                  name={s.done ? "circle-check" : "circle"}
                  className={`size-4 ${s.done ? "text-green-700 dark:text-green-400" : "text-zinc-300 dark:text-zinc-600"}`}
                />
                {s.label}
                <span className="sr-only">{s.done ? " (done)" : " (not yet)"}</span>
              </span>
              <span className="shrink-0 text-xs text-zinc-500">{s.done ? "+1" : s.progress}</span>
            </li>
          ))}
        </ul>
        <p className="text-xs text-zinc-500">
          Every member&apos;s heart is worth {BASE_HEART_WEIGHT} to {MAX_HEART_WEIGHT}: everyone starts at{" "}
          {BASE_HEART_WEIGHT}, and each step adds 1.{" "}
          {next
            ? `Next: ${next.next} to make it ${weight + 1}.`
            : "That's the most a heart can be worth. Thanks for being part of DealSnap!"}
        </p>
      </div>
    </details>
  );
}
