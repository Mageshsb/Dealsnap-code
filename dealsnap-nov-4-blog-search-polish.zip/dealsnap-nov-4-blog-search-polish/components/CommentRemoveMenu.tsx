"use client";

import { useState, useTransition } from "react";
import { removeCommentAction } from "@/lib/actions";
import MoreMenu, { moreMenuItem } from "./MoreMenu";
import Icon from "./Icon";

// The "⋯" a moderator or admin gets on a comment they look after (someone of
// lower rank's): Remove, asked once more inside the menu. The comment then
// gives way to "Removed by our team", or goes completely when it had no
// replies. The same removal as in the admin area, and logged the same way.
export default function CommentRemoveMenu({ commentId }: { commentId: string }) {
  const [asking, setAsking] = useState(false);
  const [failed, setFailed] = useState(false);
  const [pending, startTransition] = useTransition();

  function remove(close: () => void) {
    setFailed(false);
    startTransition(async () => {
      if (await removeCommentAction(commentId)) close();
      else setFailed(true);
    });
  }

  return (
    <MoreMenu
      label="Comment options"
      onOpen={() => {
        setAsking(false);
        setFailed(false);
      }}
    >
      {(close) =>
        asking ? (
          <div className="flex flex-col gap-2 px-4 py-2.5">
            <p className="text-sm font-semibold">Remove this comment?</p>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              {failed ? "That didn't work. It may already have gone." : "Replies to it stay. It's logged under your name."}
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => remove(close)}
                disabled={pending}
                className="rounded-full bg-red-600 px-3 py-1 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-60"
              >
                {pending ? "Removing…" : "Remove"}
              </button>
              <button
                type="button"
                onClick={() => setAsking(false)}
                className="rounded-full px-3 py-1 text-sm text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <button
            type="button"
            role="menuitem"
            onClick={() => setAsking(true)}
            className={`${moreMenuItem} !text-red-600 dark:!text-red-400`}
          >
            <Icon name="trash" className="size-4" />
            Remove comment
          </button>
        )
      }
    </MoreMenu>
  );
}
