import type { WhereToBuy } from "@/lib/where-to-buy";
import Icon from "./Icon";

// "In-store only" (with a shop icon) next to the store name. Nothing for online deals.
export default function WhereBadge({ where, note }: { where?: WhereToBuy; note?: string }) {
  if (where !== "instore") return null;
  return (
    <span
      title={note}
      className="inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded-full bg-blue-100 px-2 py-0.5 text-[11px] font-medium text-blue-700 dark:bg-blue-950/40 dark:text-blue-400"
    >
      <Icon name="store" className="size-3" />
      In-store only
    </span>
  );
}
