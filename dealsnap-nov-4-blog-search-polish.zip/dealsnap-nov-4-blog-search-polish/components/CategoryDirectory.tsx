"use client";

import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { ClearSearch, searchBox } from "@/components/SearchBox";
import Icon, { type IconName } from "./Icon";
import BrowseCard from "./BrowseCard";
import { EmptyToggle } from "./BrowseFilters";
import ScrollUpBand from "./ScrollUpBand";
import { NAME_SEARCH_MAX } from "@/lib/search-limits";

export type DirectoryCategory = {
  name: string;
  slug: string;
  icon: IconName;
  tile: string; // category-theme classes for the icon tile
  iconColour: string;
  count: number; // live deals
  tags: DirectoryTag[];
};

type DirectoryTag = { name: string; slug: string; icon: IconName; count: number };

// Names compared without case, spaces or punctuation, with & read as "and"
// (same as the store search), so "kids", "women's" and "food & drink" all match.
const squash = (text: string) => text.toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]/g, "");

// The list on /categories: one full-width card per category, stacked. The top
// is styled like a store card from /stores (icon, name, live deals,
// arrow), followed by its tags as tiles, each with its live-deal count so
// shoppers can see where the deals are (sub-tags like iPhone sit right after
// their tag). A search narrows the tags as you type and, like /stores, lives in
// the address (?q) so Back keeps it.
export default function CategoryDirectory({ categories }: { categories: DirectoryCategory[] }) {
  const params = useSearchParams();
  const [query, setQuery] = useState((params.get("q") ?? "").slice(0, NAME_SEARCH_MAX));
  const liveOnly = params.get("live") === "1";
  const controlsRef = useRef<HTMLDivElement>(null);

  // The search box updates the address a moment after typing stops.
  useEffect(() => {
    const t = setTimeout(() => {
      const next = new URLSearchParams(window.location.search);
      if (query.trim()) next.set("q", query.trim());
      else next.delete("q");
      const qs = next.toString();
      window.history.replaceState(null, "", qs ? `?${qs}` : window.location.pathname);
    }, 300);
    return () => clearTimeout(t);
  }, [query]);

  const q = squash(query);
  // A tag matches if its name contains what's typed, or what's typed contains
  // the tag's name ("headphones", "tvs", "kids clothes"). A matching category
  // keeps all its tags.
  const matches = (name: string) => {
    const n = squash(name);
    return n.includes(q) || (q.length >= 2 && q.includes(n));
  };
  const searched = q
    ? categories
        .map((c) => (matches(c.name) ? c : { ...c, tags: c.tags.filter((t) => matches(t.name)) }))
        .filter((c) => matches(c.name) || c.tags.length > 0)
    : categories;
  // Hide empty: tags with nothing live go, and so does a category with none left.
  const shown = liveOnly
    ? searched.map((c) => ({ ...c, tags: c.tags.filter((t) => t.count > 0) })).filter((c) => c.tags.length > 0)
    : searched;

  // Swap the address without a page load (Next keeps useSearchParams in step).
  function setLive(on: boolean) {
    const next = new URLSearchParams(window.location.search);
    if (on) next.set("live", "1");
    else next.delete("live");
    const qs = next.toString();
    window.history.replaceState(null, "", qs ? `?${qs}` : window.location.pathname);
  }

  // The search row is drawn twice: in the page, and again in the band that
  // slides down when you scroll back up (ScrollUpBand). Both share the same
  // state, so they always agree. The search has the hide-empty button right
  // after it (beside it on phones too).
  const searchRow = (
      <div className="flex w-full min-w-0 items-center gap-2 sm:max-w-md">
      {/* Same box and clear (x) button as the store search. */}
      <div className="relative min-w-0 flex-1">
        <input
          type="search"
          enterKeyHint="search"
          value={query}
          maxLength={NAME_SEARCH_MAX}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()}
          placeholder="Search, e.g. TV or iPhone"
          aria-label="Search categories and tags"
          className={searchBox}
        />
          {query && <ClearSearch onClick={() => setQuery("")} />}
      </div>
      <EmptyToggle on={liveOnly} onToggle={() => setLive(!liveOnly)} />
      </div>
  );

  return (
    <div className="flex flex-col gap-4">
      <div ref={controlsRef}>{searchRow}</div>
      <ScrollUpBand after={controlsRef}>{searchRow}</ScrollUpBand>

      {shown.length === 0 ? (
        <div className="flex flex-col items-center gap-2 py-10 text-center text-zinc-500">
          <p>{q ? <>No categories or tags match &ldquo;{query.trim()}&rdquo;.</> : "Nothing live right now."}</p>
          {/* Probably a product name, so offer the deal search. */}
          {q && (
            <Link href={`/?q=${encodeURIComponent(query.trim())}`} className="text-sm font-medium text-orange-700 hover:underline dark:text-orange-400">
              Search all deals for &ldquo;{query.trim()}&rdquo; ›
            </Link>
          )}
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {shown.map((c) => (
            <section
              key={c.slug}
              className="overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900"
            >
              {/* The top of a store card from /stores: icon, name, live deals,
                  arrow. It opens the whole category. */}
              <h2>
                <Link
                  href={`/categories/${c.slug}`}
                  className="group flex items-center gap-3 border-b border-zinc-100 bg-zinc-50 px-3 py-2.5 transition-colors hover:bg-zinc-100 dark:border-zinc-800 dark:bg-zinc-950/40 dark:hover:bg-zinc-800/60"
                >
                  <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${c.tile}`}>
                    <Icon name={c.icon} className={`size-5 ${c.iconColour}`} />
                  </span>
                  <span className="flex min-w-0 flex-1 flex-col gap-1">
                    <span className="font-semibold leading-snug group-hover:text-orange-600 dark:group-hover:text-orange-400">{c.name}</span>
                    <span className="text-xs font-normal text-zinc-500">
                      {c.count > 0 ? `${c.count} live deal${c.count === 1 ? "" : "s"}` : "No live deals"}
                    </span>
                  </span>
                  <svg aria-hidden viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 shrink-0 text-zinc-300 transition-colors group-hover:text-orange-500 dark:text-zinc-600">
                    <path d="M7.5 5l5 5-5 5" />
                  </svg>
                </Link>
              </h2>
              {/* Its tags as the same cards as stores and brands, the icon tile in
                  the category's colour, each with its live-deal count. More tags
                  just add a row. */}
              <ul className="grid grid-cols-2 gap-1.5 p-2 sm:grid-cols-3 sm:gap-2.5 sm:p-3 lg:grid-cols-4">
                {c.tags.map((t) => (
                  <li key={t.slug} className="min-w-0">
                    <BrowseCard
                      nested
                      href={`/tags/${t.slug}`}
                      leading={
                        <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${c.tile} ${c.iconColour} ${t.count ? "" : "opacity-50"}`}>
                          <Icon name={t.icon} className="size-[18px]" />
                        </span>
                      }
                      name={t.name}
                      /* Tags with nothing on right now stay listed (their page
                         can still alert you), just quieter. */
                      sub={t.count ? `${t.count} deal${t.count === 1 ? "" : "s"}` : "None right now"}
                      muted={!t.count}
                      phoneArrow={false}
                    />
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
