import type { Impact } from "@/lib/staff-impact";
import type { UserRole } from "@/lib/db";

// The numbers for one person and one time block, with all time beneath each.
// Helpers only do the first three things; moderators and admins do more.
export default function ImpactTiles({ recent, allTime, role, more }: { recent: Impact; allTime: Impact; role: UserRole; more?: { edits: number; perDeal: number | null } }) {
  const senior = role !== "helper";
  const tiles: { label: string; value: number; all: number }[] = [
    { label: "Deals improved", value: recent.improved, all: allTime.improved },
    { label: "Deals marked ended", value: recent.ended, all: allTime.ended },
    ...(senior
      ? [
          { label: "Deals reviewed", value: recent.reviewed, all: allTime.reviewed },
          { label: "Comments handled", value: recent.comments, all: allTime.comments },
          { label: "Sent to admins", value: recent.escalated, all: allTime.escalated },
        ]
      : []),
  ];
  const box = "rounded-xl bg-zinc-50 p-3 dark:bg-zinc-800/60";
  return (
    <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3">
      {tiles.map((t) => (
        <li key={t.label} className={box}>
          <p className="text-2xl font-bold tabular-nums">{t.value}</p>
          <p className="text-sm text-zinc-700 dark:text-zinc-300">{t.label}</p>
          <p className="text-xs text-zinc-500">{t.all} all time</p>
        </li>
      ))}
      <li className={box}>
        <p className="text-2xl font-bold tabular-nums">{recent.kept === null ? "–" : `${recent.kept}%`}</p>
        <p className="text-sm text-zinc-700 dark:text-zinc-300">Fixes that stood</p>
        <p className="text-xs text-zinc-500">{allTime.kept === null ? "Shows after 5 fixes" : `${allTime.kept}% all time`}</p>
      </li>
      {more && (
        <li className={box}>
          <p className="text-2xl font-bold tabular-nums">{more.perDeal ?? "–"}</p>
          <p className="text-sm text-zinc-700 dark:text-zinc-300">Edits per deal</p>
          <p className="text-xs text-zinc-500">{more.edits} edits in all</p>
        </li>
      )}
    </ul>
  );
}
