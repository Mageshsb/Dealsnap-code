import Link from "next/link";

// The row of time blocks (24 hours, 7 days…) on the staff pages. Plain links,
// so each choice is an address you can share or come back to. On a narrow
// phone it wraps onto a second line so every choice stays in view.
export default function RangeSwitch({
  ranges,
  current,
  href,
}: {
  ranges: readonly { key: string; label: string }[];
  current: string;
  href: (key: string) => string;
}) {
  return (
    <div className="flex max-w-full flex-wrap gap-1 rounded-lg border border-zinc-300 p-0.5 dark:border-zinc-700">
      {ranges.map((r) => (
        <Link
          key={r.key}
          href={href(r.key)}
          scroll={false}
          aria-current={r.key === current ? "true" : undefined}
          className={`whitespace-nowrap rounded-md px-2.5 py-1.5 text-sm font-medium sm:px-3 ${
            r.key === current
              ? "bg-orange-100 text-orange-700 dark:bg-orange-950/50 dark:text-orange-400"
              : "text-zinc-600 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-800"
          }`}
        >
          {r.label}
        </Link>
      ))}
    </div>
  );
}
