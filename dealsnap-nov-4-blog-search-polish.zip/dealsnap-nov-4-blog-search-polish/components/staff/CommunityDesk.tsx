import Link from "next/link";
import type { ReportedPost, WaitingThread } from "@/lib/community-db";
import { deskHidePostAction, deskSnoozePostAction } from "@/lib/helper-actions";
import { pageOfSeq } from "@/lib/community-rules";
import { SNOOZE_DAYS } from "@/lib/helper-desk";
import { timeAgo } from "@/lib/format";
import EmptyState from "@/components/EmptyState";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import Icon from "@/components/Icon";

const outline =
  "inline-flex min-h-10 items-center justify-center gap-1.5 rounded-full border border-zinc-300 px-4 text-sm font-semibold text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800";
const primary =
  "inline-flex min-h-10 items-center justify-center gap-1.5 rounded-full bg-orange-500 px-4 text-sm font-semibold text-white hover:bg-orange-600";
const card = "flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900";

const postHref = (slug: string, seq: number) => `/community/t/${slug}${pageOfSeq(seq) > 1 ? `?page=${pageOfSeq(seq)}` : ""}#post-${seq}`;

// The Community half of the helper desk: replies members have reported (to read,
// then hide for a moderator to check, or pass as fine) and new threads nobody has
// answered yet (where a friendly reply counts most). A helper only ever sees what
// they could already do from the thread itself: hide a reply by someone below them.
export default function CommunityDesk({ tab, reported, waiting }: { tab: "reports" | "welcome"; reported: ReportedPost[]; waiting: WaitingThread[] }) {
  if (tab === "reports") {
    if (!reported.length) return <EmptyState icon="circle-check">Nothing reported right now. Nicely done.</EmptyState>;
    return (
      <ul className="flex flex-col gap-3">
        {reported.map((p) => (
          <li key={p.postId} className={card}>
            <div className="flex min-w-0 flex-col gap-0.5">
              <Link href={postHref(p.threadSlug, p.seq)} className="line-clamp-2 font-semibold leading-snug hover:text-orange-600">
                {p.threadTitle}
              </Link>
              <p className="truncate text-xs text-zinc-500 dark:text-zinc-400">
                {p.spaceName} · {p.seq === 1 ? "opening post" : `reply #${p.seq}`} by {p.username} · {timeAgo(p.createdAt)}
              </p>
            </div>
            <div className="flex flex-col gap-1.5 rounded-lg border border-red-300 bg-red-50 p-3 dark:border-red-800 dark:bg-red-950/30">
              <p className="flex items-center gap-1.5 text-sm font-semibold text-red-800 dark:text-red-300">
                <Icon name="flag" className="size-4 shrink-0" />
                Reported by {p.reports} {p.reports === 1 ? "member" : "members"}
              </p>
              <p className="line-clamp-4 whitespace-pre-line text-sm text-zinc-700 [overflow-wrap:anywhere] dark:text-zinc-300">&ldquo;{p.snippet}&rdquo;</p>
              <p className="text-sm text-zinc-600 dark:text-zinc-400">
                {p.seq === 1
                  ? "This is an opening post, so a moderator decides on it. Read it in the thread, or tap Looks fine."
                  : "Read it in the thread. If it breaks the rules, hide it and a moderator will check it. If it's fine, tap Looks fine."}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Link href={postHref(p.threadSlug, p.seq)} className={outline}>
                Open the post
              </Link>
              {p.seq > 1 && (
                <form action={deskHidePostAction}>
                  <input type="hidden" name="post" value={p.postId} />
                  <ConfirmSubmitButton confirmText="Hide this reply? It shows as “hidden while the team checks it”, and a moderator decides what happens next." confirmLabel="Hide it" className={primary}>
                    <Icon name="eye-off" className="size-4" />
                    Hide it
                  </ConfirmSubmitButton>
                </form>
              )}
              <form action={deskSnoozePostAction}>
                <input type="hidden" name="post" value={p.postId} />
                <button type="submit" className={outline} title={`Hides it from your desk for ${SNOOZE_DAYS} days, unless it's reported again`}>
                  Looks fine
                </button>
              </form>
            </div>
          </li>
        ))}
      </ul>
    );
  }

  if (!waiting.length) return <EmptyState icon="circle-check">Every recent thread has had a reply. Nicely done.</EmptyState>;
  return (
    <>
      <p className="flex gap-2 rounded-xl bg-zinc-100 px-4 py-3 text-sm text-zinc-600 dark:bg-zinc-800/60 dark:text-zinc-300">
        <Icon name="lightbulb" className="mt-0.5 size-4 shrink-0 text-amber-500" />
        New threads from the last two weeks that nobody has answered. A friendly reply, or an answer if you know it, is what makes someone come back.
      </p>
      <ul className="flex flex-col gap-3">
        {waiting.map((t) => (
          <li key={t.slug} className={card}>
            <div className="flex min-w-0 flex-col gap-0.5">
              <Link href={`/community/t/${t.slug}`} className="line-clamp-2 font-semibold leading-snug hover:text-orange-600">
                {t.title}
              </Link>
              <p className="truncate text-xs text-zinc-500 dark:text-zinc-400">
                {t.spaceName} · started by {t.username} · {timeAgo(t.createdAt)}
              </p>
              {t.snippet && <p className="line-clamp-2 whitespace-pre-line pt-1 text-sm text-zinc-600 [overflow-wrap:anywhere] dark:text-zinc-400">{t.snippet}</p>}
            </div>
            <div>
              <Link href={`/community/t/${t.slug}`} className={primary}>
                <Icon name="reply" className="size-4" />
                Open and reply
              </Link>
            </div>
          </li>
        ))}
      </ul>
    </>
  );
}
