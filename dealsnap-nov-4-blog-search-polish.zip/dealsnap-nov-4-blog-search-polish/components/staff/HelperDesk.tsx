import Link from "next/link";
import type { UserRecord } from "@/lib/db";
import { FIX_KINDS, KINDS, KIND_LOOK, SNOOZE_DAYS, buildDeskItems, type Item, type Kind } from "@/lib/helper-desk";
import { getAdminDealsView, getDealBySlug } from "@/lib/mock-deals";
import { getDealReportReasons, getRecentCodeComplaints, getDealsBeingFixed, getDeskSnoozes, getOthersDeskChecks, recentOtherActions } from "@/lib/db";
import { seenNow } from "@/lib/collisions";
import { helperEndDealAction, snoozeDeskDealAction, unsnoozeDeskDealAction } from "@/lib/helper-actions";
import { timeAgo } from "@/lib/format";
import { dealPriceTag, filedAs, priceTagText } from "@/lib/deal-kinds";
import { getCategoryGroups } from "@/lib/categories";
import { SEARCH_MAX } from "@/lib/search-limits";
import { getImpact, rangeStart } from "@/lib/staff-impact";
import { can } from "@/lib/permissions";
import { mayAct } from "@/lib/community-access";
import { getCommunitySettings, getPostSnoozes, getReportedLivePosts, getThreadsWaitingForReply } from "@/lib/community-db";
import CommunityDesk from "@/components/staff/CommunityDesk";
import { AccountPageHeader } from "@/components/AccountShell";
import EmptyState from "@/components/EmptyState";
import SelectField from "@/components/SelectField";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";
import DealThumbnail from "@/components/DealThumbnail";
import Icon from "@/components/Icon";
import StaffImpact from "@/components/staff/StaffImpact";
import ClashNotice from "@/components/admin/ClashNotice";
import Pager from "@/components/admin/Pager";
import { searchField } from "@/components/admin/formStyles";

const PAGE_SIZE = 15;

const SORTS = {
  priority: "Most urgent",
  newest: "Newest first",
  oldest: "Oldest first",
  store: "Store A to Z",
} as const;
type SortKey = keyof typeof SORTS;

const outline =
  "inline-flex min-h-10 items-center justify-center gap-1.5 rounded-full border border-zinc-300 px-4 text-sm font-semibold text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800";
const primary =
  "inline-flex min-h-10 items-center justify-center gap-1.5 rounded-full bg-orange-500 px-4 text-sm font-semibold text-white hover:bg-orange-600";

const TONE = {
  red: { box: "border-red-400 bg-red-50 dark:border-red-700 dark:bg-red-950/30", icon: "text-red-600 dark:text-red-400" },
  amber: { box: "border-amber-400 bg-amber-50 dark:border-amber-700 dark:bg-amber-950/30", icon: "text-amber-600 dark:text-amber-400" },
  sky: { box: "border-sky-400 bg-sky-50 dark:border-sky-700 dark:bg-sky-950/30", icon: "text-sky-600 dark:text-sky-400" },
  zinc: { box: "border-zinc-300 bg-zinc-50 dark:border-zinc-600 dark:bg-zinc-800/50", icon: "text-zinc-500 dark:text-zinc-400" },
} as const;

// A tip for the reason being looked at, shown once above the list rather
// than on every card.
const TAB_TIPS: Partial<Record<Kind, string>> = {
  photo:
    "Some stores turn our reader away. If “Fill in the gaps from the link” finds nothing, open the deal's link with the DealSnap extension and tap Post this deal to read it.",
  ended: "Open the deal and tap Get deal to see it at the store. Members can be wrong, so check before marking it ended.",
  soon: "Deals often end early. A quick look at the store keeps the site honest.",
};

// One deal to look at: what it is (photo, price, store), then each reason
// it's here as a coloured box saying what's wrong and what to do, then the
// buttons for exactly those jobs.
// What someone else is doing or did about a deal: fixing it right now
// (amber: probably leave it), or fixed or checked it lately (grey).
type Others = { now: boolean; text: string };

function DeskCard({ item, back, hidden, seen, others }: { item: Item; back: string; hidden: boolean; seen: string; others?: Others }) {
  const { deal, tasks } = item;
  // Opening the deal keeps the way back here (the deal page's "Back" says so).
  const dealHref = `/deals/${deal.slug}?from=helper${back ? `&hq=${encodeURIComponent(back)}` : ""}`;
  const fixHref = `/deals/${deal.slug}/edit?from=helper${back ? `&hq=${encodeURIComponent(back)}` : ""}`;
  // Marking ended is for deals that might be over, not ones that only need tidying.
  const endable = tasks.some((t) => t.kind === "flagged" || t.kind === "ended" || t.kind === "soon" || t.kind === "code");
  const fixable = deal.source === "user";
  // The top job decides which button leads: a fix, or (when the question is
  // "is it still on?") neither, as that needs a look at the store first.
  const fixFirst = fixable && FIX_KINDS.includes(tasks[0].kind);
  const price = priceTagText(dealPriceTag(deal));

  return (
    <li className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
      <div className="flex gap-3">
        <Link href={dealHref} className="size-16 shrink-0 overflow-hidden rounded-lg" tabIndex={-1} aria-hidden>
          <DealThumbnail deal={deal} sizes="64px" iconSize="size-6" />
        </Link>
        <div className="flex min-w-0 flex-1 flex-col gap-0.5">
          <Link href={dealHref} className="line-clamp-2 font-semibold leading-snug hover:text-orange-600">
            {deal.title}
          </Link>
          <p className="text-sm text-zinc-500">
            <span className="font-semibold text-orange-700 dark:text-orange-400">{price}</span> · {deal.store}
          </p>
          <p className="truncate text-xs text-zinc-500 dark:text-zinc-400">
            {filedAs(deal)}
            {deal.brand && ` · ${deal.brand}`} · posted {timeAgo(deal.postedAt)} by {deal.postedByUsername ?? "someone"}
          </p>
        </div>
      </div>

      {others && (
        <p
          className={`flex items-center gap-1.5 text-sm ${
            others.now ? "font-medium text-amber-800 dark:text-amber-300" : "text-zinc-500"
          }`}
        >
          <Icon name="users" className="size-4 shrink-0" />
          {others.text}
        </p>
      )}

      <ul className="flex flex-col gap-2">
        {tasks.map((t) => {
          const look = KIND_LOOK[t.kind];
          return (
            <li key={t.kind} className={`flex gap-2.5 rounded-lg border-l-4 px-3 py-2 ${TONE[look.tone].box}`}>
              <Icon name={look.icon} className={`mt-0.5 size-4 shrink-0 ${TONE[look.tone].icon}`} />
              <span className="flex min-w-0 flex-col">
                <span className="text-sm font-semibold break-words">{t.what}</span>
                <span className="text-sm text-zinc-600 dark:text-zinc-300">{t.todo}</span>
              </span>
            </li>
          );
        })}
      </ul>

      <div className="flex flex-wrap items-center gap-2">
        {fixable && !hidden && (
          <Link href={fixHref} className={fixFirst ? primary : outline}>
            <Icon name="pencil" className="size-4" />
            Fix details
          </Link>
        )}
        {endable && !hidden && (
          <form action={helperEndDealAction}>
            <input type="hidden" name="slug" value={deal.slug} />
            <input type="hidden" name="back" value={back} />
            <input type="hidden" name="seen" value={seen} />
            <ConfirmSubmitButton confirmText={`Mark "${deal.title}" as ended? A moderator can undo this.`} className={outline}>
              <Icon name="hourglass" className="size-4" />
              Mark ended
            </ConfirmSubmitButton>
          </form>
        )}
        <form action={hidden ? unsnoozeDeskDealAction : snoozeDeskDealAction} className="ml-auto">
          <input type="hidden" name="slug" value={deal.slug} />
          <input type="hidden" name="back" value={back} />
          <input type="hidden" name="seen" value={seen} />
          <button
            type="submit"
            className="inline-flex min-h-10 items-center gap-1.5 rounded-full px-3 text-sm font-medium text-zinc-500 hover:bg-zinc-100 hover:text-zinc-800 dark:hover:bg-zinc-800 dark:hover:text-zinc-200"
          >
            <Icon name={hidden ? "eye" : "check"} className="size-4" />
            {hidden ? "Show again" : "All good"}
          </button>
        </form>
      </div>
    </li>
  );
}

// The helper's to-do list: live deals that could do with a hand (flagged by
// members, maybe over, ending soon, thin on detail, no photo, labels in
// doubt), most urgent first, each saying exactly what to do. Filter by why,
// or (behind Filters) by category, words or order. Opening or fixing a deal
// comes back to the same view; each action says what it did. It only ever
// offers what a helper can already do from a deal's page (fix details, mark
// ended), shows no names of who reported, and never opens /admin.
export type DeskParams = { impact?: string; tab?: string; q?: string; sort?: string; category?: string; page?: string; done?: string; deal?: string; saved?: string; clash?: string };

// Helpers open it in My account (/helper); moderators and admins inside the
// admin area (/admin/helper), so `base` is where its own links go.
export default function HelperDesk({ sp, user, base }: { sp: DeskParams; user: UserRecord; base: "/helper" | "/admin/helper" }) {
  // The Community half (reported posts, threads waiting for a reply) is for anyone with the helper Community powers.
  const community = can(user.role, "forum.tidy") && getCommunitySettings().on;
  const tab: Kind | "all" | "hidden" | "reports" | "welcome" =
    community && (sp.tab === "reports" || sp.tab === "welcome") ? sp.tab : sp.tab === "hidden" ? "hidden" : sp.tab && sp.tab in KINDS ? (sp.tab as Kind) : "all";
  const sort: SortKey = sp.sort && sp.sort in SORTS ? (sp.sort as SortKey) : "priority";
  const category = getCategoryGroups().some((g) => g.name === sp.category) ? (sp.category as string) : "all";
  const q = (sp.q ?? "").trim().slice(0, SEARCH_MAX);
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);

  const items = buildDeskItems(user, getAdminDealsView(), getDealReportReasons(), getRecentCodeComplaints());

  // Community: replies members reported that this person may act on (never their own, nor someone
  // above them), minus the ones they've passed as fine since (until reported again); and new
  // threads nobody has answered.
  const passed = community ? getPostSnoozes(user.id) : new Map<string, number>();
  const reportedPosts = community
    ? getReportedLivePosts().filter((p) => p.userId !== user.id && mayAct(user, { userId: p.userId, role: p.role }) && passed.get(p.postId) !== p.reports)
    : [];
  const waitingThreads = community ? getThreadsWaitingForReply(user.id) : [];

  // "All good" hides a deal from this person only, until something new comes up on it.
  const snoozed = getDeskSnoozes(user.id);
  const isHidden = (i: Item) => snoozed.get(i.deal.slug)?.sig === i.sig;
  const visible = items.filter((i) => !isHidden(i));
  const hiddenItems = items.filter(isHidden);

  // Everyone else's part, so two people don't do the same deal: who has it
  // open to fix right now, who fixed it in the last day, and who said it's
  // all good (for what's on it now). Three small lookups for the whole desk.
  const seen = seenNow();
  const fixing = getDealsBeingFixed(user.id);
  const recent = recentOtherActions(new Date(Date.parse(seen) - 24 * 60 * 60 * 1000).toISOString(), user.id, ["deal.edit", "deal.labels", "deal.unended"]);
  const checks = new Map<string, { username: string; until: string; sig: string }>();
  for (const c of getOthersDeskChecks(user.id)) if (!checks.has(c.slug)) checks.set(c.slug, c);
  const othersOn = (i: Item): Others | undefined => {
    const f = fixing.get(i.deal.slug);
    if (f) return { now: true, text: `${f.username} is fixing this right now (opened ${timeAgo(f.at)})` };
    const r = recent.get(i.deal.slug);
    if (r) return { now: false, text: `${r.username} ${r.action === "deal.labels" ? "checked its labels" : r.action === "deal.unended" ? "said it's still on" : "fixed it"} ${timeAgo(r.at)}` };
    const c = checks.get(i.deal.slug);
    if (c && c.sig === i.sig) return { now: false, text: `${c.username} checked it ${timeAgo(new Date(Date.parse(c.until) - SNOOZE_DAYS * 24 * 60 * 60 * 1000).toISOString())} and said all good` };
    return undefined;
  };

  // Counts per reason, after the category and search choices, so each tab says what it would show.
  const needle = q.toLowerCase();
  const inScope = (list: Item[]) =>
    list
      .filter((i) => category === "all" || i.deal.category === category)
      .filter(
        (i) =>
          !needle ||
          i.deal.title.toLowerCase().includes(needle) ||
          i.deal.store.toLowerCase().includes(needle) ||
          (i.deal.postedByUsername ?? "").toLowerCase().includes(needle),
      );
  const scoped = inScope(visible);
  const hiddenScoped = inScope(hiddenItems);
  const count = (k: Kind) => scoped.filter((i) => i.kinds.includes(k)).length;

  const posted = (i: Item) => new Date(i.deal.postedAt).getTime();
  const by: Record<SortKey, (a: Item, b: Item) => number> = {
    priority: (a, b) => b.weight - a.weight || posted(b) - posted(a),
    newest: (a, b) => posted(b) - posted(a),
    oldest: (a, b) => posted(a) - posted(b),
    store: (a, b) => a.deal.store.localeCompare(b.deal.store) || posted(b) - posted(a),
  };
  // A deal someone else is fixing right now waits at the end, whatever the order.
  const taken = (i: Item) => (fixing.has(i.deal.slug) ? 1 : 0);
  const shown = (tab === "hidden" ? hiddenScoped : scoped.filter((i) => tab === "all" || i.kinds.includes(tab as Kind))).sort(
    (a, b) => taken(a) - taken(b) || by[sort](a, b),
  );
  const totalPages = Math.max(1, Math.ceil(shown.length / PAGE_SIZE));
  // A page past the end (a deal fixed since the link was made) shows the last one.
  const pageNo = Math.min(page, totalPages);
  const pageItems = shown.slice((pageNo - 1) * PAGE_SIZE, pageNo * PAGE_SIZE);
  const narrowed = Boolean(q) || category !== "all" || sort !== "priority";
  const filtered = narrowed || tab !== "all";

  // This view's address, without the page for the tabs and with it for "Back" after fixing a deal.
  const query = (over: Record<string, string | undefined>) => {
    const next: Record<string, string | undefined> = { tab: tab === "all" ? undefined : tab, q: q || undefined, sort: sort === "priority" ? undefined : sort, category: category === "all" ? undefined : category, page: pageNo > 1 ? String(pageNo) : undefined, ...over };
    return new URLSearchParams(Object.entries(next).filter((e): e is [string, string] => !!e[1])).toString();
  };
  const href = (over: Record<string, string | undefined>) => {
    const qs = query(over);
    return qs ? `${base}?${qs}` : base;
  };
  // This view as a query string, so opening, fixing or acting on a deal returns to it (see lib/deal-edit-from.ts).
  const back = query({});

  const tabs: { key: Kind | "all" | "hidden" | "reports" | "welcome"; label: string; n: number }[] = [
    { key: "all", label: "All", n: scoped.length },
    ...(Object.keys(KINDS) as Kind[]).map((k) => ({ key: k, label: KINDS[k], n: count(k) })),
    { key: "hidden", label: "Hidden by you", n: hiddenScoped.length },
    { key: "reports", label: "Reported posts", n: reportedPosts.length },
    { key: "welcome", label: "Waiting for a reply", n: waitingThreads.length },
  ];
  const communityTab = tab === "reports" || tab === "welcome" ? tab : undefined;

  // What the last action did, said once at the top (?done=…&deal=…, or ?saved=… after Fix details).
  const doneSlug = sp.saved ?? sp.deal;
  const doneDeal = doneSlug ? getDealBySlug(doneSlug) : undefined;
  const done = sp.saved ? "saved" : sp.done === "ended" || sp.done === "fine" || sp.done === "undone" ? sp.done : undefined;

  const month = getImpact(user.id, rangeStart(30));
  const sorted = month.improved + month.ended;
  const tip = tab !== "all" && tab !== "hidden" && !communityTab ? TAB_TIPS[tab as Kind] : undefined;
  const communityDone = sp.done === "hid" ? "Hidden. A moderator will check it." : sp.done === "postfine" ? `Hidden from your desk for ${SNOOZE_DAYS} days, unless it's reported again.` : undefined;

  return (
    <>
      <AccountPageHeader
        title="Helper desk"
        description={
          <>
            {visible.length === 0 && reportedPosts.length === 0 ? "Nothing needs a hand right now" : visible.length === 0 ? "No deals need a hand" : `${visible.length} ${visible.length === 1 ? "deal could" : "deals could"} use a hand`}
            {reportedPosts.length > 0 && ` · ${reportedPosts.length} reported ${reportedPosts.length === 1 ? "post" : "posts"}`}
            {sorted > 0 && (
              <>
                {" · "}
                <a href="#your-impact" className="hover:underline">
                  You&apos;ve sorted {sorted} in 30 days
                </a>
              </>
            )}
          </>
        }
      />

      <ClashNotice message={sp.clash} />

      {communityDone && (
        <div role="status" className="flex items-center gap-2 rounded-lg bg-emerald-50 px-4 py-2 text-sm text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300">
          <Icon name="circle-check" className="size-4 shrink-0" />
          {communityDone}
        </div>
      )}

      {done && doneDeal && (
        <div role="status" className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg bg-emerald-50 px-4 py-2 text-sm text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300">
          <Icon name="circle-check" className="size-4 shrink-0" />
          <span className="min-w-0 flex-1">
            {done === "saved" && <>Saved &ldquo;{doneDeal.title}&rdquo;. Next one below.</>}
            {done === "ended" && <>Marked &ldquo;{doneDeal.title}&rdquo; as ended. A moderator can undo it.</>}
            {done === "fine" && <>Hidden &ldquo;{doneDeal.title}&rdquo; for {SNOOZE_DAYS} days, unless something new comes up.</>}
            {done === "undone" && <>&ldquo;{doneDeal.title}&rdquo; is back on your list.</>}
          </span>
          {done === "fine" ? (
            <form action={unsnoozeDeskDealAction}>
              <input type="hidden" name="slug" value={doneDeal.slug} />
              <input type="hidden" name="back" value={back} />
              <button type="submit" className="font-semibold underline">
                Undo
              </button>
            </form>
          ) : (
            <Link href={`/deals/${doneDeal.slug}?from=helper${back ? `&hq=${encodeURIComponent(back)}` : ""}`} className="font-semibold underline">
              View deal
            </Link>
          )}
        </div>
      )}

      {/* Why a deal is here: one line of tiles (it slides sideways on a
          narrow phone rather than wrapping). Reasons with nothing in them
          are left out. */}
      <nav aria-label="Why a deal is here" className="no-scrollbar -mx-4 flex gap-1.5 overflow-x-auto px-4 md:mx-0 md:flex-wrap md:px-0">
        {tabs
          .filter((t) => t.key === "all" || t.key === tab || t.n > 0)
          .map((t) => (
            <Link
              key={t.key}
              href={href({ tab: t.key === "all" ? undefined : t.key, page: undefined })}
              aria-current={t.key === tab ? "page" : undefined}
              className={`inline-flex min-h-9 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl px-3 text-sm font-medium ${
                t.key === tab
                  ? "bg-orange-500 text-white"
                  : "bg-orange-50 text-orange-800 hover:bg-orange-100 dark:bg-orange-950/30 dark:text-orange-300 dark:hover:bg-orange-950/50"
              }`}
            >
              {t.key !== "all" && t.key !== "hidden" && <Icon name={t.key === "reports" ? "replies" : t.key === "welcome" ? "hand-helping" : KIND_LOOK[t.key].icon} className="size-3.5" />}
              {t.label}
              <span className="text-xs tabular-nums opacity-80">{t.n}</span>
            </Link>
          ))}
      </nav>

      {communityTab ? (
        <CommunityDesk tab={communityTab} reported={reportedPosts} waiting={waitingThreads} />
      ) : (
        <>
          {/* Category, words and order: most helpers just work from the top, so
              these wait behind one button (open while any is in use). */}
          <details className="group -mt-2" open={narrowed}>
            <summary className="flex cursor-pointer list-none items-center gap-2 text-sm text-zinc-500 [&::-webkit-details-marker]:hidden">
              <span className="min-w-0 flex-1">
                {shown.length} to look at · {SORTS[sort].toLowerCase()}
                {category !== "all" && ` · ${category}`}
                {q && ` · “${q}”`}
              </span>
              {narrowed && (
                <Link href={href({ q: undefined, category: undefined, sort: undefined, page: undefined })} className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
                  Clear
                </Link>
              )}
              <span className="inline-flex min-h-9 items-center gap-1.5 rounded-full border border-zinc-300 px-3 font-medium text-zinc-700 group-open:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-200 dark:group-open:bg-zinc-800">
                <Icon name="arrow-up-down" className="size-4" />
                Filters
              </span>
            </summary>
            <form action={base} className="mt-3 grid grid-cols-2 items-center gap-2 rounded-xl border border-zinc-200 bg-white p-3 sm:flex sm:flex-wrap dark:border-zinc-800 dark:bg-zinc-900">
              {tab !== "all" && <input type="hidden" name="tab" value={tab} />}
              <input
                type="search"
                name="q"
                defaultValue={q}
                maxLength={SEARCH_MAX}
                placeholder="Find a deal, store or poster…"
                aria-label="Find a deal, store or poster"
                className={`col-span-2 min-w-0 sm:min-w-[14rem] sm:flex-1 ${searchField}`}
              />
              <SelectField
                look="admin"
                name="category"
                label="Category"
                defaultValue={category}
                options={[{ value: "all", label: "All categories" }, ...getCategoryGroups().map((g) => ({ value: g.name, label: g.name }))]}
                className="max-[379px]:col-span-2"
              />
              <SelectField
                look="admin"
                name="sort"
                label="Sort by"
                defaultValue={sort}
                leadingIcon="arrow-up-down"
                options={(Object.keys(SORTS) as SortKey[]).map((k) => ({ value: k, label: SORTS[k] }))}
                className="max-[379px]:col-span-2"
              />
              <button type="submit" className="col-span-2 min-h-[42px] rounded-lg bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600 sm:col-auto">
                Apply
              </button>
            </form>
          </details>

          {tip && (
            <p className="flex gap-2 rounded-xl bg-zinc-100 px-4 py-3 text-sm text-zinc-600 dark:bg-zinc-800/60 dark:text-zinc-300">
              <Icon name="lightbulb" className="mt-0.5 size-4 shrink-0 text-amber-500" />
              {tip}
            </p>
          )}

          {shown.length === 0 ? (
            <EmptyState icon="circle-check">
              <p>{tab === "hidden" && !narrowed ? "Nothing hidden. Anything you mark All good waits here." : filtered ? "Nothing matches these choices." : "All clear. Nothing needs a hand right now."}</p>
              {filtered && (
                <Link href={base} className="mt-1 text-sm font-medium text-orange-700 dark:text-orange-400 hover:underline">
                  Show everything
                </Link>
              )}
            </EmptyState>
          ) : (
            <>
              <ul className="flex flex-col gap-3">
                {pageItems.map((item) => (
                  <DeskCard key={item.deal.slug} item={item} back={back} hidden={tab === "hidden"} seen={seen} others={othersOn(item)} />
                ))}
              </ul>
              <Pager page={pageNo} totalPages={totalPages} href={(p) => href({ page: p > 1 ? String(p) : undefined })} />
            </>
          )}
        </>
      )}

      <StaffImpact userId={user.id} role={user.role} rangeKey={sp.impact} basePath={base} />
    </>
  );
}
