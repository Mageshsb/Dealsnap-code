import Link from "next/link";
import ImpactTiles from "@/components/staff/ImpactTiles";
import RangeSwitch from "@/components/staff/RangeSwitch";
import Icon from "@/components/Icon";
import { AUDIT_ACTIONS, type AuditAction } from "@/lib/audit";
import { getAuditLog, getLastAuditByActor, getLastEditByEditor, type UserRole } from "@/lib/db";
import { TEAM_RANGES, getImpact, rangeStart, teamRow } from "@/lib/staff-impact";
import { timeAgo } from "@/lib/format";

const card = "flex flex-col gap-4 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900";

// The "Staff work" side of a person's admin page: the same numbers they see
// on their own impact card, for any time block, with what's off about them (if
// anything) and the actions behind the numbers.
export default function StaffWork({
  userId,
  role,
  username,
  rangeKey,
  hrefFor,
}: {
  userId: string;
  role: UserRole;
  username: string;
  rangeKey?: string;
  hrefFor: (rangeKey: string) => string;
}) {
  const range = TEAM_RANGES.find((r) => r.key === rangeKey) ?? TEAM_RANGES[2];
  const since = rangeStart(range.days);
  const n = teamRow(userId, since);
  const allTime = getImpact(userId, rangeStart(null));
  const { entries, total } = getAuditLog({ actorId: userId, since, limit: 15 });
  const times = [getLastAuditByActor().get(userId), getLastEditByEditor().get(userId)].filter((t): t is string => !!t).sort();
  const last = times.at(-1);

  return (
    <section className={card}>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <Icon name="handshake" className="size-5 text-orange-700 dark:text-orange-400" />
            Staff work
          </h2>
          <p className="text-sm text-zinc-500">{last ? `Last active ${timeAgo(last)}` : `${username} hasn't done any staff work yet`}</p>
        </div>
        <RangeSwitch ranges={TEAM_RANGES} current={range.key} href={hrefFor} />
      </div>

      {n.flags.length > 0 && (
        <p className="flex items-start gap-2 rounded-xl bg-amber-50 px-4 py-3 text-sm font-medium text-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
          <Icon name="warning" className="mt-0.5 size-4 shrink-0" />
          Worth a look in this period: {n.flags.join(" · ")}
        </p>
      )}

      <ImpactTiles recent={n} allTime={allTime} role={role} more={{ edits: n.edits, perDeal: n.editsPerDeal }} />

      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-sm font-bold uppercase tracking-wide text-zinc-600 dark:text-zinc-300">What they did</h3>
          <Link href={`/admin/activity?staff=${userId}&days=${range.key}`} className="text-xs font-medium text-orange-700 dark:text-orange-400 hover:underline">
            {total > entries.length ? `All ${total} in the activity log →` : "In the activity log →"}
          </Link>
        </div>
        <ul className="flex flex-col gap-2">
          {entries.map((e) => {
            const meta = AUDIT_ACTIONS[e.action as AuditAction];
            return (
              <li key={e.id} className="text-sm">
                <p>
                  <Icon name={meta?.icon ?? "clipboard"} className="mr-1 text-zinc-500 dark:text-zinc-400" />
                  <span className="text-zinc-500">{meta?.text ?? e.action}</span>{" "}
                  {e.targetUrl ? (
                    <Link href={e.targetUrl} target={e.targetUrl.startsWith("/deals/") ? "_blank" : undefined} className="font-medium hover:underline">
                      {e.targetLabel}
                    </Link>
                  ) : (
                    <span className="font-medium">{e.targetLabel}</span>
                  )}
                </p>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  {e.detail ? `${e.detail} · ` : ""}
                  {timeAgo(e.at)}
                </p>
              </li>
            );
          })}
          {entries.length === 0 && <li className="text-sm text-zinc-500">Nothing recorded in this period.</li>}
        </ul>
      </div>
    </section>
  );
}
