import AccountSection from "@/components/AccountSection";
import ImpactTiles from "@/components/staff/ImpactTiles";
import RangeSwitch from "@/components/staff/RangeSwitch";
import { TEAM_RANGES, getImpact, rangeStart } from "@/lib/staff-impact";
import type { UserRole } from "@/lib/db";

// A staff member's own numbers for a time block you choose (30 days to begin
// with), with all time beneath. Private to them and the admins: no ranking
// against anyone else. The time block is the page's ?impact= and stays put when
// it changes, thanks to the #your-impact anchor.
export default function StaffImpact({ userId, role, rangeKey, basePath }: { userId: string; role: UserRole; rangeKey?: string; basePath: string }) {
  const range = TEAM_RANGES.find((r) => r.key === rangeKey) ?? TEAM_RANGES[2];
  const recent = getImpact(userId, rangeStart(range.days));
  const allTime = getImpact(userId, rangeStart(null));
  return (
    <div id="your-impact" className="scroll-mt-4">
      <AccountSection
        icon="handshake"
        title="Your impact"
        description="Only you and the admins see this."
      >
        <RangeSwitch ranges={TEAM_RANGES} current={range.key} href={(k) => `${basePath}?impact=${k}#your-impact`} />
        <ImpactTiles recent={recent} allTime={allTime} role={role} />
        <p className="text-xs text-zinc-500">
          A deal counts once however many times you edit it. Saves that change nothing, or only capitals, spacing or punctuation, don&apos;t count. A fix
          someone else redoes within a week stops counting as one that stood.
        </p>
      </AccountSection>
    </div>
  );
}
