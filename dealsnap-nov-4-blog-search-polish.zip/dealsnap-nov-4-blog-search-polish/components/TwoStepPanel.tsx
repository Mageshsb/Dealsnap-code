import { isStaffRole } from "@/lib/permissions";
import QRCode from "qrcode";
import { cookies } from "next/headers";
import { getTotpState, type UserRecord } from "@/lib/db";
import { totpUri } from "@/lib/totp";
import {
  startTwoStepSetupAction,
  confirmTwoStepSetupAction,
  cancelTwoStepSetupAction,
  disableTwoStepAction,
} from "@/lib/actions";
import { RowIcon } from "@/components/AccountSection";

const field =
  "rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950";
const primary = "self-start rounded-full bg-orange-500 px-4 py-1.5 text-sm font-semibold text-white hover:bg-orange-600";

const outline =
  "shrink-0 items-center rounded-full border border-zinc-300 px-3.5 py-1.5 text-sm font-semibold text-zinc-700 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800";

// The two-step login row of Settings → Sign-in & security: off (one tap to
// set up), being set up (the QR code, open), or on (Turn off asks for the
// password). Laid out like the rows above it (SettingRow).
export default async function TwoStepPanel({ user, open = false }: { user: UserRecord; open?: boolean }) {
  const state = getTotpState(user.id);
  const recovery = (await cookies()).get("dealsnap_recovery")?.value;
  const isStaff = isStaffRole(user.role);
  const why = `A code from an app on your phone (Google Authenticator, Microsoft Authenticator, 1Password…) as well as your password. ${
    isStaff ? "Strongly recommended for staff accounts." : "Keeps your account safe even if your password leaks."
  }`;

  const head = (value: React.ReactNode, action?: React.ReactNode) => (
    <div className="flex items-center gap-3">
      <RowIcon icon="shield-check" />
      <span className="flex min-w-0 flex-1 flex-col">
        <span className="text-sm font-semibold">Two-step login</span>
        <span className="text-sm text-zinc-500">{value}</span>
      </span>
      {action}
    </div>
  );
  const on = <span className="font-medium text-green-700 dark:text-green-400">On</span>;

  if (state.secret) {
    return (
      <div id="two-step" className="flex scroll-mt-24 flex-col gap-4 py-4 last:pb-0">
        {recovery && (
          <>
            {head(on)}
            <div className="rounded-xl border border-amber-300 bg-amber-50 p-4 text-sm text-amber-900 sm:ml-[52px] dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
              <p className="font-semibold">Save these recovery codes now. They won&apos;t be shown again.</p>
              <p className="mt-1 text-xs">Each one gets you in once if you lose your phone. Keep them somewhere safe, like a password manager.</p>
              <ul className="mt-3 grid grid-cols-2 gap-1 font-mono text-sm">
                {recovery.split(",").map((c) => (
                  <li key={c}>{c}</li>
                ))}
              </ul>
            </div>
          </>
        )}
        {!recovery && (
          <details open={open} className="group">
            <summary className="cursor-pointer list-none [&::-webkit-details-marker]:hidden">
              {head(
                on,
                <>
                  <span className={`${outline} inline-flex group-open:hidden`}>Turn off</span>
                  <span className={`${outline} hidden group-open:inline-flex`}>Cancel</span>
                </>
              )}
            </summary>
            <form action={disableTwoStepAction} className="flex flex-col gap-2 pt-4 sm:max-w-xs sm:pl-[52px]">
              <input name="password" type="password" required autoComplete="current-password" placeholder="Your password" className={field} />
              <button type="submit" className="self-start rounded-full border border-red-300 px-4 py-1.5 text-sm font-semibold text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/40">
                Turn off two-step login
              </button>
            </form>
          </details>
        )}
      </div>
    );
  }

  if (state.pending) {
    return (
      <div id="two-step" className="flex scroll-mt-24 flex-col gap-4 py-4 last:pb-0">
        {head("Setting up")}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:gap-5 sm:pl-[52px]">
          <div
            className="h-44 w-44 shrink-0 rounded-xl border border-zinc-200 bg-white p-2 [&>svg]:h-full [&>svg]:w-full"
            dangerouslySetInnerHTML={{
              __html: await QRCode.toString(totpUri(state.pending, user.username), { type: "svg", margin: 0 }),
            }}
          />
          <div className="flex flex-col gap-2">
            <p className="text-sm">1. Scan this with your authenticator app.</p>
            <p className="text-xs text-zinc-500">
              Can&apos;t scan? Enter this key instead: <span className="break-all font-mono">{state.pending.match(/.{1,4}/g)?.join(" ")}</span>
            </p>
            <p className="text-sm">2. Type the 6-digit code it shows:</p>
            <form action={confirmTwoStepSetupAction} className="flex flex-wrap items-center gap-2">
              <input
                name="code"
                required
                inputMode="numeric"
                autoComplete="one-time-code"
                maxLength={7}
                placeholder="123456"
                className={`${field} w-32 font-mono tracking-widest`}
              />
              <button type="submit" className={primary}>
                Turn on
              </button>
            </form>
            <form action={cancelTwoStepSetupAction}>
              <button type="submit" className="min-h-9 text-xs text-zinc-500 hover:underline">
                Cancel
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div id="two-step" className="flex scroll-mt-24 flex-col gap-2 py-4 last:pb-0">
      {head(
        "Off",
        <form action={startTwoStepSetupAction}>
          <button type="submit" className="shrink-0 rounded-full bg-orange-500 px-3.5 py-1.5 text-sm font-semibold text-white hover:bg-orange-600">
            Set up
          </button>
        </form>
      )}
      <p className="text-xs text-zinc-500 sm:pl-[52px]">{why}</p>
    </div>
  );
}
