"use client";

import Link from "next/link";
import SelectField from "./SelectField";
import { useActionState, useState } from "react";
import { sendContactMessageAction, type ContactState } from "@/lib/contact-actions";
import { CONTACT_LIMITS, CONTACT_TOPICS, contactTopic } from "@/lib/contact";
import type { FormCheck } from "@/lib/captcha";
import Icon from "./Icon";
import BotCheck from "./BotCheck";

// The same field as the site's other forms; a shade darker than the form's
// card in dark mode, like every field inside a card.
const input =
  "w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950";
const errorRing = "border-red-400 dark:border-red-500";
const label = "text-sm font-medium";

export default function ContactForm({
  initialCheck,
  turnstileSiteKey,
  defaultName = "",
  defaultEmail = "",
  defaultTopic = "help",
}: {
  initialCheck: FormCheck;
  turnstileSiteKey?: string;
  defaultName?: string;
  defaultEmail?: string;
  defaultTopic?: string;
}) {
  const [state, action, pending] = useActionState<ContactState, FormData>(sendContactMessageAction, { status: "idle" });
  const check = state.check ?? initialCheck;
  // After a failed send React resets the form to these, so what was typed stays.
  const values = state.values ?? { name: defaultName, email: defaultEmail, topic: defaultTopic, message: "" };
  const [length, setLength] = useState(0);
  const [topic, setTopic] = useState(values.topic);
  const [syncedTo, setSyncedTo] = useState(state);
  if (syncedTo !== state) {
    setSyncedTo(state);
    setLength(values.message.length);
    setTopic(values.topic);
  }
  const hint = contactTopic(topic)?.hint;
  if (state.status === "sent") {
    return (
      <div role="status" className="flex flex-col items-center gap-2 rounded-xl border border-green-200 bg-green-50 p-6 text-center dark:border-green-900/60 dark:bg-green-950/30">
        <Icon name="circle-check" className="size-10 text-green-700 dark:text-green-400" />
        <h2 className="text-lg font-bold">Thanks, message sent!</h2>
        <p className="max-w-md text-sm leading-relaxed text-zinc-600 dark:text-zinc-400">
          We read every message and will reply to <span className="font-medium text-zinc-800 dark:text-zinc-200">{state.sentTo}</span> as soon
          as we can
          {state.replyFrom && (
            <>
              , from <span className="font-medium text-zinc-800 dark:text-zinc-200">{state.replyFrom}</span>
            </>
          )}
          . We’ll never ask for your password.
        </p>
        <Link href="/" className="mt-2 rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600">
          Back to deals
        </Link>
      </div>
    );
  }

  const bad = (f: ContactState["field"]) => (state.status === "error" && state.field === f ? errorRing : "");

  return (
    <form action={action} className="flex flex-col gap-4 rounded-xl border border-zinc-200 bg-white p-5 sm:p-6 dark:border-zinc-800 dark:bg-zinc-900" noValidate={false}>
      {state.status === "error" && state.error && (
        <p role="alert" className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
          {state.error}
        </p>
      )}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="flex flex-col gap-1">
          <label htmlFor="contact-name" className={label}>Your name</label>
          <input id="contact-name" name="name" required maxLength={CONTACT_LIMITS.name} autoComplete="name" defaultValue={values.name} className={`${input} ${bad("name")}`} />
        </div>
        <div className="flex flex-col gap-1">
          <label htmlFor="contact-email" className={label}>Email</label>
          <input
            id="contact-email"
            name="email"
            type="email"
            required
            maxLength={CONTACT_LIMITS.email}
            autoComplete="email"
            autoCapitalize="none"
            spellCheck={false}
            defaultValue={values.email}
            placeholder="you@example.com"
            className={`${input} ${bad("email")}`}
          />
        </div>
      </div>

      <div className="flex flex-col gap-1">
        <label htmlFor="contact-topic" className={label}>What’s it about?</label>
        <SelectField
          id="contact-topic"
          name="topic"
          label="What’s it about?"
          required
          value={topic}
          onChange={setTopic}
          options={CONTACT_TOPICS.map((t) => ({ value: t.value, label: t.label }))}
        />
        <p aria-live="polite" className="text-xs text-zinc-500 empty:hidden dark:text-zinc-400">
          {hint}
        </p>
      </div>

      <div className="flex flex-col gap-1">
        <label htmlFor="contact-message" className={label}>Message</label>
        <textarea
          id="contact-message"
          name="message"
          required
          minLength={CONTACT_LIMITS.minMessage}
          maxLength={CONTACT_LIMITS.message}
          rows={6}
          defaultValue={values.message}
          onChange={(e) => setLength(e.target.value.length)}
          placeholder="How can we help? If it’s about a deal, a link to it helps."
          className={`${input} resize-y ${bad("message")}`}
        />
        <div className="flex justify-between gap-3 text-xs text-zinc-500 dark:text-zinc-400">
          <span>Please don’t include passwords or card details.</span>
          <span className="shrink-0 tabular-nums">
            {length}/{CONTACT_LIMITS.message}
          </span>
        </div>
      </div>

      <BotCheck
        idPrefix="contact"
        check={check}
        siteKey={turnstileSiteKey}
        resetKey={state.status === "error" ? state : undefined}
        answerClassName={`${input} w-24 ${bad("check")}`}
      />

      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <p className="flex gap-1.5 text-xs leading-relaxed text-zinc-500 dark:text-zinc-400">
          <Icon name="lock" className="mt-0.5 size-3.5 shrink-0" />
          <span>
            We only use your details to reply to you. See our{" "}
            <Link href="/privacy" className="underline underline-offset-2 hover:text-orange-500">Privacy policy</Link>.
          </span>
        </p>
        <button
          type="submit"
          disabled={pending}
          className="shrink-0 rounded-full bg-orange-500 px-6 py-2 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60"
        >
          {pending ? "Sending…" : "Send message"}
        </button>
      </div>
    </form>
  );
}
