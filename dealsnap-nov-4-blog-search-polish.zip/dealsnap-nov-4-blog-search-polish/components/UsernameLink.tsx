import Link from "next/link";
import Icon from "./Icon";
import UserAvatar from "./UserAvatar";
import RoleBadge, { tierLook, tierOf, type Tier } from "./RoleBadge";
import type { UserRole } from "@/lib/db";

// Only real registered accounts (an id present) get a link — a handful of
// seed deals are attributed to made-up demo posters that have no user row,
// so linking those would just 404.
export default function UsernameLink({
  username,
  userId,
  avatarUrl,
  size = "h-6 w-6",
  className = "",
  nameClassName = "",
  role,
  tier = tierOf(role),
  badge = "icon",
  avatar = true,
}: {
  username: string;
  userId?: string;
  avatarUrl?: string | null;
  size?: string;
  className?: string;
  // e.g. "max-sm:sr-only" to show only the avatar where space is tight.
  nameClassName?: string;
  // Their rank, shown as a small mark by the name (helpers and up).
  role?: UserRole;
  tier?: Tier;
  // "colour": the name takes the rank's colour, with its icon after it where there is room.
  badge?: "icon" | "label" | "colour";
  // Off where the picture sits apart from the name (a comment's left column).
  avatar?: boolean;
}) {
  const look = tier && badge === "colour" ? tierLook(tier) : undefined;
  const content = (
    <>
      {avatar && <UserAvatar username={username} avatarUrl={avatarUrl} size={size} />}
      {look ? (
        // The rank's icon sits after the name, on a second line the fixed height
        // hides: it shows only when the whole name fits beside it, so a tight
        // space always gives the room to the name.
        <span className="flex h-[1lh] min-w-0 flex-wrap items-center gap-x-1 overflow-hidden">
          <span className={`max-w-full truncate font-medium ${look.text} ${nameClassName}`} title={`${look.label}: ${look.tip}`}>
            {username}
            <span className="sr-only">, {look.label}</span>
          </span>
          <Icon name={look.icon} className={`size-3.5 shrink-0 ${look.text}`} />
        </span>
      ) : (
        <span className={`truncate ${nameClassName}`}>{username}</span>
      )}
      {tier && !look && <RoleBadge tier={tier} variant={badge as "icon" | "label"} />}
    </>
  );

  if (!userId) {
    return <span className={className}>{content}</span>;
  }

  return (
    <Link href={`/u/${username}`} className={`hover:underline ${className}`}>
      {content}
    </Link>
  );
}
