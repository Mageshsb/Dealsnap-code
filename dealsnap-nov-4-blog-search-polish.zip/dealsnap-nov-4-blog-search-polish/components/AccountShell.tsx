import { Fragment } from "react";
import Link from "next/link";
import type { UserRecord } from "@/lib/db";
import { logoutAction } from "@/lib/actions";
import { ACCOUNT_LINKS, SETTINGS_SECTIONS, type AccountHref, type SettingsKey } from "@/lib/account-links";
import { CountBadge } from "./NotificationCount";
import UserAvatar from "./UserAvatar";
import Icon, { type IconName } from "./Icon";
import RoleBadge, { tierOf } from "./RoleBadge";
import { can, isStaffRole } from "@/lib/permissions";

const current = "bg-orange-100 font-medium text-orange-700 dark:bg-orange-950/50 dark:text-orange-400";
const idle = "text-zinc-700 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800";

// The My account menu down the side on tablets and desktop. Phones get
// AccountHub instead (the My account page itself), with the same places.
export function AccountMenu({
  user,
  active,
  settingsSection,
}: {
  user: UserRecord;
  active?: AccountHref;
  settingsSection?: SettingsKey;
}) {
  const row = "flex items-center gap-2 rounded-lg px-3 py-2 text-sm";
  const icon = "size-[18px]";

  return (
    <div className="flex flex-col gap-1">
      <div className="mb-2 flex items-center gap-2.5 px-2">
        <UserAvatar username={user.username} avatarUrl={user.avatarUrl} size="h-9 w-9" />
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-zinc-900 dark:text-zinc-100">{user.username}</p>
          <p className="text-xs text-zinc-500">My account</p>
        </div>
      </div>

      <nav aria-label="My account" className="flex flex-col gap-0.5">
        {ACCOUNT_LINKS.map((l) => (
          <Fragment key={l.href}>
            <Link
              href={l.href}
              aria-current={l.href === active && !(l.href === "/settings" && settingsSection) ? "page" : undefined}
              className={`${row} ${l.href !== active ? idle : settingsSection ? "font-semibold text-zinc-900 dark:text-zinc-100" : current}`}
            >
              <Icon name={l.icon} className={`${icon} ${l.href === active ? "" : "text-zinc-500 dark:text-zinc-400"}`} />
              <span className="flex-1">{l.label}</span>
              {l.badge && <CountBadge />}
            </Link>
            {/* Settings' own sections, while you're in Settings. */}
            {l.href === "/settings" && active === "/settings" && (
              <div className="ml-5 flex flex-col gap-0.5 border-l border-zinc-200 pl-2 dark:border-zinc-800">
                {SETTINGS_SECTIONS.map((s) => (
                  <Link
                    key={s.key}
                    href={`/settings?s=${s.key}`}
                    aria-current={s.key === settingsSection ? "page" : undefined}
                    className={`rounded-lg px-3 py-1.5 text-sm ${s.key === settingsSection ? current : idle}`}
                  >
                    {s.label}
                  </Link>
                ))}
              </div>
            )}
          </Fragment>
        ))}
      </nav>

      <div className="mt-2 flex flex-col gap-0.5 border-t border-zinc-200 pt-2 dark:border-zinc-800">
        <StaffLink user={user} className={row} icon={icon} active={active} />
        <LogOutButton className={row} icon={icon} />
      </div>
    </div>
  );
}

// Admin, Moderation or the Helper desk, for the people who have one.
function StaffLink({ user, className, icon, active }: { user: UserRecord; className: string; icon: string; active?: AccountHref }) {
  const desk = isStaffRole(user.role)
    ? { href: "/admin", label: user.role === "admin" ? "Admin" : "Moderation", icon: (user.role === "admin" ? "wrench" : "shield") as IconName }
    : can(user.role, "deals.fix")
      ? { href: "/helper", label: "Helper desk", icon: "hand-helping" as IconName }
      : undefined;
  if (!desk) return null;
  const here = desk.href === active;
  return (
    <Link
      href={desk.href}
      aria-current={here ? "page" : undefined}
      className={`${className} font-medium text-orange-700 dark:text-orange-400 ${here ? "bg-orange-100 dark:bg-orange-950/50" : "hover:bg-zinc-100 dark:hover:bg-zinc-800"}`}
    >
      <Icon name={desk.icon} className={`${icon} text-orange-700 dark:text-orange-400`} />
      <span className="flex-1">{desk.label}</span>
    </Link>
  );
}

function LogOutButton({ className, icon }: { className: string; icon: string }) {
  return (
    <form action={logoutAction}>
      <button type="submit" className={`${className} w-full ${idle}`}>
        <Icon name="log-out" className={`${icon} text-zinc-500 dark:text-zinc-400`} />
        Log out
      </button>
    </form>
  );
}

// What the phone My account page shows beside each place, so you can see
// what's waiting without opening anything.
export type AccountSummary = {
  dealCount: number;
  heartsReceived: number;
  saved: number;
  alerts: number;
  following: number;
};

const plural = (n: number, one: string, many: string) => `${n} ${n === 1 ? one : many}`;

// My account on phones: you at the top (tap for your profile), then two
// short groups, each row saying what's in it.
export function AccountHub({ user, summary }: { user: UserRecord; summary: AccountSummary }) {
  const rank = tierOf(user.role);
  const row = "flex min-h-14 items-center gap-3 px-4 text-base hover:bg-zinc-50 dark:hover:bg-zinc-800/60";
  const group = "flex flex-col divide-y divide-zinc-100 overflow-hidden rounded-xl border border-zinc-200 bg-white dark:divide-zinc-800 dark:border-zinc-800 dark:bg-zinc-900";
  const heading = "px-1 text-xs font-semibold uppercase tracking-wide text-zinc-500";
  const status = "shrink-0 text-sm text-zinc-500";
  const chevron = <Icon name="chevron-right" className="size-4 shrink-0 text-zinc-300 dark:text-zinc-600" />;
  const activity: { href: AccountHref; icon: IconName; label: string; status?: React.ReactNode }[] = [
    { href: "/notifications", icon: "bell", label: "Notifications", status: <CountBadge /> },
    { href: "/saved", icon: "bookmark", label: "Saved deals", status: summary.saved > 0 ? summary.saved : undefined },
    { href: "/alerts", icon: "target", label: "Alerts", status: summary.alerts > 0 ? `${summary.alerts} on` : "None yet" },
    { href: "/feed", icon: "users", label: "Following feed", status: summary.following > 0 ? plural(summary.following, "person", "people") : undefined },
  ];

  return (
    <div className="flex flex-col gap-5">
      <AccountPageHeader title="My account" description="Your profile, what's new for you, and your settings." />
      <Link
        href="/profile"
        className="flex flex-col gap-4 rounded-xl border border-zinc-200 bg-white p-4 hover:border-zinc-300 dark:border-zinc-800 dark:bg-zinc-900 dark:hover:border-zinc-700"
      >
        <div className="flex items-center gap-3">
          <UserAvatar username={user.username} avatarUrl={user.avatarUrl} size="h-14 w-14" textSize="text-2xl" />
          <div className="flex min-w-0 flex-1 flex-col gap-1">
            <span className="flex min-w-0 items-center gap-2">
              <span className="truncate text-lg font-bold">{user.username}</span>
              {rank && <RoleBadge tier={rank} variant="pill" />}
            </span>
            <span className="text-sm font-medium text-orange-700 dark:text-orange-400">View my profile</span>
          </div>
          {chevron}
        </div>
        <div className="grid grid-cols-2 divide-x divide-zinc-100 border-t border-zinc-100 pt-3 text-center dark:divide-zinc-800 dark:border-zinc-800">
          <span className="flex flex-col">
            <span className="text-lg font-bold tabular-nums">{summary.dealCount}</span>
            <span className="text-xs text-zinc-500">{summary.dealCount === 1 ? "deal posted" : "deals posted"}</span>
          </span>
          <span className="flex flex-col">
            <span className="text-lg font-bold tabular-nums">{summary.heartsReceived}</span>
            <span className="text-xs text-zinc-500">{summary.heartsReceived === 1 ? "heart received" : "hearts received"}</span>
          </span>
        </div>
      </Link>

      <section className="flex flex-col gap-2">
        <h2 className={heading}>Your activity</h2>
        <nav aria-label="Your activity" className={group}>
          {activity.map((l) => (
            <Link key={l.href} href={l.href} className={row}>
              <Icon name={l.icon} className="size-5 shrink-0 text-zinc-500 dark:text-zinc-400" />
              <span className="flex-1">{l.label}</span>
              {l.status !== undefined && <span className={status}>{l.status}</span>}
              {chevron}
            </Link>
          ))}
        </nav>
      </section>

      <section className="flex flex-col gap-2">
        <h2 className={heading}>Account</h2>
        <div className={group}>
          <Link href="/settings" className={row}>
            <Icon name="settings" className="size-5 shrink-0 text-zinc-500 dark:text-zinc-400" />
            <span className="flex-1">Settings</span>
            {chevron}
          </Link>
          <StaffLink user={user} className={row} icon="size-5" />
          <LogOutButton className={row} icon="size-5" />
        </div>
      </section>
    </div>
  );
}

// The frame around every My account page: the menu down the side on tablets and desktop;
// on phones, a link back up a level (the My account page, which is the menu,
// or for one Settings section, the Settings list).
export default function AccountShell({
  user,
  active,
  settingsSection,
  back = { href: "/account", label: "My account" },
  children,
}: {
  user: UserRecord;
  active: AccountHref;
  settingsSection?: SettingsKey;
  back?: { href: string; label: string };
  children: React.ReactNode;
}) {
  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-5 px-4 py-6 md:flex-row md:items-start md:gap-6 lg:gap-8">
      <aside className="hidden md:sticky md:top-20 md:block md:w-52 md:shrink-0 lg:w-56">
        <AccountMenu user={user} active={active} settingsSection={settingsSection} />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col gap-5">
        <Link href={back.href} className="-my-1.5 inline-flex min-h-9 items-center gap-0.5 self-start text-sm font-medium text-zinc-500 hover:text-orange-700 md:hidden">
          <Icon name="chevron-left" className="size-4" />
          {back.label}
        </Link>
        {children}
      </div>
    </main>
  );
}

// The same heading on every My account page: a title, one line saying what
// the page is for, and any buttons on the right.
export function AccountPageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: React.ReactNode;
  actions?: React.ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3">
      <div className="min-w-0">
        <h1 className="text-xl font-bold sm:text-2xl">{title}</h1>
        {description && <p className="text-sm text-zinc-500">{description}</p>}
      </div>
      {actions}
    </div>
  );
}
