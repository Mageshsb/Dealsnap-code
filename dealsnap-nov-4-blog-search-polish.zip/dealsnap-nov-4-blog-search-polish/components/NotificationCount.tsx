"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { usePathname } from "next/navigation";

// The unread notification count, shared by the bell (tablet and desktop) and the
// phone menu button. It refreshes when you move between pages, when you come back
// to the tab, and once a minute while the page is open.
const CountContext = createContext(0);

export function NotificationCountProvider({ initial, enabled, children }: { initial: number; enabled: boolean; children: React.ReactNode }) {
  const [count, setCount] = useState(initial);
  const pathname = usePathname();

  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    const refresh = () =>
      fetch("/api/notifications/count", { cache: "no-store" })
        .then((r) => r.json())
        .then((d: { count: number }) => {
          if (!cancelled) setCount(d.count);
        })
        .catch(() => {});
    refresh();
    const timer = window.setInterval(() => {
      if (document.visibilityState === "visible") refresh();
    }, 60_000);
    const onFocus = () => refresh();
    window.addEventListener("focus", onFocus);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
      window.removeEventListener("focus", onFocus);
    };
  }, [enabled, pathname]);

  return <CountContext.Provider value={enabled ? count : 0}>{children}</CountContext.Provider>;
}

export function useNotificationCount() {
  return useContext(CountContext);
}

export function CountBadge({ className = "" }: { className?: string }) {
  const count = useNotificationCount();
  if (!count) return null;
  return (
    <span
      className={`flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-red-500 px-1 text-[11px] font-bold leading-none text-white ${className}`}
    >
      {count > 99 ? "99+" : count}
    </span>
  );
}
