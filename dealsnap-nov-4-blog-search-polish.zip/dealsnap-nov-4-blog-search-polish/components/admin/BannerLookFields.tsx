"use client";

import { useEffect, useRef, useState } from "react";
import BannerStrip from "@/components/BannerStrip";
import { DEFAULT_BANNER_BG, DEFAULT_BANNER_FG, MIN_READABLE, contrastRatio, isHexColour } from "@/lib/banners";
import { hint } from "./formStyles";

const PICKER =
  "h-11 w-full cursor-pointer rounded-lg border border-zinc-300 bg-zinc-50 p-1 dark:border-zinc-700 dark:bg-zinc-950";

// The banner's two colours, with a live look at the result as the colours and
// words are changed. It reads the words from the form it sits in (the boxes
// named by `messageField`, `linkField` and `labelField`), so it works for a
// banner of its own and for an event's banner alike.
export default function BannerLookFields({
  bg = DEFAULT_BANNER_BG,
  fg = DEFAULT_BANNER_FG,
  messageField,
  fallbackMessage = "",
  link,
}: {
  bg?: string;
  fg?: string;
  messageField: string;
  fallbackMessage?: string; // shown while the message box is empty
  link: { url: string; label: string } | { urlField: string; labelField: string; url?: string; label?: string };
}) {
  const root = useRef<HTMLDivElement>(null);
  const urlField = "urlField" in link ? link.urlField : undefined;
  const labelField = "labelField" in link ? link.labelField : undefined;
  const [look, setLook] = useState({
    bg,
    fg,
    message: "",
    url: "url" in link ? (link.url ?? "") : "",
    label: "label" in link ? (link.label ?? "") : "",
  });

  useEffect(() => {
    const form = root.current?.closest("form");
    if (!form) return;
    const read = () => {
      const data = new FormData(form);
      const text = (name?: string) => (name ? String(data.get(name) ?? "") : "");
      setLook((prev) => ({
        bg: String(data.get("bg") ?? bg),
        fg: String(data.get("fg") ?? fg),
        message: text(messageField),
        url: urlField ? text(urlField) : prev.url,
        label: labelField ? text(labelField) : prev.label,
      }));
    };
    read();
    form.addEventListener("input", read);
    return () => form.removeEventListener("input", read);
  }, [bg, fg, messageField, urlField, labelField]);

  const bgOk = isHexColour(look.bg) ? look.bg : DEFAULT_BANNER_BG;
  const fgOk = isHexColour(look.fg) ? look.fg : DEFAULT_BANNER_FG;
  const hard = contrastRatio(bgOk, fgOk) < MIN_READABLE;

  return (
    <div ref={root} className="flex flex-col gap-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <label className="flex flex-col gap-1 text-sm font-medium">
          Background colour
          <input type="color" name="bg" defaultValue={bg} className={PICKER} />
        </label>
        <label className="flex flex-col gap-1 text-sm font-medium">
          Text colour
          <input type="color" name="fg" defaultValue={fg} className={PICKER} />
        </label>
      </div>
      <div className="flex flex-col gap-1.5">
        <span className="text-sm font-medium">How it looks</span>
        <div className="overflow-hidden rounded-lg border border-zinc-200 dark:border-zinc-700">
          <BannerStrip
            preview
            stamp="preview"
            message={look.message || fallbackMessage || "Your message appears here."}
            linkUrl={look.url || undefined}
            linkLabel={look.label || undefined}
            bg={bgOk}
            fg={fgOk}
          />
        </div>
        {hard && (
          <p className="text-xs text-amber-700 dark:text-amber-400">
            These two colours are hard to read together. Try making one lighter or darker.
          </p>
        )}
        <p className={hint}>Phones show it the same way, with the words wrapping onto a second line if needed.</p>
      </div>
    </div>
  );
}
