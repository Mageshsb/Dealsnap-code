import Icon from "@/components/Icon";
import type { UserRole } from "@/lib/db";
import { ROLE_LABELS } from "@/lib/permissions";

// Shown beside a deal or comment the viewer can see but not change, so it
// doesn't look like a ghost: it's by someone of their own rank or above, and
// the way to deal with it is to escalate it to the admins.
export default function AboveYouNote({ role, what }: { role: UserRole; what: "deal" | "comment" }) {
  return (
    <p className="flex items-start gap-1.5 text-xs text-zinc-500 dark:text-zinc-400 sm:max-w-[16rem] sm:text-right">
      <Icon name="info" className="mt-0.5 size-3.5 shrink-0" />
      <span>
        {ROLE_LABELS[role]}&apos;s {what}: same rank or above yours, so you can escalate it but not change it.
      </span>
    </p>
  );
}
