import Link from "next/link";

// The one look for moving between the parts of an admin section (Site
// content, Ads, Team, Settings, Tags and brands, a member's page): orange
// for where you are, outlined for the rest. "Which ones to show" filters use
// the orange tiles instead, and black pills are only for deal sort order.
export default function SectionTabs({
  label,
  tabs,
  current,
}: {
  label: string;
  tabs: readonly { key: string; label: string; href: string }[];
  current: string;
}) {
  return (
    <nav aria-label={label} className="-mt-1 flex flex-wrap gap-1.5">
      {tabs.map((t) => (
        <Link
          key={t.key}
          href={t.href}
          aria-current={t.key === current ? "page" : undefined}
          className={`flex h-9 items-center rounded-full px-4 text-sm font-medium ${
            t.key === current
              ? "bg-orange-500 text-white"
              : "border border-zinc-300 text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
          }`}
        >
          {t.label}
        </Link>
      ))}
    </nav>
  );
}
