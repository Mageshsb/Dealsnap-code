import type { ReactNode } from "react";
import ContentTabs from "./ContentTabs";

// The top of each Site content page: the section's name, the tabs between its
// sub-sections, then the sub-section itself (its name, what it's for, and the
// button that makes a new one). The buttons sit under the tabs because they
// belong to the tab you're on, not to Site content as a whole.
export default function ContentHeader({
  current,
  title,
  description,
  actions,
}: {
  current: "strip" | "promos" | "events";
  title: string;
  description: ReactNode;
  actions: ReactNode;
}) {
  return (
    <>
      <h1 className="text-xl font-bold sm:text-2xl">Site content</h1>
      <ContentTabs current={current} />
      <div className="flex flex-wrap items-end justify-between gap-x-4 gap-y-2">
        <div className="min-w-0 max-w-xl">
          <h2 className="font-semibold">{title}</h2>
          <p className="text-sm text-zinc-500">{description}</p>
        </div>
        <div className="flex flex-wrap gap-2">{actions}</div>
      </div>
    </>
  );
}
