import { searchField } from "./formStyles";
import { SEARCH_MAX } from "@/lib/search-limits";

// One box above the Admin menu that looks across deals, members, comments and
// stores at once (Admin → Search). Enter sends it; no button to add clutter.
export default function AdminSearch({ defaultValue = "" }: { defaultValue?: string }) {
  return (
    <form action="/admin/search" role="search">
      <input
        type="search"
        name="q"
        defaultValue={defaultValue}
        maxLength={SEARCH_MAX}
        placeholder="Search all of Admin…"
        aria-label="Search all of Admin"
        className={`w-full ${searchField}`}
      />
    </form>
  );
}
