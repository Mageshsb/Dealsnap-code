"use client";

import { useRef, useState, useTransition } from "react";
import { uploadBlogImageAction } from "@/lib/admin-actions";
import { parseBlogContent, plainBlogText, readMinutes, wordCount } from "@/lib/blog";
import BlogContent from "../BlogContent";
import Icon, { type IconName } from "../Icon";
import { field, hint } from "./formStyles";

const TABLE_TEMPLATE = "| Product | Price | Best for |\n| Name | £0 | Who it suits |\n| Name | £0 | Who it suits |";

type Panel = "picture" | "deal" | null;

// The post's writing box: a toolbar for the marks (so nobody has to remember
// them), a Preview that draws the post as readers will see it, and the live
// word count. What's saved is the same plain text as ever, never HTML.
export default function PostWriter({ initial }: { initial: string }) {
  const [text, setText] = useState(initial);
  const [view, setView] = useState<"write" | "preview">("write");
  const [panel, setPanel] = useState<Panel>(null);
  const [alt, setAlt] = useState("");
  const [dealRef, setDealRef] = useState("");
  const [error, setError] = useState("");
  const [pending, startTransition] = useTransition();
  const box = useRef<HTMLTextAreaElement>(null);
  const file = useRef<HTMLInputElement>(null);

  // Puts text where the cursor is, or around what's selected.
  function put(make: (selected: string) => string, { block = false } = {}) {
    const el = box.current;
    if (!el) return;
    const [from, to] = [el.selectionStart, el.selectionEnd];
    const insert = make(text.slice(from, to));
    let before = text.slice(0, from);
    let after = text.slice(to);
    // A block (heading, list, table…) sits on its own paragraph.
    if (block) {
      if (before && !before.endsWith("\n\n")) before += before.endsWith("\n") ? "\n" : "\n\n";
      if (after && !after.startsWith("\n\n")) after = (after.startsWith("\n") ? "\n" : "\n\n") + after;
      else if (!after) after = "\n";
    }
    const next = before + insert + after;
    setText(next);
    const caret = (before + insert).length;
    requestAnimationFrame(() => {
      el.focus();
      el.setSelectionRange(caret, caret);
    });
  }

  const lines = (prefix: string, fallback: string) => (s: string) =>
    (s || fallback)
      .split("\n")
      .map((l) => (l.trim() ? `${prefix}${l.replace(/^(#{2,3} |[-•*] |> )/, "")}` : l))
      .join("\n");

  function addPicture() {
    const f = file.current?.files?.[0];
    if (!f) return setError("Choose a picture first.");
    setError("");
    const data = new FormData();
    data.set("image", f);
    data.set("alt", alt);
    startTransition(async () => {
      const result = await uploadBlogImageAction(data);
      if ("error" in result) return setError(result.error);
      put(() => result.markup, { block: true });
      setPanel(null);
      setAlt("");
      if (file.current) file.current.value = "";
    });
  }

  function addDeal() {
    // A pasted deal page address, or just its ending.
    const match = dealRef.trim().match(/\/deals\/([a-z0-9-]+)/i) ?? dealRef.trim().match(/^([a-z0-9][a-z0-9-]*)$/i);
    if (!match) return setError("Paste the deal's page address (it contains /deals/…).");
    setError("");
    put(() => `::deal ${match[1].toLowerCase()}`, { block: true });
    setPanel(null);
    setDealRef("");
  }

  const tools: { id: string; icon: IconName; label: string }[] = [
    { id: "h2", icon: "heading-2", label: "Section heading" },
    { id: "h3", icon: "heading-3", label: "Smaller heading" },
    { id: "bold", icon: "bold", label: "Bold" },
    { id: "list", icon: "list", label: "Bullet list" },
    { id: "link", icon: "link", label: "Link" },
    { id: "note", icon: "quote", label: "Highlighted note" },
    { id: "table", icon: "table", label: "Table" },
    { id: "picture", icon: "image", label: "Picture" },
    { id: "deal", icon: "shopping-bag", label: "Live deal card" },
  ];

  function pressTool(id: string) {
    if (id === "h2") put(lines("## ", "Heading"), { block: true });
    else if (id === "h3") put(lines("### ", "Heading"), { block: true });
    else if (id === "bold") put((s) => `**${s || "bold words"}**`);
    else if (id === "list") put(lines("- ", "Point"), { block: true });
    else if (id === "link") put((s) => `[${s || "link words"}](https://)`);
    else if (id === "note") put(lines("> ", "A tip worth highlighting"), { block: true });
    else if (id === "table") put(() => TABLE_TEMPLATE, { block: true });
    else if (id === "picture") setPanel((p) => (p === "picture" ? null : "picture"));
    else if (id === "deal") setPanel((p) => (p === "deal" ? null : "deal"));
  }

  const blocks = parseBlogContent(text.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean));
  const words = wordCount(plainBlogText(text));
  const tab = (active: boolean) =>
    `min-h-9 rounded-lg px-3 text-sm font-medium transition-colors ${active ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900" : "text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"}`;

  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <label htmlFor="content" className="text-sm font-medium">
          The post
        </label>
        <div role="tablist" aria-label="Write or preview" className="flex gap-1">
          <button type="button" role="tab" aria-selected={view === "write"} onClick={() => setView("write")} className={tab(view === "write")}>
            Write
          </button>
          <button type="button" role="tab" aria-selected={view === "preview"} onClick={() => setView("preview")} className={tab(view === "preview")}>
            Preview
          </button>
        </div>
      </div>

      {view === "write" && (
        <div className="flex flex-wrap gap-1 rounded-lg border border-zinc-200 bg-zinc-50 p-1 dark:border-zinc-700 dark:bg-zinc-950" role="toolbar" aria-label="Formatting">
          {tools.map((t) => (
            <button
              key={t.id}
              type="button"
              title={t.label}
              aria-label={t.label}
              onClick={() => pressTool(t.id)}
              className="flex size-9 items-center justify-center rounded-md text-zinc-600 transition-colors hover:bg-white hover:text-orange-600 dark:text-zinc-300 dark:hover:bg-zinc-800"
            >
              <Icon name={t.icon} className="size-4" />
            </button>
          ))}
        </div>
      )}

      {view === "write" && panel === "picture" && (
        <div className="flex flex-col gap-2 rounded-lg border border-zinc-200 p-3 dark:border-zinc-700">
          <input ref={file} type="file" accept="image/png,image/jpeg,image/webp" className="text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-zinc-100 file:px-3 file:py-2 file:text-sm file:font-medium dark:file:bg-zinc-800" />
          <input value={alt} onChange={(e) => setAlt(e.target.value)} maxLength={160} placeholder="Describe the picture (read aloud to blind readers, and used by Google)" className={field} />
          <div className="flex items-center gap-2">
            <button type="button" onClick={addPicture} disabled={pending} className="rounded-full bg-orange-500 px-4 py-1.5 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60">
              {pending ? "Adding…" : "Add picture"}
            </button>
            <span className={hint}>JPG, PNG or WEBP, under 8MB.</span>
          </div>
        </div>
      )}

      {view === "write" && panel === "deal" && (
        <div className="flex flex-col gap-2 rounded-lg border border-zinc-200 p-3 dark:border-zinc-700">
          <input value={dealRef} onChange={(e) => setDealRef(e.target.value)} placeholder="Paste the deal's page address, e.g. https://…/deals/pixel-9a-deal" className={field} />
          <div className="flex items-center gap-2">
            <button type="button" onClick={addDeal} className="rounded-full bg-orange-500 px-4 py-1.5 text-sm font-semibold text-white hover:bg-orange-600">
              Add deal card
            </button>
            <span className={hint}>Shows the deal&apos;s picture and live price, so it never goes stale.</span>
          </div>
        </div>
      )}

      {error && (
        <p role="alert" className="text-sm text-red-600 dark:text-red-400">
          {error}
        </p>
      )}

      {/* Kept in the form while previewing, so switching tabs never loses anything. */}
      <textarea
        id="content"
        ref={box}
        name="content"
        required
        rows={20}
        value={text}
        onChange={(e) => setText(e.target.value)}
        hidden={view === "preview"}
        className={`${field} leading-relaxed`}
      />

      {view === "preview" && (
        <div className="rounded-lg border border-zinc-200 bg-white p-4 sm:p-6 dark:border-zinc-700 dark:bg-zinc-950">
          {blocks.length ? (
            <div className="mx-auto max-w-[44rem]">
              <BlogContent blocks={blocks} preview />
            </div>
          ) : (
            <p className="text-sm text-zinc-500">Nothing to preview yet.</p>
          )}
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className={hint}>Leave a blank line between paragraphs.</span>
        <span className="text-xs tabular-nums text-zinc-500">
          {words.toLocaleString("en-GB")} words · about {readMinutes(text)} min read
        </span>
      </div>
    </div>
  );
}
