"use client";

import { useEffect, useRef, useState } from "react";
import { blogChecks, type BlogCheck } from "@/lib/blog";
import Icon from "../Icon";
import { hint, panel, panelTitle } from "./formStyles";

// "Is it ready to be found?": updates as you type. It never blocks a save.
export default function PostChecklist({ initial }: { initial: Parameters<typeof blogChecks>[0] }) {
  const [checks, setChecks] = useState<BlogCheck[]>(() => blogChecks(initial));
  const anchor = useRef<HTMLElement>(null);

  useEffect(() => {
    const form = anchor.current?.closest("form");
    if (!form) return;
    let timer: ReturnType<typeof setTimeout>;
    const read = () => {
      const data = new FormData(form);
      const cover = data.get("cover");
      setChecks(
        blogChecks({
          title: String(data.get("title") ?? ""),
          excerpt: String(data.get("excerpt") ?? ""),
          content: String(data.get("content") ?? ""),
          takeaways: String(data.get("takeaways") ?? ""),
          hasCover: initial.hasCover || (cover instanceof File && cover.size > 0),
        })
      );
    };
    // Waits for a pause in typing, so a long post isn't re-read on every key.
    const later = () => {
      clearTimeout(timer);
      timer = setTimeout(read, 400);
    };
    form.addEventListener("input", later);
    form.addEventListener("change", later);
    return () => {
      clearTimeout(timer);
      form.removeEventListener("input", later);
      form.removeEventListener("change", later);
    };
  }, [initial.hasCover]);

  const done = checks.filter((c) => c.ok).length;
  return (
    <section ref={anchor} className={panel}>
      <h2 className={panelTitle}>
        Ready to be found? <span className="font-normal text-zinc-500">{done} of {checks.length}</span>
      </h2>
      <ul className="flex flex-col gap-2">
        {checks.map((c) => (
          <li key={c.label} className="flex gap-2 text-sm">
            <Icon name={c.ok ? "circle-check" : "circle"} className={`mt-0.5 size-4 shrink-0 ${c.ok ? "text-green-700" : "text-zinc-300 dark:text-zinc-600"}`} />
            <span className="min-w-0">
              <span className={c.ok ? "text-zinc-500" : "font-medium"}>{c.label}</span>
              {!c.ok && <span className={`block ${hint}`}>{c.hint}</span>}
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}
