import Icon from "../Icon";

// The green "done" line and red "problem" line at the top of an admin page,
// fed by the ?notice= and ?error= an action redirects back with.
export default function Notice({ notice, error }: { notice?: string; error?: string }) {
  return (
    <>
      {notice && (
        <p role="status" className="rounded-lg bg-green-50 px-4 py-2 text-sm text-green-800 dark:bg-green-950/40 dark:text-green-300">
          <Icon name="circle-check" className="mr-1.5" />
          {notice}
        </p>
      )}
      {error && (
        <p role="alert" className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-800 dark:bg-red-950/40 dark:text-red-300">
          {error}
        </p>
      )}
    </>
  );
}
