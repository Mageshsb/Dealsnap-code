import { HUES, hueTheme } from "@/lib/category-theme";

// A category's colour: one tap on a swatch. Plain radio buttons, so it needs no script.
export default function HuePicker({ name, defaultValue }: { name: string; defaultValue: string }) {
  return (
    <div role="radiogroup" aria-label="Colour" className="flex flex-wrap gap-2">
      {HUES.map((hue) => (
        <label key={hue} className="relative cursor-pointer" title={hue}>
          <input type="radio" name={name} value={hue} defaultChecked={hue === defaultValue} className="peer sr-only" aria-label={hue} />
          <span
            className={`block size-8 rounded-full ${hueTheme(hue).swatch} ring-offset-2 ring-offset-white peer-checked:ring-2 peer-checked:ring-zinc-900 peer-focus-visible:ring-2 peer-focus-visible:ring-orange-500 dark:ring-offset-zinc-900 dark:peer-checked:ring-white`}
          />
        </label>
      ))}
    </div>
  );
}
