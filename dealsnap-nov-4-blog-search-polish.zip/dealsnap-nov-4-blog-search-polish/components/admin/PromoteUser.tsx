import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { findUserById } from "@/lib/db";
import { promoteUserAction } from "@/lib/admin-actions";
import { formatDate } from "@/lib/format";
import { getSiteSettings } from "@/lib/site-settings";
import Icon, { type IconName } from "@/components/Icon";

type Tier = "moderator" | "admin";

// Everything that differs between the two confirmation screens. The steps are
// the same; the colours and wording make clear which level of access this is.
const TIERS = {
  admin: {
    word: "an admin",
    icon: "wrench" as IconName,
    chip: "Admin access",
    headlineIcon: "warning" as IconName,
    headline: "This gives them full control of the site.",
    can: [
      "Approve, take down and permanently delete any deal or comment",
      "Suspend users and change site settings",
      "Make other people admins or moderators, with no limit",
    ],
    cannot: [] as string[],
    closing:
      "Only continue for someone you fully trust. You can remove their access afterwards, but not undo what they do.",
    understand: (name: string) => `I understand ${name} will have full admin access, including making other admins.`,
    box: "border-red-200 bg-red-50 text-red-900 dark:border-red-900 dark:bg-red-950/30 dark:text-red-200",
    chipStyle: "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400",
    focus: "focus:border-red-500",
    check: "accent-red-600",
    button: "bg-red-600 hover:bg-red-700",
  },
  moderator: {
    word: "a moderator",
    icon: "shield" as IconName,
    chip: "Moderator access",
    headlineIcon: "shield" as IconName,
    headline: "This gives them a limited set of moderation tools.",
    can: [
      "Approve, reject, take down and restore deals, and fix details on them",
      "Delete comments and dismiss reports",
      "Suspend and unsuspend regular members (never other staff)",
    ],
    cannot: [
      "Make anyone a moderator or admin",
      "Feature deals, choose the Deal of the Day or permanently delete deals",
      "Open Stores or Settings, or see members' email addresses",
    ],
    closing:
      "A good fit for a long-standing member you trust to use good judgement. You can remove their moderator access at any time.",
    understand: (name: string) =>
      `I understand ${name} will be able to moderate deals and comments and suspend regular members.`,
    box: "border-sky-200 bg-sky-50 text-sky-900 dark:border-sky-900 dark:bg-sky-950/30 dark:text-sky-200",
    chipStyle: "bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400",
    focus: "focus:border-sky-500",
    check: "accent-sky-600",
    button: "bg-sky-600 hover:bg-sky-700",
  },
} as const;

export default async function PromoteUser({
  params,
  searchParams,
  tier,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string }>;
  tier: Tier;
}) {
  const t = TIERS[tier];
  const { probationDays } = getSiteSettings();
  const { id } = await params;
  const { error } = await searchParams;
  const user = findUserById(id);
  if (!user) notFound();
  if (user.role === "admin" || user.role === tier) redirect("/admin/users");

  const input = `rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none lg:text-sm dark:border-zinc-700 dark:bg-zinc-900 ${t.focus}`;

  return (
    <div className="flex max-w-xl flex-col gap-5">
      <div>
        <Link
          href="/admin/users"
          className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline"
        >
          ← Back to members
        </Link>
        <h1 className="mt-2 flex flex-wrap items-center gap-2 text-xl font-bold sm:text-2xl">
          Make {user.username} {t.word}
          <span
            className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ${t.chipStyle}`}
          >
            <Icon name={t.icon} className="size-3.5" />
            {t.chip}
          </span>
        </h1>
        <p className="text-sm text-zinc-500">
          {user.email} · joined {formatDate(user.createdAt)}
        </p>
      </div>

      <div className={`rounded-xl border p-4 text-sm ${t.box}`}>
        <p className="font-semibold">
          <Icon name={t.headlineIcon} className="mr-1.5" />
          {t.headline}
        </p>
        <p className="mt-2 font-medium">They will be able to:</p>
        <ul className="mt-1 list-disc space-y-1 pl-5">
          {t.can.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
        {t.cannot.length > 0 && (
          <>
            <p className="mt-3 font-medium">They will not be able to:</p>
            <ul className="mt-1 list-disc space-y-1 pl-5">
              {t.cannot.map((line) => (
                <li key={line}>{line}</li>
              ))}
            </ul>
          </>
        )}
        <p className="mt-3">{t.closing}</p>
      </div>

      {user.suspended ? (
        <p className="rounded-lg bg-amber-50 px-4 py-3 text-sm text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
          This account is suspended. Unsuspend it first if you really want to make it {t.word}.
        </p>
      ) : (
        <form action={promoteUserAction} className="flex flex-col gap-4">
          <input type="hidden" name="userId" value={user.id} />
          <input type="hidden" name="role" value={tier} />

          {error && (
            <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
              {error}
            </p>
          )}

          <label className="flex items-start gap-3 text-sm">
            <input type="checkbox" name="understood" required className={`mt-1 h-4 w-4 ${t.check}`} />
            <span>{t.understand(user.username)}</span>
          </label>

          {tier === "moderator" && probationDays > 0 && (
            <label className="flex items-start gap-3 text-sm">
              <input type="checkbox" name="probation" defaultChecked className={`mt-1 h-4 w-4 ${t.check}`} />
              <span>
                Start with a {probationDays}-day probation. Everything they do is listed on your dashboard for you to
                check.
              </span>
            </label>
          )}

          <div className="flex flex-col gap-1">
            <label htmlFor="username" className="text-sm font-medium">
              Type <span className="rounded bg-zinc-100 px-1.5 py-0.5 font-mono dark:bg-zinc-800">{user.username}</span>{" "}
              to confirm
            </label>
            <input
              id="username"
              name="username"
              required
              autoComplete="off"
              autoCapitalize="off"
              spellCheck={false}
              className={input}
            />
          </div>

          <div className="flex flex-col gap-1">
            <label htmlFor="password" className="text-sm font-medium">
              Your password
            </label>
            <input
              id="password"
              name="password"
              type="password"
              required
              autoComplete="current-password"
              className={input}
            />
            <p className="text-xs text-zinc-500">Your own admin password, to prove it&apos;s really you.</p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="submit"
              className={`min-h-[44px] rounded-lg px-5 py-2 text-sm font-semibold text-white ${t.button}`}
            >
              Make {user.username} {t.word}
            </button>
            <Link href="/admin/users" className="text-sm text-zinc-500 hover:underline">
              Cancel
            </Link>
          </div>
        </form>
      )}
    </div>
  );
}
