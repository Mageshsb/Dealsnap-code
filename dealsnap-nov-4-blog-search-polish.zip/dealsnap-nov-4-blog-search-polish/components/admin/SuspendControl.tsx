import { setUserSuspendedAction } from "@/lib/admin-actions";
import { SUSPENSION_DURATIONS, suspensionReasons } from "@/lib/moderation";
import ReasonDialog from "./ReasonDialog";

const red =
  "min-h-[36px] rounded-lg border border-red-300 px-3.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/40";

// Suspend (asks why and for how long) or lift a suspension, for one member.
export default function SuspendControl({
  user,
  back = "/admin/users",
}: {
  user: { id: string; username: string; suspended: boolean };
  back?: string;
}) {
  return (
    <form action={setUserSuspendedAction}>
      <input type="hidden" name="userId" value={user.id} />
      <input type="hidden" name="back" value={back} />
      <input type="hidden" name="suspended" value={user.suspended ? "false" : "true"} />
      {user.suspended ? (
        <button type="submit" className={red}>
          Unsuspend
        </button>
      ) : (
        <ReasonDialog
          label="Suspend…"
          title={`Suspend ${user.username}`}
          intro="They're signed out straight away and shown this reason if they try to log in. They can appeal through the contact form."
          reasons={suspensionReasons()}
          durations={SUSPENSION_DURATIONS}
          confirmLabel="Suspend"
          buttonClassName={red}
        />
      )}
    </form>
  );
}
