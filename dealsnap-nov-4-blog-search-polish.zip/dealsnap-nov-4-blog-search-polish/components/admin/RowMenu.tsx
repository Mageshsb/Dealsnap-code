"use client";

import type { ReactNode } from "react";
import { createPortal } from "react-dom";
import { useAnchoredMenu } from "../useAnchoredMenu";

// A small "More ▾" popover for the less-used actions on a table row. The items
// are server-rendered forms/links passed in as children, so they keep working
// as plain form posts; this only handles opening and closing. The menu is
// drawn on top of the page (see useAnchoredMenu), so a phone's edge or the
// table around it can't cut it off. The menu closes itself once an item is
// used (the action carries on without it), and steps out of sight while a
// pop-up it opened (like "Take down…") is on screen, so it never hangs over it.
export default function RowMenu({ label = "More", children }: { label?: string; children: ReactNode }) {
  const { open, toggle, close, anchorRef, host, menuProps } = useAnchoredMenu<HTMLButtonElement>("right");

  return (
    <>
      <button
        ref={anchorRef}
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={toggle}
        className="inline-flex min-h-[36px] items-center gap-1 rounded-lg border border-zinc-300 px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
      >
        {label} <span aria-hidden>▾</span>
      </button>
      {open &&
        host &&
        createPortal(
          <div
            {...menuProps}
            role="menu"
            onSubmitCapture={() => setTimeout(close, 60)}
            className={`${menuProps.className} has-[dialog[open]]:invisible [&_dialog]:visible flex w-52 flex-col rounded-xl border border-zinc-200 bg-white py-1 shadow-lg dark:border-zinc-700 dark:bg-zinc-900 [&>form>button]:flex [&>form>button]:min-h-[40px] [&>form>button]:w-full [&>form>button]:items-center [&>form>button]:px-4 [&>form>button]:text-left [&>form>button]:text-sm [&>form>button]:no-underline [&>form>button]:hover:bg-zinc-100 dark:[&>form>button]:hover:bg-zinc-800 [&>a]:flex [&>a]:min-h-[40px] [&>a]:items-center [&>a]:px-4 [&>a]:text-sm [&>a]:no-underline [&>a]:hover:bg-zinc-100 dark:[&>a]:hover:bg-zinc-800`}
          >
            {children}
          </div>,
          host,
        )}
    </>
  );
}
