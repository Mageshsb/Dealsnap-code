import SectionTabs from "./SectionTabs";

const TABS = [
  { key: "overview", label: "Overview", href: "/admin/content" },
  { key: "strip", label: "Top strip", href: "/admin/banners" },
  { key: "promos", label: "Promos", href: "/admin/promos" },
  { key: "events", label: "Events", href: "/admin/events" },
] // The row at the top of every Site content page: the places on the site staff
// can put things in front of visitors, one tab each.
export default function ContentTabs({ current }: { current: (typeof TABS)[number]["key"] }) {
  return <SectionTabs label="Site content" tabs={TABS} current={current} />;
}
