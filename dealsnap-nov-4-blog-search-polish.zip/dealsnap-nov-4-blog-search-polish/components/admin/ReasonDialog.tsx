"use client";

import { ReactNode, useEffect, useRef, useState } from "react";
import Icon from "../Icon";

// A button that opens a small dialog asking WHY before a moderation action
// goes through. It must sit inside the <form> it submits: the reason, note and
// (optional) duration fields live in the dialog and post with that form.
// The dialog is only built the first time it's opened, so a list with a
// button on every row (Members, Deals, Comments) doesn't send a hidden form
// for each one.
export default function ReasonDialog({
  label,
  title,
  intro,
  reasons,
  durations,
  noteLabel = "Add a note (optional, shown to them)",
  noteRequired = false,
  confirmLabel,
  buttonClassName,
  tone = "red",
  children,
}: {
  label: ReactNode;
  title: string;
  intro?: string;
  reasons?: readonly string[];
  durations?: readonly { value: string; label: string }[];
  noteLabel?: string;
  noteRequired?: boolean;
  confirmLabel: string;
  buttonClassName?: string;
  tone?: "red" | "sky" | "green";
  children?: ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const [built, setBuilt] = useState(false);
  useEffect(() => {
    if (built) ref.current?.showModal();
  }, [built]);
  const confirmTone =
    tone === "sky"
      ? "bg-sky-600 hover:bg-sky-700"
      : tone === "green"
        ? "bg-green-700 hover:bg-green-800"
        : "bg-red-600 hover:bg-red-700";

  return (
    <>
      <button type="button" className={buttonClassName} onClick={() => (built ? ref.current?.showModal() : setBuilt(true))}>
        {label}
      </button>
      {built && (
        <dialog
          ref={ref}
          className="m-auto max-h-[calc(100dvh-2rem)] w-[min(28rem,calc(100vw-2rem))] overflow-hidden rounded-2xl border border-zinc-200 bg-white p-0 text-left text-zinc-900 shadow-xl backdrop:bg-black/40 open:flex open:flex-col dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
          onClick={(e) => {
            // Clicking the dim backdrop closes it, like other pop-ups on the site.
            if (e.target === ref.current) ref.current?.close();
          }}
        >
          {/* The questions scroll if the screen is short; Cancel and the confirm
              button stay in view underneath. */}
          <div className="flex min-h-0 flex-col gap-4 overflow-y-auto overscroll-contain p-5 pb-4">
            <div className="relative pr-8">
              <button
                type="button"
                aria-label="Close"
                tabIndex={-1}
                onClick={() => ref.current?.close()}
                className="absolute -right-2 -top-2 flex size-10 items-center justify-center rounded-full text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-zinc-800 dark:hover:text-zinc-200"
              >
                <Icon name="x" className="size-5" />
              </button>
              <h2 className="text-base font-semibold">{title}</h2>
              {intro && <p className="mt-1 text-sm text-zinc-500">{intro}</p>}
            </div>
            {children}
            {reasons && (
              <fieldset className="flex flex-col gap-1.5">
                <legend className="mb-1 text-sm font-medium">Reason</legend>
                {reasons.map((r, i) => (
                  <label
                    key={r}
                    className="flex min-h-[36px] items-center gap-2.5 rounded-lg px-2 text-sm hover:bg-zinc-50 dark:hover:bg-zinc-800"
                  >
                    <input
                      type="radio"
                      name="reason"
                      value={r}
                      required
                      defaultChecked={i === 0}
                      className="h-4 w-4 accent-orange-500"
                    />
                    {r}
                  </label>
                ))}
              </fieldset>
            )}
            {/* Radio buttons like the reasons above, so every choice shows at once. */}
            {durations && (
              <fieldset className="flex flex-col gap-1.5">
                <legend className="mb-1 text-sm font-medium">How long</legend>
                {durations.map((d, i) => (
                  <label
                    key={d.value}
                    className="flex min-h-[36px] items-center gap-2.5 rounded-lg px-2 text-sm hover:bg-zinc-50 dark:hover:bg-zinc-800"
                  >
                    <input
                      type="radio"
                      name="duration"
                      value={d.value}
                      required
                      defaultChecked={i === Math.min(2, durations.length - 1)}
                      className="h-4 w-4 accent-orange-500"
                    />
                    {d.label}
                  </label>
                ))}
              </fieldset>
            )}
            <label className="flex flex-col gap-1 text-sm font-medium">
              {noteLabel}
              <textarea
                name="note"
                rows={2}
                maxLength={500}
                required={noteRequired}
                className="rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base font-normal outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950"
              />
            </label>
          </div>
          <div className="flex shrink-0 flex-wrap justify-end gap-2 border-t border-zinc-100 px-5 py-3 dark:border-zinc-800">
            <button
              type="button"
              onClick={() => ref.current?.close()}
              className="min-h-[40px] rounded-lg border border-zinc-300 px-4 text-sm font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`min-h-[40px] rounded-lg px-4 text-sm font-semibold text-white ${confirmTone}`}
            >
              {confirmLabel}
            </button>
          </div>
        </dialog>
      )}
    </>
  );
}
