import Link from "next/link";
import SectionTabs from "./SectionTabs";
import type { ReactNode } from "react";
import Icon from "@/components/Icon";

const TABS = [
  { key: "overview", label: "Overview", href: "/admin/ads" },
  { key: "campaigns", label: "Campaigns", href: "/admin/ads/campaigns" },
  { key: "places", label: "Ad spaces", href: "/admin/ads/places" },
  { key: "advertisers", label: "Advertisers", href: "/admin/ads/advertisers" },
  { key: "selling", label: "Selling", href: "/admin/ads/selling" },
  { key: "network", label: "Ad network", href: "/admin/ads/network" },
] as const;

// The top of each Ads page: the section's name, the master switch's state (so
// nobody wonders why a live campaign isn't showing), the tabs, then the tab's
// own title, what it's for, its buttons and any message.
export default function AdsHeader({
  current,
  on,
  title,
  description,
  actions,
  notice,
  error,
}: {
  current: (typeof TABS)[number]["key"];
  on: boolean;
  title: string;
  description: ReactNode;
  actions?: ReactNode;
  notice?: string;
  error?: string;
}) {
  return (
    <>
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
        <h1 className="text-xl font-bold sm:text-2xl">Ads</h1>
        <span
          className={`rounded-full px-2 py-0.5 text-xs font-medium ${
            on ? "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400" : "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400"
          }`}
        >
          {on ? "Ads are on" : "Ads are off"}
        </span>
        {!on && current !== "overview" && current !== "places" && (
          <Link href="/admin/ads" className="text-xs text-zinc-500 underline hover:text-zinc-700 dark:hover:text-zinc-300">
            Nothing shows on the site until they&apos;re turned on (Overview)
          </Link>
        )}
      </div>
      <SectionTabs label="Ads" tabs={TABS} current={current} />
      <div className="flex flex-wrap items-end justify-between gap-x-4 gap-y-2">
        <div className="min-w-0 max-w-xl">
          <h2 className="font-semibold">{title}</h2>
          <p className="text-sm text-zinc-500">{description}</p>
        </div>
        {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
      </div>
      {notice && (
        <p className="rounded-lg bg-green-50 px-4 py-2 text-sm text-green-800 dark:bg-green-950/40 dark:text-green-300">
          <Icon name="circle-check" className="mr-1.5" />
          {notice}
        </p>
      )}
      {error && <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">{error}</p>}
    </>
  );
}
