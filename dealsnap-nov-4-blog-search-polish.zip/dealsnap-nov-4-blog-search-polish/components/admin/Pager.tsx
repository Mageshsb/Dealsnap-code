import Link from "next/link";

const button = "rounded-lg border border-zinc-300 px-3 py-1.5 dark:border-zinc-700";

// Previous / Next under every paged list in the admin area and the helper
// desk. `href` makes the address for a page number; the words can change
// where "newer" and "older" say it better (the activity log).
export default function Pager({
  page,
  totalPages,
  href,
  prev = "← Prev",
  next = "Next →",
}: {
  page: number;
  totalPages: number;
  href: (page: number) => string;
  prev?: string;
  next?: string;
}) {
  if (totalPages <= 1) return null;
  return (
    <nav aria-label="Pages" className="flex items-center justify-center gap-3 text-sm">
      <Link
        href={href(Math.max(1, page - 1))}
        aria-disabled={page === 1}
        className={`${button} ${page === 1 ? "pointer-events-none opacity-40" : "hover:bg-zinc-100 dark:hover:bg-zinc-800"}`}
      >
        {prev}
      </Link>
      <span className="text-zinc-500">
        Page {page} of {totalPages}
      </span>
      <Link
        href={href(Math.min(totalPages, page + 1))}
        aria-disabled={page === totalPages}
        className={`${button} ${page === totalPages ? "pointer-events-none opacity-40" : "hover:bg-zinc-100 dark:hover:bg-zinc-800"}`}
      >
        {next}
      </Link>
    </nav>
  );
}
