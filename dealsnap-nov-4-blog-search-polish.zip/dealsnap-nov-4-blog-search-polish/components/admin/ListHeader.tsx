import Link from "next/link";

// The title of an Admin list and the line under it: how many there are, and
// (once any filter is on) the one link that clears them all. Deals, Members,
// Comments and the other lists all say it the same way.
export default function ListHeader({
  title,
  count,
  noun,
  filtered,
  clearHref,
  intro,
  aside,
}: {
  title: string;
  count: number;
  noun: string; // singular, e.g. "deal"
  filtered: boolean;
  clearHref: string;
  // A sentence on what the list is, under the count.
  intro?: React.ReactNode;
  aside?: React.ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-x-4 gap-y-2">
      <div>
        <h1 className="text-xl font-bold sm:text-2xl">{title}</h1>
        <p className="text-sm text-zinc-500">
          {count.toLocaleString("en-GB")} {noun}
          {count === 1 ? "" : "s"}
          {filtered ? " matching your filters" : ""}.
          {filtered && (
            <>
              {" "}
              <Link href={clearHref} className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
                Clear all filters
              </Link>
            </>
          )}
        </p>
        {intro && <p className="mt-1 max-w-2xl text-sm text-zinc-500">{intro}</p>}
      </div>
      {aside}
    </div>
  );
}
