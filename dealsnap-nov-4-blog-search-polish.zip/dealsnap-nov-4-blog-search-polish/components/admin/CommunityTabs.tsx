import SectionTabs from "./SectionTabs";

// The row at the top of every Community page in the admin area: what needs
// attention (for moderators too), then the spaces and the limits (admins).
export default function CommunityTabs({ current, canManage }: { current: "overview" | "spaces" | "limits"; canManage: boolean }) {
  const tabs = [
    { key: "overview", label: "Overview", href: "/admin/community" },
    ...(canManage
      ? [
          { key: "spaces", label: "Spaces", href: "/admin/community/spaces" },
          { key: "limits", label: "Limits", href: "/admin/community/limits" },
        ]
      : []),
  ];
  return <SectionTabs label="Community" tabs={tabs} current={current} />;
}
