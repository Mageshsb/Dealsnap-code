import Link from "next/link";
import { postWelcomeThreadAction } from "@/lib/community-actions";
import { THREAD_BODY_MAX, TITLE_MAX, welcomeDefaults } from "@/lib/community-rules";
import { getWelcomeThread, type SpaceRow } from "@/lib/community-db";
import Icon from "../Icon";
import { field, hint, label, panel, panelTitle } from "./formStyles";

// One welcome thread per space, so nobody lands in an empty room. A space that
// has one shows it; one that hasn't shows a message already written for it, there
// to be changed and posted. It is posted under the admin's own name and pinned to
// the top of its space.
export default function WelcomeThreads({ spaces, who }: { spaces: SpaceRow[]; who: string }) {
  const open = spaces.filter((s) => !s.archived);
  const rows = open.map((space) => ({ space, thread: getWelcomeThread(space.id) }));
  const waiting = rows.filter((r) => !r.thread).length;
  return (
    <section id="welcome" className={`${panel} scroll-mt-24`}>
      <div>
        <h2 className={panelTitle}>Welcome threads</h2>
        <p className="mt-1 text-sm text-zinc-500">
          {waiting
            ? "A pinned first thread in each space, so a new visitor sees someone has said hello. Each is already written: change anything you like, then post it."
            : "Every space has its welcome thread."}{" "}
          They are posted under your name ({who}) and pinned to the top.
        </p>
      </div>
      <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
        {rows.map(({ space, thread }) => {
          const draft = welcomeDefaults(space);
          return (
            <li key={space.id} className="flex flex-col gap-2 py-3 first:pt-0 last:pb-0">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="flex min-w-0 items-center gap-2 text-sm font-semibold">
                  <Icon name={space.icon} className="size-4 shrink-0 text-orange-700 dark:text-orange-400" />
                  <span className="truncate">{space.name}</span>
                </span>
                {thread ? (
                  <span className="flex items-center gap-1.5 text-sm text-emerald-700 dark:text-emerald-400">
                    <Icon name="circle-check" className="size-4" />
                    Posted
                    <Link href={`/community/t/${thread.slug}`} className="font-medium text-orange-700 hover:underline dark:text-orange-400">
                      View
                    </Link>
                  </span>
                ) : null}
              </div>
              {thread ? (
                <p className="truncate text-sm text-zinc-500">&ldquo;{thread.title}&rdquo;</p>
              ) : (
                <details className="group">
                  <summary className="flex min-h-9 cursor-pointer list-none items-center gap-1 text-sm font-medium text-orange-700 dark:text-orange-400">
                    Read and post the welcome
                    <Icon name="chevron-down" className="size-4 transition-transform group-open:rotate-180" />
                  </summary>
                  <form action={postWelcomeThreadAction} className="flex flex-col gap-3 pt-2">
                    <input type="hidden" name="space" value={space.id} />
                    <label className={label}>
                      Title
                      <input name="title" required maxLength={TITLE_MAX} defaultValue={draft.title} className={field} />
                    </label>
                    <label className={label}>
                      Message
                      <textarea name="text" required rows={10} maxLength={THREAD_BODY_MAX} defaultValue={draft.text} className={`${field} resize-y`} />
                      <span className={hint}>Plain text. Start a line with a dash for a list.</span>
                    </label>
                    <div>
                      <button type="submit" className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600">
                        Post and pin
                      </button>
                    </div>
                  </form>
                </details>
              )}
            </li>
          );
        })}
      </ul>
    </section>
  );
}
