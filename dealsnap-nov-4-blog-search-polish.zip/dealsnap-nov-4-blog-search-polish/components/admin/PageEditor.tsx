"use client";

import Link from "next/link";
import { useActionState, useMemo, useState } from "react";
import Icon from "../Icon";
import Notice from "./Notice";
import ConfirmSubmitButton from "./ConfirmSubmitButton";
import { copyText } from "../VoucherCode";
import { field, hint, label, panel, panelTitle } from "./formStyles";
import { createPageAction, deletePageAction, resetPageAction, savePageAction, type PageFormState } from "@/lib/page-actions";
import { PAGE_LIMITS, PAGE_TOKENS } from "@/lib/page-text";
import StableLabel, { words } from "../StableLabel";

// Writing a footer page. A client component so that, when a check fails (a
// mistyped {placeholder}, a text that's too long), everything you typed is
// still here: a long page is never lost to a message.

export type EditablePage = {
  slug: string;
  kind: "doc" | "auto" | "code";
  format: "text" | "html";
  html: string;
  css: string;
  builtin: boolean;
  title: string;
  description: string;
  intro: string;
  summary: string;
  body: string;
  numbered: boolean;
  showUpdated: boolean;
  updatedOn: string;
  updatedLabel: string; // updatedOn as "1 November 2026"
  inFooter: boolean;
  footerLabel: string;
  published: boolean;
  href: string; // where the page lives
  hasOriginal: boolean; // a built-in page with wording to go back to
};

const FORMATTING: [string, string][] = [
  ["## Title", "a section. Add {#address} after the title to give it a link that never changes, e.g. ## Contact {#contact}"],
  ["### Heading", "a smaller heading inside a section"],
  ["- Point", "a bullet point"],
  ["1. Step", "a numbered list"],
  ["1. **Rule title**", "a numbered rule card: put its words on the next line, indented by two spaces. They're numbered on for you across the page"],
  ["**words**", "bold"],
  ["[words](https://…)", "a link (or /terms#moderation for a place on this site, or mailto:you@…)"],
  ["| A | B |", "a table of 2 or 3 columns, with | --- | --- | as its second line"],
];

const save = "rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60";
const check = "flex items-start gap-2 text-sm";

export default function PageEditor({ page, notice, error }: { page?: EditablePage; notice?: string; error?: string }) {
  const adding = !page;
  const [state, formAction, pending] = useActionState<PageFormState, FormData>(adding ? createPageAction : savePageAction, {});
  const [v, setV] = useState({
    title: page?.title ?? "",
    slug: "",
    description: page?.description ?? "",
    intro: page?.intro ?? "",
    summary: page?.summary ?? "",
    body: page?.body ?? "",
    footerLabel: page?.footerLabel ?? "",
    format: page?.format ?? ("text" as "text" | "html"),
    html: page?.html ?? "",
    css: page?.css ?? "",
    numbered: page?.numbered ?? false,
    showUpdated: page?.showUpdated ?? false,
    setToday: false,
    inFooter: page?.inFooter ?? true,
    published: page?.published ?? false,
  });
  const set = <K extends keyof typeof v>(key: K, value: (typeof v)[K]) => setV((p) => ({ ...p, [key]: value }));

  const kind = page?.kind ?? "doc";
  const custom = v.format === "html";
  const designed = kind === "code" && !custom; // About and Contact, unless they're given HTML
  const draft = !!page && !page.builtin && !page.published;

  return (
    <div className="flex max-w-6xl flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          <Link href="/admin/pages" className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline">
            ← Pages
          </Link>
          <h1 className="mt-2 text-xl font-bold sm:text-2xl">{adding ? "New page" : page.title}</h1>
          {page && (
            <p className="text-sm text-zinc-500">
              {page.href}
              {page.builtin ? " · built in" : draft ? " · draft" : " · live"}
            </p>
          )}
        </div>
        {page && (
          <Link
            href={page.href}
            target="_blank"
            className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-50 dark:border-zinc-700 dark:hover:bg-zinc-800"
          >
            {draft ? "Preview ↗" : "View page ↗"}
          </Link>
        )}
      </div>

      <Notice notice={notice} error={state.error ?? error} />

      <form action={formAction} className="grid grid-cols-1 items-start gap-5 lg:grid-cols-[minmax(0,1fr)_300px]">
        {page && <input type="hidden" name="slug" value={page.slug} />}

        <div className="flex min-w-0 flex-col gap-5">
          {kind === "auto" ? null : (
            <section className={panel}>
              <h2 className={panelTitle}>Page type</h2>
              <div role="radiogroup" className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                {(
                  [
                    ["text", kind === "code" ? "Built-in design" : "Text", kind === "code" ? "The page as it was designed, with its pictures and layout. Only its footer link is edited here." : "Write it with headings, lists and tables, and the site lays it out."],
                    ["html", "Custom HTML", "Paste in a page written as HTML and CSS, for example by Claude. It replaces the page's own layout."],
                  ] as const
                ).map(([value, name, about]) => (
                  <label
                    key={value}
                    className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3 text-sm ${
                      v.format === value ? "border-orange-400 bg-orange-50/60 dark:border-orange-700 dark:bg-orange-950/20" : "border-zinc-200 hover:border-zinc-300 dark:border-zinc-800"
                    }`}
                  >
                    <input type="radio" name="format" value={value} checked={v.format === value} onChange={() => set("format", value)} className="mt-0.5 size-4 accent-orange-500" />
                    <span>
                      <span className="block font-semibold">{name}</span>
                      <span className={`${hint} block`}>{about}</span>
                    </span>
                  </label>
                ))}
              </div>
            </section>
          )}

          {designed && (
            <section className={panel}>
              <h2 className={panelTitle}>This page has its own design</h2>
              <p className="text-sm text-zinc-600 dark:text-zinc-400">
                {page?.title} is a designed page (pictures, steps, its own layout).{" "}
                {page?.slug === "about" && (
                  <>
                    Its words are edited in{" "}
                    <Link href="/admin/wording?tab=about" className="text-orange-700 dark:text-orange-400 hover:underline">
                      Wording → About page
                    </Link>
                    .{" "}
                  </>
                )}
                You can change how it&apos;s
                linked in the footer, on the right, or choose Custom HTML above to replace it with a page of your own. The email addresses it shows come from{" "}
                <Link href="/admin/pages/company" className="text-orange-700 dark:text-orange-400 hover:underline">
                  Company details
                </Link>
                .
              </p>
            </section>
          )}

          {!designed && (
            <>
              {kind === "auto" && (
                <p className="rounded-lg bg-sky-50 px-4 py-3 text-sm text-sky-900 dark:bg-sky-950/30 dark:text-sky-200">
                  <Icon name="info" className="mr-1.5" />
                  The sections of this policy are written automatically from your Settings (cookies, analytics, ads, who your data is shared with), so it
                  always matches what the site really does. Anything you write below is added after them.
                </p>
              )}
              <section className={panel}>
                <label className={label}>
                  Title
                  <input
                    name="title"
                    required
                    maxLength={PAGE_LIMITS.title}
                    value={v.title}
                    onChange={(e) => set("title", e.target.value)}
                    className={`${field} text-lg! font-semibold`}
                  />
                </label>
                {adding && (
                  <label className={label}>
                    Address
                    <span className={hint}>Where the page will live. Leave empty to make it from the title. It can&apos;t be changed later.</span>
                    <span className="flex items-center gap-1 text-sm text-zinc-500">
                      /pages/
                      <input
                        name="slug"
                        maxLength={60}
                        value={v.slug}
                        onChange={(e) => set("slug", e.target.value)}
                        placeholder="how-we-make-money"
                        className={`${field} max-w-xs`}
                      />
                    </span>
                  </label>
                )}
                <div className={custom ? "hidden" : "contents"}>
                  <label className={label}>
                    Line under the title
                    <span className={hint}>One short sentence, like “The rules for using DealSnap, in plain English.”</span>
                    <input name="intro" maxLength={PAGE_LIMITS.intro} value={v.intro} onChange={(e) => set("intro", e.target.value)} className={field} />
                  </label>
                </div>
                <label className={label}>
                  Description for Google
                  <span className={hint}>What search results show under the page&apos;s name. About one sentence; empty is fine.</span>
                  <textarea
                    name="description"
                    rows={2}
                    maxLength={PAGE_LIMITS.description}
                    value={v.description}
                    onChange={(e) => set("description", e.target.value)}
                    className={field}
                  />
                </label>
              </section>

              {kind === "doc" && (
                <section className={custom ? "hidden" : panel}>
                  <label className={label}>
                    The short version (optional)
                    <span className={hint}>A summary box at the top. One point per line, starting with “- ”.</span>
                    <textarea
                      name="summary"
                      rows={5}
                      maxLength={PAGE_LIMITS.summary}
                      value={v.summary}
                      onChange={(e) => set("summary", e.target.value)}
                      className={`${field} font-mono text-[13px]! leading-relaxed`}
                    />
                  </label>
                </section>
              )}

              <section className={custom ? "hidden" : panel}>
                <div className="flex flex-col gap-1">
                  <label htmlFor="body" className="text-sm font-medium">
                    {kind === "auto" ? "Your own sections (added at the end)" : "The text"}
                  </label>
                  <span className={hint}>
                    Start each section with “## ” and its title. Leave a blank line between paragraphs.{" "}
                    {(v.body.length / 1000).toFixed(1)}k of {PAGE_LIMITS.body / 1000}k characters.
                  </span>
                </div>
                <textarea
                  id="body"
                  name="body"
                  rows={28}
                  value={v.body}
                  onChange={(e) => set("body", e.target.value)}
                  spellCheck
                  className={`${field} font-mono text-[13px]! leading-relaxed`}
                />
                <details className="rounded-lg bg-zinc-50 px-3 py-2 text-sm dark:bg-zinc-950">
                  <summary className="cursor-pointer font-medium">How to format</summary>
                  <dl className="mt-2 grid grid-cols-1 gap-x-4 gap-y-1.5 sm:grid-cols-[auto_1fr]">
                    {FORMATTING.map(([mark, what]) => (
                      <div key={mark} className="contents">
                        <dt>
                          <code className="rounded bg-white px-1.5 py-0.5 text-xs dark:bg-zinc-800">{mark}</code>
                        </dt>
                        <dd className="text-xs text-zinc-500">{what}</dd>
                      </div>
                    ))}
                  </dl>
                  <p className="mt-3 text-xs font-medium">Details you can drop in</p>
                  <p className="text-xs text-zinc-500">
                    Type one in curly brackets and it&apos;s filled in from{" "}
                    <Link href="/admin/pages/company" className="text-orange-700 dark:text-orange-400 hover:underline">
                      Company details
                    </Link>
                    . If a detail isn&apos;t set, the paragraph or point that mentions it is left out, so there are never gaps.
                  </p>
                  <dl className="mt-1.5 grid grid-cols-1 gap-x-4 gap-y-1 sm:grid-cols-[auto_1fr]">
                    {PAGE_TOKENS.map((t) => (
                      <div key={t.name} className="contents">
                        <dt>
                          <code className="rounded bg-white px-1.5 py-0.5 text-xs dark:bg-zinc-800">{`{${t.name}}`}</code>
                        </dt>
                        <dd className="text-xs text-zinc-500">{t.help}</dd>
                      </div>
                    ))}
                  </dl>
                </details>
              </section>
            </>
          )}

          <div className={custom && !designed ? "contents" : "hidden"}>
            <HtmlPanel html={v.html} css={v.css} onHtml={(x) => set("html", x)} onCss={(x) => set("css", x)} />
          </div>
        </div>

        <div className="flex min-w-0 flex-col gap-5">
          <section className={panel}>
            <h2 className={panelTitle}>In the footer</h2>
            <label className={check}>
              <input type="checkbox" name="inFooter" value="1" checked={v.inFooter} onChange={(e) => set("inFooter", e.target.checked)} className="mt-0.5 size-4 accent-orange-500" />
              <span>Link to this page in the footer</span>
            </label>
            <label className={label}>
              Footer wording
              <span className={hint}>One or two words. Empty uses the title.</span>
              <input name="footerLabel" maxLength={PAGE_LIMITS.footerLabel} value={v.footerLabel} onChange={(e) => set("footerLabel", e.target.value)} placeholder={v.title || "Title"} className={field} />
            </label>
            {!page?.builtin && (
              <label className={check}>
                <input type="checkbox" name="published" value="1" checked={v.published} onChange={(e) => set("published", e.target.checked)} className="mt-0.5 size-4 accent-orange-500" />
                <span>
                  Published
                  <span className={`${hint} block`}>Untick to keep it as a draft that only owners can open.</span>
                </span>
              </label>
            )}
            <p className={hint}>The order of the footer links is set on the Pages list, with the arrows.</p>
          </section>

          {!designed && !custom && (
            <section className={panel}>
              <h2 className={panelTitle}>Dates and numbering</h2>
              <label className={check}>
                <input type="checkbox" name="showUpdated" value="1" checked={v.showUpdated} onChange={(e) => set("showUpdated", e.target.checked)} className="mt-0.5 size-4 accent-orange-500" />
                <span>Show “Last updated” under the title</span>
              </label>
              {v.showUpdated && (
                <label className={check}>
                  <input type="checkbox" name="setToday" value="1" checked={v.setToday} onChange={(e) => set("setToday", e.target.checked)} className="mt-0.5 size-4 accent-orange-500" />
                  <span>
                    Set it to today when I save
                    <span className={`${hint} block`}>
                      {page?.updatedLabel ? `Now ${page.updatedLabel}. ` : ""}Tick this for changes that alter what the page means, not for a typo.
                    </span>
                  </span>
                </label>
              )}
              {kind === "doc" && (
                <label className={check}>
                  <input type="checkbox" name="numbered" value="1" checked={v.numbered} onChange={(e) => set("numbered", e.target.checked)} className="mt-0.5 size-4 accent-orange-500" />
                  <span>Number the section titles (1, 2, 3…)</span>
                </label>
              )}
            </section>
          )}

          <div className="flex flex-wrap items-center gap-3">
            <button type="submit" disabled={pending} className={save}>
              {pending ? "Saving…" : adding ? "Add page" : "Save"}
            </button>
          </div>
        </div>
      </form>

      {page && (
        <div className="flex flex-wrap items-center gap-3 border-t border-zinc-200 pt-4 dark:border-zinc-800">
          {page.hasOriginal && (page.kind !== "code" || page.format === "html") && (
            <form action={resetPageAction}>
              <input type="hidden" name="slug" value={page.slug} />
              <ConfirmSubmitButton
                confirmText={
                  page.kind === "code"
                    ? "Put this page back to its built-in design? The HTML and CSS you pasted in will be lost. Its footer settings stay."
                    : "Put this page's title, intro and text back to what the site started with? Your changes to them, and any HTML you pasted in, will be lost. Its footer settings stay."
                }
                confirmLabel="Yes, go back"
                className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-50 dark:border-zinc-700 dark:hover:bg-zinc-800"
              >
                {page.kind === "code" ? "Back to the built-in design" : "Back to the original wording"}
              </ConfirmSubmitButton>
            </form>
          )}
          {!page.builtin && (
            <form action={deletePageAction}>
              <input type="hidden" name="slug" value={page.slug} />
              <ConfirmSubmitButton
                confirmText={`Delete “${page.title}”? Its address stops working and it leaves the footer. This can't be undone.`}
                confirmLabel="Yes, delete it"
                className="rounded-full border border-red-300 px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/30"
              >
                Delete page
              </ConfirmSubmitButton>
            </form>
          )}
        </div>
      )}
    </div>
  );
}

const CLAUDE_PROMPT = `Write me a web page as plain HTML and CSS. Give me the HTML and the CSS as two separate code blocks.

Rules:
- No JavaScript, no forms or buttons (use links), and no external fonts, libraries or stylesheets.
- Start straight with the page content: no <html>, <head> or <body> tags.
- Make it work well on phones, and in dark mode with @media (prefers-color-scheme: dark).
- Where the contact form should go, put [[contact-form]] on a line of its own between sections, not inside another element.
- These details are filled in by the site; write them in curly brackets: {operator}, {operatorLine}, {companyNumber}, {address}, {supportEmail}, {privacyEmail}, {partnersEmail}, {minAge}.

The page is about: `;

// The "Custom HTML" page type: the HTML and CSS boxes, and a preview of them.
function HtmlPanel({ html, css, onHtml, onCss }: { html: string; css: string; onHtml: (v: string) => void; onCss: (v: string) => void }) {
  const [width, setWidth] = useState<"phone" | "computer">("computer");
  const [copied, setCopied] = useState(false);
  // Sandboxed with nothing allowed: whatever is pasted can't run code here or reach the admin.
  const preview = useMemo(
    () =>
      `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><base target="_blank"><style>html{font-family:system-ui,sans-serif;line-height:1.5;color:#171717}body{margin:16px}img{max-width:100%}${css.replace(/<\/style/gi, "")}</style>${html}`,
    [html, css]
  );
  const code = `${field} font-mono text-[13px]! leading-relaxed`;
  return (
    <section className={panel}>
      <div className="flex flex-col gap-1">
        <h2 className={panelTitle}>The page</h2>
        <p className={hint}>
          Paste the HTML and the CSS into the two boxes. Scripts, forms, frames and anything that could run code are left out when it&apos;s saved, and the CSS
          only ever applies to this page. The page sits in the site&apos;s usual width, under the header.
        </p>
      </div>
      <label className={label}>
        HTML
        <span className={hint}>{(html.length / 1000).toFixed(1)}k of {PAGE_LIMITS.html / 1000}k characters.</span>
        <textarea name="html" rows={16} value={html} onChange={(e) => onHtml(e.target.value)} spellCheck={false} className={code} placeholder="<section>…</section>" />
      </label>
      <label className={label}>
        CSS
        <span className={hint}>{(css.length / 1000).toFixed(1)}k of {PAGE_LIMITS.css / 1000}k characters. Optional if the HTML has its own &lt;style&gt;.</span>
        <textarea name="css" rows={10} value={css} onChange={(e) => onCss(e.target.value)} spellCheck={false} className={code} placeholder=".hero { … }" />
      </label>

      <div className="flex flex-col gap-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-sm font-medium">Preview</span>
          <div className="flex rounded-lg border border-zinc-300 p-0.5 text-xs font-semibold dark:border-zinc-700">
            {(["computer", "phone"] as const).map((w) => (
              <button
                key={w}
                type="button"
                onClick={() => setWidth(w)}
                className={`rounded-md px-3 py-1 ${width === w ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900" : "text-zinc-600 dark:text-zinc-400"}`}
              >
                {w === "phone" ? "Phone" : "Computer"}
              </button>
            ))}
          </div>
        </div>
        <div className="overflow-x-auto rounded-lg border border-zinc-200 bg-white dark:border-zinc-800">
          <iframe title="Preview of the page" sandbox="" srcDoc={preview} className="block h-[28rem] bg-white" style={{ width: width === "phone" ? 375 : "100%", maxWidth: "100%" }} />
        </div>
        <p className={hint}>A quick look only. On the site the page also gets the header, footer and your {"{details}"}, and the saved version has anything unsafe removed.</p>
      </div>

      <details className="rounded-lg bg-zinc-50 px-3 py-2 text-sm dark:bg-zinc-950">
        <summary className="cursor-pointer font-medium">Asking Claude to write one</summary>
        <p className="mt-2 text-xs text-zinc-500">Copy this, add what the page is about at the end, and paste the HTML and CSS it gives you into the boxes above.</p>
        <textarea readOnly value={CLAUDE_PROMPT} rows={11} onFocus={(e) => e.currentTarget.select()} className={`${field} mt-2 font-mono text-xs!`} />
        <button
          type="button"
          onClick={async () => {
            if (await copyText(CLAUDE_PROMPT)) {
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            }
          }}
          className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-orange-500 px-3 py-2 text-xs font-semibold text-white hover:bg-orange-600"
        >
          <Icon name={copied ? "check" : "copy"} className="size-3.5" />
          <StableLabel options={words("Copy", "Copied")} show={copied ? "Copied" : "Copy"} />
        </button>
        <p className="mt-3 text-xs font-medium">Details you can drop in</p>
        <p className="text-xs text-zinc-500">
          Written in curly brackets, filled in from{" "}
          <Link href="/admin/pages/company" className="text-orange-700 dark:text-orange-400 hover:underline">
            Company details
          </Link>
          . Use them in links too, like <code>href=&quot;mailto:{"{supportEmail}"}&quot;</code>.
        </p>
        <dl className="mt-1.5 grid grid-cols-1 gap-x-4 gap-y-1 sm:grid-cols-[auto_1fr]">
          {PAGE_TOKENS.map((t) => (
            <div key={t.name} className="contents">
              <dt>
                <code className="rounded bg-white px-1.5 py-0.5 text-xs dark:bg-zinc-800">{`{${t.name}}`}</code>
              </dt>
              <dd className="text-xs text-zinc-500">{t.help}</dd>
            </div>
          ))}
        </dl>
      </details>
    </section>
  );
}
