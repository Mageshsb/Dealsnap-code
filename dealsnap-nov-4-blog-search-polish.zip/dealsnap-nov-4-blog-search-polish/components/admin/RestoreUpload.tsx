"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Icon from "../Icon";
import { sizeLabel } from "@/lib/backup-limits";

// Sends a downloaded backup file to the server (app/restore-upload/route.ts) and,
// once it's been checked, goes on to the confirmation page. A plain request so it
// can show progress: backups can be large.
export default function RestoreUpload({ maxBytes }: { maxBytes: number }) {
  const router = useRouter();
  const input = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [percent, setPercent] = useState<number | null>(null);
  const [error, setError] = useState("");
  const busy = percent !== null;

  function send() {
    if (!file) return;
    if (file.size > maxBytes) {
      setError(`That file is too big (the limit is ${sizeLabel(maxBytes)}).`);
      return;
    }
    setError("");
    setPercent(0);
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/restore-upload");
    xhr.setRequestHeader("x-dealsnap-upload", "1");
    xhr.setRequestHeader("content-type", "application/octet-stream");
    xhr.upload.onprogress = (e) => e.lengthComputable && setPercent(Math.min(99, Math.round((e.loaded / e.total) * 100)));
    xhr.onerror = () => {
      setPercent(null);
      setError("The upload couldn't be sent. Check your connection and try again.");
    };
    xhr.onload = () => {
      let message = "";
      try {
        message = (JSON.parse(xhr.responseText) as { error?: string }).error ?? "";
      } catch {
        // Not JSON: something in front of the site answered (a size limit, say).
        message = xhr.status === 413 ? "The host refused a file that big. See the note below." : "";
      }
      if (xhr.status >= 200 && xhr.status < 300) router.push("/admin/restore?from=upload");
      else {
        setPercent(null);
        setError(message || "The upload didn't work. Try again.");
      }
    };
    xhr.send(file);
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <input
          ref={input}
          type="file"
          accept=".db,application/octet-stream"
          className="sr-only"
          tabIndex={-1}
          onChange={(e) => {
            setFile(e.target.files?.[0] ?? null);
            setError("");
          }}
        />
        <button
          type="button"
          disabled={busy}
          onClick={() => input.current?.click()}
          className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-100 disabled:opacity-60 dark:border-zinc-700 dark:hover:bg-zinc-800"
        >
          <Icon name="upload" className="mr-1.5" />
          Choose a backup file
        </button>
        {file && (
          <>
            <span className="min-w-0 truncate text-sm text-zinc-600 dark:text-zinc-300">
              {file.name} <span className="text-zinc-500 dark:text-zinc-400">· {(file.size / 1048576).toFixed(1)}MB</span>
            </span>
            <button
              type="button"
              disabled={busy}
              onClick={send}
              className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60"
            >
              {busy ? (percent >= 99 ? "Checking…" : `Uploading ${percent}%`) : "Upload and check"}
            </button>
          </>
        )}
      </div>
      {busy && (
        <div className="h-1.5 w-full max-w-sm overflow-hidden rounded-full bg-zinc-200 dark:bg-zinc-800" role="progressbar" aria-valuenow={percent} aria-valuemin={0} aria-valuemax={100}>
          <div className="h-full bg-orange-500 transition-[width]" style={{ width: `${percent}%` }} />
        </div>
      )}
      {error && (
        <p role="alert" className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-800 dark:bg-red-950/40 dark:text-red-300">
          {error}
        </p>
      )}
    </div>
  );
}
