import type { BannerState } from "@/lib/banners";

const LOOK: Record<BannerState, { label: string; style: string }> = {
  off: { label: "Not showing", style: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400" },
  scheduled: { label: "Live, starts later", style: "bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400" },
  live: { label: "Showing now", style: "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400" },
  ended: { label: "Ended", style: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400" },
};

// Where a banner stands, as a small pill.
export default function BannerStatePill({ state }: { state: BannerState }) {
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${LOOK[state].style}`}>{LOOK[state].label}</span>
  );
}
