"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { changeThreadAction, deleteThreadForeverAction, dismissPostReportsAction, muteMemberAction, removePostAction, unmuteMemberAction } from "@/lib/community-actions";

const button = "min-h-9 rounded-lg border px-3 py-1.5 text-xs font-medium disabled:opacity-60";
const quiet = "border-zinc-300 text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800";

// The buttons under a post in the moderation queue. Each one does what it
// says and the row goes; every one is logged under the moderator's name.
export function QueuePostActions({ postId, userId, canMute }: { postId: string; userId: string; canMute: boolean }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [asking, setAsking] = useState(false);
  const [failed, setFailed] = useState(false);

  function run(work: () => Promise<boolean>) {
    setFailed(false);
    startTransition(async () => {
      if (await work()) router.refresh();
      else setFailed(true);
    });
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      {asking ? (
        <>
          <span className="text-xs text-zinc-500">Remove it? It&apos;s logged.</span>
          <button type="button" disabled={pending} onClick={() => run(() => removePostAction(postId))} className={`${button} border-red-600 bg-red-600 text-white hover:bg-red-700`}>
            {pending ? "Removing…" : "Yes, remove"}
          </button>
          <button type="button" onClick={() => setAsking(false)} className={`${button} ${quiet}`}>
            Cancel
          </button>
        </>
      ) : (
        <>
          {/* "Looks fine" clears the reports, and brings back a post a helper hid. */}
          <button type="button" disabled={pending} onClick={() => run(() => dismissPostReportsAction(postId))} className={`${button} ${quiet}`}>
            Looks fine
          </button>
          <button type="button" onClick={() => setAsking(true)} className={`${button} border-red-300 text-red-700 hover:bg-red-50 dark:border-red-900 dark:text-red-400 dark:hover:bg-red-950/40`}>
            Remove
          </button>
          {canMute && (
            <button type="button" disabled={pending} onClick={() => run(() => muteMemberAction(userId, 7, "Please take a break and read the guidelines."))} className={`${button} ${quiet}`}>
              Mute 7 days
            </button>
          )}
        </>
      )}
      {failed && <span className="text-xs text-amber-700 dark:text-amber-400">That didn&apos;t work. It may already have been dealt with.</span>}
    </div>
  );
}

// A first thread waiting for a check: let it through, or take it down.
export function HeldThreadActions({ threadId, postId }: { threadId: string; postId: string }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  return (
    <div className="flex flex-wrap gap-2">
      <button
        type="button"
        disabled={pending}
        onClick={() =>
          startTransition(async () => {
            if (await changeThreadAction(threadId, "approve")) router.refresh();
          })
        }
        className={`${button} border-green-700 bg-green-700 text-white hover:bg-green-800`}
      >
        Let it through
      </button>
      <button
        type="button"
        disabled={pending}
        onClick={() =>
          startTransition(async () => {
            if (await removePostAction(postId)) router.refresh();
          })
        }
        className={`${button} border-red-300 text-red-700 hover:bg-red-50 dark:border-red-900 dark:text-red-400 dark:hover:bg-red-950/40`}
      >
        Remove
      </button>
    </div>
  );
}

export function UnmuteButton({ userId }: { userId: string }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  return (
    <button
      type="button"
      disabled={pending}
      onClick={() =>
        startTransition(async () => {
          if (await unmuteMemberAction(userId)) router.refresh();
        })
      }
      className={`${button} ${quiet}`}
    >
      {pending ? "Working…" : "Let back in"}
    </button>
  );
}

// A removed thread: bring it back, or (owners) delete it for good after one more question.
export function RemovedThreadActions({ threadId, posts, canDelete }: { threadId: string; posts: number; canDelete: boolean }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [asking, setAsking] = useState(false);
  const [failed, setFailed] = useState(false);
  return (
    <div className="flex flex-wrap items-center gap-2">
      {asking ? (
        <>
          <span className="text-xs text-zinc-500">
            Delete it and its {posts === 1 ? "post" : `${posts} posts`} for good? This can&apos;t be undone.
          </span>
          <button
            type="button"
            disabled={pending}
            onClick={() =>
              startTransition(async () => {
                if (await deleteThreadForeverAction(threadId)) router.refresh();
                else setFailed(true);
              })
            }
            className={`${button} border-red-600 bg-red-600 text-white hover:bg-red-700`}
          >
            {pending ? "Deleting…" : "Yes, delete it"}
          </button>
          <button type="button" onClick={() => setAsking(false)} className={`${button} ${quiet}`}>
            Cancel
          </button>
        </>
      ) : (
        <>
          <button
            type="button"
            disabled={pending}
            onClick={() =>
              startTransition(async () => {
                if (await changeThreadAction(threadId, "restore")) router.refresh();
                else setFailed(true);
              })
            }
            className={`${button} ${quiet}`}
          >
            Restore
          </button>
          {canDelete && (
            <button type="button" onClick={() => setAsking(true)} className={`${button} border-red-300 text-red-700 hover:bg-red-50 dark:border-red-900 dark:text-red-400 dark:hover:bg-red-950/40`}>
              Delete permanently
            </button>
          )}
        </>
      )}
      {failed && <span className="text-xs text-amber-700 dark:text-amber-400">That didn&apos;t work. It may already have been dealt with.</span>}
    </div>
  );
}
