"use client";

import { useActionState, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { archiveSpaceAction, moveSpaceAction, saveSpaceAction, type SpaceFormState } from "@/lib/community-actions";
import { SPACE_BLURB_MAX, SPACE_KINDS, SPACE_NAME_MAX, SPACE_RULES_MAX, SPACE_WHO, type SpaceKind, type SpaceWho } from "@/lib/community-rules";
import type { SpaceRow } from "@/lib/community-db";
import IconPicker from "./IconPicker";
import SelectField from "../SelectField";
import Icon from "../Icon";
import { field, hint, label } from "./formStyles";

// One space's settings (or, with no `space`, a new one): name, a line about it,
// its rules, whether it takes questions, who may start threads, and its icon.
export function SpaceForm({ space, onDone }: { space?: SpaceRow; onDone?: () => void }) {
  const router = useRouter();
  const [state, action, pending] = useActionState<SpaceFormState, FormData>(async (prev, formData) => {
    const result = await saveSpaceAction(prev, formData);
    if (result.saved) {
      router.refresh();
      onDone?.();
    }
    return result;
  }, {});
  const [kind, setKind] = useState<SpaceKind>(space?.kind ?? "talk");
  const [who, setWho] = useState<SpaceWho>(space?.who ?? "members");

  return (
    <form action={action} className="flex flex-col gap-4">
      {space && <input type="hidden" name="id" value={space.id} />}
      {state.error && (
        <p role="alert" className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200">
          {state.error}
        </p>
      )}
      <label className={label}>
        Name
        <input name="name" required maxLength={SPACE_NAME_MAX} defaultValue={space?.name} className={field} />
      </label>
      <label className={label}>
        A line about it
        <input name="blurb" maxLength={SPACE_BLURB_MAX} defaultValue={space?.blurb} className={field} />
        <span className={hint}>Shown under the name on the Community home.</span>
      </label>
      <label className={label}>
        Rules for this space
        <textarea name="rules" rows={3} maxLength={SPACE_RULES_MAX} defaultValue={space?.rules} className={`${field} resize-y`} />
        <span className={hint}>Shown to members when they start a thread here, and at the top of the space. Leave empty for none.</span>
      </label>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className={label}>
          What kind of space
          <SelectField look="admin" name="kind" label="What kind of space" value={kind} onChange={(v) => setKind(v as SpaceKind)} options={SPACE_KINDS.map((k) => ({ value: k.value, label: k.label }))} />
          <span className={hint}>{SPACE_KINDS.find((k) => k.value === kind)?.hint}</span>
        </div>
        <div className={label}>
          Who can start a thread
          <SelectField look="admin" name="who" label="Who can start a thread" value={who} onChange={(v) => setWho(v as SpaceWho)} options={SPACE_WHO.map((k) => ({ value: k.value, label: k.label }))} />
          <span className={hint}>Anyone confirmed can always reply.</span>
        </div>
      </div>
      <div className={label}>
        Icon
        <IconPicker name="icon" defaultValue={space?.icon ?? "comment"} />
      </div>
      <div className="flex justify-end">
        <button type="submit" disabled={pending} className="min-h-10 rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60">
          {pending ? "Saving…" : space ? "Save space" : "Add space"}
        </button>
      </div>
    </form>
  );
}

// Up, down and archive for one space, outside its edit form.
export function SpaceControls({ space, first, last, threads }: { space: SpaceRow; first: boolean; last: boolean; threads: number }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState("");
  const round = "flex size-9 items-center justify-center rounded-lg border border-zinc-300 text-zinc-600 hover:bg-zinc-100 disabled:opacity-30 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800";
  return (
    <div className="flex flex-wrap items-center gap-2">
      <button type="button" aria-label={`Move ${space.name} up`} disabled={first || pending} onClick={() => startTransition(async () => { await moveSpaceAction(space.id, "up"); router.refresh(); })} className={round}>
        <Icon name="arrow-up" className="size-4" />
      </button>
      <button type="button" aria-label={`Move ${space.name} down`} disabled={last || pending} onClick={() => startTransition(async () => { await moveSpaceAction(space.id, "down"); router.refresh(); })} className={round}>
        <Icon name="arrow-down" className="size-4" />
      </button>
      <button
        type="button"
        disabled={pending}
        onClick={() =>
          startTransition(async () => {
            const problem = await archiveSpaceAction(space.id, !space.archived);
            if (problem) setError(problem);
            else router.refresh();
          })
        }
        className="min-h-9 rounded-lg border border-zinc-300 px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-100 disabled:opacity-60 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
      >
        {space.archived ? "Bring back" : "Archive"}
      </button>
      {!space.archived && threads > 0 && <span className="text-xs text-zinc-500 dark:text-zinc-400">Archiving hides its {threads} {threads === 1 ? "thread" : "threads"}; nothing is deleted.</span>}
      {error && <span className="text-xs text-amber-700 dark:text-amber-400">{error}</span>}
    </div>
  );
}

// "Add a space": a button that opens the empty form.
export function AddSpace() {
  const [open, setOpen] = useState(false);
  if (!open) {
    return (
      <button type="button" onClick={() => setOpen(true)} className="flex min-h-10 items-center gap-1.5 self-start rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
        <Icon name="plus" className="size-4" />
        Add a space
      </button>
    );
  }
  return (
    <div className="tell-us-in flex flex-col gap-3 rounded-2xl border border-orange-300 bg-white p-4 dark:border-orange-900 dark:bg-zinc-900 sm:p-5">
      <h2 className="text-sm font-bold uppercase tracking-wide text-zinc-500">New space</h2>
      <SpaceForm onDone={() => setOpen(false)} />
      <button type="button" onClick={() => setOpen(false)} className="self-start text-sm text-zinc-500 hover:underline">
        Cancel
      </button>
    </div>
  );
}
