"use client";

import { useEffect, useRef, useState } from "react";
import { AdBox, AdRow, AdStrip, AdTallCard, AdTower } from "@/components/AdCreative";
import type { AdCreative } from "@/lib/ads";

// A live look at the ad in every space it can go, drawn by the very
// components the site uses, as the words and pictures are changed. It reads
// the form it sits in (pictures included), so it keeps no state of its own
// in step with the fields.
export default function AdPreview({ currentImage, currentLogo }: { currentImage?: string; currentLogo?: string }) {
  const root = useRef<HTMLDivElement>(null);
  const [ad, setAd] = useState<AdCreative>({
    id: "preview",
    advertiser: "",
    headline: "",
    ctaLabel: "",
    imageUrl: currentImage,
    logoUrl: currentLogo,
    internal: false,
  });

  useEffect(() => {
    const form = root.current?.closest("form");
    if (!form) return;
    const urls: Record<"image" | "logo", string> = { image: "", logo: "" };
    const picture = (data: FormData, slot: "image" | "logo", current?: string) => {
      const file = data.get(slot);
      if (urls[slot]) URL.revokeObjectURL(urls[slot]);
      urls[slot] = file instanceof File && file.size > 0 ? URL.createObjectURL(file) : "";
      return urls[slot] || (data.get(`remove-${slot}`) === "on" ? undefined : current);
    };
    const read = () => {
      const data = new FormData(form);
      const text = (name: string) => String(data.get(name) ?? "").trim();
      setAd({
        id: "preview",
        advertiser: text("shownName") || "Advertiser",
        headline: text("headline") || "Your headline appears here",
        body: text("body") || undefined,
        ctaLabel: text("ctaLabel") || "Shop now",
        imageUrl: picture(data, "image", currentImage),
        logoUrl: picture(data, "logo", currentLogo),
        internal: false,
      });
    };
    read();
    form.addEventListener("input", read);
    form.addEventListener("change", read);
    return () => {
      form.removeEventListener("input", read);
      form.removeEventListener("change", read);
      for (const u of Object.values(urls)) if (u) URL.revokeObjectURL(u);
    };
  }, [currentImage, currentLogo]);

  const caption = "text-xs font-medium text-zinc-500";
  return (
    <div ref={root} className="flex flex-col gap-4 rounded-xl bg-zinc-100 p-3 sm:p-4 dark:bg-zinc-950">
      <div className="flex max-w-[360px] flex-col gap-1.5">
        <span className={caption}>In the lists, and Standard on deal pages and articles (a phone)</span>
        <AdRow ad={ad} />
      </div>
      <div className="flex flex-col gap-1.5">
        <span className={caption}>Compact on deal pages and articles (a phone, then a laptop)</span>
        <div className="max-w-[360px]">
          <AdStrip ad={ad} />
        </div>
        <div className="max-w-[640px]">
          <AdStrip ad={ad} />
        </div>
      </div>
      <div className="flex flex-wrap items-start gap-4">
        <div className="flex flex-col gap-1.5">
          <span className={caption}>Cards view</span>
          <div className="flex h-[26rem] w-[16rem]">
            <AdTallCard ad={ad} />
          </div>
        </div>
        <div className="flex w-[280px] flex-col gap-1.5">
          <span className={caption}>Under Filters (laptops)</span>
          <AdBox ad={ad} />
        </div>
        <div className="flex flex-col gap-1.5">
          <span className={caption}>Side column (wide screens)</span>
          <AdTower ad={ad} />
        </div>
      </div>
    </div>
  );
}
