import Link from "next/link";
import Icon from "@/components/Icon";
import { deleteBannerAction, saveBannerAction, setBannerLiveAction } from "@/lib/content-actions";
import { bannerState } from "@/lib/banners";
import { ukDay } from "@/lib/events";
import type { BannerRow } from "@/lib/db";
import ConfirmSubmitButton from "./ConfirmSubmitButton";
import BannerStatePill from "./BannerState";
import BannerLookFields from "./BannerLookFields";
import { field, hint, label, panel, panelTitle } from "./formStyles";

// A banner: one line across the top of every page, with an optional link.
// Putting it live and taking it down is separate from saving.
export default function BannerEditor({
  banner,
  error,
  notice,
}: {
  banner?: BannerRow;
  error?: string;
  notice?: string;
}) {
  const state = banner ? bannerState(banner, ukDay()) : undefined;

  return (
    <div className="flex max-w-2xl flex-col gap-5">
      <div>
        <Link
          href="/admin/banners"
          className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline"
        >
          ← All banners
        </Link>
        <h1 className="mt-2 text-xl font-bold sm:text-2xl">{banner ? "Edit banner" : "New banner"}</h1>
      </div>

      {notice && (
        <p className="rounded-lg bg-green-50 px-4 py-2 text-sm text-green-800 dark:bg-green-950/40 dark:text-green-300">
          <Icon name="circle-check" className="mr-1.5" />
          {notice}
        </p>
      )}
      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </p>
      )}

      {banner && state && (
        <section className={panel}>
          <h2 className={panelTitle}>Status</h2>
          <div className="flex flex-wrap items-center gap-3">
            <BannerStatePill state={state} />
          </div>
          <p className={hint}>
            {banner.live
              ? "Showing across the site from its start date to its end date (or until you take it down). If more than one is live, the newest shows."
              : "Not showing. Put it live when it's ready."}
          </p>
          <form action={setBannerLiveAction}>
            <input type="hidden" name="id" value={banner.id} />
            <input type="hidden" name="live" value={banner.live ? "0" : "1"} />
            {banner.live ? (
              <ConfirmSubmitButton
                confirmText="Take this banner down? It disappears from every page."
                confirmLabel="Take down"
                className="rounded-full border border-red-300 px-5 py-2.5 text-sm font-semibold text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/30"
              >
                Take down
              </ConfirmSubmitButton>
            ) : (
              <button
                type="submit"
                className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600"
              >
                Put live
              </button>
            )}
          </form>
        </section>
      )}

      <form action={saveBannerAction} className="flex flex-col gap-5">
        {banner && <input type="hidden" name="id" value={banner.id} />}
        <section className={panel}>
          <label className={label}>
            Message
            <span className={hint}>Keep it short: it has to read well on a phone.</span>
            <textarea
              name="message"
              required
              rows={2}
              maxLength={160}
              defaultValue={banner?.message}
              placeholder="Black Friday starts on the 27th."
              className={field}
            />
          </label>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <label className={label}>
              Link (optional)
              <span className={hint}>A page on the site, like /black-friday, or an https:// address.</span>
              <input
                name="linkUrl"
                maxLength={300}
                defaultValue={banner?.linkUrl}
                placeholder="/black-friday"
                className={field}
              />
            </label>
            <label className={label}>
              What the link says
              <span className={hint}>Like “See the deals”.</span>
              <input name="linkLabel" maxLength={30} defaultValue={banner?.linkLabel} className={field} />
            </label>
          </div>
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>Colours</h2>
          <BannerLookFields
            bg={banner?.bg}
            fg={banner?.fg}
            messageField="message"
            link={{ urlField: "linkUrl", labelField: "linkLabel" }}
          />
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>When</h2>
          <p className={hint}>Both optional. Leave them empty and it shows whenever it&apos;s live.</p>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <label className={label}>
              Starts showing
              <input type="date" name="showFrom" defaultValue={banner?.showFrom} className={field} />
            </label>
            <label className={label}>
              Stops showing
              <input type="date" name="showUntil" defaultValue={banner?.showUntil} className={field} />
            </label>
          </div>
        </section>

        <div>
          <button
            type="submit"
            className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600"
          >
            {banner ? "Save" : "Create banner"}
          </button>
        </div>
      </form>

      {banner && (
        <form action={deleteBannerAction}>
          <input type="hidden" name="id" value={banner.id} />
          <ConfirmSubmitButton
            confirmText="Delete this banner for good?"
            className="text-sm font-medium text-red-600 hover:underline"
          >
            Delete this banner
          </ConfirmSubmitButton>
        </form>
      )}
    </div>
  );
}
