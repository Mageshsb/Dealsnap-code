import Link from "next/link";
import Icon from "@/components/Icon";
import SelectField from "@/components/SelectField";
import DealCard from "@/components/DealCard";
import { deleteCampaignAction, duplicateCampaignAction, saveCampaignAction, setCampaignReportAction, setCampaignStatusAction } from "@/lib/ad-actions";
import type { Deal } from "@/lib/types";
import type { AdCampaignRow, AdvertiserRow } from "@/lib/db";
import {
  AD_SCOPES,
  AD_SLOTS,
  AD_TEXT,
  PRIORITIES,
  campaignAttention,
  campaignState,
  clickRate,
  creativeImageUrl,
  earned,
  pounds,
  slotName,
  turnShares,
  type AdSlotId,
  type CampaignKind,
  type CampaignStatus,
  type Rival,
} from "@/lib/ads";
import CopyField from "./CopyField";
import ConfirmSubmitButton from "./ConfirmSubmitButton";
import AdPreview from "./AdPreview";
import { AdProgress, AdStatePill } from "./AdBits";
import { field, hint, label, panel, panelTitle } from "./formStyles";

type Report = {
  days: { day: string; views: number; clicks: number }[];
  slots: { slot: string; views: number; clicks: number }[];
};

const radio = "flex items-start gap-2 text-sm font-normal";
const FILE =
  "text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-zinc-100 file:px-3 file:py-2 file:text-sm file:font-medium dark:file:bg-zinc-800";
const BUTTON = "rounded-full px-5 py-2.5 text-sm font-semibold";
const day = (d: string) => new Date(`${d}T12:00:00Z`).toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short", timeZone: "UTC" });

// One campaign: who it's for, the ad (with a live look at it in every space),
// where and when it shows, how much is bought and at what price, and, once it
// has run, its report. Putting it live, pausing and archiving are separate from
// saving, so an edit never puts something live by accident.
export default function AdEditor({
  campaign,
  advertisers,
  report,
  today,
  error,
  notice,
  slot,
  kind: newKind = "ad",
  deal,
  reportUrl,
  reportExpires,
  rivals,
}: {
  slot?: AdSlotId; // a new campaign for this space (from the Overview)
  kind?: CampaignKind; // a new campaign: an ad, or a sponsored deal
  deal?: Deal; // a sponsored deal's deal, for its preview
  reportUrl?: string; // the advertiser's report link, when it's on
  reportExpires?: string; // the day it stops working
  rivals?: Rival[]; // the other campaigns that meet this one in a space
  campaign?: AdCampaignRow;
  advertisers: AdvertiserRow[];
  report?: Report;
  today: string;
  error?: string;
  notice?: string;
}) {
  const c = campaign;
  const isDeal = (c?.kind ?? newKind) === "deal";
  const views = report?.days.reduce((n, d) => n + d.views, 0) ?? 0;
  const clicks = report?.days.reduce((n, d) => n + d.clicks, 0) ?? 0;
  const todayViews = report?.days.find((d) => d.day === today)?.views ?? 0;
  const state = c ? campaignState(c, { total: views, today: todayViews }, today) : undefined;
  const notes = c ? campaignAttention(c, { total: views, today: todayViews }, today) : [];
  const shares = c && rivals ? turnShares(c, rivals) : [];
  const image = c?.imageVersion ? creativeImageUrl(c.id, "image", c.imageVersion) : undefined;
  const logo = c?.logoVersion ? creativeImageUrl(c.id, "logo", c.logoVersion) : undefined;
  const scope = c?.scope ?? "all";

  const statusButton = (status: CampaignStatus, text: string, style: string, confirm?: string) => (
    <form action={setCampaignStatusAction}>
      <input type="hidden" name="id" value={c!.id} />
      <input type="hidden" name="status" value={status} />
      {confirm ? (
        <ConfirmSubmitButton confirmText={confirm} confirmLabel={text} className={`${BUTTON} ${style}`}>
          {text}
        </ConfirmSubmitButton>
      ) : (
        <button type="submit" className={`${BUTTON} ${style}`}>
          {text}
        </button>
      )}
    </form>
  );
  const primary = "bg-orange-500 text-white hover:bg-orange-600";
  const quiet = "border border-zinc-300 hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800";

  return (
    <div className="flex max-w-2xl flex-col gap-5">
      <div>
        <Link href="/admin/ads/campaigns" className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline">
          ← All campaigns
        </Link>
        <h1 className="mt-2 text-xl font-bold sm:text-2xl">{c ? c.name : isDeal ? "New sponsored deal" : "New campaign"}</h1>
        <p className="text-sm text-zinc-500">
          {isDeal
            ? "A real deal on DealSnap that a store pays to place among the others in the lists and Cards view, labelled “Ad · Sponsored by…”. Members can still heart, save and comment on it, and it never changes how deals are ranked."
            : "An ad an advertiser pays DealSnap for, built from their words and picture in the site's own look. It's labelled “Ad” with their name, and it's picked for the page it's on, not for who's looking: no cookies, no tracking."}
        </p>
      </div>

      {notice && (
        <p className="rounded-lg bg-green-50 px-4 py-2 text-sm text-green-800 dark:bg-green-950/40 dark:text-green-300">
          <Icon name="circle-check" className="mr-1.5" />
          {notice}
        </p>
      )}
      {error && <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">{error}</p>}

      {c && state && (
        <section className={panel}>
          <h2 className={panelTitle}>Status</h2>
          <div className="flex flex-wrap items-center gap-3">
            <AdStatePill state={state} />
            <AdProgress views={views} goal={c.goal} startsOn={c.startsOn} endsOn={c.endsOn} today={today} />
          </div>
          <p className={hint}>
            {state === "draft"
              ? "Not showing. Check the preview below, then put it live."
              : state === "paused"
                ? "Not showing while paused. Its views so far are kept."
                : state === "full"
                  ? "It has had all the views bought, so it has stopped. Raise the goal to run it further."
                  : state === "finished"
                    ? "Its end date has passed."
                    : state === "archived"
                      ? "Put away. Its report is kept."
                      : c.priority === "house"
                        ? "A house ad: it fills a space only when no paying campaign and no ad network ad wants it."
                        : "It shares its spaces with any other campaigns there, taking turns by weight."}
          </p>
          {notes.length > 0 && (
            <ul className="flex flex-col gap-1">
              {notes.map((n) => (
                <li key={n.text} className="flex items-start gap-2 text-sm">
                  <Icon name={n.level === "warn" ? "warning" : "info"} className={`mt-0.5 size-4 shrink-0 ${n.level === "warn" ? "text-amber-600" : "text-zinc-500 dark:text-zinc-400"}`} />
                  {n.text}
                </li>
              ))}
            </ul>
          )}
          <div className="flex flex-wrap gap-2">
            {(c.status === "draft" || c.status === "paused") && statusButton("live", c.status === "paused" ? "Resume" : "Put live", primary)}
            {c.status === "live" && statusButton("paused", "Pause", quiet)}
            {c.status !== "archived" && c.status !== "draft" && statusButton("archived", "Archive", quiet, "Archive this campaign? It stops showing; its report is kept.")}
            {c.status === "archived" && statusButton("draft", "Back to draft", quiet)}
            <form action={duplicateCampaignAction}>
              <input type="hidden" name="id" value={c.id} />
              <button type="submit" className={`${BUTTON} ${quiet}`}>
                <Icon name="copy" className="mr-1.5" />
                Duplicate
              </button>
            </form>
          </div>
        </section>
      )}

      <form action={saveCampaignAction} className="flex flex-col gap-5">
        {c ? <input type="hidden" name="id" value={c.id} /> : <input type="hidden" name="kind" value={isDeal ? "deal" : "ad"} />}

        <section className={panel}>
          <h2 className={panelTitle}>Who it&apos;s for</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className={label}>
              Advertiser
              <SelectField
                look="admin"
                label="Advertiser"
                name="advertiserId"
                defaultValue={c?.advertiserId ?? (advertisers.length ? advertisers[0].id : "new")}
                options={[...advertisers.map((a) => ({ value: a.id, label: a.name })), { value: "new", label: "A new advertiser…" }]}
              />
            </div>
            <label className={label}>
              New advertiser&apos;s name
              <span className={hint}>Only if you picked “A new advertiser…”.</span>
              <input name="newAdvertiser" maxLength={AD_TEXT.name} placeholder="Currys" className={field} />
            </label>
          </div>
          <label className={label}>
            Campaign name
            <span className={hint}>For you only, never shown on the site. Like “Currys TVs, November”.</span>
            <input name="name" required maxLength={AD_TEXT.name} defaultValue={c?.name} className={field} />
          </label>
        </section>

        {isDeal && (
          <section className={panel}>
            <h2 className={panelTitle}>The deal</h2>
            <label className={label}>
              Sponsored by
              <span className={hint}>Shown as “Ad · Sponsored by …”, like “Currys”.</span>
              <input name="shownName" required maxLength={AD_TEXT.advertiser} defaultValue={c?.shownName} className={field} />
            </label>
            <label className={label}>
              The deal&apos;s link
              <span className={hint}>
                Copy it from the deal&apos;s page on DealSnap. It must be live; while it&apos;s expired or taken down, it
                isn&apos;t shown. Its Featured or Deal of the Day look is left off, as those can&apos;t be bought.
              </span>
              <input name="deal" required maxLength={500} defaultValue={c?.dealSlug ? `/deals/${c.dealSlug}` : undefined} placeholder="https://dealsnap.co.uk/deals/…" className={field} />
            </label>
            {deal && c && (
              <div className="flex max-w-xl flex-col gap-1">
                <span className="text-sm font-medium">How it looks</span>
                <div className="pointer-events-none">
                  <DealCard deal={{ ...deal, featured: false, hero: false }} sponsoredBy={c.shownName} />
                </div>
              </div>
            )}
          </section>
        )}

        {!isDeal && (
          <section className={panel}>
            <h2 className={panelTitle}>The ad</h2>
            <label className={label}>
              Who it&apos;s from, as visitors see it
              <span className={hint}>Shown after the “Ad” label, like “Currys”.</span>
              <input name="shownName" required maxLength={AD_TEXT.advertiser} defaultValue={c?.shownName} className={field} />
            </label>
            <label className={label}>
              Headline
              <span className={hint}>Keep it short: two lines at most show in the lists.</span>
              <input name="headline" required maxLength={AD_TEXT.headline} defaultValue={c?.headline} placeholder="Up to 30% off OLED TVs" className={field} />
            </label>
            <label className={label}>
              A line under it (optional)
              <input name="body" maxLength={AD_TEXT.body} defaultValue={c?.body} className={field} />
            </label>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <label className={label}>
                Button says
                <input name="ctaLabel" required maxLength={AD_TEXT.cta} defaultValue={c?.ctaLabel} placeholder="Shop now" className={field} />
              </label>
              <label className={label}>
                Goes to
                <span className={hint}>
                  The advertiser&apos;s page, starting https://. DealSnap&apos;s tracking tags (utm_source=dealsnap…) are added
                  on the way, so they can see the sales you send, unless the link already has its own.
                </span>
                <input name="linkUrl" required maxLength={500} defaultValue={c?.linkUrl} placeholder="https://www.currys.co.uk/tvs" className={field} />
              </label>
            </div>
            {(["image", "logo"] as const).map((slot) => {
              const current = slot === "image" ? image : logo;
              return (
                <div key={slot} className="flex flex-col gap-2">
                  <span className="text-sm font-medium">{slot === "image" ? "Picture (optional)" : "Logo (optional)"}</span>
                  {current && (
                    <div className="flex items-center gap-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={current} alt="" className={`rounded-lg border border-zinc-200 bg-zinc-100 dark:border-zinc-700 dark:bg-zinc-800 ${slot === "image" ? "h-16 w-24 object-cover" : "size-12 object-contain"}`} />
                      <label className="flex items-center gap-2 text-sm font-normal">
                        <input type="checkbox" name={`remove-${slot}`} className="size-4 accent-orange-500" />
                        Remove it
                      </label>
                    </div>
                  )}
                  <input type="file" name={slot} accept="image/png,image/jpeg,image/webp" className={FILE} />
                  <span className={hint}>
                    {slot === "image"
                      ? "Fills the picture spot, cropped to fit (tall and narrow in the lists, wide elsewhere), so keep the product in the middle and leave words out of it."
                      : "Shown on a plain tile when there's no picture. A square logo works best."}{" "}
                    PNG, JPG or WEBP, under 3MB.
                  </span>
                </div>
              );
            })}
            <div className="flex flex-col gap-1.5">
              <span className="text-sm font-medium">How it looks</span>
              <AdPreview currentImage={image} currentLogo={logo} />
            </div>
          </section>
        )}

        <section className={panel}>
          <h2 className={panelTitle}>Where it shows</h2>
          {isDeal ? (
            <p className={hint}>
              In the deal lists and Cards view, in the Sponsored deals space (never first in a list; how often is set in
              Ad spaces).
            </p>
          ) : (
            <fieldset className="flex flex-col gap-2.5">
              <legend className="mb-1 text-sm font-medium">Ad spaces</legend>
              {AD_SLOTS.filter((s) => s.id !== "sponsored").map((s) => (
                <label key={s.id} className={radio}>
                  <input type="checkbox" name="slots" value={s.id} defaultChecked={c ? c.slots.includes(s.id) : slot ? s.id === slot : s.id === "list" || s.id === "cards"} className="mt-0.5 size-4 shrink-0 accent-orange-500" />
                  <span className="flex flex-col">
                    <span className="font-medium">{s.name}</span>
                    <span className={hint}>
                      {s.screens}. {s.where}
                    </span>
                  </span>
                </label>
              ))}
            </fieldset>
          )}
          <fieldset className="flex flex-col gap-2">
            <legend className="mb-1 text-sm font-medium">Pages</legend>
            {AD_SCOPES.map((s) => (
              <label key={s.value} className={radio}>
                <input type="radio" name="scope" value={s.value} defaultChecked={scope === s.value} className="mt-0.5 size-4 accent-orange-500" />
                {s.label}
              </label>
            ))}
          </fieldset>
          <label className={label}>
            Just one store, category, tag, brand or article (optional)
            <span className={hint}>
              The last part of its page&apos;s address, like “currys” for /stores/currys. The ad then shows on that page
              and on that store&apos;s (or category&apos;s, tag&apos;s or brand&apos;s) deal pages. For an article, its
              address name after /blog/.
            </span>
            <input name="target" maxLength={80} defaultValue={c?.target} placeholder="currys" className={field} />
          </label>
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>When and how much</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <label className={label}>
              Starts
              <input type="date" name="startsOn" defaultValue={c?.startsOn} className={field} />
            </label>
            <label className={label}>
              Ends
              <input type="date" name="endsOn" defaultValue={c?.endsOn} className={field} />
            </label>
          </div>
          <label className={label}>
            Views bought (optional)
            <span className={hint}>
              It stops once it has had this many. A view counts when at least half the ad is on screen for a second, the
              industry&apos;s standard. Leave empty for no limit.
            </span>
            <input name="goal" inputMode="numeric" defaultValue={c?.goal} placeholder="100000" className={`${field} sm:w-48`} />
          </label>
          <fieldset className="flex flex-col gap-2">
            <legend className="mb-1 text-sm font-medium">Pace</legend>
            <label className={radio}>
              <input type="radio" name="pacing" value="even" defaultChecked={(c?.pacing ?? "even") === "even"} className="mt-0.5 size-4 accent-orange-500" />
              <span>
                Evenly to the end date <span className={hint}>(what advertisers usually expect)</span>
              </span>
            </label>
            <label className={radio}>
              <input type="radio" name="pacing" value="fast" defaultChecked={c?.pacing === "fast"} className="mt-0.5 size-4 accent-orange-500" />
              As fast as possible
            </label>
          </fieldset>
          <fieldset className="flex flex-col gap-2">
            <legend className="mb-1 text-sm font-medium">Sharing its spaces</legend>
            {PRIORITIES.filter((p) => !isDeal || p.value !== "house").map((p) => (
              <label key={p.value} className={radio}>
                <input type="radio" name="priority" value={p.value} defaultChecked={(c?.priority ?? "standard") === p.value} className="mt-0.5 size-4 accent-orange-500" />
                <span className="flex flex-col">
                  {p.label}
                  <span className={hint}>{p.hint}</span>
                </span>
              </label>
            ))}
          </fieldset>
          <label className={label}>
            Weight
            <span className={hint}>
              1 to 10. A 10 comes up about twice as often as a 5. A campaign that falls behind its dates is given extra turns automatically, up to four times its weight.
            </span>
            <input type="number" name="weight" min={1} max={10} defaultValue={c?.weight ?? 5} className={`${field} sm:w-24`} />
          </label>
          <fieldset className="flex flex-col gap-2">
            <legend className="mb-1 text-sm font-medium">Price (a house ad is always free)</legend>
            <label className={radio}>
              <input type="radio" name="pricing" value="cpm" defaultChecked={(c?.pricing ?? "cpm") === "cpm"} className="mt-0.5 size-4 accent-orange-500" />
              Per 1,000 views
            </label>
            <label className={radio}>
              <input type="radio" name="pricing" value="flat" defaultChecked={c?.pricing === "flat"} className="mt-0.5 size-4 accent-orange-500" />
              A fixed fee for the whole campaign
            </label>
            <label className={radio}>
              <input type="radio" name="pricing" value="none" defaultChecked={c?.pricing === "none"} className="mt-0.5 size-4 accent-orange-500" />
              Free (a test, or a favour)
            </label>
          </fieldset>
          <label className={label}>
            Amount (£)
            <input name="price" inputMode="decimal" defaultValue={c && c.pricing !== "none" ? (c.pricePence / 100).toFixed(2) : ""} placeholder="6.00" className={`${field} sm:w-32`} />
          </label>
          <label className="flex items-start gap-2.5 text-sm font-medium">
            <input type="checkbox" name="reportCosts" defaultChecked={c?.reportCosts ?? true} className="mt-0.5 size-4 shrink-0 accent-orange-500" />
            <span className="flex flex-col gap-0.5">
              Show the cost on the advertiser&apos;s report
              <span className={hint}>Untick if someone else (an agency) gets the report and shouldn&apos;t see the price.</span>
            </span>
          </label>
        </section>

        <label className="flex items-start gap-2.5 rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm dark:border-amber-900 dark:bg-amber-950/30">
          <input type="checkbox" name="rulesOk" required className="mt-0.5 size-4 shrink-0 accent-orange-500" />
          <span className="flex flex-col gap-1">
            <span className="font-medium">I&apos;ve checked this ad is allowed</span>
            <span className={hint}>
              Its claims are true and it&apos;s clearly from the advertiser (UK advertising rules, the CAP Code). It isn&apos;t
              for gambling, alcohol, tobacco or vapes, medicines or weight loss, or “less healthy” food and drink (paid online
              ads for those have been banned in the UK since 5 January 2026, unless the advertiser is a small business).
            </span>
          </span>
        </label>

        <div>
          <button type="submit" className={`${BUTTON} ${primary}`}>
            {c ? "Save" : "Save as a draft"}
          </button>
        </div>
      </form>

      {c && rivals && (
        <section className={panel}>
          <h2 className={panelTitle}>Who else is in these spaces</h2>
          {rivals.length === 0 ? (
            <p className={hint}>
              No other campaign is booked in these spaces, on these pages, over these dates. This one has them to itself, apart from the
              ad network and house ads, which only cover what it leaves.
            </p>
          ) : (
            <>
              <p className={hint}>
                Only campaigns in the same space take its turns. A campaign aimed at the exact page being looked at comes first on that page,
                and one that falls behind its dates is given extra turns.
              </p>
              {shares.length > 0 && (
                <ul className="flex flex-col gap-1 text-sm">
                  {shares.map((x) => (
                    <li key={x.slot}>
                      <span className="font-medium">{slotName(x.slot)}:</span>{" "}
                      {x.share === 0 ? "none while a sponsorship has it" : `about ${Math.round(x.share * 100)}% of the turns, by weight`}
                    </li>
                  ))}
                </ul>
              )}
              <ul className="flex flex-col gap-2">
                {rivals.map((r) => (
                  <li key={r.campaign.id} className="flex flex-col gap-0.5 rounded-lg bg-zinc-50 p-2.5 text-sm dark:bg-zinc-950">
                    <span className="flex flex-wrap items-center gap-2">
                      <Link href={`/admin/ads/${r.campaign.id}`} className="font-medium hover:underline">
                        {r.campaign.name}
                      </Link>
                      <span
                        className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                          r.effect === "outranks"
                            ? "bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400"
                            : "bg-zinc-200 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300"
                        }`}
                      >
                        {r.effect === "outranks"
                          ? "Takes the space first"
                          : r.effect === "outranked"
                            ? "Gives way to this one"
                            : r.effect === "backfill"
                              ? "House ad: fills what's left"
                              : "Takes turns"}
                      </span>
                      <span className="text-xs text-zinc-500">
                        {r.campaign.status === "draft" ? "Draft" : r.campaign.status === "paused" ? "Paused" : r.campaign.startsOn && r.campaign.startsOn > today ? "Scheduled" : "Live"}
                        {r.campaign.advertiserName && ` · ${r.campaign.advertiserName}`}
                      </span>
                    </span>
                    <span className="text-xs text-zinc-500">
                      {r.slots.map(slotName).join(", ")}
                      {(r.campaign.startsOn || r.campaign.endsOn) && ` · ${r.campaign.startsOn ? day(r.campaign.startsOn) : "now"} to ${r.campaign.endsOn ? day(r.campaign.endsOn) : "no end"}`}
                    </span>
                  </li>
                ))}
              </ul>
            </>
          )}
        </section>
      )}

      {c && (
        <section id="report-link" className={`${panel} scroll-mt-24`}>
          <h2 className={panelTitle}>Report link for the advertiser</h2>
          <p className={hint}>
            A private page with this campaign&apos;s live numbers, for the advertiser: no sign-in, read-only, never shown to
            search engines. Anyone with the link can open it, so send it only to them.
            {reportExpires && ` It stops working on ${new Date(`${reportExpires}T12:00:00Z`).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" })}, 90 days after the campaign ends.`}
          </p>
          {reportUrl ? (
            <>
              <CopyField value={reportUrl} label="Report link" />
              <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
                <a href={reportUrl} target="_blank" rel="noopener" className="font-medium text-orange-700 hover:underline dark:text-orange-400">
                  Open it
                </a>
                <form action={setCampaignReportAction}>
                  <input type="hidden" name="id" value={c.id} />
                  <input type="hidden" name="on" value="1" />
                  <ConfirmSubmitButton confirmText="Make a new link? The current one stops working." confirmLabel="Make a new link" className="font-medium text-zinc-600 hover:underline dark:text-zinc-400">
                    Make a new link
                  </ConfirmSubmitButton>
                </form>
                <form action={setCampaignReportAction}>
                  <input type="hidden" name="id" value={c.id} />
                  <input type="hidden" name="on" value="0" />
                  <ConfirmSubmitButton confirmText="Turn the report link off? Anyone who has it can't open it any more." confirmLabel="Turn off" className="font-medium text-red-600 hover:underline">
                    Turn off
                  </ConfirmSubmitButton>
                </form>
              </div>
            </>
          ) : (
            <form action={setCampaignReportAction}>
              <input type="hidden" name="id" value={c.id} />
              <input type="hidden" name="on" value="1" />
              <button type="submit" className={`${BUTTON} ${quiet}`}>
                Make a report link
              </button>
            </form>
          )}
        </section>
      )}

      {c && report && (
        <section className={panel}>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className={panelTitle}>Report</h2>
            <a href={`/admin/ads/${c.id}/report`} className="text-sm font-medium text-orange-700 hover:underline dark:text-orange-400">
              <Icon name="download" className="mr-1" />
              Spreadsheet (CSV)
            </a>
          </div>
          <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              ["Views", views.toLocaleString("en-GB")],
              ["Clicks", clicks.toLocaleString("en-GB")],
              ["Click rate", clickRate(views, clicks)],
              ["Earned", pounds(earned(c, views))],
            ].map(([k, v]) => (
              <div key={k} className="rounded-lg bg-zinc-50 p-3 dark:bg-zinc-950">
                <dt className="text-xs text-zinc-500">{k}</dt>
                <dd className="text-lg font-semibold">{v}</dd>
              </div>
            ))}
          </dl>
          {report.slots.length > 0 && (
            <table className="w-full text-sm">
              <thead className="text-left text-xs text-zinc-500">
                <tr>
                  <th className="py-1 font-medium">Ad space</th>
                  <th className="py-1 text-right font-medium">Views</th>
                  <th className="py-1 text-right font-medium">Clicks</th>
                  <th className="py-1 text-right font-medium">Rate</th>
                </tr>
              </thead>
              <tbody>
                {report.slots.map((s) => (
                  <tr key={s.slot} className="border-t border-zinc-100 dark:border-zinc-800">
                    <td className="py-1.5">{slotName(s.slot)}</td>
                    <td className="py-1.5 text-right tabular-nums">{s.views.toLocaleString("en-GB")}</td>
                    <td className="py-1.5 text-right tabular-nums">{s.clicks.toLocaleString("en-GB")}</td>
                    <td className="py-1.5 text-right tabular-nums">{clickRate(s.views, s.clicks)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {report.days.length > 0 ? (
            <div className="max-h-80 overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-white text-left text-xs text-zinc-500 dark:bg-zinc-900">
                  <tr>
                    <th className="py-1 font-medium">Day</th>
                    <th className="py-1 text-right font-medium">Views</th>
                    <th className="py-1 text-right font-medium">Clicks</th>
                    <th className="py-1 text-right font-medium">Rate</th>
                  </tr>
                </thead>
                <tbody>
                  {report.days.map((d) => (
                    <tr key={d.day} className="border-t border-zinc-100 dark:border-zinc-800">
                      <td className="py-1.5">{day(d.day)}</td>
                      <td className="py-1.5 text-right tabular-nums">{d.views.toLocaleString("en-GB")}</td>
                      <td className="py-1.5 text-right tabular-nums">{d.clicks.toLocaleString("en-GB")}</td>
                      <td className="py-1.5 text-right tabular-nums">{clickRate(d.views, d.clicks)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className={hint}>Nothing counted yet. Staff and bots are never counted, so looking at it yourself won&apos;t add views.</p>
          )}
        </section>
      )}

      {c && (
        <form action={deleteCampaignAction}>
          <input type="hidden" name="id" value={c.id} />
          <ConfirmSubmitButton confirmText="Delete this campaign and its report for good? (Archive keeps the report.)" className="text-sm font-medium text-red-600 hover:underline">
            Delete this campaign
          </ConfirmSubmitButton>
        </form>
      )}
    </div>
  );
}
