import Link from "next/link";
import SelectField from "@/components/SelectField";
import { saveBlogPostAction, deleteBlogPostAction } from "@/lib/admin-actions";
import { getCategoryGroups } from "@/lib/categories";
import { blogCoverUrl } from "@/lib/mock-blog";
import { BLOG_KINDS } from "@/lib/blog";
import { formatDate } from "@/lib/format";
import PostChecklist from "./PostChecklist";
import PostWriter from "./PostWriter";
import type { BlogRow } from "@/lib/db";
import ConfirmSubmitButton from "./ConfirmSubmitButton";
import { field, hint, label, panel, panelTitle } from "./formStyles";
import Icon from "@/components/Icon";

// The marks a post can use, for anyone who'd rather type them than use the toolbar.
const FORMATTING: [string, string][] = [
  ["## Heading", "a section heading (also listed in the post's contents)"],
  ["### Smaller heading", "a sub-heading; under a “Common questions” heading each one becomes a question in Google"],
  ["- Point", "a bullet point"],
  ["> Words", "a highlighted note"],
  ["| a | b |", "a table row (the first row is the heading)"],
  ["**words**", "bold"],
  ["[words](https://…)", "a link (or /deals/… for a page on the site)"],
  ["::deal deal-address", "a live card for a deal on the site"],
];

// Writing on the left; publishing, sorting, picture and deals on the right
// (stacked underneath on phones).
export default function BlogEditor({ row, error, notice }: { row?: BlogRow; error?: string; notice?: string }) {
  const picksText = (row?.picks ?? [])
    .map((p) => [p.name, p.price, p.blurb, p.url ?? ""].join(" | ").replace(/ \| $/, ""))
    .join("\n");
  const date = (row ? new Date(row.publishedAt) : new Date()).toISOString().slice(0, 10);
  const now = new Date().toISOString();
  const state = !row ? "New" : row.status === "draft" ? "Draft" : row.publishedAt > now ? "Scheduled" : "Published";

  return (
    <div className="flex max-w-6xl flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <Link
            href="/admin/blog"
            className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline"
          >
            ← All posts
          </Link>
          <h1 className="mt-2 text-xl font-bold sm:text-2xl">{row ? "Edit post" : "New post"}</h1>
          {row && (
            <p className="text-sm text-zinc-500">
              {state} · about {row.readMinutes} min read
            </p>
          )}
        </div>
        {row && (
          <Link
            href={`/blog/${row.slug}${state === "Published" ? "" : "?preview=1"}`}
            target="_blank"
            className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-50 dark:border-zinc-700 dark:hover:bg-zinc-800"
          >
            {state === "Published" ? "View post ↗" : "Preview ↗"}
          </Link>
        )}
      </div>

      {notice && (
        <p className="rounded-lg bg-green-50 px-4 py-2 text-sm text-green-800 dark:bg-green-950/40 dark:text-green-300">
          <Icon name="circle-check" className="mr-1.5" />
          {notice}
        </p>
      )}
      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </p>
      )}

      <form
        action={saveBlogPostAction}
        className="grid grid-cols-1 items-start gap-5 lg:grid-cols-[minmax(0,1fr)_300px]"
      >
        {row && <input type="hidden" name="id" value={row.id} />}

        <div className="flex min-w-0 flex-col gap-5">
          <section className={panel}>
            <label className={label}>
              Title
              <input
                name="title"
                required
                maxLength={160}
                defaultValue={row?.title}
                className={`${field} text-lg! font-semibold`}
              />
            </label>
            <label className={label}>
              Short summary
              <span className={hint}>
                Shown under the title, on the blog list and in Google. About 1–2 sentences (under 160 characters is
                ideal).
              </span>
              <textarea name="excerpt" rows={2} maxLength={300} defaultValue={row?.excerpt} className={field} />
            </label>
          </section>

          <section className={panel}>
            <PostWriter initial={row?.content ?? ""} />
            <details className="rounded-lg bg-zinc-50 px-3 py-2 text-sm dark:bg-zinc-950">
              <summary className="cursor-pointer font-medium">Typing the marks yourself</summary>
              <dl className="mt-2 grid grid-cols-1 gap-x-4 gap-y-1.5 sm:grid-cols-[auto_1fr]">
                {FORMATTING.map(([mark, what]) => (
                  <div key={mark} className="contents">
                    <dt>
                      <code className="rounded bg-white px-1.5 py-0.5 text-xs dark:bg-zinc-800">{mark}</code>
                    </dt>
                    <dd className="text-xs text-zinc-500">{what}</dd>
                  </div>
                ))}
              </dl>
            </details>
          </section>

          <section className={panel}>
            <label className={label}>
              <Icon name="zap" className="mr-1.5" />
              Key takeaways (optional)
              <span className={hint}>A short summary box at the top of the post. One point per line, up to 5.</span>
              <textarea name="takeaways" rows={4} defaultValue={row?.takeaways.join("\n")} className={field} />
            </label>
            <label className={label}>
              <Icon name="trophy" className="mr-1.5" />
              Product picks (optional)
              <span className={hint}>
                Numbered cards after the post. One per line: Name | £price | why it&apos;s good | link (optional). For
                example: Best All-Rounder | £219 | Great camera, 4 years of updates | https://… A store link goes through
                your affiliate setup and is marked sponsored; with no link, the button shows the live deals for that
                product, if there are any.
              </span>
              <textarea name="picks" rows={4} defaultValue={picksText} className={`${field} font-mono text-sm!`} />
            </label>
          </section>
        </div>

        <div className="flex flex-col gap-5 lg:sticky lg:top-20">
          <PostChecklist initial={{ title: row?.title ?? "", excerpt: row?.excerpt ?? "", content: row?.content ?? "", takeaways: row?.takeaways.join("\n") ?? "", hasCover: !!row && (row.hasCoverImage || !!row.coverPath) }} />

          <section className={panel}>
            <h2 className={panelTitle}>Publish</h2>
            <label className={label}>
              Status
              <SelectField
                look="admin"
                name="status"
                label="Status"
                defaultValue={row?.status ?? "draft"}
                options={[
                  { value: "draft", label: "Draft (hidden)" },
                  { value: "published", label: "Published" },
                ]}
              />
            </label>
            <label className={label}>
              Date
              <span className={hint}>A future date schedules it.</span>
              <input type="date" name="publishedAt" defaultValue={date} className={field} />
            </label>
            <label className="flex items-start gap-2 text-sm font-medium">
              <input
                type="checkbox"
                name="featured"
                defaultChecked={row?.featured}
                className="mt-0.5 h-4 w-4 accent-orange-500"
              />
              <span>
                <Icon name="pin" className="mr-1.5" />
                Pin to the top of the blog
                <span className={`block ${hint}`}>Shown big at the top. Only one post is pinned at a time.</span>
              </span>
            </label>
            <label className="flex items-start gap-2 text-sm font-medium">
              <input type="checkbox" name="pricesChecked" className="mt-0.5 h-4 w-4 accent-orange-500" />
              <span>
                <Icon name="circle-check" className="mr-1.5" />
                I&apos;ve checked the prices today
                <span className={`block ${hint}`}>
                  {row?.checkedAt ? `Last checked ${formatDate(row.checkedAt)}.` : "Shows “Prices checked” on the post."} Posts not checked for four months get a gentle warning.
                </span>
              </span>
            </label>
            <button
              type="submit"
              className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600"
            >
              Save
            </button>
          </section>

          <section className={panel}>
            <h2 className={panelTitle}>Sort</h2>
            <label className={label}>
              Type
              <SelectField
                look="admin"
                name="kind"
                label="Type of post"
                defaultValue={row?.kind ?? "tips"}
                options={BLOG_KINDS.map((k) => ({ value: k.key, label: k.single }))}
              />
            </label>
            <label className={label}>
              Category
              <SelectField
                look="admin"
                name="category"
                label="Category"
                defaultValue={row?.category ?? ""}
                options={[
                  { value: "", label: "No category" },
                  ...getCategoryGroups().map((g) => ({ value: g.name, label: g.name })),
                  ...(row?.category && !getCategoryGroups().some((g) => g.name === row.category)
                    ? [{ value: row.category, label: row.category }]
                    : []),
                ]}
              />
            </label>
            <label className={label}>
              Author
              <input name="author" maxLength={60} defaultValue={row?.author ?? "DealSnap Team"} className={field} />
            </label>
            <label className={label}>
              Web address
              <span className={hint}>/blog/…</span>
              <input
                name="slug"
                maxLength={80}
                defaultValue={row?.slug}
                placeholder="made from the title"
                className={field}
              />
            </label>
          </section>

          <section className={panel}>
            <h2 className={panelTitle}>Cover picture</h2>
            {row && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={blogCoverUrl(row)}
                alt=""
                className="aspect-[16/9] w-full rounded-lg border border-zinc-200 object-cover dark:border-zinc-700"
              />
            )}
            <input
              type="file"
              name="cover"
              accept="image/png,image/jpeg,image/webp"
              className="text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-zinc-100 file:px-3 file:py-2 file:text-sm file:font-medium dark:file:bg-zinc-800"
            />
            <span className={hint}>
              PNG, JPG or WEBP, under 3MB. Wide (16:9) works best.{row ? " Leave empty to keep the current one." : ""}
            </span>
          </section>

          <section className={panel}>
            <h2 className={panelTitle}>Deals under the post</h2>
            <label className={label}>
              Show deals matching
              <span className={hint}>
                For example &ldquo;sofa&rdquo;. Also adds an &ldquo;Get alerts for new sofa deals&rdquo; button. Leave
                empty to show deals from the category.
              </span>
              <input name="dealsQuery" maxLength={60} defaultValue={row?.dealsQuery} className={field} />
            </label>
          </section>
        </div>
      </form>

      {row && (
        <form action={deleteBlogPostAction}>
          <input type="hidden" name="id" value={row.id} />
          <ConfirmSubmitButton
            confirmText={`Delete "${row.title}" for good?`}
            className="text-sm font-medium text-red-600 hover:underline"
          >
            Delete this post
          </ConfirmSubmitButton>
        </form>
      )}
    </div>
  );
}
