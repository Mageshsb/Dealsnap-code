import type { ReactNode } from "react";
import SectionTabs from "./SectionTabs";

const TABS = [
  { key: "people", label: "People", href: "/admin/team" },
  { key: "activity", label: "Activity log", href: "/admin/activity" },
  { key: "rules", label: "Rules", href: "/admin/team/rules" },
] as const;

// The top of each Team page: the section's name, the tabs between its views
// (how each person is getting on, everything they did, and the rules they
// work to), then what the view is for. Rules is for admins who change
// settings, so it's left out for everyone else.
export default function TeamHeader({
  current,
  description,
  rules,
  side,
}: {
  current: (typeof TABS)[number]["key"];
  description: ReactNode;
  rules: boolean;
  side?: ReactNode;
}) {
  return (
    <>
      <h1 className="text-xl font-bold sm:text-2xl">Team</h1>
      <SectionTabs label="Team" tabs={TABS.filter((t) => rules || t.key !== "rules")} current={current} />
      <div className="flex flex-wrap items-end justify-between gap-3">
        <p className="min-w-0 max-w-xl text-sm text-zinc-500">{description}</p>
        {side}
      </div>
    </>
  );
}
