"use client";

import { useState } from "react";
import Icon from "@/components/Icon";

// The Daily Top 5 as ready-to-paste text, with a Copy button.
export default function ShareTopFive({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const el = document.getElementById("top-five-text") as HTMLTextAreaElement | null;
      el?.select();
      document.execCommand("copy");
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="flex flex-col gap-2">
      <textarea
        id="top-five-text"
        aria-label="The text to share"
        readOnly
        value={text}
        rows={Math.min(16, text.split("\n").length + 1)}
        className="w-full rounded-lg border border-zinc-300 bg-zinc-50 p-3 font-mono text-xs leading-relaxed dark:border-zinc-700 dark:bg-zinc-950"
      />
      <button
        type="button"
        onClick={copy}
        className="self-start rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600"
      >
        {copied ? (
          <>
            Copied <Icon name="check" className="ml-0.5" />
          </>
        ) : (
          "Copy text"
        )}
      </button>
    </div>
  );
}
