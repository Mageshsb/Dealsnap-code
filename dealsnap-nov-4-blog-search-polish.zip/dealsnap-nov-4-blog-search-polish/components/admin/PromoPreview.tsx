"use client";

import { useEffect, useRef, useState } from "react";
import PromoCard from "@/components/PromoCard";
import PromoSwipeCard from "@/components/PromoSwipeCard";
import { PromoBannerView } from "@/components/PromoBanner";
import { MIN_READABLE, contrastRatio, isHexColour } from "@/lib/banners";
import { DEFAULT_PROMO_BG, DEFAULT_PROMO_FG, PROMO_ICONS, type PromoKind } from "@/lib/promos";

// A live look at the promo as the words and choices are changed, drawn by the
// very components the site uses, at a phone's width (and for the banner, a
// laptop's too). It reads the form it sits in, picture included, so it needs
// no state of its own to keep in step.
export default function PromoPreview({ kind, currentImage, currentLogo }: { kind: PromoKind; currentImage?: string; currentLogo?: string }) {
  const root = useRef<HTMLDivElement>(null);
  const [v, setV] = useState({
    kicker: "",
    headline: "",
    body: "",
    benefits: [] as string[],
    ctaLabel: "",
    icon: "",
    showTag: true,
    bg: DEFAULT_PROMO_BG,
    fg: DEFAULT_PROMO_FG,
    picture: (kind === "banner" ? currentLogo : currentImage) ?? "",
  });

  useEffect(() => {
    const form = root.current?.closest("form");
    if (!form) return;
    let objectUrl = "";
    const read = () => {
      const data = new FormData(form);
      const text = (name: string) => String(data.get(name) ?? "");
      const file = data.get(kind === "banner" ? "logo" : "image");
      if (objectUrl) URL.revokeObjectURL(objectUrl);
      objectUrl = file instanceof File && file.size > 0 ? URL.createObjectURL(file) : "";
      const current = kind === "banner" ? currentLogo : currentImage;
      setV({
        kicker: text("kicker"),
        headline: text("headline"),
        body: text("body"),
        benefits: text("benefits")
          .split("\n")
          .map((b) => b.trim())
          .filter(Boolean),
        ctaLabel: text("ctaLabel"),
        icon: text("icon"),
        showTag: data.get("showTag") === "on",
        bg: text("bg") || DEFAULT_PROMO_BG,
        fg: text("fg") || DEFAULT_PROMO_FG,
        picture: objectUrl || (data.get("removePicture") === "on" ? "" : (current ?? "")),
      });
    };
    read();
    form.addEventListener("input", read);
    form.addEventListener("change", read);
    return () => {
      form.removeEventListener("input", read);
      form.removeEventListener("change", read);
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [kind, currentImage, currentLogo]);

  const base = {
    kicker: v.kicker || undefined,
    headline: v.headline || "Your headline appears here",
    body: v.body || undefined,
    ctaLabel: v.ctaLabel || (kind === "signup" ? "Join free" : "Button"),
    linkUrl: "/",
    showTag: kind !== "signup" && v.showTag,
  };
  const bg = isHexColour(v.bg) ? v.bg : DEFAULT_PROMO_BG;
  const fg = isHexColour(v.fg) ? v.fg : DEFAULT_PROMO_FG;
  const hard = kind === "banner" && contrastRatio(bg, fg) < MIN_READABLE;
  const card = {
    ...base,
    variant: kind === "signup" ? ("signup" as const) : ("promo" as const),
    benefits: v.benefits.length ? v.benefits : kind === "signup" ? ["Your benefits appear here"] : [],
    icon: PROMO_ICONS.find((i) => i === v.icon),
    imageUrl: v.picture || undefined,
  };
  const label = "text-xs text-zinc-500";

  return (
    <div ref={root} className="flex flex-col gap-3">
      {kind === "banner" ? (
        <>
          <div className="flex flex-col gap-1">
            <span className={label}>Phone</span>
            <div className="max-w-[375px] overflow-hidden rounded-lg border border-zinc-200 dark:border-zinc-700">
              <PromoBannerView preview promo={{ ...base, logoUrl: v.picture || undefined, bg, fg }} />
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <span className={label}>Laptop</span>
            <div className="overflow-hidden rounded-lg border border-zinc-200 dark:border-zinc-700">
              <PromoBannerView preview promo={{ ...base, logoUrl: v.picture || undefined, bg, fg }} />
            </div>
          </div>
        </>
      ) : (
        <div className="flex flex-wrap items-start gap-4">
          <div className="flex w-full max-w-[343px] flex-col gap-1 sm:w-[343px]">
            <span className={label}>In the list, on a phone</span>
            <div className="rounded-xl bg-zinc-100 p-0 dark:bg-zinc-950">
              <PromoCard preview promo={card} />
            </div>
          </div>
          <div className="flex w-[220px] flex-col gap-1">
            <span className={label}>In Cards view</span>
            <div className="h-[340px] w-full">
              <PromoSwipeCard preview promo={card} />
            </div>
          </div>
        </div>
      )}
      {hard && (
        <p className="text-xs text-amber-700 dark:text-amber-400">
          These two colours are hard to read together. Try making one lighter or darker.
        </p>
      )}
    </div>
  );
}
