import Link from "next/link";
import Icon from "@/components/Icon";
import { deletePromoAction, savePromoAction, setPromoLiveAction } from "@/lib/promo-actions";
import { bannerState } from "@/lib/banners";
import { ukDay } from "@/lib/events";
import type { PromoRow } from "@/lib/db";
import {
  AFTER_DEALS_DEFAULT,
  AFTER_DEALS_MAX,
  BANNER_SCOPES,
  BENEFITS_MAX,
  BENEFIT_MAX_LENGTH,
  CARD_SCOPES,
  DEFAULT_PROMO_BG,
  DEFAULT_PROMO_FG,
  PROMO_ICONS,
  SIGNUP_AFTER_DEFAULT,
  promoImageUrl,
  type PromoKind,
} from "@/lib/promos";
import ConfirmSubmitButton from "./ConfirmSubmitButton";
import BannerStatePill from "./BannerState";
import PromoPreview from "./PromoPreview";
import { field, hint, label, panel, panelTitle } from "./formStyles";

const PICKER =
  "h-11 w-full cursor-pointer rounded-lg border border-zinc-300 bg-zinc-50 p-1 dark:border-zinc-700 dark:bg-zinc-950";

// A promo: a card that sits inside a deal list after the Nth deal, a sign-up
// tile (a card that sells joining, shown only to people who aren't signed in),
// or a banner under the header. What it says, its picture, where it shows, and
// whether it wears the "Promoted" tag are all set here. Putting it live and
// taking it down is separate from saving.
export default function PromoEditor({
  promo,
  kind: newKind = "card",
  error,
  notice,
}: {
  promo?: PromoRow;
  kind?: PromoKind;
  error?: string;
  notice?: string;
}) {
  const kind = promo?.kind ?? newKind;
  const state = promo ? bannerState(promo, ukDay()) : undefined;
  const listed = kind !== "banner";
  const signup = kind === "signup";
  const scopes = listed ? CARD_SCOPES : BANNER_SCOPES;
  const scope = promo?.scope ?? "all";
  const radio = "flex items-center gap-2 text-sm font-normal";
  const currentImage = promo?.imageVersion ? promoImageUrl(promo.id, "image", promo.imageVersion) : undefined;
  const currentLogo = promo?.logoVersion ? promoImageUrl(promo.id, "logo", promo.logoVersion) : undefined;
  const current = kind === "banner" ? currentLogo : currentImage;

  return (
    <div className="flex max-w-2xl flex-col gap-5">
      <div>
        <Link
          href="/admin/promos"
          className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline"
        >
          ← All promos
        </Link>
        <h1 className="mt-2 text-xl font-bold sm:text-2xl">
          {promo ? "Edit" : "New"} {signup ? "sign-up tile" : kind === "card" ? "promo card" : "promo banner"}
        </h1>
        <p className="text-sm text-zinc-500">
          {signup
            ? "A card in the deal lists that asks people to join, with the benefits listed. Only people who aren't signed in see it."
            : kind === "card"
              ? "A card that sits in the deal lists, after the deal number you choose, the same size as a deal."
              : "A band under the header, in your colours, the same height on every page. It scrolls away with the page, and people can close it for the day."}
        </p>
      </div>

      {notice && (
        <p className="rounded-lg bg-green-50 px-4 py-2 text-sm text-green-800 dark:bg-green-950/40 dark:text-green-300">
          <Icon name="circle-check" className="mr-1.5" />
          {notice}
        </p>
      )}
      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </p>
      )}

      {promo && state && (
        <section className={panel}>
          <h2 className={panelTitle}>Status</h2>
          <div className="flex flex-wrap items-center gap-3">
            <BannerStatePill state={state} />
          </div>
          <p className={hint}>
            {promo.live
              ? "Showing from its start date to its end date (or until you take it down). If more than one of this kind fits a page, the best fit shows (one aimed at that exact page beats a general one), newest first."
              : "Not showing. Put it live when it's ready."}
          </p>
          <form action={setPromoLiveAction}>
            <input type="hidden" name="id" value={promo.id} />
            <input type="hidden" name="live" value={promo.live ? "0" : "1"} />
            {promo.live ? (
              <ConfirmSubmitButton
                confirmText="Take this promo down? It disappears from the site."
                confirmLabel="Take down"
                className="rounded-full border border-red-300 px-5 py-2.5 text-sm font-semibold text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/30"
              >
                Take down
              </ConfirmSubmitButton>
            ) : (
              <button
                type="submit"
                className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600"
              >
                Put live
              </button>
            )}
          </form>
        </section>
      )}

      <form action={savePromoAction} className="flex flex-col gap-5">
        {promo ? <input type="hidden" name="id" value={promo.id} /> : <input type="hidden" name="kind" value={kind} />}

        <section className={panel}>
          <h2 className={panelTitle}>Words</h2>
          {!signup && (
            <label className={label}>
              {kind === "card" ? "Who it's from (optional)" : "Small line above (optional)"}
              <span className={hint}>{kind === "card" ? "The store or brand, like “Currys”." : "Like “Black Friday”."}</span>
              <input name="kicker" maxLength={30} defaultValue={promo?.kicker} className={field} />
            </label>
          )}
          <label className={label}>
            Headline
            <span className={hint}>
              {kind === "banner"
                ? "Short wins: a phone fits about 30 characters beside the button (without a small line above it, two lines). Anything longer is cut off with …"
                : "Keep it short: two lines at most show."}
            </span>
            <input
              name="headline"
              required
              maxLength={70}
              defaultValue={promo?.headline}
              placeholder={signup ? "Join DealSnap. It's free" : kind === "card" ? "Up to 30% off laptops" : "Black Friday deals are live"}
              className={field}
            />
          </label>
          {signup ? (
            <label className={label}>
              Benefits
              <span className={hint}>
                One to a line, up to {BENEFITS_MAX}, each up to {BENEFIT_MAX_LENGTH} characters. Each gets a tick. Short ones read best: a phone fits about 28 characters before it&apos;s cut off with …
              </span>
              <textarea
                name="benefits"
                required
                rows={3}
                defaultValue={promo?.benefits.join("\n")}
                placeholder={"Get alerts for deals you want\nSave deals for later\nHeart the best deals"}
                className={field}
              />
            </label>
          ) : (
            <label className={label}>
              {kind === "card" ? "A line under it (optional)" : "A line beside it on laptops (optional)"}
              <input name="body" maxLength={120} defaultValue={promo?.body} className={field} />
            </label>
          )}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <label className={label}>
              Button says
              <input
                name="ctaLabel"
                required
                maxLength={24}
                defaultValue={promo?.ctaLabel ?? (signup ? "Join free" : undefined)}
                placeholder="Shop now"
                className={field}
              />
            </label>
            <label className={label}>
              Button goes to
              <span className={hint}>
                {signup ? "Leave empty to use the sign-up page (/signup)." : "A page on the site, like /black-friday, or an https:// address."}
              </span>
              <input
                name="linkUrl"
                required={!signup}
                maxLength={300}
                defaultValue={promo?.linkUrl ?? (signup ? "/signup" : undefined)}
                placeholder={signup ? "/signup" : "/black-friday"}
                className={field}
              />
            </label>
          </div>
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>Look</h2>
          {listed ? (
            <fieldset className="flex flex-col gap-2">
              <legend className="text-sm font-medium">Icon (optional)</legend>
              <span className={hint}>Shows in the picture slot when there&apos;s no picture.</span>
              <div className="flex flex-wrap gap-2">
                <label className="cursor-pointer">
                  <input type="radio" name="icon" value="" defaultChecked={!promo?.icon} className="peer sr-only" />
                  <span className="flex h-10 items-center rounded-lg border border-zinc-300 px-3 text-sm peer-checked:border-orange-500 peer-checked:bg-orange-50 peer-focus-visible:ring-2 peer-focus-visible:ring-orange-500 dark:border-zinc-700 dark:peer-checked:bg-orange-950/30">
                    None
                  </span>
                </label>
                {PROMO_ICONS.map((i) => (
                  <label key={i} className="cursor-pointer">
                    <input type="radio" name="icon" value={i} defaultChecked={promo?.icon === i} className="peer sr-only" />
                    <span
                      title={i}
                      className="flex size-10 items-center justify-center rounded-lg border border-zinc-300 peer-checked:border-orange-500 peer-checked:bg-orange-50 peer-focus-visible:ring-2 peer-focus-visible:ring-orange-500 dark:border-zinc-700 dark:peer-checked:bg-orange-950/30"
                    >
                      <Icon name={i} className="size-5" />
                    </span>
                  </label>
                ))}
              </div>
            </fieldset>
          ) : (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <label className={label}>
                Background colour
                <input type="color" name="bg" defaultValue={promo?.bg ?? DEFAULT_PROMO_BG} className={PICKER} />
              </label>
              <label className={label}>
                Text colour
                <input type="color" name="fg" defaultValue={promo?.fg ?? DEFAULT_PROMO_FG} className={PICKER} />
              </label>
            </div>
          )}
          <div className="flex flex-col gap-2">
            <span className="text-sm font-medium">{kind === "banner" ? "Logo (optional)" : "Picture (optional)"}</span>
            {current && (
              <div className="flex items-center gap-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={current}
                  alt=""
                  className={`rounded-lg border border-zinc-200 bg-zinc-100 object-cover dark:border-zinc-700 dark:bg-zinc-800 ${kind === "banner" ? "size-10 object-contain" : "h-16 w-24"}`}
                />
                <label className="flex items-center gap-2 text-sm font-normal">
                  <input type="checkbox" name="removePicture" className="size-4 accent-orange-500" />
                  Remove it
                </label>
              </div>
            )}
            <input
              type="file"
              name={kind === "banner" ? "logo" : "image"}
              accept="image/png,image/jpeg,image/webp"
              className="text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-zinc-100 file:px-3 file:py-2 file:text-sm file:font-medium dark:file:bg-zinc-800"
            />
            <span className={hint}>
              {kind === "banner"
                ? "A small mark shown at the left, 36px, so a square logo works best. PNG, JPG or WEBP, under 3MB."
                : "Fills the picture slot, cropped to fit (a deal's photo slot is tall and narrow in the list, wide in Cards view). PNG, JPG or WEBP, under 3MB."}
              {current ? " Choose a new file to replace the current one." : ""}
            </span>
          </div>
          {!signup && (
          <label className="flex items-start gap-2.5 text-sm font-medium">
            <input type="checkbox" name="showTag" defaultChecked={promo?.showTag ?? true} className="mt-0.5 size-4 accent-orange-500" />
            <span className="flex flex-col gap-0.5">
              Show the “Promoted” tag (with its megaphone icon)
              <span className={hint}>
                Leave it on for anything paid for or from a partner: shoppers should be able to tell a promotion from a
                deal. Turn it off only for DealSnap&apos;s own news.
              </span>
            </span>
          </label>
          )}
          <div className="flex flex-col gap-1.5">
            <span className="text-sm font-medium">How it looks</span>
            <PromoPreview kind={kind} currentImage={currentImage} currentLogo={currentLogo} />
          </div>
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>Where it shows</h2>
          <fieldset className="flex flex-col gap-2">
            <legend className="sr-only">Pages</legend>
            {scopes.map((s) => (
              <label key={s.value} className={radio}>
                <input type="radio" name="scope" value={s.value} defaultChecked={scope === s.value} className="size-4 accent-orange-500" />
                {s.label}
              </label>
            ))}
          </fieldset>
          {signup && (
            <p className={hint}>
              Only people who aren&apos;t signed in see it. Once they join or log in it disappears.
            </p>
          )}
          {listed ? (
            <>
              <label className={label}>
                Just one page (optional)
                <span className={hint}>
                  For store, category, tag and brand pages: the last part of the page&apos;s address, like “currys” for
                  /stores/currys. Leave empty for every page of that kind.
                </span>
                <input name="target" maxLength={80} defaultValue={promo?.target} placeholder="currys" className={field} />
              </label>
              <label className={label}>
                Appears after deal number
                <span className={hint}>
                  1 to {AFTER_DEALS_MAX}. On a list with fewer deals it goes at the end. One promo card and one sign-up tile can show per list.
                </span>
                <input
                  type="number"
                  name="afterDeals"
                  min={1}
                  max={AFTER_DEALS_MAX}
                  defaultValue={promo?.afterDeals ?? (signup ? SIGNUP_AFTER_DEFAULT : AFTER_DEALS_DEFAULT)}
                  className={`${field} sm:w-32`}
                />
              </label>
            </>
          ) : (
            <label className="flex items-start gap-2.5 text-sm font-medium">
              <input type="checkbox" name="closable" defaultChecked={promo?.closable ?? true} className="mt-0.5 size-4 accent-orange-500" />
              <span className="flex flex-col gap-0.5">
                People can close it
                <span className={hint}>A close button hides it for the rest of that day. If you edit it, it shows again.</span>
              </span>
            </label>
          )}
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>When</h2>
          <p className={hint}>Both optional. Leave them empty and it shows whenever it&apos;s live.</p>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <label className={label}>
              Starts showing
              <input type="date" name="showFrom" defaultValue={promo?.showFrom} className={field} />
            </label>
            <label className={label}>
              Stops showing
              <input type="date" name="showUntil" defaultValue={promo?.showUntil} className={field} />
            </label>
          </div>
        </section>

        <div>
          <button
            type="submit"
            className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600"
          >
            {promo ? "Save" : "Create"}
          </button>
        </div>
      </form>

      {promo && (
        <form action={deletePromoAction}>
          <input type="hidden" name="id" value={promo.id} />
          <ConfirmSubmitButton
            confirmText="Delete this promo for good?"
            className="text-sm font-medium text-red-600 hover:underline"
          >
            Delete this promo
          </ConfirmSubmitButton>
        </form>
      )}
    </div>
  );
}
