"use client";

import { useEffect, useState } from "react";
import { DealSnapIcon } from "@/components/icons";
import Icon from "@/components/Icon";
import { saveSiteBrandAction } from "@/lib/admin-actions";
import { BRAND_IMAGE_MAX_BYTES, BRAND_IMAGE_TYPES, WIDE_LOGO } from "@/lib/site-brand-shared";

const FILE =
  "min-w-0 max-w-full text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-zinc-100 file:px-3 file:py-2 file:text-sm file:font-medium hover:file:bg-zinc-200 dark:file:bg-zinc-800";
const LINK_BUTTON = "self-start text-sm font-medium text-zinc-600 underline underline-offset-2 hover:text-orange-600 dark:text-zinc-300";
// Server actions take up to 4MB at once (next.config.ts).
const SEND_MAX = 3.8 * 1024 * 1024;

type Pic = { src: string; w: number; h: number };

// A picture chosen in a file box, shown straight away (before saving), with
// its size so the preview can tell a wide logo from a square one.
function useChosen() {
  const [chosen, setChosen] = useState<{ pic?: Pic; file?: File; error?: string }>({});
  useEffect(() => () => {
    if (chosen.pic) URL.revokeObjectURL(chosen.pic.src);
  }, [chosen.pic]);
  function choose(input: HTMLInputElement) {
    const file = input.files?.[0];
    if (!file) return setChosen({});
    if (file.size > BRAND_IMAGE_MAX_BYTES) {
      input.value = "";
      return setChosen({ error: "That picture is too big. Use one under 2MB." });
    }
    const src = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => setChosen({ file, pic: { src, w: img.naturalWidth || 1, h: img.naturalHeight || 1 } });
    img.onerror = () => {
      URL.revokeObjectURL(src);
      input.value = "";
      setChosen({ error: "We couldn't read that picture. Try a PNG, JPG, WebP or SVG." });
    };
    img.src = src;
  }
  return { ...chosen, choose };
}

// The header's logo as it will look: the uploaded logo (wide ones without
// the name), or the built-in icon and the name.
function HeaderSample({ logo, showName, siteName, dark }: { logo?: Pic; showName: boolean; siteName: string; dark?: boolean }) {
  const wide = logo ? logo.w / logo.h > WIDE_LOGO : false;
  return (
    <div className={`flex h-12 min-w-0 items-center gap-1.5 rounded-lg border px-3 text-lg font-bold tracking-tight ${dark ? "border-zinc-800 bg-black text-zinc-50" : "border-zinc-200 bg-white text-zinc-900"}`}>
      {logo ? (
        // eslint-disable-next-line @next/next/no-img-element -- a local preview
        <img src={logo.src} alt="" className={wide ? "h-7 w-auto max-w-[200px] object-contain object-left" : "size-6 object-contain"} />
      ) : (
        <DealSnapIcon className="size-6 shrink-0" />
      )}
      {(showName || !logo) && <span className="truncate">{siteName}</span>}
      <span className={`ml-3 hidden h-8 min-w-0 flex-1 rounded-full border sm:block ${dark ? "border-zinc-800 bg-zinc-900" : "border-zinc-200 bg-zinc-50"}`} />
    </div>
  );
}

// A browser tab with the icon, and the icon as a phone's home-screen app.
function IconSample({ icon, siteName }: { icon?: Pic; siteName: string }) {
  const mark = (size: string) =>
    icon ? (
      // eslint-disable-next-line @next/next/no-img-element -- a local preview
      <img src={icon.src} alt="" className={`${size} object-contain`} />
    ) : (
      <DealSnapIcon className={size} />
    );
  return (
    <div className="flex flex-wrap items-end gap-4">
      <div className="flex h-9 w-56 max-w-full items-center gap-2 rounded-t-lg border border-b-0 border-zinc-200 bg-white px-3 text-xs text-zinc-700 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-200">
        {mark("size-4 shrink-0")}
        <span className="truncate">{siteName}</span>
        <Icon name="x" className="ml-auto size-3 shrink-0 text-zinc-400" />
      </div>
      <div className="flex flex-col items-center gap-1">
        <span className="flex size-14 items-center justify-center overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-zinc-200 dark:ring-zinc-700">{mark("size-full")}</span>
        <span className="max-w-16 truncate text-[11px] text-zinc-500">{siteName}</span>
      </div>
    </div>
  );
}

// Admin → Settings → General: the logo in the header, an optional copy for
// dark mode, and the icon in browser tabs and on phones' home screens.
export default function SiteBrandForm({
  siteName,
  logo,
  logoDark,
  icon,
  showName,
  cardClass,
  hintClass,
  saveClass,
}: {
  siteName: string;
  logo?: Pic;
  logoDark?: Pic;
  icon?: Pic;
  showName: boolean;
  cardClass: string;
  hintClass: string;
  saveClass: string;
}) {
  const newLogo = useChosen();
  const newDark = useChosen();
  const newIcon = useChosen();
  const [nameShown, setNameShown] = useState(showName);
  const shownLogo = newLogo.pic ?? logo;
  const shownDark = newDark.pic ?? (newLogo.pic ? undefined : logoDark) ?? shownLogo;
  const shownIcon = newIcon.pic ?? icon;
  // A new logo starts with the name beside it if it's square-ish, and
  // without if it's wide (the server does the same).
  const [seenLogo, setSeenLogo] = useState(newLogo.pic);
  if (newLogo.pic !== seenLogo) {
    setSeenLogo(newLogo.pic);
    if (newLogo.pic) setNameShown(newLogo.pic.w / newLogo.pic.h <= WIDE_LOGO);
  }
  const sending = (newLogo.file?.size ?? 0) + (newDark.file?.size ?? 0) + (newIcon.file?.size ?? 0);
  const tooMuch = sending > SEND_MAX;

  return (
    <form action={saveSiteBrandAction} className={cardClass}>
      <div>
        <h2 className="font-semibold">Logo and browser icon</h2>
        <p className="text-sm text-zinc-500">What the header shows, and the little picture in browser tabs, bookmarks and on phones&rsquo; home screens.</p>
      </div>

      <div className="flex flex-col gap-2">
        <span className="text-sm font-medium">How the header looks</span>
        <HeaderSample logo={shownLogo} showName={nameShown} siteName={siteName} />
        <HeaderSample logo={shownDark} showName={nameShown} siteName={siteName} dark />
        <p className={hintClass}>Light and dark mode. The name comes from the site title below (the part before the &ldquo;—&rdquo;).</p>
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="brand-logo" className="text-sm font-medium">
          Logo
        </label>
        <input id="brand-logo" type="file" name="logo" accept={BRAND_IMAGE_TYPES} onChange={(e) => newLogo.choose(e.currentTarget)} className={FILE} />
        {newLogo.error && <p className="text-sm text-red-600 dark:text-red-400">{newLogo.error}</p>}
        <p className={hintClass}>
          A PNG or SVG with a see-through background works best. A wide logo takes the place of the name; a square one sits beside it. Empty space around it is trimmed off.
        </p>
        {logo && !newLogo.pic && (
          <button type="submit" name="remove" value="logo" className={LINK_BUTTON}>
            Use the standard logo
          </button>
        )}
      </div>

      {shownLogo && (
        <label className="flex items-start gap-2 text-sm">
          <input
            type="checkbox"
            name="showName"
            value="1"
            checked={nameShown}
            onChange={(e) => setNameShown(e.target.checked)}
            className="mt-0.5 h-4 w-4 shrink-0 rounded border-zinc-300 accent-orange-500"
          />
          <span>Show the site&rsquo;s name beside the logo</span>
        </label>
      )}

      {shownLogo && (
        <div className="flex flex-col gap-1.5">
          <label htmlFor="brand-logo-dark" className="text-sm font-medium">
            Logo for dark mode <span className="font-normal text-zinc-500">(optional)</span>
          </label>
          <input id="brand-logo-dark" type="file" name="logoDark" accept={BRAND_IMAGE_TYPES} onChange={(e) => newDark.choose(e.currentTarget)} className={FILE} />
          {newDark.error && <p className="text-sm text-red-600 dark:text-red-400">{newDark.error}</p>}
          <p className={hintClass}>Only if the logo is hard to see on black, like dark writing. A light copy of it goes here.</p>
          {logoDark && !newDark.pic && !newLogo.pic && (
            <button type="submit" name="remove" value="logoDark" className={LINK_BUTTON}>
              Remove the dark mode copy
            </button>
          )}
        </div>
      )}

      <div className="flex flex-col gap-2">
        <label htmlFor="brand-icon" className="text-sm font-medium">
          Browser icon
        </label>
        <IconSample icon={shownIcon} siteName={siteName} />
        <input id="brand-icon" type="file" name="icon" accept={BRAND_IMAGE_TYPES} onChange={(e) => newIcon.choose(e.currentTarget)} className={FILE} />
        {newIcon.error && <p className="text-sm text-red-600 dark:text-red-400">{newIcon.error}</p>}
        <p className={hintClass}>
          A square picture, 512 by 512 pixels is best. Keep it simple: it&rsquo;s shown as small as 16 pixels. Browsers can take a day to show a new one.
        </p>
        {icon && !newIcon.pic && (
          <button type="submit" name="remove" value="icon" className={LINK_BUTTON}>
            Use the standard icon
          </button>
        )}
      </div>

      {tooMuch && <p className="text-sm text-red-600 dark:text-red-400">Those pictures are too big to send together. Save them one at a time.</p>}
      <button type="submit" disabled={tooMuch} className={`${saveClass} disabled:opacity-50`}>
        Save
      </button>
    </form>
  );
}
