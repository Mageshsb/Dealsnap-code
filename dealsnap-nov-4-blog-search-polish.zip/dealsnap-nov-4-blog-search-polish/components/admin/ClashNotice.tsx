import Icon from "@/components/Icon";

// "Someone else got there first": shown at the top of a helper-desk or admin
// page when a button was pressed on something another person had just dealt
// with (lib/collisions.ts). Amber, not red: nothing went wrong, nothing changed.
export default function ClashNotice({ message }: { message?: string }) {
  if (!message) return null;
  return (
    <p role="status" className="flex gap-2 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-200">
      <Icon name="users" className="mt-0.5 size-4 shrink-0" />
      <span>{message}</span>
    </p>
  );
}
