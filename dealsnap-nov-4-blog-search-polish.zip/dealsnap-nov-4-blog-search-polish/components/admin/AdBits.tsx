import { daysInclusive, type CampaignState } from "@/lib/ads";

const LOOK: Record<CampaignState, { label: string; style: string }> = {
  draft: { label: "Draft", style: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400" },
  scheduled: { label: "Live, starts later", style: "bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400" },
  live: { label: "Showing now", style: "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400" },
  paused: { label: "Paused", style: "bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400" },
  full: { label: "Goal reached", style: "bg-violet-100 text-violet-700 dark:bg-violet-950/40 dark:text-violet-300" },
  finished: { label: "Ended", style: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400" },
  archived: { label: "Archived", style: "bg-zinc-100 text-zinc-500 dark:bg-zinc-800 dark:text-zinc-500" },
};

// Where a campaign stands, as a small pill.
export function AdStatePill({ state }: { state: CampaignState }) {
  return <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${LOOK[state].style}`}>{LOOK[state].label}</span>;
}

// Views so far against the goal, with how it's pacing when it has an end date.
export function AdProgress({
  views,
  goal,
  startsOn,
  endsOn,
  today,
}: {
  views: number;
  goal?: number;
  startsOn?: string;
  endsOn?: string;
  today: string;
}) {
  if (!goal) return <span className="text-xs text-zinc-500">{views.toLocaleString("en-GB")} views · no goal</span>;
  const share = Math.min(1, views / goal);
  let pace = "";
  if (startsOn && endsOn && today >= startsOn && today <= endsOn && views < goal) {
    const expected = goal * (daysInclusive(startsOn, today) / daysInclusive(startsOn, endsOn));
    pace = views < expected * 0.85 ? " · behind" : views > expected * 1.15 ? " · ahead" : " · on pace";
  }
  return (
    <span className="flex min-w-0 flex-col gap-1">
      <span className="h-1.5 w-full max-w-56 overflow-hidden rounded-full bg-zinc-200 dark:bg-zinc-800">
        <span className="block h-full rounded-full bg-orange-500" style={{ width: `${(share * 100).toFixed(1)}%` }} />
      </span>
      <span className="text-xs text-zinc-500">
        {views.toLocaleString("en-GB")} of {goal.toLocaleString("en-GB")} views ({Math.floor(share * 100)}%){pace}
      </span>
    </span>
  );
}
