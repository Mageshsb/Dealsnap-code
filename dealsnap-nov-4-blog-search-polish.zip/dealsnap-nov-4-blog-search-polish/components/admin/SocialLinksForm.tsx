"use client";

import { useActionState, useState } from "react";
import Notice from "./Notice";
import { field, panel, panelTitle } from "./formStyles";
import Icon from "@/components/Icon";
import SocialIcon from "@/components/SocialIcon";
import { saveSocialLinksAction, type PageFormState } from "@/lib/page-actions";
import { LINK_KINDS, PROFILE_URL_MAX, type LinkGroup, type SiteLinkSetting } from "@/lib/social-links-shared";

const arrow = "flex size-9 items-center justify-center rounded-lg text-zinc-500 hover:bg-zinc-100 disabled:opacity-30 disabled:hover:bg-transparent dark:hover:bg-zinc-800";
const kinds = new Map(LINK_KINDS.map((k) => [k.id, k]));

// The footer's social and app links: one row each, with its link, a Show
// switch and arrows for the order. Everything is kept in the form until Save,
// so moving one doesn't lose a link that's half typed.
export default function SocialLinksForm({ initial, notice }: { initial: SiteLinkSetting[]; notice?: string }) {
  const [state, formAction, pending] = useActionState<PageFormState, FormData>(saveSocialLinksAction, {});
  const [rows, setRows] = useState(initial);

  const update = (id: string, change: Partial<SiteLinkSetting>) => setRows((list) => list.map((r) => (r.id === id ? { ...r, ...change } : r)));
  // Up or down within its own group (socials, apps).
  function move(id: string, by: -1 | 1) {
    setRows((list) => {
      const group = kinds.get(id)!.group;
      const same = list.filter((r) => kinds.get(r.id)!.group === group);
      const at = same.findIndex((r) => r.id === id);
      const to = at + by;
      if (to < 0 || to >= same.length) return list;
      [same[at], same[to]] = [same[to], same[at]];
      return [...same, ...list.filter((r) => kinds.get(r.id)!.group !== group)].sort(
        (a, b) => (kinds.get(a.id)!.group === "social" ? 0 : 1) - (kinds.get(b.id)!.group === "social" ? 0 : 1)
      );
    });
  }

  function group(name: LinkGroup, title: string, intro: string) {
    const list = rows.filter((r) => kinds.get(r.id)!.group === name);
    return (
      <section className={panel}>
        <h2 className={panelTitle}>{title}</h2>
        <p className="-mt-2 text-sm text-zinc-500">{intro}</p>
        <ul className="flex flex-col gap-2">
          {list.map((r, i) => {
            const kind = kinds.get(r.id)!;
            return (
              <li key={r.id} className="flex flex-col gap-2 rounded-xl border border-zinc-200 p-2.5 sm:flex-row sm:items-center dark:border-zinc-800">
                <div className="flex min-w-0 items-center gap-2.5 sm:w-40 sm:shrink-0">
                  <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-200">
                    {name === "social" ? <SocialIcon id={r.id} /> : <Icon name="smartphone" className="size-4" />}
                  </span>
                  <span className="truncate text-sm font-semibold">{kind.name}</span>
                </div>
                <input
                  type="text"
                  inputMode="url"
                  name={`url_${r.id}`}
                  value={r.url}
                  maxLength={PROFILE_URL_MAX}
                  onChange={(e) => update(r.id, { url: e.target.value, on: r.on || (!r.url && !!e.target.value.trim()) })}
                  placeholder={kind.example}
                  aria-label={`${kind.name} link`}
                  autoComplete="off"
                  spellCheck={false}
                  className={`${field} min-w-0 sm:flex-1`}
                />
                <div className="flex items-center justify-between gap-2 sm:justify-end">
                  <label className="flex min-h-9 cursor-pointer items-center gap-2 px-1 text-sm">
                    <input
                      type="checkbox"
                      name={`on_${r.id}`}
                      value="1"
                      checked={r.on}
                      onChange={(e) => update(r.id, { on: e.target.checked })}
                      aria-label={`Show ${kind.name}`}
                      className="size-5 accent-orange-500"
                    />
                    Show
                  </label>
                  <span className="flex">
                    <button type="button" onClick={() => move(r.id, -1)} disabled={i === 0} aria-label={`Move ${kind.name} up`} className={arrow}>
                      <Icon name="arrow-up" className="size-4" />
                    </button>
                    <button type="button" onClick={() => move(r.id, 1)} disabled={i === list.length - 1} aria-label={`Move ${kind.name} down`} className={arrow}>
                      <Icon name="arrow-down" className="size-4" />
                    </button>
                  </span>
                </div>
              </li>
            );
          })}
        </ul>
      </section>
    );
  }

  const showing = rows.filter((r) => r.on && r.url.trim()).length;
  return (
    <form action={formAction} className="flex flex-col gap-5">
      <Notice notice={notice} error={state.error} />
      <input type="hidden" name="order" value={rows.map((r) => r.id).join(",")} />
      {group("social", "Social media", "Small logos in the footer, in this order. Paste the link to your page or profile; typing one switches it on.")}
      {group("app", "Phone apps", "Small “App Store” and “Google Play” buttons beside them, once the apps are in the stores.")}
      <div className="flex flex-wrap items-center gap-3">
        <button type="submit" disabled={pending} className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60">
          {pending ? "Saving…" : "Save"}
        </button>
        <span className="text-sm text-zinc-500">{showing ? `${showing} will show in the footer.` : "None will show: the footer stays as it is."}</span>
      </div>
    </form>
  );
}
