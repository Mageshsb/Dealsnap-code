// The look shared by the admin editors (blog, events, banners).
export const field =
  "w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950";
// Every search box in Admin: the editors' field, 42px tall to line up with the
// filters and buttons beside it. Add layout (widths) beside it, never colours.
export const searchField =
  "min-h-[42px] rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-900";
export const label = "flex flex-col gap-1 text-sm font-medium";
export const hint = "text-xs font-normal text-zinc-500";
export const panel =
  "flex flex-col gap-4 rounded-2xl border border-zinc-200 bg-white p-4 sm:p-5 dark:border-zinc-800 dark:bg-zinc-900";
export const panelTitle = "text-sm font-bold uppercase tracking-wide text-zinc-500";
