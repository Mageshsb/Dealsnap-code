"use client";

import { ReactNode, useRef } from "react";
import Icon from "../Icon";

// A button that asks "are you sure?" in a small pop-up on the page (not the
// browser's own box) before the form it sits in is sent. It must sit inside
// that <form>: the confirm button in the pop-up is what submits it. Cancel,
// the ✕, the dim background and Escape all close it. Red when the button
// itself is red (a delete or removal), orange otherwise.
export default function ConfirmSubmitButton({
  confirmText,
  confirmLabel = "Yes, continue",
  className,
  children,
}: {
  confirmText: string;
  confirmLabel?: string;
  className?: string;
  children: ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const tone = /red/.test(className ?? "") ? "bg-red-600 hover:bg-red-700" : "bg-orange-500 hover:bg-orange-600";

  return (
    <>
      <button type="button" className={className} onClick={() => ref.current?.showModal()}>
        {children}
      </button>
      <dialog
        ref={ref}
        className="m-auto w-[min(24rem,calc(100vw-2rem))] rounded-2xl border border-zinc-200 bg-white p-0 text-left text-zinc-900 shadow-xl backdrop:bg-black/40 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
        onClick={(e) => {
          if (e.target === ref.current) ref.current?.close();
        }}
      >
        <div className="relative flex flex-col gap-4 p-5">
          <button
            type="button"
            aria-label="Close"
            tabIndex={-1}
            onClick={() => ref.current?.close()}
            className="absolute right-2 top-2 flex size-10 items-center justify-center rounded-full text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-zinc-800 dark:hover:text-zinc-200"
          >
            <Icon name="x" className="size-5" />
          </button>
          <p className="pr-8 text-sm font-medium">{confirmText}</p>
          <div className="flex flex-wrap justify-end gap-2">
            <button
              type="button"
              autoFocus
              onClick={() => ref.current?.close()}
              className="min-h-[40px] rounded-lg border border-zinc-300 px-4 text-sm font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
            >
              Cancel
            </button>
            {/* Closes after the click has sent the form, so the pop-up never
                stays open over a page that didn't reload. */}
            <button
              type="submit"
              onClick={() => setTimeout(() => ref.current?.close(), 0)}
              className={`min-h-[40px] rounded-lg px-4 text-sm font-semibold text-white ${tone}`}
            >
              {confirmLabel}
            </button>
          </div>
        </div>
      </dialog>
    </>
  );
}
