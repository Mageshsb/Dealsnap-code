"use client";

import { useActionState } from "react";
import { saveCommunitySettingsAction, type SpaceFormState } from "@/lib/community-actions";
import type { CommunitySettings } from "@/lib/community-db";
import { field, hint, label, panel, panelTitle } from "./formStyles";

const check = "mt-0.5 size-4 shrink-0 accent-orange-500";

function NumberField({ name, text, value, min, max, note }: { name: string; text: string; value: number; min: number; max: number; note?: string }) {
  return (
    <label className={label}>
      {text}
      <input type="number" name={name} defaultValue={value} min={min} max={max} inputMode="numeric" className={`${field} w-28`} />
      {note && <span className={hint}>{note}</span>}
    </label>
  );
}

export default function CommunityLimits({ s }: { s: CommunitySettings }) {
  const [state, action, pending] = useActionState<SpaceFormState, FormData>(saveCommunitySettingsAction, {});
  return (
    <form action={action} className="flex flex-col gap-5">
      {state.error && (
        <p role="alert" className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200">
          {state.error}
        </p>
      )}
      {state.saved && (
        <p role="status" className="rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-900 dark:border-green-900/50 dark:bg-green-950/30 dark:text-green-200">
          Saved.
        </p>
      )}

      <section className={panel}>
        <h2 className={panelTitle}>The Community</h2>
        <label className="flex items-start gap-2.5 text-sm font-medium">
          <input type="checkbox" name="on" defaultChecked={s.on} className={check} />
          <span className="flex flex-col gap-0.5">
            The Community is open
            <span className={hint}>Switch off to close it for everyone (nothing is deleted). Visitors see a short “closed for the moment” page.</span>
          </span>
        </label>
      </section>

      <section className={panel}>
        <h2 className={panelTitle}>New members</h2>
        <p className="text-sm text-zinc-500">
          Accounts younger than the age set in Settings → Spam limits are “new”. They can&apos;t post links (also set there) and have these lower limits. Nobody is made to wait for approval, because a member whose first post waits usually doesn&apos;t come back.
        </p>
        <div className="grid gap-4 sm:grid-cols-2">
          <NumberField name="newThreadsPerDay" text="Threads a day, new members" value={s.newThreadsPerDay} min={1} max={50} />
          <NumberField name="threadsPerDay" text="Threads a day, everyone else" value={s.threadsPerDay} min={1} max={200} />
          <NumberField name="newRepliesPerHour" text="Replies an hour, new members" value={s.newRepliesPerHour} min={1} max={200} />
          <NumberField name="repliesPerHour" text="Replies an hour, everyone else" value={s.repliesPerHour} min={1} max={500} />
        </div>
        <label className="flex items-start gap-2.5 text-sm font-medium">
          <input type="checkbox" name="holdFirstThreads" defaultChecked={s.holdFirstThreads} className={check} />
          <span className="flex flex-col gap-0.5">
            Check a member&apos;s first threads before they show
            <span className={hint}>Off is recommended. Turn it on if the Community is being flooded; the held threads wait on the Overview page.</span>
          </span>
        </label>
        <NumberField name="holdCount" text="How many of a member's first threads to check" value={s.holdCount} min={1} max={10} />
      </section>

      <section className={panel}>
        <h2 className={panelTitle}>Old threads</h2>
        <NumberField
          name="closeAfterDays"
          text="Close a thread after this many days with no reply"
          value={s.closeAfterDays}
          min={0}
          max={730}
          note="0 keeps every thread open for ever. At 90 or so, a reply to a long-quiet thread is refused politely and the member starts a new thread instead, so old conversations aren't dragged back to the top. Closed threads can still be read, and moderators can still reply. 30 days is the shortest."
        />
      </section>

      <section className={panel}>
        <h2 className={panelTitle}>Reports and words</h2>
        <NumberField
          name="autoHideReports"
          text="Reports that hide a post until a moderator looks"
          value={s.autoHideReports}
          min={2}
          max={20}
          note="Only reports from accounts over a week old count, so a pile of new accounts can't silence someone."
        />
        <label className={label}>
          Words that can&apos;t be used
          <textarea name="bannedWords" rows={5} defaultValue={s.bannedWords} className={`${field} resize-y`} placeholder={"One word or phrase per line"} />
          <span className={hint}>A post with one of these is refused with a polite message. Whole words only, any capitals. The word isn&apos;t shown to the writer.</span>
        </label>
      </section>

      <div className="flex justify-end">
        <button type="submit" disabled={pending} className="min-h-10 rounded-full bg-orange-500 px-5 py-2 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60">
          {pending ? "Saving…" : "Save"}
        </button>
      </div>
    </form>
  );
}
