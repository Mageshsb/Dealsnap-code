"use client";

import { useState, type ReactNode } from "react";
import { hint } from "./formStyles";

// One ad space's "where does it go" line: after the Nth deal, then every Mth,
// up to so many a page. "Up to 1" means the ad shows just once, so "then every"
// is greyed out while it's 1 (it's still sent, and has no effect).
export default function AdRepeatFields({
  id,
  name,
  of,
  ofPlural = `${of}s`,
  first,
  every,
  max,
  firstMin,
  firstMax,
  everyMin,
  everyMax,
  maxMax,
  className,
  children,
}: {
  id: string;
  name: string;
  of: string; // "deal", "card", "paragraph", "thread" or "reply"
  ofPlural?: string;
  first: number;
  every: number;
  max: number;
  firstMin: number;
  firstMax: number;
  everyMin: number;
  everyMax: number;
  maxMax: number;
  className: string; // the number box's look
  children?: ReactNode; // the rules written under the boxes
}) {
  const [most, setMost] = useState(String(max));
  const once = most === "1";
  return (
    <div className="flex flex-wrap items-center gap-2 text-sm">
      After {of}
      <input type="number" name={`first-${id}`} min={firstMin} max={firstMax} defaultValue={first} aria-label={`${name}: first after ${of}`} className={className} />
      <span className={once ? "text-zinc-500 dark:text-zinc-400" : ""}>then every</span>
      <input
        type="number"
        name={`every-${id}`}
        min={everyMin}
        max={everyMax}
        defaultValue={every}
        aria-label={`${name}: then every`}
        className={`${className} ${once ? "opacity-40" : ""}`}
      />
      <span className={once ? "text-zinc-500 dark:text-zinc-400" : ""}>{ofPlural},</span>
      up to
      <input
        type="number"
        name={`max-${id}`}
        min={0}
        max={maxMax}
        value={most}
        onChange={(e) => setMost(e.target.value)}
        aria-label={`${name}: most on a page`}
        className={className}
      />
      a page
      <span className={`${hint} w-full`}>
        {once ? "Just once a page, after the first one above. “Then every” isn't used." : "Set “up to” to 1 to show it just once a page."} {children}
      </span>
    </div>
  );
}
