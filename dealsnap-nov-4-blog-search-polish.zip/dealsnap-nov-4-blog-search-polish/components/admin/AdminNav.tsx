"use client";

import Link from "next/link";
import { useState } from "react";
import { usePathname } from "next/navigation";
import Icon, { type IconName } from "@/components/Icon";

// `todo` is how many things in that section are waiting for staff (deals to
// review, reports, unanswered messages): the only number shown, so a red
// badge always means "something needs you here".
// `also` lists other addresses that belong under the same item (Site content
// holds the pages for the top strip, promos and events).
export type AdminNavItem = { href: string; label: string; icon: IconName; todo?: number; also?: string[] };
export type AdminNavGroup = { label?: string; items: AdminNavItem[] };

function useActive() {
  const pathname = usePathname();
  return (item: AdminNavItem) =>
    item.href === "/admin" ? pathname === "/admin" : [item.href, ...(item.also ?? [])].some((h) => pathname.startsWith(h));
}

function Todo({ n }: { n?: number }) {
  if (!n) return null;
  return (
    <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1.5 text-[11px] font-bold tabular-nums text-white">
      {n > 99 ? "99+" : n}
    </span>
  );
}

// Down the side on tablets and desktop, grouped like the work itself
// (moderating, growing the site, running it), as My account's menu is.
export function AdminSidebar({ groups }: { groups: AdminNavGroup[] }) {
  const isActive = useActive();
  return (
    <nav aria-label="Admin sections" className="flex flex-col gap-4">
      {groups.map((g, i) => (
        <div key={g.label ?? i} className="flex flex-col gap-0.5">
          {g.label && (
            <p className="px-3 pb-1 text-xs font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">{g.label}</p>
          )}
          {g.items.map((item) => {
            const active = isActive(item);
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm ${
                  active
                    ? "bg-orange-100 font-medium text-orange-700 dark:bg-orange-950/50 dark:text-orange-400"
                    : "text-zinc-700 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
                }`}
              >
                <Icon name={item.icon} className={`size-[18px] ${active ? "" : "text-zinc-500 dark:text-zinc-400"}`} />
                <span className="flex-1">{item.label}</span>
                <Todo n={item.todo} />
              </Link>
            );
          })}
        </div>
      ))}
    </nav>
  );
}

// Phones: every section as a tile, three to a row, so all of them show
// without side-scrolling. Only the Dashboard opens with them all showing;
// every other page has one bar naming where you are, which opens them, so
// the page itself starts at the top of the screen.
export function AdminTabs({ groups }: { groups: AdminNavGroup[] }) {
  const isActive = useActive();
  const pathname = usePathname();
  const [openOn, setOpenOn] = useState<string | null>(null);
  const items = groups.flatMap((g) => g.items);
  const onDashboard = pathname === "/admin";
  const open = onDashboard || openOn === pathname;
  const current = items.find((item) => isActive(item));
  const waiting = items.reduce((n, item) => n + (item.todo ?? 0), 0);

  return (
    <div className="flex flex-col gap-1.5">
      {!onDashboard && (
        <button
          type="button"
          onClick={() => setOpenOn(open ? null : pathname)}
          aria-expanded={open}
          className="flex min-h-11 items-center gap-2 rounded-lg bg-zinc-100/70 px-3 text-sm font-medium text-zinc-700 dark:bg-zinc-900 dark:text-zinc-300"
        >
          {current && <Icon name={current.icon} className="size-4 text-orange-700 dark:text-orange-400" />}
          <span className="flex-1 text-left">{current?.label ?? "Admin"}</span>
          <span className="text-xs text-zinc-500">All sections</span>
          <Todo n={waiting} />
          <Icon name="chevron-down" className={`size-4 text-zinc-500 dark:text-zinc-400 transition-transform ${open ? "rotate-180" : ""}`} />
        </button>
      )}
      {open && (
        <nav aria-label="Admin sections" className="grid grid-cols-3 gap-1.5">
          {items.map((item) => {
            const active = isActive(item);
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpenOn(null)}
                aria-current={active ? "page" : undefined}
                className={`relative flex min-h-[52px] flex-col items-center justify-center gap-1 rounded-lg px-1 py-1.5 text-[12px] font-medium leading-tight whitespace-nowrap ${
                  active
                    ? "bg-orange-100 text-orange-700 dark:bg-orange-950/50 dark:text-orange-400"
                    : "bg-zinc-100/70 text-zinc-600 hover:bg-zinc-200/70 dark:bg-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800"
                }`}
              >
                <Icon name={item.icon} className="size-4" />
                <span>{item.label}</span>
                {Boolean(item.todo) && (
                  <span className="absolute right-1 top-1">
                    <Todo n={item.todo} />
                  </span>
                )}
              </Link>
            );
          })}
        </nav>
      )}
    </div>
  );
}
