"use client";

import { useState, useTransition } from "react";
import Icon from "@/components/Icon";
import { makeEngineKeyAction } from "@/lib/engine-actions";
import StableLabel, { words } from "../StableLabel";

// Makes the deal engine's key and shows it once, here on the page, to copy
// into the engine's settings. It's never shown again (only a fingerprint is
// kept), and replacing it stops the old one, so that asks first.
export default function EngineKeyButton({ hasKey }: { hasKey: boolean }) {
  const [key, setKey] = useState<string | null>(null);
  const [asking, setAsking] = useState(false);
  const [copied, setCopied] = useState(false);
  const [pending, start] = useTransition();

  function make() {
    setAsking(false);
    start(async () => setKey((await makeEngineKeyAction()).key));
  }

  async function copy() {
    if (!key) return;
    try {
      await navigator.clipboard.writeText(key);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      (document.getElementById("engine-key") as HTMLInputElement | null)?.select();
    }
  }

  if (key) {
    return (
      <div className="flex flex-col gap-2 rounded-lg bg-amber-50 p-3 dark:bg-amber-950/30">
        <p className="text-sm font-medium text-amber-900 dark:text-amber-200">
          <Icon name="warning" className="mr-1.5" />
          Copy it now into the engine&apos;s settings: it won&apos;t be shown again.
        </p>
        <div className="flex flex-wrap gap-2">
          <input
            id="engine-key"
            readOnly
            value={key}
            onFocus={(e) => e.currentTarget.select()}
            className="min-w-0 flex-1 rounded-lg border border-zinc-300 bg-white px-3 py-2 font-mono text-xs dark:border-zinc-700 dark:bg-zinc-900"
          />
          <button type="button" onClick={copy} className="rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">
            <StableLabel options={words("Copy", "Copied")} show={copied ? "Copied" : "Copy"} />
          </button>
        </div>
      </div>
    );
  }

  if (asking) {
    return (
      <div className="flex flex-wrap items-center gap-2 text-sm">
        <span>The engine&apos;s current key will stop working. Make a new one?</span>
        <button type="button" onClick={make} className="rounded-full bg-orange-500 px-4 py-1.5 font-semibold text-white hover:bg-orange-600">
          Yes, make a new key
        </button>
        <button type="button" onClick={() => setAsking(false)} className="rounded-full border border-zinc-300 px-4 py-1.5 font-semibold dark:border-zinc-700">
          Cancel
        </button>
      </div>
    );
  }

  return (
    <button
      type="button"
      disabled={pending}
      onClick={() => (hasKey ? setAsking(true) : make())}
      className={`self-start rounded-full px-4 py-2 text-sm font-semibold disabled:opacity-60 ${
        hasKey
          ? "border border-zinc-300 text-zinc-700 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
          : "bg-orange-500 text-white hover:bg-orange-600"
      }`}
    >
      {pending ? "Making it…" : hasKey ? "Make a new key" : "Make the engine's key"}
    </button>
  );
}
