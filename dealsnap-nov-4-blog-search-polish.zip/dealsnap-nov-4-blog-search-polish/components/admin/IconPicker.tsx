"use client";

import { useState } from "react";
import Icon, { ICON_NAMES, type IconName } from "../Icon";
import { searchField } from "@/components/admin/formStyles";

// Picks one of the site's icons for a category or tag. The grid is only drawn
// once opened, so a page with many of these stays light.
export default function IconPicker({ name, defaultValue, label = "Icon" }: { name: string; defaultValue: IconName; label?: string }) {
  const [value, setValue] = useState<IconName>(defaultValue);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const shown = ICON_NAMES.filter((n) => n.includes(query.trim().toLowerCase()));

  return (
    <div className="flex flex-col gap-2">
      <input type="hidden" name={name} value={value} />
      <button
        type="button"
        aria-expanded={open}
        aria-label={`${label}: ${value}. Change it`}
        onClick={() => setOpen((o) => !o)}
        className="flex min-h-10 items-center gap-2 self-start rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-sm hover:border-zinc-400 dark:border-zinc-700 dark:bg-zinc-950"
      >
        <Icon name={value} className="size-5 text-zinc-700 dark:text-zinc-200" />
        <span className="text-zinc-600 dark:text-zinc-300">{value}</span>
        <Icon name="chevron-down" className={`size-4 text-zinc-500 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="flex flex-col gap-2 rounded-xl border border-zinc-200 bg-white p-2 dark:border-zinc-700 dark:bg-zinc-900">
          <input
            type="search"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              // Enter is for finding icons here; it mustn't send the whole form.
              if (e.key === "Enter") e.preventDefault();
            }}
            placeholder="Search icons, e.g. dog, car, gift"
            aria-label="Search icons"
            className={`w-full ${searchField}`}
          />
          {shown.length === 0 && <p className="px-1 py-2 text-sm text-zinc-500">No icon has that name. The site&apos;s icon set is fixed, so try another word.</p>}
          <div role="radiogroup" aria-label={label} className="grid max-h-56 grid-cols-6 gap-1 overflow-y-auto sm:grid-cols-8">
            {shown.map((n) => (
              <button
                key={n}
                type="button"
                role="radio"
                aria-checked={n === value}
                aria-label={n}
                title={n}
                onClick={() => {
                  setValue(n);
                  setOpen(false);
                  setQuery("");
                }}
                className={`flex h-10 items-center justify-center rounded-lg ${
                  n === value ? "bg-orange-500 text-white" : "text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
                }`}
              >
                <Icon name={n} className="size-5" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
