"use client";

import { useState } from "react";
import Icon from "@/components/Icon";
import { copyText } from "@/components/VoucherCode";
import StableLabel, { words } from "../StableLabel";

// A link to hand on (an advertiser's report link), with a Copy button.
export default function CopyField({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="flex min-w-0 items-center gap-2">
      <input
        readOnly
        value={value}
        aria-label={label}
        onFocus={(e) => e.currentTarget.select()}
        className="min-w-0 flex-1 rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 font-mono text-xs outline-none dark:border-zinc-700 dark:bg-zinc-950"
      />
      <button
        type="button"
        onClick={async () => {
          if (await copyText(value)) {
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
          }
        }}
        className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-orange-500 px-3 py-2 text-xs font-semibold text-white hover:bg-orange-600"
      >
        <Icon name={copied ? "check" : "copy"} className="size-3.5" />
        <StableLabel options={words("Copy", "Copied")} show={copied ? "Copied" : "Copy"} />
      </button>
    </div>
  );
}
