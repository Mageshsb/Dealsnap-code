"use client";

import { useActionState, useState } from "react";
import Notice from "./Notice";
import { field, hint, label, panel, panelTitle } from "./formStyles";
import { saveCompanyAction, type PageFormState } from "@/lib/page-actions";
import { LEGAL_LIMITS, SAMPLE_EMAILS, type Legal } from "@/lib/legal-shared";

// Who runs the site and the three inboxes. Kept in one place so Terms, Privacy,
// Contact and the contact form can't disagree. A failed check keeps what was typed.
export default function CompanyForm({ initial, notice }: { initial: Legal; notice?: string }) {
  const [state, formAction, pending] = useActionState<PageFormState, FormData>(saveCompanyAction, {});
  const [v, setV] = useState({
    operator: initial.operator,
    companyNumber: initial.companyNumber,
    address: initial.registeredAddress,
    icoNumber: initial.icoNumber,
    supportEmail: initial.email.support,
    privacyEmail: initial.email.privacy,
    partnersEmail: initial.email.partners,
  });
  const set = (key: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setV((p) => ({ ...p, [key]: e.target.value }));
  const sample = Object.values(SAMPLE_EMAILS);
  const stillSample = [v.supportEmail, v.privacyEmail, v.partnersEmail].some((e) => sample.includes(e));

  return (
    <form action={formAction} className="flex flex-col gap-5">
      <Notice notice={notice} error={state.error} />
      {stillSample && (
        <p className="rounded-lg bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
          One or more inboxes are still the sample addresses (ending .example), so mail to them goes nowhere. Put in real ones before you tell people about the site.
        </p>
      )}

      <section className={panel}>
        <h2 className={panelTitle}>The company</h2>
        <p className="-mt-2 text-sm text-zinc-500">Leave anything you don&apos;t have empty: pages simply leave it out.</p>
        <label className={label}>
          Company or trading name
          <span className={hint}>Whoever is legally responsible for the site, e.g. “DealSnap Ltd”. Empty shows just “DealSnap”.</span>
          <input name="operator" maxLength={LEGAL_LIMITS.operator} value={v.operator} onChange={set("operator")} className={field} />
        </label>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <label className={label}>
            Companies House number
            <input name="companyNumber" maxLength={LEGAL_LIMITS.companyNumber} value={v.companyNumber} onChange={set("companyNumber")} className={field} />
          </label>
          <label className={label}>
            ICO registration number
            <span className={hint}>For the yearly data protection fee, e.g. ZB123456.</span>
            <input name="icoNumber" maxLength={LEGAL_LIMITS.icoNumber} value={v.icoNumber} onChange={set("icoNumber")} className={field} />
          </label>
        </div>
        <label className={label}>
          Registered office or postal address
          <textarea name="address" rows={2} maxLength={LEGAL_LIMITS.registeredAddress} value={v.address} onChange={set("address")} className={field} />
        </label>
      </section>

      <section className={panel}>
        <h2 className={panelTitle}>Inboxes</h2>
        <p className="-mt-2 text-sm text-zinc-500">
          Contact form messages are always kept in Messages, and also emailed to the inbox for their topic once email is set up.
        </p>
        <label className={label}>
          Help and feedback
          <input name="supportEmail" type="email" maxLength={LEGAL_LIMITS.email} value={v.supportEmail} onChange={set("supportEmail")} className={field} />
        </label>
        <label className={label}>
          Privacy and your data
          <input name="privacyEmail" type="email" maxLength={LEGAL_LIMITS.email} value={v.privacyEmail} onChange={set("privacyEmail")} className={field} />
        </label>
        <label className={label}>
          Stores, partnerships and advertising
          <input name="partnersEmail" type="email" maxLength={LEGAL_LIMITS.email} value={v.partnersEmail} onChange={set("partnersEmail")} className={field} />
        </label>
      </section>

      <div>
        <button type="submit" disabled={pending} className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60">
          {pending ? "Saving…" : "Save"}
        </button>
      </div>
    </form>
  );
}
