import Link from "next/link";
import SelectField from "@/components/SelectField";
import Icon from "@/components/Icon";
import { deleteEventAction, saveEventAction, setEventLaunchedAction } from "@/lib/content-actions";
import {
  EVENT_ICONS,
  EVENT_KINDS,
  EVENT_REPEATS,
  eventState,
  eventTiming,
  type ShoppingEvent,
} from "@/lib/events";
import ConfirmSubmitButton from "./ConfirmSubmitButton";
import EventStatePill from "./EventState";
import { field, hint, label, panel, panelTitle } from "./formStyles";

// The places an event can show, each with its own switch.
const SWITCHES = [
  {
    name: "showButton",
    initially: true,
    label: "Button in the category bar",
    hint: "At the front of the row of categories while it's on.",
  },
  {
    name: "showTick",
    initially: true,
    label: "Tick when posting a deal",
    hint: "Posters can mark their deal as part of it.",
  },
] as const;

// A shopping event: what it's called, which deals fit it, and when it's on.
// Launching and taking it down is separate from saving, so edits can be made
// quietly while it's up.
export default function EventEditor({
  event,
  error,
  notice,
}: {
  event?: ShoppingEvent;
  error?: string;
  notice?: string;
}) {
  const state = event ? eventState(event) : undefined;
  const timing = event ? eventTiming(event) : undefined;

  return (
    <div className="flex max-w-2xl flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <Link
            href="/admin/events"
            className="-my-1.5 inline-flex min-h-9 items-center self-start text-sm text-zinc-500 hover:underline"
          >
            ← All events
          </Link>
          <h1 className="mt-2 text-xl font-bold sm:text-2xl">{event ? event.name : "New event"}</h1>
        </div>
        {event && (
          <Link
            href={`/${event.slug}`}
            target="_blank"
            className="rounded-full border border-zinc-300 px-4 py-2 text-sm font-semibold hover:bg-zinc-50 dark:border-zinc-700 dark:hover:bg-zinc-800"
          >
            {event.launched ? "View page ↗" : "Preview ↗"}
          </Link>
        )}
      </div>

      {notice && (
        <p className="rounded-lg bg-green-50 px-4 py-2 text-sm text-green-800 dark:bg-green-950/40 dark:text-green-300">
          <Icon name="circle-check" className="mr-1.5" />
          {notice}
        </p>
      )}
      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400">
          {error}
        </p>
      )}

      {event && state && (
        <section className={panel}>
          <h2 className={panelTitle}>Status</h2>
          <div className="flex flex-wrap items-center gap-3">
            <EventStatePill state={state} />
            <span className="text-sm text-zinc-500">
              Shows from {timing?.showFrom} to {timing?.showUntil}
            </span>
          </div>
          <p className={hint}>
            {event.launched
              ? "Launched: the page is public, its button shows in the category bar while it's on, and posters can tick it. Taking it down hides all of that (deals keep their ticks)."
              : "Not launched: only admins can see the page. Launch it when it's ready; it then shows by itself from its start date."}
          </p>
          <form action={setEventLaunchedAction}>
            <input type="hidden" name="id" value={event.id} />
            <input type="hidden" name="launch" value={event.launched ? "0" : "1"} />
            {event.launched ? (
              <ConfirmSubmitButton
                confirmText={`Take ${event.name} down? Its page and button disappear from the site.`}
                confirmLabel="Take down"
                className="rounded-full border border-red-300 px-5 py-2.5 text-sm font-semibold text-red-600 hover:bg-red-50 dark:border-red-900 dark:hover:bg-red-950/30"
              >
                Take down
              </ConfirmSubmitButton>
            ) : (
              <button
                type="submit"
                className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600"
              >
                Launch
              </button>
            )}
          </form>
        </section>
      )}

      <form action={saveEventAction} className="flex flex-col gap-5">
        {event && <input type="hidden" name="id" value={event.id} />}

        <section className={panel}>
          <label className={label}>
            Name
            <input
              name="name"
              required
              maxLength={40}
              defaultValue={event?.name}
              placeholder="Easter"
              className={field}
            />
          </label>
          <label className={label}>
            Web address
            {event ? (
              <>
                <span className={hint}>Fixed once made, so links and Google keep working.</span>
                <input value={`/${event.slug}`} readOnly className={`${field} text-zinc-500`} />
              </>
            ) : (
              <>
                <span className={hint}>Stays the same every year, like /easter.</span>
                <input name="slug" maxLength={40} placeholder="made from the name" className={field} />
              </>
            )}
          </label>
          <label className={label}>
            Short intro
            <span className={hint}>One line under the dates at the top of the page. Optional.</span>
            <textarea name="blurb" rows={2} maxLength={200} defaultValue={event?.blurb} className={field} />
          </label>
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>Which deals belong</h2>
          <label className={label}>
            Words that count
            <span className={hint}>
              A deal whose title or description uses any of these joins the event by itself. One per line; the first is
              what the page&apos;s alert button watches. Posters can also tick it, and helpers can remove a deal that
              doesn&apos;t fit.
            </span>
            <textarea
              name="keywords"
              required
              rows={5}
              defaultValue={event?.keywords.join("\n")}
              placeholder={"easter\negg hunt\nsimnel"}
              className={field}
            />
          </label>
          <label className={label}>
            Type
            <SelectField
              look="admin"
              name="kind"
              label="Type of event"
              defaultValue={event?.kind ?? "theme"}
              options={EVENT_KINDS.map((k) => ({ value: k.value, label: k.label }))}
            />
            <span className={hint}>{EVENT_KINDS.map((k) => `${k.label}: ${k.hint}`).join(" ")}</span>
          </label>
          <fieldset className="flex flex-col gap-1.5">
            <legend className="mb-1.5 text-sm font-medium">Icon</legend>
            <div className="flex flex-wrap gap-1.5">
              {EVENT_ICONS.map((name) => (
                <label
                  key={name}
                  className="flex size-11 cursor-pointer items-center justify-center rounded-xl bg-zinc-100 text-zinc-600 transition-colors hover:bg-zinc-200 has-checked:bg-orange-500 has-checked:text-white has-focus-visible:ring-2 has-focus-visible:ring-orange-500 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700 dark:has-checked:bg-orange-500 dark:has-checked:text-white"
                >
                  <input
                    type="radio"
                    name="icon"
                    value={name}
                    defaultChecked={(event?.icon ?? "tag") === name}
                    className="sr-only"
                  />
                  <Icon name={name} className="size-5" />
                  <span className="sr-only">{name}</span>
                </label>
              ))}
            </div>
          </fieldset>
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>When</h2>
          <p className={hint}>Fill these in for one year; if it repeats, the next years work themselves out.</p>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <label className={label}>
              The day
              <input type="date" name="date" required defaultValue={event?.date} className={field} />
            </label>
            <label className={label}>
              Last day of the deals
              <input type="date" name="endsOn" defaultValue={event?.endsOn} className={field} />
            </label>
            <label className={label}>
              Starts showing on the site
              <input type="date" name="showFrom" required defaultValue={event?.showFrom} className={field} />
            </label>
            <label className={label}>
              Stops showing
              <input type="date" name="showUntil" defaultValue={event?.showUntil} className={field} />
            </label>
          </div>
          <label className={label}>
            Repeats
            <SelectField
              look="admin"
              name="repeat"
              label="Repeats"
              defaultValue={event?.repeat ?? "yearly"}
              options={EVENT_REPEATS.map((r) => ({ value: r.value, label: r.label }))}
            />
          </label>
          <label className={label}>
            What the last day is called
            <span className={hint}>Like Cyber Monday. Optional.</span>
            <input name="endsLabel" maxLength={30} defaultValue={event?.endsLabel} className={field} />
          </label>
        </section>

        <section className={panel}>
          <h2 className={panelTitle}>Where it shows</h2>
          <p className={hint}>
            While the event is on, you choose each place on its own. The page itself is the Launch button above; taking
            it down switches everything off.
          </p>
          {SWITCHES.map((sw) => (
            <label key={sw.name} className="flex items-start gap-2 text-sm font-medium">
              <input
                type="checkbox"
                name={sw.name}
                defaultChecked={event ? event[sw.name] : sw.initially}
                className="mt-0.5 h-4 w-4 accent-orange-500"
              />
              <span>
                {sw.label}
                <span className={`block ${hint}`}>{sw.hint}</span>
              </span>
            </label>
          ))}
        </section>

        <div>
          <button
            type="submit"
            className="rounded-full bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600"
          >
            {event ? "Save" : "Create event"}
          </button>
        </div>
      </form>

      {event && (
        <form action={deleteEventAction}>
          <input type="hidden" name="id" value={event.id} />
          <ConfirmSubmitButton
            confirmText={`Delete ${event.name} for good? Its page goes and deals lose their ticks for it.`}
            className="text-sm font-medium text-red-600 hover:underline"
          >
            Delete this event
          </ConfirmSubmitButton>
        </form>
      )}
    </div>
  );
}
