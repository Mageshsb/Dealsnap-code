import type { EventState } from "@/lib/events";

const LOOK: Record<EventState, { label: string; style: string }> = {
  draft: { label: "Not launched", style: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400" },
  scheduled: {
    label: "Launched, not showing yet",
    style: "bg-sky-100 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400",
  },
  on: { label: "On now", style: "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400" },
  finished: { label: "Finished", style: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400" },
};

// Where an event stands, as a small pill.
export default function EventStatePill({ state }: { state: EventState }) {
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${LOOK[state].style}`}>{LOOK[state].label}</span>
  );
}
