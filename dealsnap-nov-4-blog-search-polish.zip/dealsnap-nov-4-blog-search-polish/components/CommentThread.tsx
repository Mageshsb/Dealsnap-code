"use client";

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import CommentComposer, { revealComment } from "./CommentComposer";
import Icon from "./Icon";

// A top comment and its replies (one level only: answering a reply adds to
// the same thread). The first two replies show; the rest open in place. The
// reply box opens at the end of the thread, where the reply will land.
const VISIBLE_REPLIES = 2;

type Target = { id: string; username: string };
const OpenReply = createContext<((target: Target) => void) | null>(null);

// "Reply" under any comment in the thread: opens (or retargets) its box.
export function ReplyButton({ id, username }: Target) {
  const openReply = useContext(OpenReply);
  if (!openReply) return null;
  return (
    <button type="button" onClick={() => openReply({ id, username })} className="flex items-center gap-1 transition-colors hover:text-orange-500">
      <Icon name="reply" className="size-3.5" />
      Reply
    </button>
  );
}

export default function CommentThread({
  dealSlug,
  maxPictures = 0,
  root,
  replies,
  replyIds,
}: {
  dealSlug: string;
  // Pictures a comment can have (0 for a brand-new account).
  maxPictures?: number;
  root: ReactNode;
  replies: ReactNode[];
  replyIds: string[];
}) {
  const [target, setTarget] = useState<Target | null>(null);
  const [expanded, setExpanded] = useState(false);
  const openReply = useCallback((t: Target) => setTarget(t), []);
  const hiddenCount = expanded ? 0 : Math.max(0, replies.length - VISIBLE_REPLIES);

  // A link to a reply that's tucked away (from a notification, or "Most
  // helpful") opens the thread, then brings the reply into view.
  const hiddenIds = replyIds.slice(VISIBLE_REPLIES).join(",");
  useEffect(() => {
    if (!hiddenIds) return;
    const hidden = hiddenIds.split(",");
    function onHash() {
      const id = location.hash.replace(/^#comment-/, "");
      if (!hidden.includes(id)) return;
      setExpanded(true);
      revealComment(id);
    }
    onHash();
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, [hiddenIds]);

  return (
    <OpenReply.Provider value={openReply}>
      {root}
      {(replies.length > 0 || target) && (
        // The line drops from the top comment's picture; replies' pictures
        // line up with its text.
        <div className="ml-[11px] mt-3 flex flex-col gap-3 border-l-2 border-zinc-100 pl-[19px] dark:border-zinc-800">
          {replies.map((reply, i) => (
            <div key={replyIds[i]} className={i >= VISIBLE_REPLIES && !expanded ? "hidden" : undefined}>
              {reply}
            </div>
          ))}
          {hiddenCount > 0 && (
            <button
              type="button"
              onClick={() => setExpanded(true)}
              aria-expanded={false}
              className="flex items-center gap-1 self-start text-xs font-semibold text-orange-700 hover:underline dark:text-orange-400"
            >
              <Icon name="chevron-down" className="size-4" />
              {hiddenCount} more {hiddenCount === 1 ? "reply" : "replies"}
            </button>
          )}
          {target && (
            <CommentComposer
              dealSlug={dealSlug}
              maxPictures={maxPictures}
              targetId={target.id}
              replyingTo={target.username}
              onCancel={() => setTarget(null)}
              onPosted={() => {
                setTarget(null);
                setExpanded(true);
              }}
            />
          )}
        </div>
      )}
    </OpenReply.Provider>
  );
}
