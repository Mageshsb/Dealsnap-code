import Link from "next/link";
import { timeAgo } from "@/lib/format";
import { FeedItem } from "@/lib/social";
import UsernameLink from "./UsernameLink";
import Icon, { HeartIcon } from "./Icon";
import { dealIcon } from "@/lib/categories";

export default function ActivityFeed({ items }: { items: FeedItem[] }) {
  return (
    <div className="flex flex-col gap-2">
      {items.map((item, i) => (
        <div
          key={`${item.type}-${item.deal.slug}-${item.userId}-${i}`}
          className="flex flex-col gap-1.5 rounded-xl border border-zinc-200 p-3 text-sm dark:border-zinc-800"
        >
          {/* Who did what, and when */}
          <div className="flex min-w-0 items-center gap-2">
            <UsernameLink
              username={item.username}
              userId={item.userId}
              size="h-6 w-6"
              className="flex min-w-0 items-center gap-1.5 truncate font-medium"
            />
            <span className="flex shrink-0 items-center gap-1 text-zinc-500">
              {item.type === "loved" && <HeartIcon className="size-3.5" />}
              {item.type === "posted" ? "posted" : "loved"}
            </span>
            <span className="ml-auto shrink-0 text-xs text-zinc-500 dark:text-zinc-400">{timeAgo(item.at)}</span>
          </div>
          {/* The deal, with its hearts so "Most hearts" makes sense */}
          <div className="flex min-w-0 items-center gap-2">
            <Link href={`/deals/${item.deal.slug}`} className="flex min-w-0 flex-1 items-center gap-1.5 font-medium hover:underline">
              <Icon name={dealIcon(item.deal)} className="size-4 text-zinc-500 dark:text-zinc-400" />
              <span className="truncate">{item.deal.title}</span>
            </Link>
            <span className="flex shrink-0 items-center gap-1 text-xs tabular-nums text-zinc-500" aria-label={`${item.deal.hearts} hearts`}>
              <HeartIcon className="size-3" />
              {item.deal.hearts}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}
