import Link from "next/link";
import { countOf, romanNumeral, type BadgeProgress } from "@/lib/badges";
import TierBadge, { TierPip, tierName, tierText } from "./TierBadge";

// How far through the current step (last tier reached → next one) a badge is.
function stepProgress(b: BadgeProgress) {
  if (b.nextTarget === null) return 1;
  const from = b.tiers[b.tier - 1] ?? 0;
  return (b.value - from) / (b.nextTarget - from);
}

// The Badges tab: one card per badge with its current tier, the ladder of
// tiers above it and how far to the next one, so people can see what to aim
// for next.
export default function BadgesPanel({ badges, isOwner }: { badges: BadgeProgress[]; isOwner: boolean }) {
  const earned = badges.reduce((n, b) => n + b.tier, 0);
  const total = badges.reduce((n, b) => n + b.tiers.length, 0);

  // The next tier that's closest to done — the "next up" nudge.
  const next = badges.filter((b) => b.nextTarget !== null).sort((a, b) => stepProgress(b) - stepProgress(a))[0];

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900 sm:p-6">
        <p className="text-lg font-semibold">
          {earned} of {total} badge tiers earned
        </p>
        <div
          className="mt-1 h-2 w-full overflow-hidden rounded-full bg-zinc-100 dark:bg-zinc-800"
          role="progressbar"
          aria-valuemin={0}
          aria-valuemax={total}
          aria-valuenow={earned}
          aria-label="Badge tiers earned"
        >
          <div className="h-full rounded-full bg-orange-500" style={{ width: `${(earned / total) * 100}%` }} />
        </div>
        {next ? (
          <p className="mt-2 text-sm text-zinc-500">
            {isOwner ? "Next up" : "Closest to"}:{" "}
            <span className="font-medium text-zinc-700 dark:text-zinc-300">
              {next.name} {romanNumeral(next.tier + 1)}
            </span>{" "}
            — {countOf(next.nextTarget! - next.value, next.unit, true)}
          </p>
        ) : (
          <p className="mt-2 text-sm text-zinc-500">{isOwner ? "You've" : "They've"} reached the top tier of every badge.</p>
        )}
        <p className="mt-2 border-t border-zinc-100 pt-2 text-xs text-zinc-500 dark:border-zinc-800">
          Approved deals and codes count, even after they end. Deals removed for breaking the{" "}
          <Link href="/guidelines" className="underline hover:text-zinc-700 dark:hover:text-zinc-300">
            rules
          </Link>{" "}
          (duplicates, wrong details, spam) don&apos;t.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {badges.map((b) => (
          <section
            key={b.key}
            className="flex flex-col gap-4 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900"
          >
            <div className="flex items-center gap-4">
              <TierBadge icon={b.icon} tier={b.tier} />
              <div className="flex min-w-0 flex-col">
                <h2 className="font-bold">
                  {b.name}
                  {b.tier > 0 && <span className={`ml-1.5 font-bold ${tierText(b.tier)}`}>{romanNumeral(b.tier)}</span>}
                </h2>
                <p className="text-sm text-zinc-500">
                  {b.tier > 0 ? `${tierName(b.tier)} tier` : "Not earned yet"} · {countOf(b.value, b.unit)}
                </p>
              </div>
            </div>

            {/* The ladder: each tier's numeral with what it takes. */}
            <ol className="grid gap-1" style={{ gridTemplateColumns: `repeat(${b.tiers.length}, minmax(0, 1fr))` }}>
              {b.tiers.map((target, i) => (
                <li key={target} className="flex flex-col items-center gap-1">
                  <TierPip tier={i + 1} reached={b.tier > i} />
                  <span className="text-[11px] tabular-nums text-zinc-500">
                    <span className="sr-only">
                      Tier {romanNumeral(i + 1)}{b.tier > i ? " (earned)" : ""}:{" "}
                    </span>
                    {target.toLocaleString("en-GB")}
                  </span>
                </li>
              ))}
            </ol>

            {b.nextTarget !== null ? (
              <div className="flex flex-col gap-1">
                <div
                  className="h-2 w-full overflow-hidden rounded-full bg-zinc-100 dark:bg-zinc-800"
                  role="progressbar"
                  aria-valuemin={b.tiers[b.tier - 1] ?? 0}
                  aria-valuemax={b.nextTarget}
                  aria-valuenow={b.value}
                  aria-label={`${b.name} ${romanNumeral(b.tier + 1)} progress`}
                >
                  <div className="h-full rounded-full bg-orange-500" style={{ width: `${Math.round(stepProgress(b) * 100)}%` }} />
                </div>
                <p className="text-xs text-zinc-500">
                  {countOf(b.nextTarget - b.value, b.unit, true)} to reach {romanNumeral(b.tier + 1)}
                </p>
              </div>
            ) : (
              // The count keeps growing past the top tier, so show it: a new
              // tier VI later picks up from where they already are.
              <p className="text-xs font-medium text-orange-700 dark:text-orange-400">
                Top tier reached · {countOf(b.value, b.unit)}
              </p>
            )}
          </section>
        ))}
      </div>
    </div>
  );
}
