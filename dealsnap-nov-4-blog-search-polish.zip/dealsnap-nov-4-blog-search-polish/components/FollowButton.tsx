"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { followAction, unfollowAction, setFollowMutedAction } from "@/lib/actions";
import Icon from "./Icon";

export default function FollowButton({
  targetUserId,
  initialFollowing,
  initialMuted,
}: {
  targetUserId: string;
  initialFollowing: boolean;
  initialMuted: boolean;
}) {
  const [following, setFollowing] = useState(initialFollowing);
  const [muted, setMuted] = useState(initialMuted);
  const [, startTransition] = useTransition();
  const router = useRouter();

  // Follower/following counts elsewhere on the page are server-rendered, so
  // a refresh after the mutation keeps them in sync with this button's own
  // (already-updated) optimistic state.
  function toggleFollow() {
    if (following) {
      setFollowing(false);
      setMuted(false);
      startTransition(async () => {
        await unfollowAction(targetUserId);
        router.refresh();
      });
    } else {
      setFollowing(true);
      startTransition(async () => {
        await followAction(targetUserId);
        router.refresh();
      });
    }
  }

  function toggleMute() {
    const next = !muted;
    setMuted(next);
    startTransition(async () => {
      await setFollowMutedAction(targetUserId, next);
      router.refresh();
    });
  }

  return (
    <div className="flex items-center gap-2">
      {/* The same size whether following or not, and when hovering shows
          "Unfollow": all three wordings share one spot, so nothing moves. */}
      <button
        onClick={toggleFollow}
        className={`group rounded-full border px-4 py-1.5 text-sm font-semibold ${
          following
            ? "border-zinc-300 text-zinc-700 hover:border-red-300 hover:bg-red-50 hover:text-red-600 dark:border-zinc-700 dark:text-zinc-300 dark:hover:border-red-900 dark:hover:bg-red-950/30 dark:hover:text-red-400"
            : "border-orange-500 bg-orange-500 text-white hover:border-orange-600 hover:bg-orange-600"
        }`}
      >
        <span className="inline-grid">
          <span className={`col-start-1 row-start-1 inline-flex items-center justify-center gap-1 ${following ? "invisible" : ""}`}>
            <Icon name="plus" className="size-4" />
            Follow
          </span>
          <span className={`col-start-1 row-start-1 inline-flex items-center justify-center gap-1 ${following ? "group-hover:invisible" : "invisible"}`}>
            <Icon name="check" className="size-4" />
            Following
          </span>
          <span className={`col-start-1 row-start-1 inline-flex items-center justify-center gap-1 invisible ${following ? "group-hover:visible" : ""}`}>
            <Icon name="x" className="size-4" />
            Unfollow
          </span>
        </span>
      </button>
      {following && (
        <button
          onClick={toggleMute}
          title={muted ? "Muted — click to unmute" : "Mute their activity in your feed"}
          aria-label={muted ? "Unmute" : "Mute"}
          aria-pressed={muted}
          className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition-colors ${
            muted
              ? "border-zinc-300 bg-zinc-100 text-zinc-400 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-500"
              : "border-zinc-300 text-zinc-500 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-400 dark:hover:bg-zinc-800"
          }`}
        >
          <Icon name={muted ? "bell-off" : "bell"} className="size-4" />
        </button>
      )}
    </div>
  );
}
