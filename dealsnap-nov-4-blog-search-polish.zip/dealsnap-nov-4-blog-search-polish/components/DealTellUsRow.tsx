import { getCurrentUser } from "@/lib/auth";
import { getDealFixFacts, getReportedDealSlugsByUser, hasReportedEnded } from "@/lib/db";
import { isExpired } from "@/lib/format";
import { can, canFixDeal } from "@/lib/permissions";
import { missingTwoStep } from "@/lib/staff-two-step";
import type { Deal } from "@/lib/types";
import { DealOwnerRow, DealTellUs } from "@/components/ReportControls";

// The "Deal ended?" + "Report other issue" line under a deal's description. "Deal ended?"
// is the quick way for members to flag a deal that's sold out or finished
// (hotukdeals' "expired" vote); enough of them mark it expired for everyone.
// Deliberately quiet — logged-out visitors see nothing here at all, rather
// than a prompt to log in. The deal's own poster gets "It's ended" and "Edit
// deal" instead.
export default async function DealTellUsRow({ deal }: { deal: Deal }) {
  const user = await getCurrentUser();
  if (!user) return null;
  if (user.id === deal.postedByUserId) {
    const ended = hasReportedEnded(deal.slug, user.id);
    return (
      <DealOwnerRow
        dealSlug={deal.slug}
        canSayEnded={deal.status === "live" && !isExpired(deal.expiresAt)}
        initiallyEnded={ended}
      />
    );
  }

  const ended = hasReportedEnded(deal.slug, user.id);
  // Staff only (members skip the lookup): the deal's standing and poster's
  // rank decide Fix details. Demo deals have no stored copy, so no link.
  const facts = can(user.role, "deals.fix") ? getDealFixFacts(deal.slug) : undefined;
  return (
    <DealTellUs
      dealSlug={deal.slug}
      canSayEnded={ended || !isExpired(deal.expiresAt)}
      initiallyEnded={ended}
      initiallyReported={!ended && getReportedDealSlugsByUser(user.id).has(deal.slug)}
      canFix={!!facts && canFixDeal(user, facts) && !missingTwoStep(user)}
    />
  );
}
