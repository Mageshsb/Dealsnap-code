"use client";

import { useCallback, useEffect, useLayoutEffect, useRef, useState, type CSSProperties, type RefObject } from "react";

const GAP = 6; // between the button and the menu
const EDGE = 8; // the menu never comes closer than this to the screen's edge
const MAX_HEIGHT = 480; // 30rem

type Place = { top?: number; bottom?: number; left: number; maxHeight: number };

// The one way a small pop-up menu (a row's "Role ▾", a sort picker, the "…"
// on a profile) is placed, so none of them can be cut off. The menu is drawn
// on top of the page rather than inside the row or card that holds the
// button, lined up with the button (its left or right edge, or centred under it), below it (or above when there's more
// room), and kept inside the screen on every side: it never goes past an
// edge, and a long list scrolls within the space left. It follows the button
// if the page scrolls. Pass the menu's own `menuProps` to the element drawn
// in a portal into `host`; `anchorRef` goes on the button (or the box around
// it). Escape and a tap outside close it. MenuSelect and CategorySwitcher
// have their own copy of this and work the same way.
export function useAnchoredMenu<A extends HTMLElement>(align: "left" | "right" | "center" = "left", onClose?: () => void) {
  const [open, setOpen] = useState(false);
  const [place, setPlace] = useState<Place | null>(null);
  // Where it is drawn: the page, or the pop-up <dialog> the button is in (a
  // menu outside one would sit behind it).
  const [host, setHost] = useState<Element | null>(null);
  const anchorRef = useRef<A>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const onCloseRef = useRef(onClose);
  useLayoutEffect(() => {
    onCloseRef.current = onClose;
  });

  const close = useCallback(() => {
    setOpen(false);
    setPlace(null);
    onCloseRef.current?.();
  }, []);

  const toggle = () => {
    if (open) return close();
    setHost(anchorRef.current?.closest("dialog") ?? document.body);
    setOpen(true);
  };

  const measure = () => {
    const anchor = anchorRef.current;
    if (!anchor) return;
    const r = anchor.getBoundingClientRect();
    const below = window.innerHeight - r.bottom - GAP - EDGE;
    const above = r.top - GAP - EDGE;
    const up = below < 240 && above > below;
    const menuWidth = menuRef.current?.offsetWidth ?? r.width;
    const wanted = align === "right" ? r.right - menuWidth : align === "center" ? r.left + (r.width - menuWidth) / 2 : r.left;
    setPlace({
      ...(up ? { bottom: window.innerHeight - r.top + GAP } : { top: r.bottom + GAP }),
      left: Math.max(EDGE, Math.min(wanted, window.innerWidth - menuWidth - EDGE)),
      maxHeight: Math.min(MAX_HEIGHT, up ? above : below),
    });
  };
  const measureRef = useRef(measure);
  useLayoutEffect(() => {
    measureRef.current = measure;
  });

  // Once the menu is drawn (so its width is known), put it in place.
  useLayoutEffect(() => {
    if (open) measureRef.current();
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const inside = (t: EventTarget | null) =>
      t instanceof Node && (menuRef.current?.contains(t) || anchorRef.current?.contains(t));
    const onDown = (e: PointerEvent) => {
      if (!inside(e.target)) close();
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    const follow = (e: Event) => {
      if (!(e.target instanceof Node && menuRef.current?.contains(e.target))) measureRef.current();
    };
    document.addEventListener("pointerdown", onDown);
    document.addEventListener("keydown", onKey);
    window.addEventListener("scroll", follow, true);
    window.addEventListener("resize", follow);
    // A menu that grows (a form opening inside it) may need to move up or shrink.
    const resized = new ResizeObserver(() => measureRef.current());
    if (menuRef.current) resized.observe(menuRef.current);
    return () => {
      resized.disconnect();
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("keydown", onKey);
      window.removeEventListener("scroll", follow, true);
      window.removeEventListener("resize", follow);
    };
  }, [open, close]);

  // Hidden until measured, so it never flashes in the wrong place.
  const style: CSSProperties = place ? { ...place } : { top: 0, left: 0, visibility: "hidden" };
  const menuProps: {
    ref: RefObject<HTMLDivElement | null>;
    style: CSSProperties;
    className: string;
  } = {
    ref: menuRef,
    style,
    className: "fixed z-[60] max-w-[calc(100vw-1rem)] overflow-y-auto overscroll-contain",
  };

  return { open, toggle, close, anchorRef, host, menuProps };
}
