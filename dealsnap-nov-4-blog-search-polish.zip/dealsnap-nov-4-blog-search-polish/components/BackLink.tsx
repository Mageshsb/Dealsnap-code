"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ReactNode } from "react";
import Icon from "./Icon";

// The one "back" link on the site: a chevron and a short label. It goes back
// in the history when there is one (so the page you came from keeps its place
// and filters), otherwise to `href`. `exact` always goes to `href`, for after
// posting or editing, where going back would mean the form. The -my-2 and
// min-h-9 give a 36px tap target without making the row taller than its text.
export default function BackLink({
  href,
  className = "",
  exact = false,
  children,
}: {
  href: string;
  className?: string;
  exact?: boolean;
  children: ReactNode;
}) {
  const router = useRouter();

  return (
    <Link
      href={href}
      className={`-my-2 inline-flex min-h-9 w-fit items-center gap-0.5 text-sm font-medium text-zinc-500 hover:text-orange-600 dark:text-zinc-400 dark:hover:text-orange-400 ${className}`}
      onClick={(e) => {
        if (!exact && window.history.length > 1) {
          e.preventDefault();
          router.back();
        }
      }}
    >
      <Icon name="chevron-left" className="size-4 shrink-0" />
      {children}
    </Link>
  );
}
