import type { ReactNode } from "react";
import Icon, { type IconName } from "./Icon";
import DealCard from "./DealCard";
import PrintButton from "./PrintButton";
import SiteMark from "./SiteMark";
import { getSiteName } from "@/lib/site-url";
import { AdBox, AdRow, AdStrip, AdTallCard, AdTower } from "./AdCreative";
import type { AdSettings } from "@/lib/ad-serving";
import type { KitData, KitSettings } from "@/lib/media-kit";
import type { Deal } from "@/lib/types";
import { AD_PAGE_KINDS, AD_SCREENS, AD_SLOTS, isRailSlot, repeatUnit, type AdCreative, type AdSlotDef, type AdSlotId } from "@/lib/ads";

// The media kit: everything a business needs to decide to advertise, laid out
// as a document that reads well on a screen and saves as a tidy A4 PDF. Used
// by the private kit links (/media-kit/…) and staff's preview. All of it comes
// from the site's live settings, so it never offers a space that's off or
// quotes old numbers.

const SAMPLE: AdCreative = {
  id: "sample",
  advertiser: "Your brand",
  headline: "Your offer, in your words",
  body: "A line about it, and a picture or your logo",
  ctaLabel: "Shop now",
  internal: true,
};

const nf = (n: number) => n.toLocaleString("en-GB");
const pct = (n: number) => `${(n * 100).toFixed(n < 0.1 ? 1 : 0)}%`;
const month = (d: string) => new Date(`${d}T12:00:00Z`).toLocaleDateString("en-GB", { month: "long", year: "numeric", timeZone: "UTC" });
const day = (d: string) => new Date(`${d}T12:00:00Z`).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });

// Each format, in words: its size, and what the advertiser sends.
const SIZE: Partial<Record<AdSlotId, string>> = {
  sponsored: "A deal card, the same as every other deal",
  list: "As tall as the smallest deal card (about 175 to 190px), the full width of the list",
  cards: "A full card in Cards view, the same as a deal's",
  sidebar: "A 280×288px box on laptops",
  "rail-left": "160×600px columns on screens 1,420px wide or more",
  "rail-right": "160×600px columns on screens 1,420px wide or more",
};

function Section({ title, icon, children }: { title: string; icon: IconName; children: ReactNode }) {
  return (
    <section className="kit-section flex flex-col gap-3 border-t border-zinc-200 pt-6 dark:border-zinc-800">
      <h2 className="flex items-center gap-2 text-lg font-bold">
        <Icon name={icon} className="size-5 text-orange-700 dark:text-orange-400" />
        {title}
      </h2>
      {children}
    </section>
  );
}

export default function MediaKit({
  recipient,
  note,
  rates,
  showStats,
  data,
  ads,
  kit,
  sampleDeal,
  expiresOn,
}: {
  recipient: string;
  note: string;
  rates: string; // already chosen: this business's, or the usual ones; empty for none
  showStats: boolean;
  data: KitData;
  ads: AdSettings;
  kit: KitSettings;
  sampleDeal?: Deal;
  expiresOn?: string;
}) {
  // The spaces that are on, on at least one kind of page that's on.
  // Sponsored deals lead: it's the format deal sites are known for.
  const offered = AD_SLOTS.filter((d) => ads.slots[d.id].enabled && d.pages.some((p) => !ads.offPages.includes(p)) && (d.id !== "sponsored" || sampleDeal)).sort(
    (a, b) => Number(b.id === "sponsored") - Number(a.id === "sponsored"),
  );
  // The two side columns are sold as one format when both are on: one column or both.
  const bothColumns = offered.some((d) => d.id === "rail-left") && offered.some((d) => d.id === "rail-right");
  const shown = bothColumns ? offered.filter((d) => d.id !== "rail-right") : offered;
  const titleOf = (def: AdSlotDef) => (bothColumns && def.id === "rail-left" ? "Side columns" : def.name);
  const whereOf = (def: AdSlotDef) =>
    bothColumns && def.id === "rail-left"
      ? "A tall column on each side of the page on deal lists, deal pages, articles and the Community, staying in view as people scroll. Book the left, the right, or both."
      : def.where;
  const pages = AD_PAGE_KINDS.filter((k) => !ads.offPages.includes(k.value)).map((k) => k.label.toLowerCase());
  const often = (def: AdSlotDef) => {
    const s = ads.slots[def.id];
    if (!def.repeats) return "One per page";
    const of = repeatUnit(def.repeats.of);
    return `After ${of} ${s.first}, then every ${s.every}${s.max ? `, up to ${s.max} a page` : ""}`;
  };
  const size = (def: AdSlotDef) =>
    SIZE[def.id] ?? (ads.slots[def.id].size === "compact" ? "A strip about 96px tall, full width" : "About 175 to 190px tall (as tall as the smallest deal), full width");
  const screens = (def: AdSlotDef) => (def.screenChoice ? AD_SCREENS.find((x) => x.value === ads.slots[def.id].screens)!.label : def.screens);
  const sample = (def: AdSlotDef): ReactNode => {
    if (def.id === "sponsored" && sampleDeal) {
      return <DealCard deal={sampleDeal} sponsoredBy="Your brand" />;
    }
    if (def.id === "cards") return <div className="mx-auto flex h-[22rem] w-[15rem]"><AdTallCard ad={SAMPLE} /></div>;
    if (def.id === "sidebar") return <div className="w-[240px]"><AdBox ad={SAMPLE} /></div>;
    if (isRailSlot(def.id)) return <div className="h-[23.25rem] origin-top-left scale-[0.6]"><AdTower ad={SAMPLE} /></div>;
    return ads.slots[def.id].size === "compact" ? <AdStrip ad={SAMPLE} /> : <AdRow ad={SAMPLE} />;
  };
  const stats: [string, number][] = showStats
    ? ([
        ["Members", data.members],
        ["Deals shared in the last 30 days", data.deals30],
        ["Taps through to stores in the last 30 days", data.taps30],
        ["Ads seen in the last 30 days", data.adViews30],
      ] as [string, number][]).filter(([, n]) => n > 0)
    : [];

  return (
    <article id="media-kit" className="mx-auto flex w-full max-w-3xl flex-col gap-6 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-zinc-200 sm:p-10 dark:bg-zinc-900 dark:ring-zinc-800">
      {/* What prints as the first page. */}
      <header className="kit-cover flex flex-col gap-6">
        <div className="flex items-center justify-between gap-3">
          <span className="flex items-center gap-1.5 text-lg font-bold tracking-tight">
            <SiteMark className="size-6" />
            {getSiteName()}
          </span>
          <span data-print-hide className="flex flex-wrap justify-end gap-2">
            <PrintButton />
          </span>
        </div>
        <div className="flex flex-col gap-2 rounded-2xl bg-zinc-900 p-6 text-white sm:p-8 dark:bg-zinc-800">
          <p className="text-xs font-semibold uppercase tracking-wide text-orange-300">Media kit · {month(data.asOf)}</p>
          <h1 className="text-3xl font-bold text-balance sm:text-4xl">Reach UK shoppers while they&apos;re choosing what to buy</h1>
          <p className="text-zinc-300">Prepared for {recipient}</p>
        </div>
        {note && (
          <div className="flex flex-col gap-1 rounded-xl border-l-4 border-orange-500 bg-orange-50 p-4 dark:bg-orange-950/30">
            <p className="whitespace-pre-line text-zinc-800 dark:text-zinc-200">{note}</p>
            {kit.contactName && <p className="text-sm text-zinc-500">{kit.contactName}, DealSnap</p>}
          </div>
        )}
        <p className="text-zinc-700 dark:text-zinc-300">
          {ads.page.intro ||
            "DealSnap is a UK community where shoppers share, check and vote on the best deals. People come here to spend: they're comparing prices and looking for a reason to choose. Your offer appears in the site's own style, clearly labelled, and without tracking anyone."}
        </p>
      </header>

      {(stats.length > 0 || data.topCategories.length > 0) && showStats && (
        <Section title="The audience" icon="users">
          {stats.length > 0 && (
            <dl className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {stats.map(([k, n]) => (
                <div key={k} className="rounded-xl bg-zinc-50 p-3 dark:bg-zinc-950">
                  <dd className="text-2xl font-bold tabular-nums">{nf(n)}</dd>
                  <dt className="text-xs text-zinc-500">{k}</dt>
                </div>
              ))}
            </dl>
          )}
          {data.topCategories.length > 0 && (
            <div className="flex flex-col gap-1.5">
              <p className="text-sm font-medium">What they buy: share of taps through to stores, last 30 days</p>
              {data.topCategories.map((c) => (
                <div key={c.name} className="flex items-center gap-3 text-sm">
                  <span className="w-44 shrink-0 truncate sm:w-56">{c.name}</span>
                  <span className="h-2.5 flex-1 overflow-hidden rounded-full bg-zinc-100 dark:bg-zinc-800">
                    <span className="block h-full rounded-full bg-orange-500" style={{ width: `${Math.max(2, c.share * 100).toFixed(1)}%` }} />
                  </span>
                  <span className="w-12 shrink-0 text-right tabular-nums text-zinc-500">{pct(c.share)}</span>
                </div>
              ))}
            </div>
          )}
          <p className="text-xs text-zinc-500">Figures as of {day(data.asOf)}, straight from DealSnap. This page always shows the latest.</p>
        </Section>
      )}

      <Section title="Ways to advertise" icon="megaphone">
        <p className="text-sm text-zinc-600 dark:text-zinc-400">
          You send your words and a picture or logo (or pick one of your deals); we build it in DealSnap&apos;s style and send you a
          preview before anything goes live. Every space has a fixed size, so nothing on the page jumps when it appears.
        </p>
        <div className="flex flex-col gap-4">
          {shown.map((def) => (
            <div key={def.id} className="kit-section flex flex-col gap-3 border-t border-zinc-200 pt-4 sm:rounded-xl sm:border sm:p-4 dark:border-zinc-800">
              <div className="flex min-w-0 flex-col gap-2">
                <h3 className="font-semibold">{titleOf(def)}</h3>
                <p className="text-sm text-zinc-600 dark:text-zinc-400">{whereOf(def)}</p>
                <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 text-sm">
                  <dt className="text-zinc-500">Size</dt>
                  <dd>{size(def)}</dd>
                  <dt className="text-zinc-500">How often</dt>
                  <dd>{often(def)}</dd>
                  <dt className="text-zinc-500">Screens</dt>
                  <dd>{screens(def)}</dd>
                  <dt className="text-zinc-500">You send</dt>
                  <dd>{def.id === "sponsored" ? "The link to your deal on DealSnap" : "A headline, a short line, a button label, a link, and a picture or logo"}</dd>
                </dl>
              </div>
              <div aria-hidden className="pointer-events-none min-w-0 max-w-xl select-none overflow-hidden rounded-xl sm:bg-zinc-50 sm:p-3 dark:sm:bg-zinc-950">
                {sample(def)}
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Getting it in front of the right people" icon="target">
        <ul className="grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
          {[
            ["Your own pages", "Your store or brand's page, and every one of your deals"],
            ["Categories and tags", "Like TVs, laptops or toys, and their deals"],
            ["Buying guides", "Every article, or one in particular"],
            ["Everywhere", `Across ${pages.join(", ")}`],
            ["Dates and pace", "Set dates, spread evenly or as fast as possible"],
            ["Sponsorships", "Have a space to yourself, like your store's page for a week"],
          ].map(([t, b]) => (
            <li key={t} className="rounded-lg bg-zinc-50 p-3 dark:bg-zinc-950">
              <span className="font-medium">{t}</span>
              <span className="block text-zinc-600 dark:text-zinc-400">{b}</span>
            </li>
          ))}
        </ul>
        <p className="text-sm text-zinc-600 dark:text-zinc-400">
          Ads are chosen for the page they&apos;re on, never for who&apos;s looking: no cookies, no profiles, nothing for your
          customers to consent to.
        </p>
      </Section>

      <Section title="Results you can see" icon="chart-line">
        <ul className="flex list-disc flex-col gap-1.5 pl-5 text-sm text-zinc-700 dark:text-zinc-300">
          <li>A view counts only when at least half the ad is on screen for a full second (the industry&apos;s “viewable” standard).</li>
          <li>Bots, link previews and our own team are never counted; one person&apos;s repeat views are capped each day.</li>
          <li>Your own live report link: views, clicks and click rate by day and by space, with a spreadsheet to download.</li>
          <li>Visits arrive tagged utm_source=dealsnap, so they show up in your own analytics, sales included.</li>
          {data.clickRate !== undefined && (
            <li>
              Ads on DealSnap have been clicked on <strong>{pct(data.clickRate)}</strong> of views so far.
            </li>
          )}
        </ul>
      </Section>

      {rates && (
        <Section title="Rates" icon="pound">
          <p className="whitespace-pre-line text-zinc-800 dark:text-zinc-200">{rates}</p>
          <p className="text-xs text-zinc-500">Prices exclude VAT where it applies. Ask about packages, longer bookings and repeat campaigns.</p>
        </Section>
      )}

      <Section title="How to book" icon="calendar">
        <ol className="flex flex-col gap-2 text-sm">
          {[
            ["Tell us what you'd like", "What you're promoting, where, when, and how many views or weeks."],
            ["Approve the preview", `We build it and send you a preview. Allow ${kit.leadDays === 0 ? "a day" : `${kit.leadDays} working day${kit.leadDays === 1 ? "" : "s"}`} before it goes live.`],
            ["Watch it live", "You get your report link the day it starts. Change or pause it any time by email."],
            ["Run it again", "Rebook a campaign that worked in one email; we keep everything ready."],
          ].map(([t, b], i) => (
            <li key={t} className="flex gap-3">
              <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-zinc-900 text-xs font-bold text-white dark:bg-zinc-100 dark:text-zinc-900">{i + 1}</span>
              <span>
                <span className="font-medium">{t}.</span> <span className="text-zinc-600 dark:text-zinc-400">{b}</span>
              </span>
            </li>
          ))}
        </ol>
      </Section>

      <Section title="Our standards" icon="shield-check">
        <ul className="flex list-disc flex-col gap-1.5 pl-5 text-sm text-zinc-700 dark:text-zinc-300">
          <li>Every ad is labelled “Ad” with who it&apos;s from, as UK advertising rules (the CAP Code) require.</li>
          <li>Paying for an ad never changes how members&apos; deals are ranked. A sponsored deal is never first in a list.</li>
          <li>
            We don&apos;t take ads for gambling, alcohol, tobacco or vapes, medicines or weight loss, or “less healthy” food and drink
            (banned from paid online ads in the UK since 5 January 2026), or anything misleading.
          </li>
        </ul>
        {kit.terms && <p className="whitespace-pre-line text-sm text-zinc-600 dark:text-zinc-400">{kit.terms}</p>}
      </Section>

      <section className="kit-section flex flex-col items-start gap-2 rounded-2xl bg-orange-50 p-5 dark:bg-orange-950/30">
        <h2 className="text-lg font-bold">Let&apos;s talk</h2>
        <p className="text-sm text-zinc-700 dark:text-zinc-300">
          Reply to the email this came with, or write to {kit.contactName ? `${kit.contactName} at ` : ""}
          <strong className="select-all">{kit.contactEmail}</strong>.
        </p>
        {expiresOn && <p className="text-xs text-zinc-500">This kit was prepared for {recipient} and is available until {day(expiresOn)}.</p>}
      </section>
    </article>
  );
}

// The print rules for a kit page: just the kit, on clean A4 pages.
export const KIT_PRINT_CSS = `
@media print {
  @page { size: A4; margin: 14mm; }
  body > *:not(:has(#media-kit)):not(#media-kit) { display: none !important; }
  body { background: #fff !important; }
  main:has(#media-kit) { padding: 0 !important; max-width: none !important; }
  #media-kit { box-shadow: none !important; padding: 0 !important; max-width: none !important; }
  #media-kit [data-print-hide] { display: none !important; }
  #media-kit .kit-cover { break-after: page; }
  #media-kit .kit-section { break-inside: avoid; }
  #media-kit, #media-kit * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
}`;
