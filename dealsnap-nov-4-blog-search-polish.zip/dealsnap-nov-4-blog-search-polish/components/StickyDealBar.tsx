"use client";

import GetDealButton from "./GetDealButton";
import { useEffect, useState } from "react";
import { WasPrice } from "./DealPrice";

// Once the deal's own "Get deal" button has scrolled up out of sight (into the
// description or comments), a slim bar slides up from the bottom with the
// price (or offer) and the button, so it's always one tap away. Edge to edge on phones;
// from 640px a floating panel as wide as the page.
export default function StickyDealBar({
  slug,
  title,
  price,
  was,
  wasRrp,
  ctaId,
  upcoming = false,
  store,
  code,
  voucher = false,
}: {
  slug: string;
  title: string;
  price: string;
  was?: string;
  wasRrp?: boolean;
  ctaId: string;
  upcoming?: boolean;
  store: string;
  // The code its button copies, and whether it's a voucher ("Get code").
  code?: string;
  voucher?: boolean;
}) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const cta = document.getElementById(ctaId);
    if (!cta) return;
    const observer = new IntersectionObserver(([entry]) => {
      // Only once it's gone off the top, not while it's still further down.
      setShow(!entry.isIntersecting && entry.boundingClientRect.top < 0);
    });
    observer.observe(cta);
    return () => observer.disconnect();
  }, [ctaId]);

  return (
    <>
      {/* Room at the bottom of the page so the bar never covers the footer. */}
      <div aria-hidden className="h-14 sm:h-20" />
      <div
        aria-hidden={!show}
        className={`fixed inset-x-0 bottom-0 z-40 border-t border-zinc-200 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur transition-transform duration-200 ease-out motion-reduce:transition-none dark:border-zinc-800 dark:bg-zinc-900/95 sm:inset-x-4 sm:bottom-4 sm:mx-auto sm:max-w-[62rem] sm:rounded-2xl sm:border sm:pb-0 sm:shadow-lg ${
          show ? "translate-y-0" : "pointer-events-none translate-y-[calc(100%+2rem)]"
        }`}
      >
        <div className="flex items-center gap-3 px-4 py-2 sm:py-2.5">
          <div className="flex min-w-0 flex-1 flex-col">
            <span className="truncate text-xs text-zinc-500 sm:text-sm">{title}</span>
            <span className="flex min-w-0 items-baseline gap-1.5 whitespace-nowrap">
              {/* Orange like the price everywhere else (list, cards, deal
                  page). On a sale, multi-buy or voucher it's the offer, cut
                  short with … if a phone is too narrow for all of it. */}
              <span className="truncate text-base font-bold text-orange-700 dark:text-orange-400">{price}</span>
              <WasPrice tag={{ was, wasRrp }} className="text-xs text-zinc-500 dark:text-zinc-400" />
            </span>
          </div>
          <GetDealButton
            slug={slug}
            store={store}
            code={code}
            voucher={voucher}
            upcoming={upcoming}
            tabIndex={show ? 0 : -1}
            className="shrink-0 rounded-full px-6 py-2.5 text-sm font-semibold"
          />
        </div>
      </div>
    </>
  );
}
