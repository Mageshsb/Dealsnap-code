import Icon, { type IconName } from "./Icon";
import type { UserRole } from "@/lib/db";
import { ROLE_LABELS } from "@/lib/permissions";

// How each rank looks wherever a name appears. Colours avoid orange (Featured)
// and violet/gold (the Hero deal) so a badge is never mistaken for a deal label.
const LOOK = {
  helper: {
    label: ROLE_LABELS.helper,
    icon: "hand-helping",
    text: "text-green-700 dark:text-green-400",
    bg: "bg-green-100 dark:bg-green-950/40",
    tip: "Hand-picked member who keeps deals accurate",
  },
  moderator: {
    label: ROLE_LABELS.moderator,
    icon: "shield",
    text: "text-indigo-700 dark:text-indigo-400",
    bg: "bg-indigo-100 dark:bg-indigo-950/40",
    tip: "Looks after DealSnap: checks deals and comments",
  },
  admin: {
    label: "Founder",
    icon: "shield-check",
    text: "text-zinc-900 dark:text-zinc-100",
    bg: "bg-zinc-200 dark:bg-zinc-700",
    tip: "Runs DealSnap",
  },
} satisfies Record<string, { label: string; icon: IconName; text: string; bg: string; tip: string }>;

export type Tier = keyof typeof LOOK;

// Only ranks we hand out show: a member who has simply earned posting rights
// gets no badge, as one would read as us vouching for them.
export function tierOf(role: UserRole | undefined): Tier | undefined {
  if (role === "admin" || role === "moderator" || role === "helper") return role;
  return undefined;
}

// The rank's colour, icon and label for a name that shows the rank by colour
// (deal cards), with the icon only where the name leaves room for it.
export function tierLook(tier: Tier) {
  const { label, icon, text, tip } = LOOK[tier];
  return { label, icon, text, tip };
}

// pill: profile header. label: beside a name on a deal page or comment.
// icon: just a small mark beside a name where space is tight (deal cards).
export default function RoleBadge({ tier, variant }: { tier: Tier; variant: "pill" | "label" | "icon" }) {
  const look = LOOK[tier];
  if (variant === "icon") {
    return (
      <span role="img" aria-label={look.label} title={`${look.label}: ${look.tip}`} className={`shrink-0 ${look.text}`}>
        <Icon name={look.icon} className="size-3.5" />
      </span>
    );
  }
  if (variant === "label") {
    return (
      <span title={look.tip} className={`inline-flex shrink-0 items-center gap-0.5 text-xs font-semibold ${look.text}`}>
        <Icon name={look.icon} className="size-3" />
        {look.label}
      </span>
    );
  }
  return (
    <span
      title={look.tip}
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${look.bg} ${look.text}`}
    >
      <Icon name={look.icon} className="size-3.5" />
      {look.label}
    </span>
  );
}
