import Link from "next/link";
import { timeAgo } from "@/lib/format";
import { CommentPageItem } from "@/lib/social";
import { dealIcon } from "@/lib/categories";
import Icon from "./Icon";

// One of a member's posts on their profile: a comment (under its deal's name)
// or a post in the Community (under its thread's title and space).
export default function ProfileCommentCard({ item }: { item: CommentPageItem }) {
  const community = item.kind === "community";
  return (
    <div className="flex flex-col gap-1.5 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
      <Link
        href={community ? `/community/t/${item.threadSlug}` : `/deals/${item.deal.slug}#comments`}
        className="flex min-w-0 items-center gap-1.5 text-sm font-medium text-zinc-700 hover:underline dark:text-zinc-300"
      >
        <Icon name={community ? "users" : dealIcon(item.deal)} className="size-4 text-zinc-500 dark:text-zinc-400" />
        <span className="truncate">{community ? item.threadTitle : item.deal.title}</span>
      </Link>
      <p className="line-clamp-6 text-sm text-zinc-600 [overflow-wrap:anywhere] dark:text-zinc-400">{item.text}</p>
      <div className="flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
        <span>{timeAgo(item.createdAt)}</span>
        {community && (
          <>
            <span>·</span>
            <span className="min-w-0 truncate">{item.spaceName}</span>
          </>
        )}
        <span>·</span>
        <span className="flex items-center gap-1">
          <Icon name="thumbs-up" className="size-3.5" />
          {item.likeCount}
        </span>
      </div>
    </div>
  );
}
