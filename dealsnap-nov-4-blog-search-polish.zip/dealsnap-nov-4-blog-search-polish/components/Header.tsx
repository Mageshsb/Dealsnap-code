import Link from "next/link";
import SearchBar from "./SearchBar";
import ViewModeToggle from "./ViewModeToggle";
import MobileMenu from "./MobileMenu";
import BrowseMenu from "./BrowseMenu";
import SiteLogoLink from "./SiteLogoLink";
import { getSiteBrand } from "@/lib/site-brand";
import { isWideLogo, logoSrc } from "@/lib/site-brand-shared";
import { getSiteName } from "@/lib/site-url";
import { getCurrentUser } from "@/lib/auth";
import NotificationBell from "./NotificationBell";
import UserAvatar from "./UserAvatar";
import { BookmarkIcon } from "./icons";
import Icon from "./Icon";

const navText = "shrink-0 text-sm font-medium text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-50";
const navLink = `hidden ${navText} lg:inline`;

export default async function Header() {
  const user = await getCurrentUser();
  const brand = getSiteBrand();
  const logo = brand.logo && {
    src: logoSrc(brand.logo),
    darkSrc: brand.logoDark && logoSrc(brand.logoDark, true),
    w: brand.logo.w,
    h: brand.logo.h,
    wide: isWideLogo(brand.logo),
  };

  return (
    <header className="site-header sticky top-0 z-40 transform-gpu border-b border-zinc-200 bg-white dark:border-zinc-800 dark:bg-black">
      {/* Where a long read shows how far through you are (ReadingProgress):
          along the header's bottom edge, over its grey line. Empty elsewhere. */}
      <div id="reading-progress" aria-hidden className="pointer-events-none absolute inset-x-0 top-full -mt-px h-[3px] print:hidden" />
      <div className="relative mx-auto flex max-w-5xl items-center gap-0 px-2 py-3 max-[350px]:px-1 max-[344px]:px-0.5 max-[329px]:px-0 sm:gap-1.5 sm:px-3 lg:gap-[18px] lg:px-4">
        <SiteLogoLink siteName={getSiteName()} logo={logo || undefined} showName={brand.showName} />

        <SearchBar />

        {/* On laptops every item sits 18px from the next as you see it: the bell
            and bookmark's hover squares reach into the gaps (negative margin),
            so their invisible padding doesn't widen the space around them. */}
        <div className="flex shrink-0 items-center gap-1 max-[344px]:gap-0 sm:gap-1.5 lg:gap-[18px]">
          <ViewModeToggle />

          {/* Plain links, no dropdowns. Everything about you lives in My account. */}
          {/* The three ways to browse (categories, stores, brands) in one small menu. */}
          <BrowseMenu className={`hidden ${navText} lg:inline-flex`} />
          <Link href="/community" className={navLink}>
            Community
          </Link>
          <Link href="/blog" className={navLink}>
            Blog
          </Link>

          {user && <NotificationBell />}

          {/* Saved deals, one tap from any page, after the bell (the same order
              as the phone menu, which has them instead: no room on phones). */}
          {user && (
            <Link
              href="/saved"
              aria-label="Saved deals"
              title="Saved deals"
              className="hidden h-10 w-10 shrink-0 items-center justify-center rounded-lg text-zinc-600 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-800 sm:flex lg:-mx-2 lg:h-9 lg:w-9"
            >
              <BookmarkIcon className="h-5 w-5" />
            </Link>
          )}

          {user ? (
            // Just the avatar: the header is never wider than 1024px, and a name
            // beside it would squeeze the search box. The picture stays round,
            // in the same square-cornered hover box as the bell and saved deals.
            <Link
              href="/account"
              aria-label="My account"
              title="My account"
              className="hidden h-9 w-9 shrink-0 items-center justify-center rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 lg:-ml-2 lg:-mr-1 lg:flex"
            >
              <UserAvatar username={user.username} avatarUrl={user.avatarUrl} size="h-7 w-7" />
            </Link>
          ) : (
            <Link
              href="/login"
              className="hidden shrink-0 text-sm font-medium text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-50 lg:inline"
            >
              Log in
            </Link>
          )}

          <Link
            href="/submit"
            aria-label="Post a deal"
            className="flex min-h-11 min-w-11 shrink-0 flex-col items-center justify-center gap-0.5 rounded-xl bg-orange-500 px-2 py-0.5 text-sm font-semibold text-white hover:bg-orange-600 lg:min-h-0 lg:min-w-0 lg:flex-row lg:rounded-full lg:px-4 lg:py-2"
          >
            {/* Icon over a small label below laptops, like List/Cards beside it. */}
            <Icon name="plus" className="size-4 lg:hidden" />
            <span className="text-[9px] leading-none lg:hidden">Post</span>
            <span className="hidden lg:inline">+ Post a deal</span>
          </Link>

          <MobileMenu username={user?.username} avatarUrl={user?.avatarUrl} />
        </div>
      </div>
    </header>
  );
}
