"use client";

import { useState, useTransition, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { deleteOwnCommentAction, editOwnCommentAction } from "@/lib/actions";
import { EDIT_WINDOW_MINUTES, MAX_COMMENT_LENGTH, editableUntil } from "@/lib/comment-rules";
import { COMMENT_ACTIONS, COMMENT_TEXT } from "./comment-styles";
import MoreMenu, { moreMenuItem } from "./MoreMenu";
import Icon from "./Icon";

// The member's own comment: its name-and-time line, its text, and the line
// under it with the "⋯" menu at the end (where others' comments have Report).
// The menu holds Edit, for the first 15 minutes only, and Delete, which asks
// once more on the line itself. Editing swaps the text for a box, saved in place.
export default function OwnComment({
  commentId,
  createdAt,
  meta,
  text,
  body,
  actions,
}: {
  commentId: string;
  createdAt: string;
  meta: ReactNode;
  text: string;
  // The comment as it shows (links and @names made clickable), drawn on the
  // server; `text` is what the edit box starts with.
  body?: ReactNode;
  actions: ReactNode; // Like and Reply
}) {
  const router = useRouter();
  const [editing, setEditing] = useState(false);
  const [canEdit, setCanEdit] = useState(false);
  const [draft, setDraft] = useState(text);
  const [error, setError] = useState("");
  const [askingDelete, setAskingDelete] = useState(false);
  const [pending, startTransition] = useTransition();

  function save() {
    setError("");
    startTransition(async () => {
      const problem = await editOwnCommentAction(commentId, draft);
      if (problem) return setError(problem);
      setEditing(false);
      router.refresh();
    });
  }

  function remove() {
    setError("");
    startTransition(async () => {
      if (await deleteOwnCommentAction(commentId)) router.refresh();
      else setError("We couldn't delete that. Please try again.");
    });
  }

  return (
    <>
      {meta}
      {editing ? (
        <div className="mt-1 flex flex-col gap-2">
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            rows={3}
            maxLength={MAX_COMMENT_LENGTH}
            autoFocus
            aria-label="Your comment"
            className="w-full rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus:border-orange-500 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950"
          />
          {error && <p className="text-xs text-amber-700 dark:text-amber-400">{error}</p>}
          <div className="flex items-center justify-end gap-2 text-xs">
            <button
              type="button"
              onClick={() => {
                setEditing(false);
                setError("");
              }}
              className="rounded-full px-3 py-1 font-medium text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={save}
              disabled={pending || !draft.trim()}
              className="rounded-full bg-orange-500 px-3 py-1 font-semibold text-white hover:bg-orange-600 disabled:opacity-60"
            >
              {pending ? "Saving…" : "Save"}
            </button>
          </div>
        </div>
      ) : (
        <>
          {body ?? <p className={COMMENT_TEXT}>{text}</p>}
          <div className={COMMENT_ACTIONS}>
            {askingDelete ? (
              <span className="tell-us-in flex items-center gap-3">
                Delete this comment?
                <button type="button" onClick={remove} disabled={pending} className="font-medium text-red-600 hover:underline disabled:opacity-60 dark:text-red-400">
                  {pending ? "Deleting…" : "Yes, delete"}
                </button>
                <button type="button" onClick={() => setAskingDelete(false)} className="hover:underline">
                  Cancel
                </button>
              </span>
            ) : (
              <>
                {actions}
                <span className="ml-auto flex">
                  <MoreMenu label="Your comment's options" onOpen={() => setCanEdit(Date.now() < editableUntil(createdAt))}>
                    {(close) => (
                      <>
                        {canEdit && (
                          <button
                            type="button"
                            role="menuitem"
                            onClick={() => {
                              close();
                              setDraft(text);
                              setError("");
                              setEditing(true);
                            }}
                            className={moreMenuItem}
                          >
                            <Icon name="pencil" className="size-4 text-zinc-500 dark:text-zinc-400" />
                            Edit
                          </button>
                        )}
                        <button
                          type="button"
                          role="menuitem"
                          onClick={() => {
                            close();
                            setAskingDelete(true);
                          }}
                          className={`${moreMenuItem} hover:text-red-600 dark:hover:text-red-400`}
                        >
                          <Icon name="trash" className="size-4 text-zinc-500 dark:text-zinc-400" />
                          Delete
                        </button>
                        {!canEdit && (
                          <p className="border-t border-zinc-100 px-4 pb-1.5 pt-2 text-xs text-zinc-500 dark:text-zinc-400 dark:border-zinc-800">
                            Comments can be edited for {EDIT_WINDOW_MINUTES} minutes after posting.
                          </p>
                        )}
                      </>
                    )}
                  </MoreMenu>
                </span>
              </>
            )}
          </div>
          {error && <p className="text-xs text-amber-700 dark:text-amber-400">{error}</p>}
        </>
      )}
    </>
  );
}
