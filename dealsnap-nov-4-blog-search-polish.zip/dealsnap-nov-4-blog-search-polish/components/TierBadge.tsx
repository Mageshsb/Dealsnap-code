import { romanNumeral, TIER_NAMES } from "@/lib/badges";
import Icon, { type IconName } from "./Icon";

// Tier colours, lowest first: bronze, silver, gold, platinum, then DealSnap
// orange at the top. A tier VI needs one more entry here and in TIER_NAMES.
const TIER_FILL = [
  "bg-gradient-to-br from-amber-600 to-amber-800",
  "bg-gradient-to-br from-zinc-300 to-zinc-500",
  "bg-gradient-to-br from-amber-300 to-yellow-600",
  "bg-gradient-to-br from-sky-200 to-sky-500",
  "bg-gradient-to-br from-orange-400 to-rose-500",
];
const TIER_TEXT = [
  "text-amber-800 dark:text-amber-500",
  "text-zinc-500 dark:text-zinc-400",
  "text-yellow-700 dark:text-yellow-500",
  "text-sky-700 dark:text-sky-400",
  "text-orange-700 dark:text-orange-400",
];
const LOCKED_FILL = "bg-zinc-100 text-zinc-400 dark:bg-zinc-800 dark:text-zinc-500";

export function tierName(tier: number) {
  return TIER_NAMES[tier - 1] ?? TIER_NAMES[TIER_NAMES.length - 1];
}

function fill(tier: number) {
  return tier > 0 ? `${TIER_FILL[Math.min(tier, TIER_FILL.length) - 1]} text-white` : LOCKED_FILL;
}

export function tierText(tier: number) {
  return TIER_TEXT[Math.min(tier, TIER_TEXT.length) - 1] ?? "text-zinc-500";
}

// Every badge uses the same medal: the badge's own icon on a disc coloured by
// tier, with the tier's numeral on a tab underneath (left off at the small
// size, where the numeral is written next to the name instead). Tier 0 is a
// grey, not-yet-earned medal.
export default function TierBadge({ icon, tier, size = "lg" }: { icon: IconName; tier: number; size?: "sm" | "lg" }) {
  if (size === "sm") {
    return (
      <span aria-hidden className={`flex size-6 shrink-0 items-center justify-center rounded-full ${fill(tier)}`}>
        <Icon name={icon} className="size-3.5" />
      </span>
    );
  }
  return (
    <span aria-hidden className="relative flex size-14 shrink-0 items-center justify-center">
      <span
        className={`flex size-14 items-center justify-center rounded-full ring-4 ring-inset ring-white/30 ${fill(tier)} ${
          tier > 0 ? "shadow-sm" : ""
        }`}
      >
        <Icon name={icon} className="size-6" />
      </span>
      {tier > 0 && (
        <span
          className={`absolute -bottom-1.5 left-1/2 min-w-6 -translate-x-1/2 rounded-full border border-zinc-200 bg-white px-1.5 text-center text-[11px] font-bold leading-4 dark:border-zinc-700 dark:bg-zinc-900 ${tierText(tier)}`}
        >
          {romanNumeral(tier)}
        </span>
      )}
    </span>
  );
}

// One step on a badge's ladder of tiers: its numeral on the tier's colour once
// reached, grey until then.
export function TierPip({ tier, reached }: { tier: number; reached: boolean }) {
  return (
    <span
      aria-hidden
      className={`flex size-8 items-center justify-center rounded-full text-xs font-bold ${reached ? fill(tier) : LOCKED_FILL}`}
    >
      {romanNumeral(tier)}
    </span>
  );
}
