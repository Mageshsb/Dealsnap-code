import Icon, { type IconName } from "./Icon";

// A section of a My account page (Settings, Alerts…): one white card with an
// orange icon, a title, a line saying what it's for, and anything on the
// right (a count, a button). Every account page is built from these, so
// they look and read the same.
export default function AccountSection({
  id,
  icon,
  title,
  description,
  aside,
  children,
}: {
  // For a link straight to this section ("#apply-next").
  id?: string;
  icon: IconName;
  title: string;
  description?: React.ReactNode;
  aside?: React.ReactNode;
  children?: React.ReactNode;
}) {
  return (
    <section id={id} className="flex min-w-0 scroll-mt-20 flex-col gap-5 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900 sm:p-6">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 className="flex items-center gap-2 text-lg font-bold">
            <Icon name={icon} className="size-5 shrink-0 text-orange-700 dark:text-orange-400" />
            {title}
          </h2>
          {description && <p className="mt-0.5 text-sm text-zinc-500">{description}</p>}
        </div>
        {aside && <div className="shrink-0">{aside}</div>}
      </div>
      {children}
    </section>
  );
}

// The round icon a row starts with (an alert, a blocked member…). In a list
// of rows with a lot in them, it can make way on phones (`phones={false}`),
// where every bit of width counts.
export function RowIcon({ icon, phones = true }: { icon: IconName; phones?: boolean }) {
  return (
    <span
      className={`size-10 shrink-0 items-center justify-center rounded-xl bg-orange-50 text-orange-700 dark:bg-orange-950/40 dark:text-orange-400 ${
        phones ? "flex" : "hidden sm:flex"
      }`}
    >
      <Icon name={icon} className="size-5" />
    </span>
  );
}
