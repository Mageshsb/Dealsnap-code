// Facts about a page in the format search engines read (schema.org), so
// Google can show things like a deal's price and shop right in its results.
// "<" is escaped so text from a deal can never close the script tag early.
export default function JsonLd({ data }: { data: object }) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, "\\u003c") }}
    />
  );
}
