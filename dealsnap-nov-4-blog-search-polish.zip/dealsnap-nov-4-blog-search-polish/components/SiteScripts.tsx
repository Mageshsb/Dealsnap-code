"use client";

import { useEffect, useSyncExternalStore } from "react";
import { usePathname } from "next/navigation";
import Script from "next/script";
import { GoogleAnalytics, GoogleTagManager } from "@next/third-parties/google";
import { useConsent, type CookieCategory } from "./cookie-consent";

// Loads the analytics + any custom code an admin set up in /admin/settings.
// Uses Next's own Google components (nothing hand-rolled), and only once:
//   - the visitor has said yes on the cookie banner: Google for analytics,
//     the custom code (pixels and the like) for marketing (no answer is a no), and
//   - this isn't an admin page, and
//   - this isn't a local test copy of the site — so your own testing never
//     pollutes your real analytics. (To preview on localhost, run
//     localStorage.setItem("dealsnap:trackLocal","1") in the browser console.)
export default function SiteScripts({
  gaId,
  gtmId,
  headCode,
  footerCode,
}: {
  gaId: string;
  gtmId: string;
  headCode: string;
  footerCode: string;
}) {
  // The same kinds the banner asks about (cookieCategories in site-settings).
  const categories: CookieCategory[] = [...(gaId || gtmId ? ["analytics" as const] : []), ...(headCode || footerCode ? ["marketing" as const] : [])];
  const consent = useConsent(categories);
  const pathname = usePathname();
  // Read in the browser once it's running; the server (which can't tell)
  // treats it as local, so nothing loads until the browser has checked.
  const isLocal = useSyncExternalStore(noSubscribe, isLocalCopy, () => true);

  const analytics = typeof consent === "object" && consent.analytics;
  const marketing = typeof consent === "object" && consent.marketing;

  // A marketing yes given after Google has loaded reaches its tags straight
  // away. (A no given later reloads the page, so it needs nothing here.)
  useEffect(() => {
    if (!analytics || !marketing) return;
    const w = window as unknown as { dataLayer?: unknown[] };
    const dataLayer = (w.dataLayer ??= []);
    // gtag's own shape: Google reads the call's arguments object, not an array.
    function gtag() {
      // eslint-disable-next-line prefer-rest-params
      dataLayer.push(arguments);
    }
    (gtag as (...args: unknown[]) => void)("consent", "update", { ad_storage: "granted", ad_user_data: "granted", ad_personalization: "granted" });
  }, [analytics, marketing]);

  if (isLocal || pathname.startsWith("/admin") || (!analytics && !marketing)) return null;
  // Google's consent mode, set before its tags load: analytics was a yes, and
  // ads cookies follow the marketing answer, so tags inside a Tag Manager
  // container hold back too. Taking a yes back reloads the page without them.
  const ads = marketing ? "granted" : "denied";

  return (
    <>
      {analytics && (
        <Script id="consent-defaults" strategy="afterInteractive">
          {`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag("consent","default",{analytics_storage:"granted",ad_storage:"${ads}",ad_user_data:"${ads}",ad_personalization:"${ads}"});`}
        </Script>
      )}
      {/* Both IDs are validated server-side when saved; re-checked here too. */}
      {analytics && gtmId && /^GTM-[A-Z0-9]{4,10}$/.test(gtmId) && <GoogleTagManager gtmId={gtmId} />}
      {analytics && gaId && /^G-[A-Z0-9]{6,12}$/.test(gaId) && <GoogleAnalytics gaId={gaId} />}
      {marketing && headCode && <CustomCode html={headCode} target="head" />}
      {marketing && footerCode && <CustomCode html={footerCode} target="body" />}
    </>
  );
}

// Neither the address nor the trackLocal switch changes while a page is open.
function noSubscribe() {
  return () => {};
}

function isLocalCopy() {
  const host = window.location.hostname;
  const local = host === "localhost" || host.endsWith(".local") || /^[\d.]+$/.test(host) || host === "[::1]";
  return local && window.localStorage.getItem("dealsnap:trackLocal") !== "1";
}

// Drops admin-supplied HTML (a Meta pixel, a chat widget…) into the page.
// Browsers won't run <script> tags that arrive as plain innerHTML, so each one
// is re-created as a real script element, like WordPress "headers and footers"
// plugins do.
function CustomCode({ html, target }: { html: string; target: "head" | "body" }) {
  useEffect(() => {
    const template = document.createElement("template");
    template.innerHTML = html;
    const added: Node[] = [];

    template.content.childNodes.forEach((node) => {
      let el: Node = node.cloneNode(true);
      if (node instanceof HTMLScriptElement) {
        const script = document.createElement("script");
        for (const attr of Array.from(node.attributes)) script.setAttribute(attr.name, attr.value);
        script.text = node.text;
        el = script;
      }
      document[target].appendChild(el);
      added.push(el);
    });

    return () => added.forEach((n) => n.parentNode?.removeChild(n));
  }, [html, target]);

  return null;
}
