import { SOCIAL_ICON_PATHS } from "@/lib/social-icons";

// A social network's logo in the text colour (lib/social-icons.ts), at the
// size the className gives it. Just a drawing: the link round it is labelled.
export default function SocialIcon({ id, className = "size-4" }: { id: string; className?: string }) {
  const path = SOCIAL_ICON_PATHS[id];
  if (!path) return null;
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden focusable="false" className={className}>
      <path d={path} />
    </svg>
  );
}
