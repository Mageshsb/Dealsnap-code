"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { addKeywordAlertAction, removeKeywordAlertAction } from "@/lib/actions";
import { BellIcon } from "./icons";

// "Get alerts for Black Friday deals": a one-tap keyword alert, the same as
// adding the word on the Alerts page. Logged-out visitors sign in first and
// come back here.
export default function KeywordAlertButton({
  keyword,
  label,
  initialAlertId,
  nextPath,
}: {
  keyword: string;
  label: string;
  initialAlertId: string | null;
  nextPath: string;
}) {
  const [alertId, setAlertId] = useState(initialAlertId);
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const on = !!alertId;

  function toggle() {
    setError(null);
    startTransition(async () => {
      if (alertId) {
        const res = await removeKeywordAlertAction(alertId);
        if (res.ok) setAlertId(null);
        return;
      }
      const res = await addKeywordAlertAction(keyword);
      if (res.ok) setAlertId(res.alert.id);
      else if (res.needsLogin) router.push(`/login?next=${encodeURIComponent(nextPath)}`);
      else setError(res.error);
    });
  }

  return (
    <div className="flex flex-col items-start gap-1">
      <button
        type="button"
        onClick={toggle}
        disabled={pending}
        aria-pressed={on}
        className={`flex min-h-11 items-center gap-2 rounded-full border px-4 text-sm font-semibold transition-colors disabled:opacity-60 ${
          on
            ? "border-orange-500 bg-orange-500 text-white hover:bg-orange-600"
            : "border-zinc-300 bg-white text-zinc-800 hover:border-orange-400 hover:text-orange-600 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
        }`}
      >
        <BellIcon className="h-4 w-4" filled={on} />
        {on ? "You'll get alerts · Turn off" : label}
      </button>
      {error && <p className="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  );
}
