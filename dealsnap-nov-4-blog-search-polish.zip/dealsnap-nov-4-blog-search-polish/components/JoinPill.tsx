import Link from "next/link";
import Icon from "./Icon";

// Logged-out visitors on the home page: a small "Join free" button in the title
// row, the same place and size as "Get alerts" on category, tag and store pages,
// so the home page lines up with them instead of having a banner above it.
export default function JoinPill({ className = "" }: { className?: string }) {
  return (
    <Link
      href="/signup"
      title="Deals spotted and rated by shoppers like you. Join free to post, love deals and get alerts."
      className={`flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border border-orange-300 bg-orange-50 px-3 py-1.5 text-sm font-semibold leading-5 text-orange-700 transition-colors hover:border-orange-400 hover:bg-orange-100 dark:border-orange-900/60 dark:bg-orange-950/30 dark:text-orange-300 dark:hover:bg-orange-950/60 ${className}`}
    >
      <Icon name="user-plus" className="size-4" />
      Join free
    </Link>
  );
}
