"use client";

import { createContext, useContext, useMemo, type ReactNode } from "react";
import { buildTaxonomy, type CategoryGroup, type Taxonomy } from "@/lib/taxonomy-shared";

// The category tree for the parts of the site that run in the browser (the
// post form's pickers, the category menu, photo-less tiles). The server reads
// it from the database (lib/categories.ts) and hands it down once, from the
// layout, in a trimmed form (no ids, nothing admin-only).
const TaxonomyContext = createContext<Taxonomy | null>(null);

export default function TaxonomyProvider({ groups, children }: { groups: CategoryGroup[]; children: ReactNode }) {
  const taxonomy = useMemo(() => buildTaxonomy(groups), [groups]);
  return <TaxonomyContext value={taxonomy}>{children}</TaxonomyContext>;
}

export function useTaxonomy(): Taxonomy {
  const taxonomy = useContext(TaxonomyContext);
  if (!taxonomy) throw new Error("useTaxonomy needs the TaxonomyProvider from the root layout.");
  return taxonomy;
}
