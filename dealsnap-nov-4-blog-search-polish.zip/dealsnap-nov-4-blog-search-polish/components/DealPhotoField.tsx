"use client";

import { useEffect, useRef, useState } from "react";
import Icon from "./Icon";
import { fetchPhotoFromUrlAction } from "@/lib/actions";
import { HINT } from "./DealExtrasFields";

// A deal's photo while posting (or when staff edit one): from the link, or
// the poster's own. A new photo's `src` is a data: address, so it can also be
// kept in a guest's saved draft; when staff edit, it starts as the deal's
// current photo address and is only sent if they change it.
export type DealPhoto = { src: string; fromLink: boolean };

// Phone photos can be 5–10MB. They're shrunk here, on the phone, before
// sending (quicker on mobile data, and less work for the server, which still
// checks and cleans whatever arrives; see lib/deal-images.ts).
const MAX_PICK_BYTES = 25 * 1024 * 1024;
const SEND_SIDE = 1600;

// (Screenshots use it too, at a lower `quality` when one comes out big.)
export async function shrinkPhoto(file: File, quality = 0.85): Promise<string> {
  if (file.size > MAX_PICK_BYTES) throw new Error("That photo is too big. Please use one under 25MB.");
  let bitmap: ImageBitmap;
  try {
    bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
  } catch {
    throw new Error("We couldn't open that photo. Please use a JPG, PNG or WEBP.");
  }
  const scale = Math.min(1, SEND_SIDE / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  const ctx = canvas.getContext("2d")!;
  // White behind see-through pictures, as a JPEG has no see-through.
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  return canvas.toDataURL("image/jpeg", quality);
}

// Puts the photo in the form's hidden file box, so it's sent with the deal.
async function attach(input: HTMLInputElement | null, src: string | undefined) {
  if (!input) return;
  const transfer = new DataTransfer();
  if (src?.startsWith("data:")) {
    const blob = await (await fetch(src)).blob();
    transfer.items.add(new File([blob], blob.type === "image/webp" ? "photo.webp" : "photo.jpg", { type: blob.type }));
  }
  input.files = transfer.files;
}

export default function DealPhotoField({ value, onChange }: { value: DealPhoto | null; onChange: (photo: DealPhoto | null) => void }) {
  const sent = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [dragging, setDragging] = useState(false);
  // "Paste image link": a box that opens under the photo, so the choices stay
  // Add a photo / paste a link rather than another row of buttons.
  const [linkOpen, setLinkOpen] = useState(false);
  const [link, setLink] = useState("");

  // Whatever's showing is what's sent: a new photo from the link, one they
  // picked, or one brought back from a saved draft.
  useEffect(() => {
    void attach(sent.current, value?.src);
  }, [value?.src]);

  async function pick(file: File | undefined) {
    if (!file) return;
    setError("");
    setBusy(true);
    try {
      onChange({ src: await shrinkPhoto(file), fromLink: false });
    } catch (e) {
      setError(e instanceof Error ? e.message : "We couldn't open that photo.");
    } finally {
      setBusy(false);
    }
  }

  async function fromLink() {
    if (!link.trim() || busy) return;
    setError("");
    setBusy(true);
    try {
      const res = await fetchPhotoFromUrlAction(link);
      if ("error" in res) {
        setError(res.error);
      } else {
        onChange({ src: res.photo, fromLink: false });
        setLink("");
        setLinkOpen(false);
      }
    } catch {
      setError("We couldn't get a picture from that link. Please try again, or upload the photo.");
    } finally {
      setBusy(false);
    }
  }

  const picker = (
    <input
      type="file"
      accept="image/jpeg,image/png,image/webp,image/gif,image/avif,image/heic"
      className="sr-only"
      onChange={(e) => {
        void pick(e.target.files?.[0]);
        e.target.value = "";
      }}
    />
  );

  return (
    <fieldset className="flex flex-col gap-1.5">
      <legend className="mb-1.5 text-sm font-medium">Photo</legend>
      <input ref={sent} type="file" name="photo" hidden tabIndex={-1} aria-hidden />
      {/* Tells a staff edit to take the photo off (posting ignores it). */}
      {!value && <input type="hidden" name="photoRemoved" value="1" />}

      {value ? (
        <div data-fill={value.fromLink ? "auto" : undefined} className="flex flex-col gap-2">
          {/* eslint-disable-next-line @next/next/no-img-element -- a data: address on this device, nothing to optimise */}
          <img
            src={value.src}
            alt="Your deal's photo"
            className={`h-44 w-full rounded-lg border object-contain p-2 ${
              value.fromLink
                ? "border-green-300 bg-green-50/60 dark:border-green-700 dark:bg-green-950/30"
                : "border-zinc-200 bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-950"
            }`}
          />
          <div className="flex items-center gap-1">
            <label className="flex cursor-pointer items-center gap-1.5 rounded-full px-3 py-2 text-sm font-medium text-zinc-700 hover:bg-zinc-100 has-focus-visible:ring-2 has-focus-visible:ring-orange-500 dark:text-zinc-200 dark:hover:bg-zinc-800">
              {picker}
              <Icon name="camera" className="size-4" />
              {busy ? "Getting it ready…" : "Change"}
            </label>
            <button
              type="button"
              onClick={() => {
                setError("");
                onChange(null);
              }}
              className="flex items-center gap-1.5 rounded-full px-3 py-2 text-sm font-medium text-zinc-500 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-800"
            >
              <Icon name="x" className="size-4" />
              Remove
            </button>
          </div>
          {value.fromLink && <p className={HINT}>From the link. Change it if it isn&apos;t the right product.</p>}
        </div>
      ) : (
        <>
        <label
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            void pick(e.dataTransfer.files[0]);
          }}
          className={`flex h-28 cursor-pointer flex-col items-center justify-center gap-1.5 rounded-lg border-2 border-dashed text-sm transition-colors has-focus-visible:ring-2 has-focus-visible:ring-orange-500 ${
            dragging
              ? "border-orange-400 bg-orange-50 dark:bg-orange-950/30"
              : "border-zinc-300 bg-zinc-50 hover:border-zinc-400 dark:border-zinc-700 dark:bg-zinc-950"
          }`}
        >
          {picker}
          {busy ? (
            <>
              <Icon name="loader" className="size-5 animate-spin text-zinc-500 dark:text-zinc-400" />
              <span className="text-zinc-500 dark:text-zinc-400">Getting it ready…</span>
            </>
          ) : (
            <>
              <Icon name="camera" className="size-5 text-zinc-500 dark:text-zinc-400" />
              <span className="font-medium text-zinc-700 dark:text-zinc-200">Add a photo</span>
              <span className={HINT}>A photo helps your deal stand out</span>
            </>
          )}
        </label>
        {linkOpen ? (
          <div className="flex items-center gap-2">
            <input
              type="url"
              inputMode="url"
              value={link}
              onChange={(e) => setLink(e.target.value)}
              onKeyDown={(e) => {
                // Enter fetches the picture; it must not post the whole deal.
                if (e.key === "Enter") {
                  e.preventDefault();
                  void fromLink();
                }
              }}
              placeholder="https://… (the image's own address)"
              aria-label="Image link"
              autoFocus
              className="min-w-0 flex-1 rounded-lg border border-zinc-300 bg-white px-3 py-2 text-base outline-none focus:border-orange-500 sm:text-sm dark:border-zinc-700 dark:bg-zinc-900"
            />
            <button
              type="button"
              onClick={() => void fromLink()}
              disabled={busy || !link.trim()}
              className="shrink-0 rounded-full bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-50"
            >
              {busy ? "Getting it…" : "Use"}
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setLinkOpen(true)}
            className="flex items-center gap-1.5 self-start rounded-full px-3 py-1.5 text-sm font-medium text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
          >
            <Icon name="globe" className="size-4" />
            Or paste an image link
          </button>
        )}
        </>
      )}
      {error && <p className="text-xs text-amber-700 dark:text-amber-400">{error}</p>}
    </fieldset>
  );
}
