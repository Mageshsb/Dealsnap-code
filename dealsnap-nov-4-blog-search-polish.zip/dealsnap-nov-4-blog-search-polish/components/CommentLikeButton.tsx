"use client";

import { useState } from "react";
import { likeCommentAction } from "@/lib/actions";
import Icon from "./Icon";

// The thumbs-up under a comment. The count shows only once there is one, so a
// fresh conversation isn't a column of zeros; guests see the count alone.
export default function CommentLikeButton({
  commentId,
  initialLikeCount,
  initiallyLiked,
  loggedIn,
  action = likeCommentAction,
}: {
  commentId: string;
  initialLikeCount: number;
  initiallyLiked: boolean;
  loggedIn: boolean;
  // What a tap does: like a deal comment (the default), or a Community post.
  action?: (id: string) => Promise<{ liked: boolean; likeCount: number } | null>;
}) {
  const [liked, setLiked] = useState(initiallyLiked);
  const [count, setCount] = useState(initialLikeCount);

  if (!loggedIn) {
    if (!count) return null;
    return (
      <span className="flex items-center gap-1 text-zinc-500 dark:text-zinc-400" aria-label={`${count} ${count === 1 ? "like" : "likes"}`}>
        <Icon name="thumbs-up" className="size-3.5" />
        {count}
      </span>
    );
  }

  function toggle() {
    const next = !liked;
    setLiked(next);
    setCount((n) => (next ? n + 1 : n - 1));
    action(commentId).then((result) => {
      if (result) {
        setLiked(result.liked);
        setCount(result.likeCount);
      } else {
        // Refused (a limit, or not allowed): put it back as it was.
        setLiked(!next);
        setCount((n) => (next ? n - 1 : n + 1));
      }
    });
  }

  return (
    <button
      type="button"
      onClick={toggle}
      aria-pressed={liked}
      aria-label={count ? `Like (${count})` : "Like"}
      className={`flex items-center gap-1 transition-colors ${
        liked ? "font-medium text-orange-700 dark:text-orange-400" : "text-zinc-500 hover:text-orange-500"
      }`}
    >
      <Icon name="thumbs-up" filled={liked} className="size-3.5" />
      {count > 0 && count}
    </button>
  );
}
