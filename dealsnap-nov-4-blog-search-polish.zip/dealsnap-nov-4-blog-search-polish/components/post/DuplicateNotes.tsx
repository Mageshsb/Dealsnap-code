"use client";

import Link from "next/link";
import type { DuplicateCheck, DuplicateMatch } from "@/lib/mock-deals";
import { timeAgo } from "@/lib/format";
import { Note } from "./bits";

// Whether what's already on DealSnap is worth stopping for, before step 2:
// the same product still live (unless this price beats it), one waiting for
// approval, or similar deals at the same shop.
export function needsALook(check?: DuplicateCheck): boolean {
  if (!check) return false;
  const same = check.same;
  return (!!same && same.state !== "ended" && !same.cheaperNow) || check.similar.length > 0;
}

function DealLink({ deal }: { deal: DuplicateMatch }) {
  return (
    <Link href={`/deals/${deal.slug}`} target="_blank" className="font-semibold underline">
      {deal.title}
    </Link>
  );
}

// What's already been posted, the hotukdeals way: the same product again is
// fine once the earlier deal has ended or when the new price beats it.
export default function DuplicateNotes({ check }: { check: DuplicateCheck }) {
  const same = check.same;
  return (
    <>
      {same &&
        (same.state === "pending" ? (
          <Note tone="warn" icon="hourglass">
            Someone has just posted this, and it&apos;s waiting for our team to check it, so there&apos;s no need to post it again.
          </Note>
        ) : same.state === "ended" ? (
          <Note tone="good" icon="check">
            This was posted before (<DealLink deal={same} />), but that deal has ended, so it&apos;s fine to post again.
          </Note>
        ) : same.cheaperNow ? (
          <Note tone="good" icon="check">
            This is already up at {same.priceLabel} (<DealLink deal={same} />), but your price is lower, so it&apos;s fine to post as a new deal.
          </Note>
        ) : (
          <Note tone="bad" icon="warning">
            Already on DealSnap: <DealLink deal={same} /> ({same.priceLabel}, posted {timeAgo(same.postedAt)}). If it&apos;s the same
            deal, add a comment there instead.
          </Note>
        ))}
      {check.similar.length > 0 && (
        <Note tone="warn" icon="search">
          {check.similar.length === 1 ? "A similar deal is" : "Similar deals are"} already up at {check.similar[0].store}:
          <ul className="mt-1 flex flex-col gap-0.5">
            {check.similar.map((d) => (
              <li key={d.slug}>
                <DealLink deal={d} /> ({d.priceLabel})
              </li>
            ))}
          </ul>
          If yours is one of these, add a comment there instead.
        </Note>
      )}
    </>
  );
}
