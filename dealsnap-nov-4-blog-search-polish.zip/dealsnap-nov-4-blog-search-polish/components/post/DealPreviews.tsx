"use client";

import { useLayoutEffect, useRef, useState } from "react";
import { WHOLE_CATEGORY_PREFIX, type DealCondition, type PriceTag } from "@/lib/deal-kinds";
import { useTaxonomy } from "../TaxonomyProvider";
import { PriceMain, SmallPrint, WasPrice } from "../DealPrice";
import { BookmarkIcon, CommentIcon, ShareIcon } from "../icons";
import Icon, { type IconName } from "../Icon";
import { VOUCHER_BUTTON } from "../GetDealButton";

export type PreviewProps = {
  photo?: string;
  title: string;
  tag: PriceTag;
  store: string;
  conditions: DealCondition[];
  cashback?: number;
  tagName?: string;
  // A whole-store voucher or sale: a store in the picture spot.
  wholeStore?: boolean;
  // A voucher's button says Get code, in violet, as on the real card.
  voucher?: boolean;
};

// The picture spot: the photo, else the icon of what it is on its category's colour.
function usePicture(tagName?: string, wholeStore?: boolean) {
  const taxonomy = useTaxonomy();
  // A whole category comes as "category:<name>" (lib/deal-kinds.ts).
  const wholeCategory = tagName?.startsWith(WHOLE_CATEGORY_PREFIX) ? taxonomy.getCategoryByName(tagName.slice(WHOLE_CATEGORY_PREFIX.length)) : undefined;
  const found = tagName && !wholeCategory ? taxonomy.getTagByName(tagName) : undefined;
  const theme = taxonomy.categoryTheme(wholeCategory?.name ?? found?.category.name ?? "");
  const icon: IconName = wholeStore ? "store" : (wholeCategory?.icon ?? found?.tag.icon ?? found?.category.icon ?? "tag");
  return { theme, icon };
}

// The deal as it will look in Cards view on a phone, the tightest place it
// shows, built like the real card (components/SwipeCard.tsx) so the poster
// sees what people will: the title gets two lines there, so a long one is cut
// short with … and the poster can see which words make it. Only for looking at.
export function PhonePreview({ title, tag, store, conditions, cashback, photo, tagName, wholeStore, voucher, label = "How it looks" }: PreviewProps & { label?: string }) {
  const { theme, icon } = usePicture(tagName, wholeStore);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const [cut, setCut] = useState(false);
  useLayoutEffect(() => {
    const el = titleRef.current;
    if (el) setCut(el.scrollHeight > el.clientHeight + 1);
  }, [title]);
  const round = "flex items-center justify-center rounded-full border border-zinc-200 text-zinc-500 dark:border-zinc-700 dark:text-zinc-400";

  return (
    <div className="flex flex-col gap-1.5">
      <p className="text-sm font-medium">{label}</p>
      <div
        aria-hidden
        className="flex w-80 max-w-full select-none flex-col overflow-hidden rounded-3xl border border-zinc-200 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900"
      >
        <div className={`relative flex aspect-[16/10] w-full items-center justify-center overflow-hidden ${theme.tile}`}>
          {photo ? (
            // eslint-disable-next-line @next/next/no-img-element -- a data: address on this device
            <img src={photo} alt="" className="h-full w-full object-contain p-3" />
          ) : (
            <Icon name={icon} strokeWidth={1.5} className={`size-20 ${theme.icon}`} />
          )}
          {(cashback || conditions.length > 0) && (
            <div className="absolute bottom-3 left-3 max-w-[calc(100%-1.5rem)] rounded-full bg-white/90 px-2.5 py-1 shadow-sm dark:bg-zinc-900/90 [&_p]:text-zinc-800 dark:[&_p]:text-zinc-100">
              <SmallPrint conditions={conditions} cashback={cashback} className="text-xs" />
            </div>
          )}
        </div>
        <div className="flex flex-col gap-2 p-4">
          <div className="flex items-start justify-between gap-2">
            <h3 ref={titleRef} className="line-clamp-2 min-h-[2lh] min-w-0 flex-1 text-lg font-bold leading-snug">
              {title || <span className="text-zinc-500 dark:text-zinc-400">Your title</span>}
            </h3>
            <span className="shrink-0 whitespace-nowrap rounded-full bg-zinc-100 px-2.5 py-1 text-[11px] font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">
              Just now
            </span>
          </div>
          <div className="flex min-h-8 items-baseline gap-2 overflow-hidden whitespace-nowrap">
            <span className={`font-bold text-orange-700 dark:text-orange-400 ${tag.isOffer ? "text-xl" : "text-2xl"}`}>
              <PriceMain tag={tag} />
            </span>
            <WasPrice tag={tag} className="min-w-0 truncate text-base text-zinc-500 dark:text-zinc-400" />
            {tag.off && <span className="text-lg font-bold text-green-700 dark:text-green-400">{tag.off}% off</span>}
          </div>
          <p className="truncate text-sm text-zinc-500 dark:text-zinc-400">
            at <span className="font-semibold text-zinc-700 dark:text-zinc-200">{store || "Store"}</span>
          </p>
          <div className="flex items-center gap-3">
            <span className="flex flex-1 items-center gap-1 text-xs text-zinc-500 dark:text-zinc-400">
              <CommentIcon className="h-[18px] w-[18px]" />0
            </span>
            <span className={`flex h-10 shrink-0 items-center rounded-full px-5 text-sm font-semibold ${voucher ? VOUCHER_BUTTON : "bg-orange-500 text-white"}`}>
              {voucher ? "Get code*" : "Get deal*"}
            </span>
          </div>
          <div className="flex items-center justify-between border-t border-zinc-100 pt-3 dark:border-zinc-800">
            <span className={`${round} size-10`}>
              <ShareIcon className="h-5 w-5" />
            </span>
            <span className="flex items-center gap-2">
              <span className={`${round} size-10`}>
                <Icon name="heart-crack" className="size-5" />
              </span>
              <span className="min-w-8 text-center text-lg font-bold text-zinc-800 dark:text-zinc-100">0</span>
              <span className={`${round} size-10`}>
                <Icon name="heart" className="size-5" />
              </span>
            </span>
            <span className={`${round} size-10`}>
              <BookmarkIcon className="h-5 w-5" />
            </span>
          </div>
        </div>
      </div>
      {cut && (
        <p className="text-xs text-zinc-500 dark:text-zinc-400">
          Just so you know, only the first two lines of the title show here, so it&apos;s worth having the key details near the start.
        </p>
      )}
    </div>
  );
}

// A small live preview for the top of "The details" on phones: the deal as a
// line in a list, updating as the poster types, so they can see what they're
// making without scrolling to the end. (Computers get the full card beside
// the form instead.)
export function CompactPreview({ title, tag, store, conditions, cashback, photo, tagName, wholeStore }: PreviewProps) {
  const { theme, icon } = usePicture(tagName, wholeStore);
  return (
    <div aria-hidden className="flex select-none items-center gap-3 rounded-xl border border-zinc-200 bg-zinc-50 p-2.5 dark:border-zinc-800 dark:bg-zinc-950">
      <div className={`flex size-16 shrink-0 items-center justify-center overflow-hidden rounded-lg ${theme.tile}`}>
        {photo ? (
          // eslint-disable-next-line @next/next/no-img-element -- a data: address on this device
          <img src={photo} alt="" className="h-full w-full object-contain p-1" />
        ) : (
          <Icon name={icon} strokeWidth={1.5} className={`size-8 ${theme.icon}`} />
        )}
      </div>
      <div className="flex min-w-0 flex-1 flex-col gap-0.5">
        <p className="line-clamp-2 text-sm font-semibold leading-snug">{title || <span className="font-normal text-zinc-500 dark:text-zinc-400">Your title</span>}</p>
        <p className="flex min-w-0 items-baseline gap-1.5 whitespace-nowrap">
          <span className="font-bold text-orange-700 dark:text-orange-400">
            <PriceMain tag={tag} />
          </span>
          <WasPrice tag={tag} className="min-w-0 truncate text-xs text-zinc-500 dark:text-zinc-400" />
          {tag.off && <span className="shrink-0 text-xs font-bold text-green-700 dark:text-green-400">{tag.off}% off</span>}
        </p>
        <p className="truncate text-xs text-zinc-500 dark:text-zinc-400">
          at <span className="font-semibold text-zinc-700 dark:text-zinc-200">{store || "Store"}</span>
        </p>
        {(cashback || conditions.length > 0) && <SmallPrint conditions={conditions} cashback={cashback} className="text-xs" />}
      </div>
    </div>
  );
}
