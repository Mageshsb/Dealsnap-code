"use client";

import { createContext, useContext, type ReactNode } from "react";
import type { DealKind } from "@/lib/deal-kinds";
import Icon, { type IconName } from "../Icon";
import { CHOICE_TILE, HINT } from "../DealExtrasFields";

// The small shared parts of the post form (components/SubmitDealForm.tsx).

// The post form, a step at a time: what can't be skipped comes first, and
// the last step is all optional, so it's quick to post a simple deal.
export const STEPS = [
  { title: "Where's the deal?", hint: "Paste the link and we'll fill in what we can." },
  { title: "The details", hint: "Everything a deal needs to go up." },
  { title: "Anything else?", hint: "All optional. Tap a line to add or change it, then post." },
];

// "auto": filled from the link. "check": a best guess the poster should confirm.
export type FillState = "auto" | "check";

// What each type of deal asks for in the title and description: a product's
// name for a price drop, otherwise what the offer is on (the offer itself
// shows in big text under the title, so it needn't be repeated).
export const KIND_COPY: Record<DealKind, { titleLabel: string; title: string; description: string }> = {
  price: { titleLabel: "Deal title", title: "e.g. Sony WH-1000XM5 Headphones", description: "Lowest price in 6 months, ends Friday..." },
  sale: { titleLabel: "What's on sale?", title: "e.g. Toy clearance, hundreds of lines", description: "Best picks, e.g. Shark vacuum £127.99. Ends Sunday..." },
  multibuy: { titleLabel: "What's it on?", title: "e.g. Pringles, all flavours", description: "Mix and match? Any size or flavour rules..." },
  voucher: { titleLabel: "What's it for?", title: "e.g. Everything online, excluding sale items", description: "What it works on, who can use it, any exclusions..." },
  cashback: { titleLabel: "What's it on?", title: "e.g. Galaxy S25 phones, claim online", description: "Where to buy, how to claim it and by when..." },
  freebie: { titleLabel: "What's free?", title: "e.g. Costa hot drink when you join the app", description: "How to claim it, and any catch (sign-up, postage)..." },
};

// The box the form is asking the poster to fix, and what to say: shown in
// red under that box (rather than the browser's own pop-up bubble).
export type Problem = { id: string; message: string } | null;
export const ProblemContext = createContext<Problem>(null);

// The red line under a box that needs fixing, when it's this one.
export function ProblemText({ id }: { id?: string }) {
  const problem = useContext(ProblemContext);
  if (!id || problem?.id !== id) return null;
  return (
    <p id={`${id}-problem`} className="flex items-start gap-1.5 text-sm font-medium text-red-600 dark:text-red-400">
      <Icon name="warning" className="mt-0.5 size-4 shrink-0" />
      {problem.message}
    </p>
  );
}

// One box with its label and an optional hint under it, the same everywhere
// on the form. Labels stay one short line, so boxes side by side line up.
// `fill` tints the box when it came from the link (see globals.css), and a
// box that needs fixing turns red with the reason under it.
export function Field({
  label,
  htmlFor,
  hint,
  fill,
  children,
}: {
  label: string;
  htmlFor?: string;
  hint?: ReactNode;
  fill?: FillState;
  children: ReactNode;
}) {
  const problem = useContext(ProblemContext);
  const wrong = !!htmlFor && problem?.id === htmlFor;
  return (
    <div data-fill={wrong ? undefined : fill} data-problem={wrong || undefined} className="flex min-w-0 flex-col gap-1.5">
      <label htmlFor={htmlFor} className="text-sm font-medium">
        {label}
      </label>
      {children}
      <ProblemText id={htmlFor} />
      {hint && !wrong && <p className={HINT}>{hint}</p>}
    </div>
  );
}

const NOTE_TONES = {
  good: "bg-green-50 text-green-800 dark:bg-green-950/40 dark:text-green-300",
  warn: "bg-amber-50 text-amber-800 dark:bg-amber-950/30 dark:text-amber-300",
  bad: "bg-red-50 text-red-800 dark:bg-red-950/30 dark:text-red-300",
} as const;

// A message from reading the link: what was filled in, or what went wrong.
export function Note({ tone, icon, children }: { tone: keyof typeof NOTE_TONES; icon: IconName; children: ReactNode }) {
  return (
    <div className={`flex items-start gap-2 rounded-lg px-3 py-2 text-sm ${NOTE_TONES[tone]}`}>
      <Icon name={icon} className="mt-0.5 size-4 shrink-0" />
      <div className="min-w-0">{children}</div>
    </div>
  );
}

// "Up to", before a sale's % off or the cashback amount, so the row reads
// like the deal will: "Up to 70%".
export function UpToTile({ name, checked, onChange }: { name: string; checked: boolean; onChange: (on: boolean) => void }) {
  return (
    <label className={`${CHOICE_TILE} gap-1.5 whitespace-nowrap`}>
      <input type="checkbox" name={name} value="1" checked={checked} onChange={(e) => onChange(e.target.checked)} className="sr-only" />
      {checked && <Icon name="check" className="size-4" />}
      Up to
    </label>
  );
}

// What to say when a box needs fixing, by its id (or name). Anything not
// listed gets the browser's own words.
const PROBLEMS: Record<string, string> = {
  url: "Paste the link to the deal",
  title: "Add a title",
  price: "Add the price",
  originalPrice: "The was price needs to be a number",
  salePercent: "Add how much off, as a whole number like 70",
  multibuy: "Choose the offer",
  multibuyPrice: "Add the price",
  multibuyOther: "Type the offer",
  voucherAmount: "Add how much it takes off",
  voucherCode: "Add the code. No code to enter? Then it's a Sale",
  saleAmount: "Add how much off, in pounds",
  cashbackAmount: "Add how much cashback",
  store: "Add the store",
  storeSite: "Add the store's website, like bmstores.co.uk",
  tag: "Choose what it is",
  description: "Say why it's a good deal",
  deliveryCost: "Add what delivery costs",
  expiresAt: "The end date can't be in the past",
  startsAt: "The start can't be in the past",
};

export function problemFor(el: HTMLInputElement | HTMLTextAreaElement): Problem {
  const id = el.id || el.name;
  if (el.validity.typeMismatch && el.type === "url") return { id, message: "That doesn't look like a link. It should start with https://" };
  if (el.validity.rangeUnderflow && el.type === "number") return { id, message: "That needs to be more than 0" };
  return { id, message: PROBLEMS[id] ?? el.validationMessage };
}
