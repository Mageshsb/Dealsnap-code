"use client";

import { useId, type ReactNode } from "react";
import Icon, { type IconName } from "../Icon";

// One line of "Anything else?": what it is and its answer so far ("Ends ·
// Sun 9 Nov", "Discount code · Add"). Tapping it opens just that part of the
// form underneath. A closed line's boxes stay in the form (only out of sight),
// so what's in them is still posted and kept in the draft.
// `filled`: the answer came from the link, so it's green, like the boxes it fills.
export default function ExtraRow({
  name,
  label,
  icon,
  value,
  filled,
  open,
  onToggle,
  children,
}: {
  name: string;
  label: string;
  icon: IconName;
  value?: string;
  filled?: boolean;
  open: boolean;
  onToggle: (name: string) => void;
  children: ReactNode;
}) {
  const panel = useId();
  return (
    <div data-row={name} className="border-b border-zinc-100 last:border-b-0 dark:border-zinc-800">
      <button
        type="button"
        aria-expanded={open}
        aria-controls={panel}
        onClick={() => onToggle(name)}
        className="flex min-h-12 w-full items-center gap-3 py-2 text-left"
      >
        <Icon name={icon} className="size-[18px] shrink-0 text-zinc-500 dark:text-zinc-400" />
        <span className="shrink-0 text-sm font-medium">{label}</span>
        <span
          className={`min-w-0 flex-1 truncate text-right text-sm ${
            value
              ? filled
                ? "font-medium text-green-700 dark:text-green-400"
                : "font-medium text-zinc-700 dark:text-zinc-200"
              : "text-orange-700 dark:text-orange-400"
          }`}
        >
          {value || "Add"}
        </span>
        <Icon name="chevron-down" className={`size-4 shrink-0 text-zinc-400 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      <div id={panel} hidden={!open} className="pb-4 pt-1">
        {children}
      </div>
    </div>
  );
}
