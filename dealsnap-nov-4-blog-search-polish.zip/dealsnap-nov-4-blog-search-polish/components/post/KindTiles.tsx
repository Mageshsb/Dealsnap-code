"use client";

import { DEAL_KINDS, type DealKind } from "@/lib/deal-kinds";
import Icon from "../Icon";

// "What kind of deal?" as six tiles, most common first (lib/deal-kinds.ts),
// each with a tiny example, so it's clear at a glance. Reading the link picks
// one for the poster; they only tap if it's wrong. Three to a row, so all
// six fit on a 360px phone without scrolling sideways.
export default function KindTiles({ value, onChange, guessed }: { value: DealKind; onChange: (kind: DealKind) => void; guessed?: boolean }) {
  return (
    <fieldset className="flex min-w-0 flex-col gap-1.5">
      <legend className="mb-1.5 text-sm font-medium">What kind of deal?</legend>
      <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
        {DEAL_KINDS.map((k) => (
          <label
            key={k.value}
            className="flex min-h-[4.25rem] cursor-pointer flex-col items-center justify-center gap-0.5 rounded-xl border border-zinc-200 bg-white px-1 py-2 text-center transition-colors hover:border-orange-300 hover:bg-orange-50 has-checked:border-2 has-checked:border-orange-500 has-checked:bg-orange-50 has-focus-visible:ring-2 has-focus-visible:ring-orange-500 has-focus-visible:ring-offset-2 dark:border-zinc-700 dark:bg-zinc-900 dark:hover:border-orange-800 dark:hover:bg-orange-950/30 dark:has-checked:border-orange-500 dark:has-checked:bg-orange-950/40 dark:ring-offset-zinc-900"
          >
            <input
              type="radio"
              name="kind"
              value={k.value}
              checked={value === k.value}
              onChange={() => onChange(k.value)}
              className="sr-only"
            />
            <Icon name={k.icon} className={`size-5 ${value === k.value ? "text-orange-600 dark:text-orange-400" : "text-zinc-500 dark:text-zinc-400"}`} />
            <span className={`text-sm font-semibold leading-tight ${value === k.value ? "text-orange-800 dark:text-orange-300" : ""}`}>{k.short}</span>
            <span className="text-[11px] leading-tight text-zinc-500 dark:text-zinc-400">{k.example}</span>
          </label>
        ))}
      </div>
      {guessed && (
        <p className="flex items-center gap-1.5 text-xs text-green-700 dark:text-green-400">
          <Icon name="check" className="size-3.5 shrink-0" />
          Picked from the link. Tap another if it&apos;s not right.
        </p>
      )}
    </fieldset>
  );
}
