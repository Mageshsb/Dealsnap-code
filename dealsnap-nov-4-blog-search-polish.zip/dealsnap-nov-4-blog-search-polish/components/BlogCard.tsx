import Image from "next/image";
import Link from "next/link";
import { BlogCardPost as BlogPost } from "@/lib/types";
import { formatDate } from "@/lib/format";
import { blogKind } from "@/lib/blog";
import Icon from "./Icon";

// `eager`: a picture at the top of the page, fetched straight away (as the
// first deal cards are) rather than when it scrolls into view.
function Cover({ post, sizes, eager }: { post: BlogPost; sizes: string; eager?: boolean }) {
  return (
    <Image
      src={post.cover}
      alt=""
      fill
      className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
      sizes={sizes}
      loading={eager ? "eager" : "lazy"}
      fetchPriority={eager ? "high" : undefined}
      unoptimized={post.cover.startsWith("/blog-cover/")}
    />
  );
}

function Kind({ post }: { post: BlogPost }) {
  const kind = blogKind(post.kind);
  return (
    <span className="flex items-center gap-1 text-xs font-semibold text-orange-700 dark:text-orange-400">
      <Icon name={kind.icon} className="size-3.5" />
      {kind.single}
    </span>
  );
}

function Meta({ post, author = true }: { post: BlogPost; author?: boolean }) {
  return (
    <p className="flex flex-wrap items-center gap-x-1.5 text-xs text-zinc-500">
      {author && (
        <>
          <span>{post.author}</span>
          <span aria-hidden>·</span>
        </>
      )}
      <time dateTime={post.publishedAt}>{formatDate(post.publishedAt)}</time>
      <span aria-hidden>·</span>
      <span>{post.readMinutes} min read</span>
    </p>
  );
}

// The blog's cards. "featured" is the big one at the top of the blog. The
// normal card is a small row (picture on the left) on phones, so more posts fit
// on the screen, and a picture-on-top card in the grid from tablet size up.
export default function BlogCard({ post, featured = false, eager = false }: { post: BlogPost; featured?: boolean; eager?: boolean }) {
  if (featured) {
    return (
      <Link
        href={`/blog/${post.slug}`}
        className="group grid grid-cols-1 overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-sm transition-shadow hover:shadow-md dark:border-zinc-800 dark:bg-zinc-900 md:grid-cols-[1.15fr_1fr]"
      >
        <div className="relative aspect-[16/9] w-full overflow-hidden md:aspect-auto md:min-h-[17rem]">
          <Cover post={post} sizes="(min-width: 768px) 560px, 100vw" eager />
        </div>
        <div className="flex flex-col gap-2.5 p-5 sm:p-6">
          <Kind post={post} />
          <h2 className="text-xl font-bold leading-snug group-hover:text-orange-600 sm:text-2xl dark:group-hover:text-orange-400">
            {post.title}
          </h2>
          <p className="line-clamp-3 text-sm leading-relaxed text-zinc-600 sm:text-base dark:text-zinc-400">{post.excerpt}</p>
          <div className="mt-auto flex items-center justify-between gap-3 pt-2">
            <Meta post={post} />
            <span className="shrink-0 text-sm font-semibold text-orange-700 dark:text-orange-400">Read →</span>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link
      href={`/blog/${post.slug}`}
      className="group flex gap-3 overflow-hidden rounded-xl border border-zinc-200 bg-white p-2.5 shadow-sm transition-shadow hover:shadow-md sm:flex-col sm:gap-0 sm:p-0 dark:border-zinc-800 dark:bg-zinc-900"
    >
      <div className="relative aspect-[4/3] w-28 shrink-0 overflow-hidden rounded-lg sm:aspect-[16/9] sm:w-full sm:rounded-none">
        <Cover post={post} sizes="(min-width: 640px) 360px, 112px" eager={eager} />
      </div>
      <div className="flex min-w-0 flex-1 flex-col gap-1 sm:gap-1.5 sm:p-4">
        <Kind post={post} />
        <h2 className="line-clamp-3 font-semibold leading-snug group-hover:text-orange-600 sm:line-clamp-2 dark:group-hover:text-orange-400">
          {post.title}
        </h2>
        <p className="hidden text-sm text-zinc-500 sm:line-clamp-2">{post.excerpt}</p>
        <div className="mt-auto pt-0.5 sm:pt-1">
          <Meta post={post} author={false} />
        </div>
      </div>
    </Link>
  );
}
