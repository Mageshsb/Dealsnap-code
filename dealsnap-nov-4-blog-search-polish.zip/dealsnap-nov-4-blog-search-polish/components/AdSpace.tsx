"use client";

import { useCallback, useEffect, useRef, useState, type MouseEvent } from "react";
import { adClickUrl, adSlot, type AdSlotId, type SlotFill, type SponsoredDeal } from "@/lib/ads";
import { AD_HEIGHT, AD_VIEWS, type AdLayout } from "./AdCreative";
import { AdTag } from "./AdTag";
import DealCard from "./DealCard";
import SwipeCard from "./SwipeCard";
import NetworkAd from "./NetworkAd";

// The ad itself, in one ad space: a campaign's ad (counted once it's properly
// seen), the ad network's, or (staff previewing) the space's outline. Loaded
// by AdUnit only on pages that have an ad, so a page without one never
// downloads any of this.
const LAYOUT: Record<AdSlotId, AdLayout> = {
  list: "row",
  cards: "card",
  sponsored: "row",
  sidebar: "box",
  "rail-left": "tower",
  "rail-right": "tower",
  deal: "row",
  "deal-end": "row",
  blog: "row",
  "blog-end": "row",
  "community-list": "row",
  "community-thread": "row",
  "community-end": "row",
};

// An ad network's space is taller than a campaign's row (300×250 plus its label).
const NETWORK_HEIGHT: Record<AdSlotId, string> = {
  list: "h-[17.5rem]",
  cards: "h-full",
  sponsored: AD_HEIGHT.row,
  sidebar: AD_HEIGHT.box,
  "rail-left": AD_HEIGHT.tower,
  "rail-right": AD_HEIGHT.tower,
  deal: "h-[18.5rem]",
  "deal-end": "h-[18.5rem]",
  blog: "h-[18.5rem]",
  "blog-end": "h-[18.5rem]",
  "community-list": "h-[17.5rem]",
  "community-thread": "h-[18.5rem]",
  "community-end": "h-[18.5rem]",
};

// ---------------------------------------------------------------------------
// Counting views: an ad counts once it's at least half on screen for a whole
// second (the industry's "viewable"), once per ad on the page. The ids are
// sent in small batches every few seconds and as the page is left. Nothing
// is stored in the browser, so no consent is needed.
// ---------------------------------------------------------------------------
const SEEN_URL = "/api/creative/seen";
const queue: [string, AdSlotId][] = [];
const taps: [string, AdSlotId][] = [];
let timer: ReturnType<typeof setTimeout> | undefined;
let listening = false;

function send() {
  clearTimeout(timer);
  timer = undefined;
  while (queue.length || taps.length) {
    const body = JSON.stringify({ v: queue.splice(0, 50), c: taps.splice(0, 5) });
    if (!navigator.sendBeacon?.(SEEN_URL, body)) {
      fetch(SEEN_URL, { method: "POST", body, keepalive: true }).catch(() => {});
    }
  }
}

// A tap on a sponsored deal is sent straight away (it usually leaves the page).
function tapped(id: string, slot: AdSlotId) {
  taps.push([id, slot]);
  send();
}

function counted(id: string, slot: AdSlotId) {
  queue.push([id, slot]);
  timer ??= setTimeout(send, 4000);
  if (!listening) {
    listening = true;
    document.addEventListener("visibilitychange", () => document.visibilityState === "hidden" && send());
    window.addEventListener("pagehide", send);
  }
}

function useViewable(id: string | undefined, slot: AdSlotId) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!id || !el) return;
    let wait: ReturnType<typeof setTimeout> | undefined;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.intersectionRatio >= 0.5 && document.visibilityState === "visible") {
          wait ??= setTimeout(() => {
            counted(id, slot);
            observer.disconnect();
          }, 1000);
        } else if (wait) {
          clearTimeout(wait);
          wait = undefined;
        }
      },
      { threshold: [0, 0.5] },
    );
    observer.observe(el);
    return () => {
      clearTimeout(wait);
      observer.disconnect();
    };
  }, [id, slot]);
  return ref;
}

// A sponsored deal: the real deal's card (hearts, saving and Get deal all work
// as usual) with "Ad · Sponsored by…" in a strip along its top. A tap on it
// that isn't one of its buttons (the heart, save, share) counts as a click.
function Sponsored({ s, slot, cards, className }: { s: SponsoredDeal; slot: AdSlotId; cards: boolean; className: string }) {
  const ref = useViewable(s.id, slot);
  const onClickCapture = (e: MouseEvent) => {
    if (!(e.target as Element).closest("button")) tapped(s.id, slot);
  };
  if (cards) {
    return (
      <div ref={ref} data-ad-slot={slot} onClickCapture={onClickCapture} className={`relative flex h-full w-full ${className}`}>
        <SwipeCard deal={s.deal} />
        <span className="pointer-events-none absolute left-4 top-4 z-20 max-w-[calc(100%-2rem)] rounded-full bg-white/95 px-2 py-1 shadow-sm dark:bg-zinc-900/95">
          <AdTag advertiser={`Sponsored by ${s.advertiser}`} />
        </span>
      </div>
    );
  }
  return (
    <div ref={ref} data-ad-slot={slot} onClickCapture={onClickCapture} className={className}>
      <DealCard deal={s.deal} sponsoredBy={s.advertiser} />
    </div>
  );
}

export default function AdSpace({
  slot,
  fill,
  n,
  personalised,
  cards = false,
  className,
}: {
  slot: AdSlotId;
  fill: SlotFill;
  n: number;
  personalised: boolean;
  cards?: boolean; // in Cards view (a sponsored deal is drawn as a deal's card there)
  className: string;
}) {
  if (fill.deals?.length) return <Sponsored s={fill.deals[n % fill.deals.length]} slot={slot} cards={cards} className={className} />;
  return <AdBody slot={slot} fill={fill} n={n} personalised={personalised} className={className} />;
}

function AdBody({ slot, fill, n, personalised, className }: { slot: AdSlotId; fill: SlotFill; n: number; personalised: boolean; className: string }) {
  const [folded, setFolded] = useState(false);
  const fold = useCallback(() => setFolded(true), []);
  // A house ad covers the space only if the ad network comes back with nothing.
  const own = fill.creatives.length ? fill.creatives : folded ? fill.fallback ?? [] : [];
  const ad = own.length ? own[n % own.length] : undefined;
  const ref = useViewable(ad?.id, slot);
  const compact = fill.size === "compact";
  const layout: AdLayout = compact && LAYOUT[slot] === "row" ? "strip" : LAYOUT[slot];

  if (ad) {
    const View = AD_VIEWS[layout];
    return (
      <div ref={ref} data-ad-slot={slot} className={`${layout === "card" ? "flex h-full w-full" : ""} ${className}`}>
        <View ad={ad} href={adClickUrl(ad.id, slot)} />
      </div>
    );
  }
  if (fill.network) {
    if (folded) return null;
    return (
      <div data-ad-slot={slot} className={`${layout === "tower" ? "w-40" : "w-full"} ${className}`}>
        <NetworkAd
          unit={fill.network.unit}
          sizes={fill.network.sizes}
          compact={fill.network.compact}
          personalised={personalised}
          className={`${compact ? "h-[7.5rem]" : NETWORK_HEIGHT[slot]} ${layout === "card" ? "rounded-3xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900" : ""}`}
          onNothing={fold}
        />
      </div>
    );
  }
  // Staff previewing the ad spaces: an outline of the space, named.
  return (
    <div
      data-ad-slot={slot}
      className={`flex flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed border-sky-400 bg-sky-50/60 p-3 text-center text-xs text-sky-800 dark:border-sky-700 dark:bg-sky-950/30 dark:text-sky-300 ${
        layout === "tower" ? "w-40" : "w-full"
      } ${layout === "card" ? "h-full rounded-3xl" : AD_HEIGHT[layout]} ${className}`}
    >
      <span className="font-semibold">Ad space: {adSlot(slot).name}</span>
      <span>Only staff see this outline</span>
    </div>
  );
}
