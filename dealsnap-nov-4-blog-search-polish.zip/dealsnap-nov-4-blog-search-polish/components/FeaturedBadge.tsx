import Icon from "./Icon";

export default function FeaturedBadge({ className = "" }: { className?: string }) {
  return (
    <span
      className={`pointer-events-none absolute flex items-center gap-1 overflow-hidden whitespace-nowrap rounded-full bg-gradient-to-r from-amber-400 to-orange-500 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-white shadow-md ${className}`}
    >
      <Icon name="star" filled className="size-3" />
      Featured
    </span>
  );
}
