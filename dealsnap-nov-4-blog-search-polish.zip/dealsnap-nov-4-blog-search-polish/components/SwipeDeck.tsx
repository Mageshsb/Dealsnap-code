"use client";

import { Fragment, useCallback, useEffect, useLayoutEffect, useRef, useState, type ReactNode, type RefObject } from "react";
import { Deal } from "@/lib/types";
import { PAGE_SIZE } from "@/lib/pagination";
import { cameBack } from "@/lib/navigation-type";
import { fitDeck } from "@/lib/fit-deck";
import { isExpired } from "@/lib/format";
import type { LovedDivider } from "@/lib/deal-views";
import { useExpiredFilter } from "./ExpiredFilterProvider";
import ExpiredMatches from "./ExpiredMatches";
import SwipeCard from "./SwipeCard";
import PromoSwipeCard from "./PromoSwipeCard";
import { promoSlot, type ListPromos } from "@/lib/promos";
import { adPositions } from "@/lib/ad-positions";
import AdUnit, { screenClass, useAds } from "./AdUnit";
import Icon, { EMPTY_ICON } from "./Icon";
import { ClockIcon } from "./icons";
import { freshAt } from "@/lib/upcoming";

// `activeDealId` is the deal on show (when it's a deal and not a promo), so Back
// finds it again even if a promo was added or taken away in between.
type CachedState = { deals: Deal[]; hasMore: boolean; activeIndex: number; activeDealId?: string };

// Everything that makes one list different from another, so going back to a
// page restores that page's deals and never another list's (a brand page and
// the homepage would otherwise share a key).
function cacheKey(query?: string, category?: string, tag?: string, view?: string, store?: string, minHearts?: number, filterQuery?: string, when?: string, brand?: string) {
  return `swipe-cache:${category ?? ""}:${tag ?? ""}:${query ?? ""}:${view ?? ""}:${store ?? ""}:${minHearts ?? 0}:${filterQuery ?? ""}:${when ?? ""}:${brand ?? ""}`;
}

// The CSS clamp() fallback (DECK_SIZE, below) guesses a fixed px offset
// for whatever sits above the deck (header + filter bar), which breaks on
// any device where that chrome is taller or shorter than guessed — most
// notably short/landscape viewports. Measure the real available space
// instead and set an exact height, so the deck (and the caption below it)
// always fits above the fold regardless of device.
function useFitToScreen(containerRef: RefObject<HTMLDivElement | null>) {
  useLayoutEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // While a finger is down the viewport is unstable: pulling down to
    // refresh makes the browser toolbar slide in (a resize event) and the
    // page rubber-band, which used to shrink the card mid-gesture. Hold any
    // re-measure until the touch has ended and things have settled.
    let touching = false;
    let pending = false;
    let settleTimer: ReturnType<typeof setTimeout> | undefined;

    function updateHeight() {
      if (!container) return;
      if (touching) {
        pending = true;
        return;
      }
      fitDeck(container);
    }

    function onTouchStart() {
      touching = true;
      clearTimeout(settleTimer);
    }
    function onTouchEnd() {
      clearTimeout(settleTimer);
      settleTimer = setTimeout(() => {
        touching = false;
        if (pending) {
          pending = false;
          updateHeight();
        }
      }, 600);
    }

    // The toolbar sliding in or out (on a refresh, or a tap just after one)
    // fires a resize on nearly every frame, and following each one made the
    // card shake. Wait until the screen has stopped changing, then fit once.
    let resizeTimer: ReturnType<typeof setTimeout> | undefined;
    function onResize() {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(updateHeight, 200);
    }

    updateHeight();
    window.addEventListener("touchstart", onTouchStart, { passive: true });
    window.addEventListener("touchend", onTouchEnd, { passive: true });
    window.addEventListener("touchcancel", onTouchEnd, { passive: true });
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onResize);
    // Re-measure if the header (search bar wrapping, font swap, etc.)
    // changes size without a window resize event firing.
    const header = document.querySelector("header");
    const observer = new ResizeObserver(updateHeight);
    if (header) observer.observe(header);
    // The title/filter chips above the deck can change height after load (a
    // saved filter chip appearing), so re-fit when they do.
    const label = container.parentElement?.previousElementSibling;
    if (label) observer.observe(label);

    return () => {
      clearTimeout(settleTimer);
      clearTimeout(resizeTimer);
      window.removeEventListener("touchstart", onTouchStart);
      window.removeEventListener("touchend", onTouchEnd);
      window.removeEventListener("touchcancel", onTouchEnd);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onResize);
      observer.disconnect();
    };
  }, [containerRef]);
}

// The card's size (before useFitToScreen sets an exact height), shared with
// EmptyDeck. Only a stand-in: the script after the page content (layout.tsx)
// sizes the card exactly before it is first drawn. The offsets are the usual
// space above and below the card (249px, 240px on wide screens) for when that
// script can't run.
const DECK_SIZE =
  "h-[clamp(320px,calc(100dvh_-_249px),480px)] w-full max-w-[380px] rounded-3xl sm:h-[clamp(360px,calc(100dvh_-_249px),560px)] sm:max-w-[440px] lg:h-[clamp(400px,calc(100dvh_-_240px),600px)] lg:max-w-[500px]";
// The dashed "end of the deck" card.
const END_CARD =
  "flex items-center justify-center rounded-3xl border border-dashed border-zinc-300 bg-zinc-50 p-6 text-center dark:border-zinc-700 dark:bg-zinc-900";

export default function SwipeDeck({
  initialDeals,
  initialHasMore,
  query,
  expiredCount,
  category,
  tag,
  store,
  brand,
  view,
  minHearts,
  filterQuery,
  when,
  divider,
  promos,
}: {
  initialDeals: Deal[];
  initialHasMore: boolean;
  query?: string;
  expiredCount?: number; // search only: expired matches, which come after every live one
  category?: string;
  tag?: string;
  store?: string;
  brand?: string; // brand page slug
  view?: string;
  minHearts?: number;
  filterQuery?: string; // ticked stores/categories, e.g. "stores=currys,argos"
  when?: string; // Most loved's time window ("today"); unset = the last 7 days
  divider?: LovedDivider; // Most loved: where deals from before the window start
  promos?: ListPromos; // Admin → Promos: a promo card and a sign-up tile, each a card of its own in the deck
}) {
  const { showExpired, hideLocal } = useExpiredFilter();
  const pageAds = useAds();
  const cardAds = pageAds?.slots.cards;
  const sponsored = pageAds?.slots.sponsored;
  const key = cacheKey(query, category, tag, view, store, minHearts, filterQuery, when, brand);
  const [deals, setDeals] = useState(initialDeals);
  const [hasMore, setHasMore] = useState(initialHasMore);
  const [loading, setLoading] = useState(false);
  // The last "load more" failed (a hiccup on the server or the connection): stop
  // asking by itself, and offer a button, so it never hammers a struggling server.
  const [failed, setFailed] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const sentinelRef = useRef<HTMLDivElement>(null);
  const restoredDealsRef = useRef(false);
  const restoredScrollRef = useRef(false);
  const cachedIndexRef = useRef<number | null>(null);
  const cachedDealIdRef = useRef<string | undefined>(undefined);
  const cachedCountRef = useRef(0);
  // True until a pending cache restore has fully settled, so the "save"
  // effect below never overwrites the cache with a stale in-between value
  // captured from a render that happened before the restore propagated.
  const restoringRef = useRef(true);
  // On a search with expired matches hidden, stop loading once the live deals
  // run out (they all come first) and say what's left instead.
  const pastLive = !showExpired && !!expiredCount && deals.length > 0 && isExpired(deals[deals.length - 1].expiresAt);
  const moreToLoad = hasMore && !pastLive;

  const loadMore = useCallback(async () => {
    if (loading || !hasMore) return;
    setLoading(true);
    try {
      const params = new URLSearchParams({ offset: String(deals.length), limit: String(PAGE_SIZE) });
      if (query) params.set("q", query);
      if (category) params.set("category", category);
      if (tag) params.set("tag", tag);
      if (store) params.set("store", store);
      if (brand) params.set("brand", brand);
      if (view) params.set("view", view);
      if (minHearts) params.set("hearts", String(minHearts));
      if (when) params.set("when", when);
      for (const [k, v] of new URLSearchParams(filterQuery ?? "")) params.set(k, v);
      const res = await fetch(`/api/deals?${params.toString()}`);
      if (!res.ok) throw new Error("Could not load more");
      const data = await res.json();
      setDeals((prev) => [...prev, ...data.results]);
      setHasMore(data.hasMore);
      setFailed(false);
    } catch {
      setFailed(true);
    } finally {
      setLoading(false);
    }
  }, [loading, hasMore, deals.length, query, category, tag, store, brand, view, minHearts, filterQuery, when]);

  useEffect(() => {
    const sentinel = sentinelRef.current;
    const root = containerRef.current;
    if (!sentinel || !root || !moreToLoad || failed) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) loadMore();
      },
      { root, rootMargin: "800px" }
    );
    observer.observe(sentinel);
    return () => observer.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [moreToLoad, deals.length, failed]);

  // Restore the previously-loaded deals and active card from a local cache,
  // synchronously before the browser paints — no fetch involved, so there's
  // nothing to wait on.
  useLayoutEffect(() => {
    if (restoredDealsRef.current) return;
    restoredDealsRef.current = true;
    if (!cameBack()) {
      restoringRef.current = false;
      return;
    }
    const raw = sessionStorage.getItem(key);
    if (!raw) {
      restoringRef.current = false;
      return;
    }
    const cached = JSON.parse(raw) as CachedState;
    cachedIndexRef.current = cached.activeIndex;
    cachedDealIdRef.current = cached.activeDealId;
    cachedCountRef.current = cached.deals.length;
    // On purpose: putting the remembered card back here, before the first
    // paint, is what lands Back on the same card with no flicker.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setActiveIndex(cached.activeIndex);
    if (cached.deals.length > initialDeals.length) {
      setDeals(cached.deals);
      setHasMore(cached.hasMore);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Once the restored deals are actually in the DOM, jump straight to the
  // card that was active: the same deal if it's still in the list (so a promo
  // added or taken away since can't land it a card out), otherwise the same
  // position.
  useLayoutEffect(() => {
    if (restoredScrollRef.current) return;
    const index = cachedIndexRef.current;
    if (index === null) return;
    const container = containerRef.current;
    if (!container) return;
    const id = cachedDealIdRef.current;
    const byId = id ? Array.from(container.children).findIndex((c) => (c as HTMLElement).dataset.dealId === id) : -1;
    // The deal may be further down than what's loaded so far: wait for the rest.
    if (id && byId < 0 && deals.length < cachedCountRef.current) return;
    const at = byId >= 0 ? byId : index;
    const target = container.children[at] as HTMLElement | undefined;
    if (!target) return;
    container.scrollTop = target.offsetTop;
    if (at !== index) setActiveIndex(at);
    restoredScrollRef.current = true;
    restoringRef.current = false;
  }, [deals]);

  useFitToScreen(containerRef);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    function onScroll() {
      if (!container) return;
      const idx = Math.round(container.scrollTop / container.clientHeight);
      setActiveIndex((prev) => (prev === idx ? prev : idx));
    }
    container.addEventListener("scroll", onScroll, { passive: true });
    return () => container.removeEventListener("scroll", onScroll);
  }, []);

  // Keep the loaded deals and active card cached locally so a later
  // back-navigation can restore both instantly. Skipped while a restore is
  // still in flight, so this can't clobber the cache with a stale
  // in-between value from before the restore finished applying.
  useEffect(() => {
    if (restoringRef.current) return;
    const shown = containerRef.current?.children[activeIndex] as HTMLElement | undefined;
    const state: CachedState = { deals, hasMore, activeIndex, activeDealId: shown?.dataset.dealId };
    sessionStorage.setItem(key, JSON.stringify(state));
  }, [key, deals, hasMore, activeIndex]);

  const visibleDeals = deals.filter(
    (deal) => (showExpired || !isExpired(deal.expiresAt)) && (!hideLocal || deal.whereToBuy !== "instore")
  );
  const hidingExpired = !showExpired && !!expiredCount;

  // Most loved's change from the window's deals to older ones (as List view's
  // divider line). Between fresh and older deals it's a card of its own, so
  // the jump in dates can't be swiped past unnoticed. With nothing fresh at
  // all, a card would only stand in front of every deal, so the line under
  // the deck says it instead. The card is a real child of the deck, so the
  // active-card index that back-navigation restores counts it like any other.
  const sinceMs = divider ? new Date(divider.since).getTime() : 0;
  const firstOlder = divider ? visibleDeals.findIndex((d) => !d.hero && freshAt(d) < sinceMs) : -1;
  const anyFresh = visibleDeals.slice(0, Math.max(0, firstOlder)).some((d) => !d.hero);

  // Where the promo card and the sign-up tile go: after the Nth deal (a card of
  // their own in the deck), or after the last on a list that ends sooner. A tile
  // that lands on the same deal as the card follows it.
  const cardAt = promos?.card ? promoSlot(promos.card.afterDeals, visibleDeals.length, moreToLoad) : -1;
  const signupAt = promos?.signup ? promoSlot(promos.signup.afterDeals, visibleDeals.length, moreToLoad) : -1;
  // Ads (Admin → Ads): a card of their own after deal N, then every M.
  const sponsoredAt = sponsored ? adPositions(visibleDeals.length, sponsored.first, sponsored.every, [cardAt, signupAt], moreToLoad, sponsored.max) : [];
  const adAt = cardAds ? adPositions(visibleDeals.length, cardAds.first, cardAds.every, [cardAt, signupAt, ...sponsoredAt], moreToLoad, cardAds.max) : [];

  return (
    <div data-swipe-deck className="flex w-full flex-col items-center gap-2">
      <div
        ref={containerRef}
        className={`no-scrollbar relative snap-y snap-mandatory overflow-y-auto ${DECK_SIZE}`}
      >
        {visibleDeals.map((deal, i) => (
          <Fragment key={deal.id}>
            {i === firstOlder && anyFresh && divider && (
              <div role="separator" className={`relative h-full w-full shrink-0 snap-start snap-always ${END_CARD}`}>
                <div className="flex flex-col items-center gap-2">
                  <ClockIcon className="h-10 w-10 text-orange-700 dark:text-orange-400" />
                  <p className="font-semibold">That&apos;s everything from {divider.phrase}</p>
                  <p className="text-sm text-zinc-500">Earlier deals next, most loved first.</p>
                </div>
                {/* Points on to the next card, so it doesn't read as the end. */}
                <Icon name="chevron-down" className="absolute bottom-6 left-1/2 size-7 -translate-x-1/2 text-orange-700 dark:text-orange-400" />
              </div>
            )}
            <div data-deal-id={deal.id} data-expired={isExpired(deal.expiresAt) || undefined} className="flex h-full w-full snap-start snap-always">
              <SwipeCard deal={deal} />
            </div>
            {i === cardAt && promos?.card && (
              <div className="flex h-full w-full snap-start snap-always">
                <PromoSwipeCard promo={promos.card} />
              </div>
            )}
            {i === signupAt && promos?.signup && (
              <div className="flex h-full w-full snap-start snap-always">
                <PromoSwipeCard promo={promos.signup} />
              </div>
            )}
            {sponsoredAt.includes(i) && (
              <div className="flex h-full w-full snap-start snap-always">
                <AdUnit slot="sponsored" n={sponsoredAt.indexOf(i)} cards />
              </div>
            )}
            {adAt.includes(i) && (
              <div className={`flex h-full w-full snap-start snap-always ${screenClass(cardAds!.screens, "flex")}`}>
                <AdUnit slot="cards" n={adAt.indexOf(i)} cards className="h-full w-full" />
              </div>
            )}
          </Fragment>
        ))}

        {moreToLoad ? (
          failed ? (
            <div className="flex h-full w-full shrink-0 snap-start items-center justify-center">
              <button type="button" onClick={loadMore} className="min-h-10 rounded-full border border-zinc-300 px-4 text-sm font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800">
                Couldn&apos;t load more deals. Try again
              </button>
            </div>
          ) : (
            <div ref={sentinelRef} className="h-1 w-full shrink-0" />
          )
        ) : (
          <div className={`h-full w-full shrink-0 snap-start snap-always ${END_CARD}`}>
            {hidingExpired && isExpired(deals[0]?.expiresAt) ? (
              <ExpiredMatches count={expiredCount} query={query} nothingLive boxed={false} />
            ) : (
              <div className="flex flex-col items-center gap-2">
                <Icon name="party" className={EMPTY_ICON} />
                <p className="font-semibold">You&apos;ve reached the end!</p>
                {hidingExpired ? (
                  <ExpiredMatches count={expiredCount} nothingLive={false} />
                ) : (
                  <p className="text-sm text-zinc-500">Scroll back up to revisit deals.</p>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {divider && firstOlder >= 0 && !anyFresh ? (
        // Styled like List view's divider (bold words, orange clock between
        // orange bars) so it isn't missed, but kept to the scroll hint's one
        // 16px line: useFitToScreen sizes the card around it.
        <p className="flex h-4 w-full max-w-[380px] items-center gap-2 text-xs font-bold leading-4 text-zinc-900 sm:max-w-[440px] lg:max-w-[500px] dark:text-zinc-100">
          <span aria-hidden className="h-1 min-w-4 flex-1 rounded-full bg-orange-500" />
          <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap">
            <ClockIcon className="h-3.5 w-3.5 shrink-0 text-orange-700 dark:text-orange-400" />
            Nothing new in {divider.phrase} · earlier deals
          </span>
          <span aria-hidden className="h-1 min-w-4 flex-1 rounded-full bg-orange-500" />
        </p>
      ) : (
        <p className="text-xs text-zinc-500 dark:text-zinc-400">Scroll for next · tap the hearts to rate · tap for details</p>
      )}
    </div>
  );
}

// "No deals" in Cards view: the page's empty message (its own box removed) on
// a dashed card sized and placed exactly like a deal card, with a blank line
// where the scroll hint goes, rather than a small box floating mid-page.
// data-swipe-deck hides the footer on phones, as with real cards.
export function EmptyDeck({ children }: { children: ReactNode }) {
  const containerRef = useRef<HTMLDivElement>(null);
  useFitToScreen(containerRef);
  return (
    <div data-swipe-deck className="flex w-full flex-col items-center gap-2">
      <div ref={containerRef} className={`${DECK_SIZE} ${END_CARD} [&>*]:border-0 [&>*]:p-0`}>
        {children}
      </div>
      <p aria-hidden className="invisible text-xs">
        &nbsp;
      </p>
    </div>
  );
}
