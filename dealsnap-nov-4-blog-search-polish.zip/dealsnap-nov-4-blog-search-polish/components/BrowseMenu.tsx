"use client";

import Link from "next/link";
import { createPortal } from "react-dom";
import Icon, { type IconName } from "./Icon";
import { useAnchoredMenu } from "./useAnchoredMenu";

// Voucher codes first, the site's lead (its ticket in the codes' violet).
const ITEMS: { href: string; label: string; icon: IconName }[] = [
  { href: "/vouchers", label: "Voucher codes", icon: "ticket" },
  { href: "/categories", label: "Categories", icon: "grid" },
  { href: "/stores", label: "Stores", icon: "store" },
  { href: "/brands", label: "Brands", icon: "badge-check" },
];

// "Browse" in the laptop header: one click opens the ways to browse, so
// stores and brands are as close from a blog or account page as from the deals
// list. A click menu, not a hover one, so it also works on a touch laptop.
// Phones don't show it: their menu lists the three directly.
export default function BrowseMenu({ className }: { className: string }) {
  const { open, toggle, close, anchorRef, host, menuProps } = useAnchoredMenu<HTMLButtonElement>("center");

  return (
    <>
      <button
        ref={anchorRef}
        type="button"
        onClick={toggle}
        aria-haspopup="menu"
        aria-expanded={open}
        className={`${className} items-center gap-1`}
      >
        Browse
        <Icon name="chevron-down" className={`size-3.5 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open &&
        host &&
        createPortal(
          <div
            {...menuProps}
            role="menu"
            className={`${menuProps.className} w-44 rounded-xl border border-zinc-200 bg-white p-1 shadow-lg dark:border-zinc-800 dark:bg-zinc-900`}
          >
            {ITEMS.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                role="menuitem"
                onClick={close}
                className="flex min-h-10 items-center gap-2.5 rounded-lg px-3 text-sm text-zinc-700 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
              >
                <Icon name={item.icon} className={`size-[18px] ${item.href === "/vouchers" ? "text-violet-600 dark:text-violet-400" : "text-zinc-500 dark:text-zinc-400"}`} />
                {item.label}
              </Link>
            ))}
          </div>,
          host
        )}
    </>
  );
}
