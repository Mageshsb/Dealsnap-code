"use client";

import { useState } from "react";
import DealPhotoField, { type DealPhoto } from "./DealPhotoField";

// The photo on the staff edit form: starts as the deal's current one, and
// can be replaced or taken off (an unsuitable picture, say).
export default function DealPhotoEditor({ current }: { current?: string }) {
  const [photo, setPhoto] = useState<DealPhoto | null>(current ? { src: current, fromLink: false } : null);
  return <DealPhotoField value={photo} onChange={setPhoto} />;
}
