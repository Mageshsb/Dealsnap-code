import Link from "next/link";
import { UserRecord, PROFILE_REPORT_REASONS } from "@/lib/db";
import { romanNumeral, type Badge } from "@/lib/badges";
import { formatDate } from "@/lib/format";
import FollowButton from "./FollowButton";
import UserAvatar from "./UserAvatar";
import ProfileActionsMenu from "./ProfileActionsMenu";
import { SettingsIcon } from "./icons";
import Icon from "./Icon";
import VoteStrengthCard from "./VoteStrengthCard";
import TierBadge, { tierText } from "./TierBadge";
import RoleBadge, { tierOf } from "./RoleBadge";

// More than this many chips crowds the card on narrow phones.
const MAX_BADGE_CHIPS = 4;

export type ProfileStats = { dealCount: number; heartsReceived: number; commentCount: number };

export default function ProfileHeaderCard({
  profileUser,
  isOwner,
  isFollowing,
  followMuted,
  viewerLoggedIn,
  followerCount,
  followingCount,
  badges,
  stats,
  viewerRelation,
}: {
  profileUser: UserRecord;
  isOwner: boolean;
  isFollowing: boolean;
  followMuted: boolean;
  viewerLoggedIn: boolean;
  followerCount: number;
  followingCount: number;
  badges: Badge[];
  stats: ProfileStats;
  // Only for someone else's profile, when signed in.
  viewerRelation?: { blocked: boolean; blockedBy: boolean; reported: boolean };
}) {
  const shownBadges = [...badges].sort((a, b) => b.tier - a.tier).slice(0, MAX_BADGE_CHIPS);
  const hiddenBadges = badges.length - shownBadges.length;
  const statItems = [
    { value: stats.dealCount, label: stats.dealCount === 1 ? "deal posted" : "deals posted" },
    { value: stats.heartsReceived, label: stats.heartsReceived === 1 ? "heart received" : "hearts received" },
    { value: stats.commentCount, label: stats.commentCount === 1 ? "post" : "posts" },
  ];

  const rank = tierOf(profileUser.role);

  return (
    <div className="flex flex-col gap-4 rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900 sm:p-6">
      {/* The Follow and … buttons drop under the name on a narrow screen rather
          than squeezing it; a very long name shows as "name…" on one line. */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex min-w-0 flex-1 basis-52 items-center gap-3 sm:gap-4">
          <UserAvatar
            username={profileUser.username}
            avatarUrl={profileUser.avatarUrl}
            size="h-14 w-14 sm:h-16 sm:w-16"
            textSize="text-2xl"
          />
          <div className="min-w-0">
            <h1 className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xl font-bold">
              <span className="min-w-0 max-w-full truncate">{profileUser.username}</span>
              {rank && <RoleBadge tier={rank} variant="pill" />}
            </h1>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">Joined {formatDate(profileUser.createdAt)}</p>
          </div>
        </div>

        {isOwner ? (
          <Link
            href="/settings?s=profile"
            aria-label="Edit profile and settings"
            title="Edit profile and settings"
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-zinc-300 text-zinc-600 hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
          >
            <SettingsIcon className="h-[18px] w-[18px]" />
          </Link>
        ) : (
          <div className="flex shrink-0 items-center gap-2">
            {!viewerLoggedIn ? (
              <Link
                href={`/login?next=${encodeURIComponent(`/u/${profileUser.username}`)}`}
                className="inline-flex items-center gap-1 rounded-full border border-orange-500 bg-orange-500 px-4 py-1.5 text-sm font-semibold text-white hover:border-orange-600 hover:bg-orange-600"
              >
                <Icon name="plus" className="size-4" />
                Follow
              </Link>
            ) : (
              <>
                {!viewerRelation?.blocked && !viewerRelation?.blockedBy && (
                  <FollowButton targetUserId={profileUser.id} initialFollowing={isFollowing} initialMuted={followMuted} />
                )}
                <ProfileActionsMenu
                  targetUserId={profileUser.id}
                  username={profileUser.username}
                  reasons={PROFILE_REPORT_REASONS}
                  alreadyReported={!!viewerRelation?.reported}
                  isBlocked={!!viewerRelation?.blocked}
                  canBlock={profileUser.role === "user"}
                />
              </>
            )}
          </div>
        )}
      </div>

      {profileUser.bio && <p className="whitespace-pre-line text-sm text-zinc-600 dark:text-zinc-400">{profileUser.bio}</p>}

      <div className="flex flex-wrap items-center gap-4 text-sm">
        <Link href={`/u/${profileUser.username}/followers`} className="hover:underline">
          <span className="font-semibold">{followerCount}</span>{" "}
          <span className="text-zinc-500">follower{followerCount === 1 ? "" : "s"}</span>
        </Link>
        <Link href={`/u/${profileUser.username}/following`} className="hover:underline">
          <span className="font-semibold">{followingCount}</span> <span className="text-zinc-500">following</span>
        </Link>
      </div>

      {badges.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {/* Each badge at its highest tier only, the four best first; the
              rest are a "+2" that opens the Badges tab. */}
          {shownBadges.map((badge) => (
            <span
              key={badge.key}
              title={badge.description}
              className="flex items-center gap-1.5 whitespace-nowrap rounded-full bg-zinc-100 py-1 pl-1 pr-3 text-sm dark:bg-zinc-800"
            >
              <TierBadge icon={badge.icon} tier={badge.tier} size="sm" />
              <span className="font-medium">{badge.name}</span>
              <span className={`font-bold ${tierText(badge.tier)}`}>{romanNumeral(badge.tier)}</span>
            </span>
          ))}
          {hiddenBadges > 0 && (
            <Link
              href={`/u/${profileUser.username}?tab=badges`}
              aria-label={`${hiddenBadges} more badge${hiddenBadges === 1 ? "" : "s"}`}
              className="flex items-center rounded-full bg-zinc-100 px-3 py-1 text-sm font-medium text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
            >
              +{hiddenBadges}
            </Link>
          )}
        </div>
      )}

      {/* Stats, in the spirit of HUKD's profile statistics box. */}
      <dl className="grid grid-cols-3 gap-2 border-t border-zinc-100 pt-4 dark:border-zinc-800">
        {statItems.map((s) => (
          <div key={s.label} className="flex flex-col-reverse items-center text-center">
            <dt className="text-[11px] leading-tight text-zinc-500">{s.label}</dt>
            <dd className="text-lg font-bold tabular-nums">{s.value.toLocaleString("en-GB")}</dd>
          </div>
        ))}
      </dl>

      {isOwner && <VoteStrengthCard userId={profileUser.id} />}
    </div>
  );
}
