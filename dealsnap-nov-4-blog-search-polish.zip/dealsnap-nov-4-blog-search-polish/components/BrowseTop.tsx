import Link from "next/link";

const PAGES = [
  { key: "categories", label: "Categories", href: "/categories", heading: "categories", more: "& tags" },
  { key: "stores", label: "Stores", href: "/stores", heading: "stores", more: "" },
  { key: "brands", label: "Brands", href: "/brands", heading: "brands", more: "" },
] as const;

// The top of the three ways to browse (/categories, /stores, /brands): a short
// heading with the three pages as one tight switch beside it, and the count
// line under. The row stays one line on a 360px phone, even with larger text,
// and sits in the same place on all three pages. The heading names the page
// (with tags mentioned, as most of /categories is tags): "Browse stores" from
// 640px up, and on phones just "Stores". "& tags" is a second word that
// stays on the phone title only where it fits whole: the heading is one line
// tall and clipped, so a word with no room wraps below and out of sight.
// The "Browse" is hidden on phones, not removed, so the capital letter comes
// from first-letter on the page's name (a flex item, which allows it).
export default function BrowseTop({ show, children }: { show: (typeof PAGES)[number]["key"]; children: React.ReactNode }) {
  const page = PAGES.find((p) => p.key === show)!;
  return (
    <div>
      <div className="flex items-center justify-between gap-2">
        <h1 className="min-w-0 text-xl font-bold max-sm:flex max-sm:h-7 max-sm:flex-wrap max-sm:gap-x-[0.25em] max-sm:overflow-hidden sm:text-2xl">
          <span className="max-sm:hidden">Browse </span>
          <span className="max-sm:min-w-0 max-sm:max-w-full max-sm:truncate max-sm:first-letter:uppercase">{page.heading}</span>
          {page.more && <span className="max-sm:shrink-0"> {page.more}</span>}
        </h1>
        {/* The -my-1 takes the 36px switch down to the title's 28px line in
            the layout, so the row is no taller than a plain title. */}
        <nav aria-label="Browse" className="-my-1 flex shrink-0 gap-0.5 rounded-xl bg-zinc-100 p-0.5 dark:bg-zinc-800">
          {PAGES.map((p) => (
            <Link
              key={p.key}
              href={p.href}
              aria-current={show === p.key ? "page" : undefined}
              className={`flex h-8 items-center rounded-[10px] px-2 text-sm font-medium transition-colors ${
                show === p.key ? "bg-orange-500 text-white" : "text-zinc-600 hover:bg-zinc-200 dark:text-zinc-300 dark:hover:bg-zinc-700"
              }`}
            >
              {p.label}
            </Link>
          ))}
        </nav>
      </div>
      <p className="mt-1 text-sm text-zinc-500">{children}</p>
    </div>
  );
}
