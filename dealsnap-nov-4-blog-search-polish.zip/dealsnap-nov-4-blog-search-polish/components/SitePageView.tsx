import InfoPage, { type InfoSection } from "./InfoPage";
import HtmlPage from "./HtmlPage";
import PageBlocks from "./PageText";
import { formatPageDate, pageHref, pageTokens, type SitePage } from "@/lib/site-pages";

// One footer page, drawn from what's saved in Admin → Pages. `before` is for a
// built-in page whose own sections are written by code so they always match the
// site's real settings (the Privacy policy): the saved text follows them.
export default function SitePageView({
  page,
  before = [],
  summary,
  topic,
  children,
}: {
  page: SitePage;
  before?: InfoSection[];
  summary?: React.ReactNode; // the page's own "short version", when code writes it
  topic?: string; // ?topic= on the contact form, for a page that has one
  children?: React.ReactNode; // after a Custom HTML page
}) {
  if (page.format === "html") return <HtmlPage page={page} topic={topic}>{children}</HtmlPage>;
  const tokens = pageTokens();
  const taken = new Set(before.map((s) => s.id));
  const own: InfoSection[] = page.sections.map((s) => {
    let id = s.id;
    for (let n = 2; id && taken.has(id); n++) id = `${s.id}-${n}`;
    taken.add(id);
    return { id, title: s.title, body: <PageBlocks blocks={s.blocks} tokens={tokens} /> };
  });
  const sections = [...before, ...own];
  const shortVersion = summary ?? (page.summaryBlocks.length > 0 ? <PageBlocks blocks={page.summaryBlocks} tokens={tokens} /> : undefined);
  return (
    <InfoPage
      path={pageHref(page)}
      numbered={page.numbered}
      title={page.title}
      intro={page.intro || undefined}
      updated={page.showUpdated && page.updatedOn ? formatPageDate(page.updatedOn) : undefined}
      summary={shortVersion}
      sections={sections}
      contents={sections.filter((s) => s.title).length > 1}
    />
  );
}
