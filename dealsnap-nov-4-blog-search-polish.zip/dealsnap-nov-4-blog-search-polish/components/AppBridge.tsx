"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { nativeApp, registerAppPush, rememberAppPushToken, savedAppPushToken } from "@/lib/app-native";
import { forgetAppPushTokenAction, saveAppPushTokenAction } from "@/lib/member-actions";

// Only in the phone apps (app/layout.tsx mounts it there): joins the site up
// with the app's native parts.
//   - "Get deal" opens the store in the in-app browser, so shoppers come
//     straight back to DealSnap, or in the store's own app for Amazon and eBay
//     (lib/deal-click.ts). Other sites' links open in the in-app browser too.
//   - Tapping a notification, or a DealSnap link in another app, opens that
//     page here.
//   - Notifications stay pointed at whoever is signed in on this phone.
export default function AppBridge({ loggedIn }: { loggedIn: boolean }) {
  const router = useRouter();

  useEffect(() => {
    const app = nativeApp();
    if (!app) return;
    const { Browser, AppLauncher } = app.plugins;

    async function openDeal(slug: string) {
      const res = await fetch(`/api/go/${encodeURIComponent(slug)}`, { cache: "no-store" }).catch(() => undefined);
      const click = res?.ok ? ((await res.json().catch(() => undefined)) as { url: string; storeApp: boolean } | undefined) : undefined;
      if (!click) return;
      if (click.storeApp && AppLauncher) await AppLauncher.openUrl({ url: click.url });
      else await Browser?.open({ url: click.url, presentationStyle: "fullscreen" });
    }

    function onClick(e: MouseEvent) {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      const link = (e.target as Element | null)?.closest?.("a[href]") as HTMLAnchorElement | null;
      if (!link || link.hasAttribute("download")) return;
      let url: URL;
      try {
        url = new URL(link.href, location.href);
      } catch {
        return;
      }
      if (url.protocol !== "https:" && url.protocol !== "http:") return; // mailto:, tel: → the phone handles them
      if (url.origin === location.origin) {
        const deal = url.pathname.match(/^\/go\/([^/]+)$/);
        if (deal) {
          e.preventDefault();
          openDeal(decodeURIComponent(deal[1]));
        } else if (link.target === "_blank") {
          // There are no tabs in the app: open it right here.
          e.preventDefault();
          router.push(url.pathname + url.search + url.hash);
        }
        return;
      }
      e.preventDefault();
      Browser?.open({ url: url.href, presentationStyle: "fullscreen" });
    }
    // Capture, so it runs before any link's own handler sends the page there.
    document.addEventListener("click", onClick, true);

    const listeners = [
      app.plugins.App?.addListener("appUrlOpen", ({ url }) => {
        try {
          const to = new URL(url);
          if (to.host === location.host || to.hostname.replace(/^www\./, "") === location.hostname.replace(/^www\./, "")) {
            router.push(to.pathname + to.search + to.hash);
          }
        } catch {
          // Not a web address.
        }
      }),
      app.plugins.PushNotifications?.addListener("pushNotificationActionPerformed", ({ notification }) => {
        const to = notification.data?.url;
        // Only DealSnap's own pages.
        if (typeof to === "string" && to.startsWith("/") && !to.startsWith("//")) router.push(to);
      }),
    ];
    return () => {
      document.removeEventListener("click", onClick, true);
      listeners.forEach((l) => l?.then((x) => x.remove()).catch(() => {}));
    };
  }, [router]);

  // Signed in with notifications allowed: refresh this phone's address (Apple
  // and Google change it now and then) under whoever is signed in now.
  // Signed out: forget it, so the last person's notifications stop.
  useEffect(() => {
    const app = nativeApp();
    const push = app?.plugins.PushNotifications;
    if (!app || !push) return;
    const saved = savedAppPushToken();
    if (!loggedIn) {
      if (saved) {
        forgetAppPushTokenAction(app.platform, saved).catch(() => {});
        rememberAppPushToken(undefined);
      }
      return;
    }
    if (!saved) return; // Never turned on here: Settings → Notifications does that.
    push
      .checkPermissions()
      .then(async ({ receive }) => {
        if (receive !== "granted") {
          // Turned off in the phone's Settings since: stop sending.
          forgetAppPushTokenAction(app.platform, saved).catch(() => {});
          rememberAppPushToken(undefined);
          return;
        }
        const token = await registerAppPush();
        if (!token) return;
        if (token !== saved) forgetAppPushTokenAction(app.platform, saved).catch(() => {});
        const res = await saveAppPushTokenAction(app.platform, token);
        if (res.ok) rememberAppPushToken(token);
      })
      .catch(() => {});
  }, [loggedIn]);

  return null;
}
