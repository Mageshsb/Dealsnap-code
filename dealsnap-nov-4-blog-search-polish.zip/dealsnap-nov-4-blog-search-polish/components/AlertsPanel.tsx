"use client";

import Link from "next/link";
import { useMemo, useRef, useState, useTransition } from "react";
import {
  setTagAlertAction,
  setBrandAlertAction,
  setStoreAlertAction,
  setCategoryAlertAction,
  addKeywordAlertAction,
  removeKeywordAlertAction,
  setKeywordAlertPriceAction,
} from "@/lib/actions";
import type { KeywordMatchInfo } from "@/lib/keyword-matches";
import { setAlertMinHeartsAction } from "@/lib/member-actions";
import {
  MAX_ALERT_PRICE,
  alertPriceText,
  normalizeKeyword,
  sameKeyword,
} from "@/lib/alert-match";
import { ALERT_HEART_CHOICES } from "@/lib/notification-kinds";
import SelectField from "./SelectField";
import EmptyState from "./EmptyState";
import AccountSection, { RowIcon } from "./AccountSection";
import { ClearSearch, searchBox } from "@/components/SearchBox";
import Icon, { type IconName } from "./Icon";
import StoreLogo from "./StoreLogo";
import BrandLogo from "./BrandLogo";
import StableLabel, { words } from "./StableLabel";

export type AlertStore = {
  key: string;
  name: string;
  slug: string;
  dealCount: number;
  logoUrl?: string;
};
export type AlertTag = {
  slug: string;
  name: string;
  icon: IconName;
  category: string;
  // A sub-tag's tag ("Laptop" for MacBook).
  parent?: string;
};
export type AlertBrand = { slug: string; name: string; logoUrl?: string };
export type AlertCategory = { slug: string; name: string; icon: IconName };

type Option =
  | {
      kind: "category";
      id: string;
      label: string;
      icon: IconName;
      hint: string;
    }
  | { kind: "tag"; id: string; label: string; icon: IconName; hint: string }
  | { kind: "brand"; id: string; label: string; icon: IconName; hint: string; logoUrl?: string }
  | { kind: "store"; id: string; label: string; icon: IconName; hint: string; logoUrl?: string }
  | {
      kind: "keyword";
      id: string;
      label: string;
      icon: IconName;
      hint: string;
    };

// The Alerts page: one search box that finds shops, categories and products
// to be alerted about (or, when nothing fits, sets an alert for whatever
// words you typed), and one list of everything you're alerted about. Each
// alert can wait until a deal has proved popular ("once it has 100
// hearts"), and a keyword alert can have a price limit ("iphone 17 256gb,
// up to £700").
export default function AlertsPanel({
  allTags,
  initialSlugs,
  newThisWeek,
  initialKeywords,
  keywordInfo,
  allStores,
  initialStoreKeys,
  storeNewThisWeek,
  allCategories,
  initialCategorySlugs,
  categoryNewThisWeek,
  allBrands,
  initialBrandSlugs,
  brandNewThisWeek,
  minHearts: initialMinHearts = {},
  suggestions = [],
}: {
  allTags: AlertTag[];
  initialSlugs: string[];
  newThisWeek: Record<string, number>;
  initialKeywords: { id: string; keyword: string; maxPrice?: number }[];
  keywordInfo: Record<string, KeywordMatchInfo>;
  allStores: AlertStore[];
  initialStoreKeys: string[];
  storeNewThisWeek: Record<string, number>;
  allCategories: AlertCategory[];
  initialCategorySlugs: string[];
  categoryNewThisWeek: Record<string, number>;
  allBrands: AlertBrand[];
  initialBrandSlugs: string[];
  brandNewThisWeek: Record<string, number>;
  minHearts?: Record<string, number>;
  // One-tap alerts for an empty page (popular topics and stores right now).
  suggestions?: { kind: "tag" | "store"; id: string; label: string; icon: IconName }[];
}) {
  const [tagSlugs, setTagSlugs] = useState(initialSlugs);
  const [brandSlugs, setBrandSlugs] = useState(initialBrandSlugs);
  const [storeKeys, setStoreKeys] = useState(initialStoreKeys);
  const [categorySlugs, setCategorySlugs] = useState(initialCategorySlugs);
  const [keywords, setKeywords] = useState(initialKeywords);
  const [infos, setInfos] = useState(keywordInfo);
  const [minHearts, setMinHearts] = useState(initialMinHearts);
  const [, startTransition] = useTransition();

  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const tagBySlug = useMemo(
    () => new Map(allTags.map((t) => [t.slug, t])),
    [allTags],
  );
  const storeByKey = useMemo(
    () => new Map(allStores.map((s) => [s.key, s])),
    [allStores],
  );
  const categoryBySlug = useMemo(
    () => new Map(allCategories.map((c) => [c.slug, c])),
    [allCategories],
  );
  const brandBySlug = useMemo(
    () => new Map(allBrands.map((b) => [b.slug, b])),
    [allBrands],
  );

  // ---- the list of what you're alerted about -------------------------------
  const mineTags = tagSlugs
    .map((s) => tagBySlug.get(s))
    .filter((t): t is AlertTag => !!t);
  const mineStores = storeKeys
    .map((k) => storeByKey.get(k))
    .filter((s): s is AlertStore => !!s);
  const mineCategories = categorySlugs
    .map((s) => categoryBySlug.get(s))
    .filter((c): c is AlertCategory => !!c);
  const mineBrands = brandSlugs
    .map((s) => brandBySlug.get(s))
    .filter((b): b is AlertBrand => !!b);
  const total =
    mineCategories.length +
    mineTags.length +
    mineBrands.length +
    mineStores.length +
    keywords.length;

  // New category alerts start at 25 hearts (see category_alerts in db.ts), so the
  // picker shows that straight away rather than "as soon as it's posted".
  function setCategory(slug: string, on: boolean) {
    setCategorySlugs((cur) =>
      on
        ? [slug, ...cur.filter((s) => s !== slug)]
        : cur.filter((s) => s !== slug),
    );
    if (on) setMinHearts((cur) => ({ ...cur, [`category:${slug}`]: 25 }));
    startTransition(async () => {
      const res = await setCategoryAlertAction(slug, on);
      if (!res.ok)
        setCategorySlugs((cur) =>
          on ? cur.filter((s) => s !== slug) : [slug, ...cur],
        );
    });
  }

  function setTag(slug: string, on: boolean) {
    setTagSlugs((cur) =>
      on
        ? [slug, ...cur.filter((s) => s !== slug)]
        : cur.filter((s) => s !== slug),
    );
    startTransition(async () => {
      const res = await setTagAlertAction(slug, on);
      if (!res.ok)
        setTagSlugs((cur) =>
          on ? cur.filter((s) => s !== slug) : [slug, ...cur],
        );
    });
  }

  function setBrand(slug: string, on: boolean) {
    setBrandSlugs((cur) =>
      on
        ? [slug, ...cur.filter((s) => s !== slug)]
        : cur.filter((s) => s !== slug),
    );
    startTransition(async () => {
      const res = await setBrandAlertAction(slug, on);
      if (!res.ok)
        setBrandSlugs((cur) =>
          on ? cur.filter((s) => s !== slug) : [slug, ...cur],
        );
    });
  }

  function setStore(key: string, on: boolean) {
    setStoreKeys((cur) =>
      on
        ? [key, ...cur.filter((k) => k !== key)]
        : cur.filter((k) => k !== key),
    );
    startTransition(async () => {
      const res = await setStoreAlertAction(key, on);
      if (!res.ok)
        setStoreKeys((cur) =>
          on ? cur.filter((k) => k !== key) : [key, ...cur],
        );
    });
  }

  function setThreshold(kind: Option["kind"], id: string, value: number) {
    const key = `${kind}:${id}`;
    const before = minHearts[key] ?? 0;
    setMinHearts((cur) => ({ ...cur, [key]: value }));
    startTransition(async () => {
      const res = await setAlertMinHeartsAction(kind, id, value);
      if (!res.ok) setMinHearts((cur) => ({ ...cur, [key]: before }));
    });
  }

  function setPrice(id: string, maxPrice: number | null) {
    const before = keywords.find((k) => k.id === id)?.maxPrice;
    const put = (value?: number) =>
      setKeywords((cur) =>
        cur.map((k) => (k.id === id ? { ...k, maxPrice: value } : k)),
      );
    put(maxPrice ?? undefined);
    startTransition(async () => {
      const res = await setKeywordAlertPriceAction(id, maxPrice);
      if (res.ok) setInfos((cur) => ({ ...cur, [id]: res.info }));
      else put(before);
    });
  }

  function removeKeyword(id: string) {
    setKeywords((cur) => cur.filter((k) => k.id !== id));
    startTransition(async () => {
      await removeKeywordAlertAction(id);
    });
  }

  // ---- the search box ------------------------------------------------------
  const q = query.trim().toLowerCase();
  const options: Option[] = useMemo(() => {
    if (!q) return [];
    const out: Option[] = [];
    allCategories
      .filter(
        (c) =>
          !categorySlugs.includes(c.slug) && c.name.toLowerCase().includes(q),
      )
      .slice(0, 3)
      .forEach((c) =>
        out.push({
          kind: "category",
          id: c.slug,
          label: c.name,
          icon: c.icon,
          hint: "Category · from 25 hearts",
        }),
      );
    allTags
      .filter(
        (t) => !tagSlugs.includes(t.slug) && t.name.toLowerCase().includes(q),
      )
      .sort(
        (a, b) =>
          Number(b.name.toLowerCase().startsWith(q)) -
          Number(a.name.toLowerCase().startsWith(q)),
      )
      .slice(0, 5)
      .forEach((t) =>
        out.push({
          kind: "tag",
          id: t.slug,
          label: t.name,
          icon: t.icon,
          hint: `Tag · ${t.parent ?? t.category}`,
        }),
      );
    allBrands
      .filter(
        (b) => !brandSlugs.includes(b.slug) && b.name.toLowerCase().includes(q),
      )
      .sort(
        (a, b) =>
          Number(b.name.toLowerCase().startsWith(q)) -
          Number(a.name.toLowerCase().startsWith(q)),
      )
      .slice(0, 3)
      .forEach((b) =>
        out.push({
          kind: "brand",
          id: b.slug,
          label: b.name,
          icon: "badge-check",
          hint: "Brand · from any store",
          logoUrl: b.logoUrl,
        }),
      );
    allStores
      .filter(
        (s) => !storeKeys.includes(s.key) && s.name.toLowerCase().includes(q),
      )
      .sort(
        (a, b) =>
          Number(b.name.toLowerCase().startsWith(q)) -
          Number(a.name.toLowerCase().startsWith(q)),
      )
      .slice(0, 5)
      .forEach((s) =>
        out.push({
          kind: "store",
          id: s.key,
          label: s.name,
          icon: "store",
          hint: "Store",
          logoUrl: s.logoUrl,
        }),
      );
    const kw = normalizeKeyword(query);
    if (kw.length >= 2 && !keywords.some((k) => sameKeyword(k.keyword, kw))) {
      out.push({
        kind: "keyword",
        id: kw,
        label: query.trim(),
        icon: "search",
        hint: "Custom alert · any deal with these words",
      });
    }
    return out;
  }, [
    q,
    query,
    allCategories,
    allTags,
    allStores,
    allBrands,
    categorySlugs,
    tagSlugs,
    brandSlugs,
    storeKeys,
    keywords,
  ]);

  async function pick(opt: Option) {
    if (busy) return;
    setError("");
    if (opt.kind === "category") setCategory(opt.id, true);
    else if (opt.kind === "tag") setTag(opt.id, true);
    else if (opt.kind === "brand") setBrand(opt.id, true);
    else if (opt.kind === "store") setStore(opt.id, true);
    else {
      setBusy(true);
      const typed = query;
      setQuery("");
      const res = await addKeywordAlertAction(opt.label);
      setBusy(false);
      if (!res.ok) {
        setQuery(typed);
        setError(res.error);
        return;
      }
      setKeywords((cur) => [res.alert, ...cur]);
      setInfos((cur) => ({ ...cur, [res.alert.id]: res.info }));
    }
    setQuery("");
    setActive(0);
    inputRef.current?.focus();
  }

  function onKeyDown(e: React.KeyboardEvent) {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setOpen(true);
      setActive((a) => Math.min(a + 1, options.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((a) => Math.max(a - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (options[active]) pick(options[active]);
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  }

  const showList = open && q.length > 0;

  return (
    <>
      <AccountSection
        icon="plus"
        title="Add an alert"
        description={
          <>
            Search for a store, category or type of product, or type any words,
            like &ldquo;iphone 17 256gb&rdquo;.
          </>
        }
      >
        <div className="flex flex-col gap-2">
          <div className="relative">
            <input
              ref={inputRef}
              type="search"
              role="combobox"
              aria-expanded={showList}
              aria-controls="alert-options"
              aria-label="Search stores, categories and products, or type your own words"
              autoComplete="off"
              value={query}
              maxLength={60}
              onChange={(e) => {
                setQuery(e.target.value);
                setOpen(true);
                setActive(0);
                setError("");
              }}
              onFocus={() => setOpen(true)}
              onBlur={() => setTimeout(() => setOpen(false), 150)}
              onKeyDown={onKeyDown}
              placeholder="Store, category or any words"
              className={searchBox}
            />
            {query && (
              <ClearSearch
                onClick={() => {
                  setQuery("");
                  setError("");
                  inputRef.current?.focus();
                }}
              />
            )}
            {showList && (
              <ul
                id="alert-options"
                role="listbox"
                className="absolute left-0 right-0 top-full z-20 mt-1 max-h-80 overflow-y-auto rounded-xl border border-zinc-200 bg-white py-1 shadow-lg dark:border-zinc-700 dark:bg-zinc-900"
              >
                {options.length === 0 && (
                  <li className="px-3 py-2 text-sm text-zinc-500">
                    Nothing new to add for that.
                  </li>
                )}
                {options.map((o, i) => (
                  <li
                    key={`${o.kind}:${o.id}`}
                    role="option"
                    aria-selected={i === active}
                  >
                    <button
                      type="button"
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => pick(o)}
                      onMouseEnter={() => setActive(i)}
                      className={`flex w-full items-center gap-3 px-3 py-2 text-left text-sm ${i === active ? "bg-orange-50 dark:bg-zinc-800" : ""}`}
                    >
                      {o.kind === "store" && o.logoUrl ? (
                        <StoreLogo name={o.label} logoUrl={o.logoUrl} className="size-6" />
                      ) : o.kind === "brand" && o.logoUrl ? (
                        <BrandLogo name={o.label} logoUrl={o.logoUrl} className="size-6" />
                      ) : (
                        <Icon
                          name={o.icon}
                          className="size-4 shrink-0 text-zinc-500 dark:text-zinc-400"
                        />
                      )}
                      <span className="min-w-0 flex-1">
                        {o.kind === "keyword" ? (
                          <>
                            Any deal with{" "}
                            <b className="break-words">
                              &ldquo;{o.label}&rdquo;
                            </b>
                          </>
                        ) : (
                          <span className="font-medium">{o.label}</span>
                        )}
                        <span className="block truncate text-xs text-zinc-500 dark:text-zinc-400">
                          {o.hint}
                        </span>
                      </span>
                      <span className="shrink-0 text-xs font-semibold text-orange-700 dark:text-orange-400">
                        Add
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
          {error && (
            <p role="alert" className="text-sm text-red-600 dark:text-red-400">
              {error}
            </p>
          )}
        </div>
      </AccountSection>

      <AccountSection
        icon="target"
        title="Your alerts"
        description="When a new deal matches, it appears in your notifications."
        aside={
          total > 0 && (
            <span className="rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-semibold tabular-nums text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">
              {total}
            </span>
          )
        }
      >
        {total === 0 ? (
          <EmptyState icon="target">
            <p>No alerts yet.</p>
            <p>
              Add one above, or tap Get alerts on any store, category or product
              page.
            </p>
            {suggestions.length > 0 && (
              <div className="mt-3 flex flex-col items-center gap-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-zinc-500">
                  Popular right now
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  {suggestions.map((x) => (
                    <button
                      key={`${x.kind}:${x.id}`}
                      type="button"
                      onClick={() => (x.kind === "tag" ? setTag(x.id, true) : setStore(x.id, true))}
                      className="flex min-h-9 items-center gap-1.5 rounded-full border border-zinc-300 bg-white px-3 text-sm font-medium text-zinc-700 hover:border-orange-400 hover:text-orange-700 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200"
                    >
                      <Icon name="plus" className="size-3.5 text-orange-700 dark:text-orange-400" />
                      {x.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </EmptyState>
        ) : (
          <div className="-my-1 flex flex-col gap-5">
            {mineStores.length > 0 && (
              <AlertGroup id="shops" title="Stores" count={mineStores.length}>
                {mineStores.map((s) => {
                  const hearts = minHearts[`store:${s.key}`] ?? 0;
                  return (
                    <AlertItem
                      key={`s:${s.key}`}
                      icon="store"
                      logo={s.logoUrl && <StoreLogo name={s.name} logoUrl={s.logoUrl} className="size-10 rounded-xl border border-zinc-100 p-1 dark:border-zinc-800" />}
                      title={s.name}
                      href={`/stores/${s.slug}`}
                      line={[
                        whenShort(hearts),
                        weekNote(storeNewThisWeek[s.key]),
                      ].join(" · ")}
                      summary={
                        <>
                          New deals at {s.name}, {whenText(hearts)}.
                        </>
                      }
                      hearts={hearts}
                      onHearts={(v) => setThreshold("store", s.key, v)}
                      onRemove={() => setStore(s.key, false)}
                    />
                  );
                })}
              </AlertGroup>
            )}
            {mineBrands.length > 0 && (
              <AlertGroup id="brands" title="Brands" count={mineBrands.length}>
                {mineBrands.map((b) => {
                  const hearts = minHearts[`brand:${b.slug}`] ?? 0;
                  return (
                    <AlertItem
                      key={`b:${b.slug}`}
                      icon="badge-check"
                      logo={b.logoUrl && <BrandLogo name={b.name} logoUrl={b.logoUrl} className="size-10" />}
                      title={b.name}
                      href={`/brands/${b.slug}`}
                      line={[
                        whenShort(hearts),
                        weekNote(brandNewThisWeek[b.slug]),
                      ].join(" · ")}
                      summary={
                        <>
                          New {b.name} deals from any store, {whenText(hearts)}.
                        </>
                      }
                      hearts={hearts}
                      onHearts={(v) => setThreshold("brand", b.slug, v)}
                      onRemove={() => setBrand(b.slug, false)}
                    />
                  );
                })}
              </AlertGroup>
            )}
            {mineCategories.length > 0 && (
              <AlertGroup
                id="categories"
                title="Categories"
                count={mineCategories.length}
              >
                {mineCategories.map((c) => {
                  const hearts = minHearts[`category:${c.slug}`] ?? 25;
                  return (
                    <AlertItem
                      key={`c:${c.slug}`}
                      icon={c.icon}
                      title={c.name}
                      href={`/categories/${c.slug}`}
                      line={[
                        whenShort(hearts),
                        weekNote(categoryNewThisWeek[c.slug]),
                      ].join(" · ")}
                      summary={
                        <>
                          New deals in {c.name}, from any store,{" "}
                          {whenText(hearts)}.
                        </>
                      }
                      hearts={hearts}
                      onHearts={(v) => setThreshold("category", c.slug, v)}
                      onRemove={() => setCategory(c.slug, false)}
                    />
                  );
                })}
              </AlertGroup>
            )}
            {mineTags.length > 0 && (
              <AlertGroup id="tags" title="Tags" count={mineTags.length}>
                {mineTags.map((t) => {
                  const hearts = minHearts[`tag:${t.slug}`] ?? 0;
                  return (
                    <AlertItem
                      key={`t:${t.slug}`}
                      icon={t.icon}
                      title={t.name}
                      href={`/tags/${t.slug}`}
                      line={[
                        whenShort(hearts),
                        weekNote(newThisWeek[t.slug]),
                      ].join(" · ")}
                      summary={
                        <>
                          New {t.name} deals from any store, {whenText(hearts)}.
                        </>
                      }
                      hearts={hearts}
                      onHearts={(v) => setThreshold("tag", t.slug, v)}
                      onRemove={() => setTag(t.slug, false)}
                    />
                  );
                })}
              </AlertGroup>
            )}
            {keywords.length > 0 && (
              <AlertGroup id="words" title="Words" count={keywords.length}>
                {keywords.map((k) => {
                  const info = infos[k.id];
                  const hearts = minHearts[`keyword:${k.id}`] ?? 0;
                  return (
                    <AlertItem
                      key={k.id}
                      icon="search"
                      title={`“${k.keyword}”`}
                      line={[
                        k.maxPrice !== undefined
                          ? alertPriceText(k.maxPrice).replace(/^up/, "Up")
                          : "Any price",
                        whenShort(hearts),
                      ].join(" · ")}
                      summary={
                        <KeywordSummary
                          keyword={k.keyword}
                          hearts={hearts}
                          maxPrice={k.maxPrice}
                        />
                      }
                      hearts={hearts}
                      onHearts={(v) => setThreshold("keyword", k.id, v)}
                      onRemove={() => removeKeyword(k.id)}
                      price={
                        <PriceLimit
                          key={`${k.id}:${k.maxPrice}`}
                          label={k.keyword}
                          value={k.maxPrice}
                          onChange={(v) => setPrice(k.id, v)}
                        />
                      }
                      footer={info && <Matching info={info} />}
                    />
                  );
                })}
              </AlertGroup>
            )}
          </div>
        )}
      </AccountSection>
    </>
  );
}

// One kind of alert under its own small heading. The id lets a link such as
// /alerts#shops open the page at that group.
function AlertGroup({
  id,
  title,
  count,
  children,
}: {
  id: string;
  title: string;
  count: number;
  children: React.ReactNode;
}) {
  return (
    <section id={id} aria-labelledby={`${id}-title`} className="scroll-mt-20">
      <h3
        id={`${id}-title`}
        className="mb-1 text-xs font-semibold uppercase tracking-wide text-zinc-500"
      >
        {title}{" "}
        <span className="font-medium tabular-nums text-zinc-500 dark:text-zinc-400">
          · {count}
        </span>
      </h3>
      <ul className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
        {children}
      </ul>
    </section>
  );
}

const whenShort = (hearts: number) =>
  hearts > 0 ? `At ${hearts}+ hearts` : "Straight away";
const whenText = (hearts: number) =>
  hearts > 0 ? `once they have ${hearts} hearts` : "as soon as they're posted";
const weekNote = (n = 0) => (n > 0 ? `${n} new this week` : "None this week");

// One alert, as one short line (what it's for, and its settings in a few
// words), so a long list stays easy to scan. "Edit" opens its settings, the
// sentence saying exactly what it does, and Remove.
function AlertItem({
  icon,
  logo,
  title,
  href,
  line,
  summary,
  hearts,
  onHearts,
  onRemove,
  price,
  footer,
}: {
  icon: IconName;
  // A store's or brand's logo, in place of the icon, when it has one.
  logo?: React.ReactNode;
  title: string;
  href?: string;
  line: string;
  summary: React.ReactNode;
  hearts: number;
  onHearts: (value: number) => void;
  onRemove: () => void;
  price?: React.ReactNode;
  footer?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <li className="flex flex-col gap-2.5 py-2.5">
      <div className="flex items-center gap-3">
        {logo || <RowIcon icon={icon} />}
        <div className="min-w-0 flex-1">
          {href ? (
            <Link
              href={href}
              className="block truncate font-semibold hover:text-orange-600"
            >
              {title}
            </Link>
          ) : (
            <p className="truncate font-semibold">{title}</p>
          )}
          <p className="line-clamp-2 text-sm text-zinc-500">{line}</p>
        </div>
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          aria-label={`${open ? "Close" : "Edit"} the alert for ${title}`}
          className="flex size-9 shrink-0 items-center justify-center gap-1 rounded-full text-sm font-medium text-zinc-600 transition-colors hover:bg-zinc-100 sm:w-auto sm:px-3 dark:text-zinc-300 dark:hover:bg-zinc-800"
        >
          <span className="hidden sm:inline">
            <StableLabel options={words("Edit", "Done")} show={open ? "Done" : "Edit"} />
          </span>
          <Icon
            name="chevron-down"
            className={`size-4 transition-transform ${open ? "rotate-180" : ""}`}
          />
        </button>
      </div>
      {open && (
        <div className="flex flex-col gap-3 rounded-xl bg-zinc-50 p-3 sm:ml-[52px] dark:bg-zinc-800/50">
          <p className="text-sm leading-snug text-zinc-600 dark:text-zinc-300">
            {summary}
          </p>
          <div className="flex flex-wrap items-end gap-x-3 gap-y-3">
            <Labelled label="When to tell you">
              <SelectField
                look="tile"
                label={`When to tell you about ${title} deals`}
                value={String(hearts)}
                onChange={(v) => onHearts(Number(v))}
                options={ALERT_HEART_CHOICES.map((c) => ({
                  value: String(c.hearts),
                  label: c.label[0].toUpperCase() + c.label.slice(1),
                }))}
              />
            </Labelled>
            {price}
            <button
              type="button"
              onClick={onRemove}
              className="ml-auto flex h-10 items-center gap-1.5 rounded-full px-3 text-sm font-medium text-red-600 transition-colors hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30"
            >
              <Icon name="trash" className="size-4" />
              Remove
            </button>
          </div>
          {footer}
        </div>
      )}
    </li>
  );
}

function Labelled({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-xs font-medium text-zinc-500">{label}</span>
      {children}
    </div>
  );
}

// "2 deals match now", opening to show the latest of them.
function Matching({ info }: { info: KeywordMatchInfo }) {
  if (info.total === 0)
    return (
      <p className="text-xs text-zinc-500">
        No deals match yet. You&apos;ll be told when one does.
      </p>
    );
  return (
    <details className="group text-sm">
      <summary className="w-fit cursor-pointer list-none font-medium text-orange-700 dark:text-orange-400 [&::-webkit-details-marker]:hidden">
        <span className="hover:underline">
          {info.total} {info.total === 1 ? "deal matches" : "deals match"} now
        </span>
        {info.newThisWeek > 0 && (
          <span className="font-normal text-zinc-500">
            {" "}
            · {info.newThisWeek} new this week
          </span>
        )}
        <Icon
          name="chevron-down"
          className="ml-1 inline size-4 align-[-3px] transition-transform group-open:rotate-180"
        />
      </summary>
      <ul className="mt-2 flex flex-col gap-1.5">
        {info.latest.map((d) => (
          <li key={d.slug} className="truncate">
            <Link
              href={`/deals/${d.slug}`}
              className="text-zinc-600 hover:text-orange-600 hover:underline dark:text-zinc-300"
            >
              {d.title}
            </Link>
          </li>
        ))}
      </ul>
    </details>
  );
}

// "Price limit" for your own words: only deals with one price at or under
// it. Empty is all prices.
function PriceLimit({
  label,
  value,
  onChange,
}: {
  label: string;
  value?: number;
  onChange: (value: number | null) => void;
}) {
  const shown =
    value === undefined
      ? ""
      : Number.isInteger(value)
        ? String(value)
        : value.toFixed(2);
  const [text, setText] = useState(shown);
  function save() {
    const typed = text.replace(/[£,\s]/g, "");
    if (!typed) {
      if (value !== undefined) onChange(null);
      return;
    }
    const price = Number(typed);
    if (!Number.isFinite(price) || price < 1 || price > MAX_ALERT_PRICE) {
      setText(shown);
      return;
    }
    if (price !== value) onChange(price);
  }
  return (
    <Labelled label="Price limit (blank for any)">
      <span className="relative">
        {/* (The £ only once there's a price: empty, the box says "All prices".) */}
        {text && (
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-zinc-500 dark:text-zinc-400">
            £
          </span>
        )}
        <input
          inputMode="decimal"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onBlur={save}
          onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()}
          placeholder="All prices"
          aria-label={`Highest price for ${label} deals (leave blank for all prices)`}
          className={`h-10 w-32 rounded-lg border border-zinc-300 bg-zinc-50 pr-3 text-base text-zinc-800 placeholder:text-zinc-400 focus:border-orange-500 focus:outline-none lg:text-sm dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100 ${
            text ? "pl-7" : "pl-3"
          }`}
        />
      </span>
    </Labelled>
  );
}

// What a word alert will tell you about, in a sentence, so its settings
// (the words, a price limit, when to tell you) read as one rule.
function KeywordSummary({
  keyword,
  hearts,
  maxPrice,
}: {
  keyword: string;
  hearts: number;
  maxPrice?: number;
}) {
  return (
    <>
      New deals from any store with all of the words &ldquo;{keyword}&rdquo; in
      their title, store or category
      {maxPrice !== undefined ? (
        <>
          , priced at{" "}
          <span className="font-semibold text-zinc-900 dark:text-zinc-100">
            {alertPriceText(maxPrice).replace(/^up to /, "")} or less
          </span>
        </>
      ) : (
        ", at any price"
      )}
      , {whenText(hearts)}.
      {maxPrice !== undefined &&
        " Monthly plans and “from” prices don’t count."}
    </>
  );
}
