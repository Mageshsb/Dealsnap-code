import Link from "next/link";
import Icon from "./Icon";
import { CTA_LOOK, PromoPicture, PromotedTag, type PromoLook } from "./PromoCard";

// A promo card or sign-up tile as a card in the Cards view. Same shape as a
// deal's card (SwipeCard): a picture frame that takes whatever height is left,
// capped at the same 16:10, with the text below at a set length. The picture
// slot is always there, an icon tile when there's no picture. A promo is one tap
// target; a sign-up tile has its own button and a Log in link. `preview` is the
// admin's look at it, with nothing to click.
export default function PromoSwipeCard({ promo, preview = false }: { promo: PromoLook; preview?: boolean }) {
  const { variant, kicker, headline, body, benefits, ctaLabel, linkUrl, showTag } = promo;
  const signup = variant === "signup";
  const className =
    "@container flex h-full w-full select-none flex-col overflow-hidden rounded-3xl border border-orange-300 bg-orange-50 shadow-2xl dark:border-orange-900/60 dark:bg-orange-950/20";
  const inner = (
    <>
      <div className="relative min-h-0 w-full flex-[1000_1_0%] max-h-[62.5cqw] bg-orange-100 dark:bg-orange-950/50">
        <PromoPicture promo={promo} iconSize="size-24" />
      </div>
      <div className="flex min-h-0 flex-1 flex-col gap-1.5 p-4">
        {showTag && <PromotedTag />}
        {kicker && <span className="truncate text-xs font-medium text-zinc-500 dark:text-zinc-400">{kicker}</span>}
        <span className="line-clamp-2 text-lg font-bold leading-snug">{headline}</span>
        {signup ? (
          <ul className="flex flex-col gap-1">
            {benefits.slice(0, 3).map((b, i) => (
              <li key={i} className="flex items-start gap-2 text-sm leading-snug text-zinc-700 dark:text-zinc-300">
                <Icon name="check" className="mt-0.5 size-4 shrink-0 text-orange-700 dark:text-orange-400" />
                <span className="line-clamp-1">{b}</span>
              </li>
            ))}
          </ul>
        ) : (
          body && <span className="line-clamp-2 text-sm leading-snug text-zinc-600 dark:text-zinc-400">{body}</span>
        )}
        <span className="mt-auto flex items-center justify-end gap-4 pt-1">
          {signup && !preview && (
            <Link href="/login" className="text-sm font-medium text-zinc-600 hover:underline dark:text-zinc-400">
              Log in
            </Link>
          )}
          {signup && preview && <span className="text-sm font-medium text-zinc-600 dark:text-zinc-400">Log in</span>}
          {signup && !preview ? (
            <Link href={linkUrl} className={CTA_LOOK}>
              {ctaLabel}
            </Link>
          ) : (
            <span className={CTA_LOOK}>{ctaLabel}</span>
          )}
        </span>
      </div>
    </>
  );

  if (signup || preview) return <div className={className}>{inner}</div>;
  if (linkUrl.startsWith("/")) {
    return (
      <Link href={linkUrl} className={className}>
        {inner}
      </Link>
    );
  }
  return (
    <a href={linkUrl} target="_blank" rel="sponsored noopener nofollow" className={className}>
      {inner}
    </a>
  );
}
