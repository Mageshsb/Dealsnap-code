import { HERO_NAME, HERO_TAGLINE } from "@/lib/hero";
import Icon from "./Icon";

// Overlay strip along the bottom of a Hero deal's image. It sits ON the image
// (absolutely positioned) so a Hero tile is exactly the same size as any other.
export default function HeroRibbon({ className = "" }: { className?: string }) {
  return (
    <div
      className={`hero-shine pointer-events-none absolute inset-x-0 bottom-0 flex flex-col items-center overflow-hidden bg-gradient-to-r from-violet-800 via-fuchsia-600 to-violet-800 px-1 py-1 text-center leading-tight text-amber-200 ${className}`}
    >
      <span className="flex items-center gap-1 text-[10px] font-extrabold uppercase tracking-wider sm:text-[11px]">
        <span className="hero-sparkle">
          <Icon name="crown" filled className="size-3 text-amber-300" />
        </span>
        {HERO_NAME}
      </span>
      <span className="text-[9px] font-semibold text-white/90 sm:text-[10px]">{HERO_TAGLINE}</span>
    </div>
  );
}
