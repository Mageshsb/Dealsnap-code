import type { ComponentProps } from "react";

// A number box with its unit inside it ("£ 219.00", "70 %"), so the label
// above can stay short. Takes the same props as an <input>.
export default function AmountInput({
  unit,
  unitAfter = false,
  className = "",
  ...props
}: { unit: string; unitAfter?: boolean } & ComponentProps<"input">) {
  return (
    <div className="relative min-w-0">
      <span
        aria-hidden
        className={`pointer-events-none absolute inset-y-0 flex items-center text-base text-zinc-500 dark:text-zinc-400 lg:text-sm ${unitAfter ? "right-3" : "left-3"}`}
      >
        {unit}
      </span>
      <input
        type="number"
        inputMode="decimal"
        {...props}
        // No up/down arrows: nobody steps a price a penny at a time.
        className={`w-full [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none ${unitAfter ? "pr-8" : "pl-7"} ${className}`}
      />
    </div>
  );
}
