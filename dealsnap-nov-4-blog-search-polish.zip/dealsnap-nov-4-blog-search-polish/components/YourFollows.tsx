import type { ReactNode } from "react";
import Link from "next/link";
import Icon from "./Icon";

export type FollowedItem = {
  key: string;
  name: string;
  href: string;
  // The logo or icon tile at the left.
  leading: ReactNode;
  liveCount: number;
  newCount: number;
};

// What someone has the bell on for, as one scrolling row at the top of a
// browsing page ("Your shops" on /stores, "Your categories" on /categories), so
// both look the same. Ones with something new come first. Manage them (turn one
// off, change how you're told) on the Alerts page.
export default function YourFollows({ id, title, manageHref, items }: { id: string; title: string; manageHref: string; items: FollowedItem[] }) {
  if (!items.length) return null;
  return (
    <section aria-labelledby={id} className="flex flex-col gap-2">
      <div className="flex items-center justify-between gap-3">
        <h2 id={id} className="flex items-center gap-1.5 text-base font-bold">
          <Icon name="bell" className="size-4 text-orange-700 dark:text-orange-400" />
          {title}
        </h2>
        <Link href={manageHref} className="text-sm font-medium text-orange-700 hover:underline dark:text-orange-400">
          Manage
        </Link>
      </div>
      <ul className="-mx-4 flex snap-x gap-2 overflow-x-auto px-4 pb-1 [scroll-padding-left:1rem] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {items.map((s) => (
          <li key={s.key} className="snap-start">
            <Link
              href={s.href}
              className="flex w-44 items-center gap-2.5 rounded-xl border border-zinc-200 bg-white px-2.5 py-2 shadow-sm transition hover:border-orange-300 hover:shadow-md dark:border-zinc-800 dark:bg-zinc-900 dark:hover:border-orange-900"
            >
              {s.leading}
              <span className="flex min-w-0 flex-col">
                <span className="truncate text-sm font-semibold">{s.name}</span>
                {s.newCount > 0 ? (
                  <span className="truncate text-xs font-semibold text-orange-700 dark:text-orange-400">{s.newCount} new this week</span>
                ) : (
                  <span className="truncate text-xs text-zinc-500">{s.liveCount > 0 ? `${s.liveCount} live deal${s.liveCount === 1 ? "" : "s"}` : "No live deals"}</span>
                )}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
