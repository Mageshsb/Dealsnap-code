import MenuSelect, { type MenuOption } from "./MenuSelect";
import Icon, { type IconName } from "./Icon";

// The looks a dropdown comes in, so each matches what sits around it:
// - "field": a form box, like the text boxes beside it (white on admin pages);
// - "tile": the grey rounded tile used for small choices inside a sentence
//   ("Send emails as things happen ⌄").
const LOOKS = {
  field:
    "flex min-h-11 w-full min-w-0 items-center gap-2 rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus-visible:border-orange-500 data-invalid:border-red-400 disabled:cursor-not-allowed disabled:opacity-60 sm:min-h-10 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950 dark:data-invalid:border-red-500",
  admin:
    "flex min-h-11 w-full min-w-0 items-center gap-2 rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus-visible:border-orange-500 data-invalid:border-red-400 disabled:cursor-not-allowed disabled:opacity-60 sm:min-h-10 lg:text-sm dark:border-zinc-700 dark:bg-zinc-900 dark:data-invalid:border-red-500",
  tile:
    "flex min-h-9 items-center gap-1.5 rounded-xl bg-zinc-100 py-1.5 pl-3 pr-2.5 text-base font-medium text-zinc-700 outline-none transition-colors hover:bg-zinc-200 focus-visible:ring-2 focus-visible:ring-orange-500 aria-expanded:bg-zinc-200 sm:text-sm dark:bg-zinc-800 dark:text-zinc-200 dark:hover:bg-zinc-700 dark:aria-expanded:bg-zinc-700",
} as const;

// A dropdown in a form: the site's own menu (see MenuSelect) in place of the
// browser's <select>, sending its choice under `name`. Works on server pages
// with just `defaultValue`, or controlled with `value` and `onChange`.
export default function SelectField({
  look = "field",
  label,
  className = "",
  leadingIcon,
  ...rest
}: {
  look?: keyof typeof LOOKS;
  // A grey icon before the choice, like the ⇅ on a sort menu.
  leadingIcon?: IconName;
  // What it's for, read out by screen readers and shown atop the menu.
  label: string;
  options: MenuOption[];
  name?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  required?: boolean;
  disabled?: boolean;
  placeholder?: string;
  id?: string;
  className?: string;
  align?: "left" | "right";
}) {
  return (
    <MenuSelect
      {...rest}
      label={label}
      leading={leadingIcon && <Icon name={leadingIcon} className="size-3.5 shrink-0 text-zinc-500 dark:text-zinc-400" />}
      className={`min-w-0 ${className}`}
      buttonClassName={LOOKS[look]}
      chevronClassName={look === "tile" ? "size-3.5 text-zinc-500 dark:text-zinc-400" : "size-4 text-zinc-500"}
    />
  );
}
