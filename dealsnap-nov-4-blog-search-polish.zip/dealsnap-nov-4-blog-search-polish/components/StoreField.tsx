"use client";

import { useState } from "react";
import StoreCombobox from "./StoreCombobox";

// StoreCombobox for forms that don't hold the value in their own state (the
// admin edit page, a server component).
export default function StoreField({
  name,
  defaultValue,
  options,
  variants,
}: {
  name: string;
  defaultValue: string;
  options: string[];
  variants?: Record<string, string>;
}) {
  const [value, setValue] = useState(defaultValue);
  return <StoreCombobox name={name} value={value} onChange={setValue} options={options} variants={variants} />;
}
