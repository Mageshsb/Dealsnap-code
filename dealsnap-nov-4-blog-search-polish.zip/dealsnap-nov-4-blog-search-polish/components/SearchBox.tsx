import Link from "next/link";
import Icon from "./Icon";

// The one look for every search box on the public site (the one in the header,
// the store, brand and category searches, Alerts, Community, the Blog…): a
// grey-filled pill, no icon, orange when picked, and the grey round clear
// button on its right. Admin has its own matching look (`searchField` in
// components/admin/formStyles.ts). Add new search boxes with these, not copies.
export const searchBox =
  "w-full min-w-0 rounded-full border border-zinc-300 bg-zinc-50 py-2 pl-4 pr-10 text-base outline-none focus:border-orange-500 dark:border-zinc-700 dark:bg-zinc-900 lg:text-sm [&::-webkit-search-cancel-button]:appearance-none";

const clearButton =
  "absolute right-1 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full text-sm text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200";

const circle = (
  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-zinc-300 text-white dark:bg-zinc-600">
    <Icon name="x" strokeWidth={3} className="size-3" />
  </span>
);

// The clear button: a button where the box is live (it empties it), a link
// where the box is a plain form (it goes to the page without the search).
export function ClearSearch({ onClick, href }: { onClick?: () => void; href?: string }) {
  if (href !== undefined) {
    return (
      <Link href={href} aria-label="Clear search text" className={clearButton}>
        {circle}
      </Link>
    );
  }
  return (
    <button type="button" onClick={onClick} aria-label="Clear search text" className={clearButton}>
      {circle}
    </button>
  );
}
