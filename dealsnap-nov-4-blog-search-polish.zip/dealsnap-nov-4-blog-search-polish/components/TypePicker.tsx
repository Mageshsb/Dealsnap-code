"use client";

import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from "react";
import { createPortal } from "react-dom";
import type { CategoryGroup, TagInfo } from "@/lib/taxonomy-shared";
import { WHOLE_CATEGORY_PREFIX } from "@/lib/deal-kinds";
import { guessTagAction } from "@/lib/actions";
import { useTaxonomy } from "./TaxonomyProvider";
import { useAnchoredMenu } from "./useAnchoredMenu";
import Icon from "./Icon";

// "What is it?" on the post form: one pick from every tag and sub-tag, found by
// typing ("mac" → MacBook) or by browsing the categories. The category comes
// with the choice, so there's no separate category box. The button shows the
// path ("Laptop › MacBook") so the poster sees where the deal will be filed.
//
// For a sale or voucher (`allowCategory`) each category also offers "All of
// Clothing & Accessories", for one that covers several of its types ("coats
// for men, women and kids"). That's sent as "category:<name>" (lib/deal-kinds.ts).
type Row = { cat: CategoryGroup; t?: undefined } | { t: TagInfo; cat?: undefined };
export default function TypePicker({
  id,
  name,
  value,
  onChange,
  required,
  label = "What is it?",
  allowCategory = false,
}: {
  id?: string;
  name: string;
  value: string;
  onChange: (tag: string) => void;
  required?: boolean;
  // The question beside it, read out with what's chosen.
  label?: string;
  allowCategory?: boolean;
}) {
  const { allTags, getTagByName, getCategoryByName } = useTaxonomy();
  const [query, setQuery] = useState("");
  const [invalid, setInvalid] = useState(false);
  const { open, toggle, close, anchorRef, host, menuProps } = useAnchoredMenu<HTMLButtonElement>("left", () => setQuery(""));
  const searchRef = useRef<HTMLInputElement>(null);
  const wholeCategory = allowCategory && value.startsWith(WHOLE_CATEGORY_PREFIX) ? getCategoryByName(value.slice(WHOLE_CATEGORY_PREFIX.length)) : undefined;
  const current = value && !wholeCategory ? getTagByName(value) : undefined;
  const sent = wholeCategory ? `${WHOLE_CATEGORY_PREFIX}${wholeCategory.name}` : (current?.tag.name ?? "");

  // What the typed words most likely mean, from the word lists autofill uses
  // ("air fryer" → Small Appliances), asked of the server a moment after they
  // stop typing. Added to the list as a suggestion when the names alone don't
  // already show it.
  const [guess, setGuess] = useState<{ query: string; tag: string } | null>(null);
  useEffect(() => {
    const q = query.trim();
    if (q.length < 3) return;
    let current = true;
    const timer = setTimeout(async () => {
      const found = await guessTagAction(q).catch(() => null);
      if (current && found) setGuess({ query: q, tag: found.tag });
    }, 250);
    return () => {
      current = false;
      clearTimeout(timer);
    };
  }, [query]);
  const guessed = guess && guess.query === query.trim() ? getTagByName(guess.tag) : undefined;

  // Searching: every tag or sub-tag whose name, or its parent's or category's,
  // has the words in it, closest first (a category's "All of" first among
  // equals). Browsing: the whole tree in order, each category's "All of" first.
  const shown = useMemo<Row[]>(() => {
    const tags = allTags();
    const cats = allowCategory ? [...new Map(tags.map((t) => [t.category.name, t.category])).values()] : [];
    const q = query.trim().toLowerCase();
    if (!q) {
      return tags.flatMap((t, i): Row[] => (allowCategory && t.category.name !== tags[i - 1]?.category.name ? [{ cat: t.category }, { t }] : [{ t }]));
    }
    const singular = q.length < 3 ? q : q.replace(/(ies)$/, "y").replace(/s$/, "");
    const near = (name: string) => (name.startsWith(q) || name.startsWith(singular) ? 0 : name.includes(q) || name.includes(singular) ? 1 : -1);
    const score = (t: TagInfo) => {
      const own = near(t.tag.name.toLowerCase());
      if (own >= 0) return own;
      const around = `${t.parent?.name ?? ""} ${t.category.name}`.toLowerCase();
      return around.includes(q) || around.includes(singular) ? 2 : -1;
    };
    const found = [
      ...cats.map((cat) => ({ row: { cat } as Row, s: near(cat.name.toLowerCase()) })),
      ...tags.map((t) => ({ row: { t } as Row, s: score(t) })),
    ]
      .filter((x) => x.s >= 0)
      .sort((a, b) => a.s - b.s)
      .map((x) => x.row);
    // The word-list guess leads the list, unless names already found it.
    return guessed && !found.some((r) => r.t?.tag.name === guessed.tag.name) ? [{ t: guessed } as Row, ...found] : found;
  }, [query, allTags, allowCategory, guessed]);
  const rowValue = (r: Row) => (r.cat ? `${WHOLE_CATEGORY_PREFIX}${r.cat.name}` : r.t!.tag.name);

  function pick(tag: string) {
    onChange(tag);
    setInvalid(false);
    close();
    anchorRef.current?.focus();
  }

  function onListKey(e: KeyboardEvent<HTMLDivElement>) {
    const items = Array.from(e.currentTarget.querySelectorAll<HTMLElement>('[role="option"]'));
    const at = items.indexOf(document.activeElement as HTMLElement);
    if (e.key === "ArrowDown") items[Math.min(items.length - 1, at + 1)]?.focus();
    else if (e.key === "ArrowUp") (at <= 0 ? searchRef.current : items[at - 1])?.focus();
    else return;
    e.preventDefault();
  }

  const searching = query.trim().length > 0;
  return (
    <div className="relative min-w-0">
      <button
        ref={anchorRef}
        id={id}
        type="button"
        onClick={() => {
          toggle();
          // Straight into the search box on a computer; on a phone the list
          // shows first, so the keyboard doesn't cover it.
          if (!open && window.matchMedia("(pointer: fine)").matches) setTimeout(() => searchRef.current?.focus(), 0);
        }}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={`${label}: ${wholeCategory ? `All of ${wholeCategory.name}` : current ? current.tag.name : "not chosen"}`}
        data-invalid={invalid || undefined}
        className="flex min-h-11 w-full min-w-0 items-center gap-2 rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus-visible:border-orange-500 data-invalid:border-red-400 sm:min-h-10 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950 dark:data-invalid:border-red-500"
      >
        {wholeCategory ? (
          <>
            <Icon name={wholeCategory.icon} className="size-4 shrink-0 text-zinc-500 dark:text-zinc-400" />
            <span className="min-w-0 flex-1 truncate text-left">
              <span className="text-zinc-500">All of </span>
              <span className="font-medium">{wholeCategory.name}</span>
            </span>
          </>
        ) : current ? (
          <>
            <Icon name={current.tag.icon} className="size-4 shrink-0 text-zinc-500 dark:text-zinc-400" />
            <span className="min-w-0 flex-1 truncate text-left">
              <span className="text-zinc-500">{current.parent ? `${current.parent.name} › ` : `${current.category.name} › `}</span>
              <span className="font-medium">{current.tag.name}</span>
            </span>
          </>
        ) : (
          <span className="min-w-0 flex-1 truncate text-left text-zinc-500 dark:text-zinc-400">Choose what it is…</span>
        )}
        <Icon name="chevron-down" className={`size-4 shrink-0 text-zinc-500 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {/* What the form sends; a real (invisible) field when required, so the
          browser's "please choose" message appears under the button. */}
      <input
        tabIndex={-1}
        aria-hidden
        name={name}
        value={sent}
        required={required}
        onChange={() => {}}
        onInvalid={() => setInvalid(true)}
        onFocus={() => anchorRef.current?.focus()}
        className="pointer-events-none absolute bottom-0 left-4 h-px w-px opacity-0"
      />

      {open &&
        host &&
        createPortal(
          <div
            {...menuProps}
            className={`${menuProps.className} flex w-[22rem] flex-col rounded-xl border border-zinc-200 bg-white text-zinc-900 shadow-lg dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100`}
          >
            <div className="sticky top-0 z-10 border-b border-zinc-100 bg-white p-2 dark:border-zinc-800 dark:bg-zinc-900">
              <div className="flex items-center gap-2 rounded-lg bg-zinc-100 px-2.5 dark:bg-zinc-800">
                <Icon name="search" className="size-4 shrink-0 text-zinc-500 dark:text-zinc-400" />
                <input
                  ref={searchRef}
                  value={query}
                  onChange={(e) => setQuery(e.target.value.slice(0, 40))}
                  onKeyDown={(e) => {
                    if (e.key === "ArrowDown") {
                      e.preventDefault();
                      menuProps.ref.current?.querySelector<HTMLElement>('[role="option"]')?.focus();
                    } else if (e.key === "Enter") {
                      e.preventDefault();
                      if (searching && shown[0]) pick(rowValue(shown[0]));
                    }
                  }}
                  placeholder="Search, e.g. laptop or footwear"
                  aria-label="Search what it is"
                  className="h-9 min-w-0 flex-1 bg-transparent text-base outline-none sm:text-sm"
                />
              </div>
            </div>
            <div role="listbox" aria-label="What is it?" onKeyDown={onListKey} className="flex flex-col p-1">
              {shown.length === 0 && <p className="px-3 py-3 text-sm text-zinc-500">Nothing matches. Try a broader word, like &quot;phone&quot;.</p>}
              {shown.map((row, i) => {
                const prev = shown[i - 1];
                const groupName = row.cat?.name ?? row.t!.category.name;
                const newGroup = !searching && groupName !== (prev?.cat?.name ?? prev?.t?.category.name);
                const selected = rowValue(row) === sent;
                const t = row.t;
                return (
                  <div key={rowValue(row)} className="contents">
                    {newGroup && (
                      <p className="flex items-center gap-1.5 px-3 pb-1 pt-3 text-xs font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400">
                        <Icon name={(row.cat ?? row.t!.category).icon} className="size-3.5" />
                        {groupName}
                      </p>
                    )}
                    <button
                      type="button"
                      role="option"
                      aria-selected={selected}
                      onClick={() => pick(rowValue(row))}
                      className={`flex min-h-10 shrink-0 items-center gap-2.5 rounded-lg px-3 py-1.5 text-left text-sm outline-none ${
                        !searching && t?.parent ? "pl-9" : ""
                      } ${
                        selected
                          ? "bg-orange-50 font-medium text-orange-700 dark:bg-orange-950/40 dark:text-orange-400"
                          : "text-zinc-700 hover:bg-zinc-100 focus:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800 dark:focus:bg-zinc-800"
                      }`}
                    >
                      <Icon name={row.cat ? row.cat.icon : t!.tag.icon} className={`size-[18px] shrink-0 ${selected ? "" : "text-zinc-500 dark:text-zinc-400"}`} />
                      <span className="flex min-w-0 flex-1 flex-col">
                        <span className="truncate">{row.cat ? `All of ${row.cat.name}` : t!.tag.name}</span>
                        {searching && t && (
                          <span className="truncate text-xs text-zinc-500 dark:text-zinc-400">
                            {t.category.name}
                            {t.parent && ` › ${t.parent.name}`}
                          </span>
                        )}
                        {row.cat && <span className="truncate text-xs text-zinc-500 dark:text-zinc-400">Covers several of its types</span>}
                      </span>
                      {selected && <Icon name="check" className="size-4 shrink-0" />}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>,
          host
        )}
    </div>
  );
}
