"use client";

import { useState } from "react";
import { createPortal } from "react-dom";
import {
  reportProfileAction,
  withdrawProfileReportAction,
  blockUserAction,
  unblockUserAction,
} from "@/lib/member-actions";
import Icon from "./Icon";
import { useAnchoredMenu } from "./useAnchoredMenu";

const item =
  "flex w-full items-center gap-2 px-4 py-2 text-left text-sm text-zinc-700 hover:bg-zinc-50 dark:text-zinc-300 dark:hover:bg-zinc-800";

// The "..." menu on someone else's profile: report their profile, or block them.
export default function ProfileActionsMenu({
  targetUserId,
  username,
  reasons,
  alreadyReported,
  isBlocked,
  canBlock,
}: {
  targetUserId: string;
  username: string;
  reasons: readonly string[];
  alreadyReported: boolean;
  isBlocked: boolean;
  canBlock: boolean;
}) {
  const [reporting, setReporting] = useState(false);
  const [confirmingBlock, setConfirmingBlock] = useState(false);
  const { open, toggle, anchorRef, host, menuProps } = useAnchoredMenu<HTMLButtonElement>("right", () => {
    setReporting(false);
    setConfirmingBlock(false);
  });

  return (
    <>
      <button
        ref={anchorRef}
        type="button"
        onClick={toggle}
        aria-label="More options"
        aria-expanded={open}
        className="flex h-10 w-10 items-center justify-center rounded-full border border-zinc-300 text-zinc-500 hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"
      >
        <Icon name="ellipsis" className="size-5" />
      </button>
      {open &&
        host &&
        createPortal(
          <div
            {...menuProps}
            className={`${menuProps.className} w-64 rounded-xl border border-zinc-200 bg-white py-1 shadow-lg dark:border-zinc-800 dark:bg-zinc-900`}
          >
            {reporting ? (
              <form action={reportProfileAction.bind(null, targetUserId)} className="flex flex-col gap-2 p-3">
                <p className="text-sm font-semibold">What&apos;s wrong with this profile?</p>
                {/* Radio buttons, as in the staff "why?" dialogs, so every reason
                  shows at once inside this small menu. */}
                <fieldset className="flex flex-col">
                  <legend className="sr-only">Reason</legend>
                  {reasons.map((r, i) => (
                    <label
                      key={r}
                      className="flex min-h-9 items-center gap-2.5 rounded-lg px-1 text-sm hover:bg-zinc-50 dark:hover:bg-zinc-800"
                    >
                      <input
                        type="radio"
                        name="reason"
                        value={r}
                        required
                        defaultChecked={i === 0}
                        className="h-4 w-4 accent-orange-500"
                      />
                      {r}
                    </label>
                  ))}
                </fieldset>
                <p className="text-xs text-zinc-500">
                  Our team will take a look. {username} won&apos;t know who reported them.
                </p>
                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="rounded-full bg-red-600 px-3 py-1 text-sm font-semibold text-white hover:bg-red-700"
                  >
                    Send report
                  </button>
                  <button
                    type="button"
                    onClick={() => setReporting(false)}
                    className="rounded-full px-3 py-1 text-sm text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            ) : (
              <>
                {alreadyReported ? (
                  <form
                    action={withdrawProfileReportAction.bind(null, targetUserId)}
                    className="flex items-center gap-2 px-4 py-2 text-sm text-zinc-500 dark:text-zinc-400"
                  >
                    <Icon name="flag" className="size-4" />
                    Reported
                    <button type="submit" className="font-medium text-orange-700 hover:underline dark:text-orange-400">
                      Undo
                    </button>
                  </form>
                ) : (
                  <button type="button" onClick={() => setReporting(true)} className={item}>
                    <Icon name="flag" className="size-4 text-zinc-500 dark:text-zinc-400" />
                    Report profile
                  </button>
                )}
                {isBlocked ? (
                  <form action={unblockUserAction.bind(null, targetUserId)}>
                    <input type="hidden" name="back" value={`/u/${username}`} />
                    <button type="submit" className={item}>
                      <Icon name="circle-check" className="size-4 text-zinc-500 dark:text-zinc-400" />
                      Unblock {username}
                    </button>
                  </form>
                ) : (
                  canBlock &&
                  (confirmingBlock ? (
                    // Asked here in the menu, like "Yes, report · Cancel" on deals,
                    // rather than in the browser's own pop-up.
                    <form
                      action={blockUserAction.bind(null, targetUserId)}
                      className="flex flex-col gap-1.5 px-4 py-2 text-sm"
                    >
                      <input type="hidden" name="back" value={`/u/${username}`} />
                      <p className="font-semibold">Block {username}?</p>
                      <p className="text-xs text-zinc-500">
                        You won&apos;t see their deals or comments, and they won&apos;t be able to follow you.
                      </p>
                      <p className="flex items-center gap-3">
                        <button type="submit" className="font-medium text-red-600 hover:underline dark:text-red-400">
                          Yes, block
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmingBlock(false)}
                          className="text-zinc-500 hover:text-zinc-600 dark:text-zinc-500 dark:hover:text-zinc-300"
                        >
                          Cancel
                        </button>
                      </p>
                    </form>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmingBlock(true)}
                      className={`${item} text-red-600 dark:text-red-400`}
                    >
                      <Icon name="ban" className="size-4" />
                      Block {username}
                    </button>
                  ))
                )}
              </>
            )}
          </div>,
          host,
        )}
    </>
  );
}
