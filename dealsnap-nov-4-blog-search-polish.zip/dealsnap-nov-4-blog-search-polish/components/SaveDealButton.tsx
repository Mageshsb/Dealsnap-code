"use client";

import { useRef, useState, useTransition } from "react";
import { usePathname, useRouter } from "next/navigation";
import { setDealSavedAction } from "@/lib/member-actions";
import { useUserVotes } from "./UserVotesProvider";
import { BookmarkIcon } from "./icons";
import StableLabel, { words } from "./StableLabel";

const VARIANTS = {
  // List cards: a small round button after the hearts, matching their size
  // (the same order as the scroller: hearts, then save).
  icon:
    "h-8 w-8 rounded-full border border-zinc-200 text-zinc-500 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-400 dark:hover:bg-zinc-800",
  // Scroller: a round button beside the hearts, matching the heart buttons.
  round:
    "h-10 w-10 rounded-full border border-zinc-200 text-zinc-500 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-400 dark:hover:bg-zinc-800",
  // Deal page: a labelled button beside "Get deal".
  pill: "h-9 gap-1.5 rounded-full border border-zinc-300 px-4 text-sm font-semibold text-zinc-700 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800",
};

// "Save for later" bookmark. Shares its state through UserVotesProvider so
// every button for the same deal agrees. Kept off the photos and next to the
// other actions, in the style that fits each place it appears.
export default function SaveDealButton({
  dealSlug,
  variant = "icon",
  remind = false,
}: {
  dealSlug: string;
  variant?: keyof typeof VARIANTS;
  // An upcoming deal: saving it is how you're told when it starts, so it
  // says so ("Remind me" / "Reminder set").
  remind?: boolean;
}) {
  const { loggedIn, saved, setSaved } = useUserVotes();
  const on = !!saved[dealSlug];
  const [, startTransition] = useTransition();
  const router = useRouter();
  const pathname = usePathname();
  // Bumped on each save so the pop and the "Saved" label replay every time.
  const [pop, setPop] = useState(0);
  const popTimer = useRef<number | undefined>(undefined);

  function toggle(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (!loggedIn) {
      router.push(`/login?next=${encodeURIComponent(pathname)}`);
      return;
    }
    setSaved(dealSlug, !on);
    if (!on) {
      setPop((n) => n + 1);
      window.clearTimeout(popTimer.current);
      popTimer.current = window.setTimeout(() => setPop(0), 900);
    }
    startTransition(async () => {
      const res = await setDealSavedAction(dealSlug, !on);
      if (!res.ok) setSaved(dealSlug, on);
    });
  }

  return (
    <button
      type="button"
      onClick={toggle}
      aria-pressed={on}
      aria-label={
        remind
          ? on
            ? "Reminder set — tap to remove it"
            : "Remind me when this deal starts"
          : on
            ? "Saved — tap to remove from saved deals"
            : "Save this deal for later"
      }
      title={remind ? (on ? "We'll tell you when it starts" : "Remind me when it starts") : on ? "Saved" : "Save for later"}
      className={`relative flex shrink-0 items-center justify-center transition-colors ${VARIANTS[variant]} ${
        on ? "text-orange-500!" : ""
      } ${on ? "border-orange-300! bg-orange-50 dark:border-orange-800! dark:bg-orange-950/40" : ""}`}
    >
      <BookmarkIcon
        key={pop}
        className={`${variant === "round" ? "h-5 w-5" : "h-[18px] w-[18px]"} ${pop ? "save-pop" : ""}`}
        filled={on}
      />
      {/* Both labels sit in the same spot and the button is as wide as the
          longer one, so tapping it never nudges "Get deal" beside it. */}
      {variant === "pill" &&
        (remind ? (
          <StableLabel options={words("Remind me", "Reminder set")} show={on ? "Reminder set" : "Remind me"} />
        ) : (
          <StableLabel options={words("Save", "Saved")} show={on ? "Saved" : "Save"} />
        ))}
      {/* A quick confirmation when saving: the bookmark pops and a "Saved"
          label shows for a moment (not on the deal page, whose button
          already says it). The ring keeps it readable over "Get deal". */}
      {pop > 0 && variant !== "pill" && (
        <span
          key={`label-${pop}`}
          aria-hidden
          className={`save-label pointer-events-none absolute z-10 whitespace-nowrap rounded-full bg-orange-500 px-2 py-0.5 text-[11px] font-bold text-white shadow-sm ring-2 ring-white dark:ring-zinc-900 ${
            variant === "icon" ? "left-1/2 top-full mt-1" : "save-label-up bottom-full right-0 mb-1.5"
          }`}
        >
          Saved
        </span>
      )}
    </button>
  );
}
