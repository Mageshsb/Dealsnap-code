"use client";

import { useMemo, useRef, useState, type KeyboardEvent } from "react";
import { createPortal } from "react-dom";
import { useAnchoredMenu } from "./useAnchoredMenu";
import Icon from "./Icon";

// "Made by" on the post form: a brand from the site's list, or none (for a
// shop-wide sale or a mixed bundle). Usually already filled in. When the type
// has a maker (MacBook → Apple) the brand comes with it and can't be changed.
export default function BrandPicker({
  id,
  name,
  value,
  onChange,
  brands,
  maker,
}: {
  id?: string;
  name: string;
  value: string;
  onChange: (brand: string) => void;
  brands: string[];
  // The type's own maker, which decides the brand.
  maker?: string;
}) {
  const [query, setQuery] = useState("");
  const { open, toggle, close, anchorRef, host, menuProps } = useAnchoredMenu<HTMLButtonElement>("left", () => setQuery(""));
  const searchRef = useRef<HTMLInputElement>(null);

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return brands;
    return brands
      .filter((b) => b.toLowerCase().includes(q))
      .sort((a, b) => Number(!a.toLowerCase().startsWith(q)) - Number(!b.toLowerCase().startsWith(q)));
  }, [query, brands]);

  if (maker) {
    return (
      <div className="flex min-h-11 items-center gap-2 rounded-lg border border-zinc-200 bg-zinc-100 px-3 py-2 text-base sm:min-h-10 lg:text-sm dark:border-zinc-800 dark:bg-zinc-900">
        <input type="hidden" name={name} value={maker} />
        <Icon name="badge-check" className="size-4 shrink-0 text-orange-700 dark:text-orange-400" />
        <span className="font-medium">{maker}</span>
        <span className="min-w-0 truncate text-xs text-zinc-500">comes with the type</span>
      </div>
    );
  }

  function pick(brand: string) {
    onChange(brand);
    close();
    anchorRef.current?.focus();
  }

  function onListKey(e: KeyboardEvent<HTMLDivElement>) {
    const items = Array.from(e.currentTarget.querySelectorAll<HTMLElement>('[role="option"]'));
    const at = items.indexOf(document.activeElement as HTMLElement);
    if (e.key === "ArrowDown") items[Math.min(items.length - 1, at + 1)]?.focus();
    else if (e.key === "ArrowUp") (at <= 0 ? searchRef.current : items[at - 1])?.focus();
    else return;
    e.preventDefault();
  }

  return (
    <div className="relative min-w-0">
      <input type="hidden" name={name} value={value} />
      <button
        ref={anchorRef}
        id={id}
        type="button"
        onClick={() => {
          toggle();
          if (!open && window.matchMedia("(pointer: fine)").matches) setTimeout(() => searchRef.current?.focus(), 0);
        }}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={`Made by: ${value || "No single brand"}`}
        className="flex min-h-11 w-full min-w-0 items-center gap-2 rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2 text-base outline-none focus-visible:border-orange-500 sm:min-h-10 lg:text-sm dark:border-zinc-700 dark:bg-zinc-950"
      >
        {value && <Icon name="badge-check" className="size-4 shrink-0 text-orange-700 dark:text-orange-400" />}
        <span className={`min-w-0 flex-1 truncate text-left ${value ? "font-medium" : "text-zinc-500"}`}>{value || "No single brand"}</span>
        <Icon name="chevron-down" className={`size-4 shrink-0 text-zinc-500 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open &&
        host &&
        createPortal(
          <div
            {...menuProps}
            className={`${menuProps.className} flex w-[18rem] flex-col rounded-xl border border-zinc-200 bg-white text-zinc-900 shadow-lg dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-100`}
          >
            <div className="sticky top-0 z-10 border-b border-zinc-100 bg-white p-2 dark:border-zinc-800 dark:bg-zinc-900">
              <div className="flex items-center gap-2 rounded-lg bg-zinc-100 px-2.5 dark:bg-zinc-800">
                <Icon name="search" className="size-4 shrink-0 text-zinc-500 dark:text-zinc-400" />
                <input
                  ref={searchRef}
                  value={query}
                  onChange={(e) => setQuery(e.target.value.slice(0, 40))}
                  onKeyDown={(e) => {
                    if (e.key === "ArrowDown") {
                      e.preventDefault();
                      menuProps.ref.current?.querySelector<HTMLElement>('[role="option"]')?.focus();
                    } else if (e.key === "Enter") {
                      e.preventDefault();
                      if (query.trim() && shown[0]) pick(shown[0]);
                    }
                  }}
                  placeholder="Search brands"
                  aria-label="Search brands"
                  className="h-9 min-w-0 flex-1 bg-transparent text-base outline-none sm:text-sm"
                />
              </div>
            </div>
            <div role="listbox" aria-label="Made by" onKeyDown={onListKey} className="flex flex-col p-1">
              {[...(query.trim() ? [] : [""]), ...shown].map((b) => {
                const selected = b === value;
                return (
                  <button
                    key={b || "none"}
                    type="button"
                    role="option"
                    aria-selected={selected}
                    onClick={() => pick(b)}
                    className={`flex min-h-10 shrink-0 items-center gap-2.5 rounded-lg px-3 text-left text-sm outline-none ${
                      selected
                        ? "bg-orange-50 font-medium text-orange-700 dark:bg-orange-950/40 dark:text-orange-400"
                        : "text-zinc-700 hover:bg-zinc-100 focus:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800 dark:focus:bg-zinc-800"
                    }`}
                  >
                    <span className="min-w-0 flex-1 truncate">{b || "No single brand"}</span>
                    {selected && <Icon name="check" className="size-4 shrink-0" />}
                  </button>
                );
              })}
              {query.trim() && shown.length === 0 && (
                <p className="px-3 py-3 text-sm text-zinc-500">Not on our list yet. Leave it as &quot;No single brand&quot; for now.</p>
              )}
            </div>
          </div>,
          host
        )}
    </div>
  );
}
