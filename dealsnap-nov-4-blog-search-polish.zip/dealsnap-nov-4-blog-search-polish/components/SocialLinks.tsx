import { getShownLinks } from "@/lib/social-links";
import Icon from "./Icon";
import SocialIcon from "./SocialIcon";

// The site's social media and phone apps (Admin → Pages → Social and app
// links), as small grey logos that turn orange like the footer's links, and
// two small outlined "App Store" / "Google Play" buttons. Drawn on the server
// (no script), and nothing at all until one is switched on.
// The app buttons are plain words rather than Apple's and Google's badge
// artwork: those are big black badges that would make the footer heavy.
export default function SocialLinks({ className = "", centred = false }: { className?: string; centred?: boolean }) {
  const { social, apps } = getShownLinks();
  if (!social.length && !apps.length) return null;
  return (
    <div className={`flex flex-wrap items-center gap-x-3 gap-y-2 ${centred ? "justify-center" : ""} ${className}`}>
      {social.length > 0 && (
        <ul aria-label="Follow us" className="-mx-1.5 flex flex-wrap items-center">
          {social.map(({ kind, url }) => (
            <li key={kind.id}>
              <a
                href={url}
                target="_blank"
                rel="me noopener"
                aria-label={kind.name}
                title={kind.name}
                className="flex size-8 items-center justify-center rounded-lg text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-orange-500 dark:text-zinc-400 dark:hover:bg-zinc-800"
              >
                <SocialIcon id={kind.id} className="size-4" />
              </a>
            </li>
          ))}
        </ul>
      )}
      {apps.length > 0 && (
        <ul aria-label="Get the app" className="flex flex-wrap items-center gap-1.5">
          {apps.map(({ kind, url }) => (
            <li key={kind.id}>
              <a
                href={url}
                target="_blank"
                rel="noopener"
                aria-label={kind.says ?? kind.name}
                className="flex h-7 items-center gap-1 rounded-full border border-zinc-300 px-2.5 text-xs font-medium text-zinc-600 transition-colors hover:border-orange-300 hover:text-orange-600 dark:border-zinc-700 dark:text-zinc-300 dark:hover:border-orange-800 dark:hover:text-orange-400"
              >
                <Icon name="smartphone" className="size-3.5" />
                {kind.name}
              </a>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
