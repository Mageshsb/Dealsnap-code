"use client";

import { useSyncExternalStore } from "react";
import type { AdSlotId } from "@/lib/ads";
import AdUnit, { useAds } from "./AdUnit";

// The two side columns on wide screens, either side of the page, each staying
// in view as the page scrolls (until the page's end). They sit outside the
// page's own column, so nothing in it moves or shrinks. Drawn only once the
// screen is known to be wide enough, so an ad network never fills a column no
// one can see. The two are separate ad spaces (side column 1 on the left, 2 on
// the right): each can be on or off, and has its own campaigns, ad network unit
// and numbers, so one can be sold or sponsored without the other.
const WIDE = "(min-width: 1420px)";
const subscribe = (onChange: () => void) => {
  const q = window.matchMedia(WIDE);
  q.addEventListener("change", onChange);
  return () => q.removeEventListener("change", onChange);
};

const column = "pointer-events-none absolute inset-y-6 w-40";
const stick = "pointer-events-auto sticky top-[calc(var(--list-sticky-top,4rem)+1rem)]";

function Rail({ slot, side }: { slot: AdSlotId; side: string }) {
  if (!useAds()?.slots[slot]) return null;
  return (
    <div className={`${column} ${side}`}>
      <div className={stick}>
        <AdUnit slot={slot} />
      </div>
    </div>
  );
}

export default function AdRails() {
  const wide = useSyncExternalStore(subscribe, () => window.matchMedia(WIDE).matches, () => false);
  if (!wide) return null;
  return (
    <>
      <Rail slot="rail-left" side="right-full mr-4" />
      <Rail slot="rail-right" side="left-full ml-4" />
    </>
  );
}
