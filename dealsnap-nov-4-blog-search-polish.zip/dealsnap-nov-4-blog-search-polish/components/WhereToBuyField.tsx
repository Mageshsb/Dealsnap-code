"use client";

import { useState } from "react";
import { WHERE_NOTE_MAX, WHERE_TO_BUY_OPTIONS, type WhereToBuy } from "@/lib/where-to-buy";
import Icon from "./Icon";
import { CHOICE_TILE, HINT, INPUT } from "./DealExtrasFields";

// "Where can people get it?": Online (the default, even if it's in shops too)
// or In-store only, plus an optional note saying which shops. Used when
// posting and when staff edit. The post form passes `where` and
// `onWhereChange` to keep the choice itself (an in-store deal with no link
// sets it); otherwise it keeps its own.
export default function WhereToBuyField({
  defaultWhere = "online",
  defaultNote = "",
  where: given,
  onWhereChange,
}: {
  defaultWhere?: WhereToBuy;
  defaultNote?: string;
  where?: WhereToBuy;
  onWhereChange?: (where: WhereToBuy) => void;
}) {
  const [own, setOwn] = useState<WhereToBuy>(defaultWhere);
  const where = given ?? own;
  const setWhere = (next: WhereToBuy) => {
    setOwn(next);
    onWhereChange?.(next);
  };

  return (
    <fieldset className="flex flex-col gap-1.5">
      <legend className="mb-1.5 text-sm font-medium">Where can people get it?</legend>
      <div className="grid grid-cols-2 gap-1.5 sm:flex sm:gap-2">
        {WHERE_TO_BUY_OPTIONS.map((o) => (
          <label key={o.value} className={`${CHOICE_TILE} gap-1.5`}>
            <input
              type="radio"
              name="whereToBuy"
              value={o.value}
              checked={where === o.value}
              onChange={() => setWhere(o.value)}
              className="sr-only"
            />
            <Icon name={o.icon} className="size-4" />
            {o.label}
          </label>
        ))}
      </div>
      <p className={HINT}>Choose Online if it&apos;s sold online, even if stores have it too.</p>

      {where === "instore" && (
        <div className="mt-2 flex flex-col gap-1.5">
          <label htmlFor="whereNote" className="text-sm font-medium">
            Which stores?
          </label>
          <input
            id="whereNote"
            name="whereNote"
            defaultValue={defaultNote}
            maxLength={WHERE_NOTE_MAX}
            placeholder="e.g. most large Tesco stores, or Tesco Extra Leeds"
            className={INPUT}
          />
          <p className={HINT}>Store prices can vary by branch, so say where you saw it.</p>
        </div>
      )}
    </fieldset>
  );
}
