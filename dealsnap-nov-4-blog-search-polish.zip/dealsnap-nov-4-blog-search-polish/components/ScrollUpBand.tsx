"use client";

import { ReactNode, RefObject, useEffect, useRef, useState } from "react";

// A copy of a page's search and filter row that slides down under the header
// when you scroll back up, once the page's own row has gone out of sight, so
// you can change a filter without going all the way to the top. Scrolling down
// (or being back at the top) tucks it away again. It's the same band as the
// category strip on the deal lists: full width, with the page's own side
// padding inside.
//
// It's `fixed`, so it takes no room and showing it never moves the page.
// While you're typing in it, it stays (and if the page jumps to the top under
// you, your cursor moves to the page's own search box). `onHide` runs as it tucks away, so a
// menu opened from it (which would follow it up out of sight) can close.
const MIN_MOVE = 8; // px of scrolling before it reacts, so a jittery thumb doesn't flicker it

export default function ScrollUpBand({ after, onHide, children }: { after: RefObject<HTMLElement | null>; onHide?: () => void; children: ReactNode }) {
  const bandRef = useRef<HTMLDivElement>(null);
  const [headerHeight, setHeaderHeight] = useState(0);
  const [shown, setShown] = useState(false);
  const onHideRef = useRef(onHide);
  useEffect(() => {
    onHideRef.current = onHide;
  });

  useEffect(() => {
    const header = document.querySelector<HTMLElement>("header");
    const measure = () => setHeaderHeight(header?.offsetHeight ?? 0);
    measure();
    const observer = new ResizeObserver(measure);
    if (header) observer.observe(header);

    let lastY = window.scrollY;
    let up = false;
    let wasShown = false;
    function onScroll() {
      const y = window.scrollY;
      if (Math.abs(y - lastY) >= MIN_MOVE) {
        up = y < lastY;
        lastY = y;
      }
      // The page's own row counts as gone once it's up behind the header.
      const own = after.current;
      const gone = !!own && own.getBoundingClientRect().bottom < (header?.getBoundingClientRect().bottom ?? 0);
      const typing = !!bandRef.current?.contains(document.activeElement);
      const next = gone && (up || typing);
      if (wasShown && !next) {
        onHideRef.current?.();
        // A search that shrinks the list can throw the page back to the top,
        // where the page's own row is showing again and this one tucks away.
        // Hand the cursor over to that row's search box (it holds the same
        // text) so typing carries on without a break.
        const active = document.activeElement;
        const mine = active instanceof HTMLInputElement && bandRef.current?.contains(active);
        const theirs = own?.querySelector<HTMLInputElement>("input");
        if (mine && theirs) {
          theirs.focus({ preventScroll: true });
          theirs.setSelectionRange(theirs.value.length, theirs.value.length);
        }
      }
      wasShown = next;
      setShown(next);
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      observer.disconnect();
    };
  }, [after]);

  return (
    <div
      ref={bandRef}
      aria-hidden={!shown}
      style={{ top: headerHeight }}
      className={`fixed inset-x-0 z-30 border-b border-zinc-200 bg-white py-2 transition-[transform,visibility] duration-200 ease-out dark:border-zinc-800 dark:bg-black ${
        shown ? "" : "invisible -translate-y-full"
      }`}
    >
      <div className="mx-auto max-w-5xl px-4">{children}</div>
    </div>
  );
}
