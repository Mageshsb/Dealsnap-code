"use client";

import Link from "next/link";
import { createContext, useContext, type ReactNode } from "react";

// The "we may earn a commission" note that UK advertising rules ask for, set
// in Admin → Settings → Affiliate links. As on hotukdeals, every "Get deal"
// button gets a "*" while it's on, and the note (starting with "*") says what
// that means: in the footer, and at the bottom of the phone menu (Cards view
// hides the footer on phones and tablets).
const NoteContext = createContext<string | undefined>(undefined);

export function AffiliateNoteProvider({ text, children }: { text?: string; children: ReactNode }) {
  return <NoteContext.Provider value={text}>{children}</NoteContext.Provider>;
}

export function useAffiliateNote() {
  return useContext(NoteContext);
}

// "Get deal", marked with the "*" while the note is on. An upcoming deal's
// button says "View store" instead (or "Upcoming · View store" where there's
// room), still with the "*": it goes through the same earning link.
export function GetDealLabel({ upcoming, long }: { upcoming?: boolean; long?: boolean } = {}) {
  const star = useAffiliateNote() ? "*" : "";
  if (upcoming) return <>{long ? "Upcoming · View store" : "View store"}{star}</>;
  return <>Get deal{star}</>;
}

// The note itself is the link to the full explanation in the Terms (that it
// never affects which deals are shown, and the price is the same), with a
// light underline so it reads as tappable without adding any words.
export function AffiliateNote({ text }: { text: string }) {
  return (
    <Link
      href="/terms#how-we-make-money"
      className="underline decoration-zinc-300 underline-offset-2 hover:text-orange-500 hover:decoration-current dark:decoration-zinc-600"
    >
      *{text}
    </Link>
  );
}

// The same "*" after a link to another website in a member's post: those go
// out through /out, which adds the store's earning tag where there is one.
export function LinkStar() {
  return useAffiliateNote() ? <span aria-hidden>*</span> : null;
}
