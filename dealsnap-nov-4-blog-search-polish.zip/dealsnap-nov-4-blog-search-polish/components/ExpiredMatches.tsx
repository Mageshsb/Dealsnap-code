"use client";

import { useExpiredFilter } from "./ExpiredFilterProvider";
import EmptyState from "./EmptyState";

// Under search results, when "Show expired" is off: says how many expired deals
// also matched, with a link that ticks that filter. When nothing live matched
// at all, it stands in for the empty list so the page never just looks blank.
// `boxed={false}` inside the Cards view's end card, which is a dashed box already.
export default function ExpiredMatches({
  count,
  query,
  nothingLive,
  boxed = true,
}: {
  count: number;
  query?: string;
  nothingLive: boolean;
  boxed?: boolean;
}) {
  const { setShowExpired } = useExpiredFilter();
  // The expired deals appear above this line (in Cards view, above the last
  // card), so bring the first one into view rather than leave you at the end.
  function reveal() {
    setShowExpired(true);
    requestAnimationFrame(() =>
      document.querySelector("[data-expired]")?.scrollIntoView({ block: "nearest", behavior: "smooth" })
    );
  }
  const show = (
    <button type="button" onClick={reveal} className="font-medium text-orange-700 dark:text-orange-400 hover:underline">
      Show {count === 1 ? "it" : "them"}
    </button>
  );
  const matches = count === 1 ? "1 expired deal matches." : `${count} expired deals match.`;

  if (nothingLive) {
    return (
      <EmptyState icon="search" boxed={boxed}>
        <p>No live deals for &ldquo;{query}&rdquo;.</p>
        <p>
          {matches} {show}
        </p>
      </EmptyState>
    );
  }

  return (
    <p className="py-4 text-center text-sm text-zinc-500">
      {count === 1 ? "1 expired deal also matches." : `${count} expired deals also match.`} {show}
    </p>
  );
}
