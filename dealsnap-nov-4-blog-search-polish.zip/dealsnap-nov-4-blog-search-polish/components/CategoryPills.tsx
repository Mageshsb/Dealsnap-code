import { ReactNode } from "react";
import Link from "next/link";
import { getCategoryGroups } from "@/lib/categories";
import { slugify } from "@/lib/slug";
import { currentShoppingEvent } from "@/lib/events";
import { getLiveEvents } from "@/lib/db";
import Icon from "./Icon";

export default function CategoryPills({
  activeSlug,
  leading,
  crumbs,
  extra,
  divided,
}: {
  activeSlug?: string;
  leading?: ReactNode;
  crumbs?: ReactNode; // right after the menu button: where you are (Stores › Currys)
  extra?: ReactNode; // anything else a page puts up front
  divided?: boolean; // a divider between all that and the category pills
}) {
  const activeClass = "bg-orange-500 text-white";
  const inactiveClass =
    "bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-300";
  const pillSize = "px-3 py-1.5 text-sm";
  // In the weeks around Black Friday (and any other big day), its page leads the row.
  const event = currentShoppingEvent(getLiveEvents());

  // Voucher codes for every store, always one tap from any list. In the codes'
  // own violet, dashed like a code, so it reads as codes, not a category. On the
  // Vouchers page it's "where you are", like a store's chip on its page: it sits
  // right after the menu, before the divider, and its x steps back to all deals.
  const onVouchers = activeSlug === "vouchers";
  const voucherChip = (
    <Link
      href={onVouchers ? "/" : "/vouchers"}
      aria-current={onVouchers ? "page" : undefined}
      aria-label={onVouchers ? "Vouchers, tap to go back to all deals" : undefined}
      className={`flex shrink-0 items-center gap-1.5 rounded-xl border border-dashed font-semibold transition-colors px-3 py-[5px] text-sm ${
        onVouchers
          ? "border-violet-600 bg-violet-600 text-white dark:border-violet-500"
          : "border-violet-300 bg-violet-50 text-violet-800 hover:bg-violet-100 dark:border-violet-800 dark:bg-violet-950/40 dark:text-violet-200 dark:hover:bg-violet-950/70"
      }`}
    >
      <Icon name="ticket" className="size-4" />
      Vouchers
      {onVouchers && <Icon name="x" className="size-3.5" />}
    </Link>
  );

  // `leading` (the category menu button) scrolls away with the pills, so a
  // long category name never eats into the room for swiping along the row.
  return (
    <div className="no-scrollbar flex items-center gap-2 overflow-x-auto scroll-smooth">
      {leading && <div className="shrink-0">{leading}</div>}
      {crumbs}
      {onVouchers && voucherChip}
      {extra}
      {(divided || onVouchers) && <span aria-hidden className="mx-1 h-6 w-px shrink-0 bg-zinc-300 dark:bg-zinc-700" />}
      {event && (
        <Link
          href={`/${event.slug}`}
          className={`flex shrink-0 items-center gap-1.5 rounded-xl bg-zinc-900 font-semibold text-white transition-colors hover:bg-zinc-700 dark:bg-zinc-100 dark:text-zinc-900 dark:hover:bg-zinc-300 ${pillSize}`}
        >
          <Icon name={event.icon} className="size-4" />
          {event.name}
        </Link>
      )}
      {/* Voucher codes for every store, always one tap from any list. In the
          codes' own violet, dashed like a code, so it reads as codes, not a category. */}
      {!onVouchers && voucherChip}
      {getCategoryGroups().map((group) => {
        const slug = slugify(group.name);
        return (
          <Link
            key={slug}
            href={`/categories/${slug}`}
            className={`shrink-0 rounded-xl font-medium transition-colors ${pillSize} ${
              activeSlug === slug ? activeClass : inactiveClass
            }`}
          >
            {group.name}
          </Link>
        );
      })}
      <Link
        href="/categories"
        className="shrink-0 rounded-xl bg-zinc-100 px-3 py-1.5 text-sm font-semibold text-orange-700 transition-colors hover:bg-zinc-200 dark:bg-zinc-800 dark:text-orange-400"
      >
        All Categories &amp; Tags →
      </Link>
    </div>
  );
}
