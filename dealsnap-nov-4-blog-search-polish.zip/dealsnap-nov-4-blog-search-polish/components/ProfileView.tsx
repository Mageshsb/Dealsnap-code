import Link from "next/link";
import { UserRecord } from "@/lib/db";
import { Badge, BadgeProgress } from "@/lib/badges";
import { CommentPage, DealPage, SortLiked, SortPosted } from "@/lib/social";
import { unblockUserAction } from "@/lib/member-actions";
import ProfileHeaderCard, { type ProfileStats } from "./ProfileHeaderCard";
import ProfileTabs from "./ProfileTabs";
import ShowExpiredTile from "./ShowExpiredTile";
import SortSelect from "./SortSelect";
import Pagination from "./Pagination";
import DealCard from "./DealCard";
import ProfileCommentCard from "./ProfileCommentCard";
import BadgesPanel from "./BadgesPanel";
import Icon from "@/components/Icon";
import EmptyState from "./EmptyState";

const POSTED_SORT_OPTIONS = [
  { value: "new", label: "Newest first" },
  { value: "old", label: "Oldest first" },
  { value: "hearts", label: "Most hearts" },
];

const LIKED_SORT_OPTIONS = [
  { value: "recent", label: "Recently loved" },
  { value: "hearts", label: "Most hearts" },
];

const COMMENTS_SORT_OPTIONS = [
  { value: "new", label: "Newest first" },
  { value: "old", label: "Oldest first" },
  { value: "liked", label: "Most liked" },
];

export default function ProfileView({
  profileUser,
  basePath,
  activeTab,
  isOwner,
  isFollowing,
  followMuted,
  viewerLoggedIn,
  followerCount,
  followingCount,
  badges,
  badgeProgress,
  postedPage,
  likedPage,
  commentsPage,
  stats,
  viewerRelation,
}: {
  profileUser: UserRecord;
  basePath: string;
  activeTab: "posted" | "liked" | "comments" | "badges";
  isOwner: boolean;
  isFollowing: boolean;
  followMuted: boolean;
  viewerLoggedIn: boolean;
  followerCount: number;
  followingCount: number;
  badges: Badge[];
  badgeProgress: BadgeProgress[];
  postedPage: DealPage<SortPosted>;
  likedPage: DealPage<SortLiked>;
  commentsPage: CommentPage;
  stats: ProfileStats;
  viewerRelation?: { blocked: boolean; blockedBy: boolean; reported: boolean };
}) {
  const tabs = [
    // Approved deals only, matching "deals posted" above. Your own pending or
    // removed deals still show in the list, each with a note saying why it
    // isn't counted.
    { key: "posted", label: "Deals", count: String(stats.dealCount) },
    { key: "liked", label: "Loved", count: String(likedPage.total) },
    { key: "comments", label: "Posts", count: String(commentsPage.total) },
    { key: "badges", label: "Badges", count: `${badgeProgress.reduce((n, b) => n + b.tier, 0)}/${badgeProgress.reduce((n, b) => n + b.tiers.length, 0)}` },
  ];

  return (
    <div className="flex flex-col gap-6">
      <ProfileHeaderCard
        profileUser={profileUser}
        isOwner={isOwner}
        isFollowing={isFollowing}
        followMuted={followMuted}
        viewerLoggedIn={viewerLoggedIn}
        followerCount={followerCount}
        followingCount={followingCount}
        badges={badges}
        stats={stats}
        viewerRelation={viewerRelation}
      />

      {viewerRelation?.blocked ? (
        <div className="flex flex-col items-start gap-2 rounded-xl border border-zinc-200 bg-white p-4 text-sm text-zinc-600 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-300">
          <p>
            <Icon name="ban" className="mr-1.5 text-red-500" />
            You&apos;ve blocked {profileUser.username}. You won&apos;t see their deals or comments anywhere on DealSnap.
          </p>
          <form action={unblockUserAction.bind(null, profileUser.id)}>
            <input type="hidden" name="back" value={`/u/${profileUser.username}`} />
            <button type="submit" className="rounded-full border border-zinc-300 px-3 py-1 text-sm font-medium hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">
              Unblock
            </button>
          </form>
        </div>
      ) : (
      <>
      <ProfileTabs basePath={basePath} active={activeTab} tabs={tabs} />

      {activeTab === "posted" && (
        <div className="flex flex-col gap-3">
          {postedPage.total > 0 && (
            <div className="flex items-center justify-between gap-2">
              {postedPage.expiredCount > 0 ? <ShowExpiredTile basePath={basePath} tab="posted" sort={postedPage.sort} defaultSort="new" count={postedPage.expiredCount} showExpired={postedPage.showExpired} /> : <span />}
              <SortSelect keep={{ tab: "posted", show: postedPage.showExpired ? "all" : undefined }} current={postedPage.sort} options={POSTED_SORT_OPTIONS} />
            </div>
          )}
          {!postedPage.showExpired && postedPage.items.length === 0 && postedPage.total > 0 ? (
            <EmptyState icon="tag">
              <p>All of these deals have expired.</p>
            </EmptyState>
          ) : postedPage.items.length === 0 ? (
            <EmptyState icon="tag">
              <p>No deals posted yet.</p>
              {isOwner && (
                <Link
                  href="/submit"
                  className="mt-2 flex min-h-9 items-center gap-1.5 rounded-full bg-orange-500 px-4 text-sm font-semibold text-white hover:bg-orange-600"
                >
                  <Icon name="plus" className="size-4" />
                  Post a deal
                </Link>
              )}
            </EmptyState>
          ) : (
            postedPage.items.map((deal) =>
              isOwner && (deal.status === "pending" || deal.status === "removed") ? (
                // The note and the deal sit together in one tinted tray, so
                // it's obvious which deal the note is about.
                <div
                  key={deal.id}
                  className={`flex flex-col gap-1 rounded-2xl border p-1 ${
                    deal.status === "pending"
                      ? "border-amber-300 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/40"
                      : "border-red-300 bg-red-50 dark:border-red-900 dark:bg-red-950/40"
                  }`}
                >
                  {deal.status === "pending" ? (
                    <p className="px-2 pt-1 pb-0.5 text-xs leading-snug text-amber-900 dark:text-amber-200">
                      <span className="font-semibold">
                        <Icon name="hourglass" className="mr-1" />
                        Waiting for approval.
                      </span> This deal isn&apos;t public yet:
                      the DealSnap team checks every new deal before it goes live. Until then, only you can see it, and it
                      won&apos;t count towards your deals posted.{" "}
                      <Link href={`/deals/${deal.slug}/edit`} className="font-medium underline">
                        Edit it
                      </Link>
                    </p>
                  ) : (
                    <p className="px-2 pt-1 pb-0.5 text-xs leading-snug text-red-900 dark:text-red-200">
                      <span className="font-semibold">
                        <Icon name="ban" className="mr-1" />
                        Removed by the DealSnap team
                      </span>
                      {deal.moderationReason ? `: ${deal.moderationReason}` : "."}
                      {deal.moderationNote ? ` (${deal.moderationNote})` : ""} Only you can see it now, and it
                      doesn&apos;t count towards your deals posted.
                    </p>
                  )}
                  <DealCard deal={deal} />
                </div>
              ) : (
                <DealCard key={deal.id} deal={deal} />
              )
            )
          )}
          <Pagination
            basePath={basePath}
            tab="posted"
            sort={postedPage.sort}
            page={postedPage.page}
            totalPages={postedPage.totalPages}
            keep={{ show: postedPage.showExpired ? "all" : undefined }}
          />
        </div>
      )}

      {activeTab === "liked" && (
        <div className="flex flex-col gap-3">
          {likedPage.total > 0 && (
            <div className="flex items-center justify-between gap-2">
              {likedPage.expiredCount > 0 ? <ShowExpiredTile basePath={basePath} tab="liked" sort={likedPage.sort} defaultSort="recent" count={likedPage.expiredCount} showExpired={likedPage.showExpired} /> : <span />}
              <SortSelect keep={{ tab: "liked", show: likedPage.showExpired ? "all" : undefined }} current={likedPage.sort} options={LIKED_SORT_OPTIONS} />
            </div>
          )}
          {!likedPage.showExpired && likedPage.items.length === 0 && likedPage.total > 0 ? (
            <EmptyState icon="heart">
              <p>All of these loved deals have expired.</p>
            </EmptyState>
          ) : likedPage.items.length === 0 ? (
            <EmptyState icon="heart">
              <p>No loved deals yet.</p>
            </EmptyState>
          ) : (
            likedPage.items.map((deal) => <DealCard key={deal.id} deal={deal} />)
          )}
          <Pagination
            basePath={basePath}
            tab="liked"
            sort={likedPage.sort}
            page={likedPage.page}
            totalPages={likedPage.totalPages}
            keep={{ show: likedPage.showExpired ? "all" : undefined }}
          />
        </div>
      )}

      {activeTab === "comments" && (
        <div className="flex flex-col gap-3">
          {commentsPage.total > 0 && (
            <div className="flex items-center justify-end">
              <SortSelect keep={{ tab: "comments" }} current={commentsPage.sort} options={COMMENTS_SORT_OPTIONS} />
            </div>
          )}
          {commentsPage.items.length === 0 ? (
            <EmptyState icon="comment">
              <p>No posts yet.</p>
            </EmptyState>
          ) : (
            commentsPage.items.map((item) => <ProfileCommentCard key={item.id} item={item} />)
          )}
          <Pagination
            basePath={basePath}
            tab="comments"
            sort={commentsPage.sort}
            page={commentsPage.page}
            totalPages={commentsPage.totalPages}
          />
        </div>
      )}

      {activeTab === "badges" && <BadgesPanel badges={badgeProgress} isOwner={isOwner} />}

      </>
      )}
    </div>
  );
}
