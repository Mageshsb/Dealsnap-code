"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { DealSnapIcon } from "@/components/icons";

// The logo uploaded in Admin → Settings → General (lib/site-brand.ts), as
// the header shows it: a square-ish one sits where the built-in icon does,
// beside the site's name; a wide one is the name, 28px tall like the words.
export type HeaderLogo = { src: string; darkSrc?: string; w: number; h: number; wide: boolean };

export default function SiteLogoLink({ siteName, logo, showName = true }: { siteName: string; logo?: HeaderLogo; showName?: boolean }) {
  const pathname = usePathname();

  // A same-route <Link> is a no-op in the App Router — clicking the logo
  // while already on "/" wouldn't reset scroll or in-page state. Force an
  // actual reload only in that case; this is a plain forward navigation
  // either way, so it doesn't touch the pop-navigation scroll-restore cache
  // (see lib/navigation-type.ts) that deal-page back/forward relies on.
  function handleClick(e: React.MouseEvent) {
    if (pathname === "/") {
      e.preventDefault();
      // eslint-disable-next-line @next/next/no-location-assign-relative-destination
      window.location.href = "/";
    }
  }

  return (
    <Link href="/" onClick={handleClick} className="flex shrink-0 items-center gap-1 text-lg font-bold tracking-tight max-[344px]:text-base sm:gap-1.5">
      {logo ? (
        <picture className="contents">
          {logo.darkSrc && <source media="(prefers-color-scheme: dark)" srcSet={logo.darkSrc} />}
          <img
            src={logo.src}
            alt={showName ? "" : siteName}
            width={logo.w}
            height={logo.h}
            fetchPriority="high"
            className={
              logo.wide
                ? "h-7 w-auto max-w-[128px] shrink-0 object-contain object-left max-[344px]:h-6 max-[344px]:max-w-[104px] sm:max-w-[200px]"
                : "h-6 w-6 shrink-0 object-contain max-[329px]:h-5 max-[329px]:w-5"
            }
          />
        </picture>
      ) : (
        <DealSnapIcon className="h-6 w-6 shrink-0 max-[329px]:h-5 max-[329px]:w-5" />
      )}
      {(showName || !logo) && siteName}
    </Link>
  );
}
