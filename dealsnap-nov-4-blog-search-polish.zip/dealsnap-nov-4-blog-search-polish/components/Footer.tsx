import Link from "next/link";
import CookieSettingsLink from "./CookieSettingsLink";
import { getSiteLinks } from "@/lib/site-pages";
import { AffiliateNote } from "./AffiliateNote";
import SocialLinks from "./SocialLinks";

const link = "hover:text-orange-500 hover:underline";

// A slim footer: the copyright line on the left (with the commission note,
// and Amazon's wording once a tag is set, running on from it) and small
// links on the right; all centred on phones. Hidden on phones and tablets while the
// card view is showing (see globals.css), so the cards fill the screen without
// the page moving under them; the same links sit at the bottom of the phone menu.
// Above them, once any are switched on in Admin, a line of small social media
// logos (left) and app buttons (right); nothing at all until then.
export default function Footer({
  showCookieSettings,
  showAdvertise,
  affiliateDisclosure,
  amazonDisclosure,
}: {
  showCookieSettings?: boolean;
  showAdvertise?: boolean; // Admin → Ads → Advertise page is on
  affiliateDisclosure?: string;
  amazonDisclosure?: string;
}) {
  const note = [affiliateDisclosure, amazonDisclosure].filter(Boolean).join(" · ");
  return (
    <footer className="site-footer mt-auto border-t border-zinc-200 dark:border-zinc-800">
      <SocialLinks className="mx-auto -mb-2 w-full max-w-5xl justify-center px-4 pt-3 sm:justify-between" />
      <div className="mx-auto flex w-full max-w-5xl flex-col items-center gap-2 px-4 py-4 text-xs sm:flex-row-reverse sm:justify-between sm:gap-8">
        <nav className="flex shrink-0 flex-wrap items-center justify-center gap-x-4 gap-y-1 text-zinc-600 dark:text-zinc-400">
          {getSiteLinks().map((l) => (
            <Link key={l.href} href={l.href} className={link}>
              {l.label}
            </Link>
          ))}
          {showAdvertise && (
            <Link href="/advertise" className={link}>
              Advertise
            </Link>
          )}
          {showCookieSettings && <CookieSettingsLink className={link} />}
        </nav>
        <p className="text-center leading-relaxed text-zinc-500 sm:text-left">
          <span className="font-medium">© 2026 DealSnap</span>
          {note && (
            <>
              {" · "}
              <AffiliateNote text={note} />
            </>
          )}
        </p>
      </div>
    </footer>
  );
}
