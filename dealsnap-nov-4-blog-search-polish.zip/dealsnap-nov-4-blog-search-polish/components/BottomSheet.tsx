"use client";

import { ReactNode, useEffect } from "react";
import { createPortal } from "react-dom";

// A sheet that slides over the Scroll view's card from the bottom (so the card
// never has to move or re-fit), with a Done button. Used for Filters and the
// ⓘ Info panel. On wide screens it stays docked to the bottom edge as a
// centred column rather than floating mid-page.
export default function BottomSheet({
  open,
  onClose,
  label,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  label: string; // for screen readers
  title: ReactNode; // shown beside Done
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);

    // Freeze the page behind the sheet. Only on <html>: hiding <body>'s
    // overflow too would make it a scroll box of its own, and everything
    // sticky (the category strip, the Most loved/New row) would drop back to
    // its place far up the page until the sheet closed. Padding makes up for
    // the scrollbar that disappears on desktop so the layout doesn't jump
    // sideways.
    const { body, documentElement: html } = document;
    const prev = { bodyPadding: body.style.paddingRight, htmlOverflow: html.style.overflow };
    const scrollbar = window.innerWidth - html.clientWidth;
    html.style.overflow = "hidden";
    if (scrollbar > 0) body.style.paddingRight = `${scrollbar}px`;

    return () => {
      document.removeEventListener("keydown", onKey);
      html.style.overflow = prev.htmlOverflow;
      body.style.paddingRight = prev.bodyPadding;
    };
  }, [open, onClose]);

  if (!open) return null;
  return createPortal(
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div className="absolute inset-0 touch-none bg-black/40" onClick={onClose} aria-hidden />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={label}
        className="relative flex max-h-[85dvh] w-full flex-col gap-4 overflow-y-auto overscroll-contain rounded-t-2xl bg-white p-4 pb-6 shadow-xl dark:bg-zinc-900 sm:max-w-lg sm:p-6 sm:pb-8"
      >
        {/* Stays at the top while the sheet's content scrolls, so Done is always in reach. */}
        <div className="sticky -top-4 z-10 -mx-4 -mt-4 flex items-center justify-between gap-3 bg-white px-4 pb-2 pt-4 dark:bg-zinc-900 sm:-top-6 sm:-mx-6 sm:-mt-6 sm:px-6 sm:pt-6">
          <h2 className="font-semibold">{title}</h2>
          <button
            type="button"
            onClick={onClose}
            className="shrink-0 rounded-full bg-orange-500 px-4 py-1.5 text-sm font-semibold text-white hover:bg-orange-600"
          >
            Done
          </button>
        </div>
        {children}
      </div>
    </div>,
    document.body
  );
}
