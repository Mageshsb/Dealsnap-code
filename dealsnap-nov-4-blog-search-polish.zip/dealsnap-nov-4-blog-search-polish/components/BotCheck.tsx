"use client";

import Script from "next/script";
import { useEffect, useRef } from "react";
import type { FormCheck } from "@/lib/captcha";

type Turnstile = {
  render: (el: HTMLElement, opts: { sitekey: string; theme?: string; size?: string }) => string;
  reset: (id?: string) => void;
  remove: (id: string) => void;
};
declare global {
  interface Window {
    turnstile?: Turnstile;
  }
}

// The robot checks on a public form (see lib/captcha.ts): a hidden box only
// bots fill in, the signed ticket that says when the form was shown (where
// there is one), and Cloudflare's tick once it's set up (or, where the form
// asks for one, a sum).
// A new `resetKey` (a failed send) gets a fresh Cloudflare check, as each one
// works once.
export default function BotCheck({
  idPrefix,
  check,
  siteKey,
  resetKey,
  answerClassName = "",
}: {
  idPrefix: string;
  check?: FormCheck;
  siteKey?: string;
  resetKey?: unknown;
  answerClassName?: string;
}) {
  const widgetRef = useRef<HTMLDivElement>(null);
  const widgetId = useRef<string | null>(null);

  function render() {
    if (!siteKey || !widgetRef.current || !window.turnstile || widgetId.current) return;
    widgetId.current = window.turnstile.render(widgetRef.current, { sitekey: siteKey, size: "flexible" });
  }

  // The script may already be there (coming back to the page), so try now too.
  useEffect(() => {
    render();
    return () => {
      if (widgetId.current) window.turnstile?.remove(widgetId.current);
      widgetId.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (resetKey !== undefined && widgetId.current) window.turnstile?.reset(widgetId.current);
  }, [resetKey]);

  return (
    <>
      {siteKey && <Script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit" strategy="afterInteractive" onReady={render} />}
      {/* Only bots see and fill this in. */}
      <div aria-hidden className="absolute -left-[9999px] h-px w-px overflow-hidden">
        <label htmlFor={`${idPrefix}-website`}>Leave this empty</label>
        <input id={`${idPrefix}-website`} name="website" tabIndex={-1} autoComplete="off" />
      </div>
      {check && <input type="hidden" name="ticket" value={check.ticket} />}
      {siteKey ? (
        <div ref={widgetRef} className="min-h-[65px]" />
      ) : (
        check?.question && (
          <div className="flex flex-col gap-1">
            <label htmlFor={`${idPrefix}-answer`} className="text-sm font-medium">
              Quick check: {check.question}
            </label>
            <input
              key={check.ticket}
              id={`${idPrefix}-answer`}
              name="answer"
              required
              inputMode="numeric"
              autoComplete="off"
              maxLength={3}
              className={answerClassName}
            />
          </div>
        )
      )}
    </>
  );
}
