import { DEAL_CONDITIONS, type DealCondition, type PriceTag } from "@/lib/deal-kinds";
import { formatPrice } from "@/lib/format";
import Icon from "./Icon";

// The price spot's words around the price, smaller than it and in the same
// orange: "from £199", "£10/month", "£25pp". Goes inside the price's own span,
// so it scales with whatever size that is.
export function PriceMain({ tag }: { tag: PriceTag }) {
  return (
    <>
      {tag.from && <span className="mr-[0.25em] text-[0.6em] font-semibold">from</span>}
      {tag.main}
      {tag.unit && <span className="text-[0.6em] font-semibold">{tag.unit}</span>}
    </>
  );
}

// The "was" price beside the deal price: crossed out when it's a price the
// store charged, or "RRP £379" (not crossed out) when it's only the store's
// recommended price, which may never have been charged. `className` is the
// size and colour of the spot it sits in.
export function WasPrice({ tag, className = "" }: { tag: Pick<PriceTag, "was" | "wasRrp">; className?: string }) {
  if (!tag.was) return null;
  // "RRP" a size down, so the price beside it still fits where a crossed-out
  // one would (a four-figure RRP on a 360px phone's Cards view).
  return tag.wasRrp ? (
    <span className={className}>
      <span className="text-[0.75em] font-medium">RRP</span> {tag.was}
    </span>
  ) : (
    <span className={`line-through ${className}`}>{tag.was}</span>
  );
}

// "after cashback", straight after the price (which already has it taken off),
// where there's room for it: the deal page and the sticky bar. Cards say it in
// their small print instead.
export function PriceNote({ tag, className = "" }: { tag: PriceTag; className?: string }) {
  if (!tag.note) return null;
  return <span className={`shrink-0 text-zinc-500 dark:text-zinc-400 ${className}`}>{tag.note}</span>;
}

// "£150", "£12.50": whole pounds without the pence.
const pounds = (amount: number) => (Number.isInteger(amount) ? `£${amount}` : formatPrice(amount));

// A card's small print, one line under the shop: cashback still to claim (the
// price above already has it taken off) and the catches ("After £150 cashback
// · New customers"), cut short with … if it runs out of room. Nothing at all
// when there are none, so most cards don't change.
export function SmallPrint({ conditions, cashback, className = "" }: { conditions?: DealCondition[]; cashback?: number; className?: string }) {
  const list = DEAL_CONDITIONS.filter((c) => conditions?.includes(c.value));
  if (!list.length && !cashback) return null;
  const words = [cashback ? `After ${pounds(cashback)} cashback` : "", ...list.map((c) => c.short)].filter(Boolean);
  return (
    <p className={`flex min-w-0 items-center gap-1 whitespace-nowrap font-medium text-zinc-600 dark:text-zinc-300 ${className}`}>
      <Icon name={cashback ? "pound" : list[0].icon} className="size-3.5 shrink-0 text-zinc-500 dark:text-zinc-400" />
      <span className="min-w-0 truncate">{words.join(" · ")}</span>
    </p>
  );
}

// On the deal page: each catch in full, plus how the cashback works, so
// nobody finds out at the checkout.
export function DealCatches({ conditions, cashback, price }: { conditions?: DealCondition[]; cashback?: number; price: number }) {
  const list = DEAL_CONDITIONS.filter((c) => conditions?.includes(c.value));
  if (!list.length && !cashback) return null;
  return (
    <ul className="flex flex-col gap-1.5 rounded-xl bg-zinc-50 px-3.5 py-3 text-sm text-zinc-700 dark:bg-zinc-800/60 dark:text-zinc-300">
      {cashback ? (
        <li className="flex items-start gap-2">
          <Icon name="pound" className="mt-0.5 size-4 shrink-0 text-zinc-500 dark:text-zinc-400" />
          <span>
            You pay {formatPrice(price)}, then claim <strong className="font-semibold">{formatPrice(cashback)} cashback</strong>
          </span>
        </li>
      ) : null}
      {list.map((c) => (
        <li key={c.value} className="flex items-start gap-2">
          <Icon name={c.icon} className="mt-0.5 size-4 shrink-0 text-zinc-500 dark:text-zinc-400" />
          <span>
            {c.label}
            {c.hint && <span className="text-zinc-500 dark:text-zinc-400"> ({c.hint})</span>}
          </span>
        </li>
      ))}
    </ul>
  );
}
