"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import Icon from "./Icon";

// A member's picture in a post (a deal's description, a Community post, a
// comment), sized from its saved shape so nothing jumps as it loads. Tapping
// it opens it on its own, as big as the screen allows (PictureViewer).
export default function InlinePicture({
  id,
  width,
  height,
  alt,
  size = "large",
}: {
  id: string;
  width: number;
  height: number;
  alt: string;
  // "large" in the flow of the words; "small" as a thumbnail under a comment.
  size?: "large" | "small";
}) {
  const [open, setOpen] = useState(false);
  const close = useCallback(() => setOpen(false), []);
  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label={`Open ${alt.toLowerCase()} full size`}
        className="block w-fit max-w-full cursor-zoom-in overflow-hidden rounded-lg border border-zinc-200 bg-white hover:border-orange-300 focus-visible:ring-2 focus-visible:ring-orange-500 dark:border-zinc-700"
      >
        {/* eslint-disable-next-line @next/next/no-img-element -- our own cleaned copy, cached for a year */}
        <img
          src={`/picture/${id}/${size === "small" ? "sm" : "full"}.webp`}
          alt={alt}
          loading="lazy"
          width={width}
          height={height}
          className={`block h-auto w-auto max-w-full object-contain ${size === "small" ? "max-h-40" : "max-h-[28rem]"}`}
        />
      </button>
      {open && <PictureViewer src={`/picture/${id}/full.webp`} alt={alt} onClose={close} />}
    </>
  );
}

// One picture over the whole screen, as big as it fits. Pinch to zoom in on a
// small screenshot (left to the phone, so it feels like every other picture);
// tap outside it, the ×, or Escape to close. No arrows or "1 of 3": the
// pictures sit in the text in reading order, a few at most, each with its own
// words around it, so the next one is a close and a scroll away.
//
// Drawn on top of the page with a portal, the same way as the Filters sheet
// (BottomSheet), not a <dialog>: iPhone Safari didn't open the <dialog> one.
export function PictureViewer({ src, alt, onClose }: { src: string; alt: string; onClose: () => void }) {
  const close = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const opener = document.activeElement as HTMLElement | null;
    close.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    // Freeze the page behind, as BottomSheet does (only <html>, so sticky
    // bars stay put), making up for a desktop scrollbar so nothing shifts.
    const { body, documentElement: html } = document;
    const prev = { bodyPadding: body.style.paddingRight, htmlOverflow: html.style.overflow };
    const scrollbar = window.innerWidth - html.clientWidth;
    html.style.overflow = "hidden";
    if (scrollbar > 0) body.style.paddingRight = `${scrollbar}px`;
    return () => {
      document.removeEventListener("keydown", onKey);
      html.style.overflow = prev.htmlOverflow;
      body.style.paddingRight = prev.bodyPadding;
      opener?.focus({ preventScroll: true });
    };
  }, [onClose]);

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      aria-label={alt}
      onClick={(e) => e.target === e.currentTarget && onClose()}
      className="fixed inset-0 z-[70] flex items-center justify-center bg-black/90 px-[max(0.75rem,env(safe-area-inset-left))] pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-[calc(max(0.75rem,env(safe-area-inset-top))+3rem)]"
    >
      {/* eslint-disable-next-line @next/next/no-img-element -- our own cleaned copy, already cached from the page */}
      <img src={src} alt={alt} className="max-h-full max-w-full rounded-lg bg-white object-contain" />
      <button
        ref={close}
        type="button"
        onClick={onClose}
        aria-label="Close picture"
        className="absolute right-[max(0.75rem,env(safe-area-inset-right))] top-[max(0.75rem,env(safe-area-inset-top))] flex size-10 items-center justify-center rounded-full bg-white/15 text-white hover:bg-white/25 focus-visible:ring-2 focus-visible:ring-white"
      >
        <Icon name="x" className="size-5" />
      </button>
    </div>,
    document.body
  );
}
