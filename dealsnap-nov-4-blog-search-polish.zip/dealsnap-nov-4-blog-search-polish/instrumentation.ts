// Runs once when the server starts. Gives older deals their labels (see
// lib/label-backfill.ts), then starts the notification-email step
// (lib/email-notifications.ts) and upcoming deals' "it's on now" reminders,
// checked every minute, and Awin (lib/awin.ts),
// checked every hour: the stores that have accepted us synced, and their
// product lists downloaded, each about once a day, the daily backup
// (lib/backups.ts) and the admins' alert emails (lib/admin-alerts.ts).
// Node.js only: the database and email code can't run in the edge runtime.
// Next hands every server error nobody caught (a page that crashed, a failed
// action or route) to this. It's written to the error log (lib/error-log.ts)
// so the admins see it in Admin → Site health and in their alert email.
export async function onRequestError(
  error: unknown,
  request: { path: string; method: string },
  context: { routePath: string; routeType: string }
) {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  const { recordError } = await import("./lib/error-log");
  const err = error instanceof Error ? error : new Error(String(error));
  recordError({
    kind: "server",
    message: err.message,
    stack: err.stack,
    // The route ("/deals/[slug]"), not the address, so one problem is one row.
    path: `${request.method} ${context.routePath || request.path} (${context.routeType})`,
    digest: typeof error === "object" && error !== null && "digest" in error ? String((error as { digest: unknown }).digest) : undefined,
  });
}

export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  // Older deals get sub-tags and brands (once per database).
  const { backfillLabels } = await import("./lib/label-backfill");
  backfillLabels();
  // Older photos get checked for a white backdrop, in the background (once).
  const { backfillPhotoCutouts } = await import("./lib/photo-backfill");
  void backfillPhotoCutouts();
  const g = globalThis as unknown as {
    __dealsnapEmailTimer?: ReturnType<typeof setInterval>;
    __dealsnapProductListTimer?: ReturnType<typeof setInterval>;
  };
  // When the host stops the site (a new version going out), put everything the
  // database is still holding into its main file, so a copy taken right after
  // is complete. (The site's own writes are already safe; this just tidies.)
  const stopping = globalThis as unknown as { __dealsnapStopHook?: boolean };
  if (!stopping.__dealsnapStopHook) {
    stopping.__dealsnapStopHook = true;
    for (const signal of ["SIGTERM", "SIGINT"] as const) {
      process.once(signal, () => {
        setTimeout(() => process.exit(0), 4000).unref(); // never hang on the way out
        try {
          void import("./lib/db").then(({ sqlite }) => {
            sqlite.exec("PRAGMA wal_checkpoint(TRUNCATE)");
            process.exit(0);
          });
        } catch {
          process.exit(0);
        }
      });
    }
  }
  if (g.__dealsnapEmailTimer) return; // dev reloads: one timer only
  const { processEmailQueue } = await import("./lib/email-notifications");
  // Every minute: emails waiting to go, and upcoming deals that have just
  // started (their savers are told, lib/notifications.ts).
  const { notifyStartedDeals } = await import("./lib/notifications");
  const everyMinute = () => {
    void processEmailQueue();
    notifyStartedDeals();
  };
  g.__dealsnapEmailTimer = setInterval(everyMinute, 60 * 1000);
  everyMinute();
  const { awinUpkeep } = await import("./lib/awin");
  const { makeDailyBackup } = await import("./lib/backups");
  const { sendAdminAlerts } = await import("./lib/admin-alerts");
  // A test copy never calls the affiliate networks (lib/environment.ts).
  const { isStaging } = await import("./lib/environment");
  const hourly = () => {
    // Lets SQLite refresh what it knows about the data, so its queries keep
    // choosing the quickest route as the tables grow.
    void import("./lib/db").then(({ sqlite }) => sqlite.exec("PRAGMA optimize"));
    makeDailyBackup();
    // Pictures from posts that have gone, and binned ones' files (lib/pictures.ts).
    void import("./lib/pictures").then(({ tidyPictures }) => tidyPictures()).catch((e) => console.error("Picture tidy failed:", e));
    if (!isStaging) void awinUpkeep();
    void sendAdminAlerts();
  };
  g.__dealsnapProductListTimer = setInterval(hourly, 60 * 60 * 1000);
  makeDailyBackup();
}
