# Launch-readiness audit (5 November 2026)

What was checked, what was found, what was fixed, and what is left. The tools used
are kept, so it can be repeated before launch and after any big change:

- `npm run check`: type check, code style, and 20 test suites (≈2,000 checks).
- `npm run e2e`: a real Chrome on a computer **and** a phone walks the site as a
  visitor, a member and the admin (46 tests), including `e2e/audit.spec.ts`, which
  sweeps ~45 kinds of page for broken links, failed files, browser console errors,
  sideways scrolling, missing titles/descriptions/headings, unlabelled controls and
  accessibility (axe, WCAG 2.1 AA). Its findings are written to `test-results/audit.json`.
- Scale tests on throwaway copies of the site with 50,000 and 200,000 deals.
- Admin → **Launch checklist** and **Site health** inside the site itself.

## Verdict

The site itself is ready to launch. What stands between you and going live is accounts
and settings (domain, hosting, email, Cloudflare, company details), all listed in
Admin → Launch checklist and walked through in `docs/HOSTING.md`. Two things need a
decision from you (below), and one thing could not be tested on this Mac (the Docker image).

## Needs your decision

1. **The orange buttons' white text fails the accessibility contrast standard.**
   White on the brand orange is 2.88:1; the standard (WCAG AA) asks for 4.5:1 for normal
   text. It affects every orange button ("Post a deal", "Get deal", category button,
   tab labels): ~300 places on 52 pages. Nothing is broken for most people, and it's a
   brand choice, so I haven't changed it. Options: **(a)** keep it; **(b)** dark text
   (near-black) on the same orange, 7.2:1, a different look but the same brand colour;
   **(c)** a deeper orange fill (`orange-700`) with white text, 5.4:1, a rustier brand.
   It's a one-line codemod once you choose. The audit lists it as "advisory" until then.
2. **Prices are now a deeper orange** (`orange-700`, was `orange-600`) so the smaller
   prices and offers also pass. Large bold prices only needed `orange-600`. If you
   prefer the brighter look, say so and I'll keep the bright one on large prices only.

## Fixed in this audit

**Security**
- Visitor addresses (used by the sign-up, login and posting limits): the site trusted
  Cloudflare's `CF-Connecting-IP` header unconditionally, so a site reachable without
  Cloudflare could have its limits dodged by sending that header. Now it's only trusted
  when you set `TRUST_CLOUDFLARE_IP=1` (documented, and on the launch checklist).
- Behind a proxy, Next refuses button requests whose address doesn't match; the
  site's own address (`SITE_URL`) is now named to it.
- The "Feature" admin action now finds the deal from its address alone and checks rank
  and clashes, like the other actions. "Remove programme" in Earnings now asks first.
- "Hide from search engines" never reached the homepage or deal pages (their own robots
  tag overrode it); now enforced with a header on every page. Test copies are always hidden.
- An empty `DEALSNAP_DATA_DIR` is treated as unset, not as the root folder.
- Checked and clean: SQL (every query is parameterised; the dynamic parts come from
  fixed lists), HTML injection (the 6 places that insert HTML are sanitised or escaped),
  every download/upload/API route has its guard and limit, cookies are HttpOnly/Lax/Secure,
  password reset doesn't reveal who has an account, `npm audit` finds 0 problems.

**Accessibility** (axe, WCAG 2.1 AA): 0 serious findings remain except the orange above.
- Sign-up fields weren't linked to their labels; admin search boxes, two text areas and
  hidden previews had no names; an image-only link had none.
- Grey secondary text (`zinc-400`, 2.6:1) darkened to `zinc-500` (4.8:1) in ~460 places
  (dark mode unchanged); orange link text 600→700, green 600→700, small text on grey chips.

**Search engines**: deal page titles keep the price and store visible when the deal's
title is long; the sitemap is capped at 40,000 deals (newest first) so it never exceeds
what Google reads; titles, descriptions, canonical addresses and one main heading
verified on every public page.

**First impression**: a brand-new site with no deals now invites the first post instead of
saying "No deals found. Try another search".

**Scalability** (see `docs/HOSTING.md` → How it copes with growth)
- Admin Deals, Members, Comments and the dashboard are answered by the database a page
  at a time: 0.04–0.3 s at 200,000 deals (was 0.4–1.8 s at only 50,000).
- The public lists and search are built from recent deals only (a setting, a year by
  default); older deals keep their page. With 200,000 deals (120-day window then): 468 MB (was 2.8 GB), 85 ms
  median with 20 visitors at once, 0.35 s to rebuild after a change (was ~2 s).
- Each deal keeps its own heart total (database triggers), so votes are never re-added;
  a store has one name across all its deals, old or new; new indexes for the admin lists.
- The admin's hearts and "ended by members" now count votes the way the public site does
  (they disagreed before).

**Running it**: `/api/health` for the host and an uptime monitor; tidy shutdown;
hourly database tune-up; Dockerfile + compose + Litestream (off-server backups);
`.env.example`; Admin → Launch checklist (checks itself); Site health (errors, email
alert); a test copy (`npm run staging`); screen tests in GitHub's checks.

## Not fixed, on purpose or for later

- **The Docker image hasn't been built here** (no Docker on this Mac). I did build and
  run the same "standalone" output it uses (health check, pages, static files, empty
  site all fine), but expect to fix a small thing on the first real build.
- **Older deals aren't searchable.** Deals older than the list window keep their page but
  don't appear in lists or search. If you want them findable, raise the window or add an
  "older deals" search later (SQLite full-text search would do it).
- **The Stores admin page and the waiting queue's repost check** still read from the
  in-memory catalogue, so the first visit after a change costs ~1–2 s at 200,000 deals.
  Fine for years; the next scaling step is moving public browsing and search to SQL.
- **Settings page has two top headings** (the account hub's and its own); cosmetic.
- **Content-Security-Policy has no `script-src`** because Admin → Tracking & code takes
  pasted scripts from any service. Keep that box to trusted services (it's on the checklist).
- **Foreign keys aren't enforced by the database**; the code removes related rows itself,
  and is tested. Worth turning on after launch, with a clean-up pass.
- **Legal**: have the Terms and Privacy policy read by someone qualified, register with
  the ICO (the yearly fee), and fill in Company details. Not code.
- **Email deliverability** (SPF, DKIM, DMARC) is DNS work at your domain; steps are in
  `docs/HOSTING.md`. Send yourself a password reset and check it lands in the inbox.

## Repeat before launch day

1. `npm run check && npm run e2e` (should all pass; the audit should report 0 serious).
2. Admin → Launch checklist: every "Before you launch" item green except "Search engines".
3. Restore a backup once into a spare folder (HOSTING.md step 6).
4. Click through sign-up → post a deal → approve it → love it → get-deal on your phone,
   on the real domain, with real email.
