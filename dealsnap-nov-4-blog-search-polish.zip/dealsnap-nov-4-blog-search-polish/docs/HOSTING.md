# Putting DealSnap on a domain and hosting

This is the path from "the code on my laptop" to "live on my domain". The code is
ready for it: nothing here needs changing in the site itself, only accounts and
settings. Allow an afternoon.

## 1. What to buy

DealSnap keeps its data in one file (SQLite), which makes it fast and cheap to run,
but it means **one copy of the site on one server with a permanent disk**. That rules
out "serverless" hosts (Vercel, Netlify) and anything that runs several copies. It
suits a small always-on server:

| Option | About | Notes |
| --- | --- | --- |
| **A VPS with Docker** (Hetzner CX22, ~€4–5/month; DigitalOcean, Linode similar) | Cheapest, simplest to understand, you can see the whole machine | Recommended. Ubuntu + Docker, using the `docker-compose.yml` here |
| **Fly.io** | Runs the Dockerfile, with a "volume" for the disk | Good if you'd rather not manage a server. One machine, one volume |
| **Railway / Render** | Runs the Dockerfile, with a persistent disk | Fine; check the disk is attached before the first deploy |

Size: **2 GB of memory** carries a launch comfortably. The site's memory follows how
many deals are recent (see "How it copes with growth" below), not how many there are
in total; move to 4 GB if it starts to feel tight.

You also need:
- a **domain** (Cloudflare Registrar sells at cost; Namecheap/Porkbun are fine);
- a free **Cloudflare** account to put in front of it (https, caching, protection);
- a free **Resend** account for emails (password resets, alerts, confirmations).

## 2. The first deploy (VPS with Docker)

1. On the server: install Docker (`curl -fsSL https://get.docker.com | sh`).
2. Copy the project to the server (`git clone` your repository, or `scp`).
3. `cp .env.example .env` and fill it in. At minimum: `SITE_URL`, `ADMIN_EMAIL`. Add
   the email and Turnstile keys as you get them (steps 4 and 5).
4. `docker compose up -d --build`. The first build takes a few minutes.
5. Check it: `curl http://127.0.0.1:3000/api/health` should say `{"ok":true}`.
6. Point the domain at it (step 3), then open the site.
7. Sign up with the email you put in `ADMIN_EMAIL`, then open `/admin-claim` once:
   you're now the admin. (Nobody else can claim it.)
8. Open **Admin → Launch checklist**. It lists everything still to do, and ticks
   items off by itself.

To update later: `git pull && docker compose up -d --build`. The data lives on the
`dealsnap-data` volume, so updating never touches it. To roll back, check out the
earlier version and run the same command.

## 3. Domain and Cloudflare

1. Add the domain to Cloudflare and change the domain's nameservers to the two
   Cloudflare gives you.
2. Add a DNS record: `A` for `@` (and `www`) → your server's IP, **proxied** (orange cloud).
3. SSL/TLS → set the mode to **Full (strict)**, and under Edge Certificates turn on **Always Use HTTPS**. For the origin's certificate either
   use Cloudflare's free *Origin Certificate*, or let Caddy get one:
   `docker compose --profile caddy up -d` with `DOMAIN=dealsnap.co.uk` in `.env`.
4. Redirect `www` to the bare domain (Rules → Redirect Rules) or the other way round.
5. Security → **Bot Fight Mode** on, and **Block AI bots** on (robots.txt already asks
   AI crawlers to stay away; this enforces it).
6. Security → WAF → **Rate limiting rules**: `/login`, `/signup`, `/submit`, about 30
   requests a minute per visitor; and a looser one for `/api/search`, `/api/deals`
   and `/go/` (about 120 a minute). The site has its own limits as a backstop.
7. Lock the server so only Cloudflare can reach it (the firewall allows ports 80/443
   only from [Cloudflare's addresses](https://www.cloudflare.com/ips/)), **then** set
   `TRUST_CLOUDFLARE_IP=1` in `.env`. That makes the site use Cloudflare's visitor
   address for its sign-up/login/posting limits. Without the firewall, leave it unset.
8. Caching: leave Cloudflare's defaults. Pages are personal (signed-in state) so the
   site marks them private; pictures carry their own long cache headers.

## 4. Emails (Resend)

1. resend.com → Domains → add your domain, then add the DNS records it shows (SPF,
   DKIM). Wait for "Verified".
2. API Keys → create one. In `.env`: `RESEND_API_KEY=…` and
   `EMAIL_FROM="DealSnap <alerts@yourdomain>"`.
3. Restart (`docker compose up -d`). Admin → Launch checklist now shows emails as
   sending. Send yourself a "Forgot password?" to check it arrives (not in spam).
4. Add a DMARC record (`_dmarc` TXT: `v=DMARC1; p=none; rua=mailto:you@yourdomain`),
   which Gmail and Yahoo expect from bulk senders.

## 5. Bot protection, Google sign-in (optional but recommended)

- **Turnstile** (free): Cloudflare → Turnstile → add a widget for your domain; put the
  two keys in `.env`.
- **Continue with Google**: Google Cloud → APIs & Services → Credentials → OAuth client
  (Web). Authorised redirect: `https://yourdomain/auth/google/callback`. Put the id and
  secret in `.env`.

## 6. Backups: the one thing not to skip

The site makes a daily copy of its database on the server (Admin → Settings → Data &
backups), but a copy on the same disk doesn't survive losing the server.

**Litestream** (built into the Docker image) copies every change to cloud storage as
it happens, and restores it on its own if the disk is ever empty:

1. Create a bucket (Cloudflare R2 has a generous free tier) and an access key for it.
2. In `.env`: `LITESTREAM_REPLICA_URL=s3://your-bucket/dealsnap`,
   `LITESTREAM_ACCESS_KEY_ID`, `LITESTREAM_SECRET_ACCESS_KEY`, and for R2
   `LITESTREAM_ENDPOINT=https://<account>.r2.cloudflarestorage.com`.
3. `docker compose up -d`. The checklist shows backups as copied off the server.
4. **Practise a restore once**, on a spare folder: `litestream restore -o test.db
   s3://your-bucket/dealsnap`, then open it. A backup you've never restored is a hope,
   not a backup.

(If your host snapshots the disk for you instead, switch that on and set
`OFFSITE_BACKUPS=confirmed`.)

### Members' pictures

Pictures in deal descriptions, Community posts and comments are files, not part of
the database, so Litestream doesn't copy them. By default they sit in
`<data folder>/pictures`. To keep them in the same R2 account instead (they're then
safe if the server goes, and the disk never fills up):

1. Make a second bucket (e.g. `dealsnap-pictures`, kept private) and an access key
   that can read and write it.
2. In `.env`: `PICTURES_S3_ENDPOINT=https://<account>.r2.cloudflarestorage.com`,
   `PICTURES_S3_BUCKET=dealsnap-pictures`, `PICTURES_S3_KEY_ID`, `PICTURES_S3_SECRET`
   (and `PICTURES_S3_REGION` for anything but R2, which uses `auto`).
3. `docker compose up -d`. Pictures already on the disk move across by themselves,
   a few hundred an hour; until each one has, the site still finds it on the disk.

The site still serves every picture itself (`/picture/<id>/…`, and deal photos at
`/deal-image/…`), so a taken-down post's pictures stop being served straight away.
Browsers keep a picture for a day and Cloudflare for an hour, so it's gone from
everywhere within the hour, and for anyone who already had it, within a day.

**Backing up pictures kept on the disk.** Admin → Settings → Data & backups has two
downloads that together are the whole site: *Download database backup* (what Restore
uses) and *Download pictures* (a `.tar.gz` of the picture files). To put pictures back
on a new server, unpack that file into the data folder (it holds a `pictures/`
folder), e.g. `tar -xzf dealsnap-pictures-….tar.gz -C <data folder>`. With cloud
picture storage there's nothing to download: the provider keeps its own copies.

## 7. Launch day

1. Admin → **Launch checklist**: everything under "Before you launch" should be green
   except "Search engines may find the site".
2. Admin → Pages → **Company details**: your company, ICO number, real contact emails.
3. Have the Terms and Privacy policy read by someone qualified.
4. Post a handful of real deals yourself so the first visitors find a living site.
5. Admin → Settings → General → turn off **Hide from search engines**, paste your
   **Google Search Console** code, and submit `https://yourdomain/sitemap.xml` there.
6. Add the site to an uptime monitor (UptimeRobot or Better Stack, both free): watch
   `https://yourdomain/api/health` every minute and have it email/text you.
7. Check **Admin → Site health** a few times in the first days: anything that breaks
   for a visitor shows up there, and in the admin alert email once you tick it on.

## How it copes with growth

- **The lists and search** are built from deals posted in the last 365 days (Admin → Settings → General: "Lists and search reach back this many
  days"). Older deals keep their own page, so links and Google results never break.
  Memory and speed follow how many deals fall inside that window, not how many
  there are in total: tested (with a 120-day window) with 200,000 deals, almost all older, the site used
  under 500 MB and answered 20 simultaneous visitors in about 0.1 s each. The window
  starts at a year and can't go lower, because Most loved's "Last 12 months" needs
  it. Watch the server's memory as the deals in the last year build up; at hundreds of
  deals a day, size the server up before the lists get heavy (next step after that:
  moving the public lists to the database).
- **Admin lists** (Deals, Members, Comments, Activity) are answered by the database one
  page at a time, so they cost the same at 500 or 500,000 rows.
- **Watch these**: memory (`docker stats`), disk space (`df -h`), and the Admin → Site
  health page. When memory passes about 70% of the server's, resize the server (it's a
  button on every host, and the data volume stays).
- **One copy only.** Don't run two copies against one database. If traffic ever
  outgrows one good server (many hundreds of thousands of visits a day), that's the
  moment to move the database to a hosted one (Postgres): a project, not a setting.

## If something goes wrong

- *Site down:* `docker compose logs --tail 100 dealsnap`; `docker compose restart`.
- *Bad deploy:* check out the previous version, `docker compose up -d --build`.
- *Lost the server:* make a new one, install Docker, copy `.env`, `docker compose up -d
  --build`: Litestream brings the database back from the bucket on its own.
- *Locked out of admin:* another admin can reset your two-step login from Admin → Members. If you're the only admin, restore the latest backup into a spare folder, and ask for help from whoever set the server up.
