#!/bin/sh
# Starts the site. With LITESTREAM_REPLICA_URL set it also copies every change to
# the database off the server as it happens, and, on a brand-new disk, first
# brings the latest copy back (so a lost server is a restart, not a disaster).
set -e
if [ -n "$LITESTREAM_REPLICA_URL" ]; then
  litestream restore -if-db-not-exists -if-replica-exists -config /etc/litestream.yml "$DEALSNAP_DATA_DIR/dealsnap.db" || true
  exec litestream replicate -config /etc/litestream.yml -exec "node server.js"
fi
exec node server.js
