// The toolbar popup: the DealSnap panel (see panel.js), plus the switches
// for the floating bubble and the right-click menu.
const style = document.createElement("style");
style.textContent = DS_PANEL_CSS;
document.head.appendChild(style);

chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
  const url = tab?.url || "";
  const onShopPage = /^https?:/.test(url) && !url.startsWith(DEALSNAP_CONFIG.API_BASE);

  const panel = dealsnapPanel(document.getElementById("app"), {
    pageUrl: onShopPage ? url : undefined,
    // Reads the page in the tab, the same way the bubble does (page-reader.js).
    readPage: async () => {
      // Reading pages is a permission added in version 0.2; Chrome only
      // grants it once the extension is reloaded.
      if (!chrome.scripting) throw new Error("reload");
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["page-reader.js"] });
      const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => dealsnapReadPage() });
      return result;
    },
    onDone: () => window.close(),
  });
  if (!onShopPage) panel.focusSearch();
});

// The switches at the bottom: the bubble and the right-click menu (both on
// unless switched off).
for (const [id, key] of [
  ["bubble-toggle", "dealsnapBubbleEnabled"],
  ["menu-toggle", "dealsnapMenuEnabled"],
]) {
  const box = document.getElementById(id);
  chrome.storage.local.get([key], (result) => {
    box.checked = result[key] !== false;
  });
  box.addEventListener("change", () => chrome.storage.local.set({ [key]: box.checked }));
}
