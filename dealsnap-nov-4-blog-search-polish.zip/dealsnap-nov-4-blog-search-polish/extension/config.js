// Point this at your live site once DealSnap is deployed (and change
// host_permissions in manifest.json to match).
const DEALSNAP_CONFIG = {
  API_BASE: "http://localhost:3000",
};
