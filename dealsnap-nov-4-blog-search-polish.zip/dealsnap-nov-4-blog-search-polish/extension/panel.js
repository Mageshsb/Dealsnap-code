// The DealSnap panel: the same in the toolbar popup and the floating bubble,
// so the extension looks and works one way everywhere. It talks to DealSnap
// through background.js.

// The site's logo (app/icon.svg) and line icons from Lucide, the site's icon set.
const DS_LOGO =
  '<svg viewBox="0 0 24 24" aria-hidden="true"><g transform="rotate(-45 11 13)"><path d="M11 2.2L18 8.6V21.5C18 22.6 17.2 23.4 16.1 23.4H5.9C4.8 23.4 4 22.6 4 21.5V8.6Z" fill="#f97316"/><circle cx="11" cy="8.2" r="1.7" fill="#fff"/></g><circle cx="11.6" cy="14.6" r="5.4" fill="#fff"/><circle cx="11.6" cy="14.6" r="4.2" fill="#ef4444"/><path d="M13.4 12.9C13.1 12.2 12.5 11.8 11.7 11.8C10.7 11.8 10.1 12.5 10.1 13.5V16.9M9 17H14.3M9 14.8H12.4" fill="none" stroke="#fff" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M19.6 1L20.7 3.6L23.3 4.7L20.7 5.8L19.6 8.4L18.5 5.8L15.9 4.7L18.5 3.6Z" fill="#f59e0b"/></svg>';
const dsIcon = (paths, size = 14) =>
  `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;
const DS_ICONS = {
  plus: dsIcon('<path d="M12 5v14M5 12h14"/>', 16),
  close: dsIcon('<path d="M18 6 6 18"/><path d="m6 6 12 12"/>', 16),
  tag: dsIcon('<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/>'),
  grid: dsIcon('<rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>'),
  store: dsIcon('<path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M2 7h20"/><path d="M22 7v3a2 2 0 0 1-2 2a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 16 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 12 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 8 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 4 12a2 2 0 0 1-2-2V7"/>'),
  ticket: dsIcon('<path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/><path d="M13 5v2"/><path d="M13 17v2"/><path d="M13 11v2"/>'),
  check: dsIcon('<path d="M20 6 9 17l-5-5"/>'),
  hourglass: dsIcon('<path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/>'),
  search: dsIcon('<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>'),
  bell: dsIcon('<path d="M10.268 21a2 2 0 0 0 3.464 0"/><path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326"/>', 16),
  bookmark: dsIcon('<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>', 15),
  heart: dsIcon('<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>', 15),
};

const DS_PANEL_CSS = `
  .ds-panel, .ds-panel * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
  .ds-panel { display: flex; flex-direction: column; width: 100%; max-height: inherit; background: #fafafa; color: #18181b; font-size: 13px; line-height: 1.35; }
  .ds-header { display: flex; align-items: center; justify-content: space-between; padding: 10px 12px; background: #fff; border-bottom: 1px solid #e4e4e7; }
  .ds-logo { display: inline-flex; align-items: center; gap: 6px; font-weight: 700; font-size: 15px; }
  .ds-logo svg { width: 22px; height: 22px; }
  .ds-close { display: flex; padding: 4px; border: none; border-radius: 999px; background: none; color: #71717a; cursor: pointer; }
  .ds-close:hover { background: #f4f4f5; color: #18181b; }
  .ds-body { display: flex; flex-direction: column; gap: 10px; padding: 10px; overflow-y: auto; }
  .ds-post-btn { display: flex; align-items: center; justify-content: center; gap: 6px; width: 100%; padding: 10px 14px; border: none; border-radius: 999px; background: #f97316; color: #fff; font-size: 14px; font-weight: 600; cursor: pointer; }
  .ds-post-btn:hover { background: #ea580c; }
  .ds-post-btn:disabled { opacity: 0.6; cursor: default; }
  .ds-note { padding: 4px 4px 0; font-size: 12px; color: #71717a; text-align: center; }
  .ds-note:empty { display: none; }
  .ds-shop { display: flex; flex-direction: column; gap: 10px; }
  .ds-shop[hidden] { display: none; }
  .ds-card { display: flex; flex-direction: column; gap: 6px; padding: 10px; border: 1px solid #e4e4e7; border-radius: 12px; background: #fff; }
  .ds-card-title { display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 700; color: #3f3f46; }
  .ds-card-title svg { color: #a1a1aa; flex-shrink: 0; }
  .ds-card.ds-good { border-color: #a7f3d0; background: #ecfdf5; }
  .ds-card.ds-good .ds-card-title, .ds-card.ds-good .ds-card-title svg { color: #047857; }
  .ds-card.ds-wait { border-color: #fde68a; background: #fffbeb; }
  .ds-card.ds-wait .ds-card-title, .ds-card.ds-wait .ds-card-title svg { color: #b45309; }
  .ds-line { font-size: 12px; color: #52525b; }
  .ds-link { padding: 0; border: none; background: none; color: #ea580c; font: inherit; font-weight: 600; cursor: pointer; text-align: left; }
  .ds-link:hover { text-decoration: underline; }
  .ds-codes { display: flex; flex-direction: column; gap: 6px; }
  .ds-code { display: flex; align-items: center; gap: 8px; }
  .ds-code-text { flex-shrink: 0; padding: 4px 8px; border: 1px dashed #8b5cf6; border-radius: 6px; background: #f5f3ff; color: #6d28d9; font-family: ui-monospace, Menlo, monospace; font-size: 12px; font-weight: 700; }
  .ds-code-for { flex: 1; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: 11px; color: #71717a; }
  .ds-copy { flex-shrink: 0; padding: 4px 10px; border: 1px solid #e4e4e7; border-radius: 999px; background: #fff; color: #3f3f46; font-size: 11px; font-weight: 600; cursor: pointer; }
  .ds-copy:hover { border-color: #f97316; color: #ea580c; }
  .ds-search { width: 100%; padding: 8px 12px; border: 1px solid #d4d4d8; border-radius: 999px; background: #fff; font-size: 13px; color: #18181b; outline: none; }
  .ds-search:focus { border-color: #f97316; }
  .ds-status { padding: 0 4px; font-size: 12px; color: #71717a; }
  .ds-status:empty { display: none; }
  .ds-list { display: flex; flex-direction: column; gap: 6px; margin: 0; padding: 0; list-style: none; }
  .ds-heading { padding: 4px 4px 0; font-size: 10px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: #a1a1aa; }
  .ds-suggestion { display: flex; align-items: center; gap: 8px; padding: 7px 8px; border-radius: 8px; font-size: 12.5px; font-weight: 500; cursor: pointer; }
  .ds-suggestion:hover { background: #f4f4f5; }
  .ds-suggestion svg { color: #a1a1aa; flex-shrink: 0; }
  .ds-deal { display: flex; align-items: center; gap: 10px; padding: 8px; border: 1px solid #e4e4e7; border-radius: 10px; background: #fff; cursor: pointer; }
  .ds-deal:hover { border-color: #fdba74; }
  .ds-thumb { display: flex; align-items: center; justify-content: center; width: 40px; height: 40px; flex-shrink: 0; overflow: hidden; border-radius: 8px; background: #f4f4f5; color: #a1a1aa; }
  .ds-thumb img { width: 100%; height: 100%; object-fit: contain; }
  .ds-deal-info { flex: 1; min-width: 0; }
  .ds-deal-title { display: -webkit-box; overflow: hidden; -webkit-line-clamp: 2; -webkit-box-orient: vertical; font-size: 12px; font-weight: 600; }
  .ds-deal-meta { display: flex; align-items: center; gap: 4px; margin-top: 2px; font-size: 11px; color: #71717a; white-space: nowrap; }
  .ds-price { font-weight: 700; color: #ea580c; }
  .ds-off { font-weight: 600; color: #16a34a; }
  .ds-account { display: flex; align-items: center; gap: 4px; margin-left: auto; }
  .ds-signin { padding: 4px 10px; border: 1px solid #e4e4e7; border-radius: 999px; background: #fff; color: #3f3f46; font-size: 12px; font-weight: 600; cursor: pointer; }
  .ds-signin:hover { border-color: #f97316; color: #ea580c; }
  .ds-bell { position: relative; display: flex; padding: 5px; border: none; border-radius: 999px; background: none; color: #52525b; cursor: pointer; }
  .ds-bell:hover { background: #f4f4f5; color: #18181b; }
  .ds-unread { position: absolute; top: -2px; right: -3px; min-width: 16px; height: 16px; padding: 0 4px; border-radius: 999px; background: #ef4444; color: #fff; font-size: 10px; font-weight: 700; line-height: 16px; text-align: center; }
  .ds-actions { display: flex; flex-direction: column; align-items: center; gap: 2px; flex-shrink: 0; }
  .ds-act { display: flex; align-items: center; gap: 3px; padding: 4px 6px; border: none; border-radius: 999px; background: none; color: #a1a1aa; font-size: 11px; font-weight: 600; cursor: pointer; }
  .ds-act:hover { background: #f4f4f5; color: #52525b; }
  .ds-act.ds-loved { color: #ef4444; }
  .ds-act.ds-loved svg, .ds-act.ds-saved svg { fill: currentColor; }
  .ds-act.ds-saved { color: #f97316; }
  .ds-empty { padding: 14px; text-align: center; font-size: 12px; color: #a1a1aa; }
`;

// Text from DealSnap (deal titles are written by members) is always added as
// text, never as page code, so nothing in it can run on the shop's page.
function dsEsc(text) {
  return String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}

function dsAsk(msg) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(msg, (reply) => resolve(chrome.runtime.lastError ? { error: "reload" } : reply || { error: "offline" }));
    } catch {
      // The extension was reloaded while this page was open.
      resolve({ error: "reload" });
    }
  });
}

// options: pageUrl (the shop page it's open on, if any), readPage() (reads
// that page for posting), onClose (shows a close button), onDone (after
// something opened in a new tab).
function dealsnapPanel(root, { pageUrl, readPage, onClose, onDone }) {
  const apiBase = DEALSNAP_CONFIG.API_BASE;
  root.innerHTML = `
    <div class="ds-panel">
      <div class="ds-header">
        <span class="ds-logo">${DS_LOGO}DealSnap</span>
        <span class="ds-account"></span>
        ${onClose ? `<button class="ds-close" type="button" aria-label="Close">${DS_ICONS.close}</button>` : ""}
      </div>
      <div class="ds-body">
        ${
          pageUrl
            ? `<div>
                 <button class="ds-post-btn" type="button">${DS_ICONS.plus}Post this deal</button>
                 <div class="ds-note ds-post-note"></div>
               </div>`
            : ""
        }
        <input class="ds-search" type="search" placeholder="Search deals, e.g. headphones" aria-label="Search DealSnap deals" />
        <div class="ds-status"></div>
        <ul class="ds-list ds-results"></ul>
        ${pageUrl ? `<div class="ds-shop"></div>` : ""}
      </div>
    </div>`;
  const $ = (selector) => root.querySelector(selector);
  const open = (url) => dsAsk({ type: "open", url }).then(() => onDone?.());

  $(".ds-close")?.addEventListener("click", onClose);

  // --- Signed in? -----------------------------------------------------------
  let signedIn = false;
  const signIn = (next) => open(`/login?next=${encodeURIComponent(next)}`);
  dsAsk({ type: "me" }).then((me) => {
    const account = $(".ds-account");
    if (me.error) return;
    signedIn = !!me.user;
    if (me.user) {
      account.innerHTML = `<button class="ds-bell" type="button" title="Notifications" aria-label="Notifications${me.unread ? `, ${dsEsc(me.unread)} new` : ""}">${DS_ICONS.bell}${me.unread ? `<span class="ds-unread">${me.unread > 9 ? "9+" : dsEsc(me.unread)}</span>` : ""}</button>`;
      account.querySelector("button").addEventListener("click", () => open("/notifications"));
    } else {
      account.innerHTML = `<button class="ds-signin" type="button">Sign in</button>`;
      account.querySelector("button").addEventListener("click", () => signIn("/"));
    }
  });

  // --- Post this deal -------------------------------------------------------
  const postBtn = $(".ds-post-btn");
  const postNote = $(".ds-post-note");
  postBtn?.addEventListener("click", async () => {
    const fail = (text) => {
      postBtn.disabled = false;
      postNote.textContent = text;
    };
    postBtn.disabled = true;
    postNote.textContent = "Reading this page…";
    let page;
    try {
      page = await readPage();
    } catch (err) {
      return fail(
        err?.message === "reload"
          ? "Almost there: reload DealSnap on the chrome://extensions page, then try again."
          : "We couldn't read this page. Reload it, then press Post this deal again."
      );
    }
    const reply = await dsAsk({ type: "post", page });
    if (reply.ok) {
      fail("");
      onDone?.();
      return;
    }
    fail(
      reply.error === "offline"
        ? "Couldn't reach DealSnap. Is the site running?"
        : reply.error === "reload"
          ? "DealSnap was updated. Reload this page, then try again."
          : reply.error
    );
  });

  // --- Rows -----------------------------------------------------------------
  function dealRow(deal) {
    const li = document.createElement("li");
    li.className = "ds-deal";
    li.innerHTML = `
      <div class="ds-thumb">${deal.image ? `<img alt="" src="${dsEsc(apiBase + deal.image)}" />` : DS_ICONS.tag}</div>
      <div class="ds-deal-info">
        <div class="ds-deal-title">${dsEsc(deal.title)}</div>
        <div class="ds-deal-meta">
          <span class="ds-price">${dsEsc(deal.priceLabel)}</span>
          ${deal.off > 0 ? `<span class="ds-off">${dsEsc(deal.off)}% off</span>` : ""}
          <span>· ${dsEsc(deal.store)}</span>
          ${deal.expired ? "<span>· Expired</span>" : ""}
        </div>
      </div>
      <div class="ds-actions">
        <button class="ds-act ds-love" type="button" title="Love it" aria-pressed="false">${DS_ICONS.heart}<span>${dsEsc(deal.hearts)}</span></button>
        <button class="ds-act ds-save" type="button" title="Save for later" aria-pressed="false">${DS_ICONS.bookmark}</button>
      </div>`;
    li.dataset.slug = deal.slug;
    // A photo that can't load (an http test site seen from an https shop) falls back to the icon.
    li.querySelector("img")?.addEventListener("error", (e) => (e.target.parentElement.innerHTML = DS_ICONS.tag));
    li.addEventListener("click", () => open(`/deals/${deal.slug}`));

    const love = li.querySelector(".ds-love");
    const save = li.querySelector(".ds-save");
    love.addEventListener("click", async (e) => {
      e.stopPropagation();
      if (!signedIn) return signIn(`/deals/${deal.slug}`);
      const on = !love.classList.contains("ds-loved");
      setPressed(love, "ds-loved", on);
      const reply = await dsAsk({ type: "love", slug: deal.slug, on });
      if (reply.error) setPressed(love, "ds-loved", !on);
      else love.querySelector("span").textContent = reply.hearts;
    });
    save.addEventListener("click", async (e) => {
      e.stopPropagation();
      if (!signedIn) return signIn(`/deals/${deal.slug}`);
      const on = !save.classList.contains("ds-saved");
      setPressed(save, "ds-saved", on);
      save.title = on ? "Saved" : "Save for later";
      const reply = await dsAsk({ type: "save", slug: deal.slug, on });
      if (reply.error) setPressed(save, "ds-saved", !on);
    });
    return li;
  }

  function setPressed(button, className, on) {
    button.classList.toggle(className, on);
    button.setAttribute("aria-pressed", String(on));
  }

  // Shows which listed deals you've already loved and saved.
  async function showState(container) {
    const rows = [...container.querySelectorAll(".ds-deal")];
    if (!rows.length) return;
    const state = await dsAsk({ type: "state", slugs: rows.map((r) => r.dataset.slug) });
    if (state.error) return;
    for (const row of rows) {
      setPressed(row.querySelector(".ds-love"), "ds-loved", state.loved.includes(row.dataset.slug));
      setPressed(row.querySelector(".ds-save"), "ds-saved", state.saved.includes(row.dataset.slug));
    }
  }

  function suggestion(icon, label, path) {
    const li = document.createElement("li");
    li.className = "ds-suggestion";
    li.innerHTML = `${icon}<span>${dsEsc(label)}</span>`;
    li.addEventListener("click", () => open(path));
    return li;
  }

  function heading(label) {
    const li = document.createElement("li");
    li.className = "ds-heading";
    li.textContent = label;
    return li;
  }

  // --- What DealSnap has for this shop ---------------------------------------
  if (pageUrl) {
    dsAsk({ type: "shop", url: pageUrl }).then((shop) => {
      const box = $(".ds-shop");
      if (!box || shop.error) return;
      const parts = [];

      const p = shop.product;
      if (p) {
        const kind = p.state === "live" ? "ds-good" : p.state === "pending" ? "ds-wait" : "";
        const title =
          p.state === "live" ? "Already on DealSnap" : p.state === "pending" ? "Just posted, waiting for approval" : "Posted before (ended)";
        parts.push(`
          <div class="ds-card ${kind}">
            <div class="ds-card-title">${p.state === "pending" ? DS_ICONS.hourglass : DS_ICONS.check}${title}</div>
            ${p.state === "pending" ? `<div class="ds-line">${dsEsc(p.title)} · <strong>${dsEsc(p.priceLabel)}</strong></div>` : `<ul class="ds-list ds-product"></ul>`}
          </div>`);
      }

      if (shop.codes?.length) {
        parts.push(`
          <div class="ds-card">
            <div class="ds-card-title">${DS_ICONS.ticket}Codes for ${dsEsc(shop.store?.name)}</div>
            <div class="ds-codes">
              ${shop.codes
                .map(
                  (c) => `<div class="ds-code"><span class="ds-code-text">${dsEsc(c.code)}</span><span class="ds-code-for">${dsEsc(c.title)}</span><button class="ds-copy" data-code="${dsEsc(c.code)}">Copy</button></div>`
                )
                .join("")}
            </div>
          </div>`);
      }

      if (shop.store && shop.deals?.length) {
        parts.push(`
          <div class="ds-card">
            <div class="ds-card-title">${DS_ICONS.store}${dsEsc(shop.store.count)} deal${shop.store.count === 1 ? "" : "s"} at ${dsEsc(shop.store.name)}</div>
            <ul class="ds-list ds-shop-deals"></ul>
            ${shop.store.slug && shop.store.count > shop.deals.length ? `<button class="ds-link" data-open="/stores/${dsEsc(shop.store.slug)}">See all ${dsEsc(shop.store.count)}</button>` : ""}
          </div>`);
      }

      box.innerHTML = parts.join("");
      box.querySelector(".ds-product")?.appendChild(dealRow(p));
      const list = box.querySelector(".ds-shop-deals");
      if (list) shop.deals.forEach((d) => list.appendChild(dealRow(d)));
      showState(box);
      box.querySelectorAll("[data-open]").forEach((b) => b.addEventListener("click", () => open(b.dataset.open)));
      box.querySelectorAll("[data-code]").forEach((b) =>
        b.addEventListener("click", async () => {
          await navigator.clipboard.writeText(b.dataset.code).catch(() => {});
          b.textContent = "Copied";
          setTimeout(() => (b.textContent = "Copy"), 1500);
        })
      );
    });
  }

  // --- Search ---------------------------------------------------------------
  const input = $(".ds-search");
  const status = $(".ds-status");
  const results = $(".ds-results");
  let timer;
  let latest = 0;

  async function search(q) {
    const id = ++latest;
    status.textContent = "Searching…";
    const data = await dsAsk({ type: "search", q });
    if (id !== latest) return;
    results.innerHTML = "";
    if (data.error) {
      status.textContent = data.error === "reload" ? "DealSnap was updated. Reload this page, then try again." : "Couldn't reach DealSnap. Is the site running?";
      return;
    }
    const { categories = [], tags = [], stores = [], results: deals = [] } = data;
    status.textContent = "";
    if (!categories.length && !tags.length && !stores.length && !deals.length) {
      results.innerHTML = `<li class="ds-empty">No matches found.</li>`;
      return;
    }
    if (deals.length) {
      results.appendChild(heading("Deals"));
      deals.forEach((d) => results.appendChild(dealRow(d)));
      showState(results);
    }
    if (stores.length) {
      results.appendChild(heading("Stores"));
      stores.forEach((s) => results.appendChild(suggestion(DS_ICONS.store, s.name, `/stores/${s.slug}`)));
    }
    if (categories.length || tags.length) {
      results.appendChild(heading("Browse"));
      categories.forEach((c) => results.appendChild(suggestion(DS_ICONS.grid, c.name, `/categories/${c.slug}`)));
      tags.forEach((t) => results.appendChild(suggestion(DS_ICONS.tag, t.name, `/tags/${t.slug}`)));
    }
  }

  input.addEventListener("input", () => {
    clearTimeout(timer);
    const q = input.value.trim();
    // Search results take the shop's place while there's a search.
    const shopBox = $(".ds-shop");
    if (shopBox) shopBox.hidden = !!q;
    if (!q) {
      latest++;
      status.textContent = "";
      results.innerHTML = "";
      return;
    }
    timer = setTimeout(() => search(q), 300);
  });
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && input.value.trim()) {
      clearTimeout(timer);
      search(input.value.trim());
    }
  });

  return { focusSearch: () => input.focus() };
}
