// Does the extension's talking to DealSnap, for the toolbar popup and the
// floating bubble alike. (The bubble lives inside shop pages, which aren't
// allowed to call DealSnap themselves.) Also keeps the count on the icon.
// (Firefox loads config.js itself, listed before this file in its manifest.)
if (typeof importScripts === "function") importScripts("config.js");

const API = DEALSNAP_CONFIG.API_BASE;

// With your DealSnap sign-in, so hearts, saves and alerts are yours.
async function getJson(path) {
  const res = await fetch(`${API}${path}`, { credentials: "include" });
  if (!res.ok) throw new Error(`DealSnap answered ${res.status}`);
  return res.json();
}

async function postJson(path, body) {
  const res = await fetch(`${API}${path}`, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  return res.ok ? data : { error: data.error || "DealSnap couldn't do that. Try again in a moment." };
}

async function handle(msg, sender) {
  if (msg.type === "search") return getJson(`/api/search?q=${encodeURIComponent(msg.q)}`);
  if (msg.type === "shop") return getJson(`/api/extension/shop?url=${encodeURIComponent(msg.url)}`);
  if (msg.type === "me") return getJson("/api/extension/me");
  if (msg.type === "state") return getJson(`/api/extension/state?slugs=${encodeURIComponent(msg.slugs.join(","))}`);
  if (msg.type === "love") return postJson("/api/extension/love", { slug: msg.slug, on: msg.on });
  if (msg.type === "save") return postJson("/api/extension/save", { slug: msg.slug, on: msg.on });
  if (msg.type === "open") {
    await chrome.tabs.create({ url: msg.url.startsWith("/") ? `${API}${msg.url}` : msg.url });
    return { ok: true };
  }
  if (msg.type === "post") return postPage(msg.page);
  if (msg.type === "read-link") return readLinkForForm(msg.url, sender?.tab);
  return { error: "Unknown request" };
}

// Sends a page read in the shopper's browser (page-reader.js) to DealSnap,
// and opens the post form with it filled in.
async function postPage(page) {
  const data = await postJson("/api/extension/read", page);
  if (!data.ticket) return { error: data.error || "DealSnap couldn't read this page. Try again in a moment." };
  await chrome.tabs.create({ url: `${API}/submit?read=${encodeURIComponent(data.ticket)}` });
  return { ok: true };
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  handle(msg, sender).then(reply, () => reply({ error: "offline" }));
  return true; // answering later
});

// ---------------------------------------------------------------------------
// The count on the icon: how many live deals DealSnap has for the shop you're
// on. The list of shops is downloaded every few hours and matched here, so
// the pages you visit are never sent anywhere.
// ---------------------------------------------------------------------------

function shopHost(url) {
  try {
    return new URL(url).hostname.toLowerCase().replace(/^(www\d?|m|uk)\./, "");
  } catch {
    return "";
  }
}

async function refreshShops() {
  try {
    const { shops } = await getJson("/api/extension/shops");
    await chrome.storage.local.set({ dealsnapShops: shops });
  } catch {
    // Offline: keep the last list.
  }
}

async function updateBadge(tabId, url) {
  const { dealsnapShops = {} } = await chrome.storage.local.get("dealsnapShops");
  const count = /^https?:/.test(url || "") && !url.startsWith(API) ? dealsnapShops[shopHost(url)] : 0;
  await chrome.action.setBadgeText({ tabId, text: count ? (count > 99 ? "99+" : String(count)) : "" });
  if (count) {
    await chrome.action.setBadgeBackgroundColor({ tabId, color: "#f97316" });
    await chrome.action.setBadgeTextColor?.({ tabId, color: "#ffffff" });
    await chrome.action.setTitle({ tabId, title: `DealSnap: ${count} deal${count === 1 ? "" : "s"} at this store` });
  } else {
    await chrome.action.setTitle({ tabId, title: "DealSnap" });
  }
}

chrome.runtime.onInstalled.addListener(refreshShops);
chrome.runtime.onStartup.addListener(refreshShops);
chrome.alarms.create("dealsnap-shops", { periodInMinutes: 180 });
chrome.alarms.onAlarm.addListener((alarm) => alarm.name === "dealsnap-shops" && refreshShops());

chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
  if (change.url || change.status === "complete") updateBadge(tabId, tab.url);
});
chrome.tabs.onActivated.addListener(({ tabId }) => chrome.tabs.get(tabId, (tab) => updateBadge(tabId, tab?.url)));

// ---------------------------------------------------------------------------
// Desktop notifications: your DealSnap notifications (alerts, deals you
// saved getting popular, replies…) pop up on your computer too.
// Checked every few minutes; only new ones are shown.
// ---------------------------------------------------------------------------

async function checkNotifications() {
  const { dealsnapLastNotice } = await chrome.storage.local.get("dealsnapLastNotice");
  let items;
  try {
    ({ items } = await getJson(`/api/extension/notifications?after=${dealsnapLastNotice ?? 0}`));
  } catch {
    return; // Offline, or DealSnap isn't running.
  }
  const newest = Math.max(dealsnapLastNotice ?? 0, ...items.map((n) => n.id));
  await chrome.storage.local.set({ dealsnapLastNotice: newest });
  // The first check after installing only notes where things are, so you
  // aren't greeted by a pile of old notices.
  if (dealsnapLastNotice === undefined || !items.length) return;
  for (const n of items.slice(0, 3)) {
    chrome.notifications.create(`dealsnap-${n.id}`, {
      type: "basic",
      iconUrl: "icons/icon-128.png",
      title: "DealSnap",
      message: n.text,
    });
  }
}

chrome.alarms.create("dealsnap-notices", { periodInMinutes: 5 });
chrome.alarms.onAlarm.addListener((alarm) => alarm.name === "dealsnap-notices" && checkNotifications());
chrome.runtime.onInstalled.addListener(checkNotifications);
chrome.notifications.onClicked.addListener((id) => {
  const n = id.replace(/^dealsnap-/, "");
  chrome.tabs.create({ url: `${API}/notifications/open/${n}` });
  chrome.notifications.clear(id);
});

// ---------------------------------------------------------------------------
// Right-click "Post to DealSnap" (on unless switched off in the popup). On a
// shop page, the page is read in your browser like the Post this deal
// button. On a link, the product page is opened in a tab behind this one,
// read there the same way (so it works on shops that turn DealSnap's own
// reader away), and closed again. Nothing runs until you choose it.
// ---------------------------------------------------------------------------

const WEB_PAGES = ["http://*/*", "https://*/*"];

async function syncMenus() {
  const { dealsnapMenuEnabled } = await chrome.storage.local.get("dealsnapMenuEnabled");
  await chrome.contextMenus.removeAll();
  if (dealsnapMenuEnabled === false) return;
  chrome.contextMenus.create({ id: "dealsnap-post-page", title: "Post this deal to DealSnap", contexts: ["page", "image"], documentUrlPatterns: WEB_PAGES });
  chrome.contextMenus.create({ id: "dealsnap-post-link", title: "Post this link to DealSnap", contexts: ["link"], targetUrlPatterns: WEB_PAGES });
}

chrome.runtime.onInstalled.addListener(syncMenus);
chrome.runtime.onStartup.addListener(syncMenus);
chrome.storage.onChanged.addListener((changes, area) => area === "local" && changes.dealsnapMenuEnabled && syncMenus());

const postFormFor = (link) => `${API}/submit?url=${encodeURIComponent(link)}`;
const wait = (ms) => new Promise((done) => setTimeout(done, ms));

// Resolves once the tab has finished loading, or after `ms` regardless (some
// shops never quite finish).
function loaded(tabId, ms) {
  return new Promise((done) => {
    const finish = () => {
      chrome.tabs.onUpdated.removeListener(watch);
      clearTimeout(timer);
      done();
    };
    const watch = (id, change) => id === tabId && change.status === "complete" && finish();
    const timer = setTimeout(finish, ms);
    chrome.tabs.onUpdated.addListener(watch);
    chrome.tabs.get(tabId).then((tab) => tab.status === "complete" && finish(), finish);
  });
}

// Opens a link in a tab behind this one, reads the product page it lands on
// (after any redirects) with content.js, then closes it.
async function readLinkInBrowser(link, besideTab) {
  const tab = await chrome.tabs.create({ url: link, active: false, index: besideTab ? besideTab.index + 1 : undefined });
  try {
    await loaded(tab.id, 15000);
    // Shops often put the price in a moment after the page loads.
    for (let tries = 0; tries < 6; tries++) {
      await wait(800);
      const page = await chrome.tabs.sendMessage(tab.id, { type: "dealsnap-read-page" }).catch(() => null);
      if (typeof page?.url === "string" && typeof page?.html === "string") return page;
    }
    return null;
  } finally {
    chrome.tabs.remove(tab.id).catch(() => {});
  }
}

// DealSnap's post form asking, when a shop won't let DealSnap read a pasted
// link: read it here, as the right-click does, and hand back the ticket for
// what was read. It opens the page signed in as the shopper, so it's kept
// to exactly that: asked by the post form itself (see content.js), one link
// at a time, and only a shop DealSnap knows (the list kept for the icon's
// count), so nothing on a page could use it to read someone's other sites.
let readingForForm = false;
async function readLinkForForm(link, formTab) {
  if (typeof link !== "string" || !/^https?:\/\//i.test(link) || link.startsWith(API)) return { error: "notlink" };
  if (readingForForm || !formTab?.url?.startsWith(`${API}/submit`)) return { error: "notallowed" };
  const { dealsnapShops = {} } = await chrome.storage.local.get("dealsnapShops");
  if (!dealsnapShops[shopHost(link)]) return { error: "notshop" };
  readingForForm = true;
  try {
    const page = await readLinkInBrowser(link, formTab);
    if (!page) return { error: "unread" };
    const data = await postJson("/api/extension/read", page);
    return data.ticket ? { ticket: data.ticket } : { error: "unread" };
  } finally {
    readingForForm = false;
  }
}

// Reads a page in the tab it's open in (the right-click was on it).
async function readTab(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ["page-reader.js"] });
  const [{ result }] = await chrome.scripting.executeScript({ target: { tabId }, func: () => dealsnapReadPage() });
  return result;
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const isLink = info.menuItemId === "dealsnap-post-link";
  const link = isLink ? info.linkUrl : info.pageUrl || tab?.url;
  if (!link || (!isLink && info.menuItemId !== "dealsnap-post-page")) return;
  if (link.startsWith(API)) {
    chrome.tabs.create({ url: `${API}/submit` });
    return;
  }
  // "…" on the icon while it reads, as a link can take a few seconds.
  const tabId = tab?.id;
  if (tabId) chrome.action.setBadgeText({ tabId, text: "…" });
  try {
    const page = isLink ? await readLinkInBrowser(link, tab) : tabId ? await readTab(tabId) : null;
    if (page && (await postPage(page)).ok) return;
  } catch {
    // Fall through to the link.
  } finally {
    if (tabId) updateBadge(tabId, tab.url);
  }
  // Couldn't read it here: DealSnap's post form tries the link itself.
  chrome.tabs.create({ url: postFormFor(link) });
});
