// The floating DealSnap bubble on shop pages: tap it for the same panel as
// the toolbar button (Post this deal, what DealSnap has for this shop,
// search). It can be switched off in the toolbar popup.
//
// Also reads the page when the right-click "Post this link to DealSnap" has
// opened it in a tab behind (see background.js).
(function () {
  // Not twice.
  if (window.dealsnapContentLoaded) return;
  window.dealsnapContentLoaded = true;

  // On DealSnap itself, no bubble: just a way for its post form to ask the
  // extension to read a link from a shop that won't let DealSnap read it
  // (see readLinkForForm in background.js). The form sees it's here from
  // the page's data-dealsnap-extension.
  if (location.href.startsWith(DEALSNAP_CONFIG.API_BASE)) {
    document.documentElement.dataset.dealsnapExtension = chrome.runtime.getManifest().version;
    window.addEventListener("message", (event) => {
      const msg = event.data;
      if (event.source !== window || event.origin !== location.origin || msg?.dealsnap !== "read-link" || location.pathname !== "/submit") return;
      chrome.runtime.sendMessage({ type: "read-link", url: msg.url }, (reply) => {
        void chrome.runtime.lastError;
        window.postMessage({ dealsnap: "read-link-reply", id: msg.id, ticket: reply?.ticket, error: reply?.error ?? (reply ? undefined : "offline") }, location.origin);
      });
    });
    return;
  }

  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (msg?.type === "dealsnap-read-page") reply(dealsnapReadPage());
  });

  // The bubble is only built if it's switched on, so with it off this is
  // all that runs on a page.
  let host;
  function show(on) {
    if (on && !host) host = buildBubble();
    if (host) host.style.display = on ? "block" : "none";
  }
  chrome.storage.local.get(["dealsnapBubbleEnabled"], (result) => show(result.dealsnapBubbleEnabled !== false));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.dealsnapBubbleEnabled) show(changes.dealsnapBubbleEnabled.newValue !== false);
  });

  function buildBubble() {
    const host = document.createElement("div");
    host.id = "dealsnap-host";
    host.style.all = "initial";
    document.documentElement.appendChild(host);

    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        :host { all: initial; }
        ${DS_PANEL_CSS}
        .wrap { position: fixed; right: 20px; bottom: 20px; z-index: 2147483647; display: flex; flex-direction: column; align-items: flex-end; gap: 10px; }
        .sheet { display: none; width: 340px; max-width: calc(100vw - 40px); max-height: min(560px, calc(100vh - 110px)); overflow: hidden; border: 1px solid #e4e4e7; border-radius: 16px; box-shadow: 0 10px 34px rgba(0,0,0,0.22); }
        .sheet.open { display: flex; }
        .bubble { position: relative; display: flex; align-items: center; justify-content: center; width: 56px; height: 56px; padding: 0; border: 2px solid #f97316; border-radius: 999px; background: #fff; box-shadow: 0 4px 14px rgba(0,0,0,0.22); cursor: pointer; transition: transform 0.15s ease; }
        .bubble:hover { transform: scale(1.06); }
        .bubble svg { width: 34px; height: 34px; }
        .count { position: absolute; top: -4px; right: -4px; min-width: 20px; height: 20px; padding: 0 5px; border: 2px solid #fff; border-radius: 999px; background: #f97316; color: #fff; font: 700 11px/16px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; text-align: center; }
        .count:empty { display: none; }
      </style>
      <div class="wrap">
        <div class="sheet" id="sheet"></div>
        <button class="bubble" id="bubble" type="button" aria-label="Open DealSnap" title="DealSnap">${DS_LOGO}<span class="count" id="count"></span></button>
      </div>
    `;

    const sheet = shadow.getElementById("sheet");
    const bubble = shadow.getElementById("bubble");
    let panel;

    function close() {
      sheet.classList.remove("open");
    }

    bubble.addEventListener("click", () => {
      if (sheet.classList.toggle("open")) {
        // Built when first opened, so the shop is only looked up if you ask.
        panel ??= dealsnapPanel(sheet, { pageUrl: location.href, readPage: async () => dealsnapReadPage(), onClose: close, onDone: close });
        panel.focusSearch();
      }
    });

    // How many live deals DealSnap has for this shop, from the list the
    // extension keeps on this computer (see background.js).
    chrome.storage.local.get(["dealsnapShops"], ({ dealsnapShops = {} }) => {
      const shop = location.hostname.toLowerCase().replace(/^(www\d?|m|uk)\./, "");
      const n = dealsnapShops[shop];
      if (n) {
        shadow.getElementById("count").textContent = n > 99 ? "99+" : String(n);
        bubble.title = `DealSnap: ${n} deal${n === 1 ? "" : "s"} at this store`;
      }
    });

    return host;
  }
})();
