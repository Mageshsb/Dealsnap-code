// Reads the shop page you're on, for "Post this deal". It runs in the page
// itself (so it works on shops that turn DealSnap's own reader away) and
// keeps only what DealSnap reads: the product data shops publish for Google,
// the page's title, price and photo tags. Not the page's styles or code, so
// it's small and quick to send.
function dealsnapReadPage() {
  const copy = document.documentElement.cloneNode(true);
  copy.querySelectorAll("style, svg, noscript, iframe, video, canvas, link[rel='stylesheet'], #dealsnap-host").forEach((n) => n.remove());
  // (And offers a shop keeps behind a button, "View special offers": just
  // the short sentences in its page data that give a code, not the data.)
  const offers = new Set();
  copy.querySelectorAll("script").forEach((s) => {
    const text = s.textContent || "";
    const useful = s.type === "application/ld+json" || /hiRes|colorImages/.test(text);
    if (useful) return;
    if (/\bcode\b/i.test(text)) {
      for (const m of text.matchAll(/"((?:[^"\\<]|\\.){12,400})"/g)) {
        if (offers.size < 20 && /\bcode\b/i.test(m[1]) && /£|&#163;|\\u00a3|\d\s?%/i.test(m[1])) offers.add(m[1]);
      }
    }
    s.remove();
  });
  if (offers.size) {
    const kept = document.createElement("script");
    kept.type = "application/json";
    kept.textContent = `[${[...offers].map((o) => `"${o}"`).join(",")}]`;
    copy.querySelector("body")?.append(kept);
  }
  const html = ("<!doctype html>" + copy.outerHTML).replace(/\s{2,}/g, " ");
  return { url: location.href, html: html.slice(0, 2500000) };
}
