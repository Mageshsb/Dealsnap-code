import AxeBuilder from "@axe-core/playwright";
import { test, expect, type Page, type BrowserContext } from "@playwright/test";
import fs from "node:fs";
import { ADMIN_TOKEN, MEMBER_PASSWORD } from "./constants";

// A launch-readiness sweep. A real browser visits every kind of page, as a
// visitor, as a member and as the admin, on a computer and on a phone, and checks:
//   - it opens (no error page, no failed file, nothing in the browser's console)
//   - it doesn't scroll sideways on a phone
//   - it has a title, a description and one main heading, and the address Google
//     should use (public pages)
//   - pictures have descriptions and buttons and fields have names
//   - nothing a screen reader or keyboard user would be blocked by (axe)
//   - every link on the page leads somewhere that works
// What it finds is written to test-results/audit.json for the audit report, and
// the serious problems fail the test.
test.describe.configure({ mode: "serial" });

type Finding = { page: string; device: string; kind: string; detail: string };
const findings: Finding[] = [];
const checked = new Set<string>();
const linksSeen = new Set<string>();

const PUBLIC = ["/", "/?q=lego", "/categories", "/categories/gaming-entertainment", "/tags/toy", "/stores", "/stores/argos", "/brands", "/blog", "/community", "/login", "/signup", "/signup", "/contact", "/about", "/terms", "/privacy", "/guidelines", "/black-friday", "/nothing-here-at-all"];
const MEMBER = ["/profile", "/settings", "/alerts", "/saved", "/notifications", "/submit", "/feed", "/welcome"];
const ADMIN = ["/admin", "/admin/deals", "/admin/comments", "/admin/users", "/admin/stores", "/admin/labels", "/admin/content", "/admin/pages", "/admin/pages/social", "/admin/blog", "/admin/insights", "/admin/earnings", "/admin/ads", "/admin/team", "/admin/activity", "/admin/settings", "/admin/errors", "/admin/launch", "/admin/search?q=a", "/admin/community", "/admin/messages", "/admin/engine", "/admin/events", "/admin/banners", "/admin/promos"];

// Files the site makes itself, so a failure there is the site's own fault.
const own = (url: string) => url.startsWith("http://localhost");

async function sweep(page: Page, path: string, device: string, opts: { indexable?: boolean } = {}) {
  const key = `${device} ${path}`;
  if (checked.has(key)) return;
  checked.add(key);
  const add = (kind: string, detail: string) => findings.push({ page: path, device, kind, detail: detail.slice(0, 500) });
  const consoleErrors: string[] = [];
  const failed: string[] = [];
  const onConsole = (m: import("@playwright/test").ConsoleMessage) => {
    if (m.type() === "error" && !/Failed to load resource.*(404|401|403)/.test(m.text())) consoleErrors.push(m.text());
  };
  const onResponse = (r: import("@playwright/test").Response) => {
    if (own(r.url()) && r.status() >= 400 && !/\/(_next\/image|api\/client-error)/.test(r.url())) failed.push(`${r.status()} ${r.url().replace("http://localhost:3123", "")}`);
  };
  page.on("console", onConsole);
  page.on("response", onResponse);
  const response = await page.goto(path, { waitUntil: "networkidle" }).catch(() => null);
  page.off("console", onConsole);
  page.off("response", onResponse);
  const status = response?.status() ?? 0;
  const expectedMissing = path.startsWith("/nothing-here");
  if (expectedMissing ? status !== 404 : status >= 400 || status === 0) add("status", `answered ${status}`);
  for (const f of failed) if (!(expectedMissing && f.includes(path))) add("failed-file", f);
  for (const e of consoleErrors) add("console-error", e);

  if (!expectedMissing && status < 400) {
    const facts = await page.evaluate(() => ({
      title: document.title,
      description: document.querySelector('meta[name="description"]')?.getAttribute("content") ?? "",
      canonical: document.querySelector('link[rel="canonical"]')?.getAttribute("href") ?? "",
      robots: document.querySelector('meta[name="robots"]')?.getAttribute("content") ?? "",
      // Only the ones a visitor can see: a page may carry one for phones and one for computers.
      h1: [...document.querySelectorAll("h1")].filter((h) => h.checkVisibility()).length,
      lang: document.documentElement.lang,
      overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
      noAlt: [...document.querySelectorAll("img")].filter((i) => !i.hasAttribute("alt")).length,
      unnamedList: [...document.querySelectorAll("button, a[href]")]
        .filter((b) => !b.closest("[aria-hidden=true], [inert]") && !(b.textContent ?? "").trim() && !b.getAttribute("aria-label") && !b.getAttribute("title") && !b.querySelector("img[alt]:not([alt=''])"))
        .map((b) => b.outerHTML.slice(0, 140)),
      unlabelledList: [...document.querySelectorAll("input:not([type=hidden]):not([type=checkbox]):not([type=radio]), textarea, select")]
        .filter((f) => !f.closest("[aria-hidden=true], [inert]") && !f.hasAttribute("hidden") && !f.getAttribute("aria-label") && !f.getAttribute("aria-labelledby") && !(f.id && document.querySelector(`label[for="${f.id}"]`)) && !f.closest("label"))
        .map((f) => f.outerHTML.slice(0, 140)),
    }));
    if (!facts.title.trim()) add("no-title", "");
    if (facts.title.length > 90) add("long-title", `${facts.title.length} characters: ${facts.title}`);
    if (facts.h1 !== 1) add("headings", `${facts.h1} main headings`);
    if (!facts.lang) add("no-language", "");
    if (facts.overflow > 1 && device === "phone") add("sideways-scroll", `${facts.overflow}px wider than the screen`);
    if (facts.noAlt) add("image-without-alt", `${facts.noAlt} pictures`);
    if (facts.unnamedList.length) add("unnamed-control", `${facts.unnamedList.length} with no name, e.g. ${facts.unnamedList[0]}`);
    if (facts.unlabelledList.length) add("unlabelled-field", `${facts.unlabelledList.length} with no label, e.g. ${facts.unlabelledList.join(" | ")}`);
    if (opts.indexable) {
      if (!facts.description.trim()) add("no-description", "");
      if (!facts.canonical && !facts.robots.includes("noindex")) add("no-canonical", "");
    }
    const axe = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa"]).analyze();
    for (const v of axe.violations) {
      if (v.id === "color-contrast") {
        // Which colour pairs fail and by how much, so they can be fixed once, in the palette.
        const pairs = new Map<string, number>();
        const sample = new Map<string, string>();
        for (const n of v.nodes) {
          const d = n.any[0]?.data as { fgColor?: string; bgColor?: string; contrastRatio?: number; fontSize?: string; fontWeight?: string } | undefined;
          if (d) {
            const key = `${d.fgColor} on ${d.bgColor} = ${d.contrastRatio}:1 (${d.fontSize}, weight ${d.fontWeight})`;
            pairs.set(key, (pairs.get(key) ?? 0) + 1);
            if (!sample.has(key)) sample.set(key, n.html.slice(0, 110));
          }
        }
        for (const [pair, count] of pairs) add("axe-contrast", `color-contrast ×${count}: ${pair} e.g. ${sample.get(pair)}`);
        continue;
      }
      add(`axe-${v.impact}`, `${v.id}: ${v.help} (${v.nodes.length}) e.g. ${v.nodes[0]?.target.join(" ")}`);
    }
    for (const href of await page.$$eval("a[href]", (as) => as.map((a) => (a as HTMLAnchorElement).getAttribute("href") ?? ""))) {
      if (href.startsWith("/") && !href.startsWith("//") && !href.startsWith("/go/") && !href.startsWith("/visit/") && !href.startsWith("/pick/")) linksSeen.add(href.split("#")[0]);
    }
  }
}

// (Usernames can be at most 20 characters.)
const memberUser = (device: string) => `audit_${device.slice(0, 4)}_${Math.floor(Math.random() * 1e6)}`;

test("public pages", async ({ page }, info) => {
  const device = info.project.name;
  for (const path of PUBLIC) await sweep(page, path, device, { indexable: !/login|signup|nothing/.test(path) && !path.includes("?") });
});

test("a deal page", async ({ page }, info) => {
  await page.goto("/?q=lego");
  const href = await page.locator("h2 a:visible").first().getAttribute("href");
  expect(href).toMatch(/^\/deals\//);
  await sweep(page, href!, info.project.name, { indexable: true });
});

test("a member's pages", async ({ browser }, info) => {
  const device = info.project.name;
  const context: BrowserContext = await browser.newContext(info.project.use);
  const page = await context.newPage();
  await page.goto("/signup");
  const name = memberUser(device);
  await page.getByPlaceholder("dealhunter99").fill(name);
  await page.getByPlaceholder("you@example.com").fill(`${name}@example.invalid`);
  await page.getByPlaceholder("At least 8 characters").fill(MEMBER_PASSWORD);
  await page.getByLabel(/or over/).check();
  await page.waitForTimeout(3500);
  await page.getByRole("button", { name: "Join free" }).click();
  await expect(page).toHaveURL(/\/welcome/);
  for (const path of MEMBER) await sweep(page, path, device);
  await sweep(page, `/u/${name}`, device);
  await context.close();
});

test.describe("the admin", () => {
  test.use({ storageState: { cookies: [{ name: "dealsnap_session", value: ADMIN_TOKEN, domain: "localhost", path: "/", httpOnly: true, secure: false, sameSite: "Lax", expires: -1 }], origins: [] } });
  test("admin pages", async ({ page }, info) => {
    for (const path of ADMIN) await sweep(page, path, info.project.name);
  });
});

test("every link found leads somewhere that works", async ({ request }, info) => {
  for (const href of linksSeen) {
    const key = `link ${href}`;
    if (checked.has(key)) continue;
    checked.add(key);
    const response = await request.get(href, { maxRedirects: 5, headers: { cookie: `dealsnap_session=${ADMIN_TOKEN}` } });
    if (response.status() >= 400) findings.push({ page: href, device: info.project.name, kind: "broken-link", detail: `answered ${response.status()}` });
  }
});

test.afterAll(async () => {
  fs.mkdirSync("test-results", { recursive: true });
  const file = "test-results/audit.json";
  const before: Finding[] = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, "utf8")) : [];
  fs.writeFileSync(file, JSON.stringify([...before, ...findings], null, 1));
  // What fails the test: things a visitor would actually hit.
  const serious = findings.filter((f) => /^(status|failed-file|console-error|sideways-scroll|broken-link|axe-(critical|serious)|no-title|unlabelled-field|unnamed-control|image-without-alt)$/.test(f.kind));
  console.log(`audit: ${findings.length} findings, ${serious.length} serious`);
  for (const f of serious) console.log(`  [${f.device}] ${f.page} ${f.kind}: ${f.detail}`);
  expect(serious, "serious problems found (see test-results/audit.json)").toHaveLength(0);
});
