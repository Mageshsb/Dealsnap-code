// Starts the site the screen tests use: a build of the current code in its own
// folder (.next-e2e) with a brand-new database in a temporary folder, plus one
// admin account with a ready sign-in, so tests can look at Admin without
// typing a password. Nothing here can reach real data, emails or networks.
import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { pathToFileURL } from "node:url";
import { registerTypeScript } from "../scripts/ts-loader.mjs";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const PORT = process.env.E2E_PORT ?? "3123";
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "dealsnap-e2e-"));
const ADMIN_TOKEN = "e2e-admin-session-token-not-a-secret";

const env = {
  ...process.env,
  DEALSNAP_ENV: "staging", // no real emails, notifications or affiliate calls
  DEALSNAP_DATA_DIR: dataDir,
  DEALSNAP_DIST_DIR: ".next-e2e",
  SITE_URL: `http://localhost:${PORT}`,
  NEXT_TELEMETRY_DISABLED: "1",
};
for (const key of ["RESEND_API_KEY", "EMAIL_FROM", "AWIN_API_TOKEN", "TURNSTILE_SITE_KEY", "TURNSTILE_SECRET_KEY"]) delete env[key];

const next = path.join(root, "node_modules", ".bin", "next");
// E2E_SKIP_BUILD=1 reuses the last build, for quick reruns while writing tests
// (it won't see code changes, so never use it for a real check).
if (process.env.E2E_SKIP_BUILD && fs.existsSync(path.join(root, ".next-e2e", "BUILD_ID"))) {
  console.log("[e2e] reusing the last build in .next-e2e");
} else {
  console.log(`[e2e] building into .next-e2e (data in ${dataDir})`);
  const built = spawnSync(next, ["build"], { cwd: root, env, stdio: "inherit" });
  if (built.status !== 0) process.exit(built.status ?? 1);
}

// Set the database up with the site's own code (as the build or a first visit
// would), then add the admin and their sign-in.
process.env.DEALSNAP_DATA_DIR = dataDir;
registerTypeScript(root);
const { sqlite: db } = await import(pathToFileURL(path.join(root, "lib/db.ts")).href);
const now = new Date().toISOString();
db.prepare(
  `INSERT INTO users (id, username, email, password_hash, password_salt, created_at, role) VALUES ('e2e-admin', 'e2e_admin', 'e2e-admin@example.invalid', 'not-a-real-hash', 'x', ?, 'admin')`
).run(now);
db.prepare("INSERT INTO sessions (token, user_id, expires_at, created_at) VALUES (?, 'e2e-admin', ?, ?)").run(
  crypto.createHash("sha256").update(ADMIN_TOKEN).digest("hex"),
  new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
  now
);
db.close();

const server = spawn(next, ["start", "-p", PORT], { cwd: root, env, stdio: "inherit" });
const stop = () => {
  server.kill();
  fs.rmSync(dataDir, { recursive: true, force: true });
};
for (const signal of ["SIGINT", "SIGTERM"]) process.on(signal, () => (stop(), process.exit(0)));
server.on("exit", (code) => {
  fs.rmSync(dataDir, { recursive: true, force: true });
  process.exit(code ?? 0);
});
