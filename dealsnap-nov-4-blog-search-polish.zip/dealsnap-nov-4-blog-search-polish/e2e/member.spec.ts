import { test, expect, type Page } from "@playwright/test";
import { MEMBER_PASSWORD } from "./constants";

// The journeys a visitor takes most: look around, search, join, love a deal.
// One member is made once (per device size) and the later steps reuse them.
test.describe.configure({ mode: "serial" });

let page: Page;
let username = "";

test.beforeAll(async ({ browser }, info) => {
  const context = await browser.newContext(info.project.use);
  page = await context.newPage();
  username = `e2e_${info.project.name}_${Math.floor(Math.random() * 1e6)}`;
});
test.afterAll(async () => {
  await page.context().close();
});

test("the home page shows deals", async () => {
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toContainText("deals");
  await expect(page.getByRole("button", { name: "Love this deal" }).first()).toBeVisible();
  await expect(page.getByText("Sorry, something went wrong")).toHaveCount(0);
});

test("searching finds deals", async () => {
  await page.goto("/");
  const box = page.getByRole("searchbox", { name: "Search deals" });
  // On a phone the box opens from the magnifying-glass button.
  if (!(await box.isVisible())) await page.getByRole("button", { name: "Search", exact: true }).click();
  await box.fill("lego");
  await box.press("Enter");
  await expect(page).toHaveURL(/[?]q=lego/);
  await expect(page.getByText("Sorry, something went wrong")).toHaveCount(0);
  await expect(page.locator("h2 a:visible", { hasText: /lego/i }).first()).toBeVisible();
});

test("asking for a store's codes offers them first", async () => {
  await page.goto("/");
  const box = page.getByRole("searchbox", { name: "Search deals" });
  if (!(await box.isVisible())) await page.getByRole("button", { name: "Search", exact: true }).click();
  // "voucher" doesn't stop the store being found; its codes come first.
  await box.fill("asos voucher");
  const codes = page.getByRole("link", { name: /ASOS voucher codes/ });
  await expect(codes).toBeVisible();
  await expect(page.getByRole("link", { name: /^ASOS \d+ live deals?$/ })).toBeVisible();
  await codes.click();
  await expect(page).toHaveURL(/\/vouchers\?store=asos/);
  await expect(page.getByText("Sorry, something went wrong")).toHaveCount(0);
  // The results page names the search in the tab.
  await page.goto("/?q=asos%20voucher");
  await expect(page).toHaveTitle(/^Search: asos voucher \|/);
});

test("a deal's page opens", async () => {
  await page.goto("/?q=lego");
  // The whole card is one big link laid over its title, so a real tap on the title opens it.
  await page.locator("h2 a:visible", { hasText: /lego/i }).first().click({ force: true });
  await expect(page).toHaveURL(/\/deals\/.+/);
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
});

test("joining the site", async () => {
  await page.goto("/signup");
  await page.getByPlaceholder("dealhunter99").fill(username);
  await page.getByPlaceholder("you@example.com").fill(`${username}@example.invalid`);
  await page.getByPlaceholder("At least 8 characters").fill(MEMBER_PASSWORD);
  await page.getByLabel(/or over/).check();
  // The sign-up form refuses anything sent faster than a person could fill it in.
  await page.waitForTimeout(3500);
  await page.getByRole("button", { name: "Join free" }).click();
  await expect(page).toHaveURL(/\/welcome/);
});

test("loving a deal sticks", async () => {
  await page.goto("/");
  const heart = page.getByRole("button", { name: "Love this deal" }).first();
  await expect(heart).toHaveAttribute("aria-pressed", "false");
  await heart.click();
  await expect(heart).toHaveAttribute("aria-pressed", "true");
  // Still loved after the page is loaded again.
  await page.reload();
  await expect(page.locator('button[aria-label="Love this deal"][aria-pressed="true"]').first()).toBeVisible();
});

test("posting a deal sends it to the team", async ({}, info) => {
  const title = `E2E kettle ${info.project.name}`;
  await page.goto("/submit");
  await page.locator("#url").fill("https://shop.example.test/kettle");
  const next = page.getByRole("button", { name: /^Next/ });
  await next.click();
  // The site reads the link first. If it can't reach the shop (as here, where the
  // address isn't real) it says so and waits for a second Next.
  await page.locator("#title").waitFor({ state: "visible", timeout: 8000 }).catch(() => next.click());
  await page.locator("#title").fill(title);
  await page.locator("#price").fill("9.99");
  await page.locator("#originalPrice").fill("19.99");
  await page.locator("#store").fill("E2E Store");
  await page.getByRole("button", { name: /^What is it\?/ }).click();
  await page.getByLabel("Search what it is").fill("toy");
  await page.getByRole("option").first().click();
  await page.locator("#description").fill("Half price at the moment, and it boils fast.");
  await page.getByRole("button", { name: /^Next/ }).click();
  await page.getByRole("button", { name: "Post deal" }).click();
  await expect(page).toHaveURL(/\/deals\//);
  await expect(page.getByRole("heading", { level: 1 })).toContainText(title);
});

// A small picture to put in a description (120×80, orange).
const SHOT_PNG = "iVBORw0KGgoAAAANSUhEUgAAAHgAAABQCAIAAABd+SbeAAAACXBIWXMAAAPoAAAD6AG1e1JrAAABHUlEQVR4nO3UwY1CARDDUKpwo1T/bzTAlc1o9aRUYDl+Pe/s+T2EF8rPn6gGdED3n97G6IBuriGjm4OTjm5OowO6uYaMbg5OOro5jQ7o5hoyujk46ejmNDqgm2vI6ObgpKOb0+iAbq4ho5uDk45uTqMDurmGjG4OTjq6OY0O6OYaMro5OOno5jQ6oJtryOjm4KSjm9PogG6uIaObg5OObk6jA7q5hoxuDk46ujmNDujmGjK6OTjp6OY0OqCba8jo5uCko5vT6IBuriGjm4OTjm5OowO6uYaMbg5OOro5jQ7o5hoyujk46ejmNDqgm2vI6ObgpKOb0+iAbq4ho5uDk45uTqMDurmGjG4OTjq6OY0O6OYaMro5OOlozvTrPhbjjklG+aHoAAAAAElFTkSuQmCC";

test("an in-store deal goes up without a link, with an RRP shown as one", async ({}, info) => {
  const title = `E2E in-store toaster ${info.project.name}`;
  await page.goto("/submit");
  await page.getByRole("button", { name: "No link? It's an in-store deal" }).click();
  await page.getByRole("button", { name: /^Next/ }).click();
  await page.locator("#title").fill(title);
  await page.locator("#price").fill("15");
  await page.locator("#originalPrice").fill("40");
  await page.getByText("It's the RRP").click();
  // A store we don't know (its own name for each run, as once a deal names a
  // store its website is known): its website is asked for, so people can find it.
  await page.locator("#store").fill(`E2E Corner Shop ${info.project.name}`);
  await page.locator("#storeSite").fill(`e2e-corner-shop-${info.project.name}.co.uk`);
  await page.getByRole("button", { name: /^What is it\?/ }).click();
  await page.getByLabel("Search what it is").fill("toy");
  await page.getByRole("option").first().click();
  // The description, with a picture between its lines (where to find it in store).
  const box = page.getByRole("textbox", { name: "Why is it a good deal?" }).and(page.locator("[contenteditable]"));
  await box.click();
  await page.keyboard.type("Reduced in store ");
  // Bold from the keyboard shortcut, kept as **…** (never HTML).
  await page.keyboard.press("ControlOrMeta+b");
  await page.keyboard.type("this week only");
  await page.keyboard.press("ControlOrMeta+b");
  await page.keyboard.type(".");
  await page.keyboard.press("Enter");
  await page.keyboard.type("It's on this shelf:");
  await page.locator('label[title="Add a picture"] input[type="file"]').setInputFiles({
    name: "aisle.png",
    mimeType: "image/png",
    buffer: Buffer.from(SHOT_PNG, "base64"),
  });
  await expect(page.getByRole("button", { name: "Remove picture 1" })).toBeVisible();
  await page.keyboard.type("Near the tills.");
  await expect(page.locator('input[name="description"]')).toHaveValue(/^Reduced in store \*\*this week only\*\*\.\nIt's on this shelf:\n\[\[new:[a-z0-9]+\]\]\nNear the tills\.$/);
  await page.keyboard.press("Enter");
  await page.keyboard.type("Store finder: https://www.example-shop.co.uk/stores");
  await page.getByRole("button", { name: /^Next/ }).click();
  await expect(page.getByRole("button", { name: /Where to get it/ })).toContainText("In-store only");
  await page.getByRole("button", { name: "Post deal" }).click();
  await expect(page).toHaveURL(/\/deals\//);
  await expect(page.getByRole("heading", { level: 1 })).toContainText(title);
  await expect(page.getByText("RRP £40.00").first()).toBeVisible();
  // On the deal page the picture sits between the words, and opens full size.
  const inline = page.getByRole("img", { name: "Picture 1 from the poster" });
  await expect(inline).toBeVisible();
  expect(await inline.evaluate((img: HTMLImageElement) => img.naturalWidth)).toBe(120);
  const about = await page.locator("p", { hasText: "It's on this shelf:" }).boundingBox();
  const pictureBox = await inline.boundingBox();
  const after = await page.locator("p", { hasText: "Near the tills." }).boundingBox();
  expect(about!.y < pictureBox!.y && pictureBox!.y < after!.y).toBe(true);
  await expect(page.locator("strong", { hasText: "this week only" })).toBeVisible();
  // A link in the description goes out through /out, marked for search engines.
  const out = page.locator('a[href^="/out/d/"]');
  await expect(out).toContainText("example-shop.co.uk/stores");
  await expect(out).toHaveAttribute("rel", /ugc/);
  await page.getByRole("button", { name: "Open picture 1 from the poster full size" }).click();
  const full = page.getByRole("dialog").getByRole("img", { name: "Picture 1 from the poster" });
  await expect(full).toBeVisible();
  await page.getByRole("dialog").getByRole("button", { name: "Close picture" }).click();
  await expect(full).toBeHidden();

  // Editing it later uses the same box: the picture and the bold are still
  // there, and a line added under them is saved with them.
  const slug = new URL(page.url()).pathname.split("/")[2];
  await page.goto(`/deals/${slug}/edit`);
  await expect(page.getByRole("button", { name: "Remove picture 1" })).toBeVisible();
  await expect(page.locator('input[name="description"]')).toHaveValue(/\*\*this week only\*\*[\s\S]*\[\[shot:[a-f0-9]{24}\]\]\n+Near the tills\.\nStore finder: /);
  const editBox = page.getByRole("textbox", { name: "Why is it a good deal?" }).and(page.locator("[contenteditable]"));
  await editBox.locator("div", { hasText: /^Near the tills\.$/ }).last().click();
  await page.keyboard.press("End");
  await page.keyboard.type(" Ask at the desk.");
  await page.getByRole("button", { name: "Save changes" }).click();
  await expect(page).toHaveURL(new RegExp(`/deals/${slug}`));
  await expect(page.locator("p", { hasText: "Near the tills. Ask at the desk." })).toBeVisible();
  await expect(page.getByRole("img", { name: "Picture 1 from the poster" })).toBeVisible();
});

test("a \"did it work?\" answer can be taken back", async () => {
  await page.goto("/deals/boots-5-off-30-spend");
  const yes = page.getByRole("button", { name: "Yes", exact: true });
  await yes.click();
  await expect(yes).toHaveAttribute("aria-pressed", "true");
  await expect(page.getByText(/SAVE5 worked for 1 person/)).toBeVisible();
  // Tapping it again takes it back.
  await yes.click();
  await expect(yes).toHaveAttribute("aria-pressed", "false");
  await expect(page.getByText("Did the code SAVE5 work?")).toBeVisible();
});

test("a voucher needs its code; with no code it's a Sale, keeping what was typed", async () => {
  await page.goto("/submit");
  await page.getByRole("button", { name: "No link? It's an in-store deal" }).click();
  await page.getByText("Voucher", { exact: true }).click();
  await page.getByRole("button", { name: /^Next/ }).click();
  // The code comes first and is a must; the title writes itself from the store.
  await expect(page.locator("#voucherCode")).toHaveAttribute("required", "");
  await page.locator("#store").fill("Boots");
  await expect(page.locator("#title")).toHaveValue("Boots discount code");
  await page.locator("#voucherAmount").fill("10");
  // A code that's already live at the same store says so.
  await page.locator("#voucherCode").fill("SAVE5");
  await expect(page.getByText("Already posted:")).toBeVisible();
  await page.locator("#voucherCode").fill("");
  // No code: one tap makes it a Sale, with the same £10 off.
  await page.getByRole("button", { name: /No code to enter\? Make it a Sale/ }).click();
  await expect(page.locator('input[name="kind"][value="sale"]')).toBeChecked();
  await expect(page.locator('input[name="saleUnit"][value="£"]')).toBeChecked();
  await expect(page.locator("#saleAmount")).toHaveValue("10");
  // Still for the whole store, as the voucher was.
  await expect(page.locator('input[name="scope"][value="store"]')).toBeChecked();
  // The title it wrote for the voucher goes with it.
  await expect(page.locator("#title")).toHaveValue("");
});

test("a voucher for the whole store has no type, and is listed under its store", async ({}, info) => {
  const store = `E2E Whole Store ${info.project.name}`;
  await page.goto("/submit");
  await page.getByRole("button", { name: "No link? It's an in-store deal" }).click();
  await page.getByText("Voucher", { exact: true }).click();
  await page.getByRole("button", { name: /^Next/ }).click();
  // A voucher starts as Whole store: nothing to file it under.
  await expect(page.locator('input[name="scope"][value="store"]')).toBeChecked();
  await expect(page.getByRole("button", { name: /^Which products\?/ })).toHaveCount(0);
  // Some products asks which; back to Whole store doesn't.
  await page.getByText("Some products", { exact: true }).click();
  await expect(page.getByRole("button", { name: /^Which products\?/ })).toBeVisible();
  // ...where a whole category can be picked, for one that covers several types.
  await page.getByRole("button", { name: /^Which products\?/ }).click();
  await page.getByLabel("Search what it is").fill("clothing");
  await page.getByRole("option", { name: /^All of Clothing & Accessories/ }).click();
  await expect(page.getByRole("button", { name: "Which products?: All of Clothing & Accessories" })).toBeVisible();
  await page.getByText("Whole store", { exact: true }).click();
  await expect(page.getByRole("button", { name: /^Which products\?/ })).toHaveCount(0);
  await page.locator("#store").fill(store);
  await page.locator("#storeSite").fill(`e2e-whole-${info.project.name}.co.uk`);
  await page.locator("#voucherAmount").fill("10");
  await page.locator("#voucherCode").fill(`WHOLE${info.project.name.length}`);
  await page.getByRole("textbox", { name: "Why is it a good deal?" }).and(page.locator("[contenteditable]")).click();
  await page.keyboard.type("Works on everything in store, no minimum spend.");
  await page.getByRole("button", { name: /^Next/ }).click();
  await page.getByRole("button", { name: "Post deal" }).click();
  await expect(page).toHaveURL(/\/deals\//);
  // Its trail is its store's, not a made-up category.
  const trail = page.getByRole("navigation", { name: "Breadcrumb" });
  await expect(trail.getByRole("link", { name: "Stores" })).toBeVisible();
  await expect(trail.getByRole("link", { name: store })).toHaveAttribute("href", /\/stores\//);
});

test("a brand-new member can comment, but not add pictures yet", async () => {
  await page.goto("/?q=lego");
  await page.locator("h2 a:visible", { hasText: /lego/i }).first().click({ force: true });
  await page.getByRole("textbox", { name: "Add a comment" }).click();
  await expect(page.getByRole("button", { name: "Post", exact: true })).toBeVisible();
  await expect(page.locator('label[title="Add a picture"]')).toHaveCount(0);
});

test("a member can't open Admin", async () => {
  await page.goto("/admin");
  await expect(page).not.toHaveURL(/\/admin/);
});
