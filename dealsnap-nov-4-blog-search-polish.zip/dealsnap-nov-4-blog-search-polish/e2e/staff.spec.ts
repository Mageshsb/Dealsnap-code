import { test, expect } from "@playwright/test";
import { ADMIN_TOKEN } from "./constants";

// Admin, as the signed-in admin that e2e/serve.mjs made: the lists open, the
// filters narrow them, and search and Site health work.
test.use({ storageState: { cookies: [{ name: "dealsnap_session", value: ADMIN_TOKEN, domain: "localhost", path: "/", httpOnly: true, secure: false, sameSite: "Lax", expires: -1 }], origins: [] } });

const noCrash = async (page: import("@playwright/test").Page) => {
  await expect(page.getByText("Sorry, something went wrong")).toHaveCount(0);
  await expect(page.getByText("This page couldn")).toHaveCount(0);
};

test("the dashboard opens", async ({ page }) => {
  await page.goto("/admin");
  await expect(page.getByRole("heading", { name: "Dashboard" })).toBeVisible();
  await noCrash(page);
});

test("deal filters narrow the list", async ({ page }) => {
  await page.goto("/admin/deals");
  await expect(page.getByRole("heading", { name: "Deals", level: 1 })).toBeVisible();
  const all = await page.locator("main p", { hasText: /\d+ deals?\./ }).first().innerText();
  await page.goto("/admin/deals?tag=Toy");
  await expect(page.getByText(/matching your filters/)).toBeVisible();
  await expect(page.getByText(all.trim(), { exact: true })).toHaveCount(0);
  await page.goto("/admin/deals?status=pending&store=argos&kind=voucher&flag=reported");
  await noCrash(page);
  await expect(page.getByText("No deals match these filters.")).toBeVisible();
});

test("searching all of Admin", async ({ page }) => {
  await page.goto("/admin/search?q=lego");
  await expect(page.getByRole("heading", { name: "Deals" })).toBeVisible();
  await noCrash(page);
});

test("the other lists open", async ({ page }) => {
  for (const path of ["/admin/comments", "/admin/users", "/admin/stores", "/admin/blog", "/admin/settings", "/admin/errors"]) {
    await page.goto(path);
    await expect(page.getByRole("heading", { level: 1 }).first()).toBeVisible();
    await noCrash(page);
  }
});

test("member and store filters work", async ({ page }) => {
  for (const path of [
    "/admin/users?status=new",
    "/admin/users?status=unconfirmed",
    "/admin/users?status=inactive",
    "/admin/users?status=reported&role=moderator",
    "/admin/stores?filter=nologo",
    "/admin/stores?filter=nosite",
    "/admin/deals?status=live&brand=none",
    "/admin/comments?reported=true&sort=reports-desc",
  ]) {
    await page.goto(path);
    await expect(page.getByRole("heading", { level: 1 }).first()).toBeVisible();
    await noCrash(page);
  }
  await page.goto("/admin/users?status=new");
  await expect(page.getByRole("link", { name: "e2e_admin" })).toBeVisible();
});

test("a browser error reaches Site health", async ({ page, request }) => {
  const sent = await request.post("/api/client-error", { data: { message: "e2e: a button broke", path: "/deals/example" } });
  expect(sent.status()).toBe(204);
  await page.goto("/admin");
  await expect(page.getByText("Things that broke on the site")).toBeVisible();
  await page.goto("/admin/errors");
  await expect(page.getByText("e2e: a button broke")).toBeVisible();
  await page.getByRole("button", { name: "Dealt with", exact: true }).first().click();
  await expect(page.getByText("e2e: a button broke")).toHaveCount(0);
});

// The deal the member posted in e2e/member.spec.ts (that file runs first) is
// waiting in the queue; the team approves it and it goes live.
test("approving a member's deal", async ({ page }, info) => {
  const title = `E2E kettle ${info.project.name}`;
  await page.goto("/admin/deals?status=pending");
  const row = page.locator("tr", { hasText: title });
  await expect(row).toBeVisible();
  await row.getByRole("button", { name: "Approve" }).click();
  await expect(page.getByText(title)).toHaveCount(0);
  await page.goto("/admin/deals?q=" + encodeURIComponent(title));
  await expect(page.locator("tr", { hasText: title }).getByText("Live")).toBeVisible();
});

test("social and app links: checked in Admin, shown in the footer", async ({ page }, info) => {
  // One device size only: both would change the same setting at once.
  test.skip(info.project.name !== "computer");
  await page.goto("/admin/pages/social");
  await expect(page.getByRole("heading", { name: "Social and app links", level: 1 })).toBeVisible();
  // A link on another website is refused, and what was typed stays.
  const instagram = page.getByRole("textbox", { name: "Instagram link" });
  await instagram.fill("https://instagram.com.example/dealsnap");
  await page.getByRole("button", { name: "Save" }).click();
  await expect(page.getByText("That doesn't look like a link to Instagram.", { exact: false })).toBeVisible();
  await expect(instagram).toHaveValue("https://instagram.com.example/dealsnap");
  // A real one switches itself on; moved to the front; an app link too.
  await instagram.fill("instagram.com/dealsnap");
  await expect(page.getByRole("checkbox", { name: "Show Instagram" })).toBeChecked();
  await page.getByRole("button", { name: "Move Instagram up" }).click();
  await page.getByRole("textbox", { name: "Google Play link" }).fill("https://play.google.com/store/apps/details?id=com.dealsnap");
  await page.getByRole("button", { name: "Save" }).click();
  await expect(page.getByText("Saved. The footer shows them now.")).toBeVisible();
  // The footer: the logo links to the checked address; the app button beside it.
  await page.goto("/blog");
  const footer = page.locator("footer");
  await expect(footer.getByRole("link", { name: "Instagram" })).toHaveAttribute("href", "https://instagram.com/dealsnap");
  await expect(footer.getByRole("link", { name: "Get it on Google Play" })).toBeVisible();
  await expect(page.getByText("Sorry, something went wrong")).toHaveCount(0);
  // Put back as it was, so other tests see the usual footer.
  await page.goto("/admin/pages/social");
  await page.getByRole("checkbox", { name: "Show Instagram" }).uncheck();
  await page.getByRole("checkbox", { name: "Show Google Play" }).uncheck();
  await page.getByRole("button", { name: "Save" }).click();
  await expect(page.getByText(/Nothing is switched on/)).toBeVisible();
});

test("logo and browser icon: uploaded in Admin, shown on the site", async ({ page }, info) => {
  // One device size only: both would change the same setting at once.
  test.skip(info.project.name !== "computer");
  const svg = (w: number, h: number, body: string) => ({
    name: "logo.svg",
    mimeType: "image/svg+xml",
    buffer: Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}">${body}</svg>`),
  });
  await page.goto("/admin/settings?tab=general");
  const form = page.locator("form").filter({ has: page.getByRole("heading", { name: "Logo and browser icon" }) });
  // Not a picture: refused before it's sent, with why.
  await form.getByLabel("Logo", { exact: true }).setInputFiles({ name: "logo.png", mimeType: "image/png", buffer: Buffer.from("not a picture") });
  await expect(form.getByText("We couldn't read that picture.", { exact: false })).toBeVisible();
  // A wide logo (it replaces the name, so the tick goes off) and a square icon.
  await form.getByLabel("Logo", { exact: true }).setInputFiles(svg(200, 40, '<rect width="200" height="40" rx="8" fill="#7c3aed"/>'));
  await expect(form.getByRole("checkbox", { name: /Show the site.s name beside the logo/ })).not.toBeChecked();
  await form.getByLabel("Browser icon").setInputFiles(svg(64, 64, '<rect width="64" height="64" rx="14" fill="#7c3aed"/>'));
  await form.getByRole("button", { name: "Save", exact: true }).click();
  await expect(page.getByText("Saved.", { exact: true })).toBeVisible();
  // The header shows it, named for screen readers; the tab icon is the new one.
  await page.goto("/blog");
  const logo = page.locator("header.site-header").getByRole("link", { name: "DealSnap" }).locator("img");
  await expect(logo).toHaveAttribute("src", /^\/site-logo\/[a-f0-9]{16}\.png$/);
  expect(await logo.evaluate((img: HTMLImageElement) => img.naturalWidth)).toBeGreaterThan(0);
  await expect(page.locator('link[rel="apple-touch-icon"]')).toHaveAttribute("href", /^\/site-icon\/[a-f0-9]{16}-180\.png$/);
  const ico = await page.request.get("/favicon.ico");
  expect(ico.headers()["content-type"]).toBe("image/x-icon");
  // Back to the standard ones, so other tests see the usual header.
  await page.goto("/admin/settings?tab=general");
  await form.getByRole("button", { name: "Use the standard logo" }).click();
  await expect(page.getByText("The standard logo is back.")).toBeVisible();
  await form.getByRole("button", { name: "Use the standard icon" }).click();
  await expect(page.getByText("The standard icon is back.")).toBeVisible();
  await page.goto("/blog");
  await expect(page.locator("header.site-header").getByRole("link", { name: "DealSnap" }).locator("img")).toHaveCount(0);
});

test("Wording: an About line and an email are changed, shown, and put back", async ({ page }, info) => {
  // One device size only: both would change the same settings at once.
  test.skip(info.project.name !== "computer");
  await page.goto("/admin/wording?tab=about");
  await expect(page.getByRole("heading", { name: "Wording", level: 1 })).toBeVisible();
  await page.getByLabel("Big heading").fill("Deals, found by people like you.");
  await page.getByRole("button", { name: "Save", exact: true }).click();
  await expect(page.getByText("Saved.", { exact: true })).toBeVisible();
  await page.goto("/about");
  await expect(page.getByRole("heading", { name: "Deals, found by people like you.", level: 1 })).toBeVisible();
  await page.goto("/admin/wording?tab=about");
  await page.getByRole("button", { name: "Use the standard words" }).click();
  await page.goto("/about");
  await expect(page.getByRole("heading", { name: "Bargains are better shared.", level: 1 })).toBeVisible();

  // An email's button, in the card, with its preview and a way back.
  await page.goto("/admin/wording?tab=emails");
  const card = page.locator("#reset");
  await card.locator('input[name="button"]').fill("Pick a new one");
  await card.getByRole("button", { name: "Save", exact: true }).click();
  await expect(page.locator("#reset").getByText("Pick a new one").first()).toBeVisible();
  await expect(page.locator("#reset").getByText("Changed", { exact: true })).toBeVisible();
  await page.locator("#reset").getByRole("button", { name: "Use the standard" }).click();
  await expect(page.locator("#reset").getByText("Changed", { exact: true })).toHaveCount(0);

  // Search words are kept as typed, tidied.
  await page.goto("/admin/wording?tab=search");
  await page.getByLabel(/One group per line/).fill("Specs, glasses\nsolo");
  await page.getByRole("button", { name: "Save", exact: true }).click();
  await expect(page.getByLabel(/One group per line/)).toHaveValue("specs, glasses");
  await page.getByLabel(/One group per line/).fill("");
  await page.getByRole("button", { name: "Save", exact: true }).click();

  // The reasons staff pick from.
  await page.goto("/admin/wording?tab=reasons");
  await expect(page.getByText("Taking a deal down")).toBeVisible();
  await expect(page.getByText("Suspending a member")).toBeVisible();
});

test("the team's pages open: Wording is for admins, and Admin → Settings shows both backup downloads", async ({ page }) => {
  await page.goto("/admin/settings?tab=data");
  await expect(page.getByRole("link", { name: "Download database backup" })).toBeVisible();
  await expect(page.getByRole("link", { name: "Download pictures" })).toBeVisible();
  const pictures = await page.request.get("/admin/backup?pictures=1");
  expect(pictures.status()).toBe(200);
  expect(pictures.headers()["content-type"]).toBe("application/gzip");
  const bytes = await pictures.body();
  expect(bytes[0]).toBe(0x1f);
  expect(bytes[1]).toBe(0x8b);
  const db = await page.request.get("/admin/backup");
  expect((await db.body()).subarray(0, 15).toString()).toBe("SQLite format 3");
});
