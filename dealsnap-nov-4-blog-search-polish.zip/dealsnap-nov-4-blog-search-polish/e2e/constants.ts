// Shared by e2e/serve.mjs (which creates them) and the tests (which use them).
export const ADMIN_TOKEN = "e2e-admin-session-token-not-a-secret";
export const MEMBER_PASSWORD = "e2e-Password-123";
