import { test, expect } from "@playwright/test";

// Things true of the whole site, whoever's looking.

test("a test copy hides itself from search engines", async ({ request }) => {
  const home = await request.get("/");
  expect(home.headers()["x-robots-tag"]).toContain("noindex");
  expect(await (await request.get("/robots.txt")).text()).toContain("Disallow: /");
});

test("a page that doesn't exist says so", async ({ page }) => {
  const response = await page.goto("/deals/no-such-deal-anywhere");
  expect(response?.status()).toBe(404);
  await expect(page.getByText("Sorry, something went wrong")).toHaveCount(0);
});

test("Admin and the helper desk turn visitors away", async ({ page }) => {
  await page.goto("/admin/deals");
  await expect(page).toHaveURL(/\/login/);
});

test("the site sends its security headers", async ({ request }) => {
  const headers = (await request.get("/")).headers();
  expect(headers["x-frame-options"]).toBe("DENY");
  expect(headers["x-content-type-options"]).toBe("nosniff");
  expect(headers["content-security-policy"]).toContain("frame-ancestors 'none'");
});

test("the Vouchers page: the deals list, vouchers only, with a Store filter", async ({ page }) => {
  await page.goto("/");
  await page.locator('a[href="/vouchers"]:visible').first().click();
  await expect(page).toHaveURL(/\/vouchers$/);
  await expect(page.getByRole("heading", { name: /^Voucher codes/, level: 1 })).toBeVisible();
  // Its chip in the category strip shows where you are, and its x goes back to all deals.
  const chip = page.getByRole("link", { name: "Vouchers, tap to go back to all deals" });
  await expect(chip).toBeVisible();
  await expect(chip).toHaveAttribute("href", "/");
  // The header's List / Cards switch is there, as on every deals list.
  await expect(page.getByRole("button", { name: "Cards", exact: true })).toBeVisible();
  // Every deal here is a voucher ("Get code"), none a price drop's "Get deal".
  const list = page.locator("main");
  await expect(list.getByRole("link", { name: /^Get code/ }).first()).toBeVisible();
  await expect(list.getByRole("link", { name: /^Get deal/ })).toHaveCount(0);
  // A store narrows it, through the address like every other filter.
  await page.goto("/vouchers?store=boots");
  await expect(list.getByRole("link", { name: "Get code: copies SAVE5 and opens Boots" })).toBeVisible();
  await expect(list.getByRole("link", { name: /^Get code/ })).toHaveCount(1);
  await expect(page.getByText("Sorry, something went wrong")).toHaveCount(0);
});

test("the category dropdown leads with Voucher codes, full width", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("button", { name: /Choose a category$/ }).first().click();
  const vouchers = page.getByRole("link", { name: "Voucher codes" }).last();
  const everything = page.getByRole("link", { name: "All categories & tags", exact: true });
  await expect(vouchers).toBeVisible();
  const [v, e] = [await vouchers.boundingBox(), await everything.boundingBox()];
  // Above "All categories & tags" and as wide.
  expect(v!.y).toBeLessThan(e!.y);
  expect(Math.abs(v!.width - e!.width)).toBeLessThan(1);
});

test("a store's page lists its codes like any other deal", async ({ page }) => {
  await page.goto("/stores/boots");
  await expect(page.getByRole("region", { name: /discount codes$/ })).toHaveCount(0);
  await expect(page.getByRole("link", { name: "Get code: copies SAVE5 and opens Boots" }).first()).toBeVisible();
  // Its title for search results says what's here in full.
  await expect(page).toHaveTitle(/^Boots deals and discount codes/);
});

test("vouchers look like vouchers, and the main button copies a deal's code", async ({ page, context }) => {
  await context.grantPermissions(["clipboard-read", "clipboard-write"]);
  // The buttons open the store in a new tab through /go: kept on this page
  // here (the tap's own work, copying the code, still happens).
  const stayHere = () =>
    page.evaluate(() =>
      document.addEventListener("click", (e) => {
        if ((e.target as Element).closest('a[href^="/go/"]')) e.preventDefault();
      })
    );

  // A voucher's button says "Get code", in violet, and copies its code.
  await page.goto("/?type=voucher");
  await stayHere();
  const getCode = page.getByRole("link", { name: /^Get code: copies / }).first();
  await expect(getCode).toBeVisible();
  const code = (await getCode.getAttribute("aria-label"))!.match(/copies (\S+) and opens/)![1];
  await getCode.click();
  await expect(getCode).toContainText("Copied");
  expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(code);

  // A price drop with a code keeps its orange "Get deal", which copies the code too.
  await page.goto("/deals/ninja-air-fryer-dual-zone");
  await stayHere();
  const getDeal = page.locator("#deal-cta");
  await expect(getDeal).toHaveAttribute("aria-label", "Get deal: copies AIRFRY15 and opens Currys");
  // On a price drop the code is part of the price.
  await expect(page.getByText("Price with code").first()).toBeVisible();
  await getDeal.click();
  await expect(getDeal).toContainText("Copied");
  expect(await page.evaluate(() => navigator.clipboard.readText())).toBe("AIRFRY15");
});

test("a signed-out heart doesn't count: it offers Log in and Join free, and nothing moves", async ({ page }) => {
  await page.goto("/");
  const heart = page.getByRole("button", { name: "Love this deal" }).first();
  const pill = heart.locator("..");
  // Just the number (no floating "+5" for a signed-out tap).
  const count = pill.locator("span.font-semibold");
  const countBefore = (await count.innerText()).trim();
  const boxBefore = await pill.boundingBox();
  const height = await page.evaluate(() => document.documentElement.scrollHeight);

  await heart.click();
  const bubble = page.getByRole("status").filter({ hasText: "Log in to make your heart count" });
  await expect(bubble).toBeVisible();
  await expect(bubble.getByRole("link", { name: "Log in" })).toHaveAttribute("href", /^\/login\?next=/);
  await expect(bubble.getByRole("link", { name: "Join free" })).toHaveAttribute("href", /^\/signup\?next=/);

  // The count is the true one, the heart isn't left pressed, and the page didn't move.
  expect((await count.innerText()).trim()).toBe(countBefore);
  await expect(heart).toHaveAttribute("aria-pressed", "false");
  expect(await pill.boundingBox()).toEqual(boxBefore);
  expect(await page.evaluate(() => document.documentElement.scrollHeight)).toBe(height);

  // Escape puts it away.
  await page.keyboard.press("Escape");
  await expect(bubble).toHaveCount(0);
});

test("/search?q= goes to the same results as the search box, and nothing is missed", async ({ page }) => {
  await page.goto("/search?q=lego");
  await expect(page).toHaveURL(/\/\?q=lego$/);
  await expect(page.getByRole("heading", { name: /Search results/, level: 1 })).toBeVisible();
  await page.goto("/search");
  await expect(page).toHaveURL(/\/$/);
});

test("signing up: the age tick is needed, and a password everyone guesses is refused", async ({ page }) => {
  await page.goto("/signup");
  const name = `weak_${Math.floor(Math.random() * 1e6)}`;
  await page.getByPlaceholder("dealhunter99").fill(name);
  await page.getByPlaceholder("you@example.com").fill(`${name}@example.invalid`);
  await page.getByPlaceholder("At least 8 characters").fill("Password123!");
  await page.waitForTimeout(3500);
  // Without the tick the browser stops it.
  await page.getByRole("button", { name: "Join free" }).click();
  await expect(page).toHaveURL(/\/signup$/);
  await page.getByLabel(/or over/).check();
  await page.getByRole("button", { name: "Join free" }).click();
  await expect(page.getByText(/first things hackers try/)).toBeVisible();
  // A throwaway inbox is turned away too (the form comes back empty after an error).
  await page.getByPlaceholder("dealhunter99").fill(name);
  await page.getByPlaceholder("you@example.com").fill(`${name}@mailinator.com`);
  await page.getByPlaceholder("At least 8 characters").fill("three random words here");
  await page.getByLabel(/or over/).check();
  await page.waitForTimeout(3500);
  await page.getByRole("button", { name: "Join free" }).click();
  await expect(page.getByText(/Throwaway inboxes can't be used/)).toBeVisible();
});
