import { test, expect, type Page } from "@playwright/test";
import { ADMIN_TOKEN } from "./constants";

// Writing with formatting, pictures, links and deal cards: a Community thread
// and a reply, and a comment on a deal, as the signed-in admin that
// e2e/serve.mjs made (a brand-new member can't add pictures or links).
test.use({ storageState: { cookies: [{ name: "dealsnap_session", value: ADMIN_TOKEN, domain: "localhost", path: "/", httpOnly: true, secure: false, sameSite: "Lax", expires: -1 }], origins: [] } });
test.describe.configure({ mode: "serial" });

// A small picture (120×80, orange).
const PNG = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAHgAAABQCAIAAABd+SbeAAAACXBIWXMAAAPoAAAD6AG1e1JrAAABHUlEQVR4nO3UwY1CARDDUKpwo1T/bzTAlc1o9aRUYDl+Pe/s+T2EF8rPn6gGdED3n97G6IBuriGjm4OTjm5OowO6uYaMbg5OOro5jQ7o5hoyujk46ejmNDqgm2vI6ObgpKOb0+iAbq4ho5uDk45uTqMDurmGjG4OTjq6OY0O6OYaMro5OOno5jQ6oJtryOjm4KSjm9PogG6uIaObg5OObk6jA7q5hoxuDk46ujmNDujmGjK6OTjp6OY0OqCba8jo5uCko5vT6IBuriGjm4OTjm5OowO6uYaMbg5OOro5jQ7o5hoyujk46ejmNDqgm2vI6ObgpKOb0+iAbq4ho5uDk45uTqMDurmGjG4OTjq6OY0O6OYaMro5OOlozvTrPhbjjklG+aHoAAAAAElFTkSuQmCC",
  "base64"
);
const picture = (name: string) => ({ name, mimeType: "image/png", buffer: PNG });

// The address of a live deal to paste in, as a card.
async function someDeal(page: Page): Promise<string> {
  await page.goto("/?q=lego");
  const href = await page.locator('a[href^="/deals/"]').first().getAttribute("href");
  return href!.split("#")[0];
}

let threadUrl = "";

test("a Community thread with formatting, a picture, a link and a deal card", async ({ page }, info) => {
  const deal = await someDeal(page);
  const origin = new URL(page.url()).origin;
  await page.goto("/community/new");
  await page.locator("#thread-title").fill(`Where the code box is at Currys ${info.project.name}`);
  const box = page.getByRole("textbox", { name: "What do you want to say?" });
  await box.click();
  await page.keyboard.type("The code goes in ");
  await page.keyboard.press("ControlOrMeta+b");
  await page.keyboard.type("at the basket");
  await page.keyboard.press("ControlOrMeta+b");
  await page.keyboard.type(", see:");
  await page.locator('label[title="Add a picture"] input[type="file"]').setInputFiles(picture("basket.png"));
  await expect(page.getByRole("button", { name: "Remove picture 1" })).toBeVisible();
  await page.keyboard.type("Their help page: https://www.currys.co.uk/help?utm_source=newsletter");
  await page.keyboard.press("Enter");
  await page.keyboard.type(`${origin}${deal}`);
  await page.getByRole("button", { name: "Post thread" }).click();
  await expect(page).toHaveURL(/\/community\/t\//);
  threadUrl = new URL(page.url()).pathname;

  const post = page.locator("article").first();
  await expect(post.locator("strong", { hasText: "at the basket" })).toBeVisible();
  await expect(post.getByRole("img", { name: /^Picture 1 from / })).toBeVisible();
  await expect(post.locator(`a[href="${deal}"]`)).toBeVisible(); // the deal card
  const link = post.locator('a[href^="/out/p/"]');
  await expect(link).toContainText("currys.co.uk/help");
  await expect(link).toHaveAttribute("rel", /nofollow/);

  // The link goes out clean; an address that isn't in the post goes nowhere.
  const href = (await link.first().getAttribute("href"))!;
  const out = await page.request.get(href, { maxRedirects: 0 });
  expect(out.status()).toBe(302);
  expect(out.headers().location).toBe("https://www.currys.co.uk/help");
  const sneaky = await page.request.get(href.replace(/\?to=.*/, `?to=${encodeURIComponent("https://evil.example/")}`), { maxRedirects: 0 });
  expect(sneaky.headers().location).toContain(threadUrl);

  // The picture opens on its own, and closes.
  await post.getByRole("button", { name: /^Open picture 1 from .* full size$/ }).click();
  await expect(page.getByRole("dialog").getByRole("img")).toBeVisible();
  await page.getByRole("button", { name: "Close picture" }).click();
  await expect(page.getByRole("dialog")).toHaveCount(0);
});

test("a reply with a picture", async ({ page }) => {
  await page.goto(threadUrl);
  await page.getByRole("button", { name: /^Add a reply/ }).click();
  const box = page.getByRole("textbox", { name: "Add a reply" });
  await expect(box).toBeFocused();
  await page.keyboard.type("Same for me, it's here:");
  await page.locator('form label[title="Add a picture"] input[type="file"]').setInputFiles(picture("mine.png"));
  await expect(page.getByRole("button", { name: "Remove picture 1" })).toBeVisible();
  await page.getByRole("button", { name: "Reply", exact: true }).click();
  await expect(page.locator("article").nth(1).getByRole("img", { name: /^Picture 1 from / })).toBeVisible();
  await expect(page.locator("article").nth(1)).toContainText("Same for me, it's here:");
});

test("a comment with a picture and a better deal as a card", async ({ page }) => {
  // Two different deals: one to comment on, one to point at.
  await page.goto("/?q=lego");
  const origin = new URL(page.url()).origin;
  const hrefs = [...new Set((await page.locator('a[href^="/deals/"]').evaluateAll((as) => as.map((a) => a.getAttribute("href")!.split("#")[0]))))];
  const [here, deal] = hrefs;
  await page.goto(here);
  const box = page.getByRole("textbox", { name: "Add a comment" });
  await box.fill(`This one's cheaper:\n${origin}${deal}`);
  await page.locator('form label[title="Add a picture"] input[type="file"]').setInputFiles(picture("receipt.png"));
  await expect(page.getByRole("button", { name: "Remove picture 1" })).toBeVisible();
  await page.getByRole("button", { name: "Post", exact: true }).click();
  const comment = page.locator("article", { hasText: "This one's cheaper:" }).first();
  await expect(comment.locator(`a[href="${deal}"]`)).toBeVisible();
  await expect(comment.getByRole("img", { name: /^Picture 1 from / })).toBeVisible();
  await comment.getByRole("button", { name: /^Open picture 1 from / }).click();
  await expect(page.getByRole("dialog").getByRole("img")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).toHaveCount(0);
});
